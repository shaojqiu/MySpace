 #ifndef __checkapperrlog__
   #define __checkapperrlog__

   #ifdef NOAPPERRLOG
     #define APPERRLOG
     #define apperrlog cerr
   #else
     #include "apperrlog.hpp"
   #endif 

 #endif

 #include <private/imcommon.h> 
 #include <implatform.h> //D228 - for definitions of CORBAENV_xxxx macros

// -----------------------------------------------------------------------------
// PPTManagerPPTManager_i
// -----------------------------------------------------------------------------
class PPTManagerPPTManager_i_m : public PPTManager_i {

  public:
/* PPTManager::PPTManager_init */
virtual ::CORBA::Void  PPTManager_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::PPTManager_init()";
        PPTManager_i::PPTManager_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PPTManager::PPTManager_uninit */
virtual ::CORBA::Void  PPTManager_uninit (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::PPTManager_uninit()";
        PPTManager_i::PPTManager_uninit (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PPTManager::txHoldBankLotReq */
virtual ::CORBA::Long  txHoldBankLotReq (::pptHoldBankLotReqResult& strHoldBankLotReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifier& reasonCodeID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txHoldBankLotReq()";
        retVal =        PPTManager_i::txHoldBankLotReq ( strHoldBankLotReqResult, strObjCommonIn, seqIndex, lotIDs, reasonCodeID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txHoldReleaseBankLotReq */
virtual ::CORBA::Long  txHoldReleaseBankLotReq (::pptHoldReleaseBankLotReqResult& strHoldReleaseBankLotReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifier& reasonCodeID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txHoldReleaseBankLotReq()";
        retVal =        PPTManager_i::txHoldReleaseBankLotReq ( strHoldReleaseBankLotReqResult, strObjCommonIn, seqIndex, lotIDs, reasonCodeID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBankMoveReq */
virtual ::CORBA::Long  txBankMoveReq (::pptBankMoveReqResult& strBankMoveReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifier& toBankID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBankMoveReq()";
        retVal =        PPTManager_i::txBankMoveReq ( strBankMoveReqResult, strObjCommonIn, seqIndex, lotIDs, toBankID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txShipReq */
virtual ::CORBA::Long  txShipReq (::pptShipReqResult& strShipReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifier& bankID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txShipReq()";
        retVal =        PPTManager_i::txShipReq ( strShipReqResult, strObjCommonIn, seqIndex, lotIDs, bankID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txShipCancelReq */
virtual ::CORBA::Long  txShipCancelReq (::pptShipCancelReqResult& strShipCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifier& bankID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txShipCancelReq()";
        retVal =        PPTManager_i::txShipCancelReq ( strShipCancelReqResult, strObjCommonIn, seqIndex, lotIDs, bankID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txVendLotReceiveReq */
virtual ::CORBA::Long  txVendLotReceiveReq (::pptVendLotReceiveReqResult& strVendLotReceiveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const ::objectIdentifier& productID, const char* creatingLotID, const char* subLotType, ::CORBA::Long productCount, const char* vendorLotID, const char* vendorID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txVendLotReceiveReq()";
        retVal =        PPTManager_i::txVendLotReceiveReq ( strVendLotReceiveReqResult, strObjCommonIn, bankID, productID, creatingLotID, subLotType, productCount, vendorLotID, vendorID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txVendLotReturnReq */
virtual ::CORBA::Long  txVendLotReturnReq (::pptVendLotReturnReqResult& strVendLotReturnReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, ::CORBA::Long returnProductCount, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txVendLotReturnReq()";
        retVal =        PPTManager_i::txVendLotReturnReq ( strVendLotReturnReqResult, strObjCommonIn, lotID, returnProductCount, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBankListInq */
virtual ::CORBA::Long  txBankListInq (::pptBankListInqResult& strBankListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* inqBank, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBankListInq()";
        retVal =        PPTManager_i::txBankListInq ( strBankListInqResult, strObjCommonIn, inqBank, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDataSpecCheckReq */
virtual ::CORBA::Long  txDataSpecCheckReq (::pptDataSpecCheckReqResult& strDataSpecCheckReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDataSpecCheckReq()";
        retVal =        PPTManager_i::txDataSpecCheckReq ( strDataSpecCheckReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSpcCheckReq */
virtual ::CORBA::Long  txSpcCheckReq (::pptSpcCheckReqResult& strSpcCheckReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSpcCheckReq()";
        retVal =        PPTManager_i::txSpcCheckReq ( strSpcCheckReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txScrapWaferCancelReq */
virtual ::CORBA::Long  txScrapWaferCancelReq (::pptScrapWaferCancelReqResult& strScrapWaferCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& cassetteID, const ::pptScrapCancelWafersSequence& strScrapCancelWafers, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txScrapWaferCancelReq()";
        retVal =        PPTManager_i::txScrapWaferCancelReq ( strScrapWaferCancelReqResult, strObjCommonIn, lotID, cassetteID, strScrapCancelWafers, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txScrapWaferReq */
virtual ::CORBA::Long  txScrapWaferReq (::pptScrapWaferReqResult& strScrapWaferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& cassetteID, const ::objectIdentifier& reasonRouteID, const ::objectIdentifier& reasonOperationID, const char* reasonOperationNumber, const char* reasonOperationPass, const char* objrefPO, const ::pptScrapWafersSequence& strScrapWafers, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txScrapWaferReq()";
        retVal =        PPTManager_i::txScrapWaferReq ( strScrapWaferReqResult, strObjCommonIn, lotID, cassetteID, reasonRouteID, reasonOperationID, reasonOperationNumber, reasonOperationPass, objrefPO, strScrapWafers, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txScrapHistoryInq */
virtual ::CORBA::Long  txScrapHistoryInq (::pptScrapHistoryInqResult& strScrapHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txScrapHistoryInq()";
        retVal =        PPTManager_i::txScrapHistoryInq ( strScrapHistoryInqResult, strObjCommonIn, lotID, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAutoFlowBatchingReq */
virtual ::CORBA::Long  txAutoFlowBatchingReq (::pptAutoFlowBatchingReqResult& strAutoFlowBatchingReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAutoFlowBatchingReq()";
        retVal =        PPTManager_i::txAutoFlowBatchingReq ( strAutoFlowBatchingReqResult, strObjCommonIn, equipmentID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFlowBatchingReq */
virtual ::CORBA::Long  txFlowBatchingReq (::pptFlowBatchingReqResult& strFlowBatchingReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptFlowBatchingReqCassetteSequence& strFlowBatchingReqCassette, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFlowBatchingReq()";
        retVal =        PPTManager_i::txFlowBatchingReq ( strFlowBatchingReqResult, strObjCommonIn, equipmentID, strFlowBatchingReqCassette, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpReserveCancelReq */
virtual ::CORBA::Long  txEqpReserveCancelReq (::pptEqpReserveCancelReqResult& strEqpReserveCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& flowBatchID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpReserveCancelReq()";
        retVal =        PPTManager_i::txEqpReserveCancelReq ( strEqpReserveCancelReqResult, strObjCommonIn, equipmentID, flowBatchID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpReserveReq */
virtual ::CORBA::Long  txEqpReserveReq (::pptEqpReserveReqResult& strEqpReserveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& flowBatchID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpReserveReq()";
        retVal =        PPTManager_i::txEqpReserveReq ( strEqpReserveReqResult, strObjCommonIn, equipmentID, flowBatchID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotRemoveFromFlowBatchReq */
virtual ::CORBA::Long  txLotRemoveFromFlowBatchReq (::pptLotRemoveFromFlowBatchReqResult& strLotRemoveFromFlowBatchReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& flowBatchID, const ::pptRemoveCassetteSequence& strRemoveCassette, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotRemoveFromFlowBatchReq()";
        retVal =        PPTManager_i::txLotRemoveFromFlowBatchReq ( strLotRemoveFromFlowBatchReqResult, strObjCommonIn, flowBatchID, strRemoveCassette, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFlowBatchInq */
virtual ::CORBA::Long  txFlowBatchInq (::pptFlowBatchInqResult& strFlowBatchInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& flowBatchID, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFlowBatchInq()";
        retVal =        PPTManager_i::txFlowBatchInq ( strFlowBatchInqResult, strObjCommonIn, flowBatchID, lotID, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFloatingBatchInq */
virtual ::CORBA::Long  txFloatingBatchInq (::pptFloatingBatchInqResult& strFloatingBatchInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFloatingBatchInq()";
        retVal =        PPTManager_i::txFloatingBatchInq ( strFloatingBatchInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatNextLotListInq */
virtual ::CORBA::Long  txWhatNextLotListInq (::pptWhatNextLotListInqResult& strWhatNextLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* selectCriteria, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatNextLotListInq()";
        retVal =        PPTManager_i::txWhatNextLotListInq ( strWhatNextLotListInqResult, strObjCommonIn, equipmentID, selectCriteria, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhereNextInterBayInq */
virtual ::CORBA::Long  txWhereNextInterBayInq (::pptWhereNextInterBayInqResult& strWhereNextInterBayInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhereNextInterBayInq()";
        retVal =        PPTManager_i::txWhereNextInterBayInq ( strWhereNextInterBayInqResult, strObjCommonIn, lotID, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpStatusChangeRpt */
virtual ::CORBA::Long  txEqpStatusChangeRpt (::pptEqpStatusChangeRptResult& strEqpStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& equipmentStatusCode, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpStatusChangeRpt()";
        retVal =        PPTManager_i::txEqpStatusChangeRpt ( strEqpStatusChangeRptResult, strObjCommonIn, equipmentID, equipmentStatusCode, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCandidateEqpStatusInq */
virtual ::CORBA::Long  txCandidateEqpStatusInq (::pptCandidateEqpStatusInqResult& strCandidateEqpStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean allInquiryFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCandidateEqpStatusInq()";
        retVal =        PPTManager_i::txCandidateEqpStatusInq ( strCandidateEqpStatusInqResult, strObjCommonIn, requestUserID, equipmentID, allInquiryFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoInq */
virtual ::CORBA::Long  txEqpInfoInq (::pptEqpInfoInqResult& strEqpInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoInq()";
        retVal =        PPTManager_i::txEqpInfoInq ( strEqpInfoInqResult, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpListInq */
virtual ::CORBA::Long  txEqpListInq (::pptEqpListInqResult& strEqpListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpListInqInParm& strEqpListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpListInq()";
        retVal =        PPTManager_i::txEqpListInq ( strEqpListInqResult, strObjCommonIn, strEqpListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpNoteInq */
virtual ::CORBA::Long  txEqpNoteInq (::pptEqpNoteInqResult& strEqpNoteInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpNoteInq()";
        retVal =        PPTManager_i::txEqpNoteInq ( strEqpNoteInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCandidateChamberStatusInq */
virtual ::CORBA::Long  txCandidateChamberStatusInq (::pptCandidateChamberStatusInqResult& strCandidateChamberStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCandidateChamberStatusInq()";
        retVal =        PPTManager_i::txCandidateChamberStatusInq ( strCandidateChamberStatusInqResult, strObjCommonIn, equipmentID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpNoteRegistReq */
virtual ::CORBA::Long  txEqpNoteRegistReq (::pptEqpNoteRegistReqResult& strEqpNoteRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* noteTitle, const char* equipmentNote, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpNoteRegistReq()";
        retVal =        PPTManager_i::txEqpNoteRegistReq ( strEqpNoteRegistReqResult, strObjCommonIn, equipmentID, noteTitle, equipmentNote, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSystemMsgRpt */
virtual ::CORBA::Long  txSystemMsgRpt (::pptSystemMsgRptResult& strSystemMsgRptResult, const ::pptObjCommonIn& strObjCommonIn, const char* subSystemID, const char* systemMessageCode, const char* systemMessageText, ::CORBA::Boolean notifyFlag, const ::objectIdentifier& equipmentID, const char* equipmentStatus, const ::objectIdentifier& stockerID, const char* stockerStatus, const ::objectIdentifier& AGVID, const char* AGVStatus, const ::objectIdentifier& lotID, const char* lotStatus, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const char* systemMessageTimeStamp, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSystemMsgRpt()";
        retVal =        PPTManager_i::txSystemMsgRpt ( strSystemMsgRptResult, strObjCommonIn, subSystemID, systemMessageCode, systemMessageText, notifyFlag, equipmentID, equipmentStatus, stockerID, stockerStatus, AGVID, AGVStatus, lotID, lotStatus, routeID, operationID, operationNumber, systemMessageTimeStamp, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteXferJobCompRpt */
virtual ::CORBA::Long  txLotCassetteXferJobCompRpt (::pptLotCassetteXferJobCompRptResult& strLotCassetteXferJobCompRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptXferJobCompSequence& strXferJob, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteXferJobCompRpt()";
        retVal =        PPTManager_i::txLotCassetteXferJobCompRpt ( strLotCassetteXferJobCompRptResult, strObjCommonIn, strXferJob, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteXferStatusChangeRpt */
virtual ::CORBA::Long  txLotCassetteXferStatusChangeRpt (::pptLotCassetteXferStatusChangeRptResult& strLotCassetteXferStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& carrierID, const char* xferStatus, ::CORBA::Boolean ManualInFlag, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const char* zoneID, const char* shelfType, const char* transferStatusChangeTimeStamp, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteXferStatusChangeRpt()";
        retVal =        PPTManager_i::txLotCassetteXferStatusChangeRpt ( strLotCassetteXferStatusChangeRptResult, strObjCommonIn, carrierID, xferStatus, ManualInFlag, machineID, portID, zoneID, shelfType, transferStatusChangeTimeStamp, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteReserveCancelReq */
virtual ::CORBA::Long  txLotCassetteReserveCancelReq (::pptLotCassetteReserveCancelReqResult& strLotCassetteReserveCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRsvCanLotCarrierSequence& strRsvCanLotCarrier, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteReserveCancelReq()";
        retVal =        PPTManager_i::txLotCassetteReserveCancelReq ( strLotCassetteReserveCancelReqResult, strObjCommonIn, strRsvCanLotCarrier, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteReserveReq */
virtual ::CORBA::Long  txLotCassetteReserveReq (::pptLotCassetteReserveReqResult& strLotCassetteReserveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRsvLotCarrierSequence& strRsvLotCarrier, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteReserveReq()";
        retVal =        PPTManager_i::txLotCassetteReserveReq ( strLotCassetteReserveReqResult, strObjCommonIn, strRsvLotCarrier, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStockerInventoryRpt */
virtual ::CORBA::Long  txStockerInventoryRpt (::pptStockerInventoryRptResult& strStockerInventoryRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::pptInventoryLotInfoSequence& strInventoryLotInfo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStockerInventoryRpt()";
        retVal =        PPTManager_i::txStockerInventoryRpt ( strStockerInventoryRptResult, strObjCommonIn, stockerID, strInventoryLotInfo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStockerInventoryReq */
virtual ::CORBA::Long  txStockerInventoryReq (::pptStockerInventoryReqResult& strStockerInventoryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStockerInventoryReq()";
        retVal =        PPTManager_i::txStockerInventoryReq ( strStockerInventoryReqResult, strObjCommonIn, machineID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStockerStatusChangeRpt */
virtual ::CORBA::Long  txStockerStatusChangeRpt (::pptStockerStatusChangeRptResult& strStockerStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::objectIdentifier& stockerStatusCode, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStockerStatusChangeRpt()";
        retVal =        PPTManager_i::txStockerStatusChangeRpt ( strStockerStatusChangeRptResult, strObjCommonIn, stockerID, stockerStatusCode, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAvailableStockerInq */
virtual ::CORBA::Long  txAvailableStockerInq (::pptAvailableStockerInqResult& strAvailableStockerInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAvailableStockerInq()";
        retVal =        PPTManager_i::txAvailableStockerInq ( strAvailableStockerInqResult, strObjCommonIn, requestUserID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteXferJobInq */
virtual ::CORBA::Long  txLotCassetteXferJobInq (::pptLotCassetteXferJobInqResult& strLotCassetteXferJobInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean detailFlag, const char* inquiryType, const ::objectIdentifier& inquiryKey, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteXferJobInq()";
        retVal =        PPTManager_i::txLotCassetteXferJobInq ( strLotCassetteXferJobInqResult, strObjCommonIn, detailFlag, inquiryType, inquiryKey, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStockerInfoInq */
virtual ::CORBA::Long  txStockerInfoInq (::pptStockerInfoInqResult& strStockerInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, ::CORBA::Boolean detailFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStockerInfoInq()";
        retVal =        PPTManager_i::txStockerInfoInq ( strStockerInfoInqResult, strObjCommonIn, machineID, detailFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStockerListInq */
virtual ::CORBA::Long  txStockerListInq (::pptStockerListInqResult& strStockerListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* stockerType, ::CORBA::Boolean availFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStockerListInq()";
        retVal =        PPTManager_i::txStockerListInq ( strStockerListInqResult, strObjCommonIn, stockerType, availFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txNewLotReleaseReq */
virtual ::CORBA::Long  txNewLotReleaseReq (::pptNewLotReleaseReqResult& strNewLotReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::pptReleaseLotAttributesSequence& strReleaseLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txNewLotReleaseReq()";
        retVal =        PPTManager_i::txNewLotReleaseReq ( strNewLotReleaseReqResult, strObjCommonIn, seqIndex, strReleaseLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txNewLotReleaseCancelReq */
virtual ::CORBA::Long  txNewLotReleaseCancelReq (::pptNewLotReleaseCancelReqResult& strNewLotReleaseCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::objectIdentifierSequence& lotIDs, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txNewLotReleaseCancelReq()";
        retVal =        PPTManager_i::txNewLotReleaseCancelReq ( strNewLotReleaseCancelReqResult, strObjCommonIn, seqIndex, lotIDs, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotMfgOrderChangeReq */
virtual ::CORBA::Long  txLotMfgOrderChangeReq (::pptLotMfgOrderChangeReqResult& strLotMfgOrderChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::pptChangedLotAttributesSequence& strChangedLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotMfgOrderChangeReq()";
        retVal =        PPTManager_i::txLotMfgOrderChangeReq ( strLotMfgOrderChangeReqResult, strObjCommonIn, seqIndex, strChangedLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotSchdlChangeReq */
virtual ::CORBA::Long  txLotSchdlChangeReq (::pptLotSchdlChangeReqResult& strLotSchdlChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRescheduledLotAttributesSequence& strRescheduledLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotSchdlChangeReq()";
        retVal =        PPTManager_i::txLotSchdlChangeReq ( strLotSchdlChangeReqResult, strObjCommonIn, strRescheduledLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteExchangeReq */
virtual ::CORBA::Long  txCassetteExchangeReq (::pptCassetteExchangeReqResult& strCassetteExchangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptWaferTransferSequence& strWaferXferSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteExchangeReq()";
        retVal =        PPTManager_i::txCassetteExchangeReq ( strCassetteExchangeReqResult, strObjCommonIn, equipmentID, strWaferXferSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSortReq */
virtual ::CORBA::Long  txWaferSortReq (::pptWaferSortReqResult& strWaferSortReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptWaferTransferSequence& strWaferXferSeq, ::CORBA::Boolean bNotifyToTCS, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSortReq()";
        retVal =        PPTManager_i::txWaferSortReq ( strWaferSortReqResult, strObjCommonIn, equipmentID, strWaferXferSeq, bNotifyToTCS, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSortRpt */
virtual ::CORBA::Long  txWaferSortRpt (::pptWaferSortRptResult& strWaferSortRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptWaferTransferSequence& strWaferXferSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSortRpt()";
        retVal =        PPTManager_i::txWaferSortRpt ( strWaferSortRptResult, strObjCommonIn, equipmentID, strWaferXferSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMakeRelationMonitorProdLotsReq */
virtual ::CORBA::Long  txMakeRelationMonitorProdLotsReq (::pptMakeRelationMonitorProdLotsReqResult& strMakeRelationMonitorProdLotsReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& monitorLotID, const ::pptMonRelatedProdLotsSequence& strMonRelatedProdLots, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMakeRelationMonitorProdLotsReq()";
        retVal =        PPTManager_i::txMakeRelationMonitorProdLotsReq ( strMakeRelationMonitorProdLotsReqResult, strObjCommonIn, monitorLotID, strMonRelatedProdLots, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMonitorLotSTBAfterProcessReq */
virtual ::CORBA::Long  txMonitorLotSTBAfterProcessReq (::pptMonitorLotSTBAfterProcessReqResult& strMonitorLotSTBAfterProcessReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& processEquipmentID, const char* stbLotSubLotType, const ::pptNewLotAttributes& strNewLotAttributes, const ::objectIdentifierSequence& productLotIDs, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMonitorLotSTBAfterProcessReq()";
        retVal =        PPTManager_i::txMonitorLotSTBAfterProcessReq ( strMonitorLotSTBAfterProcessReqResult, strObjCommonIn, processEquipmentID, stbLotSubLotType, strNewLotAttributes, productLotIDs, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCtrlLotSTBReq */
virtual ::CORBA::Long  txCtrlLotSTBReq (::pptCtrlLotSTBReqResult& strCtrlLotSTBReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& productID, ::CORBA::Long waferCount, const char* lotType, const char* subLotType, const ::pptNewLotAttributes& strNewLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCtrlLotSTBReq()";
        retVal =        PPTManager_i::txCtrlLotSTBReq ( strCtrlLotSTBReqResult, strObjCommonIn, productID, waferCount, lotType, subLotType, strNewLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txConnectedRouteListInq */
virtual ::CORBA::Long  txConnectedRouteListInq (::pptConnectedRouteListInqResult& strConnectedRouteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& cassetteID, const char* routeType, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txConnectedRouteListInq()";
        retVal =        PPTManager_i::txConnectedRouteListInq ( strConnectedRouteListInqResult, strObjCommonIn, lotID, cassetteID, routeType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSourceLotInq */
virtual ::CORBA::Long  txSourceLotInq (::pptSourceLotInqResult& strSourceLotInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& productID, const ::objectIdentifier& productRequestID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSourceLotInq()";
        retVal =        PPTManager_i::txSourceLotInq ( strSourceLotInqResult, strObjCommonIn, productID, productRequestID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleInventoryReq */
virtual ::CORBA::Long  txReticleInventoryReq (::pptReticleInventoryReqResult& strReticleInventoryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleInventoryReq()";
        retVal =        PPTManager_i::txReticleInventoryReq ( strReticleInventoryReqResult, strObjCommonIn, stockerID, equipmentID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStatusInq */
virtual ::CORBA::Long  txReticleStatusInq (::pptReticleStatusInqResult& strReticleStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStatusInq()";
        retVal =        PPTManager_i::txReticleStatusInq ( strReticleStatusInqResult, strObjCommonIn, reticleID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleListInq */
virtual ::CORBA::Long  txReticleListInq (::pptReticleListInqResult& strReticleListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReticleListInqInParm& strReticleListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleListInq()";
        retVal =        PPTManager_i::txReticleListInq ( strReticleListInqResult, strObjCommonIn, strReticleListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStockerInfoInq */
virtual ::CORBA::Long  txReticleStockerInfoInq (::pptReticleStockerInfoInqResult& strReticleStockerInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStockerInfoInq()";
        retVal =        PPTManager_i::txReticleStockerInfoInq ( strReticleStockerInfoInqResult, strObjCommonIn, stockerID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleXferStatusChangeRpt */
virtual ::CORBA::Long  txReticleXferStatusChangeRpt (::pptReticleXferStatusChangeRptResult& strReticleXferStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptXferReticleSequence& strXferReticle, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleXferStatusChangeRpt()";
        retVal =        PPTManager_i::txReticleXferStatusChangeRpt ( strReticleXferStatusChangeRptResult, strObjCommonIn, stockerID, equipmentID, strXferReticle, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStatusChangeRpt */
virtual ::CORBA::Long  txReticleStatusChangeRpt (::pptReticleStatusChangeRptResult& strReticleStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const char* reticleStatus, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStatusChangeRpt()";
        retVal =        PPTManager_i::txReticleStatusChangeRpt ( strReticleStatusChangeRptResult, strObjCommonIn, reticleID, reticleStatus, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleUsageCountResetReq */
virtual ::CORBA::Long  txReticleUsageCountResetReq (::pptReticleUsageCountResetReqResult& strReticleUsageCountResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleUsageCountResetReq()";
        retVal =        PPTManager_i::txReticleUsageCountResetReq ( strReticleUsageCountResetReqResult, strObjCommonIn, reticleID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleInventoryRpt */
virtual ::CORBA::Long  txReticleInventoryRpt (::pptReticleInventoryRptResult& strReticleInventoryRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptInventoryReticleInfoSequence& strInventoryReticleInfo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleInventoryRpt()";
        retVal =        PPTManager_i::txReticleInventoryRpt ( strReticleInventoryRptResult, strObjCommonIn, stockerID, equipmentID, strInventoryReticleInfo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBulletinBoardInfoInq */
virtual ::CORBA::Long  txBulletinBoardInfoInq (::pptBulletinBoardInfoInqResult& strBulletinBoardInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBulletinBoardInfoInq()";
        retVal =        PPTManager_i::txBulletinBoardInfoInq ( strBulletinBoardInfoInqResult, strObjCommonIn, requestUserID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCommentInfoInq */
virtual ::CORBA::Long  txLotCommentInfoInq (::pptLotCommentInfoInqResult& strLotCommentInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCommentInfoInq()";
        retVal =        PPTManager_i::txLotCommentInfoInq ( strLotCommentInfoInqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotNoteInfoInq */
virtual ::CORBA::Long  txLotNoteInfoInq (::pptLotNoteInfoInqResult& strLotNoteInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotNoteInfoInq()";
        retVal =        PPTManager_i::txLotNoteInfoInq ( strLotNoteInfoInqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotOperationNoteInfoInq */
virtual ::CORBA::Long  txLotOperationNoteInfoInq (::pptLotOperationNoteInfoInqResult& strLotOperationNoteInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotOperationNoteInfoInq()";
        retVal =        PPTManager_i::txLotOperationNoteInfoInq ( strLotOperationNoteInfoInqResult, strObjCommonIn, lotID, routeID, operationID, operationNumber, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotOperationNoteListInq */
virtual ::CORBA::Long  txLotOperationNoteListInq (::pptLotOperationNoteListInqResult& strLotOperationNoteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotOperationNoteListInq()";
        retVal =        PPTManager_i::txLotOperationNoteListInq ( strLotOperationNoteListInqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeGuideInfoInq */
virtual ::CORBA::Long  txOpeGuideInfoInq (::pptOpeGuideInfoInqResult& strOpeGuideInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeGuideInfoInq()";
        retVal =        PPTManager_i::txOpeGuideInfoInq ( strOpeGuideInfoInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOperationHistoryInq */
virtual ::CORBA::Long  txOperationHistoryInq (::pptOperationHistoryInqResult& strOperationHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const char* operationPass, const char* operationCategory, ::CORBA::Boolean pinPointFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOperationHistoryInq()";
        retVal =        PPTManager_i::txOperationHistoryInq ( strOperationHistoryInqResult, strObjCommonIn, lotID, routeID, operationID, operationNumber, operationPass, operationCategory, pinPointFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRouteOperationListInq */
virtual ::CORBA::Long  txRouteOperationListInq (::pptRouteOperationListInqResult& strRouteOperationListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, ::CORBA::Long searchCount, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRouteOperationListInq()";
        retVal =        PPTManager_i::txRouteOperationListInq ( strRouteOperationListInqResult, strObjCommonIn, routeID, operationID, operationNumber, searchCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReasonListInq */
virtual ::CORBA::Long  txReasonListInq (::pptReasonListInqResult& strReasonListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* codeCategory, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReasonListInq()";
        retVal =        PPTManager_i::txReasonListInq ( strReasonListInqResult, strObjCommonIn, codeCategory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUserDescInq */
virtual ::CORBA::Long  txUserDescInq (::pptUserDescInqResult& strUserDescInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& userID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUserDescInq()";
        retVal =        PPTManager_i::txUserDescInq ( strUserDescInqResult, strObjCommonIn, userID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBulletinBoardInfoRegistReq */
virtual ::CORBA::Long  txBulletinBoardInfoRegistReq (::pptBulletinBoardInfoRegistReqResult& strBulletinBoardInfoRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* noticeTitle, const char* noticeDescription, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBulletinBoardInfoRegistReq()";
        retVal =        PPTManager_i::txBulletinBoardInfoRegistReq ( strBulletinBoardInfoRegistReqResult, strObjCommonIn, noticeTitle, noticeDescription, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotNoteInfoRegistReq */
virtual ::CORBA::Long  txLotNoteInfoRegistReq (::pptLotNoteInfoRegistReqResult& strLotNoteInfoRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* lotNoteTitle, const char* lotNoteDescription, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotNoteInfoRegistReq()";
        retVal =        PPTManager_i::txLotNoteInfoRegistReq ( strLotNoteInfoRegistReqResult, strObjCommonIn, lotID, lotNoteTitle, lotNoteDescription, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotOperationNoteInfoRegistReq */
virtual ::CORBA::Long  txLotOperationNoteInfoRegistReq (::pptLotOperationNoteInfoRegistReqResult& strLotOperationNoteInfoRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const char* lotOperationNoteTitle, const char* lotOperationNoteDescription, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotOperationNoteInfoRegistReq()";
        retVal =        PPTManager_i::txLotOperationNoteInfoRegistReq ( strLotOperationNoteInfoRegistReqResult, strObjCommonIn, lotID, routeID, operationID, operationNumber, lotOperationNoteTitle, lotOperationNoteDescription, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBankInReq */
virtual ::CORBA::Long  txBankInReq (::pptBankInReqResult& strBankInReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::objectIdentifierSequence& lotID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBankInReq()";
        retVal =        PPTManager_i::txBankInReq ( strBankInReqResult, strObjCommonIn, seqIndex, lotID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSubRouteBranchReq */
virtual ::CORBA::Long  txSubRouteBranchReq (::pptSubRouteBranchReqResult& strSubRouteBranchReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& currentRouteID, const char* currentOperationNumber, const ::objectIdentifier& subRouteID, const char* returnOperationNumber, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSubRouteBranchReq()";
        retVal =        PPTManager_i::txSubRouteBranchReq ( strSubRouteBranchReqResult, strObjCommonIn, lotID, currentRouteID, currentOperationNumber, subRouteID, returnOperationNumber, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSubRouteBranchCancelReq */
virtual ::CORBA::Long  txSubRouteBranchCancelReq (::pptSubRouteBranchCancelReqResult& strSubRouteBranchCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& currentRouteID, const char* currentOperationNumber, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSubRouteBranchCancelReq()";
        retVal =        PPTManager_i::txSubRouteBranchCancelReq ( strSubRouteBranchCancelReqResult, strObjCommonIn, lotID, currentRouteID, currentOperationNumber, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReworkPartialWaferLotCancelReq */
virtual ::CORBA::Long  txReworkPartialWaferLotCancelReq (::pptReworkPartialWaferLotCancelReqResult& strReworkPartialWaferLotCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& parentLotID, const ::objectIdentifier& childLotID, const ::objectIdentifier& reasonCodeID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReworkPartialWaferLotCancelReq()";
        retVal =        PPTManager_i::txReworkPartialWaferLotCancelReq ( strReworkPartialWaferLotCancelReqResult, strObjCommonIn, parentLotID, childLotID, reasonCodeID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReworkWholeLotCancelReq */
virtual ::CORBA::Long  txReworkWholeLotCancelReq (::pptReworkWholeLotCancelReqResult& strReworkWholeLotCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& currentRouteID, const char* currentOperationNumber, const ::objectIdentifier& reasonCodeID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReworkWholeLotCancelReq()";
        retVal =        PPTManager_i::txReworkWholeLotCancelReq ( strReworkWholeLotCancelReqResult, strObjCommonIn, lotID, currentRouteID, currentOperationNumber, reasonCodeID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txGatePassReq */
virtual ::CORBA::Long  txGatePassReq (::pptGatePassReqResult& strGatePassReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::pptGatePassLotInfoSequence& strGatePassLotInfo, const char* claimMemo, ::objectIdentifierSequence& holdReleasedLotIDs, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txGatePassReq()";
        retVal =        PPTManager_i::txGatePassReq ( strGatePassReqResult, strObjCommonIn, seqIndex, strGatePassLotInfo, claimMemo, holdReleasedLotIDs, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txHoldLotReq */
virtual ::CORBA::Long  txHoldLotReq (::pptHoldLotReqResult& strHoldLotReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::pptHoldListSequence& strLotHoldReqList, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txHoldLotReq()";
        retVal =        PPTManager_i::txHoldLotReq ( strHoldLotReqResult, strObjCommonIn, lotID, strLotHoldReqList, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txHoldLotReleaseReq */
virtual ::CORBA::Long  txHoldLotReleaseReq (::pptHoldLotReleaseReqResult& strHoldLotReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& releaseReasonCodeID, const ::pptHoldListSequence& strLotHoldReqList, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txHoldLotReleaseReq()";
        retVal =        PPTManager_i::txHoldLotReleaseReq ( strHoldLotReleaseReqResult, strObjCommonIn, lotID, releaseReasonCodeID, strLotHoldReqList, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMergeWaferLotReq */
virtual ::CORBA::Long  txMergeWaferLotReq (::pptMergeWaferLotReqResult& strMergeWaferLotReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& parentLotID, const ::objectIdentifier& childLotID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMergeWaferLotReq()";
        retVal =        PPTManager_i::txMergeWaferLotReq ( strMergeWaferLotReqResult, strObjCommonIn, parentLotID, childLotID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSplitWaferLotReq */
virtual ::CORBA::Long  txSplitWaferLotReq (::pptSplitWaferLotReqResult& strSplitWaferLotReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& parentLotID, const ::objectIdentifierSequence& childWaferID, ::CORBA::Boolean futureMergeFlag, const ::objectIdentifier& mergedRouteID, const char* mergedOperationNumber, ::CORBA::Boolean branchingRouteSpecifyFlag, const ::objectIdentifier& subRouteID, const char* returnOperationNumber, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSplitWaferLotReq()";
        retVal =        PPTManager_i::txSplitWaferLotReq ( strSplitWaferLotReqResult, strObjCommonIn, parentLotID, childWaferID, futureMergeFlag, mergedRouteID, mergedOperationNumber, branchingRouteSpecifyFlag, subRouteID, returnOperationNumber, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeCompWithDataReq */
virtual ::CORBA::Long  txOpeCompWithDataReq (::pptOpeCompWithDataReqResult& strOpeCompWithDataReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::objectIdentifierSequence& holdReleasedLotIDs, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeCompWithDataReq()";
        retVal =        PPTManager_i::txOpeCompWithDataReq ( strOpeCompWithDataReqResult, strObjCommonIn, equipmentID, controlJobID, spcResultRequiredFlag, claimMemo, holdReleasedLotIDs, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeCompWithDataReq__120 */
virtual ::CORBA::Long  txOpeCompWithDataReq__120 (::pptOpeCompWithDataReqResult& strOpeCompWithDataReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::objectIdentifierSequence& holdReleasedLotIDs, ::pptAPCBaseCassetteSequence& strAPCBaseCassetteListForOpeComp, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeCompWithDataReq__120()";
        retVal =        PPTManager_i::txOpeCompWithDataReq__120 ( strOpeCompWithDataReqResult, strObjCommonIn, equipmentID, controlJobID, spcResultRequiredFlag, claimMemo, holdReleasedLotIDs, strAPCBaseCassetteListForOpeComp, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeLocateReq */
virtual ::CORBA::Long  txOpeLocateReq (::pptOpeLocateReqResult& strOpeLocateReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean locateDirection, const ::objectIdentifier& lotID, const ::objectIdentifier& currentRouteID, const char* currentOperationNumber, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const ::pptProcessRef& processRef, ::CORBA::Long seqNo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeLocateReq()";
        retVal =        PPTManager_i::txOpeLocateReq ( strOpeLocateReqResult, strObjCommonIn, locateDirection, lotID, currentRouteID, currentOperationNumber, routeID, operationID, operationNumber, processRef, seqNo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeStartCancelReq */
virtual ::CORBA::Long  txOpeStartCancelReq (::pptOpeStartCancelReqResult& strOpeStartCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const char* claimMemo, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeStartCancelReq()";
        retVal =        PPTManager_i::txOpeStartCancelReq ( strOpeStartCancelReqResult, strObjCommonIn, equipmentID, controlJobID, claimMemo, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeStartCancelReq__120 */
virtual ::CORBA::Long  txOpeStartCancelReq__120 (::pptOpeStartCancelReqResult& strOpeStartCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const char* claimMemo, ::pptAPCBaseCassetteSequence& strAPCBaseCassetteListForOpeStartCancel, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeStartCancelReq__120()";
        retVal =        PPTManager_i::txOpeStartCancelReq__120 ( strOpeStartCancelReqResult, strObjCommonIn, equipmentID, controlJobID, claimMemo, strAPCBaseCassetteListForOpeStartCancel, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeStartReq */
virtual ::CORBA::Long  txOpeStartReq (::pptOpeStartReqResult& strOpeStartReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGropuID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean processJobPauseFlag, const char* claimMemo, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeStartReq()";
        retVal =        PPTManager_i::txOpeStartReq ( strOpeStartReqResult, strObjCommonIn, equipmentID, portGropuID, controlJobID, strStartCassette, processJobPauseFlag, claimMemo, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSTBReleasedLotReq */
virtual ::CORBA::Long  txSTBReleasedLotReq (::pptSTBReleasedLotReqResult& strSTBReleasedLotReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& productRequestID, const ::pptNewLotAttributes& strNewLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSTBReleasedLotReq()";
        retVal =        PPTManager_i::txSTBReleasedLotReq ( strSTBReleasedLotReqResult, strObjCommonIn, productRequestID, strNewLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReworkWholeLotReq */
virtual ::CORBA::Long  txReworkWholeLotReq (::pptReworkWholeLotReqResult& strReworkWholeLotReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& currentRouteID, const char* currentOperationNumber, const ::objectIdentifier& subRouteID, const char* returnOperationNumber, const ::objectIdentifier& reasonCodeID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReworkWholeLotReq()";
        retVal =        PPTManager_i::txReworkWholeLotReq ( strReworkWholeLotReqResult, strObjCommonIn, lotID, currentRouteID, currentOperationNumber, subRouteID, returnOperationNumber, reasonCodeID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotFamilyInq */
virtual ::CORBA::Long  txLotFamilyInq (::pptLotFamilyInqResult& strLotFamilyInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotFamilyInq()";
        retVal =        PPTManager_i::txLotFamilyInq ( strLotFamilyInqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotHoldListInq */
virtual ::CORBA::Long  txLotHoldListInq (::pptLotHoldListInqResult& strLotHoldListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotHoldListInq()";
        retVal =        PPTManager_i::txLotHoldListInq ( strLotHoldListInqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoInq */
virtual ::CORBA::Long  txLotInfoInq (::pptLotInfoInqResult& strLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& lotID, ::CORBA::Boolean lotBasicInfoFlag, ::CORBA::Boolean lotControlUseInfoFlag, ::CORBA::Boolean lotFlowBatchInfoFlag, ::CORBA::Boolean lotNoteFlagInfoFlag, ::CORBA::Boolean lotOperationInfoFlag, ::CORBA::Boolean lotOrderInfoFlag, ::CORBA::Boolean lotControlJobInfoFlag, ::CORBA::Boolean lotProductInfoFlag, ::CORBA::Boolean lotRecipeInfoFlag, ::CORBA::Boolean lotLocationInfoFlag, ::CORBA::Boolean lotWipOperationInfoFlag, ::CORBA::Boolean lotWaferAttributesFlag, ::CORBA::Boolean lotListInCassetteInfoFlag, ::CORBA::Boolean waferMapInCassetteInfoFlag, ::CORBA::Boolean lotBackupInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoInq()";
        retVal =        PPTManager_i::txLotInfoInq ( strLotInfoInqResult, strObjCommonIn, lotID, lotBasicInfoFlag, lotControlUseInfoFlag, lotFlowBatchInfoFlag, lotNoteFlagInfoFlag, lotOperationInfoFlag, lotOrderInfoFlag, lotControlJobInfoFlag, lotProductInfoFlag, lotRecipeInfoFlag, lotLocationInfoFlag, lotWipOperationInfoFlag, lotWaferAttributesFlag, lotListInCassetteInfoFlag, waferMapInCassetteInfoFlag, lotBackupInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInq */
virtual ::CORBA::Long  txLotListInq (::pptLotListInqResult& strLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotStatus, const char* lotType, const ::objectIdentifier& productID, const char* orderNumber, const char* customerCode, const ::objectIdentifier& manufacturingLayerID, const ::objectIdentifier& routeID, const char* operationNumber, ::CORBA::Boolean bankInRequiredFlag, const ::objectIdentifier& lotID, const char* requiredCassetteCategory, ::CORBA::Boolean backupProcessingFlag, const char* subLotType, ::CORBA::Boolean deleteLotFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInq()";
        retVal =        PPTManager_i::txLotListInq ( strLotListInqResult, strObjCommonIn, bankID, lotStatus, lotType, productID, orderNumber, customerCode, manufacturingLayerID, routeID, operationNumber, bankInRequiredFlag, lotID, requiredCassetteCategory, backupProcessingFlag, subLotType, deleteLotFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMfgLayerListInq */
virtual ::CORBA::Long  txMfgLayerListInq (::pptMfgLayerInqResult& strMfgLayerInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMfgLayerListInq()";
        retVal =        PPTManager_i::txMfgLayerListInq ( strMfgLayerInqResult, strObjCommonIn, requestUserID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotOperationListInq */
virtual ::CORBA::Long  txLotOperationListInq (::pptLotOperationListInqResult& strLotOperationListInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean searchDirection, ::CORBA::Boolean posSearchFlag, ::CORBA::Long searchCount, ::CORBA::Boolean currentFlag, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotOperationListInq()";
        retVal =        PPTManager_i::txLotOperationListInq ( strLotOperationListInqResult, strObjCommonIn, searchDirection, posSearchFlag, searchCount, currentFlag, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReleasedLotListInq */
virtual ::CORBA::Long  txReleasedLotListInq (::pptReleasedLotListInqResult& strReleasedLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& manufacturingLayerID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReleasedLotListInq()";
        retVal =        PPTManager_i::txReleasedLotListInq ( strReleasedLotListInqResult, strObjCommonIn, manufacturingLayerID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRouteIndexListInq */
virtual ::CORBA::Long  txRouteIndexListInq (::pptRouteIndexListInqResult& strRouteIndexListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* routeType, const ::objectIdentifier& lotID, const char* procDefType, ::CORBA::Boolean activeShowFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRouteIndexListInq()";
        retVal =        PPTManager_i::txRouteIndexListInq ( strRouteIndexListInqResult, strObjCommonIn, routeType, lotID, procDefType, activeShowFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWorkAreaListInq */
virtual ::CORBA::Long  txWorkAreaListInq (::pptWorkAreaListInqResult& strWorkAreaListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWorkAreaListInq()";
        retVal =        PPTManager_i::txWorkAreaListInq ( strWorkAreaListInqResult, strObjCommonIn, requestUserID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProductRequestInq */
virtual ::CORBA::Long  txProductRequestInq (::pptProductRequestInqResult& strProductRequestInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& productRequestID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProductRequestInq()";
        retVal =        PPTManager_i::txProductRequestInq ( strProductRequestInqResult, strObjCommonIn, productRequestID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDataItemWithTempDataInq */
virtual ::CORBA::Long  txDataItemWithTempDataInq (::pptDataItemWithTempDataInqResult& strDataItemWithTempDataInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDataItemWithTempDataInq()";
        retVal =        PPTManager_i::txDataItemWithTempDataInq ( strDataItemWithTempDataInqResult, strObjCommonIn, equipmentID, controlJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txTempDataRpt */
virtual ::CORBA::Long  txTempDataRpt (::pptTempDataRptResult& strTempDataRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGropuID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txTempDataRpt()";
        retVal =        PPTManager_i::txTempDataRpt ( strTempDataRptResult, strObjCommonIn, equipmentID, portGropuID, controlJobID, strStartCassette, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpPortStatusChangeRpt */
virtual ::CORBA::Long  txEqpPortStatusChangeRpt (::pptEqpPortStatusChangeRptResult& strEqpPortStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptEqpPortEventOnTCSSequence& strEqpPortEventOnTCS, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpPortStatusChangeRpt()";
        retVal =        PPTManager_i::txEqpPortStatusChangeRpt ( strEqpPortStatusChangeRptResult, strObjCommonIn, equipmentID, strEqpPortEventOnTCS, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txTCSRecoveryReq */
virtual ::CORBA::Long  txTCSRecoveryReq (::pptTCSRecoveryReqResult& strTCSRecoveryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* actionCode, const ::pptRecoverWaferSequence& strRecoverWafer, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txTCSRecoveryReq()";
        retVal =        PPTManager_i::txTCSRecoveryReq ( strTCSRecoveryReqResult, strObjCommonIn, equipmentID, actionCode, strRecoverWafer, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCandidateEqpModeInq */
virtual ::CORBA::Long  txCandidateEqpModeInq (::pptCandidateEqpModeInqResult& strCandidateEqpModeInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* modeChangeType, const ::objectIdentifierSequence& portID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCandidateEqpModeInq()";
        retVal =        PPTManager_i::txCandidateEqpModeInq ( strCandidateEqpModeInqResult, strObjCommonIn, equipmentID, modeChangeType, portID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpAlarmHistoryInq */
virtual ::CORBA::Long  txEqpAlarmHistoryInq (::pptEqpAlarmHistoryInqResult& strEqpAlarmHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& objectID, const char* inquireType, const char* fromTimeStamp, const char* toTimeStamp, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpAlarmHistoryInq()";
        retVal =        PPTManager_i::txEqpAlarmHistoryInq ( strEqpAlarmHistoryInqResult, strObjCommonIn, objectID, inquireType, fromTimeStamp, toTimeStamp, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpDetailInfoInq */
virtual ::CORBA::Long  txEqpDetailInfoInq (::pptEqpDetailInfoInqResult& strEqpDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpDetailInfoInq()";
        retVal =        PPTManager_i::txEqpDetailInfoInq ( strEqpDetailInfoInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpAlarmRpt */
virtual ::CORBA::Long  txEqpAlarmRpt (::pptEqpAlarmRptResult& strEqpAlarmRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, const ::objectIdentifier& AGVID, const ::pptEquipmentAlarm& strEquipmentAlarm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpAlarmRpt()";
        retVal =        PPTManager_i::txEqpAlarmRpt ( strEqpAlarmRptResult, strObjCommonIn, equipmentID, stockerID, AGVID, strEquipmentAlarm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSignalTowerOffReq */
virtual ::CORBA::Long  txSignalTowerOffReq (::pptSignalTowerOffReqResult& strSignalTowerOffReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSignalTowerOffReq()";
        retVal =        PPTManager_i::txSignalTowerOffReq ( strSignalTowerOffReqResult, strObjCommonIn, equipmentID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLoadingLotRpt */
virtual ::CORBA::Long  txLoadingLotRpt (::pptLoadingLotRptResult& strLoadingLotRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& cassetteID, const ::objectIdentifier& portID, const char* loadPurposeType, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLoadingLotRpt()";
        retVal =        PPTManager_i::txLoadingLotRpt ( strLoadingLotRptResult, strObjCommonIn, equipmentID, cassetteID, portID, loadPurposeType, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotVerifyForLoadingReq */
virtual ::CORBA::Long  txLotVerifyForLoadingReq (::pptLotVerifyForLoadingReqResult& strLotVerifyForLoadingReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& portID, const ::objectIdentifier& cassetteID, const char* lotPurposeType, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotVerifyForLoadingReq()";
        retVal =        PPTManager_i::txLotVerifyForLoadingReq ( strLotVerifyForLoadingReqResult, strObjCommonIn, equipmentID, portID, cassetteID, lotPurposeType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPrivilegeCheckReq */
virtual ::CORBA::Long  txPrivilegeCheckReq (::pptPrivilegeCheckReqResult& strPrivilegeCheckReqResult, ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, const ::objectIdentifierSequence& productIDs, const ::objectIdentifierSequence& routeIDs, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifierSequence& machineRecipeIDs, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPrivilegeCheckReq()";
        retVal =        PPTManager_i::txPrivilegeCheckReq ( strPrivilegeCheckReqResult, strObjCommonIn, equipmentID, stockerID, productIDs, routeIDs, lotIDs, machineRecipeIDs, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCandidateDurableStatusInq */
virtual ::CORBA::Long  txCandidateDurableStatusInq (::pptCandidateDurableStatusInqResult& strCandidateDurableStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& durableID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCandidateDurableStatusInq()";
        retVal =        PPTManager_i::txCandidateDurableStatusInq ( strCandidateDurableStatusInqResult, strObjCommonIn, durableID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteStatusInq */
virtual ::CORBA::Long  txCassetteStatusInq (::pptCassetteStatusInqResult& strCassetteStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteStatusInq()";
        retVal =        PPTManager_i::txCassetteStatusInq ( strCassetteStatusInqResult, strObjCommonIn, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteListInq */
virtual ::CORBA::Long  txCassetteListInq (::pptCassetteListInqResult& strCassetteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* cassetteCategory, ::CORBA::Boolean emptyFlag, const ::objectIdentifier& stockerID, const ::objectIdentifier& cassetteID, const char* cassetteStatus, ::CORBA::Long maxRetrieveCount, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteListInq()";
        retVal =        PPTManager_i::txCassetteListInq ( strCassetteListInqResult, strObjCommonIn, cassetteCategory, emptyFlag, stockerID, cassetteID, cassetteStatus, maxRetrieveCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteUsageCountResetReq */
virtual ::CORBA::Long  txCassetteUsageCountResetReq (::pptCassetteUsageCountResetReqResult& strCassetteUsageCountResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteUsageCountResetReq()";
        retVal =        PPTManager_i::txCassetteUsageCountResetReq ( strCassetteUsageCountResetReqResult, strObjCommonIn, cassetteID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteStatusChangeRpt */
virtual ::CORBA::Long  txCassetteStatusChangeRpt (::pptCassetteStatusChangeRptResult& strCassetteStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, const char* cassetteStatus, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteStatusChangeRpt()";
        retVal =        PPTManager_i::txCassetteStatusChangeRpt ( strCassetteStatusChangeRptResult, strObjCommonIn, cassetteID, cassetteStatus, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFutureHoldCancelReq */
virtual ::CORBA::Long  txFutureHoldCancelReq (::pptFutureHoldCancelReqResult& strFutureHoldCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& releaseReasonCodeID, const char* entryType, const ::pptHoldListSequence& strFutureHoldCancelReqList, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFutureHoldCancelReq()";
        retVal =        PPTManager_i::txFutureHoldCancelReq ( strFutureHoldCancelReqResult, strObjCommonIn, lotID, releaseReasonCodeID, entryType, strFutureHoldCancelReqList, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProductIDListInq */
virtual ::CORBA::Long  txProductIDListInq (::pptProductIDListInqResult& strProductIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* productCategory, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProductIDListInq()";
        retVal =        PPTManager_i::txProductIDListInq ( strProductIDListInqResult, strObjCommonIn, productCategory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCancelRelationMonitorProdLotsReq */
virtual ::CORBA::Long  txCancelRelationMonitorProdLotsReq (::pptCancelRelationMonitorProdLotsReqResult& strCancelRelationMonitorProdLotsReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& monitorLotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCancelRelationMonitorProdLotsReq()";
        retVal =        PPTManager_i::txCancelRelationMonitorProdLotsReq ( strCancelRelationMonitorProdLotsReqResult, strObjCommonIn, monitorLotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMonitorProdLotsRelationInq */
virtual ::CORBA::Long  txMonitorProdLotsRelationInq (::pptMonitorProdLotsRelationInqResult& strMonitorProdLotsRelationInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMonitorProdLotsRelationInq()";
        retVal =        PPTManager_i::txMonitorProdLotsRelationInq ( strMonitorProdLotsRelationInqResult, strObjCommonIn, lotID, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotsInfoForOpeStartInq */
virtual ::CORBA::Long  txLotsInfoForOpeStartInq (::pptLotsInfoForOpeStartInqResult& strLotsInfoForOpeStartInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifierSequence& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotsInfoForOpeStartInq()";
        retVal =        PPTManager_i::txLotsInfoForOpeStartInq ( strLotsInfoForOpeStartInqResult, strObjCommonIn, equipmentID, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotsInfoForStartReservationInq */
virtual ::CORBA::Long  txLotsInfoForStartReservationInq (::pptLotsInfoForStartReservationInqResult& strLotsInfoForStartReservationInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptStartCassetteSequence& strStartCassette, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotsInfoForStartReservationInq()";
        retVal =        PPTManager_i::txLotsInfoForStartReservationInq ( strLotsInfoForStartReservationInqResult, strObjCommonIn, equipmentID, strStartCassette, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpStatusChangeReq */
virtual ::CORBA::Long  txEqpStatusChangeReq (::pptEqpStatusChangeReqResult& strEqpStatusChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& equipmentStatusCode, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpStatusChangeReq()";
        retVal =        PPTManager_i::txEqpStatusChangeReq ( strEqpStatusChangeReqResult, strObjCommonIn, equipmentID, equipmentStatusCode, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpModeChangeReq */
virtual ::CORBA::Long  txEqpModeChangeReq (::pptEqpModeChangeReqResult& strEqpModeChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptPortOperationModeSequence& strPortOperationMode, ::CORBA::Boolean notifyToEqpFlag, ::CORBA::Boolean notifyToTCSFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpModeChangeReq()";
        retVal =        PPTManager_i::txEqpModeChangeReq ( strEqpModeChangeReqResult, strObjCommonIn, equipmentID, strPortOperationMode, notifyToEqpFlag, notifyToTCSFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txChamberStatusChangeReq */
virtual ::CORBA::Long  txChamberStatusChangeReq (::pptChamberStatusChangeReqResult& strChamberStatusChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptEqpChamberStatusSequence& strEqpChamberStatus, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txChamberStatusChangeReq()";
        retVal =        PPTManager_i::txChamberStatusChangeReq ( strChamberStatusChangeReqResult, strObjCommonIn, equipmentID, strEqpChamberStatus, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::calendar_GetCurrentTimeDR */
virtual ::CORBA::Long  calendar_GetCurrentTimeDR (::objCalendar_GetCurrentTimeDR_out& strCalendar_GetCurrentTimeDR_out, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::calendar_GetCurrentTimeDR()";
        retVal =        PPTManager_i::calendar_GetCurrentTimeDR ( strCalendar_GetCurrentTimeDR_out, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLogOnCheckReq */
virtual ::CORBA::Long  txLogOnCheckReq (::pptLogOnCheckReqResult& strPerson_LogOnCheck_out, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const char* subSystemID, const char* categoryID, ::CORBA::Boolean bProductRequestFlag, ::CORBA::Boolean bRecipeRequestFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLogOnCheckReq()";
        retVal =        PPTManager_i::txLogOnCheckReq ( strPerson_LogOnCheck_out, strObjCommonIn, requestUserID, subSystemID, categoryID, bProductRequestFlag, bRecipeRequestFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txNonProBankInReq */
virtual ::CORBA::Long  txNonProBankInReq (::pptNonProBankInReqResult& strNonProBankInReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& bankID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txNonProBankInReq()";
        retVal =        PPTManager_i::txNonProBankInReq ( strNonProBankInReqResult, strObjCommonIn, lotID, bankID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txNonProBankOutReq */
virtual ::CORBA::Long  txNonProBankOutReq (::pptNonProBankOutReqResult& strNonProBankOutReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, ::CORBA::Boolean holdCheckFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txNonProBankOutReq()";
        retVal =        PPTManager_i::txNonProBankOutReq ( strNonProBankOutReqResult, strObjCommonIn, lotID, holdCheckFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRunBRScriptReq */
virtual ::CORBA::Long  txRunBRScriptReq (::pptRunBRScriptReqResult& strRunBRScriptReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* phase, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRunBRScriptReq()";
        retVal =        PPTManager_i::txRunBRScriptReq ( strRunBRScriptReqResult, strObjCommonIn, phase, lotID, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUserParameterValueChangeReq */
virtual ::CORBA::Long  txUserParameterValueChangeReq (::pptUserParameterValueChangeReqResult& strUserParameterValueChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* parameterClass, const char* identifier, const ::pptUserParameterValueSequence& parameters, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUserParameterValueChangeReq()";
        retVal =        PPTManager_i::txUserParameterValueChangeReq ( strUserParameterValueChangeReqResult, strObjCommonIn, parameterClass, identifier, parameters, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDispatchEquipmentChangeReq */
virtual ::CORBA::Long  txDispatchEquipmentChangeReq (::pptDispatchEquipmentChangeReqResult& strDispatchEquipmentChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifierSequence& equipmentIDs, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDispatchEquipmentChangeReq()";
        retVal =        PPTManager_i::txDispatchEquipmentChangeReq ( strDispatchEquipmentChangeReqResult, strObjCommonIn, lotID, equipmentIDs, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUserParameterValueInq */
virtual ::CORBA::Long  txUserParameterValueInq (::pptUserParameterValueInqResult& strUserParameterValueInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* parameterClass, const char* identifier, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUserParameterValueInq()";
        retVal =        PPTManager_i::txUserParameterValueInq ( strUserParameterValueInqResult, strObjCommonIn, parameterClass, identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStartLotsReservationReq */
virtual ::CORBA::Long  txStartLotsReservationReq (::pptStartLotsReservationReqResult& strStartLotsReservationReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGropuID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, const char* claimMemo, char*& APCIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStartLotsReservationReq()";
        retVal =        PPTManager_i::txStartLotsReservationReq ( strStartLotsReservationReqResult, strObjCommonIn, equipmentID, portGropuID, controlJobID, strStartCassette, claimMemo, APCIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStartLotsReservationCancelReq */
virtual ::CORBA::Long  txStartLotsReservationCancelReq (::pptStartLotsReservationCancelReqResult& strStartLotsReservationCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const char* claimMemo, char*& APCIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStartLotsReservationCancelReq()";
        retVal =        PPTManager_i::txStartLotsReservationCancelReq ( strStartLotsReservationCancelReqResult, strObjCommonIn, equipmentID, controlJobID, claimMemo, APCIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txChamberStatusChangeRpt */
virtual ::CORBA::Long  txChamberStatusChangeRpt (::pptChamberStatusChangeRptResult& strChamberStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptEqpChamberStatusSequence& strEqpChamberStatus, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txChamberStatusChangeRpt()";
        retVal =        PPTManager_i::txChamberStatusChangeRpt ( strChamberStatusChangeRptResult, strObjCommonIn, equipmentID, strEqpChamberStatus, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCtrlStatusChangeReq */
virtual ::CORBA::Long  txLotCtrlStatusChangeReq (::pptLotCtrlStatusChangeReqResult& strLotCtrlStatusChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* controlUseState, ::CORBA::Long usageCount, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCtrlStatusChangeReq()";
        retVal =        PPTManager_i::txLotCtrlStatusChangeReq ( strLotCtrlStatusChangeReqResult, strObjCommonIn, lotID, controlUseState, usageCount, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCtrlStatusInq */
virtual ::CORBA::Long  txLotCtrlStatusInq (::pptLotCtrlStatusInqResult& strLotCtrlStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCtrlStatusInq()";
        retVal =        PPTManager_i::txLotCtrlStatusInq ( strLotCtrlStatusInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txVendorLotPreparationReq */
virtual ::CORBA::Long  txVendorLotPreparationReq (::pptVendorLotPreparationReqResult& strVendorLotPreparationReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotType, const char* subLotType, const ::pptNewLotAttributes& strNewLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txVendorLotPreparationReq()";
        retVal =        PPTManager_i::txVendorLotPreparationReq ( strVendorLotPreparationReqResult, strObjCommonIn, bankID, lotType, subLotType, strNewLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatNextStandbyLotInq */
virtual ::CORBA::Long  txWhatNextStandbyLotInq (::pptWhatNextStandbyLotInqResult& strWhatNextStandbyLotInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatNextStandbyLotInq()";
        retVal =        PPTManager_i::txWhatNextStandbyLotInq ( strWhatNextStandbyLotInqResult, strObjCommonIn, bankID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpStatusAdjustReq */
virtual ::CORBA::Long  txEqpStatusAdjustReq (::pptEqpStatusAdjustReqResult& strEqpStatusAdjustReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpStatusAdjustReq()";
        retVal =        PPTManager_i::txEqpStatusAdjustReq ( strEqpStatusAdjustReqResult, strObjCommonIn, equipmentID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpStatusRecoverReq */
virtual ::CORBA::Long  txEqpStatusRecoverReq (::pptEqpStatusRecoverReqResult& strEqpStatusRecoverReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* changeType, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpStatusRecoverReq()";
        retVal =        PPTManager_i::txEqpStatusRecoverReq ( strEqpStatusRecoverReqResult, strObjCommonIn, equipmentID, changeType, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpUsageCountResetReq */
virtual ::CORBA::Long  txEqpUsageCountResetReq (::pptEqpUsageCountResetReqResult& strEqpUsageCountResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpUsageCountResetReq()";
        retVal =        PPTManager_i::txEqpUsageCountResetReq ( strEqpUsageCountResetReqResult, strObjCommonIn, equipmentID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteXferJobDeleteReq */
virtual ::CORBA::Long  txLotCassetteXferJobDeleteReq (::pptLotCassetteXferJobDeleteReqResult& strLotCassetteXferJobDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* jobID, const ::pptDelCarrierJobSequence& strDelCarrierJob, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteXferJobDeleteReq()";
        retVal =        PPTManager_i::txLotCassetteXferJobDeleteReq ( strLotCassetteXferJobDeleteReqResult, strObjCommonIn, jobID, strDelCarrierJob, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteDeliveryReq */
virtual ::CORBA::Long  txCassetteDeliveryReq (::pptCassetteDeliveryReqResult& strCassetteDeliveryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteDeliveryReq()";
        retVal =        PPTManager_i::txCassetteDeliveryReq ( strCassetteDeliveryReqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAllAvailableEqpInq */
virtual ::CORBA::Long  txAllAvailableEqpInq (::pptAllAvailableEqpInqResult& strAllAvailableEqpInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAllAvailableEqpInq()";
        retVal =        PPTManager_i::txAllAvailableEqpInq ( strAllAvailableEqpInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAvailableEqpInq */
virtual ::CORBA::Long  txAvailableEqpInq (::pptAvailableEqpInqResult& strAvailableEqpInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& lotID, const ::objectIdentifier& cassetteID, const ::objectIdentifier& durableID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAvailableEqpInq()";
        retVal =        PPTManager_i::txAvailableEqpInq ( strAvailableEqpInqResult, strObjCommonIn, equipmentID, lotID, cassetteID, durableID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::messageQueue_Put */
virtual ::CORBA::Long  messageQueue_Put (::objMessageQueue_Put_out& strMessageQueue_Put_out, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptPortOperationModeSequence& strPortOperationMode, const ::objectIdentifier& equipmentStatusCode, const ::objectIdentifier& lotID, const char* lotProcessState, const char* lotHoldState, const ::objectIdentifier& cassetteID, const char* cassetteTransferState, ::CORBA::Boolean cassetteTransferReserveFlag, ::CORBA::Boolean cassetteDispatchReserveFlag, const ::objectIdentifier& durableID, const char* durableTransferState, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::messageQueue_Put()";
        retVal =        PPTManager_i::messageQueue_Put ( strMessageQueue_Put_out, strObjCommonIn, equipmentID, strPortOperationMode, equipmentStatusCode, lotID, lotProcessState, lotHoldState, cassetteID, cassetteTransferState, cassetteTransferReserveFlag, cassetteDispatchReserveFlag, durableID, durableTransferState, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMultiCarrierXferReq */
virtual ::CORBA::Long  txMultiCarrierXferReq (::pptMultiCarrierXferReqResult& strMultiCarrierXferReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean rerouteFlag, const char* transportType, const ::pptCarrierXferReqSequence& strCarrierXferReq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMultiCarrierXferReq()";
        retVal =        PPTManager_i::txMultiCarrierXferReq ( strMultiCarrierXferReqResult, strObjCommonIn, rerouteFlag, transportType, strCarrierXferReq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSingleCarrierXferReq */
virtual ::CORBA::Long  txSingleCarrierXferReq (::pptSingleCarrierXferReqResult& strSingleCarrierXferReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean rerouteFlag, const ::objectIdentifier& carrierID, const ::objectIdentifier& lotID, const char* zoneType, ::CORBA::Boolean n2PurgeFlag, const ::objectIdentifier& fromMachineID, const ::objectIdentifier& fromPortID, const char* toStockerGroup, const ::pptToMachineSequence& strToMachine, const char* expectedStartTime, const char* expectedEndTime, ::CORBA::Boolean mandatoryFlag, const char* priority, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSingleCarrierXferReq()";
        retVal =        PPTManager_i::txSingleCarrierXferReq ( strSingleCarrierXferReqResult, strObjCommonIn, rerouteFlag, carrierID, lotID, zoneType, n2PurgeFlag, fromMachineID, fromPortID, toStockerGroup, strToMachine, expectedStartTime, expectedEndTime, mandatoryFlag, priority, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txArrivalCarrierNotificationReq */
virtual ::CORBA::Long  txArrivalCarrierNotificationReq (::pptArrivalCarrierNotificationReqResult& strArrivalCarrierNotificationReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGroupID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txArrivalCarrierNotificationReq()";
        retVal =        PPTManager_i::txArrivalCarrierNotificationReq ( strArrivalCarrierNotificationReqResult, strObjCommonIn, equipmentID, portGroupID, controlJobID, strStartCassette, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txArrivalCarrierCancelReq */
virtual ::CORBA::Long  txArrivalCarrierCancelReq (::pptArrivalCarrierCancelReqResult& strArrivalCarrierCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGroupID, const ::pptNPWXferCassetteSequence& strNPWXferCassette, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txArrivalCarrierCancelReq()";
        retVal =        PPTManager_i::txArrivalCarrierCancelReq ( strArrivalCarrierCancelReqResult, strObjCommonIn, equipmentID, portGroupID, strNPWXferCassette, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txArrivalCarrierNotificationForInternalBufferReq */
virtual ::CORBA::Long  txArrivalCarrierNotificationForInternalBufferReq (::pptArrivalCarrierNotificationForInternalBufferReqResult& strArrivalCarrierNotificationForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGroupID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txArrivalCarrierNotificationForInternalBufferReq()";
        retVal =        PPTManager_i::txArrivalCarrierNotificationForInternalBufferReq ( strArrivalCarrierNotificationForInternalBufferReqResult, strObjCommonIn, equipmentID, portGroupID, controlJobID, strStartCassette, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txArrivalCarrierCancelForInternalBufferReq */
virtual ::CORBA::Long  txArrivalCarrierCancelForInternalBufferReq (::pptArrivalCarrierCancelForInternalBufferReqResult& strArrivalCarrierCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGroupID, const ::pptNPWXferCassetteSequence& strNPWXferCassette, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txArrivalCarrierCancelForInternalBufferReq()";
        retVal =        PPTManager_i::txArrivalCarrierCancelForInternalBufferReq ( strArrivalCarrierCancelForInternalBufferReqResult, strObjCommonIn, equipmentID, portGroupID, strNPWXferCassette, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureUsageCountResetReq */
virtual ::CORBA::Long  txFixtureUsageCountResetReq (::pptFixtureUsageCountResetReqResult& strFixtureUsageCountResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& fixtureID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureUsageCountResetReq()";
        retVal =        PPTManager_i::txFixtureUsageCountResetReq ( strFixtureUsageCountResetReqResult, strObjCommonIn, fixtureID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureListInq */
virtual ::CORBA::Long  txFixtureListInq (::pptFixtureListInqResult& strFixtureListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& fixtureCategoryID, const ::objectIdentifier& fixtureGroupID, const char* fixturePartNumber, const ::objectIdentifier& fixtureID, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, const char* fixtureStatus, ::CORBA::Long maxRetrieveCount, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureListInq()";
        retVal =        PPTManager_i::txFixtureListInq ( strFixtureListInqResult, strObjCommonIn, fixtureCategoryID, fixtureGroupID, fixturePartNumber, fixtureID, lotID, equipmentID, fixtureStatus, maxRetrieveCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureStatusInq */
virtual ::CORBA::Long  txFixtureStatusInq (::pptFixtureStatusInqResult& strFixtureStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& fixtureID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureStatusInq()";
        retVal =        PPTManager_i::txFixtureStatusInq ( strFixtureStatusInqResult, strObjCommonIn, fixtureID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureStockerInfoInq */
virtual ::CORBA::Long  txFixtureStockerInfoInq (::pptFixtureStockerInfoInqResult& strFixtureStockerInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureStockerInfoInq()";
        retVal =        PPTManager_i::txFixtureStockerInfoInq ( strFixtureStockerInfoInqResult, strObjCommonIn, stockerID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureStatusChangeRpt */
virtual ::CORBA::Long  txFixtureStatusChangeRpt (::pptFixtureStatusChangeRptResult& strFixtureStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& fixtureID, const char* fixtureStatus, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureStatusChangeRpt()";
        retVal =        PPTManager_i::txFixtureStatusChangeRpt ( strFixtureStatusChangeRptResult, strObjCommonIn, fixtureID, fixtureStatus, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureXferStatusChangeRpt */
virtual ::CORBA::Long  txFixtureXferStatusChangeRpt (::pptFixtureXferStatusChangeRptResult& strFixtureXferStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptXferFixtureSequence& strXferFixture, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureXferStatusChangeRpt()";
        retVal =        PPTManager_i::txFixtureXferStatusChangeRpt ( strFixtureXferStatusChangeRptResult, strObjCommonIn, stockerID, equipmentID, strXferFixture, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotFamilyListForDeletionInq */
virtual ::CORBA::Long  txLotFamilyListForDeletionInq (::pptLotFamilyListForDeletionInqResult& strLotFamilyListForDeletionInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& subLotType, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotFamilyListForDeletionInq()";
        retVal =        PPTManager_i::txLotFamilyListForDeletionInq ( strLotFamilyListForDeletionInqResult, strObjCommonIn, subLotType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureStatusMultiChangeRpt */
virtual ::CORBA::Long  txFixtureStatusMultiChangeRpt (::pptFixtureStatusMultiChangeRptResult& strFixtureStatusMultiChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const char* fixtureStatus, const ::objectIdentifierSequence& fixtureID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureStatusMultiChangeRpt()";
        retVal =        PPTManager_i::txFixtureStatusMultiChangeRpt ( strFixtureStatusMultiChangeRptResult, strObjCommonIn, fixtureStatus, fixtureID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStatusMultiChangeRpt */
virtual ::CORBA::Long  txReticleStatusMultiChangeRpt (::pptReticleStatusMultiChangeRptResult& strReticleStatusMultiChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleStatus, const ::objectIdentifierSequence& reticleID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStatusMultiChangeRpt()";
        retVal =        PPTManager_i::txReticleStatusMultiChangeRpt ( strReticleStatusMultiChangeRptResult, strObjCommonIn, reticleStatus, reticleID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteStatusMultiChangeRpt */
virtual ::CORBA::Long  txCassetteStatusMultiChangeRpt (::pptCassetteStatusMultiChangeRptResult& strCassetteStatusMultiChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const char* cassetteStatus, const ::objectIdentifierSequence& cassetteID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteStatusMultiChangeRpt()";
        retVal =        PPTManager_i::txCassetteStatusMultiChangeRpt ( strCassetteStatusMultiChangeRptResult, strObjCommonIn, cassetteStatus, cassetteID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoByWaferInq */
virtual ::CORBA::Long  txLotInfoByWaferInq (::pptLotInfoByWaferInqResult& strLotInfoByWaferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& waferID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoByWaferInq()";
        retVal =        PPTManager_i::txLotInfoByWaferInq ( strLotInfoByWaferInqResult, strObjCommonIn, waferID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeUploadReq */
virtual ::CORBA::Long  txRecipeUploadReq (::pptRecipeUploadReqResult& strRecipeUploadReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* fileLocation, const char* fileName, ::CORBA::Boolean formatFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeUploadReq()";
        retVal =        PPTManager_i::txRecipeUploadReq ( strRecipeUploadReqResult, strObjCommonIn, equipmentID, machineRecipeID, physicalRecipeID, fileLocation, fileName, formatFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeDownloadReq */
virtual ::CORBA::Long  txRecipeDownloadReq (::pptRecipeDownloadReqResult& strRecipeDownloadReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* fileLocation, const char* fileName, ::CORBA::Boolean formatFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeDownloadReq()";
        retVal =        PPTManager_i::txRecipeDownloadReq ( strRecipeDownloadReqResult, strObjCommonIn, equipmentID, machineRecipeID, physicalRecipeID, fileLocation, fileName, formatFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeDeletionReq */
virtual ::CORBA::Long  txRecipeDeletionReq (::pptRecipeDeletionReqResult& strRecipeDeletionReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, ::CORBA::Boolean recipeFileDeleteFlag, const ::objectIdentifier& machineRecipeID, const char* fileLocation, const char* fileName, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeDeletionReq()";
        retVal =        PPTManager_i::txRecipeDeletionReq ( strRecipeDeletionReqResult, strObjCommonIn, equipmentID, physicalRecipeID, recipeFileDeleteFlag, machineRecipeID, fileLocation, fileName, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeFileDeletionReq */
virtual ::CORBA::Long  txRecipeFileDeletionReq (::pptRecipeFileDeletionReqResult& strRecipeFileDeletionReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* fileLocation, const char* fileName, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeFileDeletionReq()";
        retVal =        PPTManager_i::txRecipeFileDeletionReq ( strRecipeFileDeletionReqResult, strObjCommonIn, equipmentID, machineRecipeID, physicalRecipeID, fileLocation, fileName, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeConfirmationReq */
virtual ::CORBA::Long  txRecipeConfirmationReq (::pptRecipeConfirmationReqResult& strRecipeConfirmationReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* fileLocation, const char* fileName, ::CORBA::Boolean formatFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeConfirmationReq()";
        retVal =        PPTManager_i::txRecipeConfirmationReq ( strRecipeConfirmationReqResult, strObjCommonIn, equipmentID, machineRecipeID, physicalRecipeID, fileLocation, fileName, formatFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeDirectoryInq */
virtual ::CORBA::Long  txRecipeDirectoryInq (::pptRecipeDirectoryInqResult& strRecipeDirectoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeDirectoryInq()";
        retVal =        PPTManager_i::txRecipeDirectoryInq ( strRecipeDirectoryInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMachineRecipeListInq */
virtual ::CORBA::Long  txMachineRecipeListInq (::pptMachineRecipeListInqResult& strMachineRecipeListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMachineRecipeListInq()";
        retVal =        PPTManager_i::txMachineRecipeListInq ( strMachineRecipeListInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessStatusRpt */
virtual ::CORBA::Long  txProcessStatusRpt (::pptProcessStatusRptResult& strProcessStatusRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::objectIdentifierSequence& lotID, const char* actionCode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessStatusRpt()";
        retVal =        PPTManager_i::txProcessStatusRpt ( strProcessStatusRptResult, strObjCommonIn, equipmentID, controlJobID, lotID, actionCode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitReq */
virtual ::CORBA::Long  txEntityInhibitReq (::pptEntityInhibitReqResult& strEntityInhibitReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitAttributes& strEntityInhibition, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitReq()";
        retVal =        PPTManager_i::txEntityInhibitReq ( strEntityInhibitReqResult, strObjCommonIn, strEntityInhibition, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitCancelReq */
virtual ::CORBA::Long  txEntityInhibitCancelReq (::pptEntityInhibitCancelReqResult& strEntityInhibitCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitInfoSequence& strEntityInhibitions, const ::objectIdentifier& reasonCode, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitCancelReq()";
        retVal =        PPTManager_i::txEntityInhibitCancelReq ( strEntityInhibitCancelReqResult, strObjCommonIn, strEntityInhibitions, reasonCode, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitListInq */
virtual ::CORBA::Long  txEntityInhibitListInq (::pptEntityInhibitListInqResult& strEntityInhibitListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitAttributes& strSearchCondition, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitListInq()";
        retVal =        PPTManager_i::txEntityInhibitListInq ( strEntityInhibitListInqResult, strObjCommonIn, strSearchCondition, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSubLotTypeIDListInq */
virtual ::CORBA::Long  txSubLotTypeIDListInq (::pptSubLotTypeIDListInqResult& strSubLotTypeIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* lotType, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSubLotTypeIDListInq()";
        retVal =        PPTManager_i::txSubLotTypeIDListInq ( strSubLotTypeIDListInqResult, strObjCommonIn, lotType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleIDListInq */
virtual ::CORBA::Long  txReticleIDListInq (::pptReticleIDListInqResult& strReticleIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleIDListInq()";
        retVal =        PPTManager_i::txReticleIDListInq ( strReticleIDListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleGroupIDListInq */
virtual ::CORBA::Long  txReticleGroupIDListInq (::pptReticleGroupIDListInqResult& strReticleGroupIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleGroupIDListInq()";
        retVal =        PPTManager_i::txReticleGroupIDListInq ( strReticleGroupIDListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureIDListInq */
virtual ::CORBA::Long  txFixtureIDListInq (::pptFixtureIDListInqResult& strFixtureIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureIDListInq()";
        retVal =        PPTManager_i::txFixtureIDListInq ( strFixtureIDListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFixtureGroupIDListInq */
virtual ::CORBA::Long  txFixtureGroupIDListInq (::pptFixtureGroupIDListInqResult& strFixtureGroupIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFixtureGroupIDListInq()";
        retVal =        PPTManager_i::txFixtureGroupIDListInq ( strFixtureGroupIDListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMachineRecipeIDListInq */
virtual ::CORBA::Long  txMachineRecipeIDListInq (::pptMachineRecipeIDListInqResult& strMachineRecipeIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMachineRecipeIDListInq()";
        retVal =        PPTManager_i::txMachineRecipeIDListInq ( strMachineRecipeIDListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEquipmentIDListInq */
virtual ::CORBA::Long  txEquipmentIDListInq (::pptEquipmentIDListInqResult& strEquipmentIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEquipmentIDListInq()";
        retVal =        PPTManager_i::txEquipmentIDListInq ( strEquipmentIDListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessDefinitionIDListInq */
virtual ::CORBA::Long  txProcessDefinitionIDListInq (::pptProcessDefinitionIDListInqResult& strProcessDefinitionIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessDefinitionIDListInq()";
        retVal =        PPTManager_i::txProcessDefinitionIDListInq ( strProcessDefinitionIDListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSplitWaferLotNotOnRouteReq */
virtual ::CORBA::Long  txSplitWaferLotNotOnRouteReq (::pptSplitWaferLotNotOnRouteReqResult& strSplitWaferLotNotOnRouteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& parentLotID, ::CORBA::Long parentLotWaferCount, ::CORBA::Long childLotWaferCount, const ::objectIdentifierSequence& childWaferID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSplitWaferLotNotOnRouteReq()";
        retVal =        PPTManager_i::txSplitWaferLotNotOnRouteReq ( strSplitWaferLotNotOnRouteReqResult, strObjCommonIn, requestUserID, parentLotID, parentLotWaferCount, childLotWaferCount, childWaferID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMergeWaferLotNotOnRouteReq */
virtual ::CORBA::Long  txMergeWaferLotNotOnRouteReq (::pptMergeWaferLotNotOnRouteReqResult& strMergeWaferLotNotOnRouteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& parentLotID, const ::objectIdentifier& childLotID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMergeWaferLotNotOnRouteReq()";
        retVal =        PPTManager_i::txMergeWaferLotNotOnRouteReq ( strMergeWaferLotNotOnRouteReqResult, strObjCommonIn, requestUserID, parentLotID, childLotID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txScrapWaferNotOnRouteReq */
virtual ::CORBA::Long  txScrapWaferNotOnRouteReq (::pptScrapWaferNotOnRouteReqResult& strScrapWaferNotOnRouteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, ::CORBA::Long waferCount, const ::objectIdentifier& reasonCode, const char* reasonDesc, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txScrapWaferNotOnRouteReq()";
        retVal =        PPTManager_i::txScrapWaferNotOnRouteReq ( strScrapWaferNotOnRouteReqResult, strObjCommonIn, lotID, waferCount, reasonCode, reasonDesc, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txScrapWaferNotOnRouteCancelReq */
virtual ::CORBA::Long  txScrapWaferNotOnRouteCancelReq (::pptScrapWaferNotOnRouteCancelReqResult& strScrapWaferNotOnRouteCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, ::CORBA::Long waferCount, const ::objectIdentifier& reasonCode, const char* reasonDesc, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txScrapWaferNotOnRouteCancelReq()";
        retVal =        PPTManager_i::txScrapWaferNotOnRouteCancelReq ( strScrapWaferNotOnRouteCancelReqResult, strObjCommonIn, lotID, waferCount, reasonCode, reasonDesc, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::diagnose */
virtual char*  diagnose (const char* cmd, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::diagnose()";
        retVal =        PPTManager_i::diagnose ( cmd, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInCassetteInq */
virtual ::CORBA::Long  txLotListInCassetteInq (::pptLotListInCassetteInqResult& strLotListInCassetteInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInCassetteInq()";
        retVal =        PPTManager_i::txLotListInCassetteInq ( strLotListInCassetteInqResult, strObjCommonIn, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFlowBatchCandidateInq */
virtual ::CORBA::Long  txFlowBatchCandidateInq (::pptFlowBatchCandidateInqResult& strFlowBatchCandidateInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFlowBatchCandidateInq()";
        retVal =        PPTManager_i::txFlowBatchCandidateInq ( strFlowBatchCandidateInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAliasWaferNameSetReq */
virtual ::CORBA::Long  txAliasWaferNameSetReq (::pptAliasWaferNameSetReqResult& strAliasWaferNameSetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::pptAliasWaferNameSequence& strAliasWaferNameList, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAliasWaferNameSetReq()";
        retVal =        PPTManager_i::txAliasWaferNameSetReq ( strAliasWaferNameSetReqResult, strObjCommonIn, lotID, strAliasWaferNameList, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUnloadingLotRpt */
virtual ::CORBA::Long  txUnloadingLotRpt (::pptUnloadingLotRptResult& strUnloadingLotRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& cassetteID, const ::objectIdentifier& portID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUnloadingLotRpt()";
        retVal =        PPTManager_i::txUnloadingLotRpt ( strUnloadingLotRptResult, strObjCommonIn, equipmentID, cassetteID, portID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteXferJobDetailInq */
virtual ::CORBA::Long  txLotCassetteXferJobDetailInq (::pptLotCassetteXferJobDetailInqResult& strLotCassetteXferJobDetailInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean detailFlag, const char* inquiryType, const ::objectIdentifier& inquiryKey, const char* functionID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteXferJobDetailInq()";
        retVal =        PPTManager_i::txLotCassetteXferJobDetailInq ( strLotCassetteXferJobDetailInqResult, strObjCommonIn, detailFlag, inquiryType, inquiryKey, functionID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInControlJobInq */
virtual ::CORBA::Long  txLotListInControlJobInq (::pptLotListInControlJobInqResult& strLotListInControlJobInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifierSequence& controlJobIDs, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInControlJobInq()";
        retVal =        PPTManager_i::txLotListInControlJobInq ( strLotListInControlJobInqResult, strObjCommonIn, requestUserID, controlJobIDs, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataHistoryInq */
virtual ::CORBA::Long  txCollectedDataHistoryInq (::pptCollectedDataHistoryInqResult& strCollectedDataHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const char* operationNumber, const char* operationPass, ::CORBA::Boolean getSpecFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataHistoryInq()";
        retVal =        PPTManager_i::txCollectedDataHistoryInq ( strCollectedDataHistoryInqResult, strObjCommonIn, lotID, routeID, operationNumber, operationPass, getSpecFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRTDIFSwitchingReq */
virtual ::CORBA::Long  txRTDIFSwitchingReq (::pptRTDIFSwitchingReqResult& strRTDIFSwitchingReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean bRTDIFSwitch, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRTDIFSwitchingReq()";
        retVal =        PPTManager_i::txRTDIFSwitchingReq ( strRTDIFSwitchingReqResult, strObjCommonIn, bRTDIFSwitch, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRTDConfigInfoUpdateReq */
virtual ::CORBA::Long  txRTDConfigInfoUpdateReq (::pptRTDConfigInfoUpdateReqResult& strRTDConfigInfoUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::stringSequence& updateMode, const ::pptRTDConfigInfoSequence& strRTDConfigInfoSeq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRTDConfigInfoUpdateReq()";
        retVal =        PPTManager_i::txRTDConfigInfoUpdateReq ( strRTDConfigInfoUpdateReqResult, strObjCommonIn, updateMode, strRTDConfigInfoSeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRTDDispatchListInq */
virtual ::CORBA::Long  txRTDDispatchListInq (::pptRTDDispatchListInqResult& strRTDDispatchListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* functionCode, const char* dispaptchStationID, const ::stringSequence& additionalParameters, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRTDDispatchListInq()";
        retVal =        PPTManager_i::txRTDDispatchListInq ( strRTDDispatchListInqResult, strObjCommonIn, functionCode, dispaptchStationID, additionalParameters, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRTDConfigInfoInq */
virtual ::CORBA::Long  txRTDConfigInfoInq (::pptRTDConfigInfoInqResult& strRTDConfigInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* functionCode, const char* dispaptchStationID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRTDConfigInfoInq()";
        retVal =        PPTManager_i::txRTDConfigInfoInq ( strRTDConfigInfoInqResult, strObjCommonIn, functionCode, dispaptchStationID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRTDIFSwitchInq */
virtual ::CORBA::Long  txRTDIFSwitchInq (::pptRTDIFSwitchInqResult& strRTDIFSwitchInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRTDIFSwitchInq()";
        retVal =        PPTManager_i::txRTDIFSwitchInq ( strRTDIFSwitchInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRTDHealthRpt */
virtual ::CORBA::Long  txRTDHealthRpt (::pptRTDHealthRptResult& strRTDHealthRptResult, const ::pptObjCommonIn& strObjCommonIn, const char* errorCode, const char* errorMessage, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRTDHealthRpt()";
        retVal =        PPTManager_i::txRTDHealthRpt ( strRTDHealthRptResult, strObjCommonIn, errorCode, errorMessage, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodListInq */
virtual ::CORBA::Long  txReticlePodListInq (::pptReticlePodListInqResult& strReticlePodListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& reticlePodID, const char* reticlePodCategory, const char* reticlePodStatus, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, ::CORBA::Boolean emptyFlag, const ::objectIdentifier& reticleID, const ::objectIdentifier& reticleGroupID, const char* reticlePartNumber, ::CORBA::Long maxRetrieveCount, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodListInq()";
        retVal =        PPTManager_i::txReticlePodListInq ( strReticlePodListInqResult, strObjCommonIn, requestUserID, reticlePodID, reticlePodCategory, reticlePodStatus, equipmentID, stockerID, emptyFlag, reticleID, reticleGroupID, reticlePartNumber, maxRetrieveCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodStatusInq */
virtual ::CORBA::Long  txReticlePodStatusInq (::pptReticlePodStatusInqResult& strReticlePodStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& reticlePodID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodStatusInq()";
        retVal =        PPTManager_i::txReticlePodStatusInq ( strReticlePodStatusInqResult, strObjCommonIn, requestUserID, reticlePodID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleSortRpt */
virtual ::CORBA::Long  txReticleSortRpt (::pptReticleSortRptResult& strReticleSortRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::pptReticleSortInfoSequence& strReticleSortInfo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleSortRpt()";
        retVal =        PPTManager_i::txReticleSortRpt ( strReticleSortRptResult, strObjCommonIn, requestUserID, strReticleSortInfo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodMultiStatusChangeRpt */
virtual ::CORBA::Long  txReticlePodMultiStatusChangeRpt (::pptReticlePodMultiStatusChangeRptResult& strReticlePodMultiStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const char* reticlePodStatus, const ::objectIdentifierSequence& reticlePodID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodMultiStatusChangeRpt()";
        retVal =        PPTManager_i::txReticlePodMultiStatusChangeRpt ( strReticlePodMultiStatusChangeRptResult, strObjCommonIn, requestUserID, reticlePodStatus, reticlePodID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodPMInfoResetReq */
virtual ::CORBA::Long  txReticlePodPMInfoResetReq (::pptReticlePodPMInfoResetReqResult& strReticlePodPMInfoResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& reticlePodID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodPMInfoResetReq()";
        retVal =        PPTManager_i::txReticlePodPMInfoResetReq ( strReticlePodPMInfoResetReqResult, strObjCommonIn, requestUserID, reticlePodID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodXferStatusChangeRpt */
virtual ::CORBA::Long  txReticlePodXferStatusChangeRpt (::pptReticlePodXferStatusChangeRptResult& strReticlePodXferStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptXferReticlePodSequence& strXferReticlePod, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodXferStatusChangeRpt()";
        retVal =        PPTManager_i::txReticlePodXferStatusChangeRpt ( strReticlePodXferStatusChangeRptResult, strObjCommonIn, requestUserID, stockerID, equipmentID, strXferReticlePod, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodInventoryRpt */
virtual ::CORBA::Long  txReticlePodInventoryRpt (::pptReticlePodInventoryRptResult& strReticlePodInventoryRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptInventoryReticlePodInfoSequence& strInventoryReticlePodInfo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodInventoryRpt()";
        retVal =        PPTManager_i::txReticlePodInventoryRpt ( strReticlePodInventoryRptResult, strObjCommonIn, requestUserID, stockerID, equipmentID, strInventoryReticlePodInfo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleJustInOutRpt */
virtual ::CORBA::Long  txReticleJustInOutRpt (::pptReticleJustInOutRptResult& strReticleJustInOutRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const char* moveDirection, const ::objectIdentifier& reticlePodID, const ::pptMoveReticlesSequence& strMoveReticles, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleJustInOutRpt()";
        retVal =        PPTManager_i::txReticleJustInOutRpt ( strReticleJustInOutRptResult, strObjCommonIn, requestUserID, moveDirection, reticlePodID, strMoveReticles, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEnvironmentVariableUpdateReq */
virtual ::CORBA::Long  txEnvironmentVariableUpdateReq (::pptEnvironmentVariableUpdateReqResult& strEnvironmentVariableUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEnvVariableListSequence& strPptEnvVariable, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEnvironmentVariableUpdateReq()";
        retVal =        PPTManager_i::txEnvironmentVariableUpdateReq ( strEnvironmentVariableUpdateReqResult, strObjCommonIn, strPptEnvVariable, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEnvironmentVariableInfoInq */
virtual ::CORBA::Long  txEnvironmentVariableInfoInq (::pptEnvironmentVariableInfoInqResult& strEnvironmentVariableInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEnvironmentVariableInfoInq()";
        retVal =        PPTManager_i::txEnvironmentVariableInfoInq ( strEnvironmentVariableInfoInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteDeliveryForInternalBufferReq */
virtual ::CORBA::Long  txCassetteDeliveryForInternalBufferReq (::pptCassetteDeliveryForInternalBufferReqResult& strCassetteDeliveryForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteDeliveryForInternalBufferReq()";
        retVal =        PPTManager_i::txCassetteDeliveryForInternalBufferReq ( strCassetteDeliveryForInternalBufferReqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoForInternalBufferInq */
virtual ::CORBA::Long  txEqpInfoForInternalBufferInq (::pptEqpInfoForInternalBufferInqResult& strEqpInfoForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForInternalBufferInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoForInternalBufferInq()";
        retVal =        PPTManager_i::txEqpInfoForInternalBufferInq ( strEqpInfoForInternalBufferInqResult, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForInternalBufferInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLoadingLotForInternalBufferRpt */
virtual ::CORBA::Long  txLoadingLotForInternalBufferRpt (::pptLoadingLotForInternalBufferRptResult& strLoadingLotForInternalBufferRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& cassetteID, const ::objectIdentifier& portID, const char* loadPurposeType, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLoadingLotForInternalBufferRpt()";
        retVal =        PPTManager_i::txLoadingLotForInternalBufferRpt ( strLoadingLotForInternalBufferRptResult, strObjCommonIn, equipmentID, cassetteID, portID, loadPurposeType, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotsInfoForOpeStartForInternalBufferInq */
virtual ::CORBA::Long  txLotsInfoForOpeStartForInternalBufferInq (::pptLotsInfoForOpeStartForInternalBufferInqResult& strLotsInfoForOpeStartForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifierSequence& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotsInfoForOpeStartForInternalBufferInq()";
        retVal =        PPTManager_i::txLotsInfoForOpeStartForInternalBufferInq ( strLotsInfoForOpeStartForInternalBufferInqResult, strObjCommonIn, equipmentID, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotsInfoForStartReservationForInternalBufferInq */
virtual ::CORBA::Long  txLotsInfoForStartReservationForInternalBufferInq (::pptLotsInfoForStartReservationForInternalBufferInqResult& strLotsInfoForStartReservationForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptStartCassetteSequence& strStartCassette, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotsInfoForStartReservationForInternalBufferInq()";
        retVal =        PPTManager_i::txLotsInfoForStartReservationForInternalBufferInq ( strLotsInfoForStartReservationForInternalBufferInqResult, strObjCommonIn, equipmentID, strStartCassette, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMoveCarrierFromInternalBufferRpt */
virtual ::CORBA::Long  txMoveCarrierFromInternalBufferRpt (::pptMoveCarrierFromInternalBufferRptResult& strMoveCarrierFromInternalBufferRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& destinationPortID, const ::objectIdentifier& carrierID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMoveCarrierFromInternalBufferRpt()";
        retVal =        PPTManager_i::txMoveCarrierFromInternalBufferRpt ( strMoveCarrierFromInternalBufferRptResult, strObjCommonIn, equipmentID, destinationPortID, carrierID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMoveCarrierToInternalBufferRpt */
virtual ::CORBA::Long  txMoveCarrierToInternalBufferRpt (::pptMoveCarrierToInternalBufferRptResult& strMoveCarrierToInternalBufferRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& loadedPortID, const ::objectIdentifier& carrierID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMoveCarrierToInternalBufferRpt()";
        retVal =        PPTManager_i::txMoveCarrierToInternalBufferRpt ( strMoveCarrierToInternalBufferRptResult, strObjCommonIn, equipmentID, loadedPortID, carrierID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeCompForInternalBufferReq */
virtual ::CORBA::Long  txOpeCompForInternalBufferReq (::pptOpeCompForInternalBufferReqResult& strOpeCompForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::objectIdentifierSequence& holdReleasedLotIDs, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeCompForInternalBufferReq()";
        retVal =        PPTManager_i::txOpeCompForInternalBufferReq ( strOpeCompForInternalBufferReqResult, strObjCommonIn, equipmentID, controlJobID, spcResultRequiredFlag, claimMemo, holdReleasedLotIDs, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeCompForInternalBufferReq__120 */
virtual ::CORBA::Long  txOpeCompForInternalBufferReq__120 (::pptOpeCompForInternalBufferReqResult& strOpeCompForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::objectIdentifierSequence& holdReleasedLotIDs, ::pptAPCBaseCassetteSequence& strAPCBaseCassetteListForOpeComp, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeCompForInternalBufferReq__120()";
        retVal =        PPTManager_i::txOpeCompForInternalBufferReq__120 ( strOpeCompForInternalBufferReqResult, strObjCommonIn, equipmentID, controlJobID, spcResultRequiredFlag, claimMemo, holdReleasedLotIDs, strAPCBaseCassetteListForOpeComp, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeStartForInternalBufferReq */
virtual ::CORBA::Long  txOpeStartForInternalBufferReq (::pptOpeStartForInternalBufferReqResult& strOpeStartForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean processJobPauseFlag, const char* claimMemo, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeStartForInternalBufferReq()";
        retVal =        PPTManager_i::txOpeStartForInternalBufferReq ( strOpeStartForInternalBufferReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, processJobPauseFlag, claimMemo, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStartLotsReservationCancelForInternalBufferReq */
virtual ::CORBA::Long  txStartLotsReservationCancelForInternalBufferReq (::pptStartLotsReservationCancelForInternalBufferReqResult& strStartLotsReservationCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const char* claimMemo, char*& APCIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStartLotsReservationCancelForInternalBufferReq()";
        retVal =        PPTManager_i::txStartLotsReservationCancelForInternalBufferReq ( strStartLotsReservationCancelForInternalBufferReqResult, strObjCommonIn, equipmentID, controlJobID, claimMemo, APCIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStartLotsReservationForInternalBufferReq */
virtual ::CORBA::Long  txStartLotsReservationForInternalBufferReq (::pptStartLotsReservationForInternalBufferReqResult& strStartLotsReservationForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, const char* claimMemo, char*& APCIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStartLotsReservationForInternalBufferReq()";
        retVal =        PPTManager_i::txStartLotsReservationForInternalBufferReq ( strStartLotsReservationForInternalBufferReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, claimMemo, APCIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUnloadingLotForInternalBufferRpt */
virtual ::CORBA::Long  txUnloadingLotForInternalBufferRpt (::pptUnloadingLotForInternalBufferRptResult& strUnloadingLotForInternalBufferRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& cassetteID, const ::objectIdentifier& portID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUnloadingLotForInternalBufferRpt()";
        retVal =        PPTManager_i::txUnloadingLotForInternalBufferRpt ( strUnloadingLotForInternalBufferRptResult, strObjCommonIn, equipmentID, cassetteID, portID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeStartCancelForInternalBufferReq */
virtual ::CORBA::Long  txOpeStartCancelForInternalBufferReq (::pptOpeStartCancelForInternalBufferReqResult& strOpeStartCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const char* claimMemo, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeStartCancelForInternalBufferReq()";
        retVal =        PPTManager_i::txOpeStartCancelForInternalBufferReq ( strOpeStartCancelForInternalBufferReqResult, strObjCommonIn, equipmentID, controlJobID, claimMemo, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeStartCancelForInternalBufferReq__120 */
virtual ::CORBA::Long  txOpeStartCancelForInternalBufferReq__120 (::pptOpeStartCancelForInternalBufferReqResult& strOpeStartCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const char* claimMemo, ::pptAPCBaseCassetteSequence& strAPCBaseCassetteListForOpeStartCancel, char*& APCIFControlStatus, char*& DCSIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeStartCancelForInternalBufferReq__120()";
        retVal =        PPTManager_i::txOpeStartCancelForInternalBufferReq__120 ( strOpeStartCancelForInternalBufferReqResult, strObjCommonIn, equipmentID, controlJobID, claimMemo, strAPCBaseCassetteListForOpeStartCancel, APCIFControlStatus, DCSIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUnloadingLotsReservationForInternalBufferRpt */
virtual ::CORBA::Long  txUnloadingLotsReservationForInternalBufferRpt (::pptUnloadingLotsReservationForInternalBufferRptResult& strUnloadingLotsReservationForInternalBufferRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& cassetteID, const ::objectIdentifier& unloadReservePortID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUnloadingLotsReservationForInternalBufferRpt()";
        retVal =        PPTManager_i::txUnloadingLotsReservationForInternalBufferRpt ( strUnloadingLotsReservationForInternalBufferRptResult, strObjCommonIn, equipmentID, cassetteID, unloadReservePortID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSorterOnEqpReq */
virtual ::CORBA::Long  txWaferSorterOnEqpReq (::pptWaferSorterOnEqpReqResult& strWaferSorterOnEqpReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const char* actionCode, const ::objectIdentifier& equipmentID, const ::pptWaferSorterSlotMapSequence& strWaferSorterSlotMapSequence, const char* portGroup, const char* physicalRecipeID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSorterOnEqpReq()";
        retVal =        PPTManager_i::txWaferSorterOnEqpReq ( strWaferSorterOnEqpReqResult, strObjCommonIn, requestUserID, actionCode, equipmentID, strWaferSorterSlotMapSequence, portGroup, physicalRecipeID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txChangeWaferSorterActionReq */
virtual ::CORBA::Long  txChangeWaferSorterActionReq (::pptChangeWaferSorterActionReqResult& strChangeWaferSorterActionReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptWaferSorterActionListSequence& strWaferSorterActionListSequence, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txChangeWaferSorterActionReq()";
        retVal =        PPTManager_i::txChangeWaferSorterActionReq ( strChangeWaferSorterActionReqResult, strObjCommonIn, strWaferSorterActionListSequence, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSorterActionListInq */
virtual ::CORBA::Long  txWaferSorterActionListInq (::pptWaferSorterActionListInqResult& strWaferSorterActionListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSorterActionListInq()";
        retVal =        PPTManager_i::txWaferSorterActionListInq ( strWaferSorterActionListInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSorterDataInq */
virtual ::CORBA::Long  txWaferSorterDataInq (::pptWaferSorterDataInqResult& strWaferSorterDataInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* portGroup, const ::objectIdentifier& equipmentID, const char* requiredData, const char* sortPattern, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSorterDataInq()";
        retVal =        PPTManager_i::txWaferSorterDataInq ( strWaferSorterDataInqResult, strObjCommonIn, portGroup, equipmentID, requiredData, sortPattern, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSorterOnEqpRpt */
virtual ::CORBA::Long  txWaferSorterOnEqpRpt (::pptWaferSorterOnEqpRptResult& strWaferSorterOnEqpRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* actionCode, const ::pptWaferSorterSlotMapSequence& strWaferSorterSlotMapSequence, ::CORBA::Long rcTCS, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSorterOnEqpRpt()";
        retVal =        PPTManager_i::txWaferSorterOnEqpRpt ( strWaferSorterOnEqpRptResult, strObjCommonIn, equipmentID, actionCode, strWaferSorterSlotMapSequence, rcTCS, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txVendorLotReceiveAndPrepareReq */
virtual ::CORBA::Long  txVendorLotReceiveAndPrepareReq (::pptVendorLotReceiveAndPrepareReqResult& strVendorLotReceiveAndPrepareReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGroup, const ::objectIdentifier& cassetteID, const char* lotType, const char* subLotType, const ::objectIdentifier& creatingLotID, const ::objectIdentifier& vendorLotID, const ::objectIdentifier& vendorID, const ::objectIdentifier& productID, const ::objectIdentifier& bankID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txVendorLotReceiveAndPrepareReq()";
        retVal =        PPTManager_i::txVendorLotReceiveAndPrepareReq ( strVendorLotReceiveAndPrepareReqResult, strObjCommonIn, equipmentID, portGroup, cassetteID, lotType, subLotType, creatingLotID, vendorLotID, vendorID, productID, bankID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSorterDataCompareReq */
virtual ::CORBA::Long  txWaferSorterDataCompareReq (::pptWaferSorterDataCompareReqResult& strWaferSorterDataCompareReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* portGroup, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSorterDataCompareReq()";
        retVal =        PPTManager_i::txWaferSorterDataCompareReq ( strWaferSorterDataCompareReqResult, strObjCommonIn, portGroup, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSorterOnEqpCancelReq */
virtual ::CORBA::Long  txWaferSorterOnEqpCancelReq (::pptWaferSorterOnEqpCancelReqResult& strWaferSortOnEqpCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* portGroup, const char* requestTimeStamp, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSorterOnEqpCancelReq()";
        retVal =        PPTManager_i::txWaferSorterOnEqpCancelReq ( strWaferSortOnEqpCancelReqResult, strObjCommonIn, requestUserID, equipmentID, portGroup, requestTimeStamp, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSorterScrapWaferInq */
virtual ::CORBA::Long  txWaferSorterScrapWaferInq (::pptWaferSorterScrapWaferInqResult& strWaferSorterScrapWaferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* portGroup, const ::objectIdentifierSequence& cassetteIDs, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSorterScrapWaferInq()";
        retVal =        PPTManager_i::txWaferSorterScrapWaferInq ( strWaferSorterScrapWaferInqResult, strObjCommonIn, requestUserID, equipmentID, portGroup, cassetteIDs, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferSorterPositionAdjustReq */
virtual ::CORBA::Long  txWaferSorterPositionAdjustReq (::pptWaferSorterPositionAdjustReqResult& strWaferSorterPositionAdjustReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const char* actionCode, const ::objectIdentifier& equipmentID, const ::pptWaferSorterSlotMapSequence& strWaferSorterSlotMapSequence, const char* portGroup, const char* physicalRecipeID, const ::pptWaferTransferSequence& strWaferXferSeq, const char* adjustDirection, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferSorterPositionAdjustReq()";
        retVal =        PPTManager_i::txWaferSorterPositionAdjustReq ( strWaferSorterPositionAdjustReqResult, strObjCommonIn, requestUserID, actionCode, equipmentID, strWaferSorterSlotMapSequence, portGroup, physicalRecipeID, strWaferXferSeq, adjustDirection, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotVerifyForLoadingForInternalBufferReq */
virtual ::CORBA::Long  txLotVerifyForLoadingForInternalBufferReq (::pptLotVerifyForLoadingForInternalBufferReqResult& strLotVerifyForLoadingForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& portID, const ::objectIdentifier& cassetteID, const char* loadPurposeType, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotVerifyForLoadingForInternalBufferReq()";
        retVal =        PPTManager_i::txLotVerifyForLoadingForInternalBufferReq ( strLotVerifyForLoadingForInternalBufferReqResult, strObjCommonIn, equipmentID, portID, cassetteID, loadPurposeType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUnloadingLotsReservationCancelForInternalBufferReq */
virtual ::CORBA::Long  txUnloadingLotsReservationCancelForInternalBufferReq (::pptUnloadingLotsReservationCancelForInternalBufferReqResult& strUnloadingLotsReservationCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUnloadingLotsReservationCancelForInternalBufferReq()";
        retVal =        PPTManager_i::txUnloadingLotsReservationCancelForInternalBufferReq ( strUnloadingLotsReservationCancelForInternalBufferReqResult, strObjCommonIn, equipmentID, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCarrierOutFromInternalBufferReq */
virtual ::CORBA::Long  txCarrierOutFromInternalBufferReq (::pptCarrierOutFromInternalBufferReqResult& strCarrierOutFromInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& cassetteID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCarrierOutFromInternalBufferReq()";
        retVal =        PPTManager_i::txCarrierOutFromInternalBufferReq ( strCarrierOutFromInternalBufferReqResult, strObjCommonIn, equipmentID, cassetteID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotExternalPriorityChangeReq */
virtual ::CORBA::Long  txLotExternalPriorityChangeReq (::pptLotExternalPriorityChangeReqResult& strLotExternalPriorityChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotExtPrtySequence& strLotExtPrtyList, ::CORBA::Boolean commitByLotFlag, const char* claimMemo, ::CORBA::Long seqIx, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotExternalPriorityChangeReq()";
        retVal =        PPTManager_i::txLotExternalPriorityChangeReq ( strLotExternalPriorityChangeReqResult, strObjCommonIn, strLotExtPrtyList, commitByLotFlag, claimMemo, seqIx, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBankInCancelReq */
virtual ::CORBA::Long  txBankInCancelReq (::pptBankInCancelReqResult& strBankInCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBankInCancelReq()";
        retVal =        PPTManager_i::txBankInCancelReq ( strBankInCancelReqResult, strObjCommonIn, lotID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExperimentalLotDeleteReq */
virtual ::CORBA::Long  txExperimentalLotDeleteReq (::pptExperimentalLotDeleteReqResult& strExperimentalLotDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotFamilyID, const ::objectIdentifier& splitRouteID, const char* splitOperationNumber, const ::objectIdentifier& originalRouteID, const char* originalOperationNumber, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExperimentalLotDeleteReq()";
        retVal =        PPTManager_i::txExperimentalLotDeleteReq ( strExperimentalLotDeleteReqResult, strObjCommonIn, lotFamilyID, splitRouteID, splitOperationNumber, originalRouteID, originalOperationNumber, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExperimentalLotExecReq */
virtual ::CORBA::Long  txExperimentalLotExecReq (::pptExperimentalLotExecReqResult& strExperimentalLotExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExperimentalLotExecReq()";
        retVal =        PPTManager_i::txExperimentalLotExecReq ( strExperimentalLotExecReqResult, strObjCommonIn, lotID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExperimentalLotInfoInq */
virtual ::CORBA::Long  txExperimentalLotInfoInq (::pptExperimentalLotInfoInqResult& strExperimentalLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotFamilyID, const ::objectIdentifier& splitRouteID, const char* splitOperationNumber, const ::objectIdentifier& originalRouteID, const char* originalOperationNumber, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExperimentalLotInfoInq()";
        retVal =        PPTManager_i::txExperimentalLotInfoInq ( strExperimentalLotInfoInqResult, strObjCommonIn, lotFamilyID, splitRouteID, splitOperationNumber, originalRouteID, originalOperationNumber, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExperimentalLotListInq */
virtual ::CORBA::Long  txExperimentalLotListInq (::pptExperimentalLotListInqResult& strExperimentalLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotFamilyID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExperimentalLotListInq()";
        retVal =        PPTManager_i::txExperimentalLotListInq ( strExperimentalLotListInqResult, strObjCommonIn, lotFamilyID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExperimentalLotUpdateReq */
virtual ::CORBA::Long  txExperimentalLotUpdateReq (::pptExperimentalLotUpdateReqResult& strExperimentalLotUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotFamilyID, const ::objectIdentifier& splitRouteID, const char* splitOperationNumber, const ::objectIdentifier& originalRouteID, const char* originalOperationNumber, ::CORBA::Boolean actionEMail, ::CORBA::Boolean actionHold, const char* testMemo, ::CORBA::Boolean execFlag, const char* actionTimeStamp, const ::objectIdentifier& modifyUserID, const ::pptExperimentalLotDetailInfoSequence& strExperimentalLotDetailInfoSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExperimentalLotUpdateReq()";
        retVal =        PPTManager_i::txExperimentalLotUpdateReq ( strExperimentalLotUpdateReqResult, strObjCommonIn, lotFamilyID, splitRouteID, splitOperationNumber, originalRouteID, originalOperationNumber, actionEMail, actionHold, testMemo, execFlag, actionTimeStamp, modifyUserID, strExperimentalLotDetailInfoSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessListInRouteInq */
virtual ::CORBA::Long  txProcessListInRouteInq (::pptProcessListInRouteInqResult& strProcessListInRouteInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& lotFamilyID, const ::objectIdentifier& originalRouteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessListInRouteInq()";
        retVal =        PPTManager_i::txProcessListInRouteInq ( strProcessListInRouteInqResult, strObjCommonIn, lotID, lotFamilyID, originalRouteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferListInLotFamilyInq */
virtual ::CORBA::Long  txWaferListInLotFamilyInq (::pptWaferListInLotFamilyInqResult& strWaferListInLotFamilyInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotFamilyID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferListInLotFamilyInq()";
        retVal =        PPTManager_i::txWaferListInLotFamilyInq ( strWaferListInLotFamilyInqResult, strObjCommonIn, lotFamilyID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessLagTimeUpdateReq */
virtual ::CORBA::Long  txProcessLagTimeUpdateReq (::pptProcessLagTimeUpdateReqResult& strProcessLagTimeUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* action, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessLagTimeUpdateReq()";
        retVal =        PPTManager_i::txProcessLagTimeUpdateReq ( strProcessLagTimeUpdateReqResult, strObjCommonIn, lotID, action, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReworkReq */
virtual ::CORBA::Long  txReworkReq (::pptReworkReqResult& strReworkReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReworkReq& strReworkReq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReworkReq()";
        retVal =        PPTManager_i::txReworkReq ( strReworkReqResult, strObjCommonIn, strReworkReq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPartialReworkReq */
virtual ::CORBA::Long  txPartialReworkReq (::pptPartialReworkReqResult& strPartialReworkReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptPartialReworkReq& strPartialReworkReq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPartialReworkReq()";
        retVal =        PPTManager_i::txPartialReworkReq ( strPartialReworkReqResult, strObjCommonIn, strPartialReworkReq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBranchReq */
virtual ::CORBA::Long  txBranchReq (::pptBranchReqResult& strBranchReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBranchReq& strBranchReq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBranchReq()";
        retVal =        PPTManager_i::txBranchReq ( strBranchReqResult, strObjCommonIn, strBranchReq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDynamicRouteListInq */
virtual ::CORBA::Long  txDynamicRouteListInq (::pptDynamicRouteListInqResult& strDynamicRouteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDynamicRouteListInq& strDynamicRouteListInq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDynamicRouteListInq()";
        retVal =        PPTManager_i::txDynamicRouteListInq ( strDynamicRouteListInqResult, strObjCommonIn, strDynamicRouteListInq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReFlowBatchingReq */
virtual ::CORBA::Long  txReFlowBatchingReq (::pptReFlowBatchingReqResult& strReFlowBatchingReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptReFlowBatchingReqCassetteSequence& strReFlowBatchingReqCassette, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReFlowBatchingReq()";
        retVal =        PPTManager_i::txReFlowBatchingReq ( strReFlowBatchingReqResult, strObjCommonIn, equipmentID, strReFlowBatchingReqCassette, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFlowBatchLostLotsInq */
virtual ::CORBA::Long  txFlowBatchLostLotsInq (::pptFlowBatchLostLotsInqResult& strFlowBatchLostLotsInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFlowBatchLostLotsInq()";
        retVal =        PPTManager_i::txFlowBatchLostLotsInq ( strFlowBatchLostLotsInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpRelatedRecipeIDListInq */
virtual ::CORBA::Long  txEqpRelatedRecipeIDListInq (::pptEqpRelatedRecipeIDListInqResult& strEqpRelatedRecipeIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpRelatedRecipeIDListInq()";
        retVal =        PPTManager_i::txEqpRelatedRecipeIDListInq ( strEqpRelatedRecipeIDListInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRunningHoldReq */
virtual ::CORBA::Long  txRunningHoldReq (::pptRunningHoldReqResult& strRunningHoldReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::objectIdentifier& holdReasonCodeID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRunningHoldReq()";
        retVal =        PPTManager_i::txRunningHoldReq ( strRunningHoldReqResult, strObjCommonIn, equipmentID, controlJobID, holdReasonCodeID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txForceOpeCompReq */
virtual ::CORBA::Long  txForceOpeCompReq (::pptForceOpeCompReqResult& strForceOpeCompReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::objectIdentifierSequence& holdReleasedLotIDs, char*& APCIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txForceOpeCompReq()";
        retVal =        PPTManager_i::txForceOpeCompReq ( strForceOpeCompReqResult, strObjCommonIn, equipmentID, controlJobID, spcResultRequiredFlag, claimMemo, holdReleasedLotIDs, APCIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txForceOpeCompForInternalBufferReq */
virtual ::CORBA::Long  txForceOpeCompForInternalBufferReq (::pptForceOpeCompForInternalBufferReqResult& strForceOpeCompForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::objectIdentifierSequence& holdReleasedLotIDs, char*& APCIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txForceOpeCompForInternalBufferReq()";
        retVal =        PPTManager_i::txForceOpeCompForInternalBufferReq ( strForceOpeCompForInternalBufferReqResult, strObjCommonIn, equipmentID, controlJobID, spcResultRequiredFlag, claimMemo, holdReleasedLotIDs, APCIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEnhancedFutureHoldReq */
virtual ::CORBA::Long  txEnhancedFutureHoldReq (::pptEnhancedFutureHoldReqResult& strEnhancedFutureHoldReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* holdType, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& reasonCodeID, const ::objectIdentifier& relatedLotID, ::CORBA::Boolean postFlag, ::CORBA::Boolean singleTriggerFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEnhancedFutureHoldReq()";
        retVal =        PPTManager_i::txEnhancedFutureHoldReq ( strEnhancedFutureHoldReqResult, strObjCommonIn, holdType, lotID, routeID, operationNumber, reasonCodeID, relatedLotID, postFlag, singleTriggerFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFutureHoldListByKeyInq */
virtual ::CORBA::Long  txFutureHoldListByKeyInq (::pptFutureHoldListByKeyInqResult& strFutureHoldListByKeyInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFutureHoldSearchKey& searchKey, ::CORBA::Long count, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFutureHoldListByKeyInq()";
        retVal =        PPTManager_i::txFutureHoldListByKeyInq ( strFutureHoldListByKeyInqResult, strObjCommonIn, searchKey, count, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReworkWithHoldReleaseReq */
virtual ::CORBA::Long  txReworkWithHoldReleaseReq (::pptReworkWithHoldReleaseReqResult& strReworkWithHoldReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReworkReq& strReworkReq, const char* claimMemo, const ::objectIdentifier& releaseReasonCodeID, const ::pptHoldListSequence& strLotHoldReleaseReqList, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReworkWithHoldReleaseReq()";
        retVal =        PPTManager_i::txReworkWithHoldReleaseReq ( strReworkWithHoldReleaseReqResult, strObjCommonIn, strReworkReq, claimMemo, releaseReasonCodeID, strLotHoldReleaseReqList, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPartialReworkWithHoldReleaseReq */
virtual ::CORBA::Long  txPartialReworkWithHoldReleaseReq (::pptPartialReworkWithHoldReleaseReqResult& strPartialReworkWithHoldReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptPartialReworkReq& strPartialReworkReq, const char* claimMemo, const ::objectIdentifier& releaseReasonCodeID, const ::pptHoldListSequence& strLotHoldReleaseReqList, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPartialReworkWithHoldReleaseReq()";
        retVal =        PPTManager_i::txPartialReworkWithHoldReleaseReq ( strPartialReworkWithHoldReleaseReqResult, strObjCommonIn, strPartialReworkReq, claimMemo, releaseReasonCodeID, strLotHoldReleaseReqList, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSplitWaferLotWithHoldReleaseReq */
virtual ::CORBA::Long  txSplitWaferLotWithHoldReleaseReq (::pptSplitWaferLotWithHoldReleaseReqResult& strSplitWaferLotWithHoldReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& parentLotID, const ::objectIdentifierSequence& childWaferID, ::CORBA::Boolean futureMergeFlag, const ::objectIdentifier& mergedRouteID, const char* mergedOperationNumber, ::CORBA::Boolean branchingRouteSpecifyFlag, const ::objectIdentifier& subRouteID, const char* returnOperationNumber, const ::objectIdentifier& releaseReasonCodeID, const ::pptHoldListSequence& strLotHoldReqList, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSplitWaferLotWithHoldReleaseReq()";
        retVal =        PPTManager_i::txSplitWaferLotWithHoldReleaseReq ( strSplitWaferLotWithHoldReleaseReqResult, strObjCommonIn, parentLotID, childWaferID, futureMergeFlag, mergedRouteID, mergedOperationNumber, branchingRouteSpecifyFlag, subRouteID, returnOperationNumber, releaseReasonCodeID, strLotHoldReqList, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBranchWithHoldReleaseReq */
virtual ::CORBA::Long  txBranchWithHoldReleaseReq (::pptBranchWithHoldReleaseReqResult& strBranchWithHoldReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBranchReq& strBranchReq, const ::objectIdentifier& releaseReasonCodeID, const ::pptHoldListSequence& strLotHoldReleaseReqList, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBranchWithHoldReleaseReq()";
        retVal =        PPTManager_i::txBranchWithHoldReleaseReq ( strBranchWithHoldReleaseReqResult, strObjCommonIn, strBranchReq, releaseReasonCodeID, strLotHoldReleaseReqList, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationCancelReq */
virtual ::CORBA::Long  txSchdlChangeReservationCancelReq (::pptSchdlChangeReservationCancelReqResult& strSchdlChangeReservationCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSchdlChangeReservationSequence& strSchdlChangeReservations, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationCancelReq()";
        retVal =        PPTManager_i::txSchdlChangeReservationCancelReq ( strSchdlChangeReservationCancelReqResult, strObjCommonIn, strSchdlChangeReservations, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationChangeReq */
virtual ::CORBA::Long  txSchdlChangeReservationChangeReq (::pptSchdlChangeReservationChangeReqResult& strSchdlChangeReservationChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSchdlChangeReservation& strCurrentSchdlChangeReservation, const ::pptSchdlChangeReservation& strNewSchdlChangeReservation, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationChangeReq()";
        retVal =        PPTManager_i::txSchdlChangeReservationChangeReq ( strSchdlChangeReservationChangeReqResult, strObjCommonIn, strCurrentSchdlChangeReservation, strNewSchdlChangeReservation, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationCreateReq */
virtual ::CORBA::Long  txSchdlChangeReservationCreateReq (::pptSchdlChangeReservationCreateReqResult& strSchdlChangeReservationCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSchdlChangeReservation& strSchdlChangeReservation, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationCreateReq()";
        retVal =        PPTManager_i::txSchdlChangeReservationCreateReq ( strSchdlChangeReservationCreateReqResult, strObjCommonIn, strSchdlChangeReservation, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationListInq */
virtual ::CORBA::Long  txSchdlChangeReservationListInq (::pptSchdlChangeReservationListInqResult& strSchdlChangeReservationListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* eventID, const char* objectID, const char* objectType, const char* targetRouteID, const char* targetOperationNumber, const char* productID, const char* routeID, const char* operationNumber, const char* startDate, const char* endDate, const char* status, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationListInq()";
        retVal =        PPTManager_i::txSchdlChangeReservationListInq ( strSchdlChangeReservationListInqResult, strObjCommonIn, eventID, objectID, objectType, targetRouteID, targetOperationNumber, productID, routeID, operationNumber, startDate, endDate, status, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotReQueueReq */
virtual ::CORBA::Long  txLotReQueueReq (::pptLotReQueueReqResult& strLotReQueueReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotReQueueAttributeSequence& strLotReQueueAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotReQueueReq()";
        retVal =        PPTManager_i::txLotReQueueReq ( strLotReQueueReqResult, strObjCommonIn, strLotReQueueAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationExecuteReq */
virtual ::CORBA::Long  txSchdlChangeReservationExecuteReq (::pptSchdlChangeReservationExecuteReqResult& strSchdlChangeReservationExecuteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRescheduledLotAttributesSequence& strRescheduledLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationExecuteReq()";
        retVal =        PPTManager_i::txSchdlChangeReservationExecuteReq ( strSchdlChangeReservationExecuteReqResult, strObjCommonIn, strRescheduledLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txModuleProcessDefinitionIDListInq */
virtual ::CORBA::Long  txModuleProcessDefinitionIDListInq (::pptModuleProcessDefinitionIDListInqResult& strModuleProcessDefinitionIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptModuleProcessDefinitionIDListInq& strModuleProcessDefinitionIDListInq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txModuleProcessDefinitionIDListInq()";
        retVal =        PPTManager_i::txModuleProcessDefinitionIDListInq ( strModuleProcessDefinitionIDListInqResult, strObjCommonIn, strModuleProcessDefinitionIDListInq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStageIDListInq */
virtual ::CORBA::Long  txStageIDListInq (::pptStageIDListInqResult& strStageIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptStageIDListInq& strStageIDListInq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStageIDListInq()";
        retVal =        PPTManager_i::txStageIDListInq ( strStageIDListInqResult, strObjCommonIn, strStageIDListInq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRouteOperationListForLotInq */
virtual ::CORBA::Long  txRouteOperationListForLotInq (::pptRouteOperationListForLotInqResult& strRouteOperationListForLotInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRouteOperationListForLotInq()";
        retVal =        PPTManager_i::txRouteOperationListForLotInq ( strRouteOperationListForLotInqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFlowBatchOpeLocateCheckReq */
virtual ::CORBA::Long  txFlowBatchOpeLocateCheckReq (::pptFlowBatchOpeLocateCheckReqResult& strFlowBatchOpeLocateCheckReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean locateDirection, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const ::pptProcessRef& processRef, ::CORBA::Long seqNo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFlowBatchOpeLocateCheckReq()";
        retVal =        PPTManager_i::txFlowBatchOpeLocateCheckReq ( strFlowBatchOpeLocateCheckReqResult, strObjCommonIn, locateDirection, lotID, routeID, operationID, operationNumber, processRef, seqNo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessHoldReq */
virtual ::CORBA::Long  txProcessHoldReq (::pptProcessHoldReqResult& strProcessHoldReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* holdType, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& productID, const ::objectIdentifier& reasonCodeID, ::CORBA::Boolean withExecHoldFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessHoldReq()";
        retVal =        PPTManager_i::txProcessHoldReq ( strProcessHoldReqResult, strObjCommonIn, holdType, routeID, operationNumber, productID, reasonCodeID, withExecHoldFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessHoldCancelReq */
virtual ::CORBA::Long  txProcessHoldCancelReq (::pptProcessHoldCancelReqResult& strProcessHoldCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* holdType, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& productID, const ::objectIdentifier& holdReasonCodeID, const ::objectIdentifier& releaseReasonCodeID, ::CORBA::Boolean withExecHoldReleaseFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessHoldCancelReq()";
        retVal =        PPTManager_i::txProcessHoldCancelReq ( strProcessHoldCancelReqResult, strObjCommonIn, holdType, routeID, operationNumber, productID, holdReasonCodeID, releaseReasonCodeID, withExecHoldReleaseFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessHoldListInq */
virtual ::CORBA::Long  txProcessHoldListInq (::pptProcessHoldListInqResult& strProcessHoldListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::pptProcessHoldSearchKey& strProcessHoldSearchKey, ::CORBA::Long count, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessHoldListInq()";
        retVal =        PPTManager_i::txProcessHoldListInq ( strProcessHoldListInqResult, strObjCommonIn, requestUserID, strProcessHoldSearchKey, count, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessHoldExecReq */
virtual ::CORBA::Long  txProcessHoldExecReq (::pptProcessHoldExecReqResult& strProcessHoldExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessHoldExecReq()";
        retVal =        PPTManager_i::txProcessHoldExecReq ( strProcessHoldExecReqResult, strObjCommonIn, lotID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteDispatchAttributeUpdateReq */
virtual ::CORBA::Long  txCassetteDispatchAttributeUpdateReq (::pptCassetteDispatchAttributeUpdateReqResult& strCassetteDispatchAttributeUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Boolean setFlag, const char* actionCode, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteDispatchAttributeUpdateReq()";
        retVal =        PPTManager_i::txCassetteDispatchAttributeUpdateReq ( strCassetteDispatchAttributeUpdateReqResult, strObjCommonIn, cassetteID, setFlag, actionCode, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupChannelListInq */
virtual ::CORBA::Long  txBackupChannelListInq (::pptBackupChannelListInqResult& strBackupChannelListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::pptBackupUniqueChannel& strBackupUniqueChannel, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupChannelListInq()";
        retVal =        PPTManager_i::txBackupChannelListInq ( strBackupChannelListInqResult, strObjCommonIn, requestUserID, strBackupUniqueChannel, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupChannelRegisterReq */
virtual ::CORBA::Long  txBackupChannelRegisterReq (::pptBackupChannelRegisterReqResult& strBackupChannelRegisterReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::pptBackupChannel& strBackupChannel, ::CORBA::Boolean addFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupChannelRegisterReq()";
        retVal =        PPTManager_i::txBackupChannelRegisterReq ( strBackupChannelRegisterReqResult, strObjCommonIn, requestUserID, strBackupChannel, addFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupChannelDeleteReq */
virtual ::CORBA::Long  txBackupChannelDeleteReq (::pptBackupChannelDeleteReqResult& strBackupChannelDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::pptBackupChannelSequence& strBackupChannelSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupChannelDeleteReq()";
        retVal =        PPTManager_i::txBackupChannelDeleteReq ( strBackupChannelDeleteReqResult, strObjCommonIn, requestUserID, strBackupChannelSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupDestinationInfoInq */
virtual ::CORBA::Long  txBackupDestinationInfoInq (::pptBackupDestinationInfoInqResult& strBackupDestinationInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupDestinationInfoInq()";
        retVal =        PPTManager_i::txBackupDestinationInfoInq ( strBackupDestinationInfoInqResult, strObjCommonIn, requestUserID, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupStateChangeReq */
virtual ::CORBA::Long  txBackupStateChangeReq (::pptBackupStateChangeReqResult& strBackupStateChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const char* request, const ::objectIdentifier& lotID, const ::pptBackupAddress& strBackupAddress, const ::pptBackupProcess& strBackupProcess, const ::pptBackupProcess& strSourceProcess, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupStateChangeReq()";
        retVal =        PPTManager_i::txBackupStateChangeReq ( strBackupStateChangeReqResult, strObjCommonIn, requestUserID, request, lotID, strBackupAddress, strBackupProcess, strSourceProcess, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupLotInfoInq */
virtual ::CORBA::Long  txBackupLotInfoInq (::pptBackupLotInfoInqResult& strBackupLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupLotInfoInq()";
        retVal =        PPTManager_i::txBackupLotInfoInq ( strBackupLotInfoInqResult, strObjCommonIn, requestUserID, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupLotSendReq */
virtual ::CORBA::Long  txBackupLotSendReq (::pptBackupLotSendReqResult& strBackupLotSendReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, const ::pptLotDBInfo& strLotDBInfo, const ::pptBackupAddress& strBackupAddress, const ::pptBackupProcess& strBackupProcess, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupLotSendReq()";
        retVal =        PPTManager_i::txBackupLotSendReq ( strBackupLotSendReqResult, strObjCommonIn, requestUserID, lotID, strLotDBInfo, strBackupAddress, strBackupProcess, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupLotSendCancelReq */
virtual ::CORBA::Long  txBackupLotSendCancelReq (::pptBackupLotSendCancelReqResult& strBackupLotSendCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, const ::pptBackupAddress& strBackupAddress, const ::pptBackupProcess& strBackupProcess, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupLotSendCancelReq()";
        retVal =        PPTManager_i::txBackupLotSendCancelReq ( strBackupLotSendCancelReqResult, strObjCommonIn, requestUserID, lotID, strBackupAddress, strBackupProcess, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupSendRequestListInq */
virtual ::CORBA::Long  txBackupSendRequestListInq (::pptBackupSendRequestListInqResult& strBackupSendRequestListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupSendRequestListInq()";
        retVal =        PPTManager_i::txBackupSendRequestListInq ( strBackupSendRequestListInqResult, strObjCommonIn, requestUserID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupSendRequestReceiveReq */
virtual ::CORBA::Long  txBackupSendRequestReceiveReq (::pptBackupSendRequestReceiveReqResult& strBackupSendRequestReceiveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::pptBackupReceiveRequest& strBackupReceiveRequest, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupSendRequestReceiveReq()";
        retVal =        PPTManager_i::txBackupSendRequestReceiveReq ( strBackupSendRequestReceiveReqResult, strObjCommonIn, requestUserID, strBackupReceiveRequest, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupLotReturnReq */
virtual ::CORBA::Long  txBackupLotReturnReq (::pptBackupLotReturnReqResult& strBackupLotReturnReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, const ::pptLotDBInfo& strLotDBInfo, const ::pptBackupAddress& strBackupAddress, const ::pptBackupProcess& strBackupProcess, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupLotReturnReq()";
        retVal =        PPTManager_i::txBackupLotReturnReq ( strBackupLotReturnReqResult, strObjCommonIn, requestUserID, lotID, strLotDBInfo, strBackupAddress, strBackupProcess, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupLotReturnCancelReq */
virtual ::CORBA::Long  txBackupLotReturnCancelReq (::pptBackupLotReturnCancelReqResult& strBackupLotReturnCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, const ::pptBackupAddress& strBackupAddress, const ::pptBackupProcess& strBackupProcess, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupLotReturnCancelReq()";
        retVal =        PPTManager_i::txBackupLotReturnCancelReq ( strBackupLotReturnCancelReqResult, strObjCommonIn, requestUserID, lotID, strBackupAddress, strBackupProcess, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupReturnRequestListInq */
virtual ::CORBA::Long  txBackupReturnRequestListInq (::pptBackupReturnRequestListInqResult& strBackupReturnRequestListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupReturnRequestListInq()";
        retVal =        PPTManager_i::txBackupReturnRequestListInq ( strBackupReturnRequestListInqResult, strObjCommonIn, requestUserID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupReturnRequestReceiveReq */
virtual ::CORBA::Long  txBackupReturnRequestReceiveReq (::pptBackupReturnRequestReceiveReqResult& strBackupReturnRequestReceiveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::pptBackupReceiveRequest& strBackupReceiveRequest, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupReturnRequestReceiveReq()";
        retVal =        PPTManager_i::txBackupReturnRequestReceiveReq ( strBackupReturnRequestReceiveReqResult, strObjCommonIn, requestUserID, strBackupReceiveRequest, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupSplitSuffixChangeReq */
virtual ::CORBA::Long  txBackupSplitSuffixChangeReq (::pptBackupSplitSuffixChangeReqResult& strBackupSplitSuffixChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, ::CORBA::Long splitNo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupSplitSuffixChangeReq()";
        retVal =        PPTManager_i::txBackupSplitSuffixChangeReq ( strBackupSplitSuffixChangeReqResult, strObjCommonIn, requestUserID, lotID, splitNo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupLotOperationListInq */
virtual ::CORBA::Long  txBackupLotOperationListInq (::pptBackupLotOperationListInqResult& strBackupLotOperationListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, ::CORBA::Long searchCount, const ::objectIdentifier& lotID, const ::pptProcessBackupData& strProcessBackupData, const ::pptBackupAddress& strBackupAddress, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupLotOperationListInq()";
        retVal =        PPTManager_i::txBackupLotOperationListInq ( strBackupLotOperationListInqResult, strObjCommonIn, requestUserID, searchCount, lotID, strProcessBackupData, strBackupAddress, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupSendRequestWaferInq */
virtual ::CORBA::Long  txBackupSendRequestWaferInq (::pptBackupSendRequestWaferInqResult& strBackupSendRequestWaferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupSendRequestWaferInq()";
        retVal =        PPTManager_i::txBackupSendRequestWaferInq ( strBackupSendRequestWaferInqResult, strObjCommonIn, requestUserID, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBackupReturnRequestWaferInq */
virtual ::CORBA::Long  txBackupReturnRequestWaferInq (::pptBackupReturnRequestWaferInqResult& strBackupReturnRequestWaferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBackupReturnRequestWaferInq()";
        retVal =        PPTManager_i::txBackupReturnRequestWaferInq ( strBackupReturnRequestWaferInqResult, strObjCommonIn, requestUserID, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProductGroupIDListInq */
virtual ::CORBA::Long  txProductGroupIDListInq (::pptProductGroupIDListInqResult& strProductGroupIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProductGroupIDListInq()";
        retVal =        PPTManager_i::txProductGroupIDListInq ( strProductGroupIDListInqResult, strObjCommonIn, requestUserID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txTechnologyIDListInq */
virtual ::CORBA::Long  txTechnologyIDListInq (::pptTechnologyIDListInqResult& strTechnologyIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txTechnologyIDListInq()";
        retVal =        PPTManager_i::txTechnologyIDListInq ( strTechnologyIDListInqResult, strObjCommonIn, requestUserID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSpcActionExecuteReq */
virtual ::CORBA::Long  txSpcActionExecuteReq (::pptSpcActionExecuteReqResult& strSpcActionExecuteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBankMoveSequence& strBankMoveList, const ::pptMailSendSequence& strMailSendList, const ::pptReworkBranchSequence& strReworkBranchList, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSpcActionExecuteReq()";
        retVal =        PPTManager_i::txSpcActionExecuteReq ( strSpcActionExecuteReqResult, strObjCommonIn, strBankMoveList, strMailSendList, strReworkBranchList, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeParameterAdjustReq */
virtual ::CORBA::Long  txRecipeParameterAdjustReq (::pptRecipeParameterAdjustReqResult& strRecipeParameterAdjustReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean allProcessStartFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeParameterAdjustReq()";
        retVal =        PPTManager_i::txRecipeParameterAdjustReq ( strRecipeParameterAdjustReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, allProcessStartFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCJPJProgressInq */
virtual ::CORBA::Long  txCJPJProgressInq (::pptCJPJProgressInqResult& strCJPJProgressInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCJPJProgressInq()";
        retVal =        PPTManager_i::txCJPJProgressInq ( strCJPJProgressInqResult, strObjCommonIn, equipmentID, controlJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txChamberProcessWaferRpt */
virtual ::CORBA::Long  txChamberProcessWaferRpt (::pptChamberProcessWaferRptResult& strChamberProcessWaferRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptChamberProcessLotInfoSequence& strChamberProcessLotInfos, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txChamberProcessWaferRpt()";
        retVal =        PPTManager_i::txChamberProcessWaferRpt ( strChamberProcessWaferRptResult, strObjCommonIn, equipmentID, controlJobID, strChamberProcessLotInfos, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotOperationListFromHistoryInq */
virtual ::CORBA::Long  txLotOperationListFromHistoryInq (::pptLotOperationListFromHistoryInqResult& strLotOperationListFromHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long searchCount, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotOperationListFromHistoryInq()";
        retVal =        PPTManager_i::txLotOperationListFromHistoryInq ( strLotOperationListFromHistoryInqResult, strObjCommonIn, searchCount, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpListByOperationInq */
virtual ::CORBA::Long  txEqpListByOperationInq (::pptEqpListByOperationInqResult& strEqpListByOperationInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpListByOperationInqInParm& strEqpListByOperationInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpListByOperationInq()";
        retVal =        PPTManager_i::txEqpListByOperationInq ( strEqpListByOperationInqResult, strObjCommonIn, strEqpListByOperationInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCCapabilityInq */
virtual ::CORBA::Long  txAPCCapabilityInq (::pptAPCCapabilityInqResult& strAPCCapabilityInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* APCSystemName, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCCapabilityInq()";
        retVal =        PPTManager_i::txAPCCapabilityInq ( strAPCCapabilityInqResult, strObjCommonIn, equipmentID, APCSystemName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCControlJobInfoInq */
virtual ::CORBA::Long  txAPCControlJobInfoInq (::pptAPCControlJobInfoInqResult& strAPCControlJobInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCControlJobInfoInq()";
        retVal =        PPTManager_i::txAPCControlJobInfoInq ( strAPCControlJobInfoInqResult, strObjCommonIn, equipmentID, controlJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCDerivedDataInq */
virtual ::CORBA::Long  txAPCDerivedDataInq (::pptAPCDerivedDataInqResult& strAPCDerivedDataInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCDerivedDataInq()";
        retVal =        PPTManager_i::txAPCDerivedDataInq ( strAPCDerivedDataInqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCEntityValueInq */
virtual ::CORBA::Long  txAPCEntityValueInq (::pptAPCEntityValueInqResult& strAPCEntityValueInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptAPCEntityValueFilter& strAPCEntityValueFilter, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCEntityValueInq()";
        retVal =        PPTManager_i::txAPCEntityValueInq ( strAPCEntityValueInqResult, strObjCommonIn, strAPCEntityValueFilter, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCIFListInq */
virtual ::CORBA::Long  txAPCIFListInq (::pptAPCIFListInqResult& strAPCIFListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCIFListInq()";
        retVal =        PPTManager_i::txAPCIFListInq ( strAPCIFListInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCProcessHistoryInq */
virtual ::CORBA::Long  txAPCProcessHistoryInq (::pptAPCProcessHistoryInqResult& strAPCProcessHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& controlJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCProcessHistoryInq()";
        retVal =        PPTManager_i::txAPCProcessHistoryInq ( strAPCProcessHistoryInqResult, strObjCommonIn, controlJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCProductDispositionInq */
virtual ::CORBA::Long  txAPCProductDispositionInq (::pptAPCProductDispositionInqResult& strAPCProductDispositionInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptAPCRunTimeCapabilityResponseSequence& strAPCRunTimeCapabilityResponseList, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCProductDispositionInq()";
        retVal =        PPTManager_i::txAPCProductDispositionInq ( strAPCProductDispositionInqResult, strObjCommonIn, equipmentID, controlJobID, strAPCRunTimeCapabilityResponseList, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCRecipeParameterAdjustInq */
virtual ::CORBA::Long  txAPCRecipeParameterAdjustInq (::pptAPCRecipeParameterAdjustInqResult& strAPCRecipeParameterAdjustInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptStartCassetteSequence& strStartCassette, const ::pptAPCRunTimeCapabilityResponseSequence& strAPCRunTimeCapabilityResponse, ::CORBA::Boolean final, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCRecipeParameterAdjustInq()";
        retVal =        PPTManager_i::txAPCRecipeParameterAdjustInq ( strAPCRecipeParameterAdjustInqResult, strObjCommonIn, equipmentID, strStartCassette, strAPCRunTimeCapabilityResponse, final, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCRunTimeCapabilityInq */
virtual ::CORBA::Long  txAPCRunTimeCapabilityInq (::pptAPCRunTimeCapabilityInqResult& strAPCRunTimeCapabilityInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean sendTxFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCRunTimeCapabilityInq()";
        retVal =        PPTManager_i::txAPCRunTimeCapabilityInq ( strAPCRunTimeCapabilityInqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, sendTxFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDCSpecDataForAPCInq */
virtual ::CORBA::Long  txDCSpecDataForAPCInq (::pptDCSpecDataForAPCInqResult& strDCSpecDataForAPCInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDCSpecDataForAPCInq()";
        retVal =        PPTManager_i::txDCSpecDataForAPCInq ( strDCSpecDataForAPCInqResult, strObjCommonIn, equipmentID, controlJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityListInq */
virtual ::CORBA::Long  txEntityListInq (::pptEntityListInqResult& strEntityListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* entityClass, const char* searchKeyName, const char* searchKeyValue, const char* option, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityListInq()";
        retVal =        PPTManager_i::txEntityListInq ( strEntityListInqResult, strObjCommonIn, entityClass, searchKeyName, searchKeyValue, option, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCDispositionLotActionReq */
virtual ::CORBA::Long  txAPCDispositionLotActionReq (::pptAPCDispositionLotActionReqResult& strAPCDispositionLotActionReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCDispositionLotActionReq()";
        retVal =        PPTManager_i::txAPCDispositionLotActionReq ( strAPCDispositionLotActionReqResult, strObjCommonIn, equipmentID, controlJobID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCIFPointReq */
virtual ::CORBA::Long  txAPCIFPointReq (::pptAPCIFPointReqResult& strAPCIFPointReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* operation, const ::pptAPCIF& strAPCIF, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCIFPointReq()";
        retVal =        PPTManager_i::txAPCIFPointReq ( strAPCIFPointReqResult, strObjCommonIn, operation, strAPCIF, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCProcessDispositionReq */
virtual ::CORBA::Long  txAPCProcessDispositionReq (::pptAPCProcessDispositionReqResult& strAPCProcessDispositionReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptAPCProcessDispositionRequest& strAPCProcessDispositionRequest, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCProcessDispositionReq()";
        retVal =        PPTManager_i::txAPCProcessDispositionReq ( strAPCProcessDispositionReqResult, strObjCommonIn, strAPCProcessDispositionRequest, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCProductDispositionRpt */
virtual ::CORBA::Long  txAPCProductDispositionRpt (::pptAPCProductDispositionRptResult& strAPCProductDispositionRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptAPCProductDispositionResponse& strAPCProductDispositionResponse, const ::pptAPCDispositionLotActionResultSequence& strAPCDispositionLotActionResultList, const ::objectIdentifier& equipmentID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCProductDispositionRpt()";
        retVal =        PPTManager_i::txAPCProductDispositionRpt ( strAPCProductDispositionRptResult, strObjCommonIn, strAPCProductDispositionResponse, strAPCDispositionLotActionResultList, equipmentID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessJobInfoRpt */
virtual ::CORBA::Long  txProcessJobInfoRpt (::pptProcessJobInfoRptResult& strProcessJobInfoRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptProcessJobSequence& strProcessJobList, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessJobInfoRpt()";
        retVal =        PPTManager_i::txProcessJobInfoRpt ( strProcessJobInfoRptResult, strObjCommonIn, equipmentID, controlJobID, strProcessJobList, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::timeStamp_DoCalculation */
virtual ::CORBA::Long  timeStamp_DoCalculation (::objTimeStamp_DoCalculation_out& strTimeStamp_DoCalculation_out, const ::pptObjCommonIn& strObjCommonIn, const char* currentTimeStamp, ::CORBA::Long days, ::CORBA::Long hours, ::CORBA::Long minutes, ::CORBA::Long seconds, ::CORBA::Long milliseconds, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::timeStamp_DoCalculation()";
        retVal =        PPTManager_i::timeStamp_DoCalculation ( strTimeStamp_DoCalculation_out, strObjCommonIn, currentTimeStamp, days, hours, minutes, seconds, milliseconds, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotDeleteReq */
virtual ::CORBA::Long  txLotDeleteReq (::pptLotDeleteReqResult& strLotDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotDeleteReq()";
        retVal =        PPTManager_i::txLotDeleteReq ( strLotDeleteReqResult, strObjCommonIn, lotID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSplitWaferLotWithoutHoldReleaseReq */
virtual ::CORBA::Long  txSplitWaferLotWithoutHoldReleaseReq (::pptSplitWaferLotWithoutHoldReleaseReqResult& strSplitWaferLotWithoutHoldReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& parentLotID, const ::objectIdentifierSequence& childWaferIDs, ::CORBA::Boolean futureMergeFlag, const ::objectIdentifier& mergedRouteID, const char* mergedOperationNumber, ::CORBA::Boolean branchingRouteSpecifyFlag, const ::objectIdentifier& subRouteID, const char* returnOperationNumber, const char* claimMemo, const ::pptHoldListSequence& strLotHoldRequests, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq()";
        retVal =        PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq ( strSplitWaferLotWithoutHoldReleaseReqResult, strObjCommonIn, parentLotID, childWaferIDs, futureMergeFlag, mergedRouteID, mergedOperationNumber, branchingRouteSpecifyFlag, subRouteID, returnOperationNumber, claimMemo, strLotHoldRequests, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPartialReworkWithoutHoldReleaseReq */
virtual ::CORBA::Long  txPartialReworkWithoutHoldReleaseReq (::pptPartialReworkWithoutHoldReleaseReqResult& strPartialReworkWithoutHoldReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptPartialReworkReq& strPartialReworkReq, const char* claimMemo, const ::pptHoldListSequence& strLotHoldRequests, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPartialReworkWithoutHoldReleaseReq()";
        retVal =        PPTManager_i::txPartialReworkWithoutHoldReleaseReq ( strPartialReworkWithoutHoldReleaseReqResult, strObjCommonIn, strPartialReworkReq, claimMemo, strLotHoldRequests, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessExecReq */
virtual ::CORBA::Long  txPostProcessExecReq (::pptPostProcessExecReqResult& strPostProcessExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* key, ::CORBA::Long syncFlag, ::CORBA::Long prevSeqNo, const char* keyTimeStamp, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessExecReq()";
        retVal =        PPTManager_i::txPostProcessExecReq ( strPostProcessExecReqResult, strObjCommonIn, key, syncFlag, prevSeqNo, keyTimeStamp, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessActionRegistReq */
virtual ::CORBA::Long  txPostProcessActionRegistReq (::pptPostProcessActionRegistReqResult& strPostProcessActionRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* txID, const char* patternID, const char* key, ::CORBA::Long seqNo, const ::pptPostProcessRegistrationParm& strPostProcessRegistrationParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessActionRegistReq()";
        retVal =        PPTManager_i::txPostProcessActionRegistReq ( strPostProcessActionRegistReqResult, strObjCommonIn, txID, patternID, key, seqNo, strPostProcessRegistrationParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessActionUpdateReq */
virtual ::CORBA::Long  txPostProcessActionUpdateReq (::pptPostProcessActionUpdateReqResult& strPostProcessActionUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* actionCode, const ::pptPostProcessActionInfoSequence& strPostProcessActionInfoSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessActionUpdateReq()";
        retVal =        PPTManager_i::txPostProcessActionUpdateReq ( strPostProcessActionUpdateReqResult, strObjCommonIn, actionCode, strPostProcessActionInfoSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessActionListInq */
virtual ::CORBA::Long  txPostProcessActionListInq (::pptPostProcessActionListInqResult& strPostProcessActionListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* key, ::CORBA::Long seqNo, const char* watchdogName, const char* postProcID, ::CORBA::Long syncFlag, const char* txID, const char* targetType, const ::pptPostProcessTargetObject& strPostProcessTargetObject, const char* status, ::CORBA::Long passedTime, const char* claimUserID, const char* startCreateTimeStamp, const char* endCreateTimeStamp, const char* startUpdateTimeStamp, const char* endUpdateTimeStamp, ::CORBA::Long maxCount, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessActionListInq()";
        retVal =        PPTManager_i::txPostProcessActionListInq ( strPostProcessActionListInqResult, strObjCommonIn, key, seqNo, watchdogName, postProcID, syncFlag, txID, targetType, strPostProcessTargetObject, status, passedTime, claimUserID, startCreateTimeStamp, endCreateTimeStamp, startUpdateTimeStamp, endUpdateTimeStamp, maxCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessConfigInfoInq */
virtual ::CORBA::Long  txPostProcessConfigInfoInq (::pptPostProcessConfigInfoInqResult& strPostProcessConfigInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* txID, const char* patternID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessConfigInfoInq()";
        retVal =        PPTManager_i::txPostProcessConfigInfoInq ( strPostProcessConfigInfoInqResult, strObjCommonIn, txID, patternID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMessageQueuePutReq */
virtual ::CORBA::Long  txMessageQueuePutReq (::pptMessageQueuePutReqResult& strMessageQueuePutReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptPortOperationModeSequence& strPortOperationMode, const ::objectIdentifier& equipmentStatusCode, const ::objectIdentifier& lotID, const char* lotProcessState, const char* lotHoldState, const ::objectIdentifier& cassetteID, const char* cassetteTransferState, ::CORBA::Boolean cassetteTransferReserveFlag, ::CORBA::Boolean cassetteDispatchReserveFlag, const ::objectIdentifier& durableID, const char* durableTransferState, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMessageQueuePutReq()";
        retVal =        PPTManager_i::txMessageQueuePutReq ( strMessageQueuePutReqResult, strObjCommonIn, equipmentID, strPortOperationMode, equipmentStatusCode, lotID, lotProcessState, lotHoldState, cassetteID, cassetteTransferState, cassetteTransferReserveFlag, cassetteDispatchReserveFlag, durableID, durableTransferState, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txControlJobManageReq */
virtual ::CORBA::Long  txControlJobManageReq (::pptControlJobManageReqResult& strControlJobManageReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& controlJobID, const char* controlJobAction, const ::pptControlJobCreateRequest& strControlJobCreateRequest, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txControlJobManageReq()";
        retVal =        PPTManager_i::txControlJobManageReq ( strControlJobManageReqResult, strObjCommonIn, controlJobID, controlJobAction, strControlJobCreateRequest, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeListInq */
virtual ::CORBA::Long  txQrestTimeListInq (::pptQrestTimeListInqResult& strQrestTimeListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeListInq()";
        retVal =        PPTManager_i::txQrestTimeListInq ( strQrestTimeListInqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFutureReworkReq */
virtual ::CORBA::Long  txFutureReworkReq (::pptFutureReworkReqResult& strFutureReworkReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const char* operationNumber, const ::pptFutureReworkDetailInfo& strFutureReworkDetailInfo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFutureReworkReq()";
        retVal =        PPTManager_i::txFutureReworkReq ( strFutureReworkReqResult, strObjCommonIn, lotID, routeID, operationNumber, strFutureReworkDetailInfo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFutureReworkCancelReq */
virtual ::CORBA::Long  txFutureReworkCancelReq (::pptFutureReworkCancelReqResult& strFutureReworkCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const char* operationNumber, const ::pptFutureReworkDetailInfoSequence& strFutureReworkDetailInfoSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFutureReworkCancelReq()";
        retVal =        PPTManager_i::txFutureReworkCancelReq ( strFutureReworkCancelReqResult, strObjCommonIn, lotID, routeID, operationNumber, strFutureReworkDetailInfoSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFutureReworkListInq */
virtual ::CORBA::Long  txFutureReworkListInq (::pptFutureReworkListInqResult& strFutureReworkListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFutureReworkListInq()";
        retVal =        PPTManager_i::txFutureReworkListInq ( strFutureReworkListInqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFutureReworkExecReq */
virtual ::CORBA::Long  txFutureReworkExecReq (::pptFutureReworkExecReqResult& strFutureReworkExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFutureReworkExecReq()";
        retVal =        PPTManager_i::txFutureReworkExecReq ( strFutureReworkExecReqResult, strObjCommonIn, lotID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCControlJobInfoRpt */
virtual ::CORBA::Long  txAPCControlJobInfoRpt (::pptAPCControlJobInfoRptResult& strAPCControlJobInfoRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, const char* notifyStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCControlJobInfoRpt()";
        retVal =        PPTManager_i::txAPCControlJobInfoRpt ( strAPCControlJobInfoRptResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, notifyStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeActionExecReq */
virtual ::CORBA::Long  txQrestTimeActionExecReq (::pptQrestTimeActionExecReqResult& strQrestTimeActionExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* lotStatus, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& equipmentID, const ::pptQrestTimeAction& strQrestTimeAction, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeActionExecReq()";
        retVal =        PPTManager_i::txQrestTimeActionExecReq ( strQrestTimeActionExecReqResult, strObjCommonIn, lotID, lotStatus, routeID, operationNumber, equipmentID, strQrestTimeAction, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::lot_qtimeInfo_SortByAction */
virtual ::CORBA::Long  lot_qtimeInfo_SortByAction (::objLot_qtimeInfo_SortByAction_out& strLot_qtimeInfo_SortByAction_out, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::pptQtimeInfoSequence& strQtimeInfoSeq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::lot_qtimeInfo_SortByAction()";
        retVal =        PPTManager_i::lot_qtimeInfo_SortByAction ( strLot_qtimeInfo_SortByAction_out, strObjCommonIn, lotID, strQtimeInfoSeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataActionReq */
virtual ::CORBA::Long  txCollectedDataActionReq (::pptCollectedDataActionReqResult& strCollectedDataActionReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCollectedDataActionReqInParm& strCollectedDataActionReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataActionReq()";
        retVal =        PPTManager_i::txCollectedDataActionReq ( strCollectedDataActionReqResult, strObjCommonIn, strCollectedDataActionReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOpeStartCancelForDCSRpt */
virtual ::CORBA::Long  txOpeStartCancelForDCSRpt (::pptOpeStartCancelForDCSRptResult& strOpeStartCancelForDCSRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptOpeStartCancelForDCSRptInParm& strOpeStartCancelForDCSRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOpeStartCancelForDCSRpt()";
        retVal =        PPTManager_i::txOpeStartCancelForDCSRpt ( strOpeStartCancelForDCSRptResult, strObjCommonIn, strOpeStartCancelForDCSRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotDeletionCheckReq */
virtual ::CORBA::Long  txLotDeletionCheckReq (::pptLotDeletionCheckReqResult& strLotDeletionCheckReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotDeletionCheckReq()";
        retVal =        PPTManager_i::txLotDeletionCheckReq ( strLotDeletionCheckReqResult, strObjCommonIn, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferDeleteReq */
virtual ::CORBA::Long  txWaferDeleteReq (::pptWaferDeleteReqResult& strWaferDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptObjectIDSequence& strWaferIDs, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferDeleteReq()";
        retVal =        PPTManager_i::txWaferDeleteReq ( strWaferDeleteReqResult, strObjCommonIn, strWaferIDs, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCProcessListInRouteInq */
virtual ::CORBA::Long  txFPCProcessListInRouteInq (::pptFPCProcessListInRouteInqResult& strFPCProcessListInRouteInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCProcessListInRouteInqInParm& strFPCProcessListInRouteInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCProcessListInRouteInq()";
        retVal =        PPTManager_i::txFPCProcessListInRouteInq ( strFPCProcessListInRouteInqResult, strObjCommonIn, strFPCProcessListInRouteInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMachineRecipeListForFPCInq */
virtual ::CORBA::Long  txMachineRecipeListForFPCInq (::pptMachineRecipeListForFPCInqResult& strMachineRecipeListForFPCInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptMachineRecipeListForFPCInqInParm& strMachineRecipeListForFPCInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMachineRecipeListForFPCInq()";
        retVal =        PPTManager_i::txMachineRecipeListForFPCInq ( strMachineRecipeListForFPCInqResult, strObjCommonIn, strMachineRecipeListForFPCInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCDetailInfoInq */
virtual ::CORBA::Long  txFPCDetailInfoInq (::pptFPCDetailInfoInqResult& strFPCDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCDetailInfoInqInParm& strFPCDetailInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCDetailInfoInq()";
        retVal =        PPTManager_i::txFPCDetailInfoInq ( strFPCDetailInfoInqResult, strObjCommonIn, strFPCDetailInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpRecipeParameterListInq */
virtual ::CORBA::Long  txEqpRecipeParameterListInq (::pptEqpRecipeParameterListInqResult& strEqpRecipeParameterListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpRecipeParameterListInqInParm& strEqpRecipeParameterListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpRecipeParameterListInq()";
        retVal =        PPTManager_i::txEqpRecipeParameterListInq ( strEqpRecipeParameterListInqResult, strObjCommonIn, strEqpRecipeParameterListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDataCollectionListInq */
virtual ::CORBA::Long  txDataCollectionListInq (::pptDataCollectionListInqResult& strDataCollectionListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDataCollectionListInqInParm& strDataCollectionListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDataCollectionListInq()";
        retVal =        PPTManager_i::txDataCollectionListInq ( strDataCollectionListInqResult, strObjCommonIn, strDataCollectionListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDCDefDetailInfoInq */
virtual ::CORBA::Long  txDCDefDetailInfoInq (::pptDCDefDetailInfoInqResult& strDCDefDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDCDefDetailInfoInqInParm& strDCDefDetailInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDCDefDetailInfoInq()";
        retVal =        PPTManager_i::txDCDefDetailInfoInq ( strDCDefDetailInfoInqResult, strObjCommonIn, strDCDefDetailInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDCSpecDetailInfoInq */
virtual ::CORBA::Long  txDCSpecDetailInfoInq (::pptDCSpecDetailInfoInqResult& strDCSpecDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDCSpecDetailInfoInqInParm& strDCSpecDetailInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDCSpecDetailInfoInq()";
        retVal =        PPTManager_i::txDCSpecDetailInfoInq ( strDCSpecDetailInfoInqResult, strObjCommonIn, strDCSpecDetailInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCUpdateReq */
virtual ::CORBA::Long  txFPCUpdateReq (::pptFPCUpdateReqResult& strFPCUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCUpdateReqInParm& strFPCUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCUpdateReq()";
        retVal =        PPTManager_i::txFPCUpdateReq ( strFPCUpdateReqResult, strObjCommonIn, strFPCUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCDeleteReq */
virtual ::CORBA::Long  txFPCDeleteReq (::pptFPCDeleteReqResult& strFPCDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCDeleteReqInParm& strFPCDeleteReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCDeleteReq()";
        retVal =        PPTManager_i::txFPCDeleteReq ( strFPCDeleteReqResult, strObjCommonIn, strFPCDeleteReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCExecReq */
virtual ::CORBA::Long  txFPCExecReq (::pptFPCExecReqResult& strFPCExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCExecReqInParm& strFPCExecReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCExecReq()";
        retVal =        PPTManager_i::txFPCExecReq ( strFPCExecReqResult, strObjCommonIn, strFPCExecReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::lotFamily_allLots_GetDR */
virtual ::CORBA::Long  lotFamily_allLots_GetDR (::objLotFamily_allLots_GetDR_out& strLotFamily_allLots_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotFamilyID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::lotFamily_allLots_GetDR()";
        retVal =        PPTManager_i::lotFamily_allLots_GetDR ( strLotFamily_allLots_GetDR_out, strObjCommonIn, lotFamilyID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhereNextUTSCarrierInq */
virtual ::CORBA::Long  txWhereNextUTSCarrierInq (::pptWhereNextUTSCarrierInqResult& strWhereNextUTSCarrierInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptWhereNextUTSCarrierInqInParm& strWhereNextUTSCarrierInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhereNextUTSCarrierInq()";
        retVal =        PPTManager_i::txWhereNextUTSCarrierInq ( strWhereNextUTSCarrierInqResult, strObjCommonIn, strWhereNextUTSCarrierInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRTDInterfaceInq */
virtual ::CORBA::Long  txRTDInterfaceInq (::pptRTDInterfaceInqResult& strRTDInterfaceInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRTDInterfaceInqInParm& strRTDInterfaceInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRTDInterfaceInq()";
        retVal =        PPTManager_i::txRTDInterfaceInq ( strRTDInterfaceInqResult, strObjCommonIn, strRTDInterfaceInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableRegistReq */
virtual ::CORBA::Long  txDurableRegistReq (::pptDurableRegistReqResult& strDurableRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean updateFlag, const char* className, const ::pptDurableAttribute& strDurableAttribute, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableRegistReq()";
        retVal =        PPTManager_i::txDurableRegistReq ( strDurableRegistReqResult, strObjCommonIn, updateFlag, className, strDurableAttribute, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableDeleteReq */
virtual ::CORBA::Long  txDurableDeleteReq (::pptDurableDeleteReqResult& strDurableDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* className, const ::objectIdentifier& durableID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableDeleteReq()";
        retVal =        PPTManager_i::txDurableDeleteReq ( strDurableDeleteReqResult, strObjCommonIn, className, durableID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUserDataInq */
virtual ::CORBA::Long  txUserDataInq (::pptUserDataInqResult& strUserDataInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUserDataInqInParm& strUserDataInqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUserDataInq()";
        retVal =        PPTManager_i::txUserDataInq ( strUserDataInqResult, strObjCommonIn, strUserDataInqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCodeListInq */
virtual ::CORBA::Long  txCodeListInq (::pptCodeListInqResult& strCodeListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& category, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCodeListInq()";
        retVal =        PPTManager_i::txCodeListInq ( strCodeListInqResult, strObjCommonIn, category, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSortJobStatusChangeRpt */
virtual ::CORBA::Long  txSortJobStatusChangeRpt (::pptSortJobStatusChangeRptResult& strSortJobStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& portGroupID, const ::objectIdentifier& jobID, const char* jobType, const char* jobStatus, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSortJobStatusChangeRpt()";
        retVal =        PPTManager_i::txSortJobStatusChangeRpt ( strSortJobStatusChangeRptResult, strObjCommonIn, equipmentID, portGroupID, jobID, jobType, jobStatus, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSortJobPriorityChangeReq */
virtual ::CORBA::Long  txSortJobPriorityChangeReq (::pptSortJobPriorityChangeReqResult& strSortJobPriorityChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& jobIDs, const char* jobType, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSortJobPriorityChangeReq()";
        retVal =        PPTManager_i::txSortJobPriorityChangeReq ( strSortJobPriorityChangeReqResult, strObjCommonIn, jobIDs, jobType, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSortJobCreateReq */
virtual ::CORBA::Long  txSortJobCreateReq (::pptSortJobCreateReqResult& strSortJobCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSorterComponentJobListAttributesSequence& strSorterComponentJobListAttributesSequence, const ::objectIdentifier& equipmentID, const char* portGroupID, ::CORBA::Boolean waferIDReadFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSortJobCreateReq()";
        retVal =        PPTManager_i::txSortJobCreateReq ( strSortJobCreateReqResult, strObjCommonIn, strSorterComponentJobListAttributesSequence, equipmentID, portGroupID, waferIDReadFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSortJobCancelReq */
virtual ::CORBA::Long  txSortJobCancelReq (::pptSortJobCancelReqResult& strSortJobCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& sorterJobID, const ::objectIdentifierSequence& sorterComponentJobIDseq, ::CORBA::Boolean notifyToTCSFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSortJobCancelReq()";
        retVal =        PPTManager_i::txSortJobCancelReq ( strSortJobCancelReqResult, strObjCommonIn, sorterJobID, sorterComponentJobIDseq, notifyToTCSFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSortJobCheckConditionReq */
virtual ::CORBA::Long  txSortJobCheckConditionReq (::pptSortJobCheckConditionReqResult& strSortJobCheckConditionReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSorterComponentJobListAttributesSequence& strSorterComponentJobListAttributesSequence, const ::objectIdentifier& equipmentID, const char* portGroupID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSortJobCheckConditionReq()";
        retVal =        PPTManager_i::txSortJobCheckConditionReq ( strSortJobCheckConditionReqResult, strObjCommonIn, strSorterComponentJobListAttributesSequence, equipmentID, portGroupID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSortJobStartReq */
virtual ::CORBA::Long  txSortJobStartReq (::pptSortJobStartReqResult& strSortJobStartReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSortJobStartReqInParm& strSortJobStartReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSortJobStartReq()";
        retVal =        PPTManager_i::txSortJobStartReq ( strSortJobStartReqResult, strObjCommonIn, strSortJobStartReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSortJobListInq */
virtual ::CORBA::Long  txSortJobListInq (::pptSortJobListInqResult& strSortJobListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& carrierID, const ::objectIdentifier& lotID, const ::objectIdentifier& createUser, const ::objectIdentifier& sorterJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSortJobListInq()";
        retVal =        PPTManager_i::txSortJobListInq ( strSortJobListInqResult, strObjCommonIn, equipmentID, carrierID, lotID, createUser, sorterJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSortJobStatusInq */
virtual ::CORBA::Long  txSortJobStatusInq (::pptSortJobStatusInqResult& strSortJobStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& sorterJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSortJobStatusInq()";
        retVal =        PPTManager_i::txSortJobStatusInq ( strSortJobStatusInqResult, strObjCommonIn, sorterJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoInq__090 */
virtual ::CORBA::Long  txLotInfoInq__090 (::pptLotInfoInqResult__090& strLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& lotID, ::CORBA::Boolean lotBasicInfoFlag, ::CORBA::Boolean lotControlUseInfoFlag, ::CORBA::Boolean lotFlowBatchInfoFlag, ::CORBA::Boolean lotNoteFlagInfoFlag, ::CORBA::Boolean lotOperationInfoFlag, ::CORBA::Boolean lotOrderInfoFlag, ::CORBA::Boolean lotControlJobInfoFlag, ::CORBA::Boolean lotProductInfoFlag, ::CORBA::Boolean lotRecipeInfoFlag, ::CORBA::Boolean lotLocationInfoFlag, ::CORBA::Boolean lotWipOperationInfoFlag, ::CORBA::Boolean lotWaferAttributesFlag, ::CORBA::Boolean lotListInCassetteInfoFlag, ::CORBA::Boolean waferMapInCassetteInfoFlag, ::CORBA::Boolean lotBackupInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoInq__090()";
        retVal =        PPTManager_i::txLotInfoInq__090 ( strLotInfoInqResult, strObjCommonIn, lotID, lotBasicInfoFlag, lotControlUseInfoFlag, lotFlowBatchInfoFlag, lotNoteFlagInfoFlag, lotOperationInfoFlag, lotOrderInfoFlag, lotControlJobInfoFlag, lotProductInfoFlag, lotRecipeInfoFlag, lotLocationInfoFlag, lotWipOperationInfoFlag, lotWaferAttributesFlag, lotListInCassetteInfoFlag, waferMapInCassetteInfoFlag, lotBackupInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInq__090 */
virtual ::CORBA::Long  txLotListInq__090 (::pptLotListInqResult__090& strLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotStatus, const char* lotType, const ::objectIdentifier& productID, const char* orderNumber, const char* customerCode, const ::objectIdentifier& manufacturingLayerID, const ::objectIdentifier& routeID, const char* operationNumber, ::CORBA::Boolean bankInRequiredFlag, const ::objectIdentifier& lotID, const char* requiredCassetteCategory, ::CORBA::Boolean backupProcessingFlag, const char* subLotType, ::CORBA::Boolean deleteLotFlag, const ::objectIdentifier& holdReasonCodeID, ::CORBA::Boolean sorterJobCreationCheckFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInq__090()";
        retVal =        PPTManager_i::txLotListInq__090 ( strLotListInqResult, strObjCommonIn, bankID, lotStatus, lotType, productID, orderNumber, customerCode, manufacturingLayerID, routeID, operationNumber, bankInRequiredFlag, lotID, requiredCassetteCategory, backupProcessingFlag, subLotType, deleteLotFlag, holdReasonCodeID, sorterJobCreationCheckFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatNextLotListInq__090 */
virtual ::CORBA::Long  txWhatNextLotListInq__090 (::pptWhatNextLotListInqResult__090& strWhatNextLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* selectCriteria, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatNextLotListInq__090()";
        retVal =        PPTManager_i::txWhatNextLotListInq__090 ( strWhatNextLotListInqResult, strObjCommonIn, equipmentID, selectCriteria, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteListInq__090 */
virtual ::CORBA::Long  txCassetteListInq__090 (::pptCassetteListInqResult__090& strCassetteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* cassetteCategory, ::CORBA::Boolean emptyFlag, const ::objectIdentifier& stockerID, const ::objectIdentifier& cassetteID, const char* cassetteStatus, ::CORBA::Long maxRetrieveCount, ::CORBA::Boolean sorterJobCreationCheckFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteListInq__090()";
        retVal =        PPTManager_i::txCassetteListInq__090 ( strCassetteListInqResult, strObjCommonIn, cassetteCategory, emptyFlag, stockerID, cassetteID, cassetteStatus, maxRetrieveCount, sorterJobCreationCheckFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteStatusInq__090 */
virtual ::CORBA::Long  txCassetteStatusInq__090 (::pptCassetteStatusInqResult__090& strCassetteStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteStatusInq__090()";
        retVal =        PPTManager_i::txCassetteStatusInq__090 ( strCassetteStatusInqResult, strObjCommonIn, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txArrivalCarrierCancelForInternalBufferReq__090 */
virtual ::CORBA::Long  txArrivalCarrierCancelForInternalBufferReq__090 (::pptArrivalCarrierCancelForInternalBufferReqResult__090& strArrivalCarrierCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGroupID, const ::pptNPWXferCassetteSequence& strNPWXferCassette, ::CORBA::Boolean notifyToTCSFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090()";
        retVal =        PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090 ( strArrivalCarrierCancelForInternalBufferReqResult, strObjCommonIn, equipmentID, portGroupID, strNPWXferCassette, notifyToTCSFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txArrivalCarrierCancelReq__090 */
virtual ::CORBA::Long  txArrivalCarrierCancelReq__090 (::pptArrivalCarrierCancelReqResult__090& strArrivalCarrierCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* portGroupID, const ::pptNPWXferCassetteSequence& strNPWXferCassette, ::CORBA::Boolean notifyToTCSFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txArrivalCarrierCancelReq__090()";
        retVal =        PPTManager_i::txArrivalCarrierCancelReq__090 ( strArrivalCarrierCancelReqResult, strObjCommonIn, equipmentID, portGroupID, strNPWXferCassette, notifyToTCSFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txForceOpeLocateReq */
virtual ::CORBA::Long  txForceOpeLocateReq (::pptForceOpeLocateReqResult& strForceOpeLocateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptForceOpeLocateReqInParm& strForceOpeLocateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txForceOpeLocateReq()";
        retVal =        PPTManager_i::txForceOpeLocateReq ( strForceOpeLocateReqResult, strObjCommonIn, strForceOpeLocateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessResourceWaferPositionRpt */
virtual ::CORBA::Long  txProcessResourceWaferPositionRpt (::pptProcessResourceWaferPositionRptResult& strProcessResourceWaferPositionRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptProcessResourceWaferPositionRptInParm& strProcessResourceWaferPositionRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessResourceWaferPositionRpt()";
        retVal =        PPTManager_i::txProcessResourceWaferPositionRpt ( strProcessResourceWaferPositionRptResult, strObjCommonIn, strProcessResourceWaferPositionRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUserDefinedDataAttributeInfoInq */
virtual ::CORBA::Long  txUserDefinedDataAttributeInfoInq (::pptUserDefinedDataAttributeInfoInqResult& strUserDefinedDataAttributeInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUserDefinedDataAttributeInfoInqInParm& strUserDefinedDataAttributeInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUserDefinedDataAttributeInfoInq()";
        retVal =        PPTManager_i::txUserDefinedDataAttributeInfoInq ( strUserDefinedDataAttributeInfoInqResult, strObjCommonIn, strUserDefinedDataAttributeInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteBaseInfoListInq */
virtual ::CORBA::Long  txCassetteBaseInfoListInq (::pptCassetteBaseInfoListInqResult& strCassetteBaseInfoListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCassetteBaseInfoListInqInParm& strCassetteBaseInfoListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteBaseInfoListInq()";
        retVal =        PPTManager_i::txCassetteBaseInfoListInq ( strCassetteBaseInfoListInqResult, strObjCommonIn, strCassetteBaseInfoListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodBaseInfoListInq */
virtual ::CORBA::Long  txReticlePodBaseInfoListInq (::pptReticlePodBaseInfoListInqResult& strReticlePodBaseInfoListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReticlePodBaseInfoListInqInParm& strReticlePodBaseInfoListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodBaseInfoListInq()";
        retVal =        PPTManager_i::txReticlePodBaseInfoListInq ( strReticlePodBaseInfoListInqResult, strObjCommonIn, strReticlePodBaseInfoListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableRegistReq__090 */
virtual ::CORBA::Long  txDurableRegistReq__090 (::pptDurableRegistReqResult& strDurableRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean updateFlag, const char* className, const ::pptDurableAttribute__090& strDurableAttribute, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableRegistReq__090()";
        retVal =        PPTManager_i::txDurableRegistReq__090 ( strDurableRegistReqResult, strObjCommonIn, updateFlag, className, strDurableAttribute, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassettePostProcessForceDeleteReq */
virtual ::CORBA::Long  txLotCassettePostProcessForceDeleteReq (::pptLotCassettePostProcessForceDeleteReqResult& strLotCassettePostProcessForceDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotCassettePostProcessForceDeleteReqInParm& strLotCassettePostProcessForceDeleteReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassettePostProcessForceDeleteReq()";
        retVal =        PPTManager_i::txLotCassettePostProcessForceDeleteReq ( strLotCassettePostProcessForceDeleteReqResult, strObjCommonIn, strLotCassettePostProcessForceDeleteReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleRetrieveJobCreateReq */
virtual ::CORBA::Long  txReticleRetrieveJobCreateReq (::pptReticleRetrieveJobCreateReqResult& strReticleRetrieveJobCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, const ::pptMoveReticlesSequence& strMoveReticlesList, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleRetrieveJobCreateReq()";
        retVal =        PPTManager_i::txReticleRetrieveJobCreateReq ( strReticleRetrieveJobCreateReqResult, strObjCommonIn, machineID, portID, reticlePodID, strMoveReticlesList, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodUnloadingRpt */
virtual ::CORBA::Long  txReticlePodUnloadingRpt (::pptReticlePodUnloadingRptResult& strReticlePodUnloadingRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& reticlePodPortID, const ::objectIdentifier& bareReticleStockerID, const ::objectIdentifier& resourceID, const ::objectIdentifier& reticlePodID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodUnloadingRpt()";
        retVal =        PPTManager_i::txReticlePodUnloadingRpt ( strReticlePodUnloadingRptResult, strObjCommonIn, equipmentID, reticlePodPortID, bareReticleStockerID, resourceID, reticlePodID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodUnclampJobCreateReq */
virtual ::CORBA::Long  txReticlePodUnclampJobCreateReq (::pptReticlePodUnclampJobCreateReqResult& strReticlePodUnclampJobCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodUnclampJobCreateReq()";
        retVal =        PPTManager_i::txReticlePodUnclampJobCreateReq ( strReticlePodUnclampJobCreateReqResult, strObjCommonIn, machineID, portID, reticlePodID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodUnclampAndXferJobCreateReq */
virtual ::CORBA::Long  txReticlePodUnclampAndXferJobCreateReq (::pptReticlePodUnclampAndXferJobCreateReqResult& strReticlePodUnclampAndXferJobCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticlePodID, const ::objectIdentifier& fromMachineID, const ::objectIdentifier& fromPortID, const ::objectIdentifier& toMachineID, const ::objectIdentifier& toPortID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodUnclampAndXferJobCreateReq()";
        retVal =        PPTManager_i::txReticlePodUnclampAndXferJobCreateReq ( strReticlePodUnclampAndXferJobCreateReqResult, strObjCommonIn, reticlePodID, fromMachineID, fromPortID, toMachineID, toPortID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodOfflineUnloadingReq */
virtual ::CORBA::Long  txReticlePodOfflineUnloadingReq (::pptReticlePodOfflineUnloadingReqResult& strReticlePodOfflineUnloadingReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, ::CORBA::Boolean bForceUnloadFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodOfflineUnloadingReq()";
        retVal =        PPTManager_i::txReticlePodOfflineUnloadingReq ( strReticlePodOfflineUnloadingReqResult, strObjCommonIn, machineID, portID, reticlePodID, bForceUnloadFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleOfflineRetrieveReq */
virtual ::CORBA::Long  txReticleOfflineRetrieveReq (::pptReticleOfflineRetrieveReqResult& strReticleOfflineRetrieveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, const ::pptReticleRetrieveResultSequence& strReticleRetrieveResult, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleOfflineRetrieveReq()";
        retVal =        PPTManager_i::txReticleOfflineRetrieveReq ( strReticleOfflineRetrieveReqResult, strObjCommonIn, machineID, portID, reticlePodID, strReticleRetrieveResult, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatReticleActionListInq */
virtual ::CORBA::Long  txWhatReticleActionListInq (::pptWhatReticleActionListInqResult& strWhatReticleActionListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* dispatchStationID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatReticleActionListInq()";
        retVal =        PPTManager_i::txWhatReticleActionListInq ( strWhatReticleActionListInqResult, strObjCommonIn, dispatchStationID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleRetrieveRpt */
virtual ::CORBA::Long  txReticleRetrieveRpt (::pptReticleRetrieveRptResult& strReticleRetrieveRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& reticlePodPortID, const ::objectIdentifier& stockerID, const ::objectIdentifier& resourceID, const ::objectIdentifier& reticlePodID, const ::pptReticleRetrieveResultSequence& strReticleRetrieveResult, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleRetrieveRpt()";
        retVal =        PPTManager_i::txReticleRetrieveRpt ( strReticleRetrieveRptResult, strObjCommonIn, equipmentID, reticlePodPortID, stockerID, resourceID, reticlePodID, strReticleRetrieveResult, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleRetrieveReq */
virtual ::CORBA::Long  txReticleRetrieveReq (::pptReticleRetrieveReqResult& strReticleRetrieveReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* reticleComponentJobID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& reticlePodPortID, const ::objectIdentifier& stockerID, const ::objectIdentifier& resourceID, const ::objectIdentifier& reticlePodID, const ::pptMoveReticlesSequence& strMoveReticlesSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleRetrieveReq()";
        retVal =        PPTManager_i::txReticleRetrieveReq ( strReticleRetrieveReqResult, strObjCommonIn, reticleDispatchJobID, reticleComponentJobID, equipmentID, reticlePodPortID, stockerID, resourceID, reticlePodID, strMoveReticlesSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodXferReq */
virtual ::CORBA::Long  txReticlePodXferReq (::pptReticlePodXferReqResult& strReticlePodXferReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* reticleComponentJobID, const ::objectIdentifier& reticlePodID, const ::objectIdentifier& fromMachineID, const ::objectIdentifier& fromPortID, const ::objectIdentifier& toMachineID, const ::objectIdentifier& toPortID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodXferReq()";
        retVal =        PPTManager_i::txReticlePodXferReq ( strReticlePodXferReqResult, strObjCommonIn, reticleDispatchJobID, reticleComponentJobID, reticlePodID, fromMachineID, fromPortID, toMachineID, toPortID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodXferJobDeleteReq */
virtual ::CORBA::Long  txReticlePodXferJobDeleteReq (::pptReticlePodXferJobDeleteReqResult& strReticlePodXferJobDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* jobID, const ::pptReticlePodJobSequence& strReticlePodJob, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodXferJobDeleteReq()";
        retVal =        PPTManager_i::txReticlePodXferJobDeleteReq ( strReticlePodXferJobDeleteReqResult, strObjCommonIn, jobID, strReticlePodJob, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodXferJobCreateReq */
virtual ::CORBA::Long  txReticlePodXferJobCreateReq (::pptReticlePodXferJobCreateReqResult& strReticlePodXferJobCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticlePodID, const ::objectIdentifier& fromMachineID, const ::objectIdentifier& fromPortID, const ::objectIdentifier& toMachineID, const ::objectIdentifier& toPortID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodXferJobCreateReq()";
        retVal =        PPTManager_i::txReticlePodXferJobCreateReq ( strReticlePodXferJobCreateReqResult, strObjCommonIn, reticlePodID, fromMachineID, fromPortID, toMachineID, toPortID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodXferJobCompRpt */
virtual ::CORBA::Long  txReticlePodXferJobCompRpt (::pptReticlePodXferJobCompRptResult& strReticlePodXferJobCompRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReticlePodXferJobCompInfoSequence& strReticlePodXferJobCompInfo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodXferJobCompRpt()";
        retVal =        PPTManager_i::txReticlePodXferJobCompRpt ( strReticlePodXferJobCompRptResult, strObjCommonIn, strReticlePodXferJobCompInfo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodUnclampRpt */
virtual ::CORBA::Long  txReticlePodUnclampRpt (::pptReticlePodUnclampRptResult& strReticlePodUnclampRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, ::CORBA::Boolean bSuccessFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodUnclampRpt()";
        retVal =        PPTManager_i::txReticlePodUnclampRpt ( strReticlePodUnclampRptResult, strObjCommonIn, machineID, portID, reticlePodID, bSuccessFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodUnclampReq */
virtual ::CORBA::Long  txReticlePodUnclampReq (::pptReticlePodUnclampReqResult& strReticlePodUnclampReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* reticleComponentJobID, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodUnclampReq()";
        retVal =        PPTManager_i::txReticlePodUnclampReq ( strReticlePodUnclampReqResult, strObjCommonIn, reticleDispatchJobID, reticleComponentJobID, machineID, portID, reticlePodID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodInventoryReq */
virtual ::CORBA::Long  txReticlePodInventoryReq (::pptReticlePodInventoryReqResult& strReticlePodInventoryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodInventoryReq()";
        retVal =        PPTManager_i::txReticlePodInventoryReq ( strReticlePodInventoryReqResult, strObjCommonIn, equipmentID, stockerID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBareReticleStockerInfoInq */
virtual ::CORBA::Long  txBareReticleStockerInfoInq (::pptBareReticleStockerInfoInqResult& strBareReticleStockerInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBareReticleStockerInfoInq()";
        retVal =        PPTManager_i::txBareReticleStockerInfoInq ( strBareReticleStockerInfoInqResult, strObjCommonIn, stockerID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBareReticleStockerOnlineModeChangeReq */
virtual ::CORBA::Long  txBareReticleStockerOnlineModeChangeReq (::pptBareReticleStockerOnlineModeChangeReqResult& strBareReticleStockerOnlineModeChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bareReticleStockerID, const char* newOnlineMode, ::CORBA::Boolean notifyToTCSFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBareReticleStockerOnlineModeChangeReq()";
        retVal =        PPTManager_i::txBareReticleStockerOnlineModeChangeReq ( strBareReticleStockerOnlineModeChangeReqResult, strObjCommonIn, bareReticleStockerID, newOnlineMode, notifyToTCSFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpRSPPortAccessModeChangeReq */
virtual ::CORBA::Long  txEqpRSPPortAccessModeChangeReq (::pptEqpRSPPortAccessModeChangeReqResult& strEqpRSPPortAccessModeChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& reticlePodPortID, const char* newAccessMode, ::CORBA::Boolean notifyToTCSFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpRSPPortAccessModeChangeReq()";
        retVal =        PPTManager_i::txEqpRSPPortAccessModeChangeReq ( strEqpRSPPortAccessModeChangeReqResult, strObjCommonIn, equipmentID, reticlePodPortID, newAccessMode, notifyToTCSFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpRSPPortStatusChangeRpt */
virtual ::CORBA::Long  txEqpRSPPortStatusChangeRpt (::pptEqpRSPPortStatusChangeRptResult& strEqpRSPPortStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::pptEqpRSPPortEventOnTCSSequence& strEqpRSPPortEventOnTCS, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpRSPPortStatusChangeRpt()";
        retVal =        PPTManager_i::txEqpRSPPortStatusChangeRpt ( strEqpRSPPortStatusChangeRptResult, strObjCommonIn, equipmentID, strEqpRSPPortEventOnTCS, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleActionReleaseErrorReq */
virtual ::CORBA::Long  txReticleActionReleaseErrorReq (::pptReticleActionReleaseErrorReqResult& strReticleActionReleaseErrorReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const ::objectIdentifier& machineID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleActionReleaseErrorReq()";
        retVal =        PPTManager_i::txReticleActionReleaseErrorReq ( strReticleActionReleaseErrorReqResult, strObjCommonIn, reticleDispatchJobID, machineID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleActionReleaseReq */
virtual ::CORBA::Long  txReticleActionReleaseReq (::pptReticleActionReleaseReqResult& strReticleActionReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleActionReleaseReq()";
        retVal =        PPTManager_i::txReticleActionReleaseReq ( strReticleActionReleaseReqResult, strObjCommonIn, reticleDispatchJobID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleComponentJobListInq */
virtual ::CORBA::Long  txReticleComponentJobListInq (::pptReticleComponentJobListInqResult& strReticleComponentJobListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleComponentJobListInq()";
        retVal =        PPTManager_i::txReticleComponentJobListInq ( strReticleComponentJobListInqResult, strObjCommonIn, reticleDispatchJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleComponentJobRetryReq */
virtual ::CORBA::Long  txReticleComponentJobRetryReq (::pptReticleComponentJobRetryReqResult& strReticleComponentJobRetryReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* reticleComponentJobID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleComponentJobRetryReq()";
        retVal =        PPTManager_i::txReticleComponentJobRetryReq ( strReticleComponentJobRetryReqResult, strObjCommonIn, reticleDispatchJobID, reticleComponentJobID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleComponentJobSkipReq */
virtual ::CORBA::Long  txReticleComponentJobSkipReq (::pptReticleComponentJobSkipReqResult& strReticleComponentJobSkipReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* reticleComponentJobID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleComponentJobSkipReq()";
        retVal =        PPTManager_i::txReticleComponentJobSkipReq ( strReticleComponentJobSkipReqResult, strObjCommonIn, reticleDispatchJobID, reticleComponentJobID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleDispatchAndComponentJobStatusChangeReq */
virtual ::CORBA::Long  txReticleDispatchAndComponentJobStatusChangeReq (::pptReticleDispatchAndComponentJobStatusChangeReqResult& strReticleDispatchAndComponentJobStatusChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRetCode& stxResult, ::CORBA::Boolean isRequest, const char* RDJ_ID, const char* RCJ_ID, const char* jobName, const ::objectIdentifier& reticleID, const ::objectIdentifier& reticlePodID, const ::objectIdentifier& fromMachineID, const ::objectIdentifier& fromPortID, const ::objectIdentifier& toMachineId, const ::objectIdentifier& toPortID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleDispatchAndComponentJobStatusChangeReq()";
        retVal =        PPTManager_i::txReticleDispatchAndComponentJobStatusChangeReq ( strReticleDispatchAndComponentJobStatusChangeReqResult, strObjCommonIn, stxResult, isRequest, RDJ_ID, RCJ_ID, jobName, reticleID, reticlePodID, fromMachineID, fromPortID, toMachineId, toPortID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleDispatchJobCancelReq */
virtual ::CORBA::Long  txReticleDispatchJobCancelReq (::pptReticleDispatchJobCancelReqResult& strReticleDispatchJobCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleDispatchJobCancelReq()";
        retVal =        PPTManager_i::txReticleDispatchJobCancelReq ( strReticleDispatchJobCancelReqResult, strObjCommonIn, reticleDispatchJobID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleDispatchJobDeleteReq */
virtual ::CORBA::Long  txReticleDispatchJobDeleteReq (::pptReticleDispatchJobDeleteReqResult& strReticleDispatchJobDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleDispatchJobDeleteReq()";
        retVal =        PPTManager_i::txReticleDispatchJobDeleteReq ( strReticleDispatchJobDeleteReqResult, strObjCommonIn, reticleDispatchJobID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleDispatchJobInsertReq */
virtual ::CORBA::Long  txReticleDispatchJobInsertReq (::pptReticleDispatchJobInsertReqResult& strReticleDispatchJobInsertReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReticleDispatchJob& strReticleDispatchJob, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleDispatchJobInsertReq()";
        retVal =        PPTManager_i::txReticleDispatchJobInsertReq ( strReticleDispatchJobInsertReqResult, strObjCommonIn, strReticleDispatchJob, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleDispatchJobListInq */
virtual ::CORBA::Long  txReticleDispatchJobListInq (::pptReticleDispatchJobListInqResult& strReticleDispatchJobListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleDispatchJobListInq()";
        retVal =        PPTManager_i::txReticleDispatchJobListInq ( strReticleDispatchJobListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleOfflineStoreReq */
virtual ::CORBA::Long  txReticleOfflineStoreReq (::pptReticleOfflineStoreReqResult& strReticleOfflineStoreReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, const ::pptReticleStoreResultSequence& strReticleStoreResultSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleOfflineStoreReq()";
        retVal =        PPTManager_i::txReticleOfflineStoreReq ( strReticleOfflineStoreReqResult, strObjCommonIn, machineID, portID, reticlePodID, strReticleStoreResultSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodLoadingRpt */
virtual ::CORBA::Long  txReticlePodLoadingRpt (::pptReticlePodLoadingRptResult& strReticlePodLoadingRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& reticlePodPortID, const ::objectIdentifier& bareReticleStockerID, const ::objectIdentifier& resourceID, const ::objectIdentifier& reticlePodID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodLoadingRpt()";
        retVal =        PPTManager_i::txReticlePodLoadingRpt ( strReticlePodLoadingRptResult, strObjCommonIn, equipmentID, reticlePodPortID, bareReticleStockerID, resourceID, reticlePodID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodOfflineLoadingReq */
virtual ::CORBA::Long  txReticlePodOfflineLoadingReq (::pptReticlePodOfflineLoadingReqResult& strReticlePodOfflineLoadingReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, ::CORBA::Boolean bForceLoadFlag, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodOfflineLoadingReq()";
        retVal =        PPTManager_i::txReticlePodOfflineLoadingReq ( strReticlePodOfflineLoadingReqResult, strObjCommonIn, machineID, portID, reticlePodID, bForceLoadFlag, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodStockerInfoInq */
virtual ::CORBA::Long  txReticlePodStockerInfoInq (::pptReticlePodStockerInfoInqResult& strReticlePodStockerInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodStockerInfoInq()";
        retVal =        PPTManager_i::txReticlePodStockerInfoInq ( strReticlePodStockerInfoInqResult, strObjCommonIn, stockerID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStoreJobCreateReq */
virtual ::CORBA::Long  txReticleStoreJobCreateReq (::pptReticleStoreJobCreateReqResult& strReticleStoreJobCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const ::objectIdentifier& reticlePodID, const ::pptMoveReticlesSequence& strMoveReticlesSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStoreJobCreateReq()";
        retVal =        PPTManager_i::txReticleStoreJobCreateReq ( strReticleStoreJobCreateReqResult, strObjCommonIn, machineID, portID, reticlePodID, strMoveReticlesSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStoreReq */
virtual ::CORBA::Long  txReticleStoreReq (::pptReticleStoreReqResult& strReticleStoreReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* reticleDispatchJobID, const char* reticleComponentJobID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& reticlePodPortID, const ::objectIdentifier& stockerID, const ::objectIdentifier& resourceID, const ::objectIdentifier& reticlePodID, const ::pptMoveReticlesSequence& strMoveReticlesSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStoreReq()";
        retVal =        PPTManager_i::txReticleStoreReq ( strReticleStoreReqResult, strObjCommonIn, reticleDispatchJobID, reticleComponentJobID, equipmentID, reticlePodPortID, stockerID, resourceID, reticlePodID, strMoveReticlesSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStoreRpt */
virtual ::CORBA::Long  txReticleStoreRpt (::pptReticleStoreRptResult& strReticleStoreRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& reticlePodPortID, const ::objectIdentifier& stockerID, const ::objectIdentifier& resourceID, const ::objectIdentifier& reticlePodID, const ::pptReticleStoreResultSequence& strReticleStoreResult, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStoreRpt()";
        retVal =        PPTManager_i::txReticleStoreRpt ( strReticleStoreRptResult, strObjCommonIn, equipmentID, reticlePodPortID, stockerID, resourceID, reticlePodID, strReticleStoreResult, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleXferJobCreateReq */
virtual ::CORBA::Long  txReticleXferJobCreateReq (::pptReticleXferJobCreateReqResult& strReticleXferJobCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const ::objectIdentifier& reticlePodID, const ::objectIdentifier& toMachineID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleXferJobCreateReq()";
        retVal =        PPTManager_i::txReticleXferJobCreateReq ( strReticleXferJobCreateReqResult, strObjCommonIn, reticleID, reticlePodID, toMachineID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatReticleActionListReq */
virtual ::CORBA::Long  txWhatReticleActionListReq (::pptWhatReticleActionListReqResult& strWhatReticleActionListReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* dispatchStationID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatReticleActionListReq()";
        retVal =        PPTManager_i::txWhatReticleActionListReq ( strWhatReticleActionListReqResult, strObjCommonIn, dispatchStationID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatReticleRetrieveInq */
virtual ::CORBA::Long  txWhatReticleRetrieveInq (::pptWhatReticleRetrieveInqResult& strWhatReticleRetrieveInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatReticleRetrieveInq()";
        retVal =        PPTManager_i::txWhatReticleRetrieveInq ( strWhatReticleRetrieveInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodXferJobListInq */
virtual ::CORBA::Long  txReticlePodXferJobListInq (::pptReticlePodXferJobListInqResult& strReticlePodXferJobListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticlePodID, const ::objectIdentifier& toMachineID, const ::objectIdentifier& toStockerID, const ::objectIdentifier& fromMachineID, const ::objectIdentifier& fromStockerID, ::CORBA::Boolean detailFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodXferJobListInq()";
        retVal =        PPTManager_i::txReticlePodXferJobListInq ( strReticlePodXferJobListInqResult, strObjCommonIn, reticlePodID, toMachineID, toStockerID, fromMachineID, fromStockerID, detailFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhereNextForReticlePodInq */
virtual ::CORBA::Long  txWhereNextForReticlePodInq (::pptWhereNextForReticlePodInqResult& strWhereNextForReticlePodInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticlePodID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhereNextForReticlePodInq()";
        retVal =        PPTManager_i::txWhereNextForReticlePodInq ( strWhereNextForReticlePodInqResult, strObjCommonIn, reticlePodID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoInq__090 */
virtual ::CORBA::Long  txEqpInfoInq__090 (::pptEqpInfoInqResult__090& strEqpInfoInqResult__090, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Boolean requestFlagForRSPPortInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoInq__090()";
        retVal =        PPTManager_i::txEqpInfoInq__090 ( strEqpInfoInqResult__090, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, requestFlagForRSPPortInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoForInternalBufferInq__090 */
virtual ::CORBA::Long  txEqpInfoForInternalBufferInq__090 (::pptEqpInfoForInternalBufferInqResult__090& strEqpInfoForInternalBufferInqResult__090, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForInternalBufferInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Boolean requestFlagForRSPPortInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoForInternalBufferInq__090()";
        retVal =        PPTManager_i::txEqpInfoForInternalBufferInq__090 ( strEqpInfoForInternalBufferInqResult__090, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForInternalBufferInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, requestFlagForRSPPortInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStatusInq__090 */
virtual ::CORBA::Long  txReticleStatusInq__090 (::pptReticleStatusInqResult__090& strReticleStatusInqResult__090, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStatusInq__090()";
        retVal =        PPTManager_i::txReticleStatusInq__090 ( strReticleStatusInqResult__090, strObjCommonIn, reticleID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodStatusInq__090 */
virtual ::CORBA::Long  txReticlePodStatusInq__090 (::pptReticlePodStatusInqResult__090& strReticlePodStatusInqResult__090, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticlePodID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodStatusInq__090()";
        retVal =        PPTManager_i::txReticlePodStatusInq__090 ( strReticlePodStatusInqResult__090, strObjCommonIn, reticlePodID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRSPXferStatusChangeRpt */
virtual ::CORBA::Long  txRSPXferStatusChangeRpt (::pptRSPXferStatusChangeRptResult& strRSPXferStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticlePodID, const char* xferStatus, ::CORBA::Boolean ManualInFlag, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRSPXferStatusChangeRpt()";
        retVal =        PPTManager_i::txRSPXferStatusChangeRpt ( strRSPXferStatusChangeRptResult, strObjCommonIn, reticlePodID, xferStatus, ManualInFlag, machineID, portID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodInventoryRpt__090 */
virtual ::CORBA::Long  txReticlePodInventoryRpt__090 (::pptReticlePodInventoryRptResult__090& strReticlePodInventoryRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptInventoryReticlePodInfoSequence& strInventoryReticlePodInfo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodInventoryRpt__090()";
        retVal =        PPTManager_i::txReticlePodInventoryRpt__090 ( strReticlePodInventoryRptResult, strObjCommonIn, requestUserID, stockerID, equipmentID, strInventoryReticlePodInfo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleInventoryReq__090 */
virtual ::CORBA::Long  txReticleInventoryReq__090 (::pptReticleInventoryReqResult__090& strReticleInventoryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleInventoryReq__090()";
        retVal =        PPTManager_i::txReticleInventoryReq__090 ( strReticleInventoryReqResult, strObjCommonIn, stockerID, equipmentID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleInventoryRpt__090 */
virtual ::CORBA::Long  txReticleInventoryRpt__090 (::pptReticleInventoryRptResult__090& strReticleInventoryRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptInventoryReticleInfoSequence& strInventoryReticleInfo, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleInventoryRpt__090()";
        retVal =        PPTManager_i::txReticleInventoryRpt__090 ( strReticleInventoryRptResult, strObjCommonIn, stockerID, equipmentID, strInventoryReticleInfo, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAsyncReticleXferJobCreateReq */
virtual ::CORBA::Long  txAsyncReticleXferJobCreateReq (::pptAsyncReticleXferJobCreateReqResult& strAsyncReticleXferJobCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const ::objectIdentifier& reticlePodID, const ::objectIdentifier& toMachineID, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAsyncReticleXferJobCreateReq()";
        retVal =        PPTManager_i::txAsyncReticleXferJobCreateReq ( strAsyncReticleXferJobCreateReqResult, strObjCommonIn, reticleID, reticlePodID, toMachineID, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatReticlePodForReticleXferInq */
virtual ::CORBA::Long  txWhatReticlePodForReticleXferInq (::pptWhatReticlePodForReticleXferInqResult& strWhatReticlePodForReticleXferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatReticlePodForReticleXferInq()";
        retVal =        PPTManager_i::txWhatReticlePodForReticleXferInq ( strWhatReticlePodForReticleXferInqResult, strObjCommonIn, reticleID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpFlowBatchMaxCountChangeReq */
virtual ::CORBA::Long  txEqpFlowBatchMaxCountChangeReq (::pptEqpFlowBatchMaxCountChangeReqResult& strEqpFlowBatchMaxCountChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Long flowBatchMaxCount, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpFlowBatchMaxCountChangeReq()";
        retVal =        PPTManager_i::txEqpFlowBatchMaxCountChangeReq ( strEqpFlowBatchMaxCountChangeReqResult, strObjCommonIn, equipmentID, flowBatchMaxCount, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFlowBatchCandidateInq__090 */
virtual ::CORBA::Long  txFlowBatchCandidateInq__090 (::pptFlowBatchCandidateInqResult__090& strFlowBatchCandidateInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFlowBatchCandidateInq__090()";
        retVal =        PPTManager_i::txFlowBatchCandidateInq__090 ( strFlowBatchCandidateInqResult, strObjCommonIn, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFlowBatchInq__090 */
virtual ::CORBA::Long  txFlowBatchInq__090 (::pptFlowBatchInqResult__090& strFlowBatchInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& flowBatchID, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFlowBatchInq__090()";
        retVal =        PPTManager_i::txFlowBatchInq__090 ( strFlowBatchInqResult, strObjCommonIn, flowBatchID, lotID, equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteTakeOutInReq */
virtual ::CORBA::Long  txLotCassetteTakeOutInReq (::pptLotCassetteTakeOutInReqResult& strLotCassetteTakeOutInReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotCassetteTakeOutInReqInParm& strLotCassetteTakeOutInReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteTakeOutInReq()";
        retVal =        PPTManager_i::txLotCassetteTakeOutInReq ( strLotCassetteTakeOutInReqResult, strObjCommonIn, strLotCassetteTakeOutInReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStartLotsReservationForTakeOutInReq */
virtual ::CORBA::Long  txStartLotsReservationForTakeOutInReq (::pptStartLotsReservationForTakeOutInReqResult& strStartLotsReservationForTakeOutInReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptStartLotsReservationForTakeOutInReqInParm& strStartLotsReservationForTakeOutInReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStartLotsReservationForTakeOutInReq()";
        retVal =        PPTManager_i::txStartLotsReservationForTakeOutInReq ( strStartLotsReservationForTakeOutInReqResult, strObjCommonIn, strStartLotsReservationForTakeOutInReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoInq__100 */
virtual ::CORBA::Long  txEqpInfoInq__100 (::pptEqpInfoInqResult__100& strEqpInfoInqResult__100, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Boolean requestFlagForRSPPortInfo, ::CORBA::Boolean requestFlagForEqpContainerInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoInq__100()";
        retVal =        PPTManager_i::txEqpInfoInq__100 ( strEqpInfoInqResult__100, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, requestFlagForRSPPortInfo, requestFlagForEqpContainerInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessJobMapInfoRpt */
virtual ::CORBA::Long  txProcessJobMapInfoRpt (::pptProcessJobMapInfoRptResult& strProcessJobMapInfoRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptProcessJobMapInfoRptInParm& strProcessJobMapInfoRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessJobMapInfoRpt()";
        retVal =        PPTManager_i::txProcessJobMapInfoRpt ( strProcessJobMapInfoRptResult, strObjCommonIn, strProcessJobMapInfoRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMProcessJobStatusRpt */
virtual ::CORBA::Long  txSLMProcessJobStatusRpt (::pptSLMProcessJobStatusRptResult& strSLMProcessJobStatusRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMProcessJobStatusRptInParm& strSLMProcessJobStatusRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMProcessJobStatusRpt()";
        retVal =        PPTManager_i::txSLMProcessJobStatusRpt ( strSLMProcessJobStatusRptResult, strObjCommonIn, strSLMProcessJobStatusRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEstimatedProcessJobEndTimeRpt */
virtual ::CORBA::Long  txEstimatedProcessJobEndTimeRpt (::pptEstimatedProcessJobEndTimeRptResult& strEstimatedProcessJobEndTimeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEstimatedProcessJobEndTimeRptInParm& strEstimatedProcessJobEndTimeRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEstimatedProcessJobEndTimeRpt()";
        retVal =        PPTManager_i::txEstimatedProcessJobEndTimeRpt ( strEstimatedProcessJobEndTimeRptResult, strObjCommonIn, strEstimatedProcessJobEndTimeRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMWaferStoreRpt */
virtual ::CORBA::Long  txSLMWaferStoreRpt (::pptSLMWaferStoreRptResult& strSLMWaferStoreRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMWaferStoreRptInParm& strSLMWaferStoreRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMWaferStoreRpt()";
        retVal =        PPTManager_i::txSLMWaferStoreRpt ( strSLMWaferStoreRptResult, strObjCommonIn, strSLMWaferStoreRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMWaferRetrieveRpt */
virtual ::CORBA::Long  txSLMWaferRetrieveRpt (::pptSLMWaferRetrieveRptResult& strSLMWaferRetrieveRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMWaferRetrieveRptInParm& strSLMWaferRetrieveRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMWaferRetrieveRpt()";
        retVal =        PPTManager_i::txSLMWaferRetrieveRpt ( strSLMWaferRetrieveRptResult, strObjCommonIn, strSLMWaferRetrieveRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMCassetteDetachFromCJReq */
virtual ::CORBA::Long  txSLMCassetteDetachFromCJReq (::pptSLMCassetteDetachFromCJReqResult& strSLMCassetteDetachFromCJReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMCassetteDetachFromCJReqInParm& strSLMCassetteDetachFromCJReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMCassetteDetachFromCJReq()";
        retVal =        PPTManager_i::txSLMCassetteDetachFromCJReq ( strSLMCassetteDetachFromCJReqResult, strObjCommonIn, strSLMCassetteDetachFromCJReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMCassetteDeliveryReq */
virtual ::CORBA::Long  txSLMCassetteDeliveryReq (::pptSLMCassetteDeliveryReqResult& strSLMCassetteDeliveryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMCassetteDeliveryReqInParm& strSLMCassetteDeliveryReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMCassetteDeliveryReq()";
        retVal =        PPTManager_i::txSLMCassetteDeliveryReq ( strSLMCassetteDeliveryReqResult, strObjCommonIn, strSLMCassetteDeliveryReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMStartLotsReservationReq */
virtual ::CORBA::Long  txSLMStartLotsReservationReq (::pptSLMStartLotsReservationReqResult& strSLMStartLotsReservationReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMStartLotsReservationReqInParm& strSLMStartLotsReservationReqInParm, const char* claimMemo, char*& APCIFControlStatus, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMStartLotsReservationReq()";
        retVal =        PPTManager_i::txSLMStartLotsReservationReq ( strSLMStartLotsReservationReqResult, strObjCommonIn, strSLMStartLotsReservationReqInParm, claimMemo, APCIFControlStatus, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMCandidateCassetteForRetrievingInq */
virtual ::CORBA::Long  txSLMCandidateCassetteForRetrievingInq (::pptSLMCandidateCassetteForRetrievingInqResult& strSLMCandidateCassetteForRetrievingInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMCandidateCassetteForRetrievingInqInParm& strSLMCandidateCassetteForRetrievingInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMCandidateCassetteForRetrievingInq()";
        retVal =        PPTManager_i::txSLMCandidateCassetteForRetrievingInq ( strSLMCandidateCassetteForRetrievingInqResult, strObjCommonIn, strSLMCandidateCassetteForRetrievingInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpListInq__100 */
virtual ::CORBA::Long  txEqpListInq__100 (::pptEqpListInqResult__100& strEqpListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpListInqInParm& strEqpListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpListInq__100()";
        retVal =        PPTManager_i::txEqpListInq__100 ( strEqpListInqResult, strObjCommonIn, strEqpListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStockerListInq__100 */
virtual ::CORBA::Long  txStockerListInq__100 (::pptStockerListInqResult__100& strStockerListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* stockerType, ::CORBA::Boolean availFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStockerListInq__100()";
        retVal =        PPTManager_i::txStockerListInq__100 ( strStockerListInqResult, strObjCommonIn, stockerType, availFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStockerInfoInq__100 */
virtual ::CORBA::Long  txStockerInfoInq__100 (::pptStockerInfoInqResult__100& strStockerInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& machineID, ::CORBA::Boolean detailFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStockerInfoInq__100()";
        retVal =        PPTManager_i::txStockerInfoInq__100 ( strStockerInfoInqResult, strObjCommonIn, machineID, detailFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMSwitchUpdateReq */
virtual ::CORBA::Long  txSLMSwitchUpdateReq (::pptSLMSwitchUpdateReqResult& strSLMSwitchUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMSwitchUpdateReqInParm& strSLMSwitchUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMSwitchUpdateReq()";
        retVal =        PPTManager_i::txSLMSwitchUpdateReq ( strSLMSwitchUpdateReqResult, strObjCommonIn, strSLMSwitchUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteStatusInq__100 */
virtual ::CORBA::Long  txCassetteStatusInq__100 (::pptCassetteStatusInqResult__100& strCassetteStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteStatusInq__100()";
        retVal =        PPTManager_i::txCassetteStatusInq__100 ( strCassetteStatusInqResult, strObjCommonIn, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteListInq__100 */
virtual ::CORBA::Long  txCassetteListInq__100 (::pptCassetteListInqResult__100& strCassetteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* cassetteCategory, ::CORBA::Boolean emptyFlag, const ::objectIdentifier& stockerID, const ::objectIdentifier& cassetteID, const char* cassetteStatus, ::CORBA::Long maxRetrieveCount, ::CORBA::Boolean sorterJobCreationCheckFlag, const char* interFabXferState, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteListInq__100()";
        retVal =        PPTManager_i::txCassetteListInq__100 ( strCassetteListInqResult, strObjCommonIn, cassetteCategory, emptyFlag, stockerID, cassetteID, cassetteStatus, maxRetrieveCount, sorterJobCreationCheckFlag, interFabXferState, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInq__100 */
virtual ::CORBA::Long  txLotListInq__100 (::pptLotListInqResult__100& strLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotStatus, const char* lotType, const ::objectIdentifier& productID, const char* orderNumber, const char* customerCode, const ::objectIdentifier& manufacturingLayerID, const ::objectIdentifier& routeID, const char* operationNumber, ::CORBA::Boolean bankInRequiredFlag, const ::objectIdentifier& lotID, const char* requiredCassetteCategory, ::CORBA::Boolean backupProcessingFlag, const char* subLotType, ::CORBA::Boolean deleteLotFlag, const ::objectIdentifier& holdReasonCodeID, ::CORBA::Boolean sorterJobCreationCheckFlag, const char* interFabXferState, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInq__100()";
        retVal =        PPTManager_i::txLotListInq__100 ( strLotListInqResult, strObjCommonIn, bankID, lotStatus, lotType, productID, orderNumber, customerCode, manufacturingLayerID, routeID, operationNumber, bankInRequiredFlag, lotID, requiredCassetteCategory, backupProcessingFlag, subLotType, deleteLotFlag, holdReasonCodeID, sorterJobCreationCheckFlag, interFabXferState, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMCassetteUnclampReq */
virtual ::CORBA::Long  txSLMCassetteUnclampReq (::pptSLMCassetteUnclampReqResult& strSLMCassetteUnclampReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMCassetteUnclampReqInParm& strSLMCassetteUnclampReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMCassetteUnclampReq()";
        retVal =        PPTManager_i::txSLMCassetteUnclampReq ( strSLMCassetteUnclampReqResult, strObjCommonIn, strSLMCassetteUnclampReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMWaferRetrieveCassetteReserveReq */
virtual ::CORBA::Long  txSLMWaferRetrieveCassetteReserveReq (::pptSLMWaferRetrieveCassetteReserveReqResult& strSLMWaferRetrieveCassetteReserveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMWaferRetrieveCassetteReserveReqInParm& strSLMWaferRetrieveCassetteReserveReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMWaferRetrieveCassetteReserveReq()";
        retVal =        PPTManager_i::txSLMWaferRetrieveCassetteReserveReq ( strSLMWaferRetrieveCassetteReserveReqResult, strObjCommonIn, strSLMWaferRetrieveCassetteReserveReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSLMStartLotsRsvMaxCountUpdateReq */
virtual ::CORBA::Long  txSLMStartLotsRsvMaxCountUpdateReq (::pptSLMStartLotsRsvMaxCountUpdateReqResult& strSLMStartLotsRsvMaxCountUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSLMStartLotsRsvMaxCountUpdateReqInParm& strSLMStartLotsRsvMaxCountUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSLMStartLotsRsvMaxCountUpdateReq()";
        retVal =        PPTManager_i::txSLMStartLotsRsvMaxCountUpdateReq ( strSLMStartLotsRsvMaxCountUpdateReqResult, strObjCommonIn, strSLMStartLotsRsvMaxCountUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExternalPostProcessFilterRegistReq */
virtual ::CORBA::Long  txExternalPostProcessFilterRegistReq (::pptExternalPostProcessFilterRegistReqResult& strExternalPostProcessFilterRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptExternalPostProcessFilterRegistReqInParm& strExternalPostProcessFilterRegistReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExternalPostProcessFilterRegistReq()";
        retVal =        PPTManager_i::txExternalPostProcessFilterRegistReq ( strExternalPostProcessFilterRegistReqResult, strObjCommonIn, strExternalPostProcessFilterRegistReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExternalPostProcessFilterDeleteReq */
virtual ::CORBA::Long  txExternalPostProcessFilterDeleteReq (::pptExternalPostProcessFilterDeleteReqResult& strExternalPostProcessFilterDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptExternalPostProcessFilterDeleteReqInParm& strExternalPostProcessFilterDeleteReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExternalPostProcessFilterDeleteReq()";
        retVal =        PPTManager_i::txExternalPostProcessFilterDeleteReq ( strExternalPostProcessFilterDeleteReqResult, strObjCommonIn, strExternalPostProcessFilterDeleteReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExternalPostProcessFilterListInq */
virtual ::CORBA::Long  txExternalPostProcessFilterListInq (::pptExternalPostProcessFilterListInqResult& strExternalPostProcessFilterListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptExternalPostProcessFilterListInqInParm& strExternalPostProcessFilterListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExternalPostProcessFilterListInq()";
        retVal =        PPTManager_i::txExternalPostProcessFilterListInq ( strExternalPostProcessFilterListInqResult, strObjCommonIn, strExternalPostProcessFilterListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txObjectIDListInq */
virtual ::CORBA::Long  txObjectIDListInq (::pptObjectIDListInqResult& strObjectIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptObjectIDListInqInParm& strObjectIDListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txObjectIDListInq()";
        retVal =        PPTManager_i::txObjectIDListInq ( strObjectIDListInqResult, strObjCommonIn, strObjectIDListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExternalPostProcessCompRpt */
virtual ::CORBA::Long  txExternalPostProcessCompRpt (::pptExternalPostProcessCompRptResult& strExternalPostProcessCompRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptExternalPostProcessCompRptInParm& strExternalPostProcessCompRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExternalPostProcessCompRpt()";
        retVal =        PPTManager_i::txExternalPostProcessCompRpt ( strExternalPostProcessCompRptResult, strObjCommonIn, strExternalPostProcessCompRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExternalPostProcessExecReq */
virtual ::CORBA::Long  txExternalPostProcessExecReq (::pptExternalPostProcessExecReqResult& strExternalPostProcessExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptExternalPostProcessExecReqInParm& strExternalPostProcessExecReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExternalPostProcessExecReq()";
        retVal =        PPTManager_i::txExternalPostProcessExecReq ( strExternalPostProcessExecReqResult, strObjCommonIn, strExternalPostProcessExecReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessExecReq__100 */
virtual ::CORBA::Long  txPostProcessExecReq__100 (::pptPostProcessExecReqResult__100& strPostProcessExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* key, ::CORBA::Long syncFlag, ::CORBA::Long prevSeqNo, const char* keyTimeStamp, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessExecReq__100()";
        retVal =        PPTManager_i::txPostProcessExecReq__100 ( strPostProcessExecReqResult, strObjCommonIn, key, syncFlag, prevSeqNo, keyTimeStamp, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessActionRegistReq__100 */
virtual ::CORBA::Long  txPostProcessActionRegistReq__100 (::pptPostProcessActionRegistReqResult__100& strPostProcessActionRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* txID, const char* patternID, const char* key, ::CORBA::Long seqNo, const ::pptPostProcessRegistrationParm& strPostProcessRegistrationParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessActionRegistReq__100()";
        retVal =        PPTManager_i::txPostProcessActionRegistReq__100 ( strPostProcessActionRegistReqResult, strObjCommonIn, txID, patternID, key, seqNo, strPostProcessRegistrationParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessActionUpdateReq__100 */
virtual ::CORBA::Long  txPostProcessActionUpdateReq__100 (::pptPostProcessActionUpdateReqResult__100& strPostProcessActionUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* actionCode, const ::pptPostProcessActionInfoSequence__100& strPostProcessActionInfoSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessActionUpdateReq__100()";
        retVal =        PPTManager_i::txPostProcessActionUpdateReq__100 ( strPostProcessActionUpdateReqResult, strObjCommonIn, actionCode, strPostProcessActionInfoSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessActionListInq__100 */
virtual ::CORBA::Long  txPostProcessActionListInq__100 (::pptPostProcessActionListInqResult__100& strPostProcessActionListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* key, ::CORBA::Long seqNo, const char* watchdogName, const char* postProcID, ::CORBA::Long syncFlag, const char* txID, const char* targetType, const ::pptPostProcessTargetObject& strPostProcessTargetObject, const char* status, ::CORBA::Long passedTime, const char* claimUserID, const char* startCreateTimeStamp, const char* endCreateTimeStamp, const char* startUpdateTimeStamp, const char* endUpdateTimeStamp, ::CORBA::Long maxCount, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessActionListInq__100()";
        retVal =        PPTManager_i::txPostProcessActionListInq__100 ( strPostProcessActionListInqResult, strObjCommonIn, key, seqNo, watchdogName, postProcID, syncFlag, txID, targetType, strPostProcessTargetObject, status, passedTime, claimUserID, startCreateTimeStamp, endCreateTimeStamp, startUpdateTimeStamp, endUpdateTimeStamp, maxCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessConfigInfoInq__100 */
virtual ::CORBA::Long  txPostProcessConfigInfoInq__100 (::pptPostProcessConfigInfoInqResult__100& strPostProcessConfigInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* txID, const char* patternID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessConfigInfoInq__100()";
        retVal =        PPTManager_i::txPostProcessConfigInfoInq__100 ( strPostProcessConfigInfoInqResult, strObjCommonIn, txID, patternID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFutureHoldPostByPostProcReq */
virtual ::CORBA::Long  txFutureHoldPostByPostProcReq (::pptFutureHoldPostByPostProcReqResult& strFutureHoldPostByPostProcReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFutureHoldPostByPostProcReqInParm& strFutureHoldPostByPostProcReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFutureHoldPostByPostProcReq()";
        retVal =        PPTManager_i::txFutureHoldPostByPostProcReq ( strFutureHoldPostByPostProcReqResult, strObjCommonIn, strFutureHoldPostByPostProcReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFutureHoldPreByPostProcReq */
virtual ::CORBA::Long  txFutureHoldPreByPostProcReq (::pptFutureHoldPreByPostProcReqResult& strFutureHoldPreByPostProcReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFutureHoldPreByPostProcReqInParm& strFutureHoldPreByPostProcReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFutureHoldPreByPostProcReq()";
        retVal =        PPTManager_i::txFutureHoldPreByPostProcReq ( strFutureHoldPreByPostProcReqResult, strObjCommonIn, strFutureHoldPreByPostProcReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationExecuteByPostProcReq */
virtual ::CORBA::Long  txSchdlChangeReservationExecuteByPostProcReq (::pptSchdlChangeReservationExecuteByPostProcReqResult& strSchdlChangeReservationExecuteByPostProcReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSchdlChangeReservationExecuteByPostProcReqInParm& strSchdlChangeReservationExecuteByPostProcReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationExecuteByPostProcReq()";
        retVal =        PPTManager_i::txSchdlChangeReservationExecuteByPostProcReq ( strSchdlChangeReservationExecuteByPostProcReqResult, strObjCommonIn, strSchdlChangeReservationExecuteByPostProcReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBankInByPostProcReq */
virtual ::CORBA::Long  txBankInByPostProcReq (::pptBankInByPostProcReqResult& strBankInByPostProcReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBankInByPostProcReqInParm& strBankInByPostProcReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBankInByPostProcReq()";
        retVal =        PPTManager_i::txBankInByPostProcReq ( strBankInByPostProcReqResult, strObjCommonIn, strBankInByPostProcReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txMonitorHoldExecByPostProcReq */
virtual ::CORBA::Long  txMonitorHoldExecByPostProcReq (::pptMonitorHoldExecByPostProcReqResult& strMonitorHoldExecByPostProcReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptMonitorHoldExecByPostProcReqInParm& strMonitorHoldExecByPostProcReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txMonitorHoldExecByPostProcReq()";
        retVal =        PPTManager_i::txMonitorHoldExecByPostProcReq ( strMonitorHoldExecByPostProcReqResult, strObjCommonIn, strMonitorHoldExecByPostProcReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataActionByPostProcReq */
virtual ::CORBA::Long  txCollectedDataActionByPostProcReq (::pptCollectedDataActionByPostProcReqResult& strCollectedDataActionByPostProcReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCollectedDataActionByPostProcReqInParm& strCollectedDataActionByPostProcReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataActionByPostProcReq()";
        retVal =        PPTManager_i::txCollectedDataActionByPostProcReq ( strCollectedDataActionByPostProcReqResult, strObjCommonIn, strCollectedDataActionByPostProcReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQtimeActionResetByPostProcReq */
virtual ::CORBA::Long  txQtimeActionResetByPostProcReq (::pptQtimeActionResetByPostProcReqResult& strQtimeActionResetByPostProcReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptQtimeActionResetByPostProcReqInParm& strQtimeActionResetByPostProcReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQtimeActionResetByPostProcReq()";
        retVal =        PPTManager_i::txQtimeActionResetByPostProcReq ( strQtimeActionResetByPostProcReqResult, strObjCommonIn, strQtimeActionResetByPostProcReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSTBCancelInfoInq */
virtual ::CORBA::Long  txSTBCancelInfoInq (::pptSTBCancelInfoInqResult& strSTBCancelInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSTBCancelInfoInqInParm& strSTBCancelInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSTBCancelInfoInq()";
        retVal =        PPTManager_i::txSTBCancelInfoInq ( strSTBCancelInfoInqResult, strObjCommonIn, strSTBCancelInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSTBCancelReq */
virtual ::CORBA::Long  txSTBCancelReq (::pptSTBCancelReqResult& strSTBCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSTBCancelReqInParm& strSTBCancelReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSTBCancelReq()";
        retVal =        PPTManager_i::txSTBCancelReq ( strSTBCancelReqResult, strObjCommonIn, strSTBCancelReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotPreparationCancelInfoInq */
virtual ::CORBA::Long  txLotPreparationCancelInfoInq (::pptLotPreparationCancelInfoInqResult& strLotPreparationCancelInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotPreparationCancelInfoInqInParm& strLotPreparationCancelInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotPreparationCancelInfoInq()";
        retVal =        PPTManager_i::txLotPreparationCancelInfoInq ( strLotPreparationCancelInfoInqResult, strObjCommonIn, strLotPreparationCancelInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotPreparationCancelReq */
virtual ::CORBA::Long  txLotPreparationCancelReq (::pptLotPreparationCancelReqResult& strLotPreparationCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotPreparationCancelReqInParm& strLotPreparationCancelReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotPreparationCancelReq()";
        retVal =        PPTManager_i::txLotPreparationCancelReq ( strLotPreparationCancelReqResult, strObjCommonIn, strLotPreparationCancelReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabLotXferPlanUpdateReq */
virtual ::CORBA::Long  txInterFabLotXferPlanUpdateReq (::pptInterFabLotXferPlanUpdateReqResult& strInterFabLotXferPlanUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabLotXferPlanUpdateReqInParm& strInterFabLotXferPlanUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabLotXferPlanUpdateReq()";
        retVal =        PPTManager_i::txInterFabLotXferPlanUpdateReq ( strInterFabLotXferPlanUpdateReqResult, strObjCommonIn, strInterFabLotXferPlanUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabLotXferPlanListInq */
virtual ::CORBA::Long  txInterFabLotXferPlanListInq (::pptInterFabLotXferPlanListInqResult& strInterFabLotXferPlanListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabLotXferPlanListInqInParm& strInterFabLotXferPlanListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabLotXferPlanListInq()";
        retVal =        PPTManager_i::txInterFabLotXferPlanListInq ( strInterFabLotXferPlanListInqResult, strObjCommonIn, strInterFabLotXferPlanListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferredLotListInq */
virtual ::CORBA::Long  txInterFabXferredLotListInq (::pptInterFabXferredLotListInqResult& strInterFabXferredLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferredLotListInqInParm& strInterFabXferredLotListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferredLotListInq()";
        retVal =        PPTManager_i::txInterFabXferredLotListInq ( strInterFabXferredLotListInqResult, strObjCommonIn, strInterFabXferredLotListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferredLotInfoDeleteReq */
virtual ::CORBA::Long  txInterFabXferredLotInfoDeleteReq (::pptInterFabXferredLotInfoDeleteReqResult& strInterFabXferredLotInfoDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferredLotInfoDeleteReqInParm& strInterFabXferredLotInfoDeleteReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferredLotInfoDeleteReq()";
        retVal =        PPTManager_i::txInterFabXferredLotInfoDeleteReq ( strInterFabXferredLotInfoDeleteReqResult, strObjCommonIn, strInterFabXferredLotInfoDeleteReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferReserveReq */
virtual ::CORBA::Long  txInterFabXferReserveReq (::pptInterFabXferReserveReqResult& strInterFabXferReserveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferReserveReqInParm& strInterFabXferReserveReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferReserveReq()";
        retVal =        PPTManager_i::txInterFabXferReserveReq ( strInterFabXferReserveReqResult, strObjCommonIn, strInterFabXferReserveReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferStartReq */
virtual ::CORBA::Long  txInterFabXferStartReq (::pptInterFabXferStartReqResult& strInterFabXferStartReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferStartReqInParm& strInterFabXferStartReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferStartReq()";
        retVal =        PPTManager_i::txInterFabXferStartReq ( strInterFabXferStartReqResult, strObjCommonIn, strInterFabXferStartReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferStateChangeReq */
virtual ::CORBA::Long  txInterFabXferStateChangeReq (::pptInterFabXferStateChangeReqResult& strInterFabXferStateChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferStateChangeReqInParm& strInterFabXferStateChangeReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferStateChangeReq()";
        retVal =        PPTManager_i::txInterFabXferStateChangeReq ( strInterFabXferStateChangeReqResult, strObjCommonIn, strInterFabXferStateChangeReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferCancelReq */
virtual ::CORBA::Long  txInterFabXferCancelReq (::pptInterFabXferCancelReqResult& strInterFabXferCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferCancelReqInParm& strInterFabXferCancelReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferCancelReq()";
        retVal =        PPTManager_i::txInterFabXferCancelReq ( strInterFabXferCancelReqResult, strObjCommonIn, strInterFabXferCancelReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferExportStartRpt */
virtual ::CORBA::Long  txInterFabXferExportStartRpt (::pptInterFabXferExportStartRptResult& strInterFabXferExportStartRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferExportStartRptInParm& strInterFabXferExportStartRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferExportStartRpt()";
        retVal =        PPTManager_i::txInterFabXferExportStartRpt ( strInterFabXferExportStartRptResult, strObjCommonIn, strInterFabXferExportStartRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferImportEndRpt */
virtual ::CORBA::Long  txInterFabXferImportEndRpt (::pptInterFabXferImportEndRptResult& strInterFabXferImportEndRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferImportEndRptInParm& strInterFabXferImportEndRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferImportEndRpt()";
        retVal =        PPTManager_i::txInterFabXferImportEndRpt ( strInterFabXferImportEndRptResult, strObjCommonIn, strInterFabXferImportEndRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabCarrierXferReq */
virtual ::CORBA::Long  txInterFabCarrierXferReq (::pptInterFabCarrierXferReqResult& strInterFabCarrierXferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabCarrierXferReqInParm& strInterFabCarrierXferReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabCarrierXferReq()";
        retVal =        PPTManager_i::txInterFabCarrierXferReq ( strInterFabCarrierXferReqResult, strObjCommonIn, strInterFabCarrierXferReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferArrivalListInq */
virtual ::CORBA::Long  txInterFabXferArrivalListInq (::pptInterFabXferArrivalListInqResult& strInterFabXferArrivalListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferArrivalListInqInParm& strInterFabXferArrivalListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferArrivalListInq()";
        retVal =        PPTManager_i::txInterFabXferArrivalListInq ( strInterFabXferArrivalListInqResult, strObjCommonIn, strInterFabXferArrivalListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferLotReceiveReq */
virtual ::CORBA::Long  txInterFabXferLotReceiveReq (::pptInterFabXferLotReceiveReqResult& strInterFabXferLotReceiveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferLotReceiveReqInParm& strInterFabXferLotReceiveReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferLotReceiveReq()";
        retVal =        PPTManager_i::txInterFabXferLotReceiveReq ( strInterFabXferLotReceiveReqResult, strObjCommonIn, strInterFabXferLotReceiveReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferDataDeleteReq */
virtual ::CORBA::Long  txInterFabXferDataDeleteReq (::pptInterFabXferDataDeleteReqResult& strInterFabXferDataDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferDataDeleteReqInParm& strInterFabXferDataDeleteReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferDataDeleteReq()";
        retVal =        PPTManager_i::txInterFabXferDataDeleteReq ( strInterFabXferDataDeleteReqResult, strObjCommonIn, strInterFabXferDataDeleteReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabXferCompRpt */
virtual ::CORBA::Long  txInterFabXferCompRpt (::pptInterFabXferCompRptResult& strInterFabXferCompRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabXferCompRptInParm& strInterFabXferCompRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabXferCompRpt()";
        retVal =        PPTManager_i::txInterFabXferCompRpt ( strInterFabXferCompRptResult, strObjCommonIn, strInterFabXferCompRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabDestinationListInq */
virtual ::CORBA::Long  txInterFabDestinationListInq (::pptInterFabDestinationListInqResult& strInterFabDestinationListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabDestinationListInqInParm& strInterFabDestinationListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabDestinationListInq()";
        retVal =        PPTManager_i::txInterFabDestinationListInq ( strInterFabDestinationListInqResult, strObjCommonIn, strInterFabDestinationListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txInterFabActionMonitorGroupReleaseReq */
virtual ::CORBA::Long  txInterFabActionMonitorGroupReleaseReq (::pptInterFabActionMonitorGroupReleaseReqResult& strInterFabActionMonitorGroupReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptInterFabActionMonitorGroupReleaseReqInParm& strInterFabActionMonitorGroupReleaseReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txInterFabActionMonitorGroupReleaseReq()";
        retVal =        PPTManager_i::txInterFabActionMonitorGroupReleaseReq ( strInterFabActionMonitorGroupReleaseReqResult, strObjCommonIn, strInterFabActionMonitorGroupReleaseReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoInq__100 */
virtual ::CORBA::Long  txLotInfoInq__100 (::pptLotInfoInqResult__100& strLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& lotID, ::CORBA::Boolean lotBasicInfoFlag, ::CORBA::Boolean lotControlUseInfoFlag, ::CORBA::Boolean lotFlowBatchInfoFlag, ::CORBA::Boolean lotNoteFlagInfoFlag, ::CORBA::Boolean lotOperationInfoFlag, ::CORBA::Boolean lotOrderInfoFlag, ::CORBA::Boolean lotControlJobInfoFlag, ::CORBA::Boolean lotProductInfoFlag, ::CORBA::Boolean lotRecipeInfoFlag, ::CORBA::Boolean lotLocationInfoFlag, ::CORBA::Boolean lotWipOperationInfoFlag, ::CORBA::Boolean lotWaferAttributesFlag, ::CORBA::Boolean lotListInCassetteInfoFlag, ::CORBA::Boolean waferMapInCassetteInfoFlag, ::CORBA::Boolean lotBackupInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoInq__100()";
        retVal =        PPTManager_i::txLotInfoInq__100 ( strLotInfoInqResult, strObjCommonIn, lotID, lotBasicInfoFlag, lotControlUseInfoFlag, lotFlowBatchInfoFlag, lotNoteFlagInfoFlag, lotOperationInfoFlag, lotOrderInfoFlag, lotControlJobInfoFlag, lotProductInfoFlag, lotRecipeInfoFlag, lotLocationInfoFlag, lotWipOperationInfoFlag, lotWaferAttributesFlag, lotListInCassetteInfoFlag, waferMapInCassetteInfoFlag, lotBackupInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpAuto3SettingListInq */
virtual ::CORBA::Long  txEqpAuto3SettingListInq (::pptEqpAuto3SettingListInqResult& strEqpAuto3SettingListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpAuto3SettingListInqInParm& strEqpAuto3SettingListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpAuto3SettingListInq()";
        retVal =        PPTManager_i::txEqpAuto3SettingListInq ( strEqpAuto3SettingListInqResult, strObjCommonIn, strEqpAuto3SettingListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpAuto3SettingUpdateReq */
virtual ::CORBA::Long  txEqpAuto3SettingUpdateReq (::pptEqpAuto3SettingUpdateReqResult& strEqpAuto3SettingUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpAuto3SettingUpdateReqInParm& strEqpAuto3SettingUpdateReqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpAuto3SettingUpdateReq()";
        retVal =        PPTManager_i::txEqpAuto3SettingUpdateReq ( strEqpAuto3SettingUpdateReqResult, strObjCommonIn, strEqpAuto3SettingUpdateReqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSpcCheckReq__101 */
virtual ::CORBA::Long  txSpcCheckReq__101 (::pptSpcCheckReqResult__101& strSpcCheckReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSpcCheckReq__101()";
        retVal =        PPTManager_i::txSpcCheckReq__101 ( strSpcCheckReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDCSpecDetailInfoInq__101 */
virtual ::CORBA::Long  txDCSpecDetailInfoInq__101 (::pptDCSpecDetailInfoInqResult__101& strDCSpecDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDCSpecDetailInfoInqInParm& strDCSpecDetailInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDCSpecDetailInfoInq__101()";
        retVal =        PPTManager_i::txDCSpecDetailInfoInq__101 ( strDCSpecDetailInfoInqResult, strObjCommonIn, strDCSpecDetailInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCDetailInfoInq__101 */
virtual ::CORBA::Long  txFPCDetailInfoInq__101 (::pptFPCDetailInfoInqResult__101& strFPCDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCDetailInfoInqInParm& strFPCDetailInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCDetailInfoInq__101()";
        retVal =        PPTManager_i::txFPCDetailInfoInq__101 ( strFPCDetailInfoInqResult, strObjCommonIn, strFPCDetailInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCUpdateReq__101 */
virtual ::CORBA::Long  txFPCUpdateReq__101 (::pptFPCUpdateReqResult& strFPCUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCUpdateReqInParm__101& strFPCUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCUpdateReq__101()";
        retVal =        PPTManager_i::txFPCUpdateReq__101 ( strFPCUpdateReqResult, strObjCommonIn, strFPCUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataActionInq */
virtual ::CORBA::Long  txCollectedDataActionInq (::pptCollectedDataActionInqResult& strCollectedDataActionInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCollectedDataActionInqInParm& strCollectedDataActionInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataActionInq()";
        retVal =        PPTManager_i::txCollectedDataActionInq ( strCollectedDataActionInqResult, strObjCommonIn, strCollectedDataActionInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDataSpecCheckResultInq */
virtual ::CORBA::Long  txDataSpecCheckResultInq (::pptDataSpecCheckResultInqResult& strDataSpecCheckResultInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDataSpecCheckResultInqInParm& strDataSpecCheckResultInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDataSpecCheckResultInq()";
        retVal =        PPTManager_i::txDataSpecCheckResultInq ( strDataSpecCheckResultInqResult, strObjCommonIn, strDataSpecCheckResultInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataHistoryInq__101 */
virtual ::CORBA::Long  txCollectedDataHistoryInq__101 (::pptCollectedDataHistoryInqResult__101& strCollectedDataHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const char* operationNumber, const char* operationPass, ::CORBA::Boolean getSpecFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataHistoryInq__101()";
        retVal =        PPTManager_i::txCollectedDataHistoryInq__101 ( strCollectedDataHistoryInqResult, strObjCommonIn, lotID, routeID, operationNumber, operationPass, getSpecFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitReq__101 */
virtual ::CORBA::Long  txEntityInhibitReq__101 (::pptEntityInhibitReqResult__101& strEntityInhibitReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitDetailAttributes& strEntityInhibition, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitReq__101()";
        retVal =        PPTManager_i::txEntityInhibitReq__101 ( strEntityInhibitReqResult, strObjCommonIn, strEntityInhibition, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitListInq__101 */
virtual ::CORBA::Long  txEntityInhibitListInq__101 (::pptEntityInhibitListInqResult__101& strEntityInhibitListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitDetailAttributes& strSearchCondition, ::CORBA::Boolean entityInhibitReasonDetailInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitListInq__101()";
        retVal =        PPTManager_i::txEntityInhibitListInq__101 ( strEntityInhibitListInqResult, strObjCommonIn, strSearchCondition, entityInhibitReasonDetailInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitCancelReq__101 */
virtual ::CORBA::Long  txEntityInhibitCancelReq__101 (::pptEntityInhibitCancelReqResult& strEntityInhibitCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitDetailInfoSequence& strEntityInhibitions, const ::objectIdentifier& reasonCode, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitCancelReq__101()";
        retVal =        PPTManager_i::txEntityInhibitCancelReq__101 ( strEntityInhibitCancelReqResult, strObjCommonIn, strEntityInhibitions, reasonCode, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUserDataInq__101 */
virtual ::CORBA::Long  txUserDataInq__101 (::pptUserDataInqResult& strUserDataInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUserDataInqInParm__101& strUserDataInqInParm__101, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUserDataInq__101()";
        retVal =        PPTManager_i::txUserDataInq__101 ( strUserDataInqResult, strObjCommonIn, strUserDataInqInParm__101, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txUserDataUpdateReq */
virtual ::CORBA::Long  txUserDataUpdateReq (::pptUserDataUpdateReqResult& strUserDataUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUserDataUpdateReqInParm& strUserDataUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txUserDataUpdateReq()";
        retVal =        PPTManager_i::txUserDataUpdateReq ( strUserDataUpdateReqResult, strObjCommonIn, strUserDataUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataInfoForUpdateInq */
virtual ::CORBA::Long  txCollectedDataInfoForUpdateInq (::pptCollectedDataInfoForUpdateInqResult& strCollectedDataInfoForUpdateInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCollectedDataInfoForUpdateInqInParm& strCollectedDataInfoForUpdateInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataInfoForUpdateInq()";
        retVal =        PPTManager_i::txCollectedDataInfoForUpdateInq ( strCollectedDataInfoForUpdateInqResult, strObjCommonIn, strCollectedDataInfoForUpdateInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataUpdateReq */
virtual ::CORBA::Long  txCollectedDataUpdateReq (::pptCollectedDataUpdateReqResult& strCollectedDataUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCollectedDataUpdateReqInParm& strCollectedDataUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataUpdateReq()";
        retVal =        PPTManager_i::txCollectedDataUpdateReq ( strCollectedDataUpdateReqResult, strObjCommonIn, strCollectedDataUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBOMPartsDefinitionInq */
virtual ::CORBA::Long  txBOMPartsDefinitionInq (::pptBOMPartsDefinitionInqResult& strBOMPartsDefinitionInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBOMPartsDefinitionInqInParm& strBOMPartsDefinitionInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBOMPartsDefinitionInq()";
        retVal =        PPTManager_i::txBOMPartsDefinitionInq ( strBOMPartsDefinitionInqResult, strObjCommonIn, strBOMPartsDefinitionInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBOMPartsLotListForProcessInq */
virtual ::CORBA::Long  txBOMPartsLotListForProcessInq (::pptBOMPartsLotListForProcessInqResult& strBOMPartsLotListForProcessInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBOMPartsLotListForProcessInqInParm& strBOMPartsLotListForProcessInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBOMPartsLotListForProcessInq()";
        retVal =        PPTManager_i::txBOMPartsLotListForProcessInq ( strBOMPartsLotListForProcessInqResult, strObjCommonIn, strBOMPartsLotListForProcessInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBondingLotListInq */
virtual ::CORBA::Long  txBondingLotListInq (::pptBondingLotListInqResult& strBondingLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBondingLotListInqInParm& strBondingLotListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBondingLotListInq()";
        retVal =        PPTManager_i::txBondingLotListInq ( strBondingLotListInqResult, strObjCommonIn, strBondingLotListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBondingGroupUpdateReq */
virtual ::CORBA::Long  txBondingGroupUpdateReq (::pptBondingGroupUpdateReqResult& strBondingGroupUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBondingGroupUpdateReqInParm& strBondingGroupUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBondingGroupUpdateReq()";
        retVal =        PPTManager_i::txBondingGroupUpdateReq ( strBondingGroupUpdateReqResult, strObjCommonIn, strBondingGroupUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBondingGroupListInq */
virtual ::CORBA::Long  txBondingGroupListInq (::pptBondingGroupListInqResult& strBondingGroupListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBondingGroupListInqInParm& strBondingGroupListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBondingGroupListInq()";
        retVal =        PPTManager_i::txBondingGroupListInq ( strBondingGroupListInqResult, strObjCommonIn, strBondingGroupListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBondingMapResultRpt */
virtual ::CORBA::Long  txBondingMapResultRpt (::pptBondingMapResultRptResult& strBondingMapResultRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBondingMapResultRptInParm& strBondingMapResultRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBondingMapResultRpt()";
        retVal =        PPTManager_i::txBondingMapResultRpt ( strBondingMapResultRptResult, strObjCommonIn, strBondingMapResultRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferStackingReq */
virtual ::CORBA::Long  txWaferStackingReq (::pptWaferStackingReqResult& strWaferStackingReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptWaferStackingReqInParm& strWaferStackingReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferStackingReq()";
        retVal =        PPTManager_i::txWaferStackingReq ( strWaferStackingReqResult, strObjCommonIn, strWaferStackingReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferStackingCancelReq */
virtual ::CORBA::Long  txWaferStackingCancelReq (::pptWaferStackingCancelReqResult& strWaferStackingCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptWaferStackingCancelReqInParm& strWaferStackingCancelReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferStackingCancelReq()";
        retVal =        PPTManager_i::txWaferStackingCancelReq ( strWaferStackingCancelReqResult, strObjCommonIn, strWaferStackingCancelReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStackedWaferListInq */
virtual ::CORBA::Long  txStackedWaferListInq (::pptStackedWaferListInqResult& strStackedWaferListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptStackedWaferListInqInParm& strStackedWaferListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStackedWaferListInq()";
        retVal =        PPTManager_i::txStackedWaferListInq ( strStackedWaferListInqResult, strObjCommonIn, strStackedWaferListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBondingGroupPartialReleaseReq */
virtual ::CORBA::Long  txBondingGroupPartialReleaseReq (::pptBondingGroupPartialReleaseReqResult& strBondingGroupPartialReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptBondingGroupPartialReleaseReqInParm& strBondingGroupPartialReleaseReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBondingGroupPartialReleaseReq()";
        retVal =        PPTManager_i::txBondingGroupPartialReleaseReq ( strBondingGroupPartialReleaseReqResult, strObjCommonIn, strBondingGroupPartialReleaseReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInBondingFlowInq */
virtual ::CORBA::Long  txLotListInBondingFlowInq (::pptLotListInBondingFlowInqResult& strLotListInBondingFlowInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotListInBondingFlowInqInParm& strLotListInBondingFlowInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInBondingFlowInq()";
        retVal =        PPTManager_i::txLotListInBondingFlowInq ( strLotListInBondingFlowInqResult, strObjCommonIn, strLotListInBondingFlowInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBondingFlowSectionListInq */
virtual ::CORBA::Long  txBondingFlowSectionListInq (::pptBondingFlowSectionListInqResult& strBondingFlowSectionListInqResult, const ::pptObjCommonIn& strObjCommonIn, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBondingFlowSectionListInq()";
        retVal =        PPTManager_i::txBondingFlowSectionListInq ( strBondingFlowSectionListInqResult, strObjCommonIn, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpCandidateForBondingInq */
virtual ::CORBA::Long  txEqpCandidateForBondingInq (::pptEqpCandidateForBondingInqResult& strEqpCandidateForBondingInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpCandidateForBondingInqInParm& strEqpCandidateForBondingInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpCandidateForBondingInq()";
        retVal =        PPTManager_i::txEqpCandidateForBondingInq ( strEqpCandidateForBondingInqResult, strObjCommonIn, strEqpCandidateForBondingInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatNextLotListInq__101 */
virtual ::CORBA::Long  txWhatNextLotListInq__101 (::pptWhatNextLotListInqResult__101& strWhatNextLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* selectCriteria, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatNextLotListInq__101()";
        retVal =        PPTManager_i::txWhatNextLotListInq__101 ( strWhatNextLotListInqResult, strObjCommonIn, equipmentID, selectCriteria, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoInq__101 */
virtual ::CORBA::Long  txLotInfoInq__101 (::pptLotInfoInqResult__101& strLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& lotID, ::CORBA::Boolean lotBasicInfoFlag, ::CORBA::Boolean lotControlUseInfoFlag, ::CORBA::Boolean lotFlowBatchInfoFlag, ::CORBA::Boolean lotNoteFlagInfoFlag, ::CORBA::Boolean lotOperationInfoFlag, ::CORBA::Boolean lotOrderInfoFlag, ::CORBA::Boolean lotControlJobInfoFlag, ::CORBA::Boolean lotProductInfoFlag, ::CORBA::Boolean lotRecipeInfoFlag, ::CORBA::Boolean lotLocationInfoFlag, ::CORBA::Boolean lotWipOperationInfoFlag, ::CORBA::Boolean lotWaferAttributesFlag, ::CORBA::Boolean lotListInCassetteInfoFlag, ::CORBA::Boolean waferMapInCassetteInfoFlag, ::CORBA::Boolean lotBackupInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoInq__101()";
        retVal =        PPTManager_i::txLotInfoInq__101 ( strLotInfoInqResult, strObjCommonIn, lotID, lotBasicInfoFlag, lotControlUseInfoFlag, lotFlowBatchInfoFlag, lotNoteFlagInfoFlag, lotOperationInfoFlag, lotOrderInfoFlag, lotControlJobInfoFlag, lotProductInfoFlag, lotRecipeInfoFlag, lotLocationInfoFlag, lotWipOperationInfoFlag, lotWaferAttributesFlag, lotListInCassetteInfoFlag, waferMapInCassetteInfoFlag, lotBackupInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInq__101 */
virtual ::CORBA::Long  txLotListInq__101 (::pptLotListInqResult__101& strLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotStatus, const char* lotType, const ::objectIdentifier& productID, const char* orderNumber, const char* customerCode, const ::objectIdentifier& manufacturingLayerID, const ::objectIdentifier& routeID, const char* operationNumber, ::CORBA::Boolean bankInRequiredFlag, const ::objectIdentifier& lotID, const char* requiredCassetteCategory, ::CORBA::Boolean backupProcessingFlag, const char* subLotType, ::CORBA::Boolean deleteLotFlag, const ::objectIdentifier& holdReasonCodeID, ::CORBA::Boolean sorterJobCreationCheckFlag, const char* interFabXferState, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInq__101()";
        retVal =        PPTManager_i::txLotListInq__101 ( strLotListInqResult, strObjCommonIn, bankID, lotStatus, lotType, productID, orderNumber, customerCode, manufacturingLayerID, routeID, operationNumber, bankInRequiredFlag, lotID, requiredCassetteCategory, backupProcessingFlag, subLotType, deleteLotFlag, holdReasonCodeID, sorterJobCreationCheckFlag, interFabXferState, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoInq__101 */
virtual ::CORBA::Long  txEqpInfoInq__101 (::pptEqpInfoInqResult__101& strEqpInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Boolean requestFlagForRSPPortInfo, ::CORBA::Boolean requestFlagForEqpContainerInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoInq__101()";
        retVal =        PPTManager_i::txEqpInfoInq__101 ( strEqpInfoInqResult, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, requestFlagForRSPPortInfo, requestFlagForEqpContainerInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOperationHistoryInq__101 */
virtual ::CORBA::Long  txOperationHistoryInq__101 (::pptOperationHistoryInqResult__101& strOperationHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const char* operationPass, const char* operationCategory, ::CORBA::Boolean pinPointFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOperationHistoryInq__101()";
        retVal =        PPTManager_i::txOperationHistoryInq__101 ( strOperationHistoryInqResult, strObjCommonIn, lotID, routeID, operationID, operationNumber, operationPass, operationCategory, pinPointFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::bondingGroup_info_GetDR */
virtual ::CORBA::Long  bondingGroup_info_GetDR (::objBondingGroup_info_GetDR_out& strBondingGroup_info_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objBondingGroup_info_GetDR_in& strBondingGroup_info_GetDR_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::bondingGroup_info_GetDR()";
        retVal =        PPTManager_i::bondingGroup_info_GetDR ( strBondingGroup_info_GetDR_out, strObjCommonIn, strBondingGroup_info_GetDR_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::bondingMap_FillInTxPCR003DR */
virtual ::CORBA::Long  bondingMap_FillInTxPCR003DR (::objBondingMap_FillInTxPCR003DR_out& strBondingMap_FillInTxPCR003DR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objBondingMap_FillInTxPCR003DR_in& strBondingMap_FillInTxPCR003DR_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::bondingMap_FillInTxPCR003DR()";
        retVal =        PPTManager_i::bondingMap_FillInTxPCR003DR ( strBondingMap_FillInTxPCR003DR_out, strObjCommonIn, strBondingMap_FillInTxPCR003DR_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::lot_stackedWaferInfo_GetDR */
virtual ::CORBA::Long  lot_stackedWaferInfo_GetDR (::objLot_stackedWaferInfo_GetDR_out& strLot_stackedWaferInfo_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objLot_stackedWaferInfo_GetDR_in& strLot_stackedWaferInfo_GetDR_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::lot_stackedWaferInfo_GetDR()";
        retVal =        PPTManager_i::lot_stackedWaferInfo_GetDR ( strLot_stackedWaferInfo_GetDR_out, strObjCommonIn, strLot_stackedWaferInfo_GetDR_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOwnerChangeReq */
virtual ::CORBA::Long  txOwnerChangeReq (::pptOwnerChangeReqResult& strOwnerChangeReqResult, ::pptOwnerChangeObjectSequence& strOwnerChangeObjectSeq, const ::pptObjCommonIn& strObjCommonIn, const ::pptOwnerChangeReqInParm& strOwnerChangeReqInParm, const char* stringifiedObjectReference, const ::pptOwnerChangeDefinition& strOwnerChangeDefinition, const ::pptOwnerChangeDefObjDefinition& strOwnerChangeDefObjDefinition, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOwnerChangeReq()";
        retVal =        PPTManager_i::txOwnerChangeReq ( strOwnerChangeReqResult, strOwnerChangeObjectSeq, strObjCommonIn, strOwnerChangeReqInParm, stringifiedObjectReference, strOwnerChangeDefinition, strOwnerChangeDefObjDefinition, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::person_existence_Check */
virtual ::CORBA::Long  person_existence_Check (::objPerson_existence_Check_out& strPerson_existence_Check_out, const ::pptObjCommonIn& strObjCommonIn, const ::objPerson_existence_Check_in& strPerson_existence_Check_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::person_existence_Check()";
        retVal =        PPTManager_i::person_existence_Check ( strPerson_existence_Check_out, strObjCommonIn, strPerson_existence_Check_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::ownerChange_definition_GetDR */
virtual ::CORBA::Long  ownerChange_definition_GetDR (::objOwnerChange_definition_GetDR_out& strOwnerChange_definition_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objOwnerChange_definition_GetDR_in& strOwnerChange_definition_GetDR_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::ownerChange_definition_GetDR()";
        retVal =        PPTManager_i::ownerChange_definition_GetDR ( strOwnerChange_definition_GetDR_out, strObjCommonIn, strOwnerChange_definition_GetDR_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::ownerChange_objectList_Get */
virtual ::CORBA::Long  ownerChange_objectList_Get (::objOwnerChange_objectList_Get_out& strOwnerChange_objectList_Get_out, const ::pptObjCommonIn& strObjCommonIn, const ::objOwnerChange_objectList_Get_in& strOwnerChange_objectList_Get_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::ownerChange_objectList_Get()";
        retVal =        PPTManager_i::ownerChange_objectList_Get ( strOwnerChange_objectList_Get_out, strObjCommonIn, strOwnerChange_objectList_Get_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::ownerChangeEvent_Make */
virtual ::CORBA::Long  ownerChangeEvent_Make (::objOwnerChangeEvent_Make_out& strOwnerChangeEvent_Make_out, const ::pptObjCommonIn& strObjCommonIn, const ::objOwnerChangeEvent_Make_in& strOwnerChangeEvent_Make_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::ownerChangeEvent_Make()";
        retVal =        PPTManager_i::ownerChangeEvent_Make ( strOwnerChangeEvent_Make_out, strObjCommonIn, strOwnerChangeEvent_Make_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txHistoryInformationInq */
virtual ::CORBA::Long  txHistoryInformationInq (::pptHistoryInformationInqResult& strHistoryInformationInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptHistoryInformationInqInParm& strHistoryInformationInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txHistoryInformationInq()";
        retVal =        PPTManager_i::txHistoryInformationInq ( strHistoryInformationInqResult, strObjCommonIn, strHistoryInformationInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txNewLotUpdateReq */
virtual ::CORBA::Long  txNewLotUpdateReq (::pptNewLotUpdateReqResult& strNewLotUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::pptUpdateLotAttributesSequence& strUpdateLotAttributesSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txNewLotUpdateReq()";
        retVal =        PPTManager_i::txNewLotUpdateReq ( strNewLotUpdateReqResult, strObjCommonIn, seqIndex, strUpdateLotAttributesSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotSchdlChangeReq__110 */
virtual ::CORBA::Long  txLotSchdlChangeReq__110 (::pptLotSchdlChangeReqResult& strLotSchdlChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRescheduledLotAttributesSequence__110& strRescheduledLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotSchdlChangeReq__110()";
        retVal =        PPTManager_i::txLotSchdlChangeReq__110 ( strLotSchdlChangeReqResult, strObjCommonIn, strRescheduledLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationCancelReq__110 */
virtual ::CORBA::Long  txSchdlChangeReservationCancelReq__110 (::pptSchdlChangeReservationCancelReqResult__110& strSchdlChangeReservationCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSchdlChangeReservationSequence__110& strSchdlChangeReservations, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationCancelReq__110()";
        retVal =        PPTManager_i::txSchdlChangeReservationCancelReq__110 ( strSchdlChangeReservationCancelReqResult, strObjCommonIn, strSchdlChangeReservations, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationChangeReq__110 */
virtual ::CORBA::Long  txSchdlChangeReservationChangeReq__110 (::pptSchdlChangeReservationChangeReqResult& strSchdlChangeReservationChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSchdlChangeReservation__110& strCurrentSchdlChangeReservation, const ::pptSchdlChangeReservation__110& strNewSchdlChangeReservation, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationChangeReq__110()";
        retVal =        PPTManager_i::txSchdlChangeReservationChangeReq__110 ( strSchdlChangeReservationChangeReqResult, strObjCommonIn, strCurrentSchdlChangeReservation, strNewSchdlChangeReservation, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationCreateReq__110 */
virtual ::CORBA::Long  txSchdlChangeReservationCreateReq__110 (::pptSchdlChangeReservationCreateReqResult& strSchdlChangeReservationCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptSchdlChangeReservation__110& strSchdlChangeReservation, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationCreateReq__110()";
        retVal =        PPTManager_i::txSchdlChangeReservationCreateReq__110 ( strSchdlChangeReservationCreateReqResult, strObjCommonIn, strSchdlChangeReservation, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationExecuteReq__110 */
virtual ::CORBA::Long  txSchdlChangeReservationExecuteReq__110 (::pptSchdlChangeReservationExecuteReqResult& strSchdlChangeReservationExecuteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRescheduledLotAttributesSequence__110& strRescheduledLotAttributes, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationExecuteReq__110()";
        retVal =        PPTManager_i::txSchdlChangeReservationExecuteReq__110 ( strSchdlChangeReservationExecuteReqResult, strObjCommonIn, strRescheduledLotAttributes, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSchdlChangeReservationListInq__110 */
virtual ::CORBA::Long  txSchdlChangeReservationListInq__110 (::pptSchdlChangeReservationListInqResult__110& strSchdlChangeReservationListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* eventID, const char* objectID, const char* objectType, const char* targetRouteID, const char* targetOperationNumber, const char* productID, const char* routeID, const char* operationNumber, const char* subLotType, const char* startDate, const char* endDate, const char* status, ::CORBA::Long lotInfoChangeFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSchdlChangeReservationListInq__110()";
        retVal =        PPTManager_i::txSchdlChangeReservationListInq__110 ( strSchdlChangeReservationListInqResult, strObjCommonIn, eventID, objectID, objectType, targetRouteID, targetOperationNumber, productID, routeID, operationNumber, subLotType, startDate, endDate, status, lotInfoChangeFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoInq__120 */
virtual ::CORBA::Long  txEqpInfoInq__120 (::pptEqpInfoInqResult__120& strEqpInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Boolean requestFlagForRSPPortInfo, ::CORBA::Boolean requestFlagForEqpContainerInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoInq__120()";
        retVal =        PPTManager_i::txEqpInfoInq__120 ( strEqpInfoInqResult, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, requestFlagForRSPPortInfo, requestFlagForEqpContainerInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoForInternalBufferInq__120 */
virtual ::CORBA::Long  txEqpInfoForInternalBufferInq__120 (::pptEqpInfoForInternalBufferInqResult__120& strEqpInfoForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForInternalBufferInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Boolean requestFlagForRSPPortInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoForInternalBufferInq__120()";
        retVal =        PPTManager_i::txEqpInfoForInternalBufferInq__120 ( strEqpInfoForInternalBufferInqResult, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForInternalBufferInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, requestFlagForRSPPortInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCJPJInfoInq */
virtual ::CORBA::Long  txCJPJInfoInq (::pptCJPJInfoInqResult& strCJPJInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCJPJInfoInqInParm& strCJPJInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCJPJInfoInq()";
        retVal =        PPTManager_i::txCJPJInfoInq ( strCJPJInfoInqResult, strObjCommonIn, strCJPJInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessJobManageReq */
virtual ::CORBA::Long  txProcessJobManageReq (::pptProcessJobManageReqResult& strProcessJobManageReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptProcessJobManageReqInParm& strProcessJobManageReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessJobManageReq()";
        retVal =        PPTManager_i::txProcessJobManageReq ( strProcessJobManageReqResult, strObjCommonIn, strProcessJobManageReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessJobInfoRpt__120 */
virtual ::CORBA::Long  txProcessJobInfoRpt__120 (::pptProcessJobInfoRptResult& strProcessJobInfoRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptProcessJobSequence__120& strProcessJobList, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessJobInfoRpt__120()";
        retVal =        PPTManager_i::txProcessJobInfoRpt__120 ( strProcessJobInfoRptResult, strObjCommonIn, equipmentID, controlJobID, strProcessJobList, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProcessJobStatusChangeRpt */
virtual ::CORBA::Long  txProcessJobStatusChangeRpt (::pptProcessJobStatusChangeRptResult& strProcessJobStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptProcessJobStatusChangeRptInParm& strProcessJobStatusChangeRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProcessJobStatusChangeRpt()";
        retVal =        PPTManager_i::txProcessJobStatusChangeRpt ( strProcessJobStatusChangeRptResult, strObjCommonIn, strProcessJobStatusChangeRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeParameterAdjustRpt */
virtual ::CORBA::Long  txRecipeParameterAdjustRpt (::pptRecipeParameterAdjustRptResult& strRecipeParameterAdjustRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRecipeParameterAdjustRptInParm& strRecipeParameterAdjustRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeParameterAdjustRpt()";
        retVal =        PPTManager_i::txRecipeParameterAdjustRpt ( strRecipeParameterAdjustRptResult, strObjCommonIn, strRecipeParameterAdjustRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRecipeParameterAdjustInProcessingReq */
virtual ::CORBA::Long  txRecipeParameterAdjustInProcessingReq (::pptRecipeParameterAdjustInProcessingReqResult& strRecipeParameterAdjustInProcessingReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRecipeParameterAdjustInProcessingReqInParm& strRecipeParameterAdjustInProcessingReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRecipeParameterAdjustInProcessingReq()";
        retVal =        PPTManager_i::txRecipeParameterAdjustInProcessingReq ( strRecipeParameterAdjustInProcessingReqResult, strObjCommonIn, strRecipeParameterAdjustInProcessingReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataByPJRpt */
virtual ::CORBA::Long  txCollectedDataByPJRpt (::pptCollectedDataByPJRptResult& strCollectedDataByPJRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCollectedDataByPJRptInParm& strCollectedDataByPJRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataByPJRpt()";
        retVal =        PPTManager_i::txCollectedDataByPJRpt ( strCollectedDataByPJRptResult, strObjCommonIn, strCollectedDataByPJRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataItemInq */
virtual ::CORBA::Long  txCollectedDataItemInq (::pptCollectedDataItemInqResult& strCollectedDataItemInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCollectedDataItemInqInParm& strCollectedDataItemInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataItemInq()";
        retVal =        PPTManager_i::txCollectedDataItemInq ( strCollectedDataItemInqResult, strObjCommonIn, strCollectedDataItemInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPartialOpeCompWithDataReq */
virtual ::CORBA::Long  txPartialOpeCompWithDataReq (::pptPartialOpeCompWithDataReqResult& strPartialOpeCompWithDataReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptPartialOpeCompWithDataReqInParm& strPartialOpeCompWithDataReqInParm, ::objectIdentifierSequence& holdReleasedLotIDs, char*& APCIFControlStatus, char*& DCSIFControlStatus, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPartialOpeCompWithDataReq()";
        retVal =        PPTManager_i::txPartialOpeCompWithDataReq ( strPartialOpeCompWithDataReqResult, strObjCommonIn, strPartialOpeCompWithDataReqInParm, holdReleasedLotIDs, APCIFControlStatus, DCSIFControlStatus, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPartialOpeCompForInternalBufferReq */
virtual ::CORBA::Long  txPartialOpeCompForInternalBufferReq (::pptPartialOpeCompForInternalBufferReqResult& strPartialOpeCompForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptPartialOpeCompForInternalBufferReqInParm& strPartialOpeCompForInternalBufferReqInParm, ::objectIdentifierSequence& holdReleasedLotIDs, char*& APCIFControlStatus, char*& DCSIFControlStatus, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPartialOpeCompForInternalBufferReq()";
        retVal =        PPTManager_i::txPartialOpeCompForInternalBufferReq ( strPartialOpeCompForInternalBufferReqResult, strObjCommonIn, strPartialOpeCompForInternalBufferReqInParm, holdReleasedLotIDs, APCIFControlStatus, DCSIFControlStatus, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txControlJobInfoForPartialOpeCompRpt */
virtual ::CORBA::Long  txControlJobInfoForPartialOpeCompRpt (::pptControlJobInfoForPartialOpeCompRptResult& strControlJobInfoForPartialOpeCompRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptControlJobInfoForPartialOpeCompRptInParm& strControlJobInfoForPartialOpeCompRptInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txControlJobInfoForPartialOpeCompRpt()";
        retVal =        PPTManager_i::txControlJobInfoForPartialOpeCompRpt ( strControlJobInfoForPartialOpeCompRptResult, strObjCommonIn, strControlJobInfoForPartialOpeCompRptInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataActionByPJReq */
virtual ::CORBA::Long  txCollectedDataActionByPJReq (::pptCollectedDataActionByPJReqResult& strCollectedDataActionByPJReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCollectedDataActionByPJReqInParm& strCollectedDataActionByPJReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataActionByPJReq()";
        retVal =        PPTManager_i::txCollectedDataActionByPJReq ( strCollectedDataActionByPJReqResult, strObjCommonIn, strCollectedDataActionByPJReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWaferAliasNameInfoInq */
virtual ::CORBA::Long  txWaferAliasNameInfoInq (::pptWaferAliasNameInfoInqResult& strWaferAliasNameInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptWaferAliasNameInfoInqInParm& strWaferAliasNameInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWaferAliasNameInfoInq()";
        retVal =        PPTManager_i::txWaferAliasNameInfoInq ( strWaferAliasNameInfoInqResult, strObjCommonIn, strWaferAliasNameInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCollectedDataHistoryInq__120 */
virtual ::CORBA::Long  txCollectedDataHistoryInq__120 (::pptCollectedDataHistoryInqResult__120& strCollectedDataHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const char* operationNumber, const char* operationPass, ::CORBA::Boolean getSpecFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCollectedDataHistoryInq__120()";
        retVal =        PPTManager_i::txCollectedDataHistoryInq__120 ( strCollectedDataHistoryInqResult, strObjCommonIn, lotID, routeID, operationNumber, operationPass, getSpecFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAPCDerivedDataInq__120 */
virtual ::CORBA::Long  txAPCDerivedDataInq__120 (::pptAPCDerivedDataInqResult__120& strAPCDerivedDataInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, const char* requestType, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAPCDerivedDataInq__120()";
        retVal =        PPTManager_i::txAPCDerivedDataInq__120 ( strAPCDerivedDataInqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette, requestType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txAutoDispatchControlUpdateReq */
virtual ::CORBA::Long  txAutoDispatchControlUpdateReq (::pptAutoDispatchControlUpdateReqResult& strAutoDispatchControlUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptAutoDispatchControlUpdateReqInParm& strAutoDispatchControlUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txAutoDispatchControlUpdateReq()";
        retVal =        PPTManager_i::txAutoDispatchControlUpdateReq ( strAutoDispatchControlUpdateReqResult, strObjCommonIn, strAutoDispatchControlUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotAutoDispatchControlInfoInq */
virtual ::CORBA::Long  txLotAutoDispatchControlInfoInq (::pptLotAutoDispatchControlInfoInqResult& strLotAutoDispatchControlInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotAutoDispatchControlInfoInqInParm& strLotAutoDispatchControlInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotAutoDispatchControlInfoInq()";
        retVal =        PPTManager_i::txLotAutoDispatchControlInfoInq ( strLotAutoDispatchControlInfoInqResult, strObjCommonIn, strLotAutoDispatchControlInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInq__120 */
virtual ::CORBA::Long  txLotListInq__120 (::pptLotListInqResult__120& strLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotStatus, const char* lotType, const ::objectIdentifier& productID, const char* orderNumber, const char* customerCode, const ::objectIdentifier& manufacturingLayerID, const ::objectIdentifier& routeID, const char* operationNumber, ::CORBA::Boolean bankInRequiredFlag, const ::objectIdentifier& lotID, const char* requiredCassetteCategory, ::CORBA::Boolean backupProcessingFlag, const char* subLotType, ::CORBA::Boolean deleteLotFlag, const ::objectIdentifier& holdReasonCodeID, ::CORBA::Boolean sorterJobCreationCheckFlag, const char* interFabXferState, ::CORBA::Boolean autoDispatchControlLotFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInq__120()";
        retVal =        PPTManager_i::txLotListInq__120 ( strLotListInqResult, strObjCommonIn, bankID, lotStatus, lotType, productID, orderNumber, customerCode, manufacturingLayerID, routeID, operationNumber, bankInRequiredFlag, lotID, requiredCassetteCategory, backupProcessingFlag, subLotType, deleteLotFlag, holdReasonCodeID, sorterJobCreationCheckFlag, interFabXferState, autoDispatchControlLotFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoInq__120 */
virtual ::CORBA::Long  txLotInfoInq__120 (::pptLotInfoInqResult__120& strLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& lotID, ::CORBA::Boolean lotBasicInfoFlag, ::CORBA::Boolean lotControlUseInfoFlag, ::CORBA::Boolean lotFlowBatchInfoFlag, ::CORBA::Boolean lotNoteFlagInfoFlag, ::CORBA::Boolean lotOperationInfoFlag, ::CORBA::Boolean lotOrderInfoFlag, ::CORBA::Boolean lotControlJobInfoFlag, ::CORBA::Boolean lotProductInfoFlag, ::CORBA::Boolean lotRecipeInfoFlag, ::CORBA::Boolean lotLocationInfoFlag, ::CORBA::Boolean lotWipOperationInfoFlag, ::CORBA::Boolean lotWaferAttributesFlag, ::CORBA::Boolean lotListInCassetteInfoFlag, ::CORBA::Boolean waferMapInCassetteInfoFlag, ::CORBA::Boolean lotBackupInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoInq__120()";
        retVal =        PPTManager_i::txLotInfoInq__120 ( strLotInfoInqResult, strObjCommonIn, lotID, lotBasicInfoFlag, lotControlUseInfoFlag, lotFlowBatchInfoFlag, lotNoteFlagInfoFlag, lotOperationInfoFlag, lotOrderInfoFlag, lotControlJobInfoFlag, lotProductInfoFlag, lotRecipeInfoFlag, lotLocationInfoFlag, lotWipOperationInfoFlag, lotWaferAttributesFlag, lotListInCassetteInfoFlag, waferMapInCassetteInfoFlag, lotBackupInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteStatusInq__120 */
virtual ::CORBA::Long  txCassetteStatusInq__120 (::pptCassetteStatusInqResult__120& strCassetteStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteStatusInq__120()";
        retVal =        PPTManager_i::txCassetteStatusInq__120 ( strCassetteStatusInqResult, strObjCommonIn, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatNextLotListInq__120 */
virtual ::CORBA::Long  txWhatNextLotListInq__120 (::pptWhatNextLotListInqResult__120& strWhatNextLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* selectCriteria, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatNextLotListInq__120()";
        retVal =        PPTManager_i::txWhatNextLotListInq__120 ( strWhatNextLotListInqResult, strObjCommonIn, equipmentID, selectCriteria, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessActionUpdateReq__130 */
virtual ::CORBA::Long  txPostProcessActionUpdateReq__130 (::pptPostProcessActionUpdateReqResult__100& strPostProcessActionUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const char* actionCode, const ::pptPostProcessActionInfoSequence__100& strPostProcessActionInfoSeq, const ::pptPostProcessAdditionalInfoSequence& strPostProcessAdditionalInfoSeq, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessActionUpdateReq__130()";
        retVal =        PPTManager_i::txPostProcessActionUpdateReq__130 ( strPostProcessActionUpdateReqResult, strObjCommonIn, actionCode, strPostProcessActionInfoSeq, strPostProcessAdditionalInfoSeq, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessActionListInq__130 */
virtual ::CORBA::Long  txPostProcessActionListInq__130 (::pptPostProcessActionListInqResult__130& strPostProcessActionListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* key, ::CORBA::Long seqNo, const char* watchdogName, const char* postProcID, ::CORBA::Long syncFlag, const char* txID, const char* targetType, const ::pptPostProcessTargetObject& strPostProcessTargetObject, const char* status, ::CORBA::Long passedTime, const char* claimUserID, const char* startCreateTimeStamp, const char* endCreateTimeStamp, const char* startUpdateTimeStamp, const char* endUpdateTimeStamp, ::CORBA::Long maxCount, ::CORBA::Boolean additionalInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessActionListInq__130()";
        retVal =        PPTManager_i::txPostProcessActionListInq__130 ( strPostProcessActionListInqResult, strObjCommonIn, key, seqNo, watchdogName, postProcID, syncFlag, txID, targetType, strPostProcessTargetObject, status, passedTime, claimUserID, startCreateTimeStamp, endCreateTimeStamp, startUpdateTimeStamp, endUpdateTimeStamp, maxCount, additionalInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessConfigInfoInq__130 */
virtual ::CORBA::Long  txPostProcessConfigInfoInq__130 (::pptPostProcessConfigInfoInqResult__100& strPostProcessConfigInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* txID, const char* patternID, const ::pptHashedInfoSequence& strSearchInfoSeq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessConfigInfoInq__130()";
        retVal =        PPTManager_i::txPostProcessConfigInfoInq__130 ( strPostProcessConfigInfoInqResult, strObjCommonIn, txID, patternID, strSearchInfoSeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotFutureActionListInq */
virtual ::CORBA::Long  txLotFutureActionListInq (::pptLotFutureActionListInqResult& strLotFutureActionListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotFutureActionListInqInParm& strLotFutureActionListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotFutureActionListInq()";
        retVal =        PPTManager_i::txLotFutureActionListInq ( strLotFutureActionListInqResult, strObjCommonIn, strLotFutureActionListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotFutureActionDetailInfoInq */
virtual ::CORBA::Long  txLotFutureActionDetailInfoInq (::pptLotFutureActionDetailInfoInqResult& strLotFutureActionDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotFutureActionDetailInfoInqInParm& strLotFutureActionDetailInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotFutureActionDetailInfoInq()";
        retVal =        PPTManager_i::txLotFutureActionDetailInfoInq ( strLotFutureActionDetailInfoInqResult, strObjCommonIn, strLotFutureActionDetailInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txPostProcessExecWithSeqNoReq */
virtual ::CORBA::Long  txPostProcessExecWithSeqNoReq (::pptPostProcessExecWithSeqNoReqResult& strPostProcessExecWithSeqNoReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptPostProcessExecWithSeqNoReqInParm& strPostProcessExecWithSeqNoReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txPostProcessExecWithSeqNoReq()";
        retVal =        PPTManager_i::txPostProcessExecWithSeqNoReq ( strPostProcessExecWithSeqNoReqResult, strObjCommonIn, strPostProcessExecWithSeqNoReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::postProcessQueue_ListDR__130 */
virtual ::CORBA::Long  postProcessQueue_ListDR__130 (::objPostProcessQueue_ListDR_out__100& strPostProcessQueue_ListDR_out, const ::pptObjCommonIn& strObjCommonIn, const char* key, ::CORBA::Long seqNo, const char* watchdogName, const char* postProcID, ::CORBA::Long syncFlag, const char* txID, const char* targetType, const ::pptPostProcessTargetObject& strPostProcessTargetObject, const char* status, ::CORBA::Long passedTime, const char* claimUserID, const char* startCreateTimeStamp, const char* endCreateTimeStamp, const char* startUpdateTimeStamp, const char* endUpdateTimeStamp, ::CORBA::Long maxCount, ::CORBA::Boolean committedReadFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::postProcessQueue_ListDR__130()";
        retVal =        PPTManager_i::postProcessQueue_ListDR__130 ( strPostProcessQueue_ListDR_out, strObjCommonIn, key, seqNo, watchdogName, postProcID, syncFlag, txID, targetType, strPostProcessTargetObject, status, passedTime, claimUserID, startCreateTimeStamp, endCreateTimeStamp, startUpdateTimeStamp, endUpdateTimeStamp, maxCount, committedReadFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::postProcessQueue_parallelExec_Check */
virtual ::CORBA::Long  postProcessQueue_parallelExec_Check (::objPostProcessQueue_parallelExec_Check_out& strPostProcessQueue_parallelExec_Check_out, const ::pptObjCommonIn& strObjCommonIn, const ::objPostProcessQueue_parallelExec_Check_in& strPostProcessQueue_parallelExec_Check_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::postProcessQueue_parallelExec_Check()";
        retVal =        PPTManager_i::postProcessQueue_parallelExec_Check ( strPostProcessQueue_parallelExec_Check_out, strObjCommonIn, strPostProcessQueue_parallelExec_Check_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::controlJob_lotIDList_GetDR */
virtual ::CORBA::Long  controlJob_lotIDList_GetDR (::objControlJob_lotIDList_GetDR_out& strControlJob_lotIDList_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& controlJobID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::controlJob_lotIDList_GetDR()";
        retVal =        PPTManager_i::controlJob_lotIDList_GetDR ( strControlJob_lotIDList_GetDR_out, strObjCommonIn, controlJobID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::cassette_lotIDList_GetDR */
virtual ::CORBA::Long  cassette_lotIDList_GetDR (::objCassette_lotIDList_GetDR_out& strCassette_lotIDList_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::cassette_lotIDList_GetDR()";
        retVal =        PPTManager_i::cassette_lotIDList_GetDR ( strCassette_lotIDList_GetDR_out, strObjCommonIn, cassetteID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::equipment_getTypeDR */
virtual ::CORBA::Long  equipment_getTypeDR (::objEquipment_getTypeDR_out& strEquipment_getTypeDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& eqipmentID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::equipment_getTypeDR()";
        retVal =        PPTManager_i::equipment_getTypeDR ( strEquipment_getTypeDR_out, strObjCommonIn, eqipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorListInq */
virtual ::CORBA::Long  txEqpMonitorListInq (::pptEqpMonitorListInqResult& strEqpMonitorListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorListInqInParm& strEqpMonitorListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorListInq()";
        retVal =        PPTManager_i::txEqpMonitorListInq ( strEqpMonitorListInqResult, strObjCommonIn, strEqpMonitorListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorJobListInq */
virtual ::CORBA::Long  txEqpMonitorJobListInq (::pptEqpMonitorJobListInqResult& strEqpMonitorJobListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorJobListInqInParm& strEqpMonitorJobListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorJobListInq()";
        retVal =        PPTManager_i::txEqpMonitorJobListInq ( strEqpMonitorJobListInqResult, strObjCommonIn, strEqpMonitorJobListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorStatusChangeRpt */
virtual ::CORBA::Long  txEqpMonitorStatusChangeRpt (::pptEqpMonitorStatusChangeRptResult& strEqpMonitorStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorStatusChangeRptInParm& strEqpMonitorStatusChangeRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorStatusChangeRpt()";
        retVal =        PPTManager_i::txEqpMonitorStatusChangeRpt ( strEqpMonitorStatusChangeRptResult, strObjCommonIn, strEqpMonitorStatusChangeRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorJobStatusChangeRpt */
virtual ::CORBA::Long  txEqpMonitorJobStatusChangeRpt (::pptEqpMonitorJobStatusChangeRptResult& strEqpMonitorJobStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorJobStatusChangeRptInParm& strEqpMonitorJobStatusChangeRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorJobStatusChangeRpt()";
        retVal =        PPTManager_i::txEqpMonitorJobStatusChangeRpt ( strEqpMonitorJobStatusChangeRptResult, strObjCommonIn, strEqpMonitorJobStatusChangeRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorUpdateReq */
virtual ::CORBA::Long  txEqpMonitorUpdateReq (::pptEqpMonitorUpdateReqResult& strEqpMonitorUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorUpdateReqInParm& strEqpMonitorUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorUpdateReq()";
        retVal =        PPTManager_i::txEqpMonitorUpdateReq ( strEqpMonitorUpdateReqResult, strObjCommonIn, strEqpMonitorUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorResetReq */
virtual ::CORBA::Long  txEqpMonitorResetReq (::pptEqpMonitorResetReqResult& strEqpMonitorResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorResetReqInParm& strEqpMonitorResetReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorResetReq()";
        retVal =        PPTManager_i::txEqpMonitorResetReq ( strEqpMonitorResetReqResult, strObjCommonIn, strEqpMonitorResetReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorScheduleUpdateReq */
virtual ::CORBA::Long  txEqpMonitorScheduleUpdateReq (::pptEqpMonitorScheduleUpdateReqResult& strEqpMonitorScheduleUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorScheduleUpdateReqInParm& strEqpMonitorScheduleUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorScheduleUpdateReq()";
        retVal =        PPTManager_i::txEqpMonitorScheduleUpdateReq ( strEqpMonitorScheduleUpdateReqResult, strObjCommonIn, strEqpMonitorScheduleUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorLotReserveReq */
virtual ::CORBA::Long  txEqpMonitorLotReserveReq (::pptEqpMonitorLotReserveReqResult& strEqpMonitorLotReserveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorLotReserveReqInParm& strEqpMonitorLotReserveReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorLotReserveReq()";
        retVal =        PPTManager_i::txEqpMonitorLotReserveReq ( strEqpMonitorLotReserveReqResult, strObjCommonIn, strEqpMonitorLotReserveReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorEvaluateReq */
virtual ::CORBA::Long  txEqpMonitorEvaluateReq (::pptEqpMonitorEvaluateReqResult& strEqpMonitorEvaluateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorEvaluateReqInParm& strEqpMonitorEvaluateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorEvaluateReq()";
        retVal =        PPTManager_i::txEqpMonitorEvaluateReq ( strEqpMonitorEvaluateReqResult, strObjCommonIn, strEqpMonitorEvaluateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorJobLotRemoveReq */
virtual ::CORBA::Long  txEqpMonitorJobLotRemoveReq (::pptEqpMonitorJobLotRemoveReqResult& strEqpMonitorJobLotRemoveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorJobLotRemoveReqInParm& strEqpMonitorJobLotRemoveReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorJobLotRemoveReq()";
        retVal =        PPTManager_i::txEqpMonitorJobLotRemoveReq ( strEqpMonitorJobLotRemoveReqResult, strObjCommonIn, strEqpMonitorJobLotRemoveReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatNextEqpMonitorLotListInq */
virtual ::CORBA::Long  txWhatNextEqpMonitorLotListInq (::pptWhatNextEqpMonitorLotListInqResult& strWhatNextEqpMonitorLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptWhatNextEqpMonitorLotListInqInParm& strWhatNextEqpMonitorLotListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatNextEqpMonitorLotListInq()";
        retVal =        PPTManager_i::txWhatNextEqpMonitorLotListInq ( strWhatNextEqpMonitorLotListInqResult, strObjCommonIn, strWhatNextEqpMonitorLotListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatNextLotListInq__140 */
virtual ::CORBA::Long  txWhatNextLotListInq__140 (::pptWhatNextLotListInqResult__140& strWhatNextLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* selectCriteria, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatNextLotListInq__140()";
        retVal =        PPTManager_i::txWhatNextLotListInq__140 ( strWhatNextLotListInqResult, strObjCommonIn, equipmentID, selectCriteria, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoInq__140 */
virtual ::CORBA::Long  txLotInfoInq__140 (::pptLotInfoInqResult__140& strLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& lotID, ::CORBA::Boolean lotBasicInfoFlag, ::CORBA::Boolean lotControlUseInfoFlag, ::CORBA::Boolean lotFlowBatchInfoFlag, ::CORBA::Boolean lotNoteFlagInfoFlag, ::CORBA::Boolean lotOperationInfoFlag, ::CORBA::Boolean lotOrderInfoFlag, ::CORBA::Boolean lotControlJobInfoFlag, ::CORBA::Boolean lotProductInfoFlag, ::CORBA::Boolean lotRecipeInfoFlag, ::CORBA::Boolean lotLocationInfoFlag, ::CORBA::Boolean lotWipOperationInfoFlag, ::CORBA::Boolean lotWaferAttributesFlag, ::CORBA::Boolean lotListInCassetteInfoFlag, ::CORBA::Boolean waferMapInCassetteInfoFlag, ::CORBA::Boolean lotBackupInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoInq__140()";
        retVal =        PPTManager_i::txLotInfoInq__140 ( strLotInfoInqResult, strObjCommonIn, lotID, lotBasicInfoFlag, lotControlUseInfoFlag, lotFlowBatchInfoFlag, lotNoteFlagInfoFlag, lotOperationInfoFlag, lotOrderInfoFlag, lotControlJobInfoFlag, lotProductInfoFlag, lotRecipeInfoFlag, lotLocationInfoFlag, lotWipOperationInfoFlag, lotWaferAttributesFlag, lotListInCassetteInfoFlag, waferMapInCassetteInfoFlag, lotBackupInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInq__140 */
virtual ::CORBA::Long  txLotListInq__140 (::pptLotListInqResult__140& strLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotStatus, const char* lotType, const ::objectIdentifier& productID, const char* orderNumber, const char* customerCode, const ::objectIdentifier& manufacturingLayerID, const ::objectIdentifier& routeID, const char* operationNumber, ::CORBA::Boolean bankInRequiredFlag, const ::objectIdentifier& lotID, const char* requiredCassetteCategory, ::CORBA::Boolean backupProcessingFlag, const char* subLotType, ::CORBA::Boolean deleteLotFlag, const ::objectIdentifier& holdReasonCodeID, ::CORBA::Boolean sorterJobCreationCheckFlag, const char* interFabXferState, ::CORBA::Boolean autoDispatchControlLotFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInq__140()";
        retVal =        PPTManager_i::txLotListInq__140 ( strLotListInqResult, strObjCommonIn, bankID, lotStatus, lotType, productID, orderNumber, customerCode, manufacturingLayerID, routeID, operationNumber, bankInRequiredFlag, lotID, requiredCassetteCategory, backupProcessingFlag, subLotType, deleteLotFlag, holdReasonCodeID, sorterJobCreationCheckFlag, interFabXferState, autoDispatchControlLotFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::postProcess_relatedQueueKey_GetDR */
virtual ::CORBA::Long  postProcess_relatedQueueKey_GetDR (::objPostProcess_relatedQueueKey_GetDR_out& strPostProcess_relatedQueueKey_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const char* key, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::postProcess_relatedQueueKey_GetDR()";
        retVal =        PPTManager_i::postProcess_relatedQueueKey_GetDR ( strPostProcess_relatedQueueKey_GetDR_out, strObjCommonIn, key, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCProcessListInRouteInq__150 */
virtual ::CORBA::Long  txFPCProcessListInRouteInq__150 (::pptFPCProcessListInRouteInqResult__150& strFPCProcessListInRouteInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCProcessListInRouteInqInParm& strFPCProcessListInRouteInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCProcessListInRouteInq__150()";
        retVal =        PPTManager_i::txFPCProcessListInRouteInq__150 ( strFPCProcessListInRouteInqResult, strObjCommonIn, strFPCProcessListInRouteInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpMonitorWaferUsedCountUpdateReq */
virtual ::CORBA::Long  txEqpMonitorWaferUsedCountUpdateReq (::pptEqpMonitorWaferUsedCountUpdateReqResult& strEqpMonitorWaferUsedCountUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorUsedCountUpdateReqInParam& strEqpMonitorUsedCountUpdateReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpMonitorWaferUsedCountUpdateReq()";
        retVal =        PPTManager_i::txEqpMonitorWaferUsedCountUpdateReq ( strEqpMonitorWaferUsedCountUpdateReqResult, strObjCommonIn, strEqpMonitorUsedCountUpdateReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoInq__150 */
virtual ::CORBA::Long  txLotInfoInq__150 (::pptLotInfoInqResult__150& strLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& lotID, ::CORBA::Boolean lotBasicInfoFlag, ::CORBA::Boolean lotControlUseInfoFlag, ::CORBA::Boolean lotFlowBatchInfoFlag, ::CORBA::Boolean lotNoteFlagInfoFlag, ::CORBA::Boolean lotOperationInfoFlag, ::CORBA::Boolean lotOrderInfoFlag, ::CORBA::Boolean lotControlJobInfoFlag, ::CORBA::Boolean lotProductInfoFlag, ::CORBA::Boolean lotRecipeInfoFlag, ::CORBA::Boolean lotLocationInfoFlag, ::CORBA::Boolean lotWipOperationInfoFlag, ::CORBA::Boolean lotWaferAttributesFlag, ::CORBA::Boolean lotListInCassetteInfoFlag, ::CORBA::Boolean waferMapInCassetteInfoFlag, ::CORBA::Boolean lotBackupInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoInq__150()";
        retVal =        PPTManager_i::txLotInfoInq__150 ( strLotInfoInqResult, strObjCommonIn, lotID, lotBasicInfoFlag, lotControlUseInfoFlag, lotFlowBatchInfoFlag, lotNoteFlagInfoFlag, lotOperationInfoFlag, lotOrderInfoFlag, lotControlJobInfoFlag, lotProductInfoFlag, lotRecipeInfoFlag, lotLocationInfoFlag, lotWipOperationInfoFlag, lotWaferAttributesFlag, lotListInCassetteInfoFlag, waferMapInCassetteInfoFlag, lotBackupInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitExceptionLotListInq */
virtual ::CORBA::Long  txEntityInhibitExceptionLotListInq (::pptEntityInhibitExceptionLotListInqResult& strExceptionLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitExceptionLotListInqInParm& strEntityInhibitExceptionLotListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitExceptionLotListInq()";
        retVal =        PPTManager_i::txEntityInhibitExceptionLotListInq ( strExceptionLotListInqResult, strObjCommonIn, strEntityInhibitExceptionLotListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitExceptionLotReq */
virtual ::CORBA::Long  txEntityInhibitExceptionLotReq (::pptEntityInhibitExceptionLotReqResult& strExceptionLotReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitExceptionLotReqInParm& strEntityInhibitExceptionLotReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitExceptionLotReq()";
        retVal =        PPTManager_i::txEntityInhibitExceptionLotReq ( strExceptionLotReqResult, strObjCommonIn, strEntityInhibitExceptionLotReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEntityInhibitExceptionLotCancelReq */
virtual ::CORBA::Long  txEntityInhibitExceptionLotCancelReq (::pptEntityInhibitExceptionLotCancelReqResult& strExceptionLotCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEntityInhibitExceptionLotCancelReqInParm& strEntityInhibitExceptionLotCancelReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEntityInhibitExceptionLotCancelReq()";
        retVal =        PPTManager_i::txEntityInhibitExceptionLotCancelReq ( strExceptionLotCancelReqResult, strObjCommonIn, strEntityInhibitExceptionLotCancelReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeListInq__150 */
virtual ::CORBA::Long  txQrestTimeListInq__150 (::pptQrestTimeListInqResult__150& strQrestTimeListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, ::CORBA::Boolean activeQTime, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeListInq__150()";
        retVal =        PPTManager_i::txQrestTimeListInq__150 ( strQrestTimeListInqResult, strObjCommonIn, lotID, activeQTime, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeActionExecReq__150 */
virtual ::CORBA::Long  txQrestTimeActionExecReq__150 (::pptQrestTimeActionExecReqResult& strQrestTimeActionExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* lotStatus, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& equipmentID, const ::pptQrestTimeAction__150& strQrestTimeAction, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeActionExecReq__150()";
        retVal =        PPTManager_i::txQrestTimeActionExecReq__150 ( strQrestTimeActionExecReqResult, strObjCommonIn, lotID, lotStatus, routeID, operationNumber, equipmentID, strQrestTimeAction, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeUpdateReq */
virtual ::CORBA::Long  txQrestTimeUpdateReq (::pptQrestTimeUpdateReqResult& strQrestTimeUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptQrestTimeUpdateReqInParm& strQrestTimeUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeUpdateReq()";
        retVal =        PPTManager_i::txQrestTimeUpdateReq ( strQrestTimeUpdateReqResult, strObjCommonIn, strQrestTimeUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::lot_qtimeInfo_SortByAction__150 */
virtual ::CORBA::Long  lot_qtimeInfo_SortByAction__150 (::objLot_qtimeInfo_SortByAction_out__150& strLot_qtimeInfo_SortByAction_out, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::pptQtimeInfoSequence__150& strQtimeInfoSeq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::lot_qtimeInfo_SortByAction__150()";
        retVal =        PPTManager_i::lot_qtimeInfo_SortByAction__150 ( strLot_qtimeInfo_SortByAction_out, strObjCommonIn, lotID, strQtimeInfoSeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeCandidateInq */
virtual ::CORBA::Long  txQrestTimeCandidateInq (::pptQrestTimeCandidateInqResult& strQrestTimeCandidateInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptQrestTimeCandidateInqInParm& strQrestTimeCandidateInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeCandidateInq()";
        retVal =        PPTManager_i::txQrestTimeCandidateInq ( strQrestTimeCandidateInqResult, strObjCommonIn, strQrestTimeCandidateInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::lot_postProcessPreviousBranchAndReturnInfo_GetDR */
virtual ::CORBA::Long  lot_postProcessPreviousBranchAndReturnInfo_GetDR (::objLot_postProcessPreviousBranchAndReturnInfo_GetDR_out& strLot_postProcessPreviousBranchAndReturnInfo_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objLot_postProcessPreviousBranchAndReturnInfo_GetDR_in& strLot_postProcessPreviousBranchAndReturnInfo_GetDR_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::lot_postProcessPreviousBranchAndReturnInfo_GetDR()";
        retVal =        PPTManager_i::lot_postProcessPreviousBranchAndReturnInfo_GetDR ( strLot_postProcessPreviousBranchAndReturnInfo_GetDR_out, strObjCommonIn, strLot_postProcessPreviousBranchAndReturnInfo_GetDR_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWIPLotResetReq */
virtual ::CORBA::Long  txWIPLotResetReq (::pptWIPLotResetReqResult& strWIPLotResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptWIPLotResetReqInParm& strWIPLotResetReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWIPLotResetReq()";
        retVal =        PPTManager_i::txWIPLotResetReq ( strWIPLotResetReqResult, strObjCommonIn, strWIPLotResetReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteListInq__160 */
virtual ::CORBA::Long  txCassetteListInq__160 (::pptCassetteListInqResult__160& strCassetteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* cassetteCategory, ::CORBA::Boolean emptyFlag, const ::objectIdentifier& stockerID, const ::objectIdentifier& cassetteID, const char* cassetteStatus, ::CORBA::Long maxRetrieveCount, ::CORBA::Boolean sorterJobCreationCheckFlag, const char* interFabXferState, const ::objectIdentifier& bankID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteListInq__160()";
        retVal =        PPTManager_i::txCassetteListInq__160 ( strCassetteListInqResult, strObjCommonIn, cassetteCategory, emptyFlag, stockerID, cassetteID, cassetteStatus, maxRetrieveCount, sorterJobCreationCheckFlag, interFabXferState, bankID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteStatusInq__160 */
virtual ::CORBA::Long  txCassetteStatusInq__160 (::pptCassetteStatusInqResult__160& strCassetteStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Boolean durableOperationInfoFlag, ::CORBA::Boolean durableWipOperationInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteStatusInq__160()";
        retVal =        PPTManager_i::txCassetteStatusInq__160 ( strCassetteStatusInqResult, strObjCommonIn, cassetteID, durableOperationInfoFlag, durableWipOperationInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableControlJobListInq */
virtual ::CORBA::Long  txDurableControlJobListInq (::pptDurableControlJobListInqResult& strDurableControlJobListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableControlJobListInqInParam& strDurableControlJobListInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableControlJobListInq()";
        retVal =        PPTManager_i::txDurableControlJobListInq ( strDurableControlJobListInqResult, strObjCommonIn, strDurableControlJobListInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableControlJobManageReq */
virtual ::CORBA::Long  txDurableControlJobManageReq (::pptDurableControlJobManageReqResult& strDurableControlJobManageReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableControlJobManageReqInParam& strDurableControlJobManageReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableControlJobManageReq()";
        retVal =        PPTManager_i::txDurableControlJobManageReq ( strDurableControlJobManageReqResult, strObjCommonIn, strDurableControlJobManageReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableOpeCompReq */
virtual ::CORBA::Long  txDurableOpeCompReq (::pptDurableOpeCompReqResult& strDurableOpeCompReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableOpeCompReqInParam& strDurableOpeCompReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableOpeCompReq()";
        retVal =        PPTManager_i::txDurableOpeCompReq ( strDurableOpeCompReqResult, strObjCommonIn, strDurableOpeCompReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableOperationStartCancelReq */
virtual ::CORBA::Long  txDurableOperationStartCancelReq (::pptDurableOperationStartCancelReqResult& strDurableOperationStartCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableOperationStartCancelReqInParam& strDurableOperationStartCancelReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableOperationStartCancelReq()";
        retVal =        PPTManager_i::txDurableOperationStartCancelReq ( strDurableOperationStartCancelReqResult, strObjCommonIn, strDurableOperationStartCancelReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableOperationStartReq */
virtual ::CORBA::Long  txDurableOperationStartReq (::pptDurableOperationStartReqResult& strDurableOperationStartReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableOperationStartReqInParam& strDurableOperationStartReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableOperationStartReq()";
        retVal =        PPTManager_i::txDurableOperationStartReq ( strDurableOperationStartReqResult, strObjCommonIn, strDurableOperationStartReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurablePFXCreateReq */
virtual ::CORBA::Long  txDurablePFXCreateReq (::pptDurablePFXCreateReqResult& strDurablePFXCreateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurablePFXCreateReqInParam& strDurablePFXCreateReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurablePFXCreateReq()";
        retVal =        PPTManager_i::txDurablePFXCreateReq ( strDurablePFXCreateReqResult, strObjCommonIn, strDurablePFXCreateReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurablePFXDeleteReq */
virtual ::CORBA::Long  txDurablePFXDeleteReq (::pptDurablePFXDeleteReqResult& strDurablePFXDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurablePFXDeleteReqInParam& strDurablePFXDeleteReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurablePFXDeleteReq()";
        retVal =        PPTManager_i::txDurablePFXDeleteReq ( strDurablePFXDeleteReqResult, strObjCommonIn, strDurablePFXDeleteReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurablesInfoForOpeStartInq */
virtual ::CORBA::Long  txDurablesInfoForOpeStartInq (::pptDurablesInfoForOpeStartInqResult& strDurablesInfoForOpeStartInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurablesInfoForOpeStartInqInParam& strDurablesInfoForOpeStartInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurablesInfoForOpeStartInq()";
        retVal =        PPTManager_i::txDurablesInfoForOpeStartInq ( strDurablesInfoForOpeStartInqResult, strObjCommonIn, strDurablesInfoForOpeStartInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpInfoInq__160 */
virtual ::CORBA::Long  txEqpInfoInq__160 (::pptEqpInfoInqResult__160& strEqpInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Boolean requestFlagForRSPPortInfo, ::CORBA::Boolean requestFlagForEqpContainerInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpInfoInq__160()";
        retVal =        PPTManager_i::txEqpInfoInq__160 ( strEqpInfoInqResult, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, requestFlagForRSPPortInfo, requestFlagForEqpContainerInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpListInq__160 */
virtual ::CORBA::Long  txEqpListInq__160 (::pptEqpListInqResult__100& strEqpListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpListInqInParm__160& strEqpListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpListInq__160()";
        retVal =        PPTManager_i::txEqpListInq__160 ( strEqpListInqResult, strObjCommonIn, strEqpListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleListInq__160 */
virtual ::CORBA::Long  txReticleListInq__160 (::pptReticleListInqResult__160& strReticleListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReticleListInqInParm__160& strReticleListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleListInq__160()";
        retVal =        PPTManager_i::txReticleListInq__160 ( strReticleListInqResult, strObjCommonIn, strReticleListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStatusInq__160 */
virtual ::CORBA::Long  txReticleStatusInq__160 (::pptReticleStatusInqResult__160& strReticleStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, ::CORBA::Boolean durableOperationInfoFlag, ::CORBA::Boolean durableWipOperationInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStatusInq__160()";
        retVal =        PPTManager_i::txReticleStatusInq__160 ( strReticleStatusInqResult, strObjCommonIn, reticleID, durableOperationInfoFlag, durableWipOperationInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodListInq__160 */
virtual ::CORBA::Long  txReticlePodListInq__160 (::pptReticlePodListInqResult__160& strReticlePodListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& reticlePodID, const char* reticlePodCategory, const char* reticlePodStatus, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, ::CORBA::Boolean emptyFlag, const ::objectIdentifier& reticleID, const ::objectIdentifier& reticleGroupID, const char* reticlePartNumber, ::CORBA::Long maxRetrieveCount, const ::objectIdentifier& bankID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodListInq__160()";
        retVal =        PPTManager_i::txReticlePodListInq__160 ( strReticlePodListInqResult, strObjCommonIn, requestUserID, reticlePodID, reticlePodCategory, reticlePodStatus, equipmentID, stockerID, emptyFlag, reticleID, reticleGroupID, reticlePartNumber, maxRetrieveCount, bankID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodStatusInq__160 */
virtual ::CORBA::Long  txReticlePodStatusInq__160 (::pptReticlePodStatusInqResult__160& strReticlePodStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticlePodID, ::CORBA::Boolean durableOperationInfoFlag, ::CORBA::Boolean durableWipOperationInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodStatusInq__160()";
        retVal =        PPTManager_i::txReticlePodStatusInq__160 ( strReticlePodStatusInqResult, strObjCommonIn, reticlePodID, durableOperationInfoFlag, durableWipOperationInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStartDurablesReservationCancelReq */
virtual ::CORBA::Long  txStartDurablesReservationCancelReq (::pptStartDurablesReservationCancelReqResult& strStartDurablesReservationCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptStartDurablesReservationCancelReqInParam& strStartDurablesReservationCancelReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStartDurablesReservationCancelReq()";
        retVal =        PPTManager_i::txStartDurablesReservationCancelReq ( strStartDurablesReservationCancelReqResult, strObjCommonIn, strStartDurablesReservationCancelReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txStartDurablesReservationReq */
virtual ::CORBA::Long  txStartDurablesReservationReq (::pptStartDurablesReservationReqResult& strStartDurablesReservationReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptStartDurablesReservationReqInParam& strStartDurablesReservationReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txStartDurablesReservationReq()";
        retVal =        PPTManager_i::txStartDurablesReservationReq ( strStartDurablesReservationReqResult, strObjCommonIn, strStartDurablesReservationReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpBufferResourceInfoInq */
virtual ::CORBA::Long  txEqpBufferResourceInfoInq (::pptEqpBufferResourceInfoInqResult& strEqpBufferResourceInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpBufferResourceInfoInqInParm& strEqpBufferResourceInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpBufferResourceInfoInq()";
        retVal =        PPTManager_i::txEqpBufferResourceInfoInq ( strEqpBufferResourceInfoInqResult, strObjCommonIn, strEqpBufferResourceInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpBufferResourceTypeChangeReq */
virtual ::CORBA::Long  txEqpBufferResourceTypeChangeReq (::pptEqpBufferResourceTypeChangeReqResult& strEqpBufferResourceTypeChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpBufferResourceTypeChangeReqInParm& strEqpBufferResourceTypeChangeReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpBufferResourceTypeChangeReq()";
        retVal =        PPTManager_i::txEqpBufferResourceTypeChangeReq ( strEqpBufferResourceTypeChangeReqResult, strObjCommonIn, strEqpBufferResourceTypeChangeReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableBankInReq */
virtual ::CORBA::Long  txDurableBankInReq (::pptDurableBankInReqResult& strDurableBankInReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::pptDurableBankInReqInParam& strDurableBankInReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableBankInReq()";
        retVal =        PPTManager_i::txDurableBankInReq ( strDurableBankInReqResult, strObjCommonIn, seqIndex, strDurableBankInReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableBankInCancelReq */
virtual ::CORBA::Long  txDurableBankInCancelReq (::pptDurableBankInCancelReqResult& strDurableBankInCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableBankInCancelReqInParam& strDurableBankInCancelReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableBankInCancelReq()";
        retVal =        PPTManager_i::txDurableBankInCancelReq ( strDurableBankInCancelReqResult, strObjCommonIn, strDurableBankInCancelReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableBankMoveReq */
virtual ::CORBA::Long  txDurableBankMoveReq (::pptDurableBankMoveReqResult& strDurableBankMoveReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::pptDurableBankMoveReqInParam& strDurableBankMoveReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableBankMoveReq()";
        retVal =        PPTManager_i::txDurableBankMoveReq ( strDurableBankMoveReqResult, strObjCommonIn, seqIndex, strDurableBankMoveReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txHoldDurableReq */
virtual ::CORBA::Long  txHoldDurableReq (::pptHoldDurableReqResult& strHoldDurableReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptHoldDurableReqInParam& strHoldDurableReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txHoldDurableReq()";
        retVal =        PPTManager_i::txHoldDurableReq ( strHoldDurableReqResult, strObjCommonIn, strHoldDurableReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableHoldListInq */
virtual ::CORBA::Long  txDurableHoldListInq (::pptDurableHoldListInqResult& strDurableHoldListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableHoldListInqInParam& strDurableHoldListInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableHoldListInq()";
        retVal =        PPTManager_i::txDurableHoldListInq ( strDurableHoldListInqResult, strObjCommonIn, strDurableHoldListInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txHoldDurableReleaseReq */
virtual ::CORBA::Long  txHoldDurableReleaseReq (::pptHoldDurableReleaseReqResult& strHoldDurableReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptHoldDurableReleaseReqInParam& strHoldDurableReleaseReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txHoldDurableReleaseReq()";
        retVal =        PPTManager_i::txHoldDurableReleaseReq ( strHoldDurableReleaseReqResult, strObjCommonIn, strHoldDurableReleaseReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReworkDurableReq */
virtual ::CORBA::Long  txReworkDurableReq (::pptReworkDurableReqResult& strReworkDurableReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReworkDurableReqInParam& strReworkDurableReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReworkDurableReq()";
        retVal =        PPTManager_i::txReworkDurableReq ( strReworkDurableReqResult, strObjCommonIn, strReworkDurableReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReworkDurableCancelReq */
virtual ::CORBA::Long  txReworkDurableCancelReq (::pptReworkDurableCancelReqResult& strReworkDurableCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReworkDurableCancelReqInParam& strReworkDurableCancelReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReworkDurableCancelReq()";
        retVal =        PPTManager_i::txReworkDurableCancelReq ( strReworkDurableCancelReqResult, strObjCommonIn, strReworkDurableCancelReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReworkDurableWithHoldReleaseReq */
virtual ::CORBA::Long  txReworkDurableWithHoldReleaseReq (::pptReworkDurableWithHoldReleaseReqResult& strReworkDurableWithHoldReleaseReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReworkDurableWithHoldReleaseReqInParam& strReworkDurableWithHoldReleaseReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReworkDurableWithHoldReleaseReq()";
        retVal =        PPTManager_i::txReworkDurableWithHoldReleaseReq ( strReworkDurableWithHoldReleaseReqResult, strObjCommonIn, strReworkDurableWithHoldReleaseReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txConnectedDurableRouteListInq */
virtual ::CORBA::Long  txConnectedDurableRouteListInq (::pptConnectedDurableRouteListInqResult& strConnectedDurableRouteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptConnectedDurableRouteListInqInParam& strConnectedDurableRouteListInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txConnectedDurableRouteListInq()";
        retVal =        PPTManager_i::txConnectedDurableRouteListInq ( strConnectedDurableRouteListInqResult, strObjCommonIn, strConnectedDurableRouteListInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableOperationListInq */
virtual ::CORBA::Long  txDurableOperationListInq (::pptDurableOperationListInqResult& strDurableOperationListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableOperationListInqInParam& strDurableOperationListInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableOperationListInq()";
        retVal =        PPTManager_i::txDurableOperationListInq ( strDurableOperationListInqResult, strObjCommonIn, strDurableOperationListInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableOperationListFromHistoryInq */
virtual ::CORBA::Long  txDurableOperationListFromHistoryInq (::pptDurableOperationListFromHistoryInqResult& strDurableOperationListFromHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableOperationListFromHistoryInqInParam& strDurableOperationListFromHistoryInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableOperationListFromHistoryInq()";
        retVal =        PPTManager_i::txDurableOperationListFromHistoryInq ( strDurableOperationListFromHistoryInqResult, strObjCommonIn, strDurableOperationListFromHistoryInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableOperationHistoryInq */
virtual ::CORBA::Long  txDurableOperationHistoryInq (::pptDurableOperationHistoryInqResult& strDurableOperationHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableOperationHistoryInqInParam& strDurableOperationHistoryInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableOperationHistoryInq()";
        retVal =        PPTManager_i::txDurableOperationHistoryInq ( strDurableOperationHistoryInqResult, strObjCommonIn, strDurableOperationHistoryInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableOpeLocateReq */
virtual ::CORBA::Long  txDurableOpeLocateReq (::pptDurableOpeLocateReqResult& strDurableOpeLocateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableOpeLocateReqInParam& strDurableOpeLocateReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableOpeLocateReq()";
        retVal =        PPTManager_i::txDurableOpeLocateReq ( strDurableOpeLocateReqResult, strObjCommonIn, strDurableOpeLocateReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableForceOpeLocateReq */
virtual ::CORBA::Long  txDurableForceOpeLocateReq (::pptDurableForceOpeLocateReqResult& strDurableForceOpeLocateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableForceOpeLocateReqInParam& strDurableForceOpeLocateReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableForceOpeLocateReq()";
        retVal =        PPTManager_i::txDurableForceOpeLocateReq ( strDurableForceOpeLocateReqResult, strObjCommonIn, strDurableForceOpeLocateReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txWhatNextDurableListInq */
virtual ::CORBA::Long  txWhatNextDurableListInq (::pptWhatNextDurableListInqResult& strWhatNextDurableListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptWhatNextDurableListInqInParam& strWhatNextDurableListInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txWhatNextDurableListInq()";
        retVal =        PPTManager_i::txWhatNextDurableListInq ( strWhatNextDurableListInqResult, strObjCommonIn, strWhatNextDurableListInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableGatePassReq */
virtual ::CORBA::Long  txDurableGatePassReq (::pptDurableGatePassReqResult& strDurableGatePassReqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long seqIndex, const ::pptDurableGatePassReqInParam& strDurableGatePassReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableGatePassReq()";
        retVal =        PPTManager_i::txDurableGatePassReq ( strDurableGatePassReqResult, strObjCommonIn, seqIndex, strDurableGatePassReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurablesInfoForStartReservationInq */
virtual ::CORBA::Long  txDurablesInfoForStartReservationInq (::pptDurablesInfoForStartReservationInqResult& strDurablesInfoForStartReservationInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurablesInfoForStartReservationInqInParam& strDurablesInfoForStartReservationInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurablesInfoForStartReservationInq()";
        retVal =        PPTManager_i::txDurablesInfoForStartReservationInq ( strDurablesInfoForStartReservationInqResult, strObjCommonIn, strDurablesInfoForStartReservationInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRouteIndexListInq__160 */
virtual ::CORBA::Long  txRouteIndexListInq__160 (::pptRouteIndexListInqResult& strRouteIndexListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* routeType, const ::objectIdentifier& lotID, const char* procDefType, ::CORBA::Boolean activeShowFlag, const char* bankID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRouteIndexListInq__160()";
        retVal =        PPTManager_i::txRouteIndexListInq__160 ( strRouteIndexListInqResult, strObjCommonIn, routeType, lotID, procDefType, activeShowFlag, bankID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRunDurableBRScriptReq */
virtual ::CORBA::Long  txRunDurableBRScriptReq (::pptRunDurableBRScriptReqResult& strRunDurableBRScriptReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRunDurableBRScriptReqInParam& strRunDurableBRScriptReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRunDurableBRScriptReq()";
        retVal =        PPTManager_i::txRunDurableBRScriptReq ( strRunDurableBRScriptReqResult, strObjCommonIn, strRunDurableBRScriptReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurablePostProcessActionRegistReq */
virtual ::CORBA::Long  txDurablePostProcessActionRegistReq (::pptDurablePostProcessActionRegistReqResult& strDurablePostProcessActionRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurablePostProcessActionRegistReqInParam& strDurablePostProcessActionRegistReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurablePostProcessActionRegistReq()";
        retVal =        PPTManager_i::txDurablePostProcessActionRegistReq ( strDurablePostProcessActionRegistReqResult, strObjCommonIn, strDurablePostProcessActionRegistReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRouteOperationListForDurableInq */
virtual ::CORBA::Long  txRouteOperationListForDurableInq (::pptRouteOperationListForDurableInqResult& strRouteOperationListForDurableInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRouteOperationListForDurableInqInParam& strRouteOperationListForDurableInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRouteOperationListForDurableInq()";
        retVal =        PPTManager_i::txRouteOperationListForDurableInq ( strRouteOperationListForDurableInqResult, strObjCommonIn, strRouteOperationListForDurableInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableBankInByPostProcReq */
virtual ::CORBA::Long  txDurableBankInByPostProcReq (::pptDurableBankInByPostProcReqResult& strDurableBankInByPostProcReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableBankInByPostProcReqInParam& strDurableBankInByPostProcReqInParam, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableBankInByPostProcReq()";
        retVal =        PPTManager_i::txDurableBankInByPostProcReq ( strDurableBankInByPostProcReqResult, strObjCommonIn, strDurableBankInByPostProcReqInParam, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpListByOperationForDurableInq */
virtual ::CORBA::Long  txEqpListByOperationForDurableInq (::pptEqpListByOperationForDurableInqResult& strEqpListByOperationForDurableInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpListByOperationForDurableInqInParam& strEqpListByOperationForDurableInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpListByOperationForDurableInq()";
        retVal =        PPTManager_i::txEqpListByOperationForDurableInq ( strEqpListByOperationForDurableInqResult, strObjCommonIn, strEqpListByOperationForDurableInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txVirtualOperationLotListInq */
virtual ::CORBA::Long  txVirtualOperationLotListInq (::pptVirtualOperationLotListInqResult& strVirtualOperationLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptVirtualOperationLotListInqInParam& strVirtualOperationLotListInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txVirtualOperationLotListInq()";
        retVal =        PPTManager_i::txVirtualOperationLotListInq ( strVirtualOperationLotListInqResult, strObjCommonIn, strVirtualOperationLotListInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotInfoInq__160 */
virtual ::CORBA::Long  txLotInfoInq__160 (::pptLotInfoInqResult__160& strLotInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifierSequence& lotID, ::CORBA::Boolean lotBasicInfoFlag, ::CORBA::Boolean lotControlUseInfoFlag, ::CORBA::Boolean lotFlowBatchInfoFlag, ::CORBA::Boolean lotNoteFlagInfoFlag, ::CORBA::Boolean lotOperationInfoFlag, ::CORBA::Boolean lotOrderInfoFlag, ::CORBA::Boolean lotControlJobInfoFlag, ::CORBA::Boolean lotProductInfoFlag, ::CORBA::Boolean lotRecipeInfoFlag, ::CORBA::Boolean lotLocationInfoFlag, ::CORBA::Boolean lotWipOperationInfoFlag, ::CORBA::Boolean lotWaferAttributesFlag, ::CORBA::Boolean lotListInCassetteInfoFlag, ::CORBA::Boolean waferMapInCassetteInfoFlag, ::CORBA::Boolean lotBackupInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotInfoInq__160()";
        retVal =        PPTManager_i::txLotInfoInq__160 ( strLotInfoInqResult, strObjCommonIn, lotID, lotBasicInfoFlag, lotControlUseInfoFlag, lotFlowBatchInfoFlag, lotNoteFlagInfoFlag, lotOperationInfoFlag, lotOrderInfoFlag, lotControlJobInfoFlag, lotProductInfoFlag, lotRecipeInfoFlag, lotLocationInfoFlag, lotWipOperationInfoFlag, lotWaferAttributesFlag, lotListInCassetteInfoFlag, waferMapInCassetteInfoFlag, lotBackupInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotListInq__160 */
virtual ::CORBA::Long  txLotListInq__160 (::pptLotListInqResult__160& strLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotStatus, const char* lotType, const ::objectIdentifier& productID, const char* orderNumber, const char* customerCode, const ::objectIdentifier& manufacturingLayerID, const ::objectIdentifier& routeID, const char* operationNumber, ::CORBA::Boolean bankInRequiredFlag, const ::objectIdentifier& lotID, const char* requiredCassetteCategory, ::CORBA::Boolean backupProcessingFlag, const char* subLotType, ::CORBA::Boolean deleteLotFlag, const ::objectIdentifier& holdReasonCodeID, ::CORBA::Boolean sorterJobCreationCheckFlag, const char* interFabXferState, ::CORBA::Boolean autoDispatchControlLotFlag, ::CORBA::Boolean virtualOperationFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotListInq__160()";
        retVal =        PPTManager_i::txLotListInq__160 ( strLotListInqResult, strObjCommonIn, bankID, lotStatus, lotType, productID, orderNumber, customerCode, manufacturingLayerID, routeID, operationNumber, bankInRequiredFlag, lotID, requiredCassetteCategory, backupProcessingFlag, subLotType, deleteLotFlag, holdReasonCodeID, sorterJobCreationCheckFlag, interFabXferState, autoDispatchControlLotFlag, virtualOperationFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRouteOperationListInq__160 */
virtual ::CORBA::Long  txRouteOperationListInq__160 (::pptRouteOperationListInqResult__160& strRouteOperationListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const char* pdType, ::CORBA::Long searchCount, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRouteOperationListInq__160()";
        retVal =        PPTManager_i::txRouteOperationListInq__160 ( strRouteOperationListInqResult, strObjCommonIn, routeID, operationID, operationNumber, pdType, searchCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotOperationListInq__160 */
virtual ::CORBA::Long  txLotOperationListInq__160 (::pptLotOperationListInqResult__160& strLotOperationListInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean searchDirection, ::CORBA::Boolean posSearchFlag, ::CORBA::Long searchCount, ::CORBA::Boolean currentFlag, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotOperationListInq__160()";
        retVal =        PPTManager_i::txLotOperationListInq__160 ( strLotOperationListInqResult, strObjCommonIn, searchDirection, posSearchFlag, searchCount, currentFlag, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotOperationListFromHistoryInq__160 */
virtual ::CORBA::Long  txLotOperationListFromHistoryInq__160 (::pptLotOperationListFromHistoryInqResult__160& strLotOperationListFromHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Long searchCount, const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotOperationListFromHistoryInq__160()";
        retVal =        PPTManager_i::txLotOperationListFromHistoryInq__160 ( strLotOperationListFromHistoryInqResult, strObjCommonIn, searchCount, lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txOperationHistoryInq__160 */
virtual ::CORBA::Long  txOperationHistoryInq__160 (::pptOperationHistoryInqResult__160& strOperationHistoryInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const char* operationPass, const char* operationCategory, ::CORBA::Boolean pinPointFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txOperationHistoryInq__160()";
        retVal =        PPTManager_i::txOperationHistoryInq__160 ( strOperationHistoryInqResult, strObjCommonIn, lotID, routeID, operationID, operationNumber, operationPass, operationCategory, pinPointFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReleasedLotListInq__160 */
virtual ::CORBA::Long  txReleasedLotListInq__160 (::pptReleasedLotListInqResult__160& strReleasedLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReleasedLotListInqInParm__160& strReleasedLotListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReleasedLotListInq__160()";
        retVal =        PPTManager_i::txReleasedLotListInq__160 ( strReleasedLotListInqResult, strObjCommonIn, strReleasedLotListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txProductIDListInq__160 */
virtual ::CORBA::Long  txProductIDListInq__160 (::pptProductIDListInqResult& strProductIDListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptProductIDListInqInParm__160& strProductIDListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txProductIDListInq__160()";
        retVal =        PPTManager_i::txProductIDListInq__160 ( strProductIDListInqResult, strObjCommonIn, strProductIDListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txEqpNoteRegistReq__160 */
virtual ::CORBA::Long  txEqpNoteRegistReq__160 (::pptEqpNoteRegistReqResult& strEqpNoteRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const char* noteTitle, const char* equipmentNote, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txEqpNoteRegistReq__160()";
        retVal =        PPTManager_i::txEqpNoteRegistReq__160 ( strEqpNoteRegistReqResult, strObjCommonIn, equipmentID, noteTitle, equipmentNote, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotNoteInfoRegistReq__160 */
virtual ::CORBA::Long  txLotNoteInfoRegistReq__160 (::pptLotNoteInfoRegistReqResult& strLotNoteInfoRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* lotNoteTitle, const char* lotNoteDescription, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotNoteInfoRegistReq__160()";
        retVal =        PPTManager_i::txLotNoteInfoRegistReq__160 ( strLotNoteInfoRegistReqResult, strObjCommonIn, lotID, lotNoteTitle, lotNoteDescription, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotOperationNoteInfoRegistReq__160 */
virtual ::CORBA::Long  txLotOperationNoteInfoRegistReq__160 (::pptLotOperationNoteInfoRegistReqResult& strLotOperationNoteInfoRegistReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::objectIdentifier& routeID, const ::objectIdentifier& operationID, const char* operationNumber, const char* lotOperationNoteTitle, const char* lotOperationNoteDescription, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotOperationNoteInfoRegistReq__160()";
        retVal =        PPTManager_i::txLotOperationNoteInfoRegistReq__160 ( strLotOperationNoteInfoRegistReqResult, strObjCommonIn, lotID, routeID, operationID, operationNumber, lotOperationNoteTitle, lotOperationNoteDescription, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotCassetteXferStatusChangeRpt__160 */
virtual ::CORBA::Long  txLotCassetteXferStatusChangeRpt__160 (::pptLotCassetteXferStatusChangeRptResult& strLotCassetteXferStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& carrierID, const char* xferStatus, ::CORBA::Boolean ManualInFlag, const ::objectIdentifier& machineID, const ::objectIdentifier& portID, const char* zoneID, const char* shelfType, const char* transferStatusChangeTimeStamp, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotCassetteXferStatusChangeRpt__160()";
        retVal =        PPTManager_i::txLotCassetteXferStatusChangeRpt__160 ( strLotCassetteXferStatusChangeRptResult, strObjCommonIn, carrierID, xferStatus, ManualInFlag, machineID, portID, zoneID, shelfType, transferStatusChangeTimeStamp, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodXferStatusChangeRpt__160 */
virtual ::CORBA::Long  txReticlePodXferStatusChangeRpt__160 (::pptReticlePodXferStatusChangeRptResult& strReticlePodXferStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptXferReticlePodSequence& strXferReticlePod, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodXferStatusChangeRpt__160()";
        retVal =        PPTManager_i::txReticlePodXferStatusChangeRpt__160 ( strReticlePodXferStatusChangeRptResult, strObjCommonIn, requestUserID, stockerID, equipmentID, strXferReticlePod, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleXferStatusChangeRpt__160 */
virtual ::CORBA::Long  txReticleXferStatusChangeRpt__160 (::pptReticleXferStatusChangeRptResult& strReticleXferStatusChangeRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& stockerID, const ::objectIdentifier& equipmentID, const ::pptXferReticleSequence& strXferReticle, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleXferStatusChangeRpt__160()";
        retVal =        PPTManager_i::txReticleXferStatusChangeRpt__160 ( strReticleXferStatusChangeRptResult, strObjCommonIn, stockerID, equipmentID, strXferReticle, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCommonEqpInfoInq */
virtual ::CORBA::Long  txCommonEqpInfoInq (::pptCommonEqpInfoInqResult& strCommonEqpInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForInternalBufferInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Boolean requestFlagForRSPPortInfo, ::CORBA::Boolean requestFlagForEqpContainerInfo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCommonEqpInfoInq()";
        retVal =        PPTManager_i::txCommonEqpInfoInq ( strCommonEqpInfoInqResult, strObjCommonIn, equipmentID, requestFlagForBRInfo, requestFlagForStatusInfo, requestFlagForPMInfo, requestFlagForPortInfo, requestFlagForChamberInfo, requestFlagForInternalBufferInfo, requestFlagForStockerInfo, requestFlagForInprocessingLotInfo, requestFlagForReservedControlJobInfo, requestFlagForRSPPortInfo, requestFlagForEqpContainerInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLotFutureActionDetailInfoInq__160 */
virtual ::CORBA::Long  txLotFutureActionDetailInfoInq__160 (::pptLotFutureActionDetailInfoInqResult__160& strLotFutureActionDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLotFutureActionDetailInfoInqInParm& strLotFutureActionDetailInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLotFutureActionDetailInfoInq__160()";
        retVal =        PPTManager_i::txLotFutureActionDetailInfoInq__160 ( strLotFutureActionDetailInfoInqResult, strObjCommonIn, strLotFutureActionDetailInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeListInq__160 */
virtual ::CORBA::Long  txQrestTimeListInq__160 (::pptQrestTimeListInqResult__160& strQrestTimeListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, ::CORBA::Boolean activeQTime, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeListInq__160()";
        retVal =        PPTManager_i::txQrestTimeListInq__160 ( strQrestTimeListInqResult, strObjCommonIn, lotID, activeQTime, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeUpdateReq__160 */
virtual ::CORBA::Long  txQrestTimeUpdateReq__160 (::pptQrestTimeUpdateReqResult& strQrestTimeUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptQrestTimeUpdateReqInParm__160& strQrestTimeUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeUpdateReq__160()";
        retVal =        PPTManager_i::txQrestTimeUpdateReq__160 ( strQrestTimeUpdateReqResult, strObjCommonIn, strQrestTimeUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeCandidateInq__160 */
virtual ::CORBA::Long  txQrestTimeCandidateInq__160 (::pptQrestTimeCandidateInqResult__160& strQrestTimeCandidateInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptQrestTimeCandidateInqInParm& strQrestTimeCandidateInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeCandidateInq__160()";
        retVal =        PPTManager_i::txQrestTimeCandidateInq__160 ( strQrestTimeCandidateInqResult, strObjCommonIn, strQrestTimeCandidateInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txQrestTimeActionExecReq__160 */
virtual ::CORBA::Long  txQrestTimeActionExecReq__160 (::pptQrestTimeActionExecReqResult& strQrestTimeActionExecReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const char* lotStatus, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& equipmentID, const ::pptQrestTimeAction__160& strQrestTimeAction, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txQrestTimeActionExecReq__160()";
        retVal =        PPTManager_i::txQrestTimeActionExecReq__160 ( strQrestTimeActionExecReqResult, strObjCommonIn, lotID, lotStatus, routeID, operationNumber, equipmentID, strQrestTimeAction, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::lot_qtimeInfo_SortByAction__160 */
virtual ::CORBA::Long  lot_qtimeInfo_SortByAction__160 (::objLot_qtimeInfo_SortByAction_out__160& strLot_qtimeInfo_SortByAction_out, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotID, const ::pptQtimeInfoSequence__160& strQtimeInfoSeq, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::lot_qtimeInfo_SortByAction__160()";
        retVal =        PPTManager_i::lot_qtimeInfo_SortByAction__160 ( strLot_qtimeInfo_SortByAction_out, strObjCommonIn, lotID, strQtimeInfoSeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txBankListInq__160 */
virtual ::CORBA::Long  txBankListInq__160 (::pptBankListInqResult& strBankListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* inqBank, const ::objectIdentifier& bankID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txBankListInq__160()";
        retVal =        PPTManager_i::txBankListInq__160 ( strBankListInqResult, strObjCommonIn, inqBank, bankID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txRouteOperationNestListInq */
virtual ::CORBA::Long  txRouteOperationNestListInq (::pptRouteOperationNestListInqResult& strRouteOperationNestListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptRouteOperationNestListInqInParam& strRouteOperationNestListInqInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txRouteOperationNestListInq()";
        retVal =        PPTManager_i::txRouteOperationNestListInq ( strRouteOperationNestListInqResult, strObjCommonIn, strRouteOperationNestListInqInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txFPCDetailInfoInq__160 */
virtual ::CORBA::Long  txFPCDetailInfoInq__160 (::pptFPCDetailInfoInqResult__160& strFPCDetailInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptFPCDetailInfoInqInParm& strFPCDetailInfoInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txFPCDetailInfoInq__160()";
        retVal =        PPTManager_i::txFPCDetailInfoInq__160 ( strFPCDetailInfoInqResult, strObjCommonIn, strFPCDetailInfoInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txExperimentalLotListInq__160 */
virtual ::CORBA::Long  txExperimentalLotListInq__160 (::pptExperimentalLotListInqResult__160& strExperimentalLotListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& lotFamilyID, ::CORBA::Boolean detailRequireFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txExperimentalLotListInq__160()";
        retVal =        PPTManager_i::txExperimentalLotListInq__160 ( strExperimentalLotListInqResult, strObjCommonIn, lotFamilyID, detailRequireFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::lot_postProcessPreviousBranchAndReturnInfo_GetDR__150 */
virtual ::CORBA::Long  lot_postProcessPreviousBranchAndReturnInfo_GetDR__150 (::objLot_postProcessPreviousBranchAndReturnInfo_GetDR_out__150& strLot_postProcessPreviousBranchAndReturnInfo_GetDR_out, const ::pptObjCommonIn& strObjCommonIn, const ::objLot_postProcessPreviousBranchAndReturnInfo_GetDR_in& strLot_postProcessPreviousBranchAndReturnInfo_GetDR_in, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::lot_postProcessPreviousBranchAndReturnInfo_GetDR__150()";
        retVal =        PPTManager_i::lot_postProcessPreviousBranchAndReturnInfo_GetDR__150 ( strLot_postProcessPreviousBranchAndReturnInfo_GetDR_out, strObjCommonIn, strLot_postProcessPreviousBranchAndReturnInfo_GetDR_in, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txLERRpt */
virtual ::CORBA::Long  txLERRpt (::pptLERRptResult& strLERRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptLERRptInParam& strLERRptInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txLERRpt()";
        retVal =        PPTManager_i::txLERRpt ( strLERRptResult, strObjCommonIn, strLERRptInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDataReportEndRpt */
virtual ::CORBA::Long  txDataReportEndRpt (::pptDataReportEndRptResult& strDataReportEndRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDataReportEndRptInParam& strDataReportEndRptInParam, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDataReportEndRpt()";
        retVal =        PPTManager_i::txDataReportEndRpt ( strDataReportEndRptResult, strObjCommonIn, strDataReportEndRptInParam, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCandidateDurableSubStatusInq */
virtual ::CORBA::Long  txCandidateDurableSubStatusInq (::pptCandidateDurableSubStatusInqResult& strCandidateDurableSubStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptCandidateDurableSubStatusInqInParm& strCandidateDurableSubStatusInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCandidateDurableSubStatusInq()";
        retVal =        PPTManager_i::txCandidateDurableSubStatusInq ( strCandidateDurableSubStatusInqResult, strObjCommonIn, strCandidateDurableSubStatusInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableStatusMultiChangeReq */
virtual ::CORBA::Long  txDurableStatusMultiChangeReq (::pptDurableStatusMultiChangeReqResult& strDurableStatusMultiChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableStatusMultiChangeReqInParm& strDurableStatusMultiChangeReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableStatusMultiChangeReq()";
        retVal =        PPTManager_i::txDurableStatusMultiChangeReq ( strDurableStatusMultiChangeReqResult, strObjCommonIn, strDurableStatusMultiChangeReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableProcessLagTimeUpdateReq */
virtual ::CORBA::Long  txDurableProcessLagTimeUpdateReq (::pptDurableProcessLagTimeUpdateReqResult& strDurableProcessLagTimeUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableProcessLagTimeUpdateReqInParm& strDurableProcessLagTimeUpdateReqInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableProcessLagTimeUpdateReq()";
        retVal =        PPTManager_i::txDurableProcessLagTimeUpdateReq ( strDurableProcessLagTimeUpdateReqResult, strObjCommonIn, strDurableProcessLagTimeUpdateReqInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteListInq__170 */
virtual ::CORBA::Long  txCassetteListInq__170 (::pptCassetteListInqResult__170& strCassetteListInqResult, const ::pptObjCommonIn& strObjCommonIn, const char* cassetteCategory, ::CORBA::Boolean emptyFlag, const ::objectIdentifier& stockerID, const ::objectIdentifier& cassetteID, const char* cassetteStatus, const ::objectIdentifier& durableSubStatus, const char* flowStatus, ::CORBA::Long maxRetrieveCount, ::CORBA::Boolean sorterJobCreationCheckFlag, const char* interFabXferState, const ::objectIdentifier& bankID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteListInq__170()";
        retVal =        PPTManager_i::txCassetteListInq__170 ( strCassetteListInqResult, strObjCommonIn, cassetteCategory, emptyFlag, stockerID, cassetteID, cassetteStatus, durableSubStatus, flowStatus, maxRetrieveCount, sorterJobCreationCheckFlag, interFabXferState, bankID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodListInq__170 */
virtual ::CORBA::Long  txReticlePodListInq__170 (::pptReticlePodListInqResult__170& strReticlePodListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptUser& requestUserID, const ::objectIdentifier& reticlePodID, const char* reticlePodCategory, const char* reticlePodStatus, const ::objectIdentifier& durableSubStatus, const char* flowStatus, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, ::CORBA::Boolean emptyFlag, const ::objectIdentifier& reticleID, const ::objectIdentifier& reticleGroupID, const char* reticlePartNumber, ::CORBA::Long maxRetrieveCount, const ::objectIdentifier& bankID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodListInq__170()";
        retVal =        PPTManager_i::txReticlePodListInq__170 ( strReticlePodListInqResult, strObjCommonIn, requestUserID, reticlePodID, reticlePodCategory, reticlePodStatus, durableSubStatus, flowStatus, equipmentID, stockerID, emptyFlag, reticleID, reticleGroupID, reticlePartNumber, maxRetrieveCount, bankID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleListInq__170 */
virtual ::CORBA::Long  txReticleListInq__170 (::pptReticleListInqResult__170& strReticleListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptReticleListInqInParm__170& strReticleListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleListInq__170()";
        retVal =        PPTManager_i::txReticleListInq__170 ( strReticleListInqResult, strObjCommonIn, strReticleListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txCassetteStatusInq__170 */
virtual ::CORBA::Long  txCassetteStatusInq__170 (::pptCassetteStatusInqResult__170& strCassetteStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Boolean durableOperationInfoFlag, ::CORBA::Boolean durableWipOperationInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txCassetteStatusInq__170()";
        retVal =        PPTManager_i::txCassetteStatusInq__170 ( strCassetteStatusInqResult, strObjCommonIn, cassetteID, durableOperationInfoFlag, durableWipOperationInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticlePodStatusInq__170 */
virtual ::CORBA::Long  txReticlePodStatusInq__170 (::pptReticlePodStatusInqResult__170& strReticlePodStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticlePodID, ::CORBA::Boolean durableOperationInfoFlag, ::CORBA::Boolean durableWipOperationInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticlePodStatusInq__170()";
        retVal =        PPTManager_i::txReticlePodStatusInq__170 ( strReticlePodStatusInqResult, strObjCommonIn, reticlePodID, durableOperationInfoFlag, durableWipOperationInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txReticleStatusInq__170 */
virtual ::CORBA::Long  txReticleStatusInq__170 (::pptReticleStatusInqResult__170& strReticleStatusInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, ::CORBA::Boolean durableOperationInfoFlag, ::CORBA::Boolean durableWipOperationInfoFlag, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txReticleStatusInq__170()";
        retVal =        PPTManager_i::txReticleStatusInq__170 ( strReticleStatusInqResult, strObjCommonIn, reticleID, durableOperationInfoFlag, durableWipOperationInfoFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txSourceLotInq__170 */
virtual ::CORBA::Long  txSourceLotInq__170 (::pptSourceLotInqResult__170& strSourceLotInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& productID, const ::objectIdentifier& productRequestID, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txSourceLotInq__170()";
        retVal =        PPTManager_i::txSourceLotInq__170 ( strSourceLotInqResult, strObjCommonIn, productID, productRequestID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDataCollectionItemListInq */
virtual ::CORBA::Long  txDataCollectionItemListInq (::pptDataCollectionItemListInqResult& strDataCollectionItemListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDataCollectionItemListInqInParm& strDataCollectionItemListInqInParm, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDataCollectionItemListInq()";
        retVal =        PPTManager_i::txDataCollectionItemListInq ( strDataCollectionItemListInqResult, strObjCommonIn, strDataCollectionItemListInqInParm, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PPTManager::txDurableXferJobStatusRpt */
virtual ::CORBA::Long  txDurableXferJobStatusRpt (::pptDurableXferJobStatusRptResult& strDurableXferJobStatusRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptDurableXferJobStatusRptInParm& strDurableXferJobStatusRptInParm, const char* claimMemo, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::txDurableXferJobStatusRpt()";
        retVal =        PPTManager_i::txDurableXferJobStatusRpt ( strDurableXferJobStatusRptResult, strObjCommonIn, strDurableXferJobStatusRptInParm, claimMemo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PPTManager_i::TxnUnlock()";
        retVal =        PPTManager_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

