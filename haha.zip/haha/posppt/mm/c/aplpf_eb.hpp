// SCCS ID: @(#) 1.1 superpos/src/spclass/spfwbins/aplpf_eb.hpp, mm_srv_90e_spcl, mm_srv_90e_spcl 4/20/07 14:15:07 [ 7/14/07 00:36:26 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview standard
// Name:aplpf_eb.hpp
// // Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- --------------------------------------------
// 12/22/04 D6000025 S.Yamamoto     Initial Release 
//

//----------------------------------------------------------------------------
//
//  Generated from aplpf_eb.idl
//  On Tuesday, November 30, 2004 6:16:09 PM JST
//  by IBM CORBA 2.3 (ih) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _aplpf_eb_ih_included
#define _aplpf_eb_ih_included
    //====================================================//
    // DEVELOPER_NOTE:                                    //
    // The classes and code emitted in this file are      //
    // provided to assist you in the development of your  //
    // implementation objects, valuetypes, and valuetype  //
    // factories.  It is your responsibility to provide   //
    // the method implementations (see the corresponding  //
    // <name>_I.cpp file).  There are alternative         //
    // ways to design the implementation classes.         //
    // The following code represents one design approach. //
    //                                                    //
    // Please search for DEVELOPER_NOTE in this file      //
    // to locate all of the places where you              //
    // may need to examine, add, or modify code.          //
    //====================================================//


// DEVELOPER_NOTE: The included .ih files are only necessary if one of your
//    implementation classes inherits or uses an implementation from another
//    .ih file.  If this is not the case, you can safely delete the #include.

#ifdef SOMCBNOLOCALINCLUDES
#include <PortableInterceptor.ih>
#else
#include "PortableInterceptor.ih"
#endif
#ifdef SOMCBNOLOCALINCLUDES
#include <aplpf_eb.hh>
#else
#include "aplpf_eb.hh"
#endif

class ApplicationProcessFilterInitializer_Impl : public virtual ::ApplicationProcessFilterInitializerBOAImpl, public virtual PortableInterceptor_ORBInitializer_Impl{

   public:
        virtual ::CORBA::Void pre_init ( ::PortableInterceptor::ORBInitInfo_ptr info );
        virtual ::CORBA::Void post_init ( ::PortableInterceptor::ORBInitInfo_ptr info );
};

class ApplicationProcessFilterRI_Impl : public virtual ::ApplicationProcessFilterRIBOAImpl, public virtual PortableInterceptor_ServerRequestInterceptor_Impl{

   public:
//        virtual ::CORBA::Void receive_request_service_contexts (::PortableInterceptor::ServerRequestInfo_ptr ri);
        virtual ::CORBA::Void receive_request (::PortableInterceptor::ServerRequestInfo_ptr ri);
        virtual ::CORBA::Void send_reply (::PortableInterceptor::ServerRequestInfo_ptr ri);
        virtual ::CORBA::Void send_exception (::PortableInterceptor::ServerRequestInfo_ptr ri);
        virtual ::CORBA::Void send_other (::PortableInterceptor::ServerRequestInfo_ptr ri);

        int SignalsDefault;
        int bInitFlg;
};

void initApplicationProcessFilter();

#endif /* _aplpf_eb_ih_included */
