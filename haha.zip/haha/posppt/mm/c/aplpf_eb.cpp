#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spclass/spfwbins/aplpf_eb.cpp, mm_srv_90e_spcl, mm_srv_90e_spcl 1/7/08 19:09:40 [ 1/7/08 19:09:41 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview
// Name: aplpf_eb.cpp
// Description:
//   This is mainline for Material Manager server.
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 12/22/04 D6000025 S.Yamamoto     Initial Release
// 11/27/05 D7000066 T.Ohsaki       Add new logic for TraceLog filtering IMCG and direct FW method call
// 11/07/07 P9000062 M.Ishino       Change of the filter logic for Ebroker version. 
// 01/07/08 P9000159 M.Ishino       Fix memory fault by receive_request


#include "aplpf_eb.hh"
#include "aplpf_eb.hpp"

#include "tracelogmgr.hpp"

#include <stdio.h>
#include <stdlib.h>

#define SPMAIN_TRACE_VERBOSE1(a)
//#define SPMAIN_TRACE_VERBOSE1(a) cout << a << endl;

void initApplicationProcessFilter()
{
    ApplicationProcessFilterInitializer_ptr initObj = new ApplicationProcessFilterInitializer_Impl();
    PortableInterceptor::register_orb_initializer ( initObj );
}

void ApplicationProcessFilterInitializer_Impl::pre_init ( ::PortableInterceptor::ORBInitInfo_ptr info )
{
    ApplicationProcessFilterRI_Impl *riObj = new ApplicationProcessFilterRI_Impl();
    info->add_server_request_interceptor ( riObj );
    CORBA::release ( riObj );

    char *p = getenv("SP_OTSSIGNALHANDLER_ENABLED");
    if ( p == NULL || atoi(p) != 1 )
    {
        cout << "******************* Default signal handlers are enabled **********************" << endl;
        SPMAIN_TRACE_VERBOSE1("Default signal handlers are enabled");
        riObj->SignalsDefault= 1;
        signal( SIGSEGV, SIG_DFL);
        signal( SIGILL , SIG_DFL);
    }
    else
    {
        SPMAIN_TRACE_VERBOSE1("OTS signal handlers are enabled");
    }
    
    riObj->bInitFlg = FALSE;
}
void ApplicationProcessFilterInitializer_Impl::post_init ( ::PortableInterceptor::ORBInitInfo_ptr info )
{
}

void ApplicationProcessFilterRI_Impl::receive_request (::PortableInterceptor::ServerRequestInfo_ptr info)
{
    SPMAIN_TRACE_VERBOSE1("ApplicationProcessFilterRI_Impl::receive_request start");
    CORBA::String              opname        = info->operation();
    
    int *pFlag = allocateTraceEnabledThreadFlag();
//D7000066    if ( theTraceLogManager->isFiltered(opname, NULL, NULL) == TRUE )
//D7000066    {
//D7000066        *pFlag = TRUE;
//D7000066    }
//D7000066    else
//D7000066    {
//D7000066        *pFlag = FALSE;
//D7000066    }

//D7000066 Add Start 
//P9000062    if( strncmp(info->target_most_derived_interface(),"IDL:PPTServiceManager",21) == 0 )  //when Large TX
//P9000159//P9000062 Add start
//P9000159    if( strncmp(info->target_most_derived_interface(),"IDL:CS_PPTServiceManager",24) == 0 ||
//P9000159        strncmp(info->target_most_derived_interface(),"IDL:PPTServiceManager",21)    == 0  )  //when Large TX
//P9000159//P9000062 Add end

//P9000159 Add start
    CORBA::String_var interfaceName = info->target_most_derived_interface();
    if( strncmp( interfaceName,"IDL:CS_PPTServiceManager",24 ) == 0 ||
        strncmp( interfaceName,"IDL:PPTServiceManager"   ,21 ) == 0  )  //when Large TX
//P9000159 Add end
    {
        if ( theTraceLogManager->isFiltered(opname, NULL, NULL) == TRUE )
        {
            *pFlag = TRUE;
        }
        else
        {
            *pFlag = FALSE;
        }
    }
    else             // when other subsystems WTDG,SM...
    {
        if( TraceLogManager_i::TraceEnabled == TRUE  && theTraceLogManager_i->isFilterKeywordsSet() == FALSE )
        {
            *pFlag = TRUE;
        }
        else
        {
            *pFlag = FALSE;
        }
    }
//D7000066 Add End
    
    if ( bInitFlg == FALSE )
    {
        if ( SignalsDefault )
        {
            SPMAIN_TRACE_VERBOSE1("Default signal handlers are enabled");
            signal( SIGSEGV, SIG_DFL );
            signal( SIGILL , SIG_DFL );
        }
        else
        {
            SPMAIN_TRACE_VERBOSE1("OTS signal handlers are enabled");
        }
        bInitFlg = TRUE;
    }
    SPMAIN_TRACE_VERBOSE1("ApplicationProcessFilterRI_Impl::receive_request end");
}

void ApplicationProcessFilterRI_Impl::send_reply (::PortableInterceptor::ServerRequestInfo_ptr info)
{
    SPMAIN_TRACE_VERBOSE1("ApplicationProcessFilterRI_Impl::send_reply start");
    int *pFlag = isTraceEnabledThread();
    *pFlag = FALSE;
    SPMAIN_TRACE_VERBOSE1("ApplicationProcessFilterRI_Impl::send_reply end");
}

void ApplicationProcessFilterRI_Impl::send_exception(::PortableInterceptor::ServerRequestInfo_ptr info)
{
    SPMAIN_TRACE_VERBOSE1("ApplicationProcessFilterRI_Impl::send_exception start");
    int *pFlag = isTraceEnabledThread();
    *pFlag = FALSE;
    SPMAIN_TRACE_VERBOSE1("ApplicationProcessFilterRI_Impl::send_exception end");
}

void ApplicationProcessFilterRI_Impl::send_other (::PortableInterceptor::ServerRequestInfo_ptr info)
{
    SPMAIN_TRACE_VERBOSE1("ApplicationProcessFilterRI_Impl::send_other start");
    int *pFlag = isTraceEnabledThread();
    *pFlag = FALSE;
    SPMAIN_TRACE_VERBOSE1("ApplicationProcessFilterRI_Impl::send_other end");
}
