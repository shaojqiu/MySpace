//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Sunday, June 29, 2008 12:45:20 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/09 DSIV00001432 S.Kawabe       Support XLC version 9
// 2017/03/14 DSN000104324 Q.Li           Add PosDurableXferJobStatusChangeEvent

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1992,2017          *
*     (C) COPYRIGHT: IBM Japan Industrial Solution Co., Ltd, 1996,2017       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

#include "IMProt.h" //DSIV00001432

// Implementation header files
#include "pevalrm.hpp"
#include "pevapcif.hpp"
#include "pevapd.hpp"
#include "pevbkmv.hpp"
#include "pevbucn.hpp"
#include "pevbuop.hpp"
#include "pevcdc.hpp"
#include "pevcjsc.hpp"
#include "pevclctd.hpp"
#include "pevcmbs.hpp"
#include "pevdrbl.hpp"
#include "pevdrch.hpp"
#include "pevemcg.hpp"
#include "pevenin.hpp"
#include "peveqps.hpp"
#include "pevfbch.hpp"
#include "pevfbm.hpp"
#include "pevfhld.hpp"
#include "pevfpc.hpp"
#include "pevfrwk.hpp"
#include "pevifx.hpp"
#include "pevlhld.hpp"
#include "pevlrwk.hpp"
#include "pevltch.hpp"
#include "pevmg.hpp"
#include "pevopcp.hpp"
#include "pevopmv.hpp"
#include "pevopst.hpp"
#include "pevowch.hpp"
#include "pevpcst.hpp"
#include "pevphld.hpp"
#include "pevpjc.hpp"
#include "pevplsp.hpp"
#include "pevprrq.hpp"
#include "pevprts.hpp"
#include "pevrcbd.hpp"
#include "pevrset.hpp"
#include "pevrwp.hpp"
#include "pevscprcg.hpp"
#include "pevsmr.hpp"
#include "pevss.hpp"
#include "pevsysm.hpp"
#include "pevudc.hpp"
#include "pevvend.hpp"
#include "pevwfcp.hpp"
#include "pevwfmv.hpp"
#include "pevwscr.hpp"
#include "pevwsj.hpp"
#include "pevwsrt.hpp"
#include "pevbdgrp.hpp"
#include "pevwfst.hpp"
#include "pevadc.hpp"
#include "pevem.hpp"
#include "pevemj.hpp"
#include "pevemt.hpp"
#include "pevqtm.hpp"
#include "pevdcjs.hpp"
#include "pevdopc.hpp"
#include "pevdops.hpp"
#include "pevdpfx.hpp"
#include "pevdbrc.hpp" //DSN000096063
#include "pevdbkm.hpp"
#include "pevdhld.hpp"
#include "pevdopm.hpp"
#include "pevdrwk.hpp"
#include "pevnote.hpp" //PSN000081321
#include "pevepsc.hpp" //DSN000101505
#include "pevdxsc.hpp" //DSN000104324

//DSIV00001432 #include "IMProt.h"

// DO implementation header files
#include "DOBase_i.h"
#include "pevalrdo.hpp"
#include "pevapcdo.hpp"
#include "pevapddo.hpp"
#include "pevbkmdo.hpp"
#include "pevbucdo.hpp"
#include "pevbuodo.hpp"
#include "pevcdcdo.hpp"
#include "pevcjsdo.hpp"
#include "pevclcdo.hpp"
#include "pevcmbdo.hpp"
#include "pevdrbdo.hpp"
#include "pevdrcdo.hpp"
#include "pevemcdo.hpp"
#include "pevenido.hpp"
#include "peveqpdo.hpp"
#include "pevfbcdo.hpp"
#include "pevfbmdo.hpp"
#include "pevfhldo.hpp"
#include "pevfpcdo.hpp"
#include "pevfrwdo.hpp"
#include "pevifxdo.hpp"
#include "pevlhldo.hpp"
#include "pevlrwdo.hpp"
#include "pevltcdo.hpp"
#include "pevopcdo.hpp"
#include "pevopmdo.hpp"
#include "pevopsdo.hpp"
#include "pevowcdo.hpp"
#include "pevpcsdo.hpp"
#include "pevphldo.hpp"
#include "pevpjcdo.hpp"
#include "pevplsdo.hpp"
#include "pevprrdo.hpp"
#include "pevprtdo.hpp"
#include "pevrcbdo.hpp"
#include "pevrsedo.hpp"
#include "pevrwpdo.hpp"
#include "pevscpdo.hpp"
#include "pevsmrdo.hpp"
#include "pevssdo.hpp"
#include "pevsysdo.hpp"
#include "pevudcdo.hpp"
#include "pevvendo.hpp"
#include "pevwfcdo.hpp"
#include "pevwfmdo.hpp"
#include "pevwscdo.hpp"
#include "pevwsjdo.hpp"
#include "pevwsrdo.hpp"
#include "pevbdgdo.hpp"
#include "pevwfsdo.hpp"
#include "pevadcdo.hpp"
#include "pevemdo.hpp"
#include "pevemjdo.hpp"
#include "pevemtdo.hpp"
#include "pevqtmdo.hpp"
#include "pevdcjdo.hpp"
#include "pevdocdo.hpp"
#include "pevdosdo.hpp"
#include "pevdpxdo.hpp"
#include "pevdbrdo.hpp" //DSN000096063
#include "pevdbmdo.hpp"
#include "pevdhddo.hpp"
#include "pevdomdo.hpp"
#include "pevdrwdo.hpp"
#include "pevnotdo.hpp" //PSN000081321
#include "pevepsdo.hpp" //DSN000101505
#include "pevdxsdo.hpp" //DSN000104324

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

//GlobalComposedObjectTable* global_func()
void global_func_BOSPEvMg( GlobalComposedObjectTable* GCOT )
{
  //GlobalComposedObjectTable *GCOT = NULL;
  //GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosWaferChamberProcessEvent,
                        PosWaferChamberProcessEvent_DO_i,
                        PosWaferChamberProcessEventPosWaferChamberProcessEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotOperationMoveEvent,
                        PosLotOperationMoveEvent_DO_i,
                        PosLotOperationMoveEventPosLotOperationMoveEvent_i_m, GCOT);

    Create_PrototypeBOA(PosWaferSortJobEvent,
                        PosWaferSortJobEvent_DO_i,
                        PosWaferSortJobEventPosWaferSortJobEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotWaferMoveEvent,
                        PosLotWaferMoveEvent_DO_i,
                        PosLotWaferMoveEventPosLotWaferMoveEvent_i_m, GCOT);

    Create_PrototypeBOA(PosProcessResourceWaferPositionEvent,
                        PosProcessResourceWaferPositionEvent_DO_i,
                        PosProcessResourceWaferPositionEventPosProcessResourceWaferPositionEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurableChangeEvent,
                        PosDurableChangeEvent_DO_i,
                        PosDurableChangeEventPosDurableChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosProcessHoldEvent,
                        PosProcessHoldEvent_DO_i,
                        PosProcessHoldEventPosProcessHoldEvent_i_m, GCOT);

    Create_PrototypeBOA(PosUserDataChangeEvent,
                        PosUserDataChangeEvent_DO_i,
                        PosUserDataChangeEventPosUserDataChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosProductRequestEvent,
                        PosProductRequestEvent_DO_i,
                        PosProductRequestEventPosProductRequestEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotOperationCompleteEvent,
                        PosLotOperationCompleteEvent_DO_i,
                        PosLotOperationCompleteEventPosLotOperationCompleteEvent_i_m, GCOT);

    Create_PrototypeBOA(PosSLMSwitchEvent,
                        PosSLMSwitchEvent_DO_i,
                        PosSLMSwitchEventPosSLMSwitchEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEqpMonitorCountEvent,
                        PosEqpMonitorCountEvent_DO_i,
                        PosEqpMonitorCountEventPosEqpMonitorCountEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotBankMoveEvent,
                        PosLotBankMoveEvent_DO_i,
                        PosLotBankMoveEventPosLotBankMoveEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotHoldEvent,
                        PosLotHoldEvent_DO_i,
                        PosLotHoldEventPosLotHoldEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEntityInhibitEvent,
                        PosEntityInhibitEvent_DO_i,
                        PosEntityInhibitEventPosEntityInhibitEvent_i_m, GCOT);

    Create_PrototypeBOA(PosAPCInterfaceEvent,
                        PosAPCInterfaceEvent_DO_i,
                        PosAPCInterfaceEventPosAPCInterfaceEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEquipmentAlarmEvent,
                        PosEquipmentAlarmEvent_DO_i,
                        PosEquipmentAlarmEventPosEquipmentAlarmEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEventManager,
                        IMFW_DataObjectBase_i,
                        PosEventManagerPosEventManager_i_m, GCOT);

    Create_PrototypeBOA(PosLotReticleSetChangeEvent,
                        PosLotReticleSetChangeEvent_DO_i,
                        PosLotReticleSetChangeEventPosLotReticleSetChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotFlowBatchEvent,
                        PosLotFlowBatchEvent_DO_i,
                        PosLotFlowBatchEventPosLotFlowBatchEvent_i_m, GCOT);

    Create_PrototypeBOA(PosInterFabXferEvent,
                        PosInterFabXferEvent_DO_i,
                        PosInterFabXferEventPosInterFabXferEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotOperationStartEvent,
                        PosLotOperationStartEvent_DO_i,
                        PosLotOperationStartEventPosLotOperationStartEvent_i_m, GCOT);

    Create_PrototypeBOA(PosSLMMaxReserveCountEvent,
                        PosSLMMaxReserveCountEvent_DO_i,
                        PosSLMMaxReserveCountEventPosSLMMaxReserveCountEvent_i_m, GCOT);

    Create_PrototypeBOA(PosPlannedSplitEvent,
                        PosPlannedSplitEvent_DO_i,
                        PosPlannedSplitEventPosPlannedSplitEvent_i_m, GCOT);

    Create_PrototypeBOA(PosBackupChannelEvent,
                        PosBackupChannelEvent_DO_i,
                        PosBackupChannelEventPosBackupChannelEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEquipmentStatusChangeEvent,
                        PosEquipmentStatusChangeEvent_DO_i,
                        PosEquipmentStatusChangeEventPosEquipmentStatusChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEquipmentModeChangeEvent,
                        PosEquipmentModeChangeEvent_DO_i,
                        PosEquipmentModeChangeEventPosEquipmentModeChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosBackupOperationEvent,
                        PosBackupOperationEvent_DO_i,
                        PosBackupOperationEventPosBackupOperationEvent_i_m, GCOT);

    Create_PrototypeBOA(PosRecipeBodyManageEvent,
                        PosRecipeBodyManageEvent_DO_i,
                        PosRecipeBodyManageEventPosRecipeBodyManageEvent_i_m, GCOT);

    Create_PrototypeBOA(PosVendorLotEvent,
                        PosVendorLotEvent_DO_i,
                        PosVendorLotEventPosVendorLotEvent_i_m, GCOT);

    Create_PrototypeBOA(PosFutureReworkEvent,
                        PosFutureReworkEvent_DO_i,
                        PosFutureReworkEventPosFutureReworkEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotReworkEvent,
                        PosLotReworkEvent_DO_i,
                        PosLotReworkEventPosLotReworkEvent_i_m, GCOT);

    Create_PrototypeBOA(PosChamberStatusChangeEvent,
                        PosChamberStatusChangeEvent_DO_i,
                        PosChamberStatusChangeEventPosChamberStatusChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosControlJobStatusChangeEvent,
                        PosControlJobStatusChangeEvent_DO_i,
                        PosControlJobStatusChangeEventPosControlJobStatusChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotWaferSortEvent,
                        PosLotWaferSortEvent_DO_i,
                        PosLotWaferSortEventPosLotWaferSortEvent_i_m, GCOT);

    Create_PrototypeBOA(PosFPCEvent,
                        PosFPCEvent_DO_i,
                        PosFPCEventPosFPCEvent_i_m, GCOT);

    Create_PrototypeBOA(PosProcessStatusEvent,
                        PosProcessStatusEvent_DO_i,
                        PosProcessStatusEventPosProcessStatusEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotWaferScrapEvent,
                        PosLotWaferScrapEvent_DO_i,
                        PosLotWaferScrapEventPosLotWaferScrapEvent_i_m, GCOT);

    Create_PrototypeBOA(PosScriptParameterChangeEvent,
                        PosScriptParameterChangeEvent_DO_i,
                        PosScriptParameterChangeEventPosScriptParameterChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosPortStatusChangeEvent,
                        PosPortStatusChangeEvent_DO_i,
                        PosPortStatusChangeEventPosPortStatusChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurableEvent,
                        PosDurableEvent_DO_i,
                        PosDurableEventPosDurableEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotChangeEvent,
                        PosLotChangeEvent_DO_i,
                        PosLotChangeEventPosLotChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosCollectedDataEvent,
                        PosCollectedDataEvent_DO_i,
                        PosCollectedDataEventPosCollectedDataEvent_i_m, GCOT);

    Create_PrototypeBOA(PosAPCProcessDispositionEvent,
                        PosAPCProcessDispositionEvent_DO_i,
                        PosAPCProcessDispositionEventPosAPCProcessDispositionEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotFutureHoldEvent,
                        PosLotFutureHoldEvent_DO_i,
                        PosLotFutureHoldEventPosLotFutureHoldEvent_i_m, GCOT);

    Create_PrototypeBOA(PosSystemMessageEvent,
                        PosSystemMessageEvent_DO_i,
                        PosSystemMessageEventPosSystemMessageEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEquipmentFlowBatchMaxCountChangeEvent,
                        PosEquipmentFlowBatchMaxCountChangeEvent_DO_i,
                        PosEquipmentFlowBatchMaxCountChangeEventPosEquipmentFlowBatchMaxCountChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosCollectedDataChangeEvent,
                        PosCollectedDataChangeEvent_DO_i,
                        PosCollectedDataChangeEventPosCollectedDataChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosLotWaferStackEvent,
                        PosLotWaferStackEvent_DO_i,
                        PosLotWaferStackEventPosLotWaferStackEvent_i_m, GCOT);

    Create_PrototypeBOA(PosBondingGroupEvent,
                        PosBondingGroupEvent_DO_i,
                        PosBondingGroupEventPosBondingGroupEvent_i_m, GCOT);

    Create_PrototypeBOA(PosOwnerChangeEvent,
                        PosOwnerChangeEvent_DO_i,
                        PosOwnerChangeEventPosOwnerChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosProcessJobChangeEvent,
                        PosProcessJobChangeEvent_DO_i,
                        PosProcessJobChangeEventPosProcessJobChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosAutoDispatchControlEvent,
                        PosAutoDispatchControlEvent_DO_i,
                        PosAutoDispatchControlEventPosAutoDispatchControlEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEqpMonitorEvent,
                        PosEqpMonitorEvent_DO_i,
                        PosEqpMonitorEventPosEqpMonitorEvent_i_m, GCOT);

    Create_PrototypeBOA(PosEqpMonitorJobEvent,
                        PosEqpMonitorJobEvent_DO_i,
                        PosEqpMonitorJobEventPosEqpMonitorJobEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurableOperationCompleteEvent,
                        PosDurableOperationCompleteEvent_DO_i,
                        PosDurableOperationCompleteEventPosDurableOperationCompleteEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurableOperationStartEvent,
                        PosDurableOperationStartEvent_DO_i,
                        PosDurableOperationStartEventPosDurableOperationStartEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurableControlJobStatusChangeEvent,
                        PosDurableControlJobStatusChangeEvent_DO_i,
                        PosDurableControlJobStatusChangeEventPosDurableControlJobStatusChangeEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurablePFXEvent,
                        PosDurablePFXEvent_DO_i,
                        PosDurablePFXEventPosDurablePFXEvent_i_m, GCOT);

    Create_PrototypeBOA(PosQTimeEvent,
                        PosQTimeEvent_DO_i,
                        PosQTimeEventPosQTimeEvent_i_m, GCOT);
//DSN000096063 add start
    Create_PrototypeBOA(PosDynamicBufferResourceChangeEvent,
                        PosDynamicBufferResourceChangeEvent_DO_i,
                        PosDynamicBufferResourceChangeEventPosDynamicBufferResourceChangeEvent_i_m, GCOT);
//DSN000096063 add end

    Create_PrototypeBOA(PosDurableOperationMoveEvent,
                        PosDurableOperationMoveEvent_DO_i,
                        PosDurableOperationMoveEventPosDurableOperationMoveEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurableBankMoveEvent,
                        PosDurableBankMoveEvent_DO_i,
                        PosDurableBankMoveEventPosDurableBankMoveEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurableReworkEvent,
                        PosDurableReworkEvent_DO_i,
                        PosDurableReworkEventPosDurableReworkEvent_i_m, GCOT);

    Create_PrototypeBOA(PosDurableHoldEvent,
                        PosDurableHoldEvent_DO_i,
                        PosDurableHoldEventPosDurableHoldEvent_i_m, GCOT);

//PSN000081321 Add Start
    Create_PrototypeBOA(PosNoteChangeEvent,
                        PosNoteChangeEvent_DO_i,
                        PosNoteChangeEventPosNoteChangeEvent_i_m, GCOT);
//PSN000081321 Add End

//DSN000101505 Add Start
    Create_PrototypeBOA(PosEqpPortStatusChangeEvent,
                        PosEqpPortStatusChangeEvent_DO_i,
                        PosEqpPortStatusChangeEventPosEqpPortStatusChangeEvent_i_m, GCOT);
//DSN000101505 Add End

//DSN000104324 Add Start
    Create_PrototypeBOA(PosDurableXferJobStatusChangeEvent,
                        PosDurableXferJobStatusChangeEvent_DO_i,
                        PosDurableXferJobStatusChangeEventPosDurableXferJobStatusChangeEvent_i_m, GCOT);
//DSN000104324 Add End

  }
  //return GCOT;
}

