#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spclass/source/poscimfw/boshlpr/boshlpr.cpp, mm_srv_90e_spcl, mm_srv_90e_spcl 7/13/07 22:06:07 [ 7/13/07 22:06:29 ]";
#endif
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// Siview
// Name: boshlpr.cpp
//
// Change history:
//
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 1999/12/09 D2200055 H.Katoh        Add new component manager (PosEntityInhibitManager)
// 2000/06/14 D2400004 M.Ameshita     Add new component manager (PosPartsManager)
// 2001/07/05 D4000022 H.Katoh        Remove Inheritance of IM object from PPTServiceManager
// 2003/03/28 D5000016 K.Kido         Delete bosppcmg.
// 2003/09/17 D5100006 K.Kido         Add new Manager (PosPropertySetManager)
// 2004/11/09 D6000044 F.Masada       Delete bospdomg.
// 

#ifdef IMIZED

#include "bospatmg.hpp"
#include "bospcdmg.hpp"
#include "bospdcmg.hpp"
//D6000044 #include "bospdomg.hpp"
#include "bospdrmg.hpp"
#include "bospmcmg.hpp"
#include "bospmsds.hpp"
#include "bosppcdf.hpp"
//D5000016 #include "bosppcmg.hpp"
#include "bospprmg.hpp"
#include "bospprsp.hpp"
#include "bosppsmg.hpp"
#include "bosprcmg.hpp"
#include "bosppl.hpp"
#include "bospdp.hpp"
#include "bospfa.hpp"
#include "bospevmg.hpp"
#include "bospabcl.hpp"
#include "bospenmg.hpp"  //D2200055
#include "bospptsmg.hpp" //D2400004
#include "bospabcl.hpp"  //D5100006

//D4000022 #include "bosfwsvcmgr.hpp"
#include "bosfwpptmgr.hpp"

#include "boshlprvarinfomgr.hpp"
#include "boshlprbrsmanager.hpp"

GlobalComposedObjectTable* global_func()
{
  GlobalComposedObjectTable *GCOT = NULL ;
  GCOT = new GlobalComposedObjectTable() ;

  if( GCOT != NULL )
  {
      global_func_BOSPAtMg( GCOT ) ;
      global_func_BOSPCdMg( GCOT ) ;
      global_func_BOSPDcMg( GCOT ) ;
      //D6000044 global_func_BOSPDoMg( GCOT ) ;
      global_func_BOSPDp( GCOT ) ;
      global_func_BOSPDrMg( GCOT ) ;
      global_func_BOSPFa( GCOT ) ;
      global_func_BOSPMcMg( GCOT ) ;
      global_func_BOSPMsDs( GCOT ) ;
      global_func_BOSPPcDf( GCOT ) ;
      //D5000016      global_func_BOSPPcMg( GCOT ) ;
      global_func_BOSPPl( GCOT ) ;
      global_func_BOSPPrMg( GCOT ) ;
      global_func_BOSPPrSp( GCOT ) ;
      global_func_BOSPPsMg( GCOT ) ;
      global_func_BOSPRcMg( GCOT ) ;
      global_func_BOSPEvMg( GCOT ) ;
      global_func_BOSPAbCl( GCOT ) ;
      global_func_BOSPEnMg( GCOT ) ;  //D2200055
      global_func_BOSPPtsMg( GCOT ) ; //D2400004

      //D4000022 global_func_BOSPPTSvcMgr( GCOT ) ;
      global_func_BOSPPTMgr( GCOT ) ;

      global_func_VarInfoMgr(GCOT) ;
      global_func_BRSManager(GCOT) ;

  }
  return GCOT ;
}


#endif

