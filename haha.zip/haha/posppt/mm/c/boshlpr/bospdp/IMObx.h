 #ifndef __checkapperrlog__
   #define __checkapperrlog__

   #ifdef NOAPPERRLOG
     #define APPERRLOG
     #define apperrlog cerr
   #else
     #include "apperrlog.hpp"
   #endif 

 #endif

 #include <private/imcommon.h> 
 #include <implatform.h> //D228 - for definitions of CORBAENV_xxxx macros

// -----------------------------------------------------------------------------
// PosDispatcherPosDispatcher_i
// -----------------------------------------------------------------------------
class PosDispatcherPosDispatcher_i_m : public PosDispatcher_i {

  public:
/* PosDispatcher::addToQueue */
virtual ::CORBA::Void  addToQueue (::PosLot_ptr aLot, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::addToQueue()";
        PosDispatcher_i::addToQueue ( aLot, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosDispatcher::removeFromQueue */
virtual ::CORBA::Void  removeFromQueue (::PosLot_ptr aLot, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::removeFromQueue()";
        PosDispatcher_i::removeFromQueue ( aLot, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosDispatcher::currentWhatNextForMachine */
virtual ::posEffectiveWhatNextLogic*  currentWhatNextForMachine (CORBAENV_ONLY_HPP) {
    ::posEffectiveWhatNextLogic*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::currentWhatNextForMachine()";
        retVal =        PosDispatcher_i::currentWhatNextForMachine (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::getEffectiveWhatNextLogic */
virtual ::PosEffectiveWhatNextLogicSequence*  getEffectiveWhatNextLogic (CORBAENV_ONLY_HPP) {
    ::PosEffectiveWhatNextLogicSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getEffectiveWhatNextLogic()";
        retVal =        PosDispatcher_i::getEffectiveWhatNextLogic (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::setEffectiveWhatNextLogic */
virtual ::CORBA::Void  setEffectiveWhatNextLogic (const ::PosEffectiveWhatNextLogicSequence& effectiveWhatNextLogic, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setEffectiveWhatNextLogic()";
        PosDispatcher_i::setEffectiveWhatNextLogic ( effectiveWhatNextLogic, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosDispatcher::PosDispatcher_init */
virtual ::CORBA::Void  PosDispatcher_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::PosDispatcher_init()";
        PosDispatcher_i::PosDispatcher_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosDispatcher::whatNextHoldLotForMachine */
virtual ::DispatchDecisionSequence*  whatNextHoldLotForMachine (::Machine_ptr aMachine, CORBAENV_ONLY_HPP) {
    ::DispatchDecisionSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::whatNextHoldLotForMachine()";
        retVal =        PosDispatcher_i::whatNextHoldLotForMachine ( aMachine, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::getNextControlJobIdentifier */
virtual char*  getNextControlJobIdentifier (const char* equipmentID, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getNextControlJobIdentifier()";
        retVal =        PosDispatcher_i::getNextControlJobIdentifier ( equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::findLastControlJobFor */
virtual ::posLastControlJob*  findLastControlJobFor (const char* equipmentID, CORBAENV_ONLY_HPP) {
    ::posLastControlJob*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::findLastControlJobFor()";
        retVal =        PosDispatcher_i::findLastControlJobFor ( equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::allLastControlJobs */
virtual ::PosLastControlJobSequence*  allLastControlJobs (CORBAENV_ONLY_HPP) {
    ::PosLastControlJobSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::allLastControlJobs()";
        retVal =        PosDispatcher_i::allLastControlJobs (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::setLastControlJob */
virtual ::CORBA::Void  setLastControlJob (const char* equipmentID, const ::posLastControlJob& aLastControlJob, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setLastControlJob()";
        PosDispatcher_i::setLastControlJob ( equipmentID, aLastControlJob, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosDispatcher::getNextDurableControlJobIdentifier */
virtual char*  getNextDurableControlJobIdentifier (const char* equipmentID, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getNextDurableControlJobIdentifier()";
        retVal =        PosDispatcher_i::getNextDurableControlJobIdentifier ( equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::findLastDurableControlJobFor */
virtual ::posLastControlJob*  findLastDurableControlJobFor (const char* equipmentID, CORBAENV_ONLY_HPP) {
    ::posLastControlJob*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::findLastDurableControlJobFor()";
        retVal =        PosDispatcher_i::findLastDurableControlJobFor ( equipmentID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::allLastDurableControlJobs */
virtual ::PosLastControlJobSequence*  allLastDurableControlJobs (CORBAENV_ONLY_HPP) {
    ::PosLastControlJobSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::allLastDurableControlJobs()";
        retVal =        PosDispatcher_i::allLastDurableControlJobs (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::setLastDurableControlJob */
virtual ::CORBA::Void  setLastDurableControlJob (const char* equipmentID, const ::posLastControlJob& aLastControlJob, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setLastDurableControlJob()";
        PosDispatcher_i::setLastDurableControlJob ( equipmentID, aLastControlJob, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosDispatcher::whatNextDurableForMachine */
virtual ::DispatchDecisionSequence*  whatNextDurableForMachine (::Machine_ptr aMachine, const char* durableCategory, CORBAENV_ONLY_HPP) {
    ::DispatchDecisionSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::whatNextDurableForMachine()";
        retVal =        PosDispatcher_i::whatNextDurableForMachine ( aMachine, durableCategory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosDispatcher::whatNextHoldDurableForMachine */
virtual ::DispatchDecisionSequence*  whatNextHoldDurableForMachine (::Machine_ptr aMachine, const char* durableCategory, CORBAENV_ONLY_HPP) {
    ::DispatchDecisionSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::whatNextHoldDurableForMachine()";
        retVal =        PosDispatcher_i::whatNextHoldDurableForMachine ( aMachine, durableCategory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Dispatcher::addDispatchableObject */
virtual ::CORBA::Void  addDispatchableObject (const ::CORBA::Any& dispatchableObject, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::addDispatchableObject()";
        PosDispatcher_i::addDispatchableObject ( dispatchableObject, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Dispatcher::removeDispatchableObject */
virtual ::CORBA::Void  removeDispatchableObject (const ::CORBA::Any& dispatchableObject, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::removeDispatchableObject()";
        PosDispatcher_i::removeDispatchableObject ( dispatchableObject, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Dispatcher::whatNextForMachine */
virtual ::DispatchDecisionSequence*  whatNextForMachine (::Machine_ptr aMachine, CORBAENV_ONLY_HPP) {
    ::DispatchDecisionSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::whatNextForMachine()";
        retVal =        PosDispatcher_i::whatNextForMachine ( aMachine, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Dispatcher::allDispatchableObjects */
virtual ::anySequence*  allDispatchableObjects (CORBAENV_ONLY_HPP) {
    ::anySequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::allDispatchableObjects()";
        retVal =        PosDispatcher_i::allDispatchableObjects (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Dispatcher::Dispatcher_init */
virtual ::CORBA::Void  Dispatcher_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::Dispatcher_init()";
        PosDispatcher_i::Dispatcher_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::resourceLevel */
virtual char*  resourceLevel (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::resourceLevel()";
        retVal =        PosDispatcher_i::resourceLevel (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Resource::nameQualifiedTo */
virtual char*  nameQualifiedTo (const char* resourceLevel, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::nameQualifiedTo()";
        retVal =        PosDispatcher_i::nameQualifiedTo ( resourceLevel, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Resource::startUp */
virtual ::CORBA::Void  startUp (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::startUp()";
        PosDispatcher_i::startUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::shutdownNormal */
virtual ::CORBA::Void  shutdownNormal (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::shutdownNormal()";
        PosDispatcher_i::shutdownNormal (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::shutdownImmediate */
virtual ::CORBA::Void  shutdownImmediate (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::shutdownImmediate()";
        PosDispatcher_i::shutdownImmediate (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::Resource_init */
virtual ::CORBA::Void  Resource_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::Resource_init()";
        PosDispatcher_i::Resource_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* OwnedEntity::setOwner */
virtual ::CORBA::Void  setOwner (::Person_ptr owner, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setOwner()";
        PosDispatcher_i::setOwner ( owner, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* OwnedEntity::getOwner */
virtual ::Person_ptr  getOwner (CORBAENV_ONLY_HPP) {
    ::Person_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getOwner()";
        retVal =        PosDispatcher_i::getOwner (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* OwnedEntity::OwnedEntity_init */
virtual ::CORBA::Void  OwnedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::OwnedEntity_init()";
        PosDispatcher_i::OwnedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::isNamed()";
        retVal =        PosDispatcher_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setName()";
        PosDispatcher_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getName()";
        retVal =        PosDispatcher_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::NamedEntity_init()";
        PosDispatcher_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setTheTIEObject()";
        PosDispatcher_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::CIMFWBO_init()";
        PosDispatcher_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::CIMFW_clear()";
        PosDispatcher_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setObjectManager()";
        PosDispatcher_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getObjectManager()";
        retVal =        PosDispatcher_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::touchMe()";
        PosDispatcher_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::checkForDeletion()";
        retVal =        PosDispatcher_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getUserDataSetNamed()";
        retVal =        PosDispatcher_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getUserDataSetSequenceNamed()";
        retVal =        PosDispatcher_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::allUserDataSets()";
        retVal =        PosDispatcher_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::removeUserDataSetNamed()";
        PosDispatcher_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::removeUserDataSetSequenceNamed()";
        PosDispatcher_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::removeAllUserDataSets()";
        PosDispatcher_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setUserDataSetNamed()";
        PosDispatcher_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setUserDataSetSequenceNamed()";
        PosDispatcher_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getUserDataNamed()";
        retVal =        PosDispatcher_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getUserDataSequenceNamed()";
        retVal =        PosDispatcher_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::allUserDataSetsFor()";
        retVal =        PosDispatcher_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::removeUserDataSetsFor()";
        PosDispatcher_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::getUserDataSetNamedAndOrig()";
        retVal =        PosDispatcher_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::setUserDataSetNamedAndOrig()";
        PosDispatcher_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::removeUserDataSetNamedAndOrg()";
        PosDispatcher_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::TxLockMainObject()";
        retVal =        PosDispatcher_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::TxLockElements()";
        retVal =        PosDispatcher_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosDispatcher_i::TxnUnlock()";
        retVal =        PosDispatcher_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosFlowBatchPosFlowBatch_i
// -----------------------------------------------------------------------------
class PosFlowBatchPosFlowBatch_i_m : public PosFlowBatch_i {

  public:
/* PosFlowBatch::setMachine */
virtual ::CORBA::Void  setMachine (::PosMachine_ptr aMachine, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setMachine()";
        PosFlowBatch_i::setMachine ( aMachine, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::getMachine */
virtual ::PosMachine_ptr  getMachine (CORBAENV_ONLY_HPP) {
    ::PosMachine_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getMachine()";
        retVal =        PosFlowBatch_i::getMachine (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::removeLot */
virtual ::CORBA::Void  removeLot (::PosLot_ptr aLot, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::removeLot()";
        PosFlowBatch_i::removeLot ( aLot, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::allLots */
virtual ::PosLotSequence*  allLots (CORBAENV_ONLY_HPP) {
    ::PosLotSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::allLots()";
        retVal =        PosFlowBatch_i::allLots (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::setLots */
virtual ::CORBA::Void  setLots (const ::PosLotSequence& aLotSequence, ::CORBA::Boolean reFlowBatchFlag, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setLots()";
        PosFlowBatch_i::setLots ( aLotSequence, reFlowBatchFlag, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::getOperationCount */
virtual ::CORBA::Long  getOperationCount (CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getOperationCount()";
        retVal =        PosFlowBatch_i::getOperationCount (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::getFlowBatchSize */
virtual ::CORBA::Long  getFlowBatchSize (CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getFlowBatchSize()";
        retVal =        PosFlowBatch_i::getFlowBatchSize (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::removeAllLots */
virtual ::CORBA::Void  removeAllLots (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::removeAllLots()";
        PosFlowBatch_i::removeAllLots (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::PosFlowBatch_init */
virtual ::CORBA::Void  PosFlowBatch_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::PosFlowBatch_init()";
        PosFlowBatch_i::PosFlowBatch_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::findLotNamed */
virtual ::PosLot_ptr  findLotNamed (const char* anIdentifier, CORBAENV_ONLY_HPP) {
    ::PosLot_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::findLotNamed()";
        retVal =        PosFlowBatch_i::findLotNamed ( anIdentifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::setLastClaimedPerson */
virtual ::CORBA::Void  setLastClaimedPerson (::PosPerson_ptr aPerson, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setLastClaimedPerson()";
        PosFlowBatch_i::setLastClaimedPerson ( aPerson, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::setLastClaimedTimeStamp */
virtual ::CORBA::Void  setLastClaimedTimeStamp (const char* aTimeStamp, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setLastClaimedTimeStamp()";
        PosFlowBatch_i::setLastClaimedTimeStamp ( aTimeStamp, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::getLastClaimedPerson */
virtual ::PosPerson_ptr  getLastClaimedPerson (CORBAENV_ONLY_HPP) {
    ::PosPerson_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getLastClaimedPerson()";
        retVal =        PosFlowBatch_i::getLastClaimedPerson (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::getLastClaimedTimeStamp */
virtual char*  getLastClaimedTimeStamp (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getLastClaimedTimeStamp()";
        retVal =        PosFlowBatch_i::getLastClaimedTimeStamp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getIdentifier()";
        retVal =        PosFlowBatch_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setIdentifier()";
        PosFlowBatch_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::makeTargetOperationStarted */
virtual ::CORBA::Void  makeTargetOperationStarted (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::makeTargetOperationStarted()";
        PosFlowBatch_i::makeTargetOperationStarted (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::makeTargetOperationNotStarted */
virtual ::CORBA::Void  makeTargetOperationNotStarted (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::makeTargetOperationNotStarted()";
        PosFlowBatch_i::makeTargetOperationNotStarted (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::isTargetOperationStarted */
virtual ::CORBA::Boolean  isTargetOperationStarted (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::isTargetOperationStarted()";
        retVal =        PosFlowBatch_i::isTargetOperationStarted (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::getLastClaimedPersonID */
virtual char*  getLastClaimedPersonID (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getLastClaimedPersonID()";
        retVal =        PosFlowBatch_i::getLastClaimedPersonID (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatch::setFlowBatchSize */
virtual ::CORBA::Void  setFlowBatchSize (::CORBA::Long flowBatchSize, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setFlowBatchSize()";
        PosFlowBatch_i::setFlowBatchSize ( flowBatchSize, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatch::setOperationCount */
virtual ::CORBA::Void  setOperationCount (::CORBA::Long operationCount, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setOperationCount()";
        PosFlowBatch_i::setOperationCount ( operationCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::isNamed()";
        retVal =        PosFlowBatch_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setName()";
        PosFlowBatch_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getName()";
        retVal =        PosFlowBatch_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::NamedEntity_init()";
        PosFlowBatch_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setTheTIEObject()";
        PosFlowBatch_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::CIMFWBO_init()";
        PosFlowBatch_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::CIMFW_clear()";
        PosFlowBatch_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setObjectManager()";
        PosFlowBatch_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getObjectManager()";
        retVal =        PosFlowBatch_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::touchMe()";
        PosFlowBatch_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::checkForDeletion()";
        retVal =        PosFlowBatch_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getUserDataSetNamed()";
        retVal =        PosFlowBatch_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getUserDataSetSequenceNamed()";
        retVal =        PosFlowBatch_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::allUserDataSets()";
        retVal =        PosFlowBatch_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::removeUserDataSetNamed()";
        PosFlowBatch_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::removeUserDataSetSequenceNamed()";
        PosFlowBatch_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::removeAllUserDataSets()";
        PosFlowBatch_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setUserDataSetNamed()";
        PosFlowBatch_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setUserDataSetSequenceNamed()";
        PosFlowBatch_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getUserDataNamed()";
        retVal =        PosFlowBatch_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getUserDataSequenceNamed()";
        retVal =        PosFlowBatch_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::allUserDataSetsFor()";
        retVal =        PosFlowBatch_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::removeUserDataSetsFor()";
        PosFlowBatch_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::getUserDataSetNamedAndOrig()";
        retVal =        PosFlowBatch_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::setUserDataSetNamedAndOrig()";
        PosFlowBatch_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::removeUserDataSetNamedAndOrg()";
        PosFlowBatch_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::TxLockMainObject()";
        retVal =        PosFlowBatch_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::TxLockElements()";
        retVal =        PosFlowBatch_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatch_i::TxnUnlock()";
        retVal =        PosFlowBatch_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosFlowBatchDispatcherPosFlowBatchDispatcher_i
// -----------------------------------------------------------------------------
class PosFlowBatchDispatcherPosFlowBatchDispatcher_i_m : public PosFlowBatchDispatcher_i {

  public:
/* PosFlowBatchDispatcher::PosFlowBatchDispatcher_init */
virtual ::CORBA::Void  PosFlowBatchDispatcher_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::PosFlowBatchDispatcher_init()";
        PosFlowBatchDispatcher_i::PosFlowBatchDispatcher_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatchDispatcher::getNextFlowBatchIdentifier */
virtual char*  getNextFlowBatchIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::getNextFlowBatchIdentifier()";
        retVal =        PosFlowBatchDispatcher_i::getNextFlowBatchIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosFlowBatchDispatcher::addToQueue */
virtual ::CORBA::Void  addToQueue (::PosLot_ptr aLot, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::addToQueue()";
        PosFlowBatchDispatcher_i::addToQueue ( aLot, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosFlowBatchDispatcher::removeFromQueue */
virtual ::CORBA::Void  removeFromQueue (::PosLot_ptr aLot, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::removeFromQueue()";
        PosFlowBatchDispatcher_i::removeFromQueue ( aLot, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::TxnUnlock()";
        retVal =        PosFlowBatchDispatcher_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::isNamed()";
        retVal =        PosFlowBatchDispatcher_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::setName()";
        PosFlowBatchDispatcher_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::getName()";
        retVal =        PosFlowBatchDispatcher_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::NamedEntity_init()";
        PosFlowBatchDispatcher_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::setTheTIEObject()";
        PosFlowBatchDispatcher_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::CIMFWBO_init()";
        PosFlowBatchDispatcher_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::CIMFW_clear()";
        PosFlowBatchDispatcher_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::setObjectManager()";
        PosFlowBatchDispatcher_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::getObjectManager()";
        retVal =        PosFlowBatchDispatcher_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::touchMe()";
        PosFlowBatchDispatcher_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::checkForDeletion()";
        retVal =        PosFlowBatchDispatcher_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::getUserDataSetNamed()";
        retVal =        PosFlowBatchDispatcher_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::getUserDataSetSequenceNamed()";
        retVal =        PosFlowBatchDispatcher_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::allUserDataSets()";
        retVal =        PosFlowBatchDispatcher_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::removeUserDataSetNamed()";
        PosFlowBatchDispatcher_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::removeUserDataSetSequenceNamed()";
        PosFlowBatchDispatcher_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::removeAllUserDataSets()";
        PosFlowBatchDispatcher_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::setUserDataSetNamed()";
        PosFlowBatchDispatcher_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::setUserDataSetSequenceNamed()";
        PosFlowBatchDispatcher_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::getUserDataNamed()";
        retVal =        PosFlowBatchDispatcher_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::getUserDataSequenceNamed()";
        retVal =        PosFlowBatchDispatcher_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::allUserDataSetsFor()";
        retVal =        PosFlowBatchDispatcher_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::removeUserDataSetsFor()";
        PosFlowBatchDispatcher_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::getUserDataSetNamedAndOrig()";
        retVal =        PosFlowBatchDispatcher_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::setUserDataSetNamedAndOrig()";
        PosFlowBatchDispatcher_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::removeUserDataSetNamedAndOrg()";
        PosFlowBatchDispatcher_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::TxLockMainObject()";
        retVal =        PosFlowBatchDispatcher_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosFlowBatchDispatcher_i::TxLockElements()";
        retVal =        PosFlowBatchDispatcher_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

