//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Wednesday, November 29, 2006 12:49:47 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/09 DSIV00001432 S.Kawabe       Support XLC version 9

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1997, 2008.          *
*     (C) COPYRIGHT: IBM Japan Services Company Ltd, 1997, 2008.       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

#include "IMProt.h" //DSIV00001432

// Implementation header files
#include "pareagr.hpp"
#include "pperson.hpp"
#include "pprivgr.hpp"
#include "ppsmgr.hpp"
#include "pusergr.hpp"

//DSIV00001432 #include "IMProt.h"

// DO implementation header files
#include "DOBase_i.h"
#include "pareagdo.hpp"
#include "ppersodo.hpp"
#include "pprivgdo.hpp"
#include "pusergdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

//GlobalComposedObjectTable* global_func()
void global_func_BOSPPsMg( GlobalComposedObjectTable* GCOT )
{
  //GlobalComposedObjectTable *GCOT = NULL;
  //GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosPersonManager,
                        IMFW_DataObjectBase_i,
                        PosPersonManagerPosPersonManager_i_m, GCOT);

    Create_PrototypeBOA(PosPrivilegeGroup,
                        PosPrivilegeGroup_DO_i,
                        PosPrivilegeGroupPosPrivilegeGroup_i_m, GCOT);

    Create_PrototypeBOA(PosAreaGroup,
                        PosAreaGroup_DO_i,
                        PosAreaGroupPosAreaGroup_i_m, GCOT);

    Create_PrototypeBOA(PosUserGroup,
                        PosUserGroup_DO_i,
                        PosUserGroupPosUserGroup_i_m, GCOT);

    Create_PrototypeBOA(PosPerson,
                        PosPerson_DO_i,
                        PosPersonPosPerson_i_m, GCOT);

  }
  //return GCOT;
}

