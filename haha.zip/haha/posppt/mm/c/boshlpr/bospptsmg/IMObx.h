 #ifndef __checkapperrlog__
   #define __checkapperrlog__

   #ifdef NOAPPERRLOG
     #define APPERRLOG
     #define apperrlog cerr
   #else
     #include "apperrlog.hpp"
   #endif 

 #endif

 #include <private/imcommon.h> 
 #include <implatform.h> //D228 - for definitions of CORBAENV_xxxx macros

// -----------------------------------------------------------------------------
// PosBOMPosBOM_i
// -----------------------------------------------------------------------------
class PosBOMPosBOM_i_m : public PosBOM_i {

  public:
/* PosBOM::PosBOM_init */
virtual ::CORBA::Void  PosBOM_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::PosBOM_init()";
        PosBOM_i::PosBOM_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBOM::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getIdentifier()";
        retVal =        PosBOM_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBOM::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* anIdentifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setIdentifier()";
        PosBOM_i::setIdentifier ( anIdentifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBOM::setDescription */
virtual ::CORBA::Void  setDescription (const char* aDescription, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setDescription()";
        PosBOM_i::setDescription ( aDescription, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBOM::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getDescription()";
        retVal =        PosBOM_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBOM::addParts */
virtual ::CORBA::Void  addParts (const ::posParts& aParts, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::addParts()";
        PosBOM_i::addParts ( aParts, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBOM::findPartsFor */
virtual ::posParts*  findPartsFor (const char* anIdentifier, CORBAENV_ONLY_HPP) {
    ::posParts*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::findPartsFor()";
        retVal =        PosBOM_i::findPartsFor ( anIdentifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBOM::allParts */
virtual ::PosPartsSequence*  allParts (CORBAENV_ONLY_HPP) {
    ::PosPartsSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::allParts()";
        retVal =        PosBOM_i::allParts (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBOM::removeParts */
virtual ::CORBA::Void  removeParts (const char* anIdentifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::removeParts()";
        PosBOM_i::removeParts ( anIdentifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBOM::removeAllParts */
virtual ::CORBA::Void  removeAllParts (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::removeAllParts()";
        PosBOM_i::removeAllParts (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBOM::setBOMInfo */
virtual ::CORBA::Void  setBOMInfo (const ::brBOMInfo& BOMInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setBOMInfo()";
        PosBOM_i::setBOMInfo ( BOMInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::isNamed()";
        retVal =        PosBOM_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setName()";
        PosBOM_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getName()";
        retVal =        PosBOM_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::NamedEntity_init()";
        PosBOM_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setTheTIEObject()";
        PosBOM_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::CIMFWBO_init()";
        PosBOM_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::CIMFW_clear()";
        PosBOM_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setObjectManager()";
        PosBOM_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getObjectManager()";
        retVal =        PosBOM_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::touchMe()";
        PosBOM_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::checkForDeletion()";
        retVal =        PosBOM_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getUserDataSetNamed()";
        retVal =        PosBOM_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getUserDataSetSequenceNamed()";
        retVal =        PosBOM_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::allUserDataSets()";
        retVal =        PosBOM_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::removeUserDataSetNamed()";
        PosBOM_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::removeUserDataSetSequenceNamed()";
        PosBOM_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::removeAllUserDataSets()";
        PosBOM_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setUserDataSetNamed()";
        PosBOM_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setUserDataSetSequenceNamed()";
        PosBOM_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getUserDataNamed()";
        retVal =        PosBOM_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getUserDataSequenceNamed()";
        retVal =        PosBOM_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::allUserDataSetsFor()";
        retVal =        PosBOM_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::removeUserDataSetsFor()";
        PosBOM_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::getUserDataSetNamedAndOrig()";
        retVal =        PosBOM_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::setUserDataSetNamedAndOrig()";
        PosBOM_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::removeUserDataSetNamedAndOrg()";
        PosBOM_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::TxLockMainObject()";
        retVal =        PosBOM_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::TxLockElements()";
        retVal =        PosBOM_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBOM_i::TxnUnlock()";
        retVal =        PosBOM_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosPartsManagerPosPartsManager_i
// -----------------------------------------------------------------------------
class PosPartsManagerPosPartsManager_i_m : public PosPartsManager_i {

  public:
/* PosPartsManager::PosPartsManager_init */
virtual ::CORBA::Void  PosPartsManager_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::PosPartsManager_init()";
        PosPartsManager_i::PosPartsManager_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosPartsManager::createBOMNamed */
virtual ::PosBOM_ptr  createBOMNamed (const char* anIdentifier, CORBAENV_ONLY_HPP) {
    ::PosBOM_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::createBOMNamed()";
        retVal =        PosPartsManager_i::createBOMNamed ( anIdentifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosPartsManager::removeBOMNamed */
virtual ::CORBA::Void  removeBOMNamed (::PosBOM_ptr aBOM, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::removeBOMNamed()";
        PosPartsManager_i::removeBOMNamed ( aBOM, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosPartsManager::allBOMs */
virtual ::PosBOMSequence*  allBOMs (CORBAENV_ONLY_HPP) {
    ::PosBOMSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::allBOMs()";
        retVal =        PosPartsManager_i::allBOMs (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosPartsManager::findBOMNamed */
virtual ::PosBOM_ptr  findBOMNamed (const char* anIdentifier, CORBAENV_ONLY_HPP) {
    ::PosBOM_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::findBOMNamed()";
        retVal =        PosPartsManager_i::findBOMNamed ( anIdentifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosPartsManager::removeAllBOMs */
virtual ::CORBA::Void  removeAllBOMs (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::removeAllBOMs()";
        PosPartsManager_i::removeAllBOMs (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeRegistered */
virtual ::CORBA::Void  makeRegistered (::MESFactory_ptr aFactory, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::makeRegistered()";
        PosPartsManager_i::makeRegistered ( aFactory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeNotRegistered */
virtual ::CORBA::Void  makeNotRegistered (::MESFactory_ptr aFactory, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::makeNotRegistered()";
        PosPartsManager_i::makeNotRegistered ( aFactory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeStartingUp */
virtual ::CORBA::Void  makeStartingUp (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::makeStartingUp()";
        PosPartsManager_i::makeStartingUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeShuttingDown */
virtual ::CORBA::Void  makeShuttingDown (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::makeShuttingDown()";
        PosPartsManager_i::makeShuttingDown (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::isStopped */
virtual ::CORBA::Boolean  isStopped (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::isStopped()";
        retVal =        PosPartsManager_i::isStopped (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isStartingUp */
virtual ::CORBA::Boolean  isStartingUp (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::isStartingUp()";
        retVal =        PosPartsManager_i::isStartingUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isOperating */
virtual ::CORBA::Boolean  isOperating (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::isOperating()";
        retVal =        PosPartsManager_i::isOperating (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isShuttingDown */
virtual ::CORBA::Boolean  isShuttingDown (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::isShuttingDown()";
        retVal =        PosPartsManager_i::isShuttingDown (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isNotRegistered */
virtual ::CORBA::Boolean  isNotRegistered (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::isNotRegistered()";
        retVal =        PosPartsManager_i::isNotRegistered (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isRegistered */
virtual ::CORBA::Boolean  isRegistered (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::isRegistered()";
        retVal =        PosPartsManager_i::isRegistered (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::makeStopped */
virtual ::CORBA::Void  makeStopped (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::makeStopped()";
        PosPartsManager_i::makeStopped (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::ComponentManager_init */
virtual ::CORBA::Void  ComponentManager_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::ComponentManager_init()";
        PosPartsManager_i::ComponentManager_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::resourceLevel */
virtual char*  resourceLevel (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::resourceLevel()";
        retVal =        PosPartsManager_i::resourceLevel (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Resource::nameQualifiedTo */
virtual char*  nameQualifiedTo (const char* resourceLevel, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::nameQualifiedTo()";
        retVal =        PosPartsManager_i::nameQualifiedTo ( resourceLevel, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Resource::startUp */
virtual ::CORBA::Void  startUp (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::startUp()";
        PosPartsManager_i::startUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::shutdownNormal */
virtual ::CORBA::Void  shutdownNormal (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::shutdownNormal()";
        PosPartsManager_i::shutdownNormal (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::shutdownImmediate */
virtual ::CORBA::Void  shutdownImmediate (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::shutdownImmediate()";
        PosPartsManager_i::shutdownImmediate (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::Resource_init */
virtual ::CORBA::Void  Resource_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::Resource_init()";
        PosPartsManager_i::Resource_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* OwnedEntity::setOwner */
virtual ::CORBA::Void  setOwner (::Person_ptr owner, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::setOwner()";
        PosPartsManager_i::setOwner ( owner, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* OwnedEntity::getOwner */
virtual ::Person_ptr  getOwner (CORBAENV_ONLY_HPP) {
    ::Person_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::getOwner()";
        retVal =        PosPartsManager_i::getOwner (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* OwnedEntity::OwnedEntity_init */
virtual ::CORBA::Void  OwnedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::OwnedEntity_init()";
        PosPartsManager_i::OwnedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::isNamed()";
        retVal =        PosPartsManager_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::setName()";
        PosPartsManager_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::getName()";
        retVal =        PosPartsManager_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::NamedEntity_init()";
        PosPartsManager_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::setTheTIEObject()";
        PosPartsManager_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::CIMFWBO_init()";
        PosPartsManager_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::CIMFW_clear()";
        PosPartsManager_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::setObjectManager()";
        PosPartsManager_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::getObjectManager()";
        retVal =        PosPartsManager_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::touchMe()";
        PosPartsManager_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::checkForDeletion()";
        retVal =        PosPartsManager_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::getUserDataSetNamed()";
        retVal =        PosPartsManager_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::getUserDataSetSequenceNamed()";
        retVal =        PosPartsManager_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::allUserDataSets()";
        retVal =        PosPartsManager_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::removeUserDataSetNamed()";
        PosPartsManager_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::removeUserDataSetSequenceNamed()";
        PosPartsManager_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::removeAllUserDataSets()";
        PosPartsManager_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::setUserDataSetNamed()";
        PosPartsManager_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::setUserDataSetSequenceNamed()";
        PosPartsManager_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::getUserDataNamed()";
        retVal =        PosPartsManager_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::getUserDataSequenceNamed()";
        retVal =        PosPartsManager_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::allUserDataSetsFor()";
        retVal =        PosPartsManager_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::removeUserDataSetsFor()";
        PosPartsManager_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::getUserDataSetNamedAndOrig()";
        retVal =        PosPartsManager_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::setUserDataSetNamedAndOrig()";
        PosPartsManager_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::removeUserDataSetNamedAndOrg()";
        PosPartsManager_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::TxLockMainObject()";
        retVal =        PosPartsManager_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::TxLockElements()";
        retVal =        PosPartsManager_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosPartsManager_i::TxnUnlock()";
        retVal =        PosPartsManager_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

