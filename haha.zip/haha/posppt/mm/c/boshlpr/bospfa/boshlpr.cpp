//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Tuesday, February 23, 2016 3:43:45 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1992,2005          *
*     (C) COPYRIGHT: IBM Japan Industrial Solution Co., Ltd, 1996,2005       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

// Implementation header files
#include "IMProt.h"

#include "parea.hpp"
#include "pbank.hpp"
#include "pcaldat.hpp"
#include "pfactry.hpp"
#include "pfctrnt.hpp"
#include "pstage.hpp"
#include "pstggrp.hpp"


// DO implementation header files
#include "DOBase_i.h"
#include "pareado.hpp"
#include "pbankdo.hpp"
#include "pcaldado.hpp"
#include "pfctrndo.hpp"
#include "pstagedo.hpp"
#include "pstggrdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

GlobalComposedObjectTable* global_func()
{
  GlobalComposedObjectTable *GCOT = NULL;
  GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosCalendarDate,
                        PosCalendarDate_DO_i,
                        PosCalendarDatePosCalendarDate_i_m, GCOT);

    Create_PrototypeBOA(PosBank,
                        PosBank_DO_i,
                        PosBankPosBank_i_m, GCOT);

    Create_PrototypeBOA(PosArea,
                        PosArea_DO_i,
                        PosAreaPosArea_i_m, GCOT);

    Create_PrototypeBOA(PosMESFactory,
                        IMFW_DataObjectBase_i,
                        PosMESFactoryPosMESFactory_i_m, GCOT);

    Create_PrototypeBOA(PosStageGroup,
                        PosStageGroup_DO_i,
                        PosStageGroupPosStageGroup_i_m, GCOT);

    Create_PrototypeBOA(PosFactoryNote,
                        PosFactoryNote_DO_i,
                        PosFactoryNotePosFactoryNote_i_m, GCOT);

    Create_PrototypeBOA(PosStage,
                        PosStage_DO_i,
                        PosStagePosStage_i_m, GCOT);

  }
  return GCOT;
}

