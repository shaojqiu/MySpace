//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Wednesday, June 25, 2008 3:34:28 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/09 DSIV00001432 S.Kawabe       Support XLC version 9

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1992,2005          *
*     (C) COPYRIGHT: IBM Japan Industrial Solution Co., Ltd, 1996,2005       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

#include "IMProt.h" //DSIV00001432

// Implementation header files
#include "pbufrs.hpp"
#include "pctnpst.hpp"
#include "pmaloc.hpp"
#include "pmc.hpp"
#include "pmcctn.hpp"
#include "pmcmg.hpp"
#include "pmcnote.hpp"
#include "pmcoppr.hpp"
#include "ppcrs.hpp"
#include "pportrs.hpp"
#include "prpprt.hpp"
#include "pstmc.hpp"
#include "pemon.hpp"
#include "pemonj.hpp"

//DSIV00001432 #include "IMProt.h"

// DO implementation header files
#include "DOBase_i.h"
#include "pbufrsdo.hpp"
#include "pctnpsdo.hpp"
#include "pmalocdo.hpp"
#include "pmcctndo.hpp"
#include "pmcdo.hpp"
#include "pmcnotdo.hpp"
#include "pmcoppdo.hpp"
#include "ppcrsdo.hpp"
#include "pportrdo.hpp"
#include "prpprtdo.hpp"
#include "pstmcdo.hpp"
#include "pemondo.hpp"
#include "pemonjdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

//GlobalComposedObjectTable* global_func()
void global_func_BOSPMcMg( GlobalComposedObjectTable* GCOT )
{
  //GlobalComposedObjectTable *GCOT = NULL;
  //GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosMachineContainer,
                        PosMachineContainer_DO_i,
                        PosMachineContainerPosMachineContainer_i_m, GCOT);

    Create_PrototypeBOA(PosProcessResource,
                        PosProcessResource_DO_i,
                        PosProcessResourcePosProcessResource_i_m, GCOT);

    Create_PrototypeBOA(PosStorageMachine,
                        PosStorageMachine_DO_i,
                        PosStorageMachinePosStorageMachine_i_m, GCOT);

    Create_PrototypeBOA(PosMachine,
                        PosMachine_DO_i,
                        PosMachinePosMachine_i_m, GCOT);

    Create_PrototypeBOA(PosReticlePodPortResource,
                        PosReticlePodPortResource_DO_i,
                        PosReticlePodPortResourcePosReticlePodPortResource_i_m, GCOT);

    Create_PrototypeBOA(PosMachineContainerPosition,
                        PosMachineContainerPosition_DO_i,
                        PosMachineContainerPositionPosMachineContainerPosition_i_m, GCOT);

    Create_PrototypeBOA(PosBufferResource,
                        PosBufferResource_DO_i,
                        PosBufferResourcePosBufferResource_i_m, GCOT);

    Create_PrototypeBOA(PosMaterialLocation,
                        PosMaterialLocation_DO_i,
                        PosMaterialLocationPosMaterialLocation_i_m, GCOT);

    Create_PrototypeBOA(PosPortResource,
                        PosPortResource_DO_i,
                        PosPortResourcePosPortResource_i_m, GCOT);

    Create_PrototypeBOA(PosMachineNote,
                        PosMachineNote_DO_i,
                        PosMachineNotePosMachineNote_i_m, GCOT);

    Create_PrototypeBOA(PosMachineManager,
                        IMFW_DataObjectBase_i,
                        PosMachineManagerPosMachineManager_i_m, GCOT);

    Create_PrototypeBOA(PosMachineOperationProcedure,
                        PosMachineOperationProcedure_DO_i,
                        PosMachineOperationProcedurePosMachineOperationProcedure_i_m, GCOT);

    Create_PrototypeBOA(PosEqpMonitor,
                        PosEqpMonitor_DO_i,
                        PosEqpMonitorPosEqpMonitor_i_m, GCOT);

    Create_PrototypeBOA(PosEqpMonitorJob,
                        PosEqpMonitorJob_DO_i,
                        PosEqpMonitorJobPosEqpMonitorJob_i_m, GCOT);
  }
  //return GCOT;
}

