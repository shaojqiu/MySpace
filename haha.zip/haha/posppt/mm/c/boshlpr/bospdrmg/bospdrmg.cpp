//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Thursday, November 2, 2006 4:48:28 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/09 DSIV00001432 S.Kawabe       Support XLC version 9

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1997, 2008.          *
*     (C) COPYRIGHT: IBM Japan Services Company Ltd, 1997, 2008.       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

#include "IMProt.h" //DSIV00001432

// Implementation header files
#include "pcas.hpp"
#include "pdrmg.hpp"
#include "ppcdr.hpp"
#include "ppcdrcp.hpp"
#include "prtclp.hpp"
#include "prtcls.hpp"
#include "pdcj.hpp"
#include "pdstat.hpp"

//DSIV00001432 #include "IMProt.h"

// DO implementation header files
#include "DOBase_i.h"
#include "pcasdo.hpp"
#include "ppcdrcdo.hpp"
#include "ppcdrdo.hpp"
#include "prtclpdo.hpp"
#include "prtclsdo.hpp"
#include "pdcjdo.hpp"
#include "pdstatdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

//GlobalComposedObjectTable* global_func()
void global_func_BOSPDrMg( GlobalComposedObjectTable* GCOT )
{
  //GlobalComposedObjectTable *GCOT = NULL;
  //GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosReticleSet,
                        PosReticleSet_DO_i,
                        PosReticleSetPosReticleSet_i_m, GCOT);

    Create_PrototypeBOA(PosProcessDurableCapability,
                        PosProcessDurableCapability_DO_i,
                        PosProcessDurableCapabilityPosProcessDurableCapability_i_m, GCOT);

    Create_PrototypeBOA(PosReticlePod,
                        PosReticlePod_DO_i,
                        PosReticlePodPosReticlePod_i_m, GCOT);

    Create_PrototypeBOA(PosCassette,
                        PosCassette_DO_i,
                        PosCassettePosCassette_i_m, GCOT);

    Create_PrototypeBOA(PosProcessDurable,
                        PosProcessDurable_DO_i,
                        PosProcessDurablePosProcessDurable_i_m, GCOT);

    Create_PrototypeBOA(PosDurableManager,
                        IMFW_DataObjectBase_i,
                        PosDurableManagerPosDurableManager_i_m, GCOT);

    Create_PrototypeBOA(PosDurableControlJob,
                        PosDurableControlJob_DO_i,
                        PosDurableControlJobPosDurableControlJob_i_m, GCOT);

    Create_PrototypeBOA(PosDurableSubState,
                        PosDurableSubState_DO_i,
                        PosDurableSubStatePosDurableSubState_i_m, GCOT);

  }
  //return GCOT;
}

