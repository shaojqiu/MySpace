//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Wednesday, July 13, 2016 1:54:12 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1992,2005          *
*     (C) COPYRIGHT: IBM Japan Industrial Solution Co., Ltd, 1996,2005       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

// Implementation header files
#include "IMProt.h"

#include "pcas.hpp"
#include "pdcj.hpp"
#include "pdrmg.hpp"
#include "pdstat.hpp"
#include "ppcdr.hpp"
#include "ppcdrcp.hpp"
#include "prtclp.hpp"
#include "prtcls.hpp"


// DO implementation header files
#include "DOBase_i.h"
#include "pcasdo.hpp"
#include "pdcjdo.hpp"
#include "pdstatdo.hpp"
#include "ppcdrcdo.hpp"
#include "ppcdrdo.hpp"
#include "prtclpdo.hpp"
#include "prtclsdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

GlobalComposedObjectTable* global_func()
{
  GlobalComposedObjectTable *GCOT = NULL;
  GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosProcessDurable,
                        PosProcessDurable_DO_i,
                        PosProcessDurablePosProcessDurable_i_m, GCOT);

    Create_PrototypeBOA(PosReticleSet,
                        PosReticleSet_DO_i,
                        PosReticleSetPosReticleSet_i_m, GCOT);

    Create_PrototypeBOA(PosCassette,
                        PosCassette_DO_i,
                        PosCassettePosCassette_i_m, GCOT);

    Create_PrototypeBOA(PosReticlePod,
                        PosReticlePod_DO_i,
                        PosReticlePodPosReticlePod_i_m, GCOT);

    Create_PrototypeBOA(PosDurableManager,
                        IMFW_DataObjectBase_i,
                        PosDurableManagerPosDurableManager_i_m, GCOT);

    Create_PrototypeBOA(PosDurableControlJob,
                        PosDurableControlJob_DO_i,
                        PosDurableControlJobPosDurableControlJob_i_m, GCOT);

    Create_PrototypeBOA(PosDurableSubState,
                        PosDurableSubState_DO_i,
                        PosDurableSubStatePosDurableSubState_i_m, GCOT);

    Create_PrototypeBOA(PosProcessDurableCapability,
                        PosProcessDurableCapability_DO_i,
                        PosProcessDurableCapabilityPosProcessDurableCapability_i_m, GCOT);

  }
  return GCOT;
}

