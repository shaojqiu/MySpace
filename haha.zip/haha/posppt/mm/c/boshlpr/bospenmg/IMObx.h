 #ifndef __checkapperrlog__
   #define __checkapperrlog__

   #ifdef NOAPPERRLOG
     #define APPERRLOG
     #define apperrlog cerr
   #else
     #include "apperrlog.hpp"
   #endif 

 #endif

 #include <private/imcommon.h> 
 #include <implatform.h> //D228 - for definitions of CORBAENV_xxxx macros

// -----------------------------------------------------------------------------
// PosEntityInhibitPosEntityInhibit_i
// -----------------------------------------------------------------------------
class PosEntityInhibitPosEntityInhibit_i_m : public PosEntityInhibit_i {

  public:
/* PosEntityInhibit::setStartTimeStamp */
virtual ::CORBA::Void  setStartTimeStamp (const char* startTimeStamp, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setStartTimeStamp()";
        PosEntityInhibit_i::setStartTimeStamp ( startTimeStamp, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getStartTimeStamp */
virtual char*  getStartTimeStamp (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getStartTimeStamp()";
        retVal =        PosEntityInhibit_i::getStartTimeStamp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setEndTimeStamp */
virtual ::CORBA::Void  setEndTimeStamp (const char* endTimeStamp, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setEndTimeStamp()";
        PosEntityInhibit_i::setEndTimeStamp ( endTimeStamp, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getEndTimeStamp */
virtual char*  getEndTimeStamp (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getEndTimeStamp()";
        retVal =        PosEntityInhibit_i::getEndTimeStamp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setEntities */
virtual ::CORBA::Void  setEntities (const ::PosEntityIdentifierSequence& entities, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setEntities()";
        PosEntityInhibit_i::setEntities ( entities, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getEntities */
virtual ::PosEntityIdentifierSequence*  getEntities (CORBAENV_ONLY_HPP) {
    ::PosEntityIdentifierSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getEntities()";
        retVal =        PosEntityInhibit_i::getEntities (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setSubLotTypes */
virtual ::CORBA::Void  setSubLotTypes (const ::stringSequence& sublottypes, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setSubLotTypes()";
        PosEntityInhibit_i::setSubLotTypes ( sublottypes, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getSubLotTypes */
virtual ::stringSequence*  getSubLotTypes (CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getSubLotTypes()";
        retVal =        PosEntityInhibit_i::getSubLotTypes (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setOwner */
virtual ::CORBA::Void  setOwner (::PosPerson_ptr owner, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setOwner()";
        PosEntityInhibit_i::setOwner ( owner, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getOwner */
virtual ::PosPerson_ptr  getOwner (CORBAENV_ONLY_HPP) {
    ::PosPerson_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getOwner()";
        retVal =        PosEntityInhibit_i::getOwner (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::getInhibitRecord */
virtual ::posEntityInhibitRecord*  getInhibitRecord (CORBAENV_ONLY_HPP) {
    ::posEntityInhibitRecord*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getInhibitRecord()";
        retVal =        PosEntityInhibit_i::getInhibitRecord (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setInhibitRecord */
virtual ::CORBA::Void  setInhibitRecord (const ::posEntityInhibitRecord& entityRecord, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setInhibitRecord()";
        PosEntityInhibit_i::setInhibitRecord ( entityRecord, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::isInhibitFor */
virtual ::CORBA::Boolean  isInhibitFor (const ::PosEntityIdentifierSequence& entities, const ::stringSequence& sublottypes, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::isInhibitFor()";
        retVal =        PosEntityInhibit_i::isInhibitFor ( entities, sublottypes, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setChangedTimeStamp */
virtual ::CORBA::Void  setChangedTimeStamp (const char* changedTimeStamp, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setChangedTimeStamp()";
        PosEntityInhibit_i::setChangedTimeStamp ( changedTimeStamp, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getChangedTimeStamp */
virtual char*  getChangedTimeStamp (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getChangedTimeStamp()";
        retVal =        PosEntityInhibit_i::getChangedTimeStamp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::PosEntityInhibit_init */
virtual ::CORBA::Void  PosEntityInhibit_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::PosEntityInhibit_init()";
        PosEntityInhibit_i::PosEntityInhibit_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::setDescription */
virtual ::CORBA::Void  setDescription (const char* desc, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setDescription()";
        PosEntityInhibit_i::setDescription ( desc, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getDescription()";
        retVal =        PosEntityInhibit_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setCode */
virtual ::CORBA::Void  setCode (::PosCode_ptr code, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setCode()";
        PosEntityInhibit_i::setCode ( code, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getCode */
virtual ::PosCode_ptr  getCode (CORBAENV_ONLY_HPP) {
    ::PosCode_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getCode()";
        retVal =        PosEntityInhibit_i::getCode (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setClaimMemo */
virtual ::CORBA::Void  setClaimMemo (const char* memo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setClaimMemo()";
        PosEntityInhibit_i::setClaimMemo ( memo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getClaimMemo */
virtual char*  getClaimMemo (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getClaimMemo()";
        retVal =        PosEntityInhibit_i::getClaimMemo (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setReasonDetailInfos */
virtual ::CORBA::Void  setReasonDetailInfos (const ::PosEntityInhibitReasonDetailInfoSequence& reasonDetailInfos, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setReasonDetailInfos()";
        PosEntityInhibit_i::setReasonDetailInfos ( reasonDetailInfos, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getReasonDetailInfos */
virtual ::PosEntityInhibitReasonDetailInfoSequence*  getReasonDetailInfos (CORBAENV_ONLY_HPP) {
    ::PosEntityInhibitReasonDetailInfoSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getReasonDetailInfos()";
        retVal =        PosEntityInhibit_i::getReasonDetailInfos (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::removeExceptionLot */
virtual ::CORBA::Void  removeExceptionLot (const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::removeExceptionLot()";
        PosEntityInhibit_i::removeExceptionLot ( lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::removeAllExceptionLots */
virtual ::CORBA::Void  removeAllExceptionLots (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::removeAllExceptionLots()";
        PosEntityInhibit_i::removeAllExceptionLots (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getExceptionLotRecords */
virtual ::PosExceptionLotRecordSequence*  getExceptionLotRecords (CORBAENV_ONLY_HPP) {
    ::PosExceptionLotRecordSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getExceptionLotRecords()";
        retVal =        PosEntityInhibit_i::getExceptionLotRecords (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setExceptionLotRecords */
virtual ::CORBA::Void  setExceptionLotRecords (const ::PosExceptionLotRecordSequence& records, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setExceptionLotRecords()";
        PosEntityInhibit_i::setExceptionLotRecords ( records, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosEntityInhibit::getExceptionLotRecord */
virtual ::posExceptionLotRecord*  getExceptionLotRecord (const ::objectIdentifier& lotID, CORBAENV_ONLY_HPP) {
    ::posExceptionLotRecord*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getExceptionLotRecord()";
        retVal =        PosEntityInhibit_i::getExceptionLotRecord ( lotID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosEntityInhibit::setExceptionLotRecord */
virtual ::CORBA::Void  setExceptionLotRecord (const ::objectIdentifier& lotID, const ::posExceptionLotRecord& record, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setExceptionLotRecord()";
        PosEntityInhibit_i::setExceptionLotRecord ( lotID, record, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setTheTIEObject()";
        PosEntityInhibit_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::CIMFWBO_init()";
        PosEntityInhibit_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::CIMFW_clear()";
        PosEntityInhibit_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setObjectManager()";
        PosEntityInhibit_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getObjectManager()";
        retVal =        PosEntityInhibit_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::touchMe()";
        PosEntityInhibit_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::checkForDeletion()";
        retVal =        PosEntityInhibit_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getUserDataSetNamed()";
        retVal =        PosEntityInhibit_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getUserDataSetSequenceNamed()";
        retVal =        PosEntityInhibit_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::allUserDataSets()";
        retVal =        PosEntityInhibit_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::removeUserDataSetNamed()";
        PosEntityInhibit_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::removeUserDataSetSequenceNamed()";
        PosEntityInhibit_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::removeAllUserDataSets()";
        PosEntityInhibit_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setUserDataSetNamed()";
        PosEntityInhibit_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setUserDataSetSequenceNamed()";
        PosEntityInhibit_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getUserDataNamed()";
        retVal =        PosEntityInhibit_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getUserDataSequenceNamed()";
        retVal =        PosEntityInhibit_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::allUserDataSetsFor()";
        retVal =        PosEntityInhibit_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::removeUserDataSetsFor()";
        PosEntityInhibit_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::getUserDataSetNamedAndOrig()";
        retVal =        PosEntityInhibit_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::setUserDataSetNamedAndOrig()";
        PosEntityInhibit_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::removeUserDataSetNamedAndOrg()";
        PosEntityInhibit_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::TxLockMainObject()";
        retVal =        PosEntityInhibit_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::TxLockElements()";
        retVal =        PosEntityInhibit_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosEntityInhibit_i::TxnUnlock()";
        retVal =        PosEntityInhibit_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

