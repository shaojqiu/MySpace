//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Thursday, November 2, 2006 5:07:19 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/09 DSIV00001432 S.Kawabe       Support XLC version 9

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1997, 2008.          *
*     (C) COPYRIGHT: IBM Japan Services Company Ltd, 1997, 2008.       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

#include "IMProt.h" //DSIV00001432

// Implementation header files
#include "pctrlj.hpp"
#include "pftrwk.hpp"
#include "plot.hpp"
#include "plotfm.hpp"
#include "plottype.hpp"
#include "pltcmnt.hpp"
#include "pltnt.hpp"
#include "pltopnt.hpp"
#include "pmongrp.hpp"
#include "pplspj.hpp"
#include "pprmgr.hpp"
#include "pwafer.hpp"

//DSIV00001432 #include "IMProt.h"

// DO implementation header files
#include "DOBase_i.h"
#include "pctrljdo.hpp"
#include "pftrwkdo.hpp"
#include "plotdo.hpp"
#include "plotfmdo.hpp"
#include "plottydo.hpp"
#include "pltcmndo.hpp"
#include "pltntdo.hpp"
#include "pltopndo.hpp"
#include "pmongrdo.hpp"
#include "pplspjdo.hpp"
#include "pwaferdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

//GlobalComposedObjectTable* global_func()
void global_func_BOSPPrMg( GlobalComposedObjectTable* GCOT )
{
  //GlobalComposedObjectTable *GCOT = NULL;
  //GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosLotComment,
                        PosLotComment_DO_i,
                        PosLotCommentPosLotComment_i_m, GCOT);

    Create_PrototypeBOA(PosMonitorGroup,
                        PosMonitorGroup_DO_i,
                        PosMonitorGroupPosMonitorGroup_i_m, GCOT);

    Create_PrototypeBOA(PosWafer,
                        PosWafer_DO_i,
                        PosWaferPosWafer_i_m, GCOT);

    Create_PrototypeBOA(PosLotFamily,
                        PosLotFamily_DO_i,
                        PosLotFamilyPosLotFamily_i_m, GCOT);

    Create_PrototypeBOA(PosLotNote,
                        PosLotNote_DO_i,
                        PosLotNotePosLotNote_i_m, GCOT);

    Create_PrototypeBOA(PosLotType,
                        PosLotType_DO_i,
                        PosLotTypePosLotType_i_m, GCOT);

    Create_PrototypeBOA(PosFutureReworkRequest,
                        PosFutureReworkRequest_DO_i,
                        PosFutureReworkRequestPosFutureReworkRequest_i_m, GCOT);

    Create_PrototypeBOA(PosProductManager,
                        IMFW_DataObjectBase_i,
                        PosProductManagerPosProductManager_i_m, GCOT);

    Create_PrototypeBOA(PosControlJob,
                        PosControlJob_DO_i,
                        PosControlJobPosControlJob_i_m, GCOT);

    Create_PrototypeBOA(PosPlannedSplitJob,
                        PosPlannedSplitJob_DO_i,
                        PosPlannedSplitJobPosPlannedSplitJob_i_m, GCOT);

    Create_PrototypeBOA(PosLotOperationNote,
                        PosLotOperationNote_DO_i,
                        PosLotOperationNotePosLotOperationNote_i_m, GCOT);

    Create_PrototypeBOA(PosLot,
                        PosLot_DO_i,
                        PosLotPosLot_i_m, GCOT);

  }
  //return GCOT;
}

