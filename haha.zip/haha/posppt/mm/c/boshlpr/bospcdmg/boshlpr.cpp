//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Tuesday, February 23, 2016 3:40:09 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1992,2005          *
*     (C) COPYRIGHT: IBM Japan Industrial Solution Co., Ltd, 1996,2005       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

// Implementation header files
#include "IMProt.h"

#include "pcatgry.hpp"
#include "pcdmgr.hpp"
#include "pcode.hpp"
#include "pe10st.hpp"
#include "pmom.hpp"
#include "pmstat.hpp"
#include "prmsts.hpp"
#include "pscript.hpp"
#include "psysmsg.hpp"


// DO implementation header files
#include "DOBase_i.h"
#include "pcatgrdo.hpp"
#include "pcodedo.hpp"
#include "pe10stdo.hpp"
#include "pmomdo.hpp"
#include "pmstatdo.hpp"
#include "prmstsdo.hpp"
#include "pscripdo.hpp"
#include "psysmsdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

GlobalComposedObjectTable* global_func()
{
  GlobalComposedObjectTable *GCOT = NULL;
  GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosE10State,
                        PosE10State_DO_i,
                        PosE10StatePosE10State_i_m, GCOT);

    Create_PrototypeBOA(PosSystemMessageCode,
                        PosSystemMessageCode_DO_i,
                        PosSystemMessageCodePosSystemMessageCode_i_m, GCOT);

    Create_PrototypeBOA(PosCode,
                        PosCode_DO_i,
                        PosCodePosCode_i_m, GCOT);

    Create_PrototypeBOA(PosCategory,
                        PosCategory_DO_i,
                        PosCategoryPosCategory_i_m, GCOT);

    Create_PrototypeBOA(PosRawMachineStateSet,
                        PosRawMachineStateSet_DO_i,
                        PosRawMachineStateSetPosRawMachineStateSet_i_m, GCOT);

    Create_PrototypeBOA(PosMachineOperationMode,
                        PosMachineOperationMode_DO_i,
                        PosMachineOperationModePosMachineOperationMode_i_m, GCOT);

    Create_PrototypeBOA(PosCodeManager,
                        IMFW_DataObjectBase_i,
                        PosCodeManagerPosCodeManager_i_m, GCOT);

    Create_PrototypeBOA(PosMachineState,
                        PosMachineState_DO_i,
                        PosMachineStatePosMachineState_i_m, GCOT);

    Create_PrototypeBOA(PosScript,
                        PosScript_DO_i,
                        PosScriptPosScript_i_m, GCOT);

  }
  return GCOT;
}

