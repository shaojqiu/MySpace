//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Tuesday, February 23, 2016 3:39:32 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1992,2005          *
*     (C) COPYRIGHT: IBM Japan Industrial Solution Co., Ltd, 1996,2005       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

// Implementation header files
#include "IMProt.h"

#include "pathmgr.hpp"


// DO implementation header files
#include "DOBase_i.h"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

GlobalComposedObjectTable* global_func()
{
  GlobalComposedObjectTable *GCOT = NULL;
  GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosAuthenticationManager,
                        IMFW_DataObjectBase_i,
                        PosAuthenticationManagerPosAuthenticationManager_i_m, GCOT);

  }
  return GCOT;
}

