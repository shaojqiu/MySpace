 #ifndef __checkapperrlog__
   #define __checkapperrlog__

   #ifdef NOAPPERRLOG
     #define APPERRLOG
     #define apperrlog cerr
   #else
     #include "apperrlog.hpp"
   #endif 

 #endif

 #include <private/imcommon.h> 
 #include <implatform.h> //D228 - for definitions of CORBAENV_xxxx macros

// -----------------------------------------------------------------------------
// PosMessageDistributionManagerPosMessageDistributionManager_i
// -----------------------------------------------------------------------------
class PosMessageDistributionManagerPosMessageDistributionManager_i_m : public PosMessageDistributionManager_i {

  public:
/* PosMessageDistributionManager::PosMessageDistributionManager_init */
virtual ::CORBA::Void  PosMessageDistributionManager_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::PosMessageDistributionManager_init()";
        PosMessageDistributionManager_i::PosMessageDistributionManager_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDistributionManager::createMessageDefinitionNamed */
virtual ::PosMessageDefinition_ptr  createMessageDefinitionNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosMessageDefinition_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::createMessageDefinitionNamed()";
        retVal =        PosMessageDistributionManager_i::createMessageDefinitionNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDistributionManager::removeMessageDefinition */
virtual ::CORBA::Void  removeMessageDefinition (::PosMessageDefinition_ptr aMessageDefinition, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::removeMessageDefinition()";
        PosMessageDistributionManager_i::removeMessageDefinition ( aMessageDefinition, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDistributionManager::allMessageDefinitions */
virtual ::PosMessageDefinitionSequence*  allMessageDefinitions (CORBAENV_ONLY_HPP) {
    ::PosMessageDefinitionSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::allMessageDefinitions()";
        retVal =        PosMessageDistributionManager_i::allMessageDefinitions (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDistributionManager::findMessageDefinitionNamed */
virtual ::PosMessageDefinition_ptr  findMessageDefinitionNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosMessageDefinition_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::findMessageDefinitionNamed()";
        retVal =        PosMessageDistributionManager_i::findMessageDefinitionNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDistributionManager::addMessageRequest */
virtual ::CORBA::Void  addMessageRequest (const ::posMessageRequest& messageRequest, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::addMessageRequest()";
        PosMessageDistributionManager_i::addMessageRequest ( messageRequest, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDistributionManager::removeMessageRequest */
virtual ::CORBA::Void  removeMessageRequest (const ::posMessageRequest& messageRequest, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::removeMessageRequest()";
        PosMessageDistributionManager_i::removeMessageRequest ( messageRequest, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDistributionManager::allMessageRequests */
virtual ::PosMessageRequestSequence*  allMessageRequests (CORBAENV_ONLY_HPP) {
    ::PosMessageRequestSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::allMessageRequests()";
        retVal =        PosMessageDistributionManager_i::allMessageRequests (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDistributionManager::firstMessageRequest */
virtual ::posMessageRequest*  firstMessageRequest (CORBAENV_ONLY_HPP) {
    ::posMessageRequest*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::firstMessageRequest()";
        retVal =        PosMessageDistributionManager_i::firstMessageRequest (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDistributionManager::removeAllMessageDefinitions */
virtual ::CORBA::Void  removeAllMessageDefinitions (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::removeAllMessageDefinitions()";
        PosMessageDistributionManager_i::removeAllMessageDefinitions (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeRegistered */
virtual ::CORBA::Void  makeRegistered (::MESFactory_ptr aFactory, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::makeRegistered()";
        PosMessageDistributionManager_i::makeRegistered ( aFactory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeNotRegistered */
virtual ::CORBA::Void  makeNotRegistered (::MESFactory_ptr aFactory, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::makeNotRegistered()";
        PosMessageDistributionManager_i::makeNotRegistered ( aFactory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeStartingUp */
virtual ::CORBA::Void  makeStartingUp (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::makeStartingUp()";
        PosMessageDistributionManager_i::makeStartingUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeShuttingDown */
virtual ::CORBA::Void  makeShuttingDown (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::makeShuttingDown()";
        PosMessageDistributionManager_i::makeShuttingDown (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::isStopped */
virtual ::CORBA::Boolean  isStopped (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::isStopped()";
        retVal =        PosMessageDistributionManager_i::isStopped (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isStartingUp */
virtual ::CORBA::Boolean  isStartingUp (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::isStartingUp()";
        retVal =        PosMessageDistributionManager_i::isStartingUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isOperating */
virtual ::CORBA::Boolean  isOperating (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::isOperating()";
        retVal =        PosMessageDistributionManager_i::isOperating (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isShuttingDown */
virtual ::CORBA::Boolean  isShuttingDown (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::isShuttingDown()";
        retVal =        PosMessageDistributionManager_i::isShuttingDown (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isNotRegistered */
virtual ::CORBA::Boolean  isNotRegistered (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::isNotRegistered()";
        retVal =        PosMessageDistributionManager_i::isNotRegistered (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isRegistered */
virtual ::CORBA::Boolean  isRegistered (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::isRegistered()";
        retVal =        PosMessageDistributionManager_i::isRegistered (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::makeStopped */
virtual ::CORBA::Void  makeStopped (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::makeStopped()";
        PosMessageDistributionManager_i::makeStopped (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::ComponentManager_init */
virtual ::CORBA::Void  ComponentManager_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::ComponentManager_init()";
        PosMessageDistributionManager_i::ComponentManager_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::resourceLevel */
virtual char*  resourceLevel (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::resourceLevel()";
        retVal =        PosMessageDistributionManager_i::resourceLevel (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Resource::nameQualifiedTo */
virtual char*  nameQualifiedTo (const char* resourceLevel, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::nameQualifiedTo()";
        retVal =        PosMessageDistributionManager_i::nameQualifiedTo ( resourceLevel, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Resource::startUp */
virtual ::CORBA::Void  startUp (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::startUp()";
        PosMessageDistributionManager_i::startUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::shutdownNormal */
virtual ::CORBA::Void  shutdownNormal (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::shutdownNormal()";
        PosMessageDistributionManager_i::shutdownNormal (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::shutdownImmediate */
virtual ::CORBA::Void  shutdownImmediate (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::shutdownImmediate()";
        PosMessageDistributionManager_i::shutdownImmediate (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::Resource_init */
virtual ::CORBA::Void  Resource_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::Resource_init()";
        PosMessageDistributionManager_i::Resource_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* OwnedEntity::setOwner */
virtual ::CORBA::Void  setOwner (::Person_ptr owner, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::setOwner()";
        PosMessageDistributionManager_i::setOwner ( owner, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* OwnedEntity::getOwner */
virtual ::Person_ptr  getOwner (CORBAENV_ONLY_HPP) {
    ::Person_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::getOwner()";
        retVal =        PosMessageDistributionManager_i::getOwner (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* OwnedEntity::OwnedEntity_init */
virtual ::CORBA::Void  OwnedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::OwnedEntity_init()";
        PosMessageDistributionManager_i::OwnedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::isNamed()";
        retVal =        PosMessageDistributionManager_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::setName()";
        PosMessageDistributionManager_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::getName()";
        retVal =        PosMessageDistributionManager_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::NamedEntity_init()";
        PosMessageDistributionManager_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::setTheTIEObject()";
        PosMessageDistributionManager_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::CIMFWBO_init()";
        PosMessageDistributionManager_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::CIMFW_clear()";
        PosMessageDistributionManager_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::setObjectManager()";
        PosMessageDistributionManager_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::getObjectManager()";
        retVal =        PosMessageDistributionManager_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::touchMe()";
        PosMessageDistributionManager_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::checkForDeletion()";
        retVal =        PosMessageDistributionManager_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::getUserDataSetNamed()";
        retVal =        PosMessageDistributionManager_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::getUserDataSetSequenceNamed()";
        retVal =        PosMessageDistributionManager_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::allUserDataSets()";
        retVal =        PosMessageDistributionManager_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::removeUserDataSetNamed()";
        PosMessageDistributionManager_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::removeUserDataSetSequenceNamed()";
        PosMessageDistributionManager_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::removeAllUserDataSets()";
        PosMessageDistributionManager_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::setUserDataSetNamed()";
        PosMessageDistributionManager_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::setUserDataSetSequenceNamed()";
        PosMessageDistributionManager_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::getUserDataNamed()";
        retVal =        PosMessageDistributionManager_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::getUserDataSequenceNamed()";
        retVal =        PosMessageDistributionManager_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::allUserDataSetsFor()";
        retVal =        PosMessageDistributionManager_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::removeUserDataSetsFor()";
        PosMessageDistributionManager_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::getUserDataSetNamedAndOrig()";
        retVal =        PosMessageDistributionManager_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::setUserDataSetNamedAndOrig()";
        PosMessageDistributionManager_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::removeUserDataSetNamedAndOrg()";
        PosMessageDistributionManager_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::TxLockMainObject()";
        retVal =        PosMessageDistributionManager_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::TxLockElements()";
        retVal =        PosMessageDistributionManager_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDistributionManager_i::TxnUnlock()";
        retVal =        PosMessageDistributionManager_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosMessageDefinitionPosMessageDefinition_i
// -----------------------------------------------------------------------------
class PosMessageDefinitionPosMessageDefinition_i_m : public PosMessageDefinition_i {

  public:
/* PosMessageDefinition::PosMessageDefinition_init */
virtual ::CORBA::Void  PosMessageDefinition_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::PosMessageDefinition_init()";
        PosMessageDefinition_i::PosMessageDefinition_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setIdentifier()";
        PosMessageDefinition_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getIdentifier()";
        retVal =        PosMessageDefinition_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setDescription()";
        PosMessageDefinition_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getDescription()";
        retVal =        PosMessageDefinition_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setMessageMediaID */
virtual ::CORBA::Void  setMessageMediaID (const char* messageMediaId, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setMessageMediaID()";
        PosMessageDefinition_i::setMessageMediaID ( messageMediaId, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getMessageMediaID */
virtual char*  getMessageMediaID (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getMessageMediaID()";
        retVal =        PosMessageDefinition_i::getMessageMediaID (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setMessageType */
virtual ::CORBA::Void  setMessageType (const char* messageType, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setMessageType()";
        PosMessageDefinition_i::setMessageType ( messageType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getMesssageType */
virtual char*  getMesssageType (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getMesssageType()";
        retVal =        PosMessageDefinition_i::getMesssageType (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setTemplateFileName */
virtual ::CORBA::Void  setTemplateFileName (const char* templateFileName, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setTemplateFileName()";
        PosMessageDefinition_i::setTemplateFileName ( templateFileName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getTemplateFileName */
virtual char*  getTemplateFileName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getTemplateFileName()";
        retVal =        PosMessageDefinition_i::getTemplateFileName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setMessageDistributionType */
virtual ::CORBA::Void  setMessageDistributionType (const char* messageDistributionType, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setMessageDistributionType()";
        PosMessageDefinition_i::setMessageDistributionType ( messageDistributionType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getMessageDistributionType */
virtual char*  getMessageDistributionType (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getMessageDistributionType()";
        retVal =        PosMessageDefinition_i::getMessageDistributionType (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setPrimaryMessage */
virtual ::CORBA::Void  setPrimaryMessage (const char* primaryMessage, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setPrimaryMessage()";
        PosMessageDefinition_i::setPrimaryMessage ( primaryMessage, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getPrimaryMessage */
virtual char*  getPrimaryMessage (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getPrimaryMessage()";
        retVal =        PosMessageDefinition_i::getPrimaryMessage (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setSecondaryMessage */
virtual ::CORBA::Void  setSecondaryMessage (const char* secondaryMessage, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setSecondaryMessage()";
        PosMessageDefinition_i::setSecondaryMessage ( secondaryMessage, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getSecondaryMessage */
virtual char*  getSecondaryMessage (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getSecondaryMessage()";
        retVal =        PosMessageDefinition_i::getSecondaryMessage (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setSubsystem */
virtual ::CORBA::Void  setSubsystem (const char* subsystem, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setSubsystem()";
        PosMessageDefinition_i::setSubsystem ( subsystem, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::getSubsystem */
virtual char*  getSubsystem (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getSubsystem()";
        retVal =        PosMessageDefinition_i::getSubsystem (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::addDestinationPerson */
virtual ::CORBA::Void  addDestinationPerson (::PosPerson_ptr aDestinationPerson, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::addDestinationPerson()";
        PosMessageDefinition_i::addDestinationPerson ( aDestinationPerson, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::removeDestinationPerson */
virtual ::CORBA::Void  removeDestinationPerson (::PosPerson_ptr aDestinationPerson, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::removeDestinationPerson()";
        PosMessageDefinition_i::removeDestinationPerson ( aDestinationPerson, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosMessageDefinition::allDestinationPersons */
virtual ::PosPersonSequence*  allDestinationPersons (CORBAENV_ONLY_HPP) {
    ::PosPersonSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::allDestinationPersons()";
        retVal =        PosMessageDefinition_i::allDestinationPersons (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::findDestinationPersonNamed */
virtual ::PosPerson_ptr  findDestinationPersonNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosPerson_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::findDestinationPersonNamed()";
        retVal =        PosMessageDefinition_i::findDestinationPersonNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosMessageDefinition::setMessageDistributionInfo */
virtual ::CORBA::Void  setMessageDistributionInfo (const ::brMessageDistributionInfo& messageDistributionInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setMessageDistributionInfo()";
        PosMessageDefinition_i::setMessageDistributionInfo ( messageDistributionInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::isNamed()";
        retVal =        PosMessageDefinition_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setName()";
        PosMessageDefinition_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getName()";
        retVal =        PosMessageDefinition_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::NamedEntity_init()";
        PosMessageDefinition_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setTheTIEObject()";
        PosMessageDefinition_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::CIMFWBO_init()";
        PosMessageDefinition_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::CIMFW_clear()";
        PosMessageDefinition_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setObjectManager()";
        PosMessageDefinition_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getObjectManager()";
        retVal =        PosMessageDefinition_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::touchMe()";
        PosMessageDefinition_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::checkForDeletion()";
        retVal =        PosMessageDefinition_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getUserDataSetNamed()";
        retVal =        PosMessageDefinition_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getUserDataSetSequenceNamed()";
        retVal =        PosMessageDefinition_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::allUserDataSets()";
        retVal =        PosMessageDefinition_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::removeUserDataSetNamed()";
        PosMessageDefinition_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::removeUserDataSetSequenceNamed()";
        PosMessageDefinition_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::removeAllUserDataSets()";
        PosMessageDefinition_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setUserDataSetNamed()";
        PosMessageDefinition_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setUserDataSetSequenceNamed()";
        PosMessageDefinition_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getUserDataNamed()";
        retVal =        PosMessageDefinition_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getUserDataSequenceNamed()";
        retVal =        PosMessageDefinition_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::allUserDataSetsFor()";
        retVal =        PosMessageDefinition_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::removeUserDataSetsFor()";
        PosMessageDefinition_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::getUserDataSetNamedAndOrig()";
        retVal =        PosMessageDefinition_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::setUserDataSetNamedAndOrig()";
        PosMessageDefinition_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::removeUserDataSetNamedAndOrg()";
        PosMessageDefinition_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::TxLockMainObject()";
        retVal =        PosMessageDefinition_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::TxLockElements()";
        retVal =        PosMessageDefinition_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosMessageDefinition_i::TxnUnlock()";
        retVal =        PosMessageDefinition_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

