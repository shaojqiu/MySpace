//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Wednesday, September 21, 2016 12:12:52 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1992,2005          *
*     (C) COPYRIGHT: IBM Japan Industrial Solution Co., Ltd, 1996,2005       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

// Implementation header files
#include "IMProt.h"

#include "pbindf.hpp"
#include "pbinsp.hpp"
#include "pcustmr.hpp"
#include "pcustpr.hpp"
#include "pprsp.hpp"
#include "pprspg.hpp"
#include "pprspmg.hpp"
#include "pprstch.hpp"
#include "ppsctgy.hpp"
#include "psmplsp.hpp"
#include "ptestsp.hpp"
#include "ptesttp.hpp"


// DO implementation header files
#include "DOBase_i.h"
#include "pbindfdo.hpp"
#include "pbinspdo.hpp"
#include "pcustmdo.hpp"
#include "pcustpdo.hpp"
#include "pprspdo.hpp"
#include "pprspgdo.hpp"
#include "pprstcdo.hpp"
#include "ppsctgdo.hpp"
#include "psmplsdo.hpp"
#include "ptestsdo.hpp"
#include "ptesttdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

GlobalComposedObjectTable* global_func()
{
  GlobalComposedObjectTable *GCOT = NULL;
  GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosTestType,
                        PosTestType_DO_i,
                        PosTestTypePosTestType_i_m, GCOT);

    Create_PrototypeBOA(PosTechnology,
                        PosTechnology_DO_i,
                        PosTechnologyPosTechnology_i_m, GCOT);

    Create_PrototypeBOA(PosBinSpecification,
                        PosBinSpecification_DO_i,
                        PosBinSpecificationPosBinSpecification_i_m, GCOT);

    Create_PrototypeBOA(PosCustomer,
                        PosCustomer_DO_i,
                        PosCustomerPosCustomer_i_m, GCOT);

    Create_PrototypeBOA(PosProductGroup,
                        PosProductGroup_DO_i,
                        PosProductGroupPosProductGroup_i_m, GCOT);

    Create_PrototypeBOA(PosSampleSpecification,
                        PosSampleSpecification_DO_i,
                        PosSampleSpecificationPosSampleSpecification_i_m, GCOT);

    Create_PrototypeBOA(PosProductSpecificationManager,
                        IMFW_DataObjectBase_i,
                        PosProductSpecificationManagerPosProductSpecificationManager_i_m, GCOT);

    Create_PrototypeBOA(PosBinDefinition,
                        PosBinDefinition_DO_i,
                        PosBinDefinitionPosBinDefinition_i_m, GCOT);

    Create_PrototypeBOA(PosProductSpecification,
                        PosProductSpecification_DO_i,
                        PosProductSpecificationPosProductSpecification_i_m, GCOT);

    Create_PrototypeBOA(PosProductCategory,
                        PosProductCategory_DO_i,
                        PosProductCategoryPosProductCategory_i_m, GCOT);

    Create_PrototypeBOA(PosTestSpecification,
                        PosTestSpecification_DO_i,
                        PosTestSpecificationPosTestSpecification_i_m, GCOT);

    Create_PrototypeBOA(PosCustomerProduct,
                        PosCustomerProduct_DO_i,
                        PosCustomerProductPosCustomerProduct_i_m, GCOT);

  }
  return GCOT;
}

