 #ifndef __checkapperrlog__
   #define __checkapperrlog__

   #ifdef NOAPPERRLOG
     #define APPERRLOG
     #define apperrlog cerr
   #else
     #include "apperrlog.hpp"
   #endif 

 #endif

 #include <private/imcommon.h> 
 #include <implatform.h> //D228 - for definitions of CORBAENV_xxxx macros

// -----------------------------------------------------------------------------
// PosBinDefinitionPosBinDefinition_i
// -----------------------------------------------------------------------------
class PosBinDefinitionPosBinDefinition_i_m : public PosBinDefinition_i {

  public:
/* PosBinDefinition::PosBinDefinition_init */
virtual ::CORBA::Void  PosBinDefinition_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::PosBinDefinition_init()";
        PosBinDefinition_i::PosBinDefinition_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinDefinition::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setIdentifier()";
        PosBinDefinition_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinDefinition::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getIdentifier()";
        retVal =        PosBinDefinition_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBinDefinition::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setDescription()";
        PosBinDefinition_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinDefinition::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getDescription()";
        retVal =        PosBinDefinition_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBinDefinition::addBinSpec */
virtual ::CORBA::Void  addBinSpec (const ::posBinSpec& binSpec, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::addBinSpec()";
        PosBinDefinition_i::addBinSpec ( binSpec, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinDefinition::findBinSpec */
virtual ::posBinSpec*  findBinSpec (const char* binNumber, CORBAENV_ONLY_HPP) {
    ::posBinSpec*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::findBinSpec()";
        retVal =        PosBinDefinition_i::findBinSpec ( binNumber, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBinDefinition::allBinSpecs */
virtual ::PosBinSpecSequence*  allBinSpecs (CORBAENV_ONLY_HPP) {
    ::PosBinSpecSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::allBinSpecs()";
        retVal =        PosBinDefinition_i::allBinSpecs (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBinDefinition::removeBinSpec */
virtual ::CORBA::Void  removeBinSpec (const char* binNumber, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::removeBinSpec()";
        PosBinDefinition_i::removeBinSpec ( binNumber, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinDefinition::setBinDefinitionInfo */
virtual ::CORBA::Void  setBinDefinitionInfo (const ::brBinDefinitionInfo& binDefinitionInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setBinDefinitionInfo()";
        PosBinDefinition_i::setBinDefinitionInfo ( binDefinitionInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::isNamed()";
        retVal =        PosBinDefinition_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setName()";
        PosBinDefinition_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getName()";
        retVal =        PosBinDefinition_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::NamedEntity_init()";
        PosBinDefinition_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setTheTIEObject()";
        PosBinDefinition_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::CIMFWBO_init()";
        PosBinDefinition_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::CIMFW_clear()";
        PosBinDefinition_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setObjectManager()";
        PosBinDefinition_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getObjectManager()";
        retVal =        PosBinDefinition_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::touchMe()";
        PosBinDefinition_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::checkForDeletion()";
        retVal =        PosBinDefinition_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getUserDataSetNamed()";
        retVal =        PosBinDefinition_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getUserDataSetSequenceNamed()";
        retVal =        PosBinDefinition_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::allUserDataSets()";
        retVal =        PosBinDefinition_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::removeUserDataSetNamed()";
        PosBinDefinition_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::removeUserDataSetSequenceNamed()";
        PosBinDefinition_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::removeAllUserDataSets()";
        PosBinDefinition_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setUserDataSetNamed()";
        PosBinDefinition_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setUserDataSetSequenceNamed()";
        PosBinDefinition_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getUserDataNamed()";
        retVal =        PosBinDefinition_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getUserDataSequenceNamed()";
        retVal =        PosBinDefinition_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::allUserDataSetsFor()";
        retVal =        PosBinDefinition_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::removeUserDataSetsFor()";
        PosBinDefinition_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::getUserDataSetNamedAndOrig()";
        retVal =        PosBinDefinition_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::setUserDataSetNamedAndOrig()";
        PosBinDefinition_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::removeUserDataSetNamedAndOrg()";
        PosBinDefinition_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::TxLockMainObject()";
        retVal =        PosBinDefinition_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::TxLockElements()";
        retVal =        PosBinDefinition_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinDefinition_i::TxnUnlock()";
        retVal =        PosBinDefinition_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosBinSpecificationPosBinSpecification_i
// -----------------------------------------------------------------------------
class PosBinSpecificationPosBinSpecification_i_m : public PosBinSpecification_i {

  public:
/* PosBinSpecification::PosBinSpecification_init */
virtual ::CORBA::Void  PosBinSpecification_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::PosBinSpecification_init()";
        PosBinSpecification_i::PosBinSpecification_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinSpecification::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getDescription()";
        retVal =        PosBinSpecification_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBinSpecification::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getIdentifier()";
        retVal =        PosBinSpecification_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBinSpecification::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setDescription()";
        PosBinSpecification_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinSpecification::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setIdentifier()";
        PosBinSpecification_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinSpecification::setPassCriteria */
virtual ::CORBA::Void  setPassCriteria (const char* passCriteria, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setPassCriteria()";
        PosBinSpecification_i::setPassCriteria ( passCriteria, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosBinSpecification::getPassCriteria */
virtual char*  getPassCriteria (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getPassCriteria()";
        retVal =        PosBinSpecification_i::getPassCriteria (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosBinSpecification::setBinSpecificationInfo */
virtual ::CORBA::Void  setBinSpecificationInfo (const ::brBinSpecificationInfo& binSpecificationInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setBinSpecificationInfo()";
        PosBinSpecification_i::setBinSpecificationInfo ( binSpecificationInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::isNamed()";
        retVal =        PosBinSpecification_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setName()";
        PosBinSpecification_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getName()";
        retVal =        PosBinSpecification_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::NamedEntity_init()";
        PosBinSpecification_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setTheTIEObject()";
        PosBinSpecification_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::CIMFWBO_init()";
        PosBinSpecification_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::CIMFW_clear()";
        PosBinSpecification_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setObjectManager()";
        PosBinSpecification_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getObjectManager()";
        retVal =        PosBinSpecification_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::touchMe()";
        PosBinSpecification_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::checkForDeletion()";
        retVal =        PosBinSpecification_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getUserDataSetNamed()";
        retVal =        PosBinSpecification_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getUserDataSetSequenceNamed()";
        retVal =        PosBinSpecification_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::allUserDataSets()";
        retVal =        PosBinSpecification_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::removeUserDataSetNamed()";
        PosBinSpecification_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::removeUserDataSetSequenceNamed()";
        PosBinSpecification_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::removeAllUserDataSets()";
        PosBinSpecification_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setUserDataSetNamed()";
        PosBinSpecification_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setUserDataSetSequenceNamed()";
        PosBinSpecification_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getUserDataNamed()";
        retVal =        PosBinSpecification_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getUserDataSequenceNamed()";
        retVal =        PosBinSpecification_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::allUserDataSetsFor()";
        retVal =        PosBinSpecification_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::removeUserDataSetsFor()";
        PosBinSpecification_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::getUserDataSetNamedAndOrig()";
        retVal =        PosBinSpecification_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::setUserDataSetNamedAndOrig()";
        PosBinSpecification_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::removeUserDataSetNamedAndOrg()";
        PosBinSpecification_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::TxLockMainObject()";
        retVal =        PosBinSpecification_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::TxLockElements()";
        retVal =        PosBinSpecification_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosBinSpecification_i::TxnUnlock()";
        retVal =        PosBinSpecification_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosCustomerPosCustomer_i
// -----------------------------------------------------------------------------
class PosCustomerPosCustomer_i_m : public PosCustomer_i {

  public:
/* PosCustomer::PosCustomer_init */
virtual ::CORBA::Void  PosCustomer_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::PosCustomer_init()";
        PosCustomer_i::PosCustomer_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomer::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setIdentifier()";
        PosCustomer_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomer::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getIdentifier()";
        retVal =        PosCustomer_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosCustomer::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setDescription()";
        PosCustomer_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomer::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getDescription()";
        retVal =        PosCustomer_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosCustomer::createCustomerProductNamed */
virtual ::PosCustomerProduct_ptr  createCustomerProductNamed (const char* identifier, ::PosProductSpecification_ptr aProductSpecification, CORBAENV_ONLY_HPP) {
    ::PosCustomerProduct_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::createCustomerProductNamed()";
        retVal =        PosCustomer_i::createCustomerProductNamed ( identifier, aProductSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosCustomer::findCustomerProductNamed */
virtual ::PosCustomerProduct_ptr  findCustomerProductNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosCustomerProduct_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::findCustomerProductNamed()";
        retVal =        PosCustomer_i::findCustomerProductNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosCustomer::allCustomerProducts */
virtual ::PosCustomerProductSequence*  allCustomerProducts (CORBAENV_ONLY_HPP) {
    ::PosCustomerProductSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::allCustomerProducts()";
        retVal =        PosCustomer_i::allCustomerProducts (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosCustomer::removeCustomerProduct */
virtual ::CORBA::Void  removeCustomerProduct (::PosCustomerProduct_ptr aCustomerProduct, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::removeCustomerProduct()";
        PosCustomer_i::removeCustomerProduct ( aCustomerProduct, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomer::removeAllCustomerProducts */
virtual ::CORBA::Void  removeAllCustomerProducts (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::removeAllCustomerProducts()";
        PosCustomer_i::removeAllCustomerProducts (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomer::setCustomerInfo */
virtual ::CORBA::Void  setCustomerInfo (const ::brCustomerInfo& customerInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setCustomerInfo()";
        PosCustomer_i::setCustomerInfo ( customerInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::isNamed()";
        retVal =        PosCustomer_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setName()";
        PosCustomer_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getName()";
        retVal =        PosCustomer_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::NamedEntity_init()";
        PosCustomer_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setTheTIEObject()";
        PosCustomer_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::CIMFWBO_init()";
        PosCustomer_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::CIMFW_clear()";
        PosCustomer_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setObjectManager()";
        PosCustomer_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getObjectManager()";
        retVal =        PosCustomer_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::touchMe()";
        PosCustomer_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::checkForDeletion()";
        retVal =        PosCustomer_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getUserDataSetNamed()";
        retVal =        PosCustomer_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getUserDataSetSequenceNamed()";
        retVal =        PosCustomer_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::allUserDataSets()";
        retVal =        PosCustomer_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::removeUserDataSetNamed()";
        PosCustomer_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::removeUserDataSetSequenceNamed()";
        PosCustomer_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::removeAllUserDataSets()";
        PosCustomer_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setUserDataSetNamed()";
        PosCustomer_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setUserDataSetSequenceNamed()";
        PosCustomer_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getUserDataNamed()";
        retVal =        PosCustomer_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getUserDataSequenceNamed()";
        retVal =        PosCustomer_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::allUserDataSetsFor()";
        retVal =        PosCustomer_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::removeUserDataSetsFor()";
        PosCustomer_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::getUserDataSetNamedAndOrig()";
        retVal =        PosCustomer_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::setUserDataSetNamedAndOrig()";
        PosCustomer_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::removeUserDataSetNamedAndOrg()";
        PosCustomer_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::TxLockMainObject()";
        retVal =        PosCustomer_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::TxLockElements()";
        retVal =        PosCustomer_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomer_i::TxnUnlock()";
        retVal =        PosCustomer_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosCustomerProductPosCustomerProduct_i
// -----------------------------------------------------------------------------
class PosCustomerProductPosCustomerProduct_i_m : public PosCustomerProduct_i {

  public:
/* PosCustomerProduct::PosCustomerProduct_init */
virtual ::CORBA::Void  PosCustomerProduct_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::PosCustomerProduct_init()";
        PosCustomerProduct_i::PosCustomerProduct_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomerProduct::setCustomerProductID */
virtual ::CORBA::Void  setCustomerProductID (const char* customerProductID, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setCustomerProductID()";
        PosCustomerProduct_i::setCustomerProductID ( customerProductID, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomerProduct::getCustomerProductID */
virtual char*  getCustomerProductID (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getCustomerProductID()";
        retVal =        PosCustomerProduct_i::getCustomerProductID (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosCustomerProduct::setCustomer */
virtual ::CORBA::Void  setCustomer (::PosCustomer_ptr aCustomer, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setCustomer()";
        PosCustomerProduct_i::setCustomer ( aCustomer, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomerProduct::getCustomer */
virtual ::PosCustomer_ptr  getCustomer (CORBAENV_ONLY_HPP) {
    ::PosCustomer_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getCustomer()";
        retVal =        PosCustomerProduct_i::getCustomer (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosCustomerProduct::setProductSpecification */
virtual ::CORBA::Void  setProductSpecification (::PosProductSpecification_ptr aProductSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setProductSpecification()";
        PosCustomerProduct_i::setProductSpecification ( aProductSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosCustomerProduct::getProductSpecification */
virtual ::PosProductSpecification_ptr  getProductSpecification (CORBAENV_ONLY_HPP) {
    ::PosProductSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getProductSpecification()";
        retVal =        PosCustomerProduct_i::getProductSpecification (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosCustomerProduct::setCustomerProductInfo */
virtual ::CORBA::Void  setCustomerProductInfo (const ::brCustomerProductInfo& customerProductInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setCustomerProductInfo()";
        PosCustomerProduct_i::setCustomerProductInfo ( customerProductInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::isNamed()";
        retVal =        PosCustomerProduct_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setName()";
        PosCustomerProduct_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getName()";
        retVal =        PosCustomerProduct_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::NamedEntity_init()";
        PosCustomerProduct_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setTheTIEObject()";
        PosCustomerProduct_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::CIMFWBO_init()";
        PosCustomerProduct_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::CIMFW_clear()";
        PosCustomerProduct_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setObjectManager()";
        PosCustomerProduct_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getObjectManager()";
        retVal =        PosCustomerProduct_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::touchMe()";
        PosCustomerProduct_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::checkForDeletion()";
        retVal =        PosCustomerProduct_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getUserDataSetNamed()";
        retVal =        PosCustomerProduct_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getUserDataSetSequenceNamed()";
        retVal =        PosCustomerProduct_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::allUserDataSets()";
        retVal =        PosCustomerProduct_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::removeUserDataSetNamed()";
        PosCustomerProduct_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::removeUserDataSetSequenceNamed()";
        PosCustomerProduct_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::removeAllUserDataSets()";
        PosCustomerProduct_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setUserDataSetNamed()";
        PosCustomerProduct_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setUserDataSetSequenceNamed()";
        PosCustomerProduct_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getUserDataNamed()";
        retVal =        PosCustomerProduct_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getUserDataSequenceNamed()";
        retVal =        PosCustomerProduct_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::allUserDataSetsFor()";
        retVal =        PosCustomerProduct_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::removeUserDataSetsFor()";
        PosCustomerProduct_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::getUserDataSetNamedAndOrig()";
        retVal =        PosCustomerProduct_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::setUserDataSetNamedAndOrig()";
        PosCustomerProduct_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::removeUserDataSetNamedAndOrg()";
        PosCustomerProduct_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::TxLockMainObject()";
        retVal =        PosCustomerProduct_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::TxLockElements()";
        retVal =        PosCustomerProduct_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosCustomerProduct_i::TxnUnlock()";
        retVal =        PosCustomerProduct_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosProductSpecificationPosProductSpecification_i
// -----------------------------------------------------------------------------
class PosProductSpecificationPosProductSpecification_i_m : public PosProductSpecification_i {

  public:
/* PosProductSpecification::PosProductSpecification_init */
virtual ::CORBA::Void  PosProductSpecification_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::PosProductSpecification_init()";
        PosProductSpecification_i::PosProductSpecification_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setDescription()";
        PosProductSpecification_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getDescription()";
        retVal =        PosProductSpecification_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setProductGroup */
virtual ::CORBA::Void  setProductGroup (::PosProductGroup_ptr aProductGroup, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setProductGroup()";
        PosProductSpecification_i::setProductGroup ( aProductGroup, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getProductGroup */
virtual ::PosProductGroup_ptr  getProductGroup (CORBAENV_ONLY_HPP) {
    ::PosProductGroup_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getProductGroup()";
        retVal =        PosProductSpecification_i::getProductGroup (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setProductType */
virtual ::CORBA::Void  setProductType (const char* productType, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setProductType()";
        PosProductSpecification_i::setProductType ( productType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getProductType */
virtual char*  getProductType (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getProductType()";
        retVal =        PosProductSpecification_i::getProductType (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setOwnerUser */
virtual ::CORBA::Void  setOwnerUser (::PosPerson_ptr aPerson, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setOwnerUser()";
        PosProductSpecification_i::setOwnerUser ( aPerson, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getOwnerUser */
virtual ::PosPerson_ptr  getOwnerUser (CORBAENV_ONLY_HPP) {
    ::PosPerson_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getOwnerUser()";
        retVal =        PosProductSpecification_i::getOwnerUser (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setSchedulerUserGroup */
virtual ::CORBA::Void  setSchedulerUserGroup (const char* ownerGroup, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setSchedulerUserGroup()";
        PosProductSpecification_i::setSchedulerUserGroup ( ownerGroup, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getSchedulerUserGroup */
virtual char*  getSchedulerUserGroup (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getSchedulerUserGroup()";
        retVal =        PosProductSpecification_i::getSchedulerUserGroup (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setReleaseBatchSize */
virtual ::CORBA::Void  setReleaseBatchSize (::CORBA::Long releaseBatchSize, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setReleaseBatchSize()";
        PosProductSpecification_i::setReleaseBatchSize ( releaseBatchSize, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getReleaseBatchSize */
virtual ::CORBA::Long  getReleaseBatchSize (CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getReleaseBatchSize()";
        retVal =        PosProductSpecification_i::getReleaseBatchSize (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setPlannedCycleTime */
virtual ::CORBA::Void  setPlannedCycleTime (::Duration aDuration, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setPlannedCycleTime()";
        PosProductSpecification_i::setPlannedCycleTime ( aDuration, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::setProductInfo__101 */
virtual ::CORBA::Void  setProductInfo__101 (const ::brProductInfo__101& productInfo__101, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setProductInfo__101()";
        PosProductSpecification_i::setProductInfo__101 ( productInfo__101, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getPlannedCycleTime */
virtual ::Duration  getPlannedCycleTime (CORBAENV_ONLY_HPP) {
    ::Duration  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getPlannedCycleTime()";
        retVal =        PosProductSpecification_i::getPlannedCycleTime (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setPlannedYield */
virtual ::CORBA::Void  setPlannedYield (::CORBA::Double plannedYield, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setPlannedYield()";
        PosProductSpecification_i::setPlannedYield ( plannedYield, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getPlannedYield */
virtual ::CORBA::Double  getPlannedYield (CORBAENV_ONLY_HPP) {
    ::CORBA::Double  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getPlannedYield()";
        retVal =        PosProductSpecification_i::getPlannedYield (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setSafetyStockLevel */
virtual ::CORBA::Void  setSafetyStockLevel (::CORBA::Long safetyStockLevel, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setSafetyStockLevel()";
        PosProductSpecification_i::setSafetyStockLevel ( safetyStockLevel, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getSafetyStockLevel */
virtual ::CORBA::Long  getSafetyStockLevel (CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getSafetyStockLevel()";
        retVal =        PosProductSpecification_i::getSafetyStockLevel (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::makeFinishedGoodFlagOn */
virtual ::CORBA::Void  makeFinishedGoodFlagOn (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::makeFinishedGoodFlagOn()";
        PosProductSpecification_i::makeFinishedGoodFlagOn (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::makeFinishedGoodFlagOff */
virtual ::CORBA::Void  makeFinishedGoodFlagOff (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::makeFinishedGoodFlagOff()";
        PosProductSpecification_i::makeFinishedGoodFlagOff (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::isFinishedGoodFlag */
virtual ::CORBA::Boolean  isFinishedGoodFlag (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::isFinishedGoodFlag()";
        retVal =        PosProductSpecification_i::isFinishedGoodFlag (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setMFGLayer */
virtual ::CORBA::Void  setMFGLayer (const char* MFGLayer, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setMFGLayer()";
        PosProductSpecification_i::setMFGLayer ( MFGLayer, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getMFGLayer */
virtual char*  getMFGLayer (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getMFGLayer()";
        retVal =        PosProductSpecification_i::getMFGLayer (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setMarkingCharacter */
virtual ::CORBA::Void  setMarkingCharacter (const char* markingCharacter, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setMarkingCharacter()";
        PosProductSpecification_i::setMarkingCharacter ( markingCharacter, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getMarkingCharacter */
virtual char*  getMarkingCharacter (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getMarkingCharacter()";
        retVal =        PosProductSpecification_i::getMarkingCharacter (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::addSourceProductSpecification */
virtual ::CORBA::Void  addSourceProductSpecification (::PosProductSpecification_ptr aProductSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::addSourceProductSpecification()";
        PosProductSpecification_i::addSourceProductSpecification ( aProductSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::findSourceProductSpecificationNamed */
virtual ::PosProductSpecification_ptr  findSourceProductSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosProductSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::findSourceProductSpecificationNamed()";
        retVal =        PosProductSpecification_i::findSourceProductSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::allSourceProductSpecifications */
virtual ::PosProductSpecificationSequence*  allSourceProductSpecifications (CORBAENV_ONLY_HPP) {
    ::PosProductSpecificationSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::allSourceProductSpecifications()";
        retVal =        PosProductSpecification_i::allSourceProductSpecifications (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::removeSourceProductSpecification */
virtual ::CORBA::Void  removeSourceProductSpecification (::PosProductSpecification_ptr aProductSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::removeSourceProductSpecification()";
        PosProductSpecification_i::removeSourceProductSpecification ( aProductSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::setProductInfo */
virtual ::CORBA::Void  setProductInfo (const ::brProductInfo& productInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setProductInfo()";
        PosProductSpecification_i::setProductInfo ( productInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::setProductCategory */
virtual ::CORBA::Void  setProductCategory (::PosProductCategory_ptr aProductCategory, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setProductCategory()";
        PosProductSpecification_i::setProductCategory ( aProductCategory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getProductCategory */
virtual ::PosProductCategory_ptr  getProductCategory (CORBAENV_ONLY_HPP) {
    ::PosProductCategory_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getProductCategory()";
        retVal =        PosProductSpecification_i::getProductCategory (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setLotGenerationType */
virtual ::CORBA::Void  setLotGenerationType (const char* lotGenerationType, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setLotGenerationType()";
        PosProductSpecification_i::setLotGenerationType ( lotGenerationType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getLotGenerationType */
virtual char*  getLotGenerationType (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getLotGenerationType()";
        retVal =        PosProductSpecification_i::getLotGenerationType (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::getPropertySet */
virtual ::PosPropertySet_ptr  getPropertySet (CORBAENV_ONLY_HPP) {
    ::PosPropertySet_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getPropertySet()";
        retVal =        PosProductSpecification_i::getPropertySet (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::addMultiPD */
virtual ::CORBA::Void  addMultiPD (const ::posMultiMainPD& aMultiPD, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::addMultiPD()";
        PosProductSpecification_i::addMultiPD ( aMultiPD, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::allMultiPD */
virtual ::PosMultiMainPDSequence*  allMultiPD (CORBAENV_ONLY_HPP) {
    ::PosMultiMainPDSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::allMultiPD()";
        retVal =        PosProductSpecification_i::allMultiPD (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::findMultiPDFor */
virtual ::posMultiMainPD*  findMultiPDFor (const char* orderType, CORBAENV_ONLY_HPP) {
    ::posMultiMainPD*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::findMultiPDFor()";
        retVal =        PosProductSpecification_i::findMultiPDFor ( orderType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::removeMultiPD */
virtual ::CORBA::Void  removeMultiPD (const char* anIdentifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::removeMultiPD()";
        PosProductSpecification_i::removeMultiPD ( anIdentifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::removeAllMultiPD */
virtual ::CORBA::Void  removeAllMultiPD (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::removeAllMultiPD()";
        PosProductSpecification_i::removeAllMultiPD (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::setState */
virtual ::CORBA::Void  setState (const char* state, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setState()";
        PosProductSpecification_i::setState ( state, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getState */
virtual char*  getState (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getState()";
        retVal =        PosProductSpecification_i::getState (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setReticleSet */
virtual ::CORBA::Void  setReticleSet (::PosReticleSet_ptr aReticleSet, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setReticleSet()";
        PosProductSpecification_i::setReticleSet ( aReticleSet, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getReticleSet */
virtual ::PosReticleSet_ptr  getReticleSet (CORBAENV_ONLY_HPP) {
    ::PosReticleSet_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getReticleSet()";
        retVal =        PosProductSpecification_i::getReticleSet (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::makeSerialManagementFlagOff */
virtual ::CORBA::Void  makeSerialManagementFlagOff (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::makeSerialManagementFlagOff()";
        PosProductSpecification_i::makeSerialManagementFlagOff (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::makeSerialManagementFlagOn */
virtual ::CORBA::Void  makeSerialManagementFlagOn (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::makeSerialManagementFlagOn()";
        PosProductSpecification_i::makeSerialManagementFlagOn (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::isSerialManagementFlag */
virtual ::CORBA::Boolean  isSerialManagementFlag (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::isSerialManagementFlag()";
        retVal =        PosProductSpecification_i::isSerialManagementFlag (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::makeFPCAvailableFlagOn */
virtual ::CORBA::Void  makeFPCAvailableFlagOn (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::makeFPCAvailableFlagOn()";
        PosProductSpecification_i::makeFPCAvailableFlagOn (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::makeFPCAvailableFlagOff */
virtual ::CORBA::Void  makeFPCAvailableFlagOff (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::makeFPCAvailableFlagOff()";
        PosProductSpecification_i::makeFPCAvailableFlagOff (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::isFPCAvailableFlagOn */
virtual ::CORBA::Boolean  isFPCAvailableFlagOn (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::isFPCAvailableFlagOn()";
        retVal =        PosProductSpecification_i::isFPCAvailableFlagOn (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setProductInfo__100 */
virtual ::CORBA::Void  setProductInfo__100 (const ::brProductInfo__100& productInfo__100, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setProductInfo__100()";
        PosProductSpecification_i::setProductInfo__100 ( productInfo__100, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::setBOM */
virtual ::CORBA::Void  setBOM (::PosBOM_ptr aBOM, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setBOM()";
        PosProductSpecification_i::setBOM ( aBOM, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::getBOM */
virtual ::PosBOM_ptr  getBOM (CORBAENV_ONLY_HPP) {
    ::PosBOM_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getBOM()";
        retVal =        PosProductSpecification_i::getBOM (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::createPropertySet */
virtual ::PosPropertySet_ptr  createPropertySet (CORBAENV_ONLY_HPP) {
    ::PosPropertySet_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::createPropertySet()";
        retVal =        PosProductSpecification_i::createPropertySet (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::setProductInfo__170 */
virtual ::CORBA::Void  setProductInfo__170 (const ::brProductInfo__170& productInfo__170, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setProductInfo__170()";
        PosProductSpecification_i::setProductInfo__170 ( productInfo__170, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecification::findSourceProductSpecificationInfoNamed */
virtual ::posSourceProductSpecificationInfo*  findSourceProductSpecificationInfoNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::posSourceProductSpecificationInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::findSourceProductSpecificationInfoNamed()";
        retVal =        PosProductSpecification_i::findSourceProductSpecificationInfoNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecification::allSourceProductSpecificationInfos */
virtual ::PosSourceProductSpecificationInfoSequence*  allSourceProductSpecificationInfos (CORBAENV_ONLY_HPP) {
    ::PosSourceProductSpecificationInfoSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::allSourceProductSpecificationInfos()";
        retVal =        PosProductSpecification_i::allSourceProductSpecificationInfos (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ProductSpecification::isEqualTo */
virtual ::CORBA::Boolean  isEqualTo (::ProductSpecification_ptr testProductSpecification, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::isEqualTo()";
        retVal =        PosProductSpecification_i::isEqualTo ( testProductSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ProductSpecification::getProcessDefinition */
virtual ::ProcessDefinition_ptr  getProcessDefinition (CORBAENV_ONLY_HPP) {
    ::ProcessDefinition_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getProcessDefinition()";
        retVal =        PosProductSpecification_i::getProcessDefinition (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ProductSpecification::setProcessDefinition */
virtual ::CORBA::Void  setProcessDefinition (::ProcessDefinition_ptr aProcessDefinition, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setProcessDefinition()";
        PosProductSpecification_i::setProcessDefinition ( aProcessDefinition, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ProductSpecification::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getIdentifier()";
        retVal =        PosProductSpecification_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ProductSpecification::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setIdentifier()";
        PosProductSpecification_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ProductSpecification::ProductSpecification_init */
virtual ::CORBA::Void  ProductSpecification_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::ProductSpecification_init()";
        PosProductSpecification_i::ProductSpecification_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::isNamed()";
        retVal =        PosProductSpecification_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setName()";
        PosProductSpecification_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getName()";
        retVal =        PosProductSpecification_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::NamedEntity_init()";
        PosProductSpecification_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setTheTIEObject()";
        PosProductSpecification_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::CIMFWBO_init()";
        PosProductSpecification_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::CIMFW_clear()";
        PosProductSpecification_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setObjectManager()";
        PosProductSpecification_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getObjectManager()";
        retVal =        PosProductSpecification_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::touchMe()";
        PosProductSpecification_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::checkForDeletion()";
        retVal =        PosProductSpecification_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getUserDataSetNamed()";
        retVal =        PosProductSpecification_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getUserDataSetSequenceNamed()";
        retVal =        PosProductSpecification_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::allUserDataSets()";
        retVal =        PosProductSpecification_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::removeUserDataSetNamed()";
        PosProductSpecification_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::removeUserDataSetSequenceNamed()";
        PosProductSpecification_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::removeAllUserDataSets()";
        PosProductSpecification_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setUserDataSetNamed()";
        PosProductSpecification_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setUserDataSetSequenceNamed()";
        PosProductSpecification_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getUserDataNamed()";
        retVal =        PosProductSpecification_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getUserDataSequenceNamed()";
        retVal =        PosProductSpecification_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::allUserDataSetsFor()";
        retVal =        PosProductSpecification_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::removeUserDataSetsFor()";
        PosProductSpecification_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::getUserDataSetNamedAndOrig()";
        retVal =        PosProductSpecification_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::setUserDataSetNamedAndOrig()";
        PosProductSpecification_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::removeUserDataSetNamedAndOrg()";
        PosProductSpecification_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::TxLockMainObject()";
        retVal =        PosProductSpecification_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::TxLockElements()";
        retVal =        PosProductSpecification_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecification_i::TxnUnlock()";
        retVal =        PosProductSpecification_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosProductGroupPosProductGroup_i
// -----------------------------------------------------------------------------
class PosProductGroupPosProductGroup_i_m : public PosProductGroup_i {

  public:
/* PosProductGroup::PosProductGroup_init */
virtual ::CORBA::Void  PosProductGroup_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::PosProductGroup_init()";
        PosProductGroup_i::PosProductGroup_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setIdentifier()";
        PosProductGroup_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getIdentifier()";
        retVal =        PosProductGroup_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setDescription()";
        PosProductGroup_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getDescription()";
        retVal =        PosProductGroup_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setTechnology */
virtual ::CORBA::Void  setTechnology (::PosTechnology_ptr aTechnology, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setTechnology()";
        PosProductGroup_i::setTechnology ( aTechnology, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getTechnology */
virtual ::PosTechnology_ptr  getTechnology (CORBAENV_ONLY_HPP) {
    ::PosTechnology_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getTechnology()";
        retVal =        PosProductGroup_i::getTechnology (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setOwnerUser */
virtual ::CORBA::Void  setOwnerUser (::PosPerson_ptr aPerson, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setOwnerUser()";
        PosProductGroup_i::setOwnerUser ( aPerson, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getOwnerUser */
virtual ::PosPerson_ptr  getOwnerUser (CORBAENV_ONLY_HPP) {
    ::PosPerson_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getOwnerUser()";
        retVal =        PosProductGroup_i::getOwnerUser (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setChipSize */
virtual ::CORBA::Void  setChipSize (const ::coordinate2D& chipSize, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setChipSize()";
        PosProductGroup_i::setChipSize ( chipSize, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getChipSize */
virtual ::coordinate2D  getChipSize (CORBAENV_ONLY_HPP) {
    ::coordinate2D  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getChipSize()";
        retVal =        PosProductGroup_i::getChipSize (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setPlannedCycleTime */
virtual ::CORBA::Void  setPlannedCycleTime (::Duration aDuration, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setPlannedCycleTime()";
        PosProductGroup_i::setPlannedCycleTime ( aDuration, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getPlannedCycleTime */
virtual ::Duration  getPlannedCycleTime (CORBAENV_ONLY_HPP) {
    ::Duration  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getPlannedCycleTime()";
        retVal =        PosProductGroup_i::getPlannedCycleTime (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setPlannedYield */
virtual ::CORBA::Void  setPlannedYield (::CORBA::Double plannedYield, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setPlannedYield()";
        PosProductGroup_i::setPlannedYield ( plannedYield, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getPlannedYield */
virtual ::CORBA::Double  getPlannedYield (CORBAENV_ONLY_HPP) {
    ::CORBA::Double  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getPlannedYield()";
        retVal =        PosProductGroup_i::getPlannedYield (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setGrossDieCount */
virtual ::CORBA::Void  setGrossDieCount (::CORBA::Long grossDieCount, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setGrossDieCount()";
        PosProductGroup_i::setGrossDieCount ( grossDieCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getGrossDieCount */
virtual ::CORBA::Long  getGrossDieCount (CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getGrossDieCount()";
        retVal =        PosProductGroup_i::getGrossDieCount (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setProductGroupInfo */
virtual ::CORBA::Void  setProductGroupInfo (const ::brProductGroupInfo& productGroupInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setProductGroupInfo()";
        PosProductGroup_i::setProductGroupInfo ( productGroupInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductGroup::getUserGroups */
virtual ::PosUserGroupSequence*  getUserGroups (CORBAENV_ONLY_HPP) {
    ::PosUserGroupSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getUserGroups()";
        retVal =        PosProductGroup_i::getUserGroups (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductGroup::setUserGroups */
virtual ::CORBA::Void  setUserGroups (const ::PosUserGroupSequence& aUserGroupSequence, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setUserGroups()";
        PosProductGroup_i::setUserGroups ( aUserGroupSequence, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::isNamed()";
        retVal =        PosProductGroup_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setName()";
        PosProductGroup_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getName()";
        retVal =        PosProductGroup_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::NamedEntity_init()";
        PosProductGroup_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setTheTIEObject()";
        PosProductGroup_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::CIMFWBO_init()";
        PosProductGroup_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::CIMFW_clear()";
        PosProductGroup_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setObjectManager()";
        PosProductGroup_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getObjectManager()";
        retVal =        PosProductGroup_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::touchMe()";
        PosProductGroup_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::checkForDeletion()";
        retVal =        PosProductGroup_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getUserDataSetNamed()";
        retVal =        PosProductGroup_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getUserDataSetSequenceNamed()";
        retVal =        PosProductGroup_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::allUserDataSets()";
        retVal =        PosProductGroup_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::removeUserDataSetNamed()";
        PosProductGroup_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::removeUserDataSetSequenceNamed()";
        PosProductGroup_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::removeAllUserDataSets()";
        PosProductGroup_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setUserDataSetNamed()";
        PosProductGroup_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setUserDataSetSequenceNamed()";
        PosProductGroup_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getUserDataNamed()";
        retVal =        PosProductGroup_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getUserDataSequenceNamed()";
        retVal =        PosProductGroup_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::allUserDataSetsFor()";
        retVal =        PosProductGroup_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::removeUserDataSetsFor()";
        PosProductGroup_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::getUserDataSetNamedAndOrig()";
        retVal =        PosProductGroup_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::setUserDataSetNamedAndOrig()";
        PosProductGroup_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::removeUserDataSetNamedAndOrg()";
        PosProductGroup_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::TxLockMainObject()";
        retVal =        PosProductGroup_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::TxLockElements()";
        retVal =        PosProductGroup_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductGroup_i::TxnUnlock()";
        retVal =        PosProductGroup_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosProductSpecificationManagerPosProductSpecificationManager_i
// -----------------------------------------------------------------------------
class PosProductSpecificationManagerPosProductSpecificationManager_i_m : public PosProductSpecificationManager_i {

  public:
/* PosProductSpecificationManager::PosProductSpecificationManager_init */
virtual ::CORBA::Void  PosProductSpecificationManager_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::PosProductSpecificationManager_init()";
        PosProductSpecificationManager_i::PosProductSpecificationManager_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createTechnologyNamed */
virtual ::PosTechnology_ptr  createTechnologyNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosTechnology_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createTechnologyNamed()";
        retVal =        PosProductSpecificationManager_i::createTechnologyNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findTechnologyNamed */
virtual ::PosTechnology_ptr  findTechnologyNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosTechnology_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findTechnologyNamed()";
        retVal =        PosProductSpecificationManager_i::findTechnologyNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::allTechnologies */
virtual ::PosTechnologySequence*  allTechnologies (CORBAENV_ONLY_HPP) {
    ::PosTechnologySequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allTechnologies()";
        retVal =        PosProductSpecificationManager_i::allTechnologies (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeTechnology */
virtual ::CORBA::Void  removeTechnology (::PosTechnology_ptr aTechnology, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeTechnology()";
        PosProductSpecificationManager_i::removeTechnology ( aTechnology, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createProductGroupNamed */
virtual ::PosProductGroup_ptr  createProductGroupNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosProductGroup_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createProductGroupNamed()";
        retVal =        PosProductSpecificationManager_i::createProductGroupNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findProductGroupNamed */
virtual ::PosProductGroup_ptr  findProductGroupNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosProductGroup_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findProductGroupNamed()";
        retVal =        PosProductSpecificationManager_i::findProductGroupNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::allProductGroups */
virtual ::PosProductGroupSequence*  allProductGroups (CORBAENV_ONLY_HPP) {
    ::PosProductGroupSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allProductGroups()";
        retVal =        PosProductSpecificationManager_i::allProductGroups (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeProductGroup */
virtual ::CORBA::Void  removeProductGroup (::PosProductGroup_ptr aProductGroup, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeProductGroup()";
        PosProductSpecificationManager_i::removeProductGroup ( aProductGroup, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createBinDefinitionNamed */
virtual ::PosBinDefinition_ptr  createBinDefinitionNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosBinDefinition_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createBinDefinitionNamed()";
        retVal =        PosProductSpecificationManager_i::createBinDefinitionNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findBinDefinitionNamed */
virtual ::PosBinDefinition_ptr  findBinDefinitionNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosBinDefinition_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findBinDefinitionNamed()";
        retVal =        PosProductSpecificationManager_i::findBinDefinitionNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::allBinDefinitions */
virtual ::PosBinDefinitionSequence*  allBinDefinitions (CORBAENV_ONLY_HPP) {
    ::PosBinDefinitionSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allBinDefinitions()";
        retVal =        PosProductSpecificationManager_i::allBinDefinitions (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeBinDefinition */
virtual ::CORBA::Void  removeBinDefinition (::PosBinDefinition_ptr aBinDefinition, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeBinDefinition()";
        PosProductSpecificationManager_i::removeBinDefinition ( aBinDefinition, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createCustomerNamed */
virtual ::PosCustomer_ptr  createCustomerNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosCustomer_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createCustomerNamed()";
        retVal =        PosProductSpecificationManager_i::createCustomerNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findCustomerNamed */
virtual ::PosCustomer_ptr  findCustomerNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosCustomer_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findCustomerNamed()";
        retVal =        PosProductSpecificationManager_i::findCustomerNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::allCustomers */
virtual ::PosCustomerSequence*  allCustomers (CORBAENV_ONLY_HPP) {
    ::PosCustomerSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allCustomers()";
        retVal =        PosProductSpecificationManager_i::allCustomers (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeCustomer */
virtual ::CORBA::Void  removeCustomer (::PosCustomer_ptr aCustomer, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeCustomer()";
        PosProductSpecificationManager_i::removeCustomer ( aCustomer, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createProductCategoryNamed */
virtual ::PosProductCategory_ptr  createProductCategoryNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosProductCategory_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createProductCategoryNamed()";
        retVal =        PosProductSpecificationManager_i::createProductCategoryNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findProductCategoryNamed */
virtual ::PosProductCategory_ptr  findProductCategoryNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosProductCategory_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findProductCategoryNamed()";
        retVal =        PosProductSpecificationManager_i::findProductCategoryNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::allProductCategorys */
virtual ::PosProductCategorySequence*  allProductCategorys (CORBAENV_ONLY_HPP) {
    ::PosProductCategorySequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allProductCategorys()";
        retVal =        PosProductSpecificationManager_i::allProductCategorys (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeProductCategory */
virtual ::CORBA::Void  removeProductCategory (::PosProductCategory_ptr aProductCategory, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeProductCategory()";
        PosProductSpecificationManager_i::removeProductCategory ( aProductCategory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::removeAllTechnologies */
virtual ::CORBA::Void  removeAllTechnologies (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllTechnologies()";
        PosProductSpecificationManager_i::removeAllTechnologies (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::removeAllProductGroups */
virtual ::CORBA::Void  removeAllProductGroups (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllProductGroups()";
        PosProductSpecificationManager_i::removeAllProductGroups (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::removeAllBinDefinitions */
virtual ::CORBA::Void  removeAllBinDefinitions (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllBinDefinitions()";
        PosProductSpecificationManager_i::removeAllBinDefinitions (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::removeAllCustomers */
virtual ::CORBA::Void  removeAllCustomers (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllCustomers()";
        PosProductSpecificationManager_i::removeAllCustomers (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::removeAllProductCategories */
virtual ::CORBA::Void  removeAllProductCategories (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllProductCategories()";
        PosProductSpecificationManager_i::removeAllProductCategories (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createTestSpecificationNamed */
virtual ::PosTestSpecification_ptr  createTestSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosTestSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createTestSpecificationNamed()";
        retVal =        PosProductSpecificationManager_i::createTestSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findTestSpecificationNamed */
virtual ::PosTestSpecification_ptr  findTestSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosTestSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findTestSpecificationNamed()";
        retVal =        PosProductSpecificationManager_i::findTestSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::allTestSpecifications */
virtual ::PosTestSpecificationSequence*  allTestSpecifications (CORBAENV_ONLY_HPP) {
    ::PosTestSpecificationSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allTestSpecifications()";
        retVal =        PosProductSpecificationManager_i::allTestSpecifications (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeTestSpecification */
virtual ::CORBA::Void  removeTestSpecification (::PosTestSpecification_ptr aTestSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeTestSpecification()";
        PosProductSpecificationManager_i::removeTestSpecification ( aTestSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::removeAllTestSpecifications */
virtual ::CORBA::Void  removeAllTestSpecifications (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllTestSpecifications()";
        PosProductSpecificationManager_i::removeAllTestSpecifications (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createBinSpecificationNamed */
virtual ::PosBinSpecification_ptr  createBinSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosBinSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createBinSpecificationNamed()";
        retVal =        PosProductSpecificationManager_i::createBinSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findBinSpecificationNamed */
virtual ::PosBinSpecification_ptr  findBinSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosBinSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findBinSpecificationNamed()";
        retVal =        PosProductSpecificationManager_i::findBinSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::allBinSpecifications */
virtual ::PosBinSpecificationSequence*  allBinSpecifications (CORBAENV_ONLY_HPP) {
    ::PosBinSpecificationSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allBinSpecifications()";
        retVal =        PosProductSpecificationManager_i::allBinSpecifications (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeBinSpecification */
virtual ::CORBA::Void  removeBinSpecification (::PosBinSpecification_ptr aBinSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeBinSpecification()";
        PosProductSpecificationManager_i::removeBinSpecification ( aBinSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::removeAllBinSpecifications */
virtual ::CORBA::Void  removeAllBinSpecifications (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllBinSpecifications()";
        PosProductSpecificationManager_i::removeAllBinSpecifications (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createTestTypeNamed */
virtual ::PosTestType_ptr  createTestTypeNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosTestType_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createTestTypeNamed()";
        retVal =        PosProductSpecificationManager_i::createTestTypeNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findTestTypeNamed */
virtual ::PosTestType_ptr  findTestTypeNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosTestType_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findTestTypeNamed()";
        retVal =        PosProductSpecificationManager_i::findTestTypeNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::allTestTypes */
virtual ::PosTestTypeSequence*  allTestTypes (CORBAENV_ONLY_HPP) {
    ::PosTestTypeSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allTestTypes()";
        retVal =        PosProductSpecificationManager_i::allTestTypes (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeTestType */
virtual ::CORBA::Void  removeTestType (::PosTestType_ptr aTestType, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeTestType()";
        PosProductSpecificationManager_i::removeTestType ( aTestType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::removeAllTestTypes */
virtual ::CORBA::Void  removeAllTestTypes (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllTestTypes()";
        PosProductSpecificationManager_i::removeAllTestTypes (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createSampleSpecificationNamed */
virtual ::PosSampleSpecification_ptr  createSampleSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosSampleSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createSampleSpecificationNamed()";
        retVal =        PosProductSpecificationManager_i::createSampleSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeSampleSpecification */
virtual ::CORBA::Void  removeSampleSpecification (::PosSampleSpecification_ptr aSampleSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeSampleSpecification()";
        PosProductSpecificationManager_i::removeSampleSpecification ( aSampleSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::allSampleSpecifications */
virtual ::PosSampleSpecificationSequence*  allSampleSpecifications (CORBAENV_ONLY_HPP) {
    ::PosSampleSpecificationSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allSampleSpecifications()";
        retVal =        PosProductSpecificationManager_i::allSampleSpecifications (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::findSampleSpecificationNamed */
virtual ::PosSampleSpecification_ptr  findSampleSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::PosSampleSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findSampleSpecificationNamed()";
        retVal =        PosProductSpecificationManager_i::findSampleSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductSpecificationManager::removeAllSampleSpecification */
virtual ::CORBA::Void  removeAllSampleSpecification (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllSampleSpecification()";
        PosProductSpecificationManager_i::removeAllSampleSpecification (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductSpecificationManager::createProductSpecificationNamed */
virtual ::ProductSpecification_ptr  createProductSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::ProductSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::createProductSpecificationNamed()";
        retVal =        PosProductSpecificationManager_i::createProductSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ProductSpecificationManager::removeProductSpecification */
virtual ::CORBA::Void  removeProductSpecification (::ProductSpecification_ptr aProductSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeProductSpecification()";
        PosProductSpecificationManager_i::removeProductSpecification ( aProductSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ProductSpecificationManager::allProductSpecifications */
virtual ::ProductSpecificationSequence*  allProductSpecifications (CORBAENV_ONLY_HPP) {
    ::ProductSpecificationSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allProductSpecifications()";
        retVal =        PosProductSpecificationManager_i::allProductSpecifications (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ProductSpecificationManager::findProductSpecificationNamed */
virtual ::ProductSpecification_ptr  findProductSpecificationNamed (const char* identifier, CORBAENV_ONLY_HPP) {
    ::ProductSpecification_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::findProductSpecificationNamed()";
        retVal =        PosProductSpecificationManager_i::findProductSpecificationNamed ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ProductSpecificationManager::ProductSpecificationManager_init */
virtual ::CORBA::Void  ProductSpecificationManager_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::ProductSpecificationManager_init()";
        PosProductSpecificationManager_i::ProductSpecificationManager_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ProductSpecificationManager::removeAllProductSpecifications */
virtual ::CORBA::Void  removeAllProductSpecifications (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllProductSpecifications()";
        PosProductSpecificationManager_i::removeAllProductSpecifications (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeRegistered */
virtual ::CORBA::Void  makeRegistered (::MESFactory_ptr aFactory, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::makeRegistered()";
        PosProductSpecificationManager_i::makeRegistered ( aFactory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeNotRegistered */
virtual ::CORBA::Void  makeNotRegistered (::MESFactory_ptr aFactory, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::makeNotRegistered()";
        PosProductSpecificationManager_i::makeNotRegistered ( aFactory, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeStartingUp */
virtual ::CORBA::Void  makeStartingUp (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::makeStartingUp()";
        PosProductSpecificationManager_i::makeStartingUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::makeShuttingDown */
virtual ::CORBA::Void  makeShuttingDown (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::makeShuttingDown()";
        PosProductSpecificationManager_i::makeShuttingDown (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::isStopped */
virtual ::CORBA::Boolean  isStopped (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::isStopped()";
        retVal =        PosProductSpecificationManager_i::isStopped (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isStartingUp */
virtual ::CORBA::Boolean  isStartingUp (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::isStartingUp()";
        retVal =        PosProductSpecificationManager_i::isStartingUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isOperating */
virtual ::CORBA::Boolean  isOperating (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::isOperating()";
        retVal =        PosProductSpecificationManager_i::isOperating (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isShuttingDown */
virtual ::CORBA::Boolean  isShuttingDown (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::isShuttingDown()";
        retVal =        PosProductSpecificationManager_i::isShuttingDown (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isNotRegistered */
virtual ::CORBA::Boolean  isNotRegistered (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::isNotRegistered()";
        retVal =        PosProductSpecificationManager_i::isNotRegistered (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::isRegistered */
virtual ::CORBA::Boolean  isRegistered (CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::isRegistered()";
        retVal =        PosProductSpecificationManager_i::isRegistered (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* ComponentManager::makeStopped */
virtual ::CORBA::Void  makeStopped (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::makeStopped()";
        PosProductSpecificationManager_i::makeStopped (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* ComponentManager::ComponentManager_init */
virtual ::CORBA::Void  ComponentManager_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::ComponentManager_init()";
        PosProductSpecificationManager_i::ComponentManager_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::resourceLevel */
virtual char*  resourceLevel (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::resourceLevel()";
        retVal =        PosProductSpecificationManager_i::resourceLevel (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Resource::nameQualifiedTo */
virtual char*  nameQualifiedTo (const char* resourceLevel, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::nameQualifiedTo()";
        retVal =        PosProductSpecificationManager_i::nameQualifiedTo ( resourceLevel, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* Resource::startUp */
virtual ::CORBA::Void  startUp (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::startUp()";
        PosProductSpecificationManager_i::startUp (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::shutdownNormal */
virtual ::CORBA::Void  shutdownNormal (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::shutdownNormal()";
        PosProductSpecificationManager_i::shutdownNormal (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::shutdownImmediate */
virtual ::CORBA::Void  shutdownImmediate (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::shutdownImmediate()";
        PosProductSpecificationManager_i::shutdownImmediate (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* Resource::Resource_init */
virtual ::CORBA::Void  Resource_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::Resource_init()";
        PosProductSpecificationManager_i::Resource_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* OwnedEntity::setOwner */
virtual ::CORBA::Void  setOwner (::Person_ptr owner, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::setOwner()";
        PosProductSpecificationManager_i::setOwner ( owner, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* OwnedEntity::getOwner */
virtual ::Person_ptr  getOwner (CORBAENV_ONLY_HPP) {
    ::Person_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::getOwner()";
        retVal =        PosProductSpecificationManager_i::getOwner (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* OwnedEntity::OwnedEntity_init */
virtual ::CORBA::Void  OwnedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::OwnedEntity_init()";
        PosProductSpecificationManager_i::OwnedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::isNamed()";
        retVal =        PosProductSpecificationManager_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::setName()";
        PosProductSpecificationManager_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::getName()";
        retVal =        PosProductSpecificationManager_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::NamedEntity_init()";
        PosProductSpecificationManager_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::setTheTIEObject()";
        PosProductSpecificationManager_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::CIMFWBO_init()";
        PosProductSpecificationManager_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::CIMFW_clear()";
        PosProductSpecificationManager_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::setObjectManager()";
        PosProductSpecificationManager_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::getObjectManager()";
        retVal =        PosProductSpecificationManager_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::touchMe()";
        PosProductSpecificationManager_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::checkForDeletion()";
        retVal =        PosProductSpecificationManager_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::getUserDataSetNamed()";
        retVal =        PosProductSpecificationManager_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::getUserDataSetSequenceNamed()";
        retVal =        PosProductSpecificationManager_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allUserDataSets()";
        retVal =        PosProductSpecificationManager_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeUserDataSetNamed()";
        PosProductSpecificationManager_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeUserDataSetSequenceNamed()";
        PosProductSpecificationManager_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeAllUserDataSets()";
        PosProductSpecificationManager_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::setUserDataSetNamed()";
        PosProductSpecificationManager_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::setUserDataSetSequenceNamed()";
        PosProductSpecificationManager_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::getUserDataNamed()";
        retVal =        PosProductSpecificationManager_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::getUserDataSequenceNamed()";
        retVal =        PosProductSpecificationManager_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::allUserDataSetsFor()";
        retVal =        PosProductSpecificationManager_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeUserDataSetsFor()";
        PosProductSpecificationManager_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::getUserDataSetNamedAndOrig()";
        retVal =        PosProductSpecificationManager_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::setUserDataSetNamedAndOrig()";
        PosProductSpecificationManager_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::removeUserDataSetNamedAndOrg()";
        PosProductSpecificationManager_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::TxLockMainObject()";
        retVal =        PosProductSpecificationManager_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::TxLockElements()";
        retVal =        PosProductSpecificationManager_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductSpecificationManager_i::TxnUnlock()";
        retVal =        PosProductSpecificationManager_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosTechnologyPosTechnology_i
// -----------------------------------------------------------------------------
class PosTechnologyPosTechnology_i_m : public PosTechnology_i {

  public:
/* PosTechnology::PosTechnology_init */
virtual ::CORBA::Void  PosTechnology_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::PosTechnology_init()";
        PosTechnology_i::PosTechnology_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTechnology::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setIdentifier()";
        PosTechnology_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTechnology::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getIdentifier()";
        retVal =        PosTechnology_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTechnology::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setDescription()";
        PosTechnology_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTechnology::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getDescription()";
        retVal =        PosTechnology_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTechnology::setOwnerUser */
virtual ::CORBA::Void  setOwnerUser (::PosPerson_ptr aPerson, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setOwnerUser()";
        PosTechnology_i::setOwnerUser ( aPerson, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTechnology::getOwnerUser */
virtual ::PosPerson_ptr  getOwnerUser (CORBAENV_ONLY_HPP) {
    ::PosPerson_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getOwnerUser()";
        retVal =        PosTechnology_i::getOwnerUser (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTechnology::setTechnologyInfo */
virtual ::CORBA::Void  setTechnologyInfo (const ::brTechnologyInfo& technologyInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setTechnologyInfo()";
        PosTechnology_i::setTechnologyInfo ( technologyInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTechnology::getPropertySet */
virtual ::PosPropertySet_ptr  getPropertySet (CORBAENV_ONLY_HPP) {
    ::PosPropertySet_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getPropertySet()";
        retVal =        PosTechnology_i::getPropertySet (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTechnology::createPropertySet */
virtual ::PosPropertySet_ptr  createPropertySet (CORBAENV_ONLY_HPP) {
    ::PosPropertySet_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::createPropertySet()";
        retVal =        PosTechnology_i::createPropertySet (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::isNamed()";
        retVal =        PosTechnology_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setName()";
        PosTechnology_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getName()";
        retVal =        PosTechnology_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::NamedEntity_init()";
        PosTechnology_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setTheTIEObject()";
        PosTechnology_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::CIMFWBO_init()";
        PosTechnology_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::CIMFW_clear()";
        PosTechnology_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setObjectManager()";
        PosTechnology_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getObjectManager()";
        retVal =        PosTechnology_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::touchMe()";
        PosTechnology_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::checkForDeletion()";
        retVal =        PosTechnology_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getUserDataSetNamed()";
        retVal =        PosTechnology_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getUserDataSetSequenceNamed()";
        retVal =        PosTechnology_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::allUserDataSets()";
        retVal =        PosTechnology_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::removeUserDataSetNamed()";
        PosTechnology_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::removeUserDataSetSequenceNamed()";
        PosTechnology_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::removeAllUserDataSets()";
        PosTechnology_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setUserDataSetNamed()";
        PosTechnology_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setUserDataSetSequenceNamed()";
        PosTechnology_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getUserDataNamed()";
        retVal =        PosTechnology_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getUserDataSequenceNamed()";
        retVal =        PosTechnology_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::allUserDataSetsFor()";
        retVal =        PosTechnology_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::removeUserDataSetsFor()";
        PosTechnology_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::getUserDataSetNamedAndOrig()";
        retVal =        PosTechnology_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::setUserDataSetNamedAndOrig()";
        PosTechnology_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::removeUserDataSetNamedAndOrg()";
        PosTechnology_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::TxLockMainObject()";
        retVal =        PosTechnology_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::TxLockElements()";
        retVal =        PosTechnology_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTechnology_i::TxnUnlock()";
        retVal =        PosTechnology_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosProductCategoryPosProductCategory_i
// -----------------------------------------------------------------------------
class PosProductCategoryPosProductCategory_i_m : public PosProductCategory_i {

  public:
/* PosProductCategory::PosProductCategory_init */
virtual ::CORBA::Void  PosProductCategory_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::PosProductCategory_init()";
        PosProductCategory_i::PosProductCategory_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductCategory::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setIdentifier()";
        PosProductCategory_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductCategory::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getIdentifier()";
        retVal =        PosProductCategory_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductCategory::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setDescription()";
        PosProductCategory_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductCategory::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getDescription()";
        retVal =        PosProductCategory_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductCategory::setAvailableMainProcessDefinitionTypes */
virtual ::CORBA::Void  setAvailableMainProcessDefinitionTypes (const ::stringSequence& availableMainPDTypes, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setAvailableMainProcessDefinitionTypes()";
        PosProductCategory_i::setAvailableMainProcessDefinitionTypes ( availableMainPDTypes, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductCategory::getAvailableMainProcessDefinitionTypes */
virtual ::stringSequence*  getAvailableMainProcessDefinitionTypes (CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getAvailableMainProcessDefinitionTypes()";
        retVal =        PosProductCategory_i::getAvailableMainProcessDefinitionTypes (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductCategory::setAvailableLotTypes */
virtual ::CORBA::Void  setAvailableLotTypes (const ::objectIdentifierSequence& availableLotTypes, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setAvailableLotTypes()";
        PosProductCategory_i::setAvailableLotTypes ( availableLotTypes, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosProductCategory::getAvailableLotTypes */
virtual ::objectIdentifierSequence*  getAvailableLotTypes (CORBAENV_ONLY_HPP) {
    ::objectIdentifierSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getAvailableLotTypes()";
        retVal =        PosProductCategory_i::getAvailableLotTypes (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosProductCategory::setProductCategoryInfo */
virtual ::CORBA::Void  setProductCategoryInfo (const ::brProductCategoryInfo& productCategoryInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setProductCategoryInfo()";
        PosProductCategory_i::setProductCategoryInfo ( productCategoryInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::isNamed()";
        retVal =        PosProductCategory_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setName()";
        PosProductCategory_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getName()";
        retVal =        PosProductCategory_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::NamedEntity_init()";
        PosProductCategory_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setTheTIEObject()";
        PosProductCategory_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::CIMFWBO_init()";
        PosProductCategory_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::CIMFW_clear()";
        PosProductCategory_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setObjectManager()";
        PosProductCategory_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getObjectManager()";
        retVal =        PosProductCategory_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::touchMe()";
        PosProductCategory_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::checkForDeletion()";
        retVal =        PosProductCategory_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getUserDataSetNamed()";
        retVal =        PosProductCategory_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getUserDataSetSequenceNamed()";
        retVal =        PosProductCategory_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::allUserDataSets()";
        retVal =        PosProductCategory_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::removeUserDataSetNamed()";
        PosProductCategory_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::removeUserDataSetSequenceNamed()";
        PosProductCategory_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::removeAllUserDataSets()";
        PosProductCategory_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setUserDataSetNamed()";
        PosProductCategory_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setUserDataSetSequenceNamed()";
        PosProductCategory_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getUserDataNamed()";
        retVal =        PosProductCategory_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getUserDataSequenceNamed()";
        retVal =        PosProductCategory_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::allUserDataSetsFor()";
        retVal =        PosProductCategory_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::removeUserDataSetsFor()";
        PosProductCategory_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::getUserDataSetNamedAndOrig()";
        retVal =        PosProductCategory_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::setUserDataSetNamedAndOrig()";
        PosProductCategory_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::removeUserDataSetNamedAndOrg()";
        PosProductCategory_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::TxLockMainObject()";
        retVal =        PosProductCategory_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::TxLockElements()";
        retVal =        PosProductCategory_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosProductCategory_i::TxnUnlock()";
        retVal =        PosProductCategory_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosSampleSpecificationPosSampleSpecification_i
// -----------------------------------------------------------------------------
class PosSampleSpecificationPosSampleSpecification_i_m : public PosSampleSpecification_i {

  public:
/* PosSampleSpecification::PosSampleSpecification_init */
virtual ::CORBA::Void  PosSampleSpecification_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::PosSampleSpecification_init()";
        PosSampleSpecification_i::PosSampleSpecification_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosSampleSpecification::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getIdentifier()";
        retVal =        PosSampleSpecification_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosSampleSpecification::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setIdentifier()";
        PosSampleSpecification_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosSampleSpecification::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getDescription()";
        retVal =        PosSampleSpecification_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosSampleSpecification::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setDescription()";
        PosSampleSpecification_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosSampleSpecification::getAQLValue */
virtual ::CORBA::Double  getAQLValue (CORBAENV_ONLY_HPP) {
    ::CORBA::Double  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getAQLValue()";
        retVal =        PosSampleSpecification_i::getAQLValue (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosSampleSpecification::setAQLValue */
virtual ::CORBA::Void  setAQLValue (::CORBA::Double anAQLValue, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setAQLValue()";
        PosSampleSpecification_i::setAQLValue ( anAQLValue, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosSampleSpecification::getSampleLevel */
virtual ::CORBA::Long  getSampleLevel (CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getSampleLevel()";
        retVal =        PosSampleSpecification_i::getSampleLevel (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosSampleSpecification::setSampleLevel */
virtual ::CORBA::Void  setSampleLevel (::CORBA::Long aSampleLevel, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setSampleLevel()";
        PosSampleSpecification_i::setSampleLevel ( aSampleLevel, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosSampleSpecification::setSampleSpecificationInfo */
virtual ::CORBA::Void  setSampleSpecificationInfo (const ::brSampleSpecificationInfo& sampleSpecificationInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setSampleSpecificationInfo()";
        PosSampleSpecification_i::setSampleSpecificationInfo ( sampleSpecificationInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosSampleSpecification::PosSampleSpecification_uninit */
virtual ::CORBA::Void  PosSampleSpecification_uninit (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::PosSampleSpecification_uninit()";
        PosSampleSpecification_i::PosSampleSpecification_uninit (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::TxnUnlock()";
        retVal =        PosSampleSpecification_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::isNamed()";
        retVal =        PosSampleSpecification_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setName()";
        PosSampleSpecification_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getName()";
        retVal =        PosSampleSpecification_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::NamedEntity_init()";
        PosSampleSpecification_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setTheTIEObject()";
        PosSampleSpecification_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::CIMFWBO_init()";
        PosSampleSpecification_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::CIMFW_clear()";
        PosSampleSpecification_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setObjectManager()";
        PosSampleSpecification_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getObjectManager()";
        retVal =        PosSampleSpecification_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::touchMe()";
        PosSampleSpecification_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::checkForDeletion()";
        retVal =        PosSampleSpecification_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getUserDataSetNamed()";
        retVal =        PosSampleSpecification_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getUserDataSetSequenceNamed()";
        retVal =        PosSampleSpecification_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::allUserDataSets()";
        retVal =        PosSampleSpecification_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::removeUserDataSetNamed()";
        PosSampleSpecification_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::removeUserDataSetSequenceNamed()";
        PosSampleSpecification_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::removeAllUserDataSets()";
        PosSampleSpecification_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setUserDataSetNamed()";
        PosSampleSpecification_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setUserDataSetSequenceNamed()";
        PosSampleSpecification_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getUserDataNamed()";
        retVal =        PosSampleSpecification_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getUserDataSequenceNamed()";
        retVal =        PosSampleSpecification_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::allUserDataSetsFor()";
        retVal =        PosSampleSpecification_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::removeUserDataSetsFor()";
        PosSampleSpecification_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::getUserDataSetNamedAndOrig()";
        retVal =        PosSampleSpecification_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::setUserDataSetNamedAndOrig()";
        PosSampleSpecification_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::removeUserDataSetNamedAndOrg()";
        PosSampleSpecification_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::TxLockMainObject()";
        retVal =        PosSampleSpecification_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosSampleSpecification_i::TxLockElements()";
        retVal =        PosSampleSpecification_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosTestSpecificationPosTestSpecification_i
// -----------------------------------------------------------------------------
class PosTestSpecificationPosTestSpecification_i_m : public PosTestSpecification_i {

  public:
/* PosTestSpecification::PosTestSpecification_init */
virtual ::CORBA::Void  PosTestSpecification_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::PosTestSpecification_init()";
        PosTestSpecification_i::PosTestSpecification_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setDescription()";
        PosTestSpecification_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getDescription()";
        retVal =        PosTestSpecification_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestSpecification::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setIdentifier()";
        PosTestSpecification_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getIdentifier()";
        retVal =        PosTestSpecification_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestSpecification::setLotYieldSpecification */
virtual ::CORBA::Void  setLotYieldSpecification (::CORBA::Double lotYieldSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setLotYieldSpecification()";
        PosTestSpecification_i::setLotYieldSpecification ( lotYieldSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::getLotYieldSpecification */
virtual ::CORBA::Double  getLotYieldSpecification (CORBAENV_ONLY_HPP) {
    ::CORBA::Double  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getLotYieldSpecification()";
        retVal =        PosTestSpecification_i::getLotYieldSpecification (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestSpecification::setWaferYieldSpecification */
virtual ::CORBA::Void  setWaferYieldSpecification (::CORBA::Double waferYieldSpecification, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setWaferYieldSpecification()";
        PosTestSpecification_i::setWaferYieldSpecification ( waferYieldSpecification, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::getWaferYieldSpecification */
virtual ::CORBA::Double  getWaferYieldSpecification (CORBAENV_ONLY_HPP) {
    ::CORBA::Double  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getWaferYieldSpecification()";
        retVal =        PosTestSpecification_i::getWaferYieldSpecification (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestSpecification::setTestSpecificationInfo */
virtual ::CORBA::Void  setTestSpecificationInfo (const ::brTestSpecificationInfo& testSpecificationInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setTestSpecificationInfo()";
        PosTestSpecification_i::setTestSpecificationInfo ( testSpecificationInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::setTargetTestType */
virtual ::CORBA::Void  setTargetTestType (::PosTestType_ptr targetTestType, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setTargetTestType()";
        PosTestSpecification_i::setTargetTestType ( targetTestType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::getTargetTestType */
virtual ::PosTestType_ptr  getTargetTestType (CORBAENV_ONLY_HPP) {
    ::PosTestType_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getTargetTestType()";
        retVal =        PosTestSpecification_i::getTargetTestType (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestSpecification::setLowYieldWaferCount */
virtual ::CORBA::Void  setLowYieldWaferCount (::CORBA::Long lowYieldWaferCountSpec, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setLowYieldWaferCount()";
        PosTestSpecification_i::setLowYieldWaferCount ( lowYieldWaferCountSpec, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::getLowYieldWaferCount */
virtual ::CORBA::Long  getLowYieldWaferCount (CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getLowYieldWaferCount()";
        retVal =        PosTestSpecification_i::getLowYieldWaferCount (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestSpecification::setCombinationCriteria */
virtual ::CORBA::Void  setCombinationCriteria (const char* combinationCriteriaCode, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setCombinationCriteria()";
        PosTestSpecification_i::setCombinationCriteria ( combinationCriteriaCode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestSpecification::getCombinationCriteria */
virtual char*  getCombinationCriteria (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getCombinationCriteria()";
        retVal =        PosTestSpecification_i::getCombinationCriteria (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::isNamed()";
        retVal =        PosTestSpecification_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setName()";
        PosTestSpecification_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getName()";
        retVal =        PosTestSpecification_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::NamedEntity_init()";
        PosTestSpecification_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setTheTIEObject()";
        PosTestSpecification_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::CIMFWBO_init()";
        PosTestSpecification_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::CIMFW_clear()";
        PosTestSpecification_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setObjectManager()";
        PosTestSpecification_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getObjectManager()";
        retVal =        PosTestSpecification_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::touchMe()";
        PosTestSpecification_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::checkForDeletion()";
        retVal =        PosTestSpecification_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getUserDataSetNamed()";
        retVal =        PosTestSpecification_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getUserDataSetSequenceNamed()";
        retVal =        PosTestSpecification_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::allUserDataSets()";
        retVal =        PosTestSpecification_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::removeUserDataSetNamed()";
        PosTestSpecification_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::removeUserDataSetSequenceNamed()";
        PosTestSpecification_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::removeAllUserDataSets()";
        PosTestSpecification_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setUserDataSetNamed()";
        PosTestSpecification_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setUserDataSetSequenceNamed()";
        PosTestSpecification_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getUserDataNamed()";
        retVal =        PosTestSpecification_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getUserDataSequenceNamed()";
        retVal =        PosTestSpecification_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::allUserDataSetsFor()";
        retVal =        PosTestSpecification_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::removeUserDataSetsFor()";
        PosTestSpecification_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::getUserDataSetNamedAndOrig()";
        retVal =        PosTestSpecification_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::setUserDataSetNamedAndOrig()";
        PosTestSpecification_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::removeUserDataSetNamedAndOrg()";
        PosTestSpecification_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::TxLockMainObject()";
        retVal =        PosTestSpecification_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::TxLockElements()";
        retVal =        PosTestSpecification_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestSpecification_i::TxnUnlock()";
        retVal =        PosTestSpecification_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

// -----------------------------------------------------------------------------
// PosTestTypePosTestType_i
// -----------------------------------------------------------------------------
class PosTestTypePosTestType_i_m : public PosTestType_i {

  public:
/* PosTestType::PosTestType_init */
virtual ::CORBA::Void  PosTestType_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::PosTestType_init()";
        PosTestType_i::PosTestType_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestType::PosTestType_uninit */
virtual ::CORBA::Void  PosTestType_uninit (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::PosTestType_uninit()";
        PosTestType_i::PosTestType_uninit (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestType::getDescription */
virtual char*  getDescription (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getDescription()";
        retVal =        PosTestType_i::getDescription (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestType::getIdentifier */
virtual char*  getIdentifier (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getIdentifier()";
        retVal =        PosTestType_i::getIdentifier (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestType::getProductType */
virtual char*  getProductType (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getProductType()";
        retVal =        PosTestType_i::getProductType (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* PosTestType::setTestTypeInfo */
virtual ::CORBA::Void  setTestTypeInfo (const ::brTestTypeInfo& testTypeInfo, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setTestTypeInfo()";
        PosTestType_i::setTestTypeInfo ( testTypeInfo, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestType::setDescription */
virtual ::CORBA::Void  setDescription (const char* description, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setDescription()";
        PosTestType_i::setDescription ( description, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestType::setIdentifier */
virtual ::CORBA::Void  setIdentifier (const char* identifier, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setIdentifier()";
        PosTestType_i::setIdentifier ( identifier, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* PosTestType::setProductType */
virtual ::CORBA::Void  setProductType (const char* productType, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setProductType()";
        PosTestType_i::setProductType ( productType, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::isNamed */
virtual ::CORBA::Boolean  isNamed (const char* testName, CORBAENV_ONLY_HPP) {
    ::CORBA::Boolean  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::isNamed()";
        retVal =        PosTestType_i::isNamed ( testName, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::setName */
virtual ::CORBA::Void  setName (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setName()";
        PosTestType_i::setName ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* NamedEntity::getName */
virtual char*  getName (CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getName()";
        retVal =        PosTestType_i::getName (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* NamedEntity::NamedEntity_init */
virtual ::CORBA::Void  NamedEntity_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::NamedEntity_init()";
        PosTestType_i::NamedEntity_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setTheTIEObject */
virtual ::CORBA::Void  setTheTIEObject (::CIMFWBO_ptr aCIMFWBO, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setTheTIEObject()";
        PosTestType_i::setTheTIEObject ( aCIMFWBO, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFWBO_init */
virtual ::CORBA::Void  CIMFWBO_init (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::CIMFWBO_init()";
        PosTestType_i::CIMFWBO_init (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::CIMFW_clear */
virtual ::CORBA::Void  CIMFW_clear (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::CIMFW_clear()";
        PosTestType_i::CIMFW_clear (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setObjectManager */
virtual ::CORBA::Void  setObjectManager (::CIMFWBO_ptr objectManager, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setObjectManager()";
        PosTestType_i::setObjectManager ( objectManager, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getObjectManager */
virtual ::CIMFWBO_ptr  getObjectManager (CORBAENV_ONLY_HPP) {
    ::CIMFWBO_ptr  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getObjectManager()";
        retVal =        PosTestType_i::getObjectManager (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::touchMe */
virtual ::CORBA::Void  touchMe (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::touchMe()";
        PosTestType_i::touchMe (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::checkForDeletion */
virtual ::checkMessageSequence*  checkForDeletion (::CORBA::Long messageCount, CORBAENV_ONLY_HPP) {
    ::checkMessageSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::checkForDeletion()";
        retVal =        PosTestType_i::checkForDeletion ( messageCount, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetNamed */
virtual ::userDataSet*  getUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSet*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getUserDataSetNamed()";
        retVal =        PosTestType_i::getUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSetSequenceNamed */
virtual ::userDataSetSequence*  getUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getUserDataSetSequenceNamed()";
        retVal =        PosTestType_i::getUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSets */
virtual ::userDataSetSequence*  allUserDataSets (CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::allUserDataSets()";
        retVal =        PosTestType_i::allUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetNamed */
virtual ::CORBA::Void  removeUserDataSetNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::removeUserDataSetNamed()";
        PosTestType_i::removeUserDataSetNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetSequenceNamed */
virtual ::CORBA::Void  removeUserDataSetSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::removeUserDataSetSequenceNamed()";
        PosTestType_i::removeUserDataSetSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeAllUserDataSets */
virtual ::CORBA::Void  removeAllUserDataSets (CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::removeAllUserDataSets()";
        PosTestType_i::removeAllUserDataSets (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetNamed */
virtual ::CORBA::Void  setUserDataSetNamed (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setUserDataSetNamed()";
        PosTestType_i::setUserDataSetNamed ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::setUserDataSetSequenceNamed */
virtual ::CORBA::Void  setUserDataSetSequenceNamed (const ::userDataSetSequence& datasets, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setUserDataSetSequenceNamed()";
        PosTestType_i::setUserDataSetSequenceNamed ( datasets, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataNamed */
virtual char*  getUserDataNamed (const char* name, CORBAENV_ONLY_HPP) {
    char*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getUserDataNamed()";
        retVal =        PosTestType_i::getUserDataNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::getUserDataSequenceNamed */
virtual ::stringSequence*  getUserDataSequenceNamed (const char* name, CORBAENV_ONLY_HPP) {
    ::stringSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getUserDataSequenceNamed()";
        retVal =        PosTestType_i::getUserDataSequenceNamed ( name, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::allUserDataSetsFor */
virtual ::userDataSetSequence*  allUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::allUserDataSetsFor()";
        retVal =        PosTestType_i::allUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::removeUserDataSetsFor */
virtual ::CORBA::Void  removeUserDataSetsFor (const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::removeUserDataSetsFor()";
        PosTestType_i::removeUserDataSetsFor ( orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::getUserDataSetNamedAndOrig */
virtual ::userDataSetSequence*  getUserDataSetNamedAndOrig (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    ::userDataSetSequence*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::getUserDataSetNamedAndOrig()";
        retVal =        PosTestType_i::getUserDataSetNamedAndOrig ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::setUserDataSetNamedAndOrig */
virtual ::CORBA::Void  setUserDataSetNamedAndOrig (const ::userDataSet& dataset, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::setUserDataSetNamedAndOrig()";
        PosTestType_i::setUserDataSetNamedAndOrig ( dataset, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::removeUserDataSetNamedAndOrg */
virtual ::CORBA::Void  removeUserDataSetNamedAndOrg (const char* name, const char* orig, CORBAENV_ONLY_HPP) {
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::removeUserDataSetNamedAndOrg()";
        PosTestType_i::removeUserDataSetNamedAndOrg ( name, orig, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
}

/* CIMFWBO::TxLockMainObject */
virtual ::CORBA::Long  TxLockMainObject (::CORBA::Long lockMode, CORBAENV_ONLY_HPP) {
    ::CORBA::Long  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::TxLockMainObject()";
        retVal =        PosTestType_i::TxLockMainObject ( lockMode, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* CIMFWBO::TxLockElements */
virtual ::resultInfo*  TxLockElements (::CORBA::Long lockMode, const char* collectionName, const ::stringSequence& keySeq, CORBAENV_ONLY_HPP) {
    ::resultInfo*  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::TxLockElements()";
        retVal =        PosTestType_i::TxLockElements ( lockMode, collectionName, keySeq, IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

/* MOFW_ManagedObjectBase::TxnUnlock */
virtual ::MOFW_TransactionalObject::lock_status  TxnUnlock (CORBAENV_ONLY_HPP) {
    ::MOFW_TransactionalObject::lock_status  retVal;
    CORBA::String ident = "";
    try {
        ident = " - before()";
        MOFW_ManagedObjectBase_i::before();
        ident = " - PosTestType_i::TxnUnlock()";
        retVal =        PosTestType_i::TxnUnlock (IT_env);
    } catch( CORBA::UserException &ue ) {
        APPERRLOG;
        apperrlog <<  __LINE__ << " Caught UserException " << ident << endl;
        if( memcmp(ident, " - before()", 11) == 0 )
            throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
        else
            throw;
    } catch( const CORBA::SystemException &se ) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw;
    } catch(...) {
        APPERRLOG;
        apperrlog << __LINE__ << " Caught SystemException " << ident << endl;
        throw CORBA::UNKNOWN(WRONG_EXCEPTION, CORBA::COMPLETED_NO);
    }
    return retVal;
}

};

