//----------------------------------------------------------------------------
//
//  Generated from boshlprDummy
//  On Thursday, November 2, 2006 4:43:08 PM JST
//  by IBM CORBA 2.3 (mh) C++ emitter 2.30
//
//----------------------------------------------------------------------------
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/09 DSIV00001432 S.Kawabe       Support XLC version 9

/*****************************************************************************
*                                                                            *
*     FILE_ID: boshlpr.cpp                                                   *
*                                                                            *
*     (C) COPYRIGHT International Business Machines Corp. 1997, 2008.          *
*     (C) COPYRIGHT: IBM Japan Services Company Ltd, 1997, 2008.       *
*     All Rights Reserved                                                    *
*     Licensed Materials - Property of IBM                                   *
*                                                                            *
*     US Government User Restricted Rights - Use, duplication                *
*     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.   *
*                                                                            *
******************************************************************************/

#include "IMProt.h" //DSIV00001432

// Implementation header files
#include "ppptset.hpp"
#include "pptyint.hpp"
#include "pptyrea.hpp"
#include "pptysetmg.hpp"
#include "pptystr.hpp"
#include "pptytsi.hpp"
#include "pptytsr.hpp"
#include "pptytss.hpp"

//DSIV00001432 #include "IMProt.h"

// DO implementation header files
#include "DOBase_i.h"
#include "ppptsedo.hpp"
#include "ppttsido.hpp"
#include "ppttsrdo.hpp"
#include "ppttssdo.hpp"
#include "pptyindo.hpp"
#include "pptyredo.hpp"
#include "pptystdo.hpp"

#include "imthd.h"
#include "sys/timeb.h"
#include "IMObx.h"

//GlobalComposedObjectTable* global_func()
void global_func_BOSPAbCl( GlobalComposedObjectTable* GCOT )
{
  //GlobalComposedObjectTable *GCOT = NULL;
  //GCOT = new GlobalComposedObjectTable();
  if( GCOT != NULL )
  {
    // Create Prototype Objects and add to the GlobalComposedObjectTable...
    Create_PrototypeBOA(PosPropertyTableSS,
                        PosPropertyTableSS_DO_i,
                        PosPropertyTableSSPosPropertyTableSS_i_m, GCOT);

    Create_PrototypeBOA(PosPropertySetManager,
                        IMFW_DataObjectBase_i,
                        PosPropertySetManagerPosPropertySetManager_i_m, GCOT);

    Create_PrototypeBOA(PosPropertyTableSR,
                        PosPropertyTableSR_DO_i,
                        PosPropertyTableSRPosPropertyTableSR_i_m, GCOT);

    Create_PrototypeBOA(PosPropertySet,
                        PosPropertySet_DO_i,
                        PosPropertySetPosPropertySet_i_m, GCOT);

    Create_PrototypeBOA(PosPropertyReal,
                        PosPropertyReal_DO_i,
                        PosPropertyRealPosPropertyReal_i_m, GCOT);

    Create_PrototypeBOA(PosPropertyString,
                        PosPropertyString_DO_i,
                        PosPropertyStringPosPropertyString_i_m, GCOT);

    Create_PrototypeBOA(PosPropertyInteger,
                        PosPropertyInteger_DO_i,
                        PosPropertyIntegerPosPropertyInteger_i_m, GCOT);

    Create_PrototypeBOA(PosPropertyTableSI,
                        PosPropertyTableSI_DO_i,
                        PosPropertyTableSIPosPropertyTableSI_i_m, GCOT);

  }
  //return GCOT;
}

