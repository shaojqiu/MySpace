// SCCS ID: @(#) 1.1 superpos/src/css/source/brsinterpreter/brsdatabank/boshelper/boshlprvarinfomgr.hpp, mm_srv_90e_css, mm_srv_90e_css 4/20/07 11:16:47 [ 7/13/07 19:19:41 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: boshlprvarinfomgr.hpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
//

#include "IMProt.h"

void global_func_VarInfoMgr( GlobalComposedObjectTable* GCOT );
