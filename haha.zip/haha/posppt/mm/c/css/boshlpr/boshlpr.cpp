#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/css/source/brsinterpreter/boshelper/boshlpr.cpp, mm_srv_90e_css, mm_srv_90e_css 7/13/07 19:16:44 [ 7/13/07 19:16:46 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview
// Name: boshlpr.cpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 02/02/00          H.Katoh        New release
// 

#ifdef IMIZED

#include "boshlprvarinfomgr.hpp"
#include "boshlprbrsmanager.hpp"

GlobalComposedObjectTable* brsserver_global_func()
{
  GlobalComposedObjectTable *GCOT = NULL ;
  GCOT = new GlobalComposedObjectTable() ;

  if( GCOT != NULL )
  {
      global_func_VarInfoMgr(GCOT) ;
      global_func_BRSManager(GCOT) ;
  }
  return GCOT ;
}


#endif

