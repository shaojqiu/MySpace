// SCCS ID: @(#) 1.1 superpos/src/spclass/spfwbins/mmserver.hpp, mm_srv_90e_spcl, mm_srv_90e_spcl 4/20/07 14:16:06 [ 7/14/07 00:36:32 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.  
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview standard
// Name: spfwsvr.hpp
// // Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- --------------------------------------------
// 06/03/05 D6000308 K.Murakami     Initial Release
//
#ifndef MMSERVER_HPP
#define MMSERVER_HPP

#include <corba.h> 

#include <threadTid/threadTid.h>
#include "imthd.h"            
#include "time.hpp"

#include "tracelogmgr.hpp"    

#ifdef _AIX
#define SPMAIN_TRACEENTRY(MethodName)\
    BOTraceFunction aBOTraceFunction(__FUNCTION__,FALSE);
#else
#define SPMAIN_TRACEENTRY(MethodName)\
    BOTraceFunction aBOTraceFunction(MethodName ,FALSE); 
#endif

#define SPMAIN_TRACEEXIT(MethodName)\

#define SPMAIN_TRACE_VERBOSE()\
{\
    if ( putTrace( __FILE__, __LINE__, __FUNCTION__ ) ) \
    { \
        SP_COUT << SP_ENDL; \
    } \
}

#define SPMAIN_TRACE_VERBOSE1(p1)\
{\
    if ( putTrace( __FILE__, __LINE__, __FUNCTION__ ) ) \
    { \
        SP_COUT << p1 << SP_ENDL; \
    } \
}

#define SPMAIN_TRACE_VERBOSE2(p1,p2)\
{\
    if ( putTrace( __FILE__, __LINE__, __FUNCTION__ ) ) \
    { \
        SP_COUT << p1 << p2 << SP_ENDL; \
    } \
}

#define SPMAIN_TRACE_VERBOSE3(p1,p2,p3)\
{\
    if ( putTrace( __FILE__, __LINE__, __FUNCTION__ ) ) \
    { \
        SP_COUT << p1 << p2 << p3 << SP_ENDL; \
    } \
}

#define SPMAIN_TRACE_VERBOSE4(p1,p2,p3,p4)\
{\
    if ( putTrace( __FILE__, __LINE__, __FUNCTION__ ) ) \
    { \
        SP_COUT << p1 << p2 << p3 << p4 << SP_ENDL; \
    } \
}

#define SPMAIN_TRACE_VERBOSE5(p1,p2,p3,p4,p5)\
{\
    if ( putTrace( __FILE__, __LINE__, __FUNCTION__ ) ) \
    { \
        SP_COUT << p1 << p2 << p3 << p4 << p5 << SP_ENDL; \
    } \
}

#define APPERRLOG_SYSTEMEXCEPTION_FOR_MAIN(SE,ACTION)\
{\
    SP_COUT << " file:" << __FILE__ << " line:" << __LINE__ << " Caught CORBA::SystemException minor:" << SE.minor() << SP_ENDL;\
    if ( ACTION != NULL && strlen(ACTION)>0 ) SP_COUT << ACTION << SP_ENDL;\
    APPERRLOG;\
    apperrlog << "Caught CORBA::SystemException" << endl;\
    apperrlog << "minor: " << SE.minor() << endl;\
}

#define APPERRLOG_UNKNOWNEXCEPTION_FOR_MAIN(ACTION)\
{\
    SP_COUT << " file:" << __FILE__ << " line:" << __LINE__ << " Caught unknown exception" << SP_ENDL;\
    if ( ACTION != NULL && strlen(ACTION)>0 ) SP_COUT << ACTION << SP_ENDL;\
    APPERRLOG;\
    apperrlog << "Caught unknown exception" << endl;\
}

#define APPERRLOG_USEREXCEPTION_FOR_MAIN(UE,ACTION)\
{\
    SP_COUT << " file:" << __FILE__ << " line:" << __LINE__ << " Caught CORBA::UserException" << SP_ENDL;\
    if ( ACTION != NULL && strlen(ACTION)>0 ) SP_COUT << ACTION << SP_ENDL;\
    APPERRLOG;\
    apperrlog << "Caught CORBA::UserException" << endl;\
}

#define APPERRLOG_EXCEPTION_FOR_MAIN(EXNAME,ACTION)\
{\
    SP_COUT << " file:" << __FILE__ << " line:" << __LINE__ << " Caught " << ##EXNAME << SP_ENDL;\
    if ( ACTION != NULL && strlen(ACTION)>0 ) SP_COUT << ACTION << SP_ENDL;\
    APPERRLOG;\
    apperrlog << "Caught " << ##EXNAME << endl;\
}

#define APPERRLOG_ERROR_FOR_MAIN(ERRMSG,ACTION)\
{\
    SP_COUT << " file:" << __FILE__ << " line:" << __LINE__ << " " << ERRMSG << SP_ENDL;\
    if ( ACTION != NULL && strlen(ACTION)>0 ) SP_COUT << ACTION << SP_ENDL;\
    APPERRLOG;\
    apperrlog << "Caught " << ERRMSG << endl;\
}

#define APPERRLOG_WARNING_FOR_MAIN(WARNMSG,ACTION)\
{\
    SP_COUT << " file:" << __FILE__ << " line:" << __LINE__ << " " << WARNMSG << SP_ENDL;\
    if ( ACTION != NULL && strlen(ACTION)>0 ) SP_COUT << ACTION << SP_ENDL;\
    APPERRLOG;\
    apperrlog << "Caught " << WARNMSG << endl;\
}

#define SPMAIN_TRACE_FRAMEWORKERRORSIGNAL(aFES)\
{\
    char * str;\
    aFES.errorInformation >>= str ;\
    SPMAIN_TRACE_VERBOSE2("Caught exception:", str);\
}


#define CORBA_RELEASE( anObject, anObjFactory )\
if( !CORBA::is_nil( anObject ) )\
{\
    anObjFactory->deleteCIMFWObject( anObject ) ;\
}

#define CREATE_COMPONENT_FACTORY( factoryClass, factoryVar, containerName, factoryName, factoryHost, factoryServer ) \
{\
     SPMAIN_TRACE_VERBOSE2("Host name is ",SiviewMMHostName);\
     SPMAIN_TRACE_VERBOSE2("Server name is ",SiviewMMServerName);\
     SPMAIN_TRACE_VERBOSE2("ALF host name is ",factoryHost     );\
     SPMAIN_TRACE_VERBOSE2("ALF server name is ",factoryServer   );\
    if ( !CIMFWStrCmp(SiviewMMHostName, factoryHost) && strstr(factoryServer, SiviewMMServerName)!=NULL )\
    {\
        SPMAIN_TRACE_VERBOSE2("About to create ",#factoryClass);\
        /* factory on same server */\
        SPMAIN_TRACE_VERBOSE();\
        factoryVar = new  factoryClass##_i()  ; \
        SPMAIN_TRACE_VERBOSE();\
\
        if( CORBA::is_nil(factoryVar) ) \
        {\
            SPMAIN_TRACE_VERBOSE2("Error in creating ",#factoryClass);\
            CleanUpServerAndExit() ;\
        }\
        try\
        {\
            SPMAIN_TRACE_VERBOSE();\
            pIMFactory = FactoryFinder.findFactory( #containerName, #factoryName ) ;\
            SPMAIN_TRACE_VERBOSE();\
            factoryVar->setMyIMFactory( pIMFactory ) ;\
            SPMAIN_TRACE_VERBOSE();\
            factoryVar->_marker(#factoryClass);\
            char buf[512];\
            strcpy( buf, SiviewMMServerName );\
            strcat( buf, "_" );\
            strcat( buf, #factoryName );\
            SPMAIN_TRACE_VERBOSE2("register_initial_reference" , buf ); \
            ::IMRegistry::orbPtr->register_initial_reference( buf, factoryVar );\
            if( EB_SiView_registObjectWithMarker( factoryVar->_marker(), factoryVar ) ) \
            { \
                SPMAIN_TRACE_VERBOSE2("Error in marker registration ",#factoryClass); \
                CleanUpServerAndExit() ;\
            } \
        }\
        catch(const CORBA::SystemException &se)\
        {\
            SPMAIN_TRACE_VERBOSE2("Exception caught while setting the IM factory for ",#factoryClass);\
            SPMAIN_TRACE_VERBOSE1(se);\
            CleanUpServerAndExit() ;\
        }\
        catch(...)\
        {\
            SPMAIN_TRACE_VERBOSE2("Exception caught while setting the IM factory for ",#factoryClass);\
            CleanUpServerAndExit() ;\
        }\
        SPMAIN_TRACE_VERBOSE2("Created ",#factoryClass);\
    }\
}

#define CREATE_COMPONENT_MANAGER( managerVar, managerClass, newMethod, factoryVar, factoryHost, factoryServer )\
{\
     SPMAIN_TRACE_VERBOSE2("Host name is ",SiviewMMHostName);\
     SPMAIN_TRACE_VERBOSE2("Server name is ",SiviewMMServerName);\
     SPMAIN_TRACE_VERBOSE2("ALF host name is ",factoryHost     );\
     SPMAIN_TRACE_VERBOSE2("ALF server name is ",factoryServer   );\
    if ( !CIMFWStrCmp(SiviewMMHostName, factoryHost) && strstr(factoryServer, SiviewMMServerName)!=NULL )\
    {\
        SPMAIN_TRACE_VERBOSE2("About to create ",#managerClass);\
        /* manager on same server */\
        try\
        {\
            CORBA::Object_var anObj = factoryVar->newMethod() ;\
            managerVar = managerClass::_narrow(anObj) ;\
            if ( CORBA::is_nil(managerVar) )\
            {\
                SPMAIN_TRACE_VERBOSE2("Error in creating ",#managerClass);\
                CleanUpServerAndExit() ;\
            }\
            managerVar->setName(#managerClass) ;\
            SPMAIN_TRACE_VERBOSE4("manager object is created :" , (void*)managerVar, ":", managerVar->_marker() );\
            SPMAIN_TRACE_VERBOSE4("manager : " , (void*)managerVar, " refcount :", managerVar->_refCount() );\
            if( EB_SiView_registObjectWithMarker( managerVar->_marker(), managerVar ) ) \
            { \
                SPMAIN_TRACE_VERBOSE2("Error in marker registration ",#managerClass); \
                CleanUpServerAndExit() ; \
            } \
        }\
        catch(const CORBA::SystemException &se)\
        {\
            SPMAIN_TRACE_VERBOSE2("Exception caught while creating the ",#managerClass);\
            SPMAIN_TRACE_VERBOSE1(se);\
            CleanUpServerAndExit() ;\
        }\
        catch(...)\
        {\
            SPMAIN_TRACE_VERBOSE2("Exception caught while creating the ",#managerClass);\
            CleanUpServerAndExit() ;\
        }\
        SPMAIN_TRACE_VERBOSE2("Created ",#managerClass);\
    }\
}


#define BIND_COMPONENT_MANAGER( managerVar, managerClass, factoryHost, factoryServer )\
{ \
    SPMAIN_TRACE_VERBOSE2("Host name is ",#factoryHost);\
    SPMAIN_TRACE_VERBOSE2("Server name is ",#factoryServer);\
    SPMAIN_TRACE_VERBOSE2("Class name is ",#managerClass);\
    SPMAIN_TRACE_VERBOSE2("Variable name is ",#managerVar);\
    if ( CORBA::is_nil(managerVar) )\
    {\
        SPMAIN_TRACE_VERBOSE2("About to bind ",#managerClass);\
        try\
        {\
            SPMAIN_TRACE_VERBOSE();\
            managerVar = managerClass##::_bind(factoryServer, factoryHost);\
            SPMAIN_TRACE_VERBOSE();\
        }\
        catch(const CORBA::NO_PERMISSION &se)\
        {\
            SPMAIN_TRACE_VERBOSE2("Exception caught while binding the ",#managerClass);\
            SPMAIN_TRACE_VERBOSE1(se);\
            SP_COUT << "Information: Waiting for " << #factoryServer << " on " << #factoryHost << SP_ENDL;\
        }\
        catch(const CORBA::NO_IMPLEMENT &se)\
        {\
            SPMAIN_TRACE_VERBOSE2("Exception caught while binding the ",#managerClass);\
            SPMAIN_TRACE_VERBOSE1(se);\
            SP_COUT << "Information: Waiting for " << #managerClass << " in " << #factoryServer << " on " << #factoryHost << SP_ENDL;\
        }\
        catch(const CORBA::COMM_FAILURE &se)\
        {\
            if(se.minor()==TCP_NO_SERVER)\
            {\
                SPMAIN_TRACE_VERBOSE2("Exception caught while binding the ",#managerClass);\
                SPMAIN_TRACE_VERBOSE1(se);\
                SP_COUT << "Information: Waiting for " << #managerClass << " in " << #factoryServer << " on " << #factoryHost << SP_ENDL;\
            }\
            else\
            {\
                throw ; \
            }\
        }\
        catch(const CORBA::BAD_OPERATION &se) \
        {\
            if(se.minor()==NOSUCH_SERVER)\
            {\
                SPMAIN_TRACE_VERBOSE2("Exception caught while binding the ",#managerClass);\
                SPMAIN_TRACE_VERBOSE1(se);\
                SP_COUT << "Information: The server is not registered " << #managerClass << " in " << #factoryServer << " on " << #factoryHost << SP_ENDL;\
            }\
            else\
            {\
                throw ;\
            }\
        }\
        catch(const CORBA::SystemException &se)\
        {\
            SPMAIN_TRACE_VERBOSE2("Exception caught while binding the ",#managerClass);\
            SPMAIN_TRACE_VERBOSE1(se);\
            throw ; \
        }\
        catch(...)\
        {\
            SPMAIN_TRACE_VERBOSE2("Exception caught while binding the ",#managerClass);\
            throw;\
        }\
        \
        SPMAIN_TRACE_VERBOSE2("Bound ",#managerClass);\
    }\
}

#define REGISTER_COMPONENT_MANAGER( theCmpntManager )\
{\
    SPMAIN_TRACE_VERBOSE2("About to register ",#theCmpntManager);\
    if( !RegisterComponentManager( theCmpntManager ) )\
    {\
        SPMAIN_TRACE_VERBOSE2("Error in registering ",#theCmpntManager);\
    }\
    else\
    {\
        SPMAIN_TRACE_VERBOSE2("Registered ",#theCmpntManager);\
    }\
}

#define CREATE_A_SPFW_SPECIAL_OBJECT( className )\
{\
    SPMAIN_TRACE_VERBOSE2("About to create ",#className);\
    the##className = className##::_nil() ;\
    \
    the##className = new className##_i() ;\
    the##className->_marker(#className); \
    if( EB_SiView_registObjectWithMarker( the##className->_marker(), the##className ) ) \
    { \
        SPMAIN_TRACE_VERBOSE2("Error in marker registration ",#className); \
        CleanUpServerAndExit() ;\
    } \
    if( CORBA::is_nil(the##className) )\
    {\
        SPMAIN_TRACE_VERBOSE2("Error in creating ",#className);\
    }\
    else\
    {\
        SPMAIN_TRACE_VERBOSE2("Created ",#className);\
    }\
}

#endif

