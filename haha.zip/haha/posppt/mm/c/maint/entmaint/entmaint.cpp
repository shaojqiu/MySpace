#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/maint/entmaint.cpp, mm_srv_90e_mnt, mm_srv_90e_mnt 2/15/08 16:11:14 [ 2/15/08 16:11:15 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView Material Manager
//  entmaint.cpp
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/02/23 D2200026 Y.Yamaguchi    Initial Release
// 2001/07/02 P4000034 R.Furuta       Change set value "searchCondition.entities[0].className"
// 2003/08/19 D5000144 F.Masada       Change how to bind to MM server (HAS)
// 2004/05/28 P5100338 K.Kido         Add entities.
//                                    "ModulePD"
//                                    "Stage"
//                                    "Route Operation + Product + Equipment"
//                                    "Equipment + Chamber"
//                                    "Equipment + Chamber + Product"
//                                    "Equipment + Chamber + Machine Recipe"
// 2004/11/29 D6000025 K.Murakami     Add include <corba.h> for eBroker.
//                                    Add New genIOR for eBroker.
// 2005/06/07 D6000348 K.Kido         Add reason code "EXPD"
// 2008/02/15 D9000160 M.Ishino       Add the logic which the system user's password and user ID hard coded is changed to an environment variable.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/02 DSIV00001365 R.Okano        Entity Inhibit Improvement (R10.1)
// 2009-11-13 PSIV00001581 R.Iriguchi     Fix memory leak
//                                        - Change "main()"
// 2015/10/27 DSN000100700 K.Yamaoku      Security enhancement.
// 2016/10/25 PSN000103236 Y.Zhuang       Change the Entity Inhibit Maintenance filter condition Enhance to avoid MM server crashes and high system load
//
// Description:
//      This program inquires expired entity inhibit entries and removes them.
//
// Input File  :
//      none
//
// Output File : This file shows the deleted lots information. It is created by each execution.
//
//      Directory : User can define it on a environment valuable "OUTFILE_DIR".
//                  If not specified, the default directory is current directory.
//
//      File Name : EntityInhibit_YYMMDDHHMM.log
//
//      Contents  : CurrentTimeStamp,LotID,WaferCount,LotStatus,CompletionTimeStamp
//                  LotFamilyID,ProductRequestID,ProductSpecificationID,LotType,SubLotType,LotOwnerID,RouteID
//
// Transaction:  TxEntityInhibitListInq__101()
//               TxEntityInhibitCancelReq__101()
//
// Pseudo Code:
//
//
#include <iostream.h>
#include <fstream.h>

#ifdef _WIN32
#include <strstrea.h>
#else
#include <strstream.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef EBROKER       //D6000025
#include <corba.h>   //D6000025
#else                //D6000025
#include <CORBA.h>
#endif               //D6000025
#include <time.h>
#include <sys/timeb.h>
#include "posconst.hpp"
#include "cimfwstr.hpp"
#include "timstamp.hpp"
#include "pptsvcmf.hh"
#include "pptsm.hh"
#include "IIOPHelper.hpp"  //D5000144
#include "spencrypt.hpp"   //D9000160

#include "sp_coninfo.hpp"           //DSN000100700
#include "sp_coninfo_target.hpp"    //DSN000100700

#define OUTFILE_DIR "OUTFILE_DIR"

PPTServiceManager_var aPPTServiceManager;

//DSIV00001365 void delete_expiredEntityInhibit(pptUser& strUser, pptEntityInhibitAttributes& searchCondition, ofstream& fo);
//DSIV00001365 void print_EntityInhibit(ostream& out, pptEntityInhibitInfo& entityInhibitInfo);
void delete_expiredEntityInhibit(pptUser& strUser, pptEntityInhibitDetailAttributes& searchCondition, ofstream& fo);    //DSIV00001365
void print_EntityInhibit(ostream& out, pptEntityInhibitDetailInfo& entityInhibitInfo);                                  //DSIV00001365

//PSIV00001581 void main (int argc, char** argv)
int main()      //PSIV00001581
{
//D5000144    //--------------------------------------------------------------------------------
//D5000144    //  Get MMServerName and MMHostName
//D5000144    //--------------------------------------------------------------------------------
//D5000144    char* aMMServerName    = NULL;
//D5000144    char* aMMHostName      = NULL;
//D5000144    if ( argc < 3 )
//D5000144    {
//D5000144        cout << endl;
//D5000144        cout << "Usage: " << argv[0] << " host server" << endl;
//D5000144        cout << endl;
//D5000144        return;
//D5000144    }
//D5000144    else
//D5000144    {
//D5000144        aMMHostName   = argv[1];
//D5000144
//D5000144        if ( argv[2][0] == ':' )
//D5000144        {
//D5000144           aMMServerName = new char[strlen(argv[2])+1];
//D5000144           strcpy(aMMServerName,argv[2]);
//D5000144        }
//D5000144        else
//D5000144        {
//D5000144           aMMServerName = new char[strlen(argv[2])+2];
//D5000144           strcpy(aMMServerName,":");
//D5000144           strcat(aMMServerName,argv[2]);
//D5000144        }
//D5000144    }
//D5000144
//D5000144    cout << "About to check PPTServiceManager of " << aMMServerName << " on " << aMMHostName << endl ;

//D5000144 start
    //---------------------------------------------------------------------
    // Get Host Name / Port ID / Server Name / Marker Name / Interface Name
    //---------------------------------------------------------------------
    char* hostName      = NULL;
    char* portID        = NULL;
    char* serverName    = NULL;
    char* markerName    = NULL;
    char* interfaceName = NULL;
    char* work          = NULL ;    //D9000160

    hostName = getenv("MM_HOST_NAME");
    if( hostName == NULL )
    {
        cerr << "Host Name is not specified" << endl ;
//PSIV00001581        return;
        return 1;       //PSIV00001581
    }
    portID     = getenv("MM_PORT_ID");
    if( portID == NULL )
    {
        cerr << "Port ID is not specified" << endl ;
//PSIV00001581        return;
        return 1;       //PSIV00001581
    }
    serverName = getenv("MM_SERVER_NAME");
    if( serverName == NULL )
    {
        cerr << "Server Name is not specified" << endl ;
//PSIV00001581        return;
        return 1;       //PSIV00001581
    }
    markerName = getenv("MM_MARKER_NAME");
    if( markerName == NULL )
    {
        cerr << "Marker Name is not specified" << endl ;
//PSIV00001581        return;
        return 1;       //PSIV00001581
    }
    interfaceName = getenv("MM_INTERFACE_NAME");
    if( interfaceName == NULL )
    {
        cerr << "Interface Name is not specified" << endl ;
//PSIV00001581        return;
        return 1;       //PSIV00001581
    }
    cout << "[Environment Variable] " << "host = " << hostName << ", port = " << portID << ", server = " << serverName << ", marker = " << markerName << ", interface = " << interfaceName << endl ;
//D5000144 end

//D5000144    //--------------------------------------------------------------------------------
//D5000144    //  Bind to PPTServiceManagerObjectFactory and Create PPTServiceManager
//D5000144    //--------------------------------------------------------------------------------
//D5000144    CORBA::Orbix.connectionTimeout(60/*lConnectTimeout*/);
//D5000144    CORBA::Orbix.maxConnectRetries(60);
//D5000144
//D5000144    PPTServiceManagerObjectFactory_var aPPTServiceManagerObjectFactory;
//D5000144    try
//D5000144    {
//D5000144        aPPTServiceManagerObjectFactory = PPTServiceManagerObjectFactory::_bind(aMMServerName, aMMHostName);
//D5000144    }
//D5000144    catch( const CORBA::SystemException& Ex ) {
//D5000144        cerr << "PPTServiceManagerObjectFactory::_bind raised CORBA::SystemException" << endl ;
//D5000144        cerr <<  Ex;
//D5000144        return;
//D5000144    }
//D5000144    catch(...) {
//D5000144        cerr << "PPTServiceManagerObjectFactory::_bind raised unknown exception" << endl ;
//D5000144        return;
//D5000144    }
//D5000144    if ( CORBA::is_nil(aPPTServiceManagerObjectFactory) )
//D5000144    {
//D5000144        cerr << "PPTServiceManagerObjectFactory is nil" << endl ;
//D5000144        return;
//D5000144    }
//D5000144    cout << "bound PPTServiveManagerObjectFactory on " << aMMServerName << " of " << aMMHostName << endl;
//D5000144
//D5000144    try
//D5000144    {
//D5000144        aPPTServiceManager = aPPTServiceManagerObjectFactory->createPPTServiceManager();
//D5000144    }
//D5000144    catch( const CORBA::UserException& Ex ) {
//D5000144        cerr << "createPPTServiceManager() raised CORBA::UserException" << endl ;
//D5000144        cerr << Ex;
//D5000144        return;
//D5000144    }
//D5000144    catch( const CORBA::SystemException& Ex ) {
//D5000144        cerr << "createPPTServiceManager() raised CORBA::SystemException" << endl ;
//D5000144        cerr <<  Ex;
//D5000144        return;
//D5000144    }
//D5000144    catch(...) {
//D5000144        cerr << "PPTServiceManagerObjectFactory->createPPTServiceManager() raised unknown exception" << endl ;
//D5000144        return;
//D5000144    }
//D5000144    if ( CORBA::is_nil(aPPTServiceManager) )
//D5000144    {
//D5000144        cerr << "PPTServiceManager is nil" << endl ;
//D5000144        return;
//D5000144    }

//D5000144 start
    //--------------------------------------------------------------------------------------------
    //  Generate IOR of PPTServiceManager
    //--------------------------------------------------------------------------------------------
#ifdef EBROKER                                                                                   //D6000025
//PSIV00001581    char *strIOR = genIOR( hostName, portID, serverName, markerName, interfaceName, "EBROKER");  //D6000025
    CORBA::String_var strIOR = genIOR( hostName, portID, serverName, markerName, interfaceName, "EBROKER");     //PSIV00001581
#else                                                                                            //D6000025
//PSIV00001581    char *strIOR = genIOR( hostName, portID, serverName, markerName, interfaceName );
    CORBA::String_var strIOR = genIOR( hostName, portID, serverName, markerName, interfaceName );       //PSIV00001581
#endif                                                                                           //D6000025

    CORBA::Object_var anObj = SP_STRING_TO_OBJECT(strIOR);

    aPPTServiceManager = PPTServiceManager::_narrow(anObj);
    if( CORBA::is_nil( aPPTServiceManager ) )
    {
        cerr << "PPTServiceManager is nil" << endl ;
//PSIV00001581        return;
        return 3;       //PSIV00001581
    }
//D5000144 end
    cout << "got PPTServiceManager" << endl;

    //--------------------------------------------------------------------------------------------
    //  Prepare Input File and Output File
    //--------------------------------------------------------------------------------------------

    // getting output directry name
    char* theOutDirectory;

    char* p = getenv(OUTFILE_DIR);
    if( p && strlen(p) )
    {
        theOutDirectory = p;
    }
    else
    {
        theOutDirectory = "."; //current directory
    }

    // getting current timestamp
    struct timeb Tp;
    ftime(&Tp);
#ifdef _WIN32
    struct tm* ptm = localtime( &Tp.time );
    struct tm&  tm = *ptm;
#else
    struct tm tm;
    localtime_r(&Tp.time, &tm);
#endif

    // generating output file name
    char* theOutFileName = new char[1024];
    sprintf( theOutFileName, "%s/EntityInhibitMaint_%02d%02d%02d%02d%02d.log",
             theOutDirectory, tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday , tm.tm_hour, tm.tm_min );

    // opening output file
    ofstream fo( theOutFileName );
    if ( !fo )
    {
        cerr << "could not open output log file." << endl ;
//PSIV00001581        return;
        return 2;       //PSIV00001581
    }
    delete[] theOutFileName;    //PSIV00001581

    //------------------------------------------------------------------------
    //  Main Routine
    //------------------------------------------------------------------------

    //
    // setting user ID
    //
    pptUser strUser;
//D9000160    strUser.userID.identifier = "PPTSvcMgr";
//D9000160    strUser.password          = "shNdwTUQQ";
    strUser.functionID        = "Lot Information";

//DSN000100700 add start
    char *targetNameMMSVR = getenv(ENV_SP_CONINFO_TARGET_MMSVR);
    if( targetNameMMSVR && strlen(targetNameMMSVR) )
    {
        cout << "    MMSVR Target Name " << targetNameMMSVR << endl;
        sp_connectionInfo_auth_v10 info;
        int rc = sp_getConnectionInfo(targetNameMMSVR,info);
        if(rc != SP_CONNECTIONINFO_RC_OK )
        {
            cout << "sp_getConnectionInfo API returns : " << sp_getErrorMessage(rc) << endl;
            // Default variable
            strUser.userID.identifier = CIMFWStrDup("PPTSvcMgr");
            strUser.password          = EncryptPW("PPTSvcMgr") ;
        }
        else
        {
            strUser.userID.identifier = CIMFWStrDup( info.userid );
            strUser.password          = EncryptPW( info.passwd );
            cout << "    MMSVR Information UserId get Successful. " << strUser.userID.identifier << endl;
        }
    }
    else
    {
//DSN000100700 add end
//D9000160 add start
        //--------------------------------------
        // UserID
        //--------------------------------------
        work = getenv("SYSUSERID");
        if ( CIMFWStrLen( work ) > 0 )
        {
            // Environment variable
            strUser.userID.identifier = CIMFWStrDup( work );
        }
        else
        {
            // Default variable
            strUser.userID.identifier = CIMFWStrDup( "PPTSvcMgr" );
        }

        //--------------------------------------
        // Password
        //--------------------------------------
        work = getenv("SYSUSERPASSWD");
        if( CIMFWStrLen(work) > 0 )
        {
            // Environment variable
            strUser.password = EncryptPW( work );
        }
        else
        {
            // Default variable
            strUser.password = CIMFWStrDup( "shNdwTUQQ" );
        }
//D9000160 add end
    } //DSN000100700

    //
    // removing route inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
        searchCondition.entities[0].attrib    = CIMFWStrDup("*");

        delete_expiredEntityInhibit( strUser, searchCondition, fo );
    }

    //
    // removing operation inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup("Operation");
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit( strUser, searchCondition, fo );
    }

    //
    // removing operation inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit( strUser, searchCondition, fo );
    }

    //
    // removing process inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing recipe inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing product inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Product);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing fixture inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Fixture);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing fixture group inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_FixtureGroup);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing reticle inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Reticle);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing reticle group inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_ReticleGroup);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing machine inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing operation + product inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(2);
//P4000034        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
        searchCondition.entities[0].className = CIMFWStrDup("Operation");     //P4000034
        searchCondition.entities[0].attrib    = CIMFWStrDup("");
        searchCondition.entities[1].className = CIMFWStrDup(SP_InhibitClassID_Product);
        searchCondition.entities[1].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing equipment + recipe inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(2);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");
        searchCondition.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
        searchCondition.entities[1].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing process + machine inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(2);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");
        searchCondition.entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
        searchCondition.entities[1].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit( strUser, searchCondition, fo );
    }

//P5100338 add start
    //
    // removing "ModulePD" inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_ModulePD);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing "Stage" inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Stage);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing "Route Operation + Product + Equipment" inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(3);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");
        searchCondition.entities[1].className = CIMFWStrDup(SP_InhibitClassID_Product);
        searchCondition.entities[1].attrib    = CIMFWStrDup("");
        searchCondition.entities[2].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
        searchCondition.entities[2].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing "Equipment + Chamber" inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(1);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing "Equipment + Chamber + Product" inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(2);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");
        searchCondition.entities[1].className = CIMFWStrDup(SP_InhibitClassID_Product);
        searchCondition.entities[1].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit(strUser, searchCondition,fo);
    }

    //
    // removing "Equipment + Chamber + Machine Recipe" inhibit entries
    //
    {
//DSIV00001365        pptEntityInhibitAttributes searchCondition;
        pptEntityInhibitDetailAttributes searchCondition;    //DSIV00001365
        searchCondition.entities.length(2);
        searchCondition.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
        searchCondition.entities[0].attrib    = CIMFWStrDup("");
        searchCondition.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
        searchCondition.entities[1].attrib    = CIMFWStrDup("");

        delete_expiredEntityInhibit( strUser, searchCondition, fo );
    }
//P5100338 add end
    return 0;   //PSIV00001581
}


//DSIV00001365 void delete_expiredEntityInhibit(pptUser& strUser, pptEntityInhibitAttributes& searchCondition, ofstream& fo)
void delete_expiredEntityInhibit(pptUser& strUser, pptEntityInhibitDetailAttributes& searchCondition, ofstream& fo)    //DSIV00001365
{

    //
    // quirying entity inhibit entities
    //
//DSIV00001365    pptEntityInhibitListInqResult_var strEntityInhibitListInqResult;
    pptEntityInhibitListInqResult__101_var strEntityInhibitListInqResult;
    CORBA::Boolean entityInhibitReasonDetailInfoFlag = TRUE;
//PSN000103236 add start
    searchCondition.endTimeStamp = CIMFWStrDup(SP_ENDTIME_PAST);
//PSN000103236 add end
//DSIV00001365    try
//DSIV00001365    {
//DSIV00001365        cout << "about to call TxEntityInhibitListInq" << endl;
//DSIV00001365        strEntityInhibitListInqResult = aPPTServiceManager->TxEntityInhibitListInq (strUser, searchCondition);
//DSIV00001365        cout << "completed to call TxEntityInhibitListInq" << endl;
//DSIV00001365    }
//DSIV00001365    catch ( const CORBA::SystemException& Ex )
//DSIV00001365    {
//DSIV00001365        cerr << "TxEntityInhibitListInq() raised CORBA::SystemException" << endl ;
//DSIV00001365        cerr << Ex;
//DSIV00001365        return;
//DSIV00001365    }
//DSIV00001365    catch(...)
//DSIV00001365    {
//DSIV00001365        cerr << "TxEntityInhibitListInq() raised unknown exception" << endl ;
//DSIV00001365        return;
//DSIV00001365    }
//DSIV00001365 add start
    try
    {
        cout << "about to call TxEntityInhibitListInq__101" << endl;
        strEntityInhibitListInqResult = aPPTServiceManager->TxEntityInhibitListInq__101 (strUser, searchCondition, entityInhibitReasonDetailInfoFlag);
        cout << "completed to call TxEntityInhibitListInq__101" << endl;
    }
    catch ( const CORBA::SystemException& Ex )
    {
        cerr << "TxEntityInhibitListInq__101() raised CORBA::SystemException" << endl ;
        cerr << Ex;
        return;
    }
    catch(...)
    {
        cerr << "TxEntityInhibitListInq__101() raised unknown exception" << endl ;
        return;
    }
//DSIV00001365 add end
    //
    // checking end time of entity inhibit entities
    //
    unsigned int n = strEntityInhibitListInqResult->strEntityInhibitions.length();

//DSIV00001365    pptEntityInhibitInfoSequence expiredEntityInhibitions;
    pptEntityInhibitDetailInfoSequence expiredEntityInhibitions;    //DSIV00001365
    expiredEntityInhibitions.length(n);

//PSN000103236    TimeStampImpl aTimeStampImpl;
//PSN000103236    char* currentTimeStamp = (TimeStamp) aTimeStampImpl;

    unsigned int count = 0;
    for (unsigned int i=0; i<n; i++)
    {
        CORBA::Boolean fExpire = FALSE;
        char* endTimeStamp =
           strEntityInhibitListInqResult->strEntityInhibitions[i].entityInhibitAttributes.endTimeStamp;

        if ( CIMFWStrCmp(endTimeStamp, "1901-01-01-00.00.00.000000") != 0 && CIMFWStrLen(endTimeStamp) > 0 )
        {
//PSN000103236            if ( CIMFWStrCmp(endTimeStamp, currentTimeStamp) < 0 )
//PSN000103236            {
            fExpire = TRUE;
            expiredEntityInhibitions[count++] = strEntityInhibitListInqResult->strEntityInhibitions[i];
            print_EntityInhibit(fo, strEntityInhibitListInqResult->strEntityInhibitions[i]);
//PSN000103236            }
        }

        if ( fExpire )
        {
            cout << "********** expired **********" << endl;
        }
        else
        {
            cout << "******** not expired ********" << endl;
        }
        print_EntityInhibit(cout, strEntityInhibitListInqResult->strEntityInhibitions[i]);

    }
    expiredEntityInhibitions.length(count);

    //
    // removing expired entity inhibit entries
    //

    if ( expiredEntityInhibitions.length() > 0 )
    {

        // setting reason code and claim memo
        objectIdentifier reason;
//D6000348        reason.identifier = CIMFWStrDup("");
//D6000348        reason.stringifiedObjectReference = CIMFWStrDup("");
        reason.identifier = CIMFWStrDup("EXPD");                                                                //D6000348
        reason.stringifiedObjectReference = CIMFWStrDup("SPIORLL:N:P4/#PosCode#F4#EntityInhibitCancel-EXPD");   //D6000348
        CORBA::String_var claimMemo = CIMFWStrDup("cancelled due to expiration");

//DSIV00001365        try
//DSIV00001365        {
//DSIV00001365            pptEntityInhibitCancelReqResult_var strEntityInhibitCancelReqResult =
//DSIV00001365                aPPTServiceManager->TxEntityInhibitCancelReq(strUser, expiredEntityInhibitions, reason, claimMemo);
//DSIV00001365
//DSIV00001365            cout << "TxEntityInhibitCancelReq() returned " << strEntityInhibitCancelReqResult->strResult.returnCode << endl;
//DSIV00001365            cout << "TxEntityInhibitCancelReq() returned " << strEntityInhibitCancelReqResult->strResult.messageText << endl;
//DSIV00001365        }
//DSIV00001365        catch ( const CORBA::SystemException& Ex )
//DSIV00001365        {
//DSIV00001365            cerr << "TxEntityInhibitCancelReq() raised CORBA::SystemException" << endl ;
//DSIV00001365            cerr <<  Ex;
//DSIV00001365            return;
//DSIV00001365        }
//DSIV00001365        catch(...)
//DSIV00001365        {
//DSIV00001365            cerr << "TxEntityInhibitCancelReq() raised unknown exception" << endl ;
//DSIV00001365            return;
//DSIV00001365        }
//DSIV00001365 add start
        try
        {
            pptEntityInhibitCancelReqResult_var strEntityInhibitCancelReqResult =
                aPPTServiceManager->TxEntityInhibitCancelReq__101(strUser, expiredEntityInhibitions, reason, claimMemo);

            cout << "TxEntityInhibitCancelReq__101() returned " << strEntityInhibitCancelReqResult->strResult.returnCode << endl;
            cout << "TxEntityInhibitCancelReq__101() returned " << strEntityInhibitCancelReqResult->strResult.messageText << endl;
        }
        catch ( const CORBA::SystemException& Ex )
        {
            cerr << "TxEntityInhibitCancelReq__101() raised CORBA::SystemException" << endl ;
            cerr <<  Ex;
            return;
        }
        catch(...)
        {
            cerr << "TxEntityInhibitCancelReq__101() raised unknown exception" << endl ;
            return;
        }
//DSIV00001365 add end
    }

}

//DSIV00001365void print_EntityInhibit(ostream& out, pptEntityInhibitInfo& entityInhibitInfo)
void print_EntityInhibit(ostream& out, pptEntityInhibitDetailInfo& entityInhibitInfo)    //DSIV00001365
{
    out << "------------------------------------------------------------------------------" << endl;
    out << "ID     :";
    out << entityInhibitInfo.entityInhibitID.identifier             << endl;
    out << "ObjRef :";
    out << entityInhibitInfo.entityInhibitID.stringifiedObjectReference << endl;
    pptEntityIdentifierSequence entities = entityInhibitInfo.entityInhibitAttributes.entities;
    for (unsigned int j=0; j<entities.length(); j++ )
    {
        out << "Entity :";
        out << entities[j].className << ":" << entities[j].objectID.identifier << ":" << entities[j].attrib << endl;
    }
    stringSequence sublottypes = entityInhibitInfo.entityInhibitAttributes.subLotTypes;
    if ( sublottypes.length() > 0 )
    {
        for (unsigned int k=0; k<sublottypes.length(); k++ )
        {
            out << "LotType:";
            out << sublottypes[k] << endl;
        }
    }
    else
    {
        out << "LotType:*" << endl;
    }
//DSIV00001365 add start
    pptEntityInhibitReasonDetailInfoSequence reasonDetailInfos = entityInhibitInfo.entityInhibitAttributes.strEntityInhibitReasonDetailInfos;
    for (unsigned int l=0; l<reasonDetailInfos.length(); l++ )
    {
        out << "Reason Detail Informatoin :" << endl;
        out << "  Related Lot                  :";
        out << reasonDetailInfos[l].relatedLotID << endl;
        out << "  Related ControlJob           :";
        out << reasonDetailInfos[l].relatedControlJobID << endl;
        out << "  Related Fab                  :";
        out << reasonDetailInfos[l].relatedFabID << endl;
        out << "  Related Route                :";
        out << reasonDetailInfos[l].relatedRouteID << endl;
        out << "  Related Process Definition   :";
        out << reasonDetailInfos[l].relatedProcessDefinitionID << endl;
        out << "  Related Operation Number     :";
        out << reasonDetailInfos[l].relatedOperationNumber << endl;
        out << "  Related Operation Pass Count :";
        out << reasonDetailInfos[l].relatedOperationPassCount << endl;

        pptEntityInhibitSpcChartInfoSequence spcChartInfos = entityInhibitInfo.entityInhibitAttributes.strEntityInhibitReasonDetailInfos[l].strEntityInhibitSpcChartInfos;
        for (unsigned int m=0; m<spcChartInfos.length(); m++ )
        {
            out << "  Related SPC Chart :" << endl;
            out << "    DC Type  :";
            out << spcChartInfos[m].relatedSpcDcType << endl;
            out << "    Chart Group  :";
            out << spcChartInfos[m].relatedSpcChartGroupID << endl;
            out << "    Chart ID  :";
            out << spcChartInfos[m].relatedSpcChartID << endl;
            out << "    Chart Type  :";
            out << spcChartInfos[m].relatedSpcChartType << endl;
        }
    }
//DSIV00001365 add end
    out << "Claim  :";
    out << entityInhibitInfo.entityInhibitAttributes.claimedTimeStamp << endl;
    out << "Start  :";
    out << entityInhibitInfo.entityInhibitAttributes.startTimeStamp << endl;
    out << "End    :";
    out << entityInhibitInfo.entityInhibitAttributes.endTimeStamp << endl;
    out << "Reason :";
    out << entityInhibitInfo.entityInhibitAttributes.reasonCode << endl;
    out << "Owner  :";
    out << entityInhibitInfo.entityInhibitAttributes.ownerID.identifier << endl;
    out << "Memo   :";
    out << entityInhibitInfo.entityInhibitAttributes.memo << endl;

}
