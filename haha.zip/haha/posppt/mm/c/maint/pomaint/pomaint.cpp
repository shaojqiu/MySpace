/************************************************************************************
**
**  System      : SiView Management of Process Operation's Data Program
**
**  Module name : pomaint.cpp
**
**  Description : Management of Process Operation's Data Program
**
** (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
** (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
**
**
** Change history:
** Date       Defect#      Person         Comments
** ---------- ------------ -------------- -------------------------------------------
** 2010/10/14 DSIV00002270 K.Yamaoku      PO Maintenance Improvement
** 2011/01/11 DSIV00002757 K.Yamaoku      Improvement of PO Maintenance Program
** 2011/08/15 DSN000015229 K.Yamaoku      Advanced Wafer Level Control
** 2012/01/24 DSN000030296 K.Yamaoku      Support thread ID which is longer than 8 digit
** 2015/10/27 DSN000100700 K.Yamaoku      Security enhancement.
**
*************************************************************************************/

#ifdef SPFW_IMIZED
#include <iostream.h>
#include <fstream.h>
#include <strstream.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <signal.h>
#include <locale.h>
#include <nl_types.h>
#include <time.h>
#include <sys/timeb.h>

#include <stdarg.h>
#include <unistd.h>
#include <pthread.h>
#include <nl_types.h>
#include <timeb.h>
#include <syslog.h>
#include <pthread.h>
#endif

// Event log.

#include "speventipc.hpp"

#include "sp_coninfo.hpp"           //DSN000100700
#include "sp_coninfo_target.hpp"    //DSN000100700

#define  INCL_MAIN
#include "pomaintdf.hpp"
#include "pomaintmsg.h"

const char * StatusStr[] = { "na", "idle", "busy", "stop", "error", "init" };
const char * LotStateStr[] = { LOT_STATE_ACTIVE, LOT_STATE_SHIPPED, LOT_STATE_SCRAPPED, LOT_STATE_EMPTIED, LOT_STATE_STACKED };

CORBA::Boolean  fEndOfProcess = FALSE;

int GetProgramParameters( void );
int GetInputFileSettings( void );

void EventDrivenProcess( void );
CORBA::Long EventDrivenSubLotTypeProcess( const char* currentTimeStamp, const char* subLotType, const int keepCount );
void threadFunc( void *param );
void threadPODeleteFunc( threadinfo *pthreadinfo );

void MaintenanceProcess();
CORBA::Long MaintenanceSubLotTypeProcess( const char* subLotType, const int keepCount );
CORBA::Long MaintenanceLotProcess( const char* subLotType, const int keepCount, const char* lotID );

CORBA::Long PODeleteProcess( const char* currentTimeStamp, const pomaintLotInf& strLotInf, const int specifiedKeepCount );

int startThreads( const int thread_count );
int get_specified_state_thread_count( const invoker_threadstatus status );
void wait_all_thread_start( void );
void wait_all_thread_not_busy( void );
void clear_all_thread_lotID( void );
int Pthread_cond_timedwait_sec( pthread_cond_t *cptr, pthread_mutex_t *mptr, int sec );

int GetKeepCount( const char* subLotType );
CORBA::Boolean CheckInactiveLotPeriodNotPassed( const invoker_lotstate lotState, const char* claimTime, const char* currentTimeStamp );
CORBA::Long CheckKeepCountOfActiveChildLot( const stringSequence& childPfxKeySeq, const int poSeqNo, const int keepCount, const char* parentSubLotType, const char* parentLotID );

void sigHandler( int code );

time_t TimestampToSeconds( const char* aTimeStamp, unsigned long* microSeconds );
void SecondsToTimestamp( const time_t seconds, const unsigned long microSeconds, char* aTimeStamp );

char* getMessage( int msgid );

//trace
void trace_verbose_print( const char *filename, const int lineno, const char *str );
void eventLog_put( const char *subLotType, const char* lotID, const long returnCode, const char *message, char *format = NULL, ... );

/*============================================================================*/
/*                                                                            */
/*   Main : pomaint.cpp                                                      */
/*                                                                            */
/*============================================================================*/
int main(int ac, char *ag[])
{
    POMAINT_FUNCTION_TRACE_ENTRY( 2, "POMaintenanceProgram::Main" );
    POMAINT_EVENT_LOG1( "", "", 0, "####################################################" );
    POMAINT_EVENT_LOG1( "", "", 0, "######## Starting PO Maintenance Program... ########" );
    POMAINT_EVENT_LOG1( "", "", 0, "####################################################" );

    int rc;

    /*-----------------------------------------------------------------------*/
    /*   Signal Handler                                                      */
    /*-----------------------------------------------------------------------*/
    signal( SIGINT,  sigHandler );
    signal( SIGKILL, sigHandler );
    signal( SIGHUP,  sigHandler );
    signal( SIGTERM, sigHandler );
    signal( SIGQUIT, sigHandler );

    /*-----------------------------------------------------------------------*/
    /*   Program Initialize                                                  */
    /*-----------------------------------------------------------------------*/
    rc = GetProgramParameters();
    if ( rc != RC_OK )
    {
        POMAINT_EVENT_LOG1( "", "", rc, getMessage( rc ) );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::Main" );
        exit(-1);
    }

    /*-----------------------------------------------------------------------*/
    /*   Check Command-line Arguments                                        */
    /*-----------------------------------------------------------------------*/
    gb_InputFileName = NULL;
    gb_Option = NULL;
    if ( ac > 1 )
    {
        if ( CIMFWStrCmp( ag[1], "-q" ) == 0 || CIMFWStrCmp( ag[1], "-e" ) == 0 )
        {
            gb_Option = ag[1];
            if ( ac > 2 )
            {
                gb_InputFileName = ag[2];
            }
        }
        else
        {
            gb_InputFileName = ag[1];
        }
    }

    // Event Driven Mode
    if ( gb_EventDrivenEnabled )
    {
        if ( gb_Option != NULL )
        {
            POMAINT_TRACE_VERBOSE1( 1, getMessage( MSG_UNNECESSARY_OPT_ERROR ) );
            POMAINT_EVENT_LOG1( "", "", 0, getMessage( MSG_UNNECESSARY_OPT_ERROR ) );
            POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::Main" );
            exit(-1);
        }
    }
    // Maintenance Mode
    else
    {
        if ( gb_Option == NULL )
        {
            POMAINT_TRACE_VERBOSE1( 1, getMessage( MSG_OPT_ERROR ) );
            POMAINT_EVENT_LOG1( "", "", 0, getMessage( MSG_OPT_ERROR ) );
            POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::Main" );
            exit(-1);
        }
    }

    if (!gb_AllSubLotTypeEnabled)
    {
        if ( gb_InputFileName == NULL )
        {
            POMAINT_TRACE_VERBOSE1( 1, getMessage( MSG_INPUTFILENAME_ERROR ) );
            POMAINT_EVENT_LOG1( "", "", 0, getMessage( MSG_INPUTFILENAME_ERROR ) );
            POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::Main" );
            exit(-1);
        }
    }

    /*-----------------------------------------------------------------------*/
    /*  Read Input File                                                      */
    /*-----------------------------------------------------------------------*/
    if ( gb_InputFileName != NULL )
    {
        rc = GetInputFileSettings();
        if ( rc != RC_OK )
        {
            POMAINT_EVENT_LOG1( "", "", rc, getMessage( rc ) );
            POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::Main" );
            exit(-1);
        }
    }

    /*-----------------------------------------------------------------------*/
    /*  Main Process                                                         */
    /*-----------------------------------------------------------------------*/
    // Event Driven Mode
    if ( gb_EventDrivenEnabled )
    {
        EventDrivenProcess();
    }
    // Maintenance Mode
    else
    {
        MaintenanceProcess();
    }

    POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::Main" );

    cout << "PO Maintenance Program will be shutdown gracefully." << endl;
    return RC_OK;
}

//------------------------------------------------------------------------
//
//   GetProgramParameters
//
//  Input  Parameter
//              none
//
//  Output Parameter
//              none
//
//  Return Code
//      RC_OK                       OK
//      RC_PROGRAMPARAMETER_ERROR   Program Parameter Get Error
//
//------------------------------------------------------------------------
int GetProgramParameters()
{
    POMAINT_FUNCTION_TRACE_ENTRY( 0, "POMaintenanceProgram::GetProgramParameter Function" );
    char *work;

    //------------------------------
    // Catalog File
    //------------------------------
    setlocale( LC_ALL, "" );
    char* catalogFile = getenv( POMAINT_CATALOG_FILE );

    if ( catalogFile == NULL || CIMFWStrLen( catalogFile ) == 0 )
    {
        catalogFile = MF_POMAINTMSG;
    }
    catd = catopen( catalogFile, 0 );
    if ( catd == CATD_ERR )
    {
        POMAINT_TRACE_VERBOSE3( 1, "Opening catalogue file : ", catalogFile, "Failed !" );
        POMAINT_FUNCTION_TRACE_EXIT( 0, "POMaintenanceProgram::GetProgramParameter Function" );
        return( RC_PROGRAMPARAMETER_ERROR );
    }

    //------------------------------
    // POMAINT_DEBUG_FLAG_ON Get
    //------------------------------
    work = getenv( POMAINT_DEBUG_FLAG_ON );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_DebugFlagON = Default_DebugFlagON;
    }
    else
    {
        gb_DebugFlagON = atoi( work );
        if ( 0 != gb_DebugFlagON && 1 != gb_DebugFlagON )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_DEBUG_FLAG_ON is not specified correctly. Default value is used. ");
            gb_DebugFlagON = Default_DebugFlagON;
        }
    }

    //------------------------------
    // POMAINT_DEBUG_LEVEL Get
    //------------------------------
    work = getenv( POMAINT_DEBUG_LEVEL );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_DebugLevel = Default_DebugLevel;
    }
    else
    {
        gb_DebugLevel = atoi( work );
        if ( gb_DebugLevel < 0 )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_DEBUG_LEVEL is not specified correctly. Default value is used. ");
            gb_DebugLevel = Default_DebugLevel;
        }
    }

//DSN000100700 add start
    char *targetNameMMDB = getenv(ENV_SP_CONINFO_TARGET_MMDB);
    if( targetNameMMDB && strlen(targetNameMMDB) )
    {
        POMAINT_TRACE_VERBOSE2( 3, "    MMDB Target Name ", targetNameMMDB );
        sp_connectionInfo_db_v10 info;
        int rc = sp_getConnectionInfo(targetNameMMDB,info);
        if(rc != SP_CONNECTIONINFO_RC_OK )
        {
            POMAINT_TRACE_VERBOSE2( 1, "sp_getConnectionInfo API returns : ", sp_getErrorMessage(rc) );
            POMAINT_FUNCTION_TRACE_EXIT( 0, "POMaintenanceProgram::GetProgramParameter Function" );
            return RC_PROGRAMPARAMETER_ERROR;
        }
        gb_DBName     = CIMFWStrDup(info.dbname);
        gb_DBUserName = CIMFWStrDup(info.userid);
        gb_Password   = CIMFWStrDup(info.passwd);
    }
    else
    {
//DSN000100700 add end
        //------------------------------
        // POMAINT_DBNAME Get
        //------------------------------
        gb_DBName = getenv( POMAINT_DBNAME );
        if ( gb_DBName == NULL || CIMFWStrLen( gb_DBName ) == 0 )
        {
            POMAINT_TRACE_VERBOSE2( 1, " Parameter Name : POMAINT_DBNAME", "Program Parameter Get Error." );
            POMAINT_FUNCTION_TRACE_EXIT( 0, "POMaintenanceProgram::GetProgramParameter Function" );
            return( RC_PROGRAMPARAMETER_ERROR );
        }

        //------------------------------
        // POMAINT_USERNAME Get
        //------------------------------
        gb_DBUserName = getenv( POMAINT_USERNAME );
        if ( gb_DBUserName == NULL || CIMFWStrLen( gb_DBUserName ) == 0 )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_USERNAME is not specified." );
            gb_DBUserName = NULL;
        }
        else
        {
            POMAINT_TRACE_VERBOSE2( 3, "POMAINT_USERNAME get Successful. ", gb_DBUserName );
        }

        //------------------------------
        // POMAINT_PASSWORD Get
        //------------------------------
        gb_Password = getenv( POMAINT_PASSWORD );
        if ( gb_Password == NULL || CIMFWStrLen( gb_Password ) == 0 )
        {
            gb_Password = NULL;
        }
    } //DSN000100700

    if ( gb_DBUserName != NULL && gb_Password == NULL )
    {
        POMAINT_TRACE_VERBOSE2( 1, " Parameter Name : POMAINT_PASSWORD", "Program Parameter Get Error." );
        POMAINT_FUNCTION_TRACE_EXIT( 0, "POMaintenanceProgram::GetProgramParameter Function" );
        return( RC_PROGRAMPARAMETER_ERROR );
    }
    else if ( gb_DBUserName == NULL && gb_Password == NULL )
    {
        POMAINT_TRACE_VERBOSE1( 3, "POMAINT_PASSWORD is not specified. ");
    }
    else
    {
//DSN000100700        POMAINT_TRACE_VERBOSE2( 3, "POMAINT_PASSWORD get Successful. ", gb_Password );
        POMAINT_TRACE_VERBOSE1( 3, "POMAINT_PASSWORD get Successful. " ); //DSN000100700
    }

    //------------------------------
    // POMAINT_EXITCOUNT Get
    //------------------------------
    work = getenv( POMAINT_EXITCOUNT );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_ExitCount = Default_ExitCount;
    }
    else
    {
        gb_ExitCount = atoi( work );
        if ( EXIT_COUNT_MIN > gb_ExitCount )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_EXITCOUNT is not specified correctly. Default value is used. ");
            gb_ExitCount = Default_ExitCount;
        }
    }

    //------------------------------
    // POMAINT_COMMITCOUNT Get
    //------------------------------
    work = getenv( POMAINT_COMMITCOUNT );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_CommitCount = Default_CommitCount;
    }
    else
    {
        gb_CommitCount = atoi( work );
        if ( COMMIT_COUNT_MIN > gb_CommitCount )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_COMMITCOUNT is not specified correctly. Default value is used. ");
            gb_CommitCount = Default_CommitCount;
        }
    }

    //------------------------------
    // POMAINT_EVENTDRIVEN_ENABLED Get
    //------------------------------
    work = getenv( POMAINT_EVENTDRIVEN_ENABLED );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_EventDrivenEnabled = Default_EventDrivenEnabled;
    }
    else
    {
        gb_EventDrivenEnabled = atoi( work );
        if ( 0 != gb_EventDrivenEnabled && 1 != gb_EventDrivenEnabled )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_EVENTDRIVEN_ENABLED is not specified correctly. Default value is used. ");
            gb_EventDrivenEnabled = Default_EventDrivenEnabled;
        }
    }

    //------------------------------
    // POMAINT_INTERVALTIME Get
    //------------------------------
    work = getenv( POMAINT_INTERVALTIME );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_IntervalTime = Default_IntervalTime;
    }
    else
    {
        gb_IntervalTime = atoi( work );
        if ( INTERVAL_TIME_MIN > gb_IntervalTime )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_INTERVALTIME is not specified correctly. Default value is used. ");
            gb_IntervalTime = Default_IntervalTime;
        }
    }

//DSIV00002757 add start
    //------------------------------
    // POMAINT_ACTIVE_ENABLED Get
    //------------------------------
    work = getenv( POMAINT_ACTIVE_ENABLED );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_ActiveEnabled = Default_ActiveEnabled;
    }
    else
    {
        gb_ActiveEnabled = atoi( work );
        if ( 0 != gb_ActiveEnabled && 1 != gb_ActiveEnabled )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_ACTIVE_ENABLED is not specified correctly. Default value is used. ");
            gb_ActiveEnabled = Default_ActiveEnabled;
        }
    }
//DSIV00002757 add end

    //------------------------------
    // POMAINT_INACTIVE_ENABLED Get
    //------------------------------
    work = getenv( POMAINT_INACTIVE_ENABLED );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_InactiveEnabled = Default_InactiveEnabled;
    }
    else
    {
        gb_InactiveEnabled = atoi( work );
        if ( 0 != gb_InactiveEnabled && 1 != gb_InactiveEnabled )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_INACTIVE_ENABLED is not specified correctly. Default value is used. ");
            gb_InactiveEnabled = Default_InactiveEnabled;
        }
    }

    //------------------------------
    // POMAINT_PO_RESERVE_PERIOD_SHIPPED Get
    //------------------------------
    work = getenv( POMAINT_PO_RESERVE_PERIOD_SHIPPED );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_PoReservePeriodShipped = Default_PoReservePeriodShipped;
    }
    else
    {
        gb_PoReservePeriodShipped = atoi( work );
        if ( PO_RESERVE_PERIOD_MIN > gb_PoReservePeriodShipped )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_PO_RESERVE_PERIOD_SHIPPED is not specified correctly. Default value is used. ");
            gb_PoReservePeriodShipped = Default_PoReservePeriodShipped;
        }
    }

    //------------------------------
    // POMAINT_PO_RESERVE_PERIOD_SCRAPPED Get
    //------------------------------
    work = getenv( POMAINT_PO_RESERVE_PERIOD_SCRAPPED );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_PoReservePeriodScrapped = Default_PoReservePeriodScrapped;
    }
    else
    {
        gb_PoReservePeriodScrapped = atoi( work );
        if ( PO_RESERVE_PERIOD_MIN > gb_PoReservePeriodScrapped )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_PO_RESERVE_PERIOD_SCRAPPED is not specified correctly. Default value is used. ");
            gb_PoReservePeriodScrapped = Default_PoReservePeriodScrapped;
        }
    }

    //------------------------------
    // POMAINT_PO_RESERVE_PERIOD_STACKED Get
    //------------------------------
    work = getenv( POMAINT_PO_RESERVE_PERIOD_STACKED );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_PoReservePeriodStacked = Default_PoReservePeriodStacked;
    }
    else
    {
        gb_PoReservePeriodStacked = atoi( work );
        if ( PO_RESERVE_PERIOD_MIN > gb_PoReservePeriodStacked )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_PO_RESERVE_PERIOD_STACKED is not specified correctly. Default value is used. ");
            gb_PoReservePeriodStacked = Default_PoReservePeriodStacked;
        }
    }

    //------------------------------
    // POMAINT_ALL_SUBLOTTYPE_ENABLED Get
    //------------------------------
    work = getenv( POMAINT_ALL_SUBLOTTYPE_ENABLED );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_AllSubLotTypeEnabled = Default_AllSubLotTypeEnabled;
    }
    else
    {
        gb_AllSubLotTypeEnabled = atoi( work );
        if ( 0 != gb_AllSubLotTypeEnabled && 1 != gb_AllSubLotTypeEnabled )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_ALL_SUBLOTTYPE_ENABLED is not specified correctly. Default value is used. ");
            gb_AllSubLotTypeEnabled = Default_AllSubLotTypeEnabled;
        }
    }

    //------------------------------
    // POMAINT_DEFAULT_KEEPCOUNT Get
    //------------------------------
    work = getenv( POMAINT_DEFAULT_KEEPCOUNT );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_DefaultKeepCount = Default_DefaultKeepCount;
    }
    else
    {
        gb_DefaultKeepCount = atoi( work );
        if ( DEFAULT_KEEP_COUNT_MIN > gb_DefaultKeepCount )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_DEFAULT_KEEPCOUNT is not specified correctly. Default value is used. ");
            gb_DefaultKeepCount = Default_DefaultKeepCount;
        }
    }

    //------------------------------
    // POMAINT_THREADCOUNT Get
    //------------------------------
    work = getenv( POMAINT_THREADCOUNT );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_ThreadCount = Default_ThreadCount;
    }
    else
    {
        gb_ThreadCount = atoi( work );
        if ( THREAD_COUNT_MIN > gb_ThreadCount || THREAD_COUNT_MAX < gb_ThreadCount )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_THREADCOUNT is not specified correctly. Default value is used. ");
            gb_ThreadCount = Default_ThreadCount;
        }
    }

    //------------------------------
    // POMAINT_DB_RETRY_COUNT Get
    //------------------------------
    work = getenv( POMAINT_DB_RETRY_COUNT );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_DBRetryCount = Default_DBRetryCount;
    }
    else
    {
        gb_DBRetryCount = atoi( work );
        if ( DB_RETRY_COUNT_MIN > gb_DBRetryCount || DB_RETRY_COUNT_MAX < gb_DBRetryCount )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_DB_RETRY_COUNT is not specified correctly. Default value is used. ");
            gb_DBRetryCount = Default_DBRetryCount;
        }
    }

    //------------------------------
    // POMAINT_DB_RETRY_INTERVAL Get
    //------------------------------
    work = getenv( POMAINT_DB_RETRY_INTERVAL );
    if ( work == NULL || CIMFWStrLen( work ) == 0 )
    {
        gb_DBRetryInterval = Default_DBRetryInterval;
    }
    else
    {
        gb_DBRetryInterval = atoi( work );
        if ( DB_RETRY_INTERVAL_MIN > gb_DBRetryInterval || DB_RETRY_INTERVAL_MAX < gb_DBRetryInterval )
        {
            POMAINT_TRACE_VERBOSE1( 3, "POMAINT_DB_RETRY_INTERVAL is not specified correctly. Default value is used. ");
            gb_DBRetryInterval = Default_DBRetryInterval;
        }
    }

    POMAINT_TRACE_VERBOSE1( 3, "catalogue file Open Successful " );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_DEBUG_FLAG_ON               ", gb_DebugFlagON             );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_DEBUG_LEVEL                 ", gb_DebugLevel              );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_DBNAME                      ", gb_DBName                  );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_USERNAME                    ", gb_DBUserName              );
//DSN000100700    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_PASSWORD                    ", gb_Password                );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_EXITCOUNT                   ", gb_ExitCount               );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_COMMITCOUNT                 ", gb_CommitCount             );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_EVENTDRIVEN_ENABLED         ", gb_EventDrivenEnabled      );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_INTERVALTIME                ", gb_IntervalTime            );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_ACTIVE_ENABLED              ", gb_ActiveEnabled           );  //DSIV00002757
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_INACTIVE_ENABLED            ", gb_InactiveEnabled         );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_PO_RESERVE_PERIOD_SHIPPED   ", gb_PoReservePeriodShipped  );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_PO_RESERVE_PERIOD_SCRAPPED  ", gb_PoReservePeriodScrapped );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_PO_RESERVE_PERIOD_STACKED   ", gb_PoReservePeriodStacked  );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_ALL_SUBLOTTYPE_ENABLED      ", gb_AllSubLotTypeEnabled    );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_DEFAULT_KEEPCOUNT           ", gb_DefaultKeepCount        );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_THREADCOUNT                 ", gb_ThreadCount             );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_DB_RETRY_COUNT              ", gb_DBRetryCount            );
    POMAINT_TRACE_VERBOSE2( 3, "    POMAINT_DB_RETRY_INTERVAL           ", gb_DBRetryInterval         );

    POMAINT_FUNCTION_TRACE_EXIT( 0, "POMaintenanceProgram::GetProgramParameter Function" );
    return(RC_OK);
}

//------------------------------------------------------------------------
//
//   GetInputFileSettings
//
//  Input  Parameter
//              none
//
//  Output Parameter
//              none
//
//  Return Code
//      RC_OK                       OK
//      RC_INPUTFILESETTING_ERROR   Input File Setting Get Error
//
//------------------------------------------------------------------------
int GetInputFileSettings()
{
    POMAINT_FUNCTION_TRACE_ENTRY( 0, "POMaintenanceProgram::GetInputFileSettings Function" );

    // Open input file
    ifstream fi( gb_InputFileName );
    if ( !fi )
    {
        POMAINT_TRACE_VERBOSE2( 1, "Open Input File Error. InputFile : ", gb_InputFileName );
        POMAINT_FUNCTION_TRACE_EXIT( 0, "POMaintenanceProgram::GetInputFileSettings Function" );
        return ( RC_INPUTFILESETTING_ERROR );
    }

    CORBA::Long extend_len = 50;
    CORBA::Long t_Len      = extend_len;
    CORBA::Long count      = 0;

    strInputFileLineSeq.length( t_Len );

    const int bufLen = 2048;
    char inbuf[bufLen];
    char tmpbuf[bufLen];

    while ( fi.getline( inbuf, bufLen ) )
    {
        //------------------------------------------------
        //  Get SubLotType and KeepCount from InputFile
        //------------------------------------------------
        POMAINT_TRACE_VERBOSE2( 3, "Get SubLotType and KeepCount from InputFile : ", gb_InputFileName );

        istrstream str( inbuf, bufLen );
        str.getline( tmpbuf, bufLen );

        char* subLotType = NULL;
        char* keepCount  = NULL;

        // Get SubLotType and KeepCount from InputFile's line ("SubLotType,KeepCount")
        char* token1 = strchr( tmpbuf, ',' );
        if ( token1 != NULL )
        {
            *token1 = 0;
            subLotType = tmpbuf;
            keepCount = ++token1;
        }

        POMAINT_TRACE_VERBOSE4( 3, "SubLotType : ", subLotType, ", KeepCount : ", keepCount );

        if ( subLotType == NULL || strlen( subLotType ) == 0 )
        {
            POMAINT_TRACE_VERBOSE1( 2, "SubLotType is not specified." );
            continue;    // To the next SubLotType.
        }

        if ( keepCount == NULL || strlen( keepCount ) == 0 )
        {
            POMAINT_TRACE_VERBOSE3( 2, "Keep Count of SubLotType [", subLotType, "] is not specified." );
            continue;    // To the next SubLotType.
        }

        int iKeepCount = atoi( keepCount );
        if ( iKeepCount == 0 )
        {
            POMAINT_TRACE_VERBOSE3( 3, "KeepCount of SubLotType [", subLotType, ",] is changed from 0 to 1." );
            iKeepCount = 1;
        }

        if ( count >= t_Len )
        {
            t_Len += extend_len;
            strInputFileLineSeq.length( t_Len );
        }
        strInputFileLineSeq[count].subLotType = CIMFWStrDup( subLotType );
        strInputFileLineSeq[count].keepCount  = iKeepCount;
        count++;
    }

    POMAINT_TRACE_VERBOSE2( 3, "count : ", count );
    strInputFileLineSeq.length( count );

    POMAINT_FUNCTION_TRACE_EXIT( 0, "POMaintenanceProgram::GetInputFileSettings Function" );
    return(RC_OK);
}

//------------------------------------------------------------------------
//
//   EventDrivenProcess
//
//  Input  Parameter
//              none
//
//  Output Parameter
//              none
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void EventDrivenProcess()
{
    POMAINT_FUNCTION_TRACE_ENTRY( 2, "POMaintenanceProgram::EventDrivenProcess" );

    CORBA::Long rc      = 0;
    CORBA::Long sqlcode = 0;

    //----------------------------------
    // Initialize main thread SQL context
    //----------------------------------
    rc = InitializeSqlContext( &gb_ctx, &gb_DBConnectFlag );
    if ( rc != RC_OK )
    {
        POMAINT_EVENT_LOG1( "", "", 0, getMessage( rc ) );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::EventDrivenProcess" )
        return;
    }

    //----------------------------------
    // Check DB connection
    //----------------------------------
    if ( !gb_DBConnectFlag )
    {
        rc = RC_DATABASE_CONNECT_ERROR;
        POMAINT_EVENT_LOG1( "", "", rc, getMessage( rc ) );

        //----------------------------------
        // Cleanup main thread SQL context
        //----------------------------------
        rc = CleanupSqlContext( &gb_ctx, &gb_DBConnectFlag );
        if ( rc != RC_OK )
        {
            POMAINT_EVENT_LOG1( "", "", rc, getMessage( rc ) );
        }

        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::EventDrivenProcess" )
        return;
    }

    //----------------------------------
    // Start worker threads
    //----------------------------------
    if ( 0 > startThreads( gb_ThreadCount ) )
    {
        POMAINT_EVENT_LOG1( "", "", 0, getMessage( MSG_START_THREAD_FAILED ) );
        POMAINT_TRACE_VERBOSE1( 2, getMessage( MSG_START_THREAD_FAILED ) );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::EventDrivenProcess" )
        exit(1);
    }

    //----------------------------------
    // All thread start waiting
    //----------------------------------
    wait_all_thread_start();

    //----------------------------------
    // Check idle thread
    //----------------------------------
    int idleCount = get_specified_state_thread_count( idle );
    if ( idleCount == 0 )
    {
        POMAINT_EVENT_LOG1( "", "", 0, getMessage( MSG_ALL_THREAD_INIT_ERROR ) );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::EventDrivenProcess" )
        return;
    }

    POMAINT_TRACE_VERBOSE2( 2, getMessage( MSG_NUMBER_OF_START_THREAD ), idleCount );
    POMAINT_EVENT_LOG2( "", "", 0, getMessage( MSG_NUMBER_OF_START_THREAD ), idleCount ) ;

    CORBA::Boolean waitIntervalTimeFlag = FALSE;
    while ( !fEndOfProcess )
    {
        POMAINT_TRACE_VERBOSE1( 2, "" );

        if ( waitIntervalTimeFlag )
        {
            POMAINT_TRACE_VERBOSE2( 2, "Prorgram Sleeping...... Please Wait.", gb_IntervalTime );

            pthread_mutex_lock( &lock );
            Pthread_cond_timedwait_sec( &sig, &lock, gb_IntervalTime );
            pthread_mutex_unlock( &lock );

            if ( fEndOfProcess )
            {
                break;
            }
        }
        waitIntervalTimeFlag = TRUE;

        if ( !gb_DBConnectFlag )
        {
            //----------------------------------
            // Reconnect DataBase
            //----------------------------------
            rc = ConnectDataBase();
            if ( rc != RC_OK )
            {
                POMAINT_EVENT_LOG1( "", "", rc, getMessage( rc ) );
                continue;
            }
            else
            {
                gb_DBConnectFlag = 1;
            }
        }

        //----------------------------------
        // Get DB current timestamp
        //----------------------------------
        char currentTimeStamp[64];
        sqlcode = GetTimeStamp( currentTimeStamp );
        if ( sqlcode != 0 )
        {
            CHECK_DB_CONNECTION_ERROR( "", "", getMessage( MSG_GET_CURRENT_TIMESTAMP_ERROR ), sqlcode, gb_DBConnectFlag );
            continue;
        }

        // Specified Sub lot Type
        if ( !gb_AllSubLotTypeEnabled )
        {
            //----------------------------------
            // Specified Sub lot Type loop
            //----------------------------------
            int inputFileCount = strInputFileLineSeq.length();
            for ( int inputFileIndex = 0; inputFileIndex < inputFileCount; inputFileIndex++ )
            {
                rc = EventDrivenSubLotTypeProcess( currentTimeStamp, strInputFileLineSeq[inputFileIndex].subLotType, strInputFileLineSeq[inputFileIndex].keepCount );
                if ( rc == RC_DATABASE_CONNECT_ERROR )
                {
                    // DB disconnection
                    gb_DBConnectFlag = 0;
                    // Exit Specified Sub lot Type loop
                    break;
                }
            }
        }
        // All Sub Lot Type
        else
        {
            sqlcode = EventDrivenSubLotTypeProcess( currentTimeStamp, NULL, 0 );
            if ( rc == RC_DATABASE_CONNECT_ERROR )
            {
                // DB disconnection
                gb_DBConnectFlag = 0;
            }
        }

        //----------------------------------
        // All thread process completion waiting
        //----------------------------------
        wait_all_thread_not_busy();

        //----------------------------------
        // Clear all thread lotID
        //----------------------------------
        clear_all_thread_lotID();
    }

    //----------------------------------
    // Cleanup main thread SQL context
    //----------------------------------
    rc = CleanupSqlContext( &gb_ctx, &gb_DBConnectFlag );
    if ( rc != RC_OK )
    {
        POMAINT_EVENT_LOG1( "", "", rc, getMessage( rc ) );
    }

    //----------------------------------
    //wait for end of worker threads
    //----------------------------------
    for ( int i = 0; i < gb_ThreadCount; i++ )
    {
        threadinfo * pthreadinfo = &(pthreadinfos[ i ]);
        pthread_join( pthreadinfo->tid, NULL );
    }

    POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::EventDrivenProcess" )
}

//------------------------------------------------------------------------
//
//   EventDrivenSubLotTypeProcess
//
//  Input  Parameter
//              const char* currentTimeStamp
//              const char* subLotType
//              const int keepCount
//
//  Output Parameter
//              none
//
//  Return Code
//              RC_OK
//              RC_DATABASE_CONNECT_ERROR
//              RC_SYSTEM_ERROR
//
//------------------------------------------------------------------------
CORBA::Long EventDrivenSubLotTypeProcess( const char* currentTimeStamp, const char* subLotType, const int keepCount )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::EventDrivenSubLotTypeProcess", "START" );

    CORBA::Long sqlcode         = 0;
    CORBA::Boolean dataEndFlag  = FALSE;
    CORBA::Long eventQueueCount = 0;
    CORBA::Long eventQueueIndex = 0;

    eventQueueCount = 0;

    while ( !fEndOfProcess )
    {
        if ( eventQueueCount <= 0 )
        {
            if ( dataEndFlag )
            {
                break;
            }

            sqlcode = GetLotsForEventDriven( currentTimeStamp, subLotType );
            if ( sqlcode != 0 )
            {
                CHECK_SQL_ERROR_RETURN( subLotType, "", "POMaintenanceProgram::EventDrivenSubLotTypeProcess", getMessage( MSG_GET_TARGET_LOT_ERROR ), sqlcode );
            }
            eventQueueCount = strEventQueueSeq.length();
            eventQueueIndex = 0;
            if ( eventQueueCount < DB_FETCH_COUNT_MAX_FOR_LOT )
            {
                dataEndFlag = TRUE;
            }
        }

        if ( eventQueueCount > 0 && get_specified_state_thread_count( idle ) == 0 )
        {
            POMAINT_TRACE_VERBOSE1( 2, "Waiting for idle worker thread......" );

            //Wait for signal from worker threads
            pthread_mutex_lock( &lock );
            if( notify_count <= 0 )
            {
                Pthread_cond_timedwait_sec( &sig, &lock, 5 );
            }
            else
            {
                notify_count = 0;
            }
            pthread_mutex_unlock( &lock );

            if ( get_specified_state_thread_count( idle ) == 0 )
            {
                continue;
            }
            if ( fEndOfProcess )
            {
                break;
            }
        }

        for ( int threadIndex = 0; threadIndex < gb_ThreadCount; threadIndex++ )
        {
            if ( eventQueueCount <= 0 )
            {
                break;
            }

            threadinfo * pthreadinfo = &(pthreadinfos[ threadIndex ]);

            pthread_mutex_lock( &pthreadinfo->plock );
            if ( pthreadinfo->status == idle )
            {
                POMAINT_TRACE_VERBOSE2( 3, "Dispatched LotID : ", strEventQueueSeq[ eventQueueIndex ].lotID );

                strcpy( pthreadinfo->lotID,      strEventQueueSeq[ eventQueueIndex ].lotID      );
                strcpy( pthreadinfo->updateTime, strEventQueueSeq[ eventQueueIndex ].updateTime );
                pthreadinfo->keepCount = keepCount;
                pthreadinfo->status    = busy;
                pthread_cond_signal( &pthreadinfo->psig );    //wakeup a worker thread
                eventQueueCount--;
                eventQueueIndex++;
            }
            pthread_mutex_unlock( &pthreadinfo->plock );
        }

    }

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::EventDrivenSubLotTypeProcess", "END" );
    return RC_OK;
}

//------------------------------------------------------------------------
//
//   threadFunc
//
//  Input  Parameter
//              void *param
//
//  Output Parameter
//              none
//
//  Return Code
//              void
//
//------------------------------------------------------------------------
void threadFunc( void *param )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadFunc", "START" );

    threadinfo *pthreadinfo = (threadinfo*)param;
    int rc;
    CORBA::Long sqlcode = 0;

    //----------------------------------
    // Initialize main thread SQL context
    //----------------------------------
    rc = InitializeSqlContext( &(pthreadinfo->ctx), &(pthreadinfo->dbConnectFlag) );
    if (rc != RC_OK )
    {
        pthread_mutex_lock( &pthreadinfo->plock );
        pthreadinfo->status = error;
        pthread_mutex_unlock( &pthreadinfo->plock );
        POMAINT_EVENT_LOG1( "", "", 0, getMessage( rc ) );
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadFunc", "END" );
        return;
    }

    pthread_mutex_lock( &pthreadinfo->plock );
    pthreadinfo->status = idle;

    while ( !fEndOfProcess )
    {
        //----------------------------------
        //Wait for Request from Main thread.
        //----------------------------------
        POMAINT_TRACE_VERBOSE1( 2, "wait for signal" );
        pthread_cond_wait( &pthreadinfo->psig, &pthreadinfo->plock ) ;
        if( pthreadinfo->status != busy )
        {
            continue;
        }
        pthread_mutex_unlock( &pthreadinfo->plock );
        POMAINT_TRACE_VERBOSE1( 2, "signal received." );
        //dispatched...
        POMAINT_TRACE_VERBOSE2( 3, "Request LotID : ", pthreadinfo->lotID );

        //----------------------------------
        // Worker thread PO delete function
        //----------------------------------
        threadPODeleteFunc( pthreadinfo );

        //----------------------------------
        //change to idle state
        //----------------------------------
        pthread_mutex_lock( &pthreadinfo->plock );
        pthreadinfo->status    = idle;
        pthreadinfo->lotID[0]  = 0;

        //----------------------------------
        //Wakeup MainThread
        //----------------------------------
        pthread_mutex_lock( &lock );
        notify_count++;
        pthread_cond_signal( &sig );
        pthread_mutex_unlock( &lock );
    }

    pthreadinfo->status = stop;
    pthread_mutex_unlock( &pthreadinfo->plock );

    //----------------------------------
    // Cleanup main thread SQL context
    //----------------------------------
    rc = CleanupSqlContext( &(pthreadinfo->ctx), &(pthreadinfo->dbConnectFlag) );
    if (rc != RC_OK )
    {
        POMAINT_EVENT_LOG1( "", pthreadinfo->lotID, rc, getMessage( rc ) );
    }

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadFunc", "END" );

    return;
}

//------------------------------------------------------------------------
//
//   threadPODeleteFunc
//
//  Input  Parameter
//              threadinfo *pthreadinfo
//
//  Output Parameter
//              none
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void threadPODeleteFunc( threadinfo *pthreadinfo )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "START" );

    CORBA::Long rc;
    CORBA::Long sqlcode = 0;

    if ( !pthreadinfo->dbConnectFlag )
    {
        //----------------------------------
        // Connect DataBase
        //----------------------------------
        rc = ConnectDataBase();
        if(rc != RC_OK )
        {
            POMAINT_EVENT_LOG1( "", pthreadinfo->lotID, rc, getMessage( rc ) );
            POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
            return;
        }
        else
        {
            pthreadinfo->dbConnectFlag = 1;
        }
    }

    //----------------------------------
    // Get current DB timestamp
    //----------------------------------
    char currentTimeStamp[64];
    sqlcode = GetTimeStamp( currentTimeStamp );
    if ( sqlcode != 0 )
    {
        CHECK_DB_CONNECTION_ERROR( "", pthreadinfo->lotID, getMessage( MSG_GET_CURRENT_TIMESTAMP_ERROR ), sqlcode, pthreadinfo->dbConnectFlag );
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
        return;
    }

    //----------------------------------
    // Update Event records
    //----------------------------------
    sqlcode = UpdateEventUpdateTime( currentTimeStamp, pthreadinfo->lotID, pthreadinfo->updateTime );
    if ( sqlcode != 0 )
    {
        RollBackDataBase();
        CHECK_DB_CONNECTION_ERROR( "", pthreadinfo->lotID, getMessage( MSG_UPDATE_EVENT_TIMESTAMP_ERROR ), sqlcode, pthreadinfo->dbConnectFlag );
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
        return;
    }

    sqlcode = DeleteOldEvent( currentTimeStamp, pthreadinfo->lotID );
    if ( sqlcode != 0 )
    {
        RollBackDataBase();
        CHECK_DB_CONNECTION_ERROR( "", pthreadinfo->lotID, getMessage( MSG_DELETE_OLD_EVENT_ERROR ), sqlcode, pthreadinfo->dbConnectFlag );
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
        return;
    }

    CommitDataBase();

    //----------------------------------
    // Get Lot detail information
    //----------------------------------
    pomaintLotInf strLotInf;
    sqlcode = GetLotInformation( pthreadinfo->lotID, strLotInf );
    if ( sqlcode != 0 )
    {
        if ( sqlcode == 100 )
        {
            POMAINT_EVENT_LOG1( "", pthreadinfo->lotID, sqlcode, getMessage( MSG_NOT_EXIST_LOT_INF ) );

            sqlcode = DeleteEvent( currentTimeStamp, pthreadinfo->lotID );
            if ( sqlcode != 0 )
            {
                RollBackDataBase();
                CHECK_DB_CONNECTION_ERROR( "", pthreadinfo->lotID, getMessage( MSG_DELETE_EVENT_ERROR ), sqlcode, pthreadinfo->dbConnectFlag );
                POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
                return;
            }
            CommitDataBase();
        }
        else
        {
            CHECK_DB_CONNECTION_ERROR( "", pthreadinfo->lotID, getMessage( MSG_GET_LOT_INF_ERROR ), sqlcode, pthreadinfo->dbConnectFlag );
        }
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
        return;
    }

    //----------------------------------
    // Parent lot exist
    //----------------------------------
    if ( gb_InactiveEnabled && CIMFWStrLen( strLotInf.splitLotID ) > 0 )
    {
        //----------------------------------
        // Get Parent lot detail information
        //----------------------------------
        pomaintLotInf strParentLotInf;
        sqlcode = GetLotInformation( strLotInf.splitLotID, strParentLotInf );
        if ( sqlcode != 0 )
        {
            if ( sqlcode == 100 )
            {
                POMAINT_TRACE_VERBOSE2( 2, "There exists no parent lot information lot ID : ", strLotInf.splitLotID );
            }
            else
            {
                CHECK_DB_CONNECTION_ERROR( "", pthreadinfo->lotID, getMessage( MSG_GET_PARENT_LOT_INF_ERROR ), sqlcode, pthreadinfo->dbConnectFlag );
                POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
                return;
            }
        }
        else
        {
            // Parent lot is inactive
            if ( CIMFWStrCmp( strParentLotInf.lotState,         LOT_STATE_SHIPPED  ) == 0 ||
                 CIMFWStrCmp( strParentLotInf.lotFinishedState, LOT_STATE_SCRAPPED ) == 0 ||
                 CIMFWStrCmp( strParentLotInf.lotFinishedState, LOT_STATE_EMPTIED  ) == 0 ||
                 CIMFWStrCmp( strParentLotInf.lotFinishedState, LOT_STATE_STACKED  ) == 0 )
            {
                //----------------------------------
                // Parent lot event queue put
                //----------------------------------
                sqlcode = InsertEventQueue( strParentLotInf.lotID, strParentLotInf.subLotType );
                if ( sqlcode != 0 )
                {
                    CHECK_DB_CONNECTION_ERROR( "", pthreadinfo->lotID, getMessage( MSG_PUT_PARENT_LOT_EVENT_ERROR ), sqlcode, pthreadinfo->dbConnectFlag );
                    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
                    return;
                }
                CommitDataBase();
            }
        }
    }

    //----------------------------------
    // PO delete main process
    //----------------------------------
    rc = PODeleteProcess( currentTimeStamp, strLotInf, pthreadinfo->keepCount );
    if ( rc == RC_DATABASE_CONNECT_ERROR )
    {
        // DB disconnection
        pthreadinfo->dbConnectFlag = 0;
    }

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::threadPODeleteFunc", "END" );
}

//------------------------------------------------------------------------
//
//   MaintenanceProcess
//
//  Input  Parameter
//              none
//
//  Output Parameter
//              none
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void MaintenanceProcess()
{
    POMAINT_FUNCTION_TRACE_ENTRY( 2, "POMaintenanceProgram::MaintenanceProcess" );

    CORBA::Long rc      = 0;
    CORBA::Long sqlcode = 0;

    //----------------------------------
    // Connect DataBase
    //----------------------------------
    rc = ConnectDataBase();
    if ( rc != RC_OK )
    {
        POMAINT_EVENT_LOG1( "", "", rc, getMessage( rc ) );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::MaintenanceProcess" )
        return;
    }

    // Specified Sub lot Type
    if ( !gb_AllSubLotTypeEnabled )
    {
        //----------------------------------
        // Specified Sub lot Type loop
        //----------------------------------
        int inputFileCount = strInputFileLineSeq.length();
        for ( int inputFileIndex = 0; inputFileIndex < inputFileCount; inputFileIndex++ )
        {
            if ( fEndOfProcess )
            {
                break;
            }

            if ( strInputFileLineSeq[inputFileIndex].keepCount == -1 )
            {
                POMAINT_TRACE_VERBOSE2( 2, "Sub Lot Type which is not target for deletion. Sub Lot Type : ", strInputFileLineSeq[inputFileIndex].subLotType );
                continue;
            }

            rc = MaintenanceSubLotTypeProcess( strInputFileLineSeq[inputFileIndex].subLotType, strInputFileLineSeq[inputFileIndex].keepCount );
            if ( rc == RC_DATABASE_CONNECT_ERROR )
            {
                // Exit Specified Sub lot Type loop
                break;
            }
        } // end of Specified Sub lot Type loop
    }
    // All Sub Lot Type
    else
    {
        //----------------------------------
        // Get all Sub Lot Type
        //----------------------------------
        stringSequence subLotTypeSeq;
        sqlcode = GetAllSubLotTypes( subLotTypeSeq );
        if ( sqlcode == 0 )
        {
            int subLotTypeCount = subLotTypeSeq.length();
            for ( int subLotTypeIndex = 0; subLotTypeIndex < subLotTypeCount; subLotTypeIndex++ )
            {
                if ( fEndOfProcess )
                {
                    break;
                }

                //----------------------------------
                // Get Keep Count
                //----------------------------------
                int keepCount = GetKeepCount( subLotTypeSeq[subLotTypeIndex] );
                if ( keepCount == -1 )
                {
                    POMAINT_TRACE_VERBOSE2( 2, "Sub Lot Type which is not target for deletion. Sub Lot Type : ", subLotTypeSeq[subLotTypeIndex] );
                    continue;
                }

                rc = MaintenanceSubLotTypeProcess( subLotTypeSeq[subLotTypeIndex], keepCount );
                if ( rc == RC_DATABASE_CONNECT_ERROR )
                {
                    // Exit Sub lot Type loop
                    break;
                }
            } // end of Sub lot Type loop
        }
    }

    //----------------------------------
    // Disconnect DataBase
    //----------------------------------
    rc = DisConnectDataBase();
    if ( rc != RC_OK )
    {
        POMAINT_EVENT_LOG1( "", "", rc, getMessage( rc ) );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::MaintenanceProcess" )
        return;
    }

    POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::MaintenanceProcess" )
}

//------------------------------------------------------------------------
//
//   MaintenanceSubLotTypeProcess
//
//  Input  Parameter
//              const char* subLotType
//              const int keepCount
//
//  Output Parameter
//              none
//
//  Return Code
//              RC_OK
//              RC_DATABASE_CONNECT_ERROR
//              RC_SYSTEM_ERROR
//
//------------------------------------------------------------------------
CORBA::Long MaintenanceSubLotTypeProcess( const char* subLotType, const int keepCount )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::MaintenanceSubLotTypeProcess", "START" );

    CORBA::Long rc      = 0;
    CORBA::Long sqlcode = 0;

    stringSequence lotIDSeq;

//DSIV00002757 add start
    if ( gb_ActiveEnabled )
    {
//DSIV00002757 add end
        //----------------------------------
        // Get active lot list
        //----------------------------------
        sqlcode = GetActiveLotsForMaintenance( subLotType, lotIDSeq );
        if ( sqlcode != 0 )
        {
            CHECK_SQL_ERROR_RETURN( "", "", "POMaintenanceProgram::MaintenanceSubLotTypeProcess", getMessage( MSG_GET_ACTIVE_LOT_ERROR ), sqlcode );
        }
        else
        {
            //----------------------------------
            // Target lot loop
            //----------------------------------
            CORBA::Long lotIDCount = lotIDSeq.length();
            for ( CORBA::Long lotIDIndex = 0; lotIDIndex < lotIDCount; lotIDIndex++ )
            {
                if ( fEndOfProcess )
                {
                    break;
                }

                char *lotID = lotIDSeq[lotIDIndex];

                rc = MaintenanceLotProcess( subLotType, keepCount, lotID );
                if ( rc == RC_DATABASE_CONNECT_ERROR )
                {
                    break;
                }
            } // end of target lot loop
        }
//DSIV00002757 add start
    }
//DSIV00002757 add end

    //----------------------------------
    // Get DB current timestamp
    //----------------------------------
    char currentTimeStamp[64];
    sqlcode = GetTimeStamp( currentTimeStamp );
    if ( sqlcode != 0 )
    {
        CHECK_SQL_ERROR_RETURN( "", "", "POMaintenanceProgram::MaintenanceSubLotTypeProcess", getMessage( MSG_GET_CURRENT_TIMESTAMP_ERROR ), sqlcode );
    }

    if ( fEndOfProcess )
    {
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::MaintenanceSubLotTypeProcess", "END" );
        return RC_OK;
    }

//DSIV00002757 add start
    if ( gb_InactiveEnabled )
    {
//DSIV00002757 add end
        //----------------------------------
        // Get inactive lot list
        //----------------------------------
        sqlcode = GetInactiveLotsForMaintenance( currentTimeStamp, subLotType, lotIDSeq );
        if ( sqlcode != 0 )
        {
            CHECK_SQL_ERROR_RETURN( "", "", "POMaintenanceProgram::MaintenanceSubLotTypeProcess", getMessage( MSG_GET_INACTIVE_LOT_ERROR ), sqlcode );
        }
        else
        {
            //----------------------------------
            // Target lot loop
            //----------------------------------
            CORBA::Long lotIDCount = lotIDSeq.length();
            for ( CORBA::Long lotIDIndex = 0; lotIDIndex < lotIDCount; lotIDIndex++ )
            {
                if ( fEndOfProcess )
                {
                    break;
                }

                char *lotID = lotIDSeq[lotIDIndex];

                rc = MaintenanceLotProcess( subLotType, keepCount, lotID );
                if ( rc == RC_DATABASE_CONNECT_ERROR || rc == RC_EXIT_PROGRAM )
                {
                    break;
                }
            } // end of target lot loop
        }
//DSIV00002757 add start
    }
//DSIV00002757 add end

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::MaintenanceSubLotTypeProcess", "END" );
    return RC_OK;
}

//------------------------------------------------------------------------
//
//   MaintenanceLotProcess
//
//  Input  Parameter
//              const char* subLotType
//              const int keepCount
//              const char* lotID
//
//  Output Parameter
//              none
//
//  Return Code
//              RC_OK
//              RC_DATABASE_CONNECT_ERROR
//              RC_SYSTEM_ERROR
//              RC_EXIT_PROGRAM
//
//------------------------------------------------------------------------
CORBA::Long MaintenanceLotProcess( const char* subLotType, const int keepCount, const char* lotID )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::MaintenanceLotProcess", "START" );

    CORBA::Long rc;
    CORBA::Long sqlcode = 0;

    //----------------------------------
    // Get Lot detail information
    //----------------------------------
    pomaintLotInf strLotInf;
    sqlcode = GetLotInformation( lotID, strLotInf );
    if ( sqlcode != 0 )
    {
        if ( sqlcode == 100 )
        {
            CHECK_SQL_ERROR_RETURN( subLotType, lotID, "POMaintenanceProgram::MaintenanceLotProcess", getMessage( MSG_NOT_EXIST_LOT_INF ), sqlcode );
        }
        else
        {
            CHECK_SQL_ERROR_RETURN( subLotType, lotID, "POMaintenanceProgram::MaintenanceLotProcess", getMessage( MSG_GET_LOT_INF_ERROR ), sqlcode );
        }
    }

    //----------------------------------
    // Get current DB timestamp
    //----------------------------------
    char currentTimeStamp[64];
    sqlcode = GetTimeStamp( currentTimeStamp );
    if ( sqlcode != 0 )
    {
        CHECK_SQL_ERROR_RETURN( subLotType, lotID, "POMaintenanceProgram::MaintenanceLotProcess", getMessage( MSG_GET_CURRENT_TIMESTAMP_ERROR ), sqlcode );
    }

    //----------------------------------
    // PO delete main process
    //----------------------------------
    rc = PODeleteProcess( currentTimeStamp, strLotInf, keepCount );
    if ( rc != RC_OK )
    {
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::MaintenanceLotProcess", "END" );
        return rc;
    }

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::MaintenanceLotProcess", "END" );

    return RC_OK;
}

//------------------------------------------------------------------------
//
//   PODeleteProcess
//
//  Input  Parameter
//              const char* currentTimeStamp
//              const pomaintLotInf& strLotInf
//              const int specifiedKeepCount
//
//  Output Parameter
//              none
//
//  Return Code
//              RC_OK
//              RC_DATABASE_CONNECT_ERROR
//              RC_SYSTEM_ERROR
//              RC_EXIT_PROGRAM
//
//------------------------------------------------------------------------
CORBA::Long PODeleteProcess( const char* currentTimeStamp, const pomaintLotInf& strLotInf, const int specifiedKeepCount )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::PODeleteProcess", "START" );

    CORBA::Long rc;
    CORBA::Long sqlcode = 0;

    POMAINT_TRACE_VERBOSE2( 3, "PODeleteProcess LotID : ", strLotInf.lotID );

    int keepCount = specifiedKeepCount;

    // Keep Count is not specified
    if ( keepCount == 0 )
    {
        //----------------------------------
        // Get Keep Count
        //----------------------------------
        keepCount = GetKeepCount( strLotInf.subLotType );
    }

    // The lot which is not target for deletion
    if ( keepCount == -1 )
    {
        POMAINT_TRACE_VERBOSE2( 2, "The lot which is not target for deletion. keepCount : ", keepCount );
        if ( gb_EventDrivenEnabled )
        {
            sqlcode = DeleteEvent( currentTimeStamp, strLotInf.lotID );
            if ( sqlcode != 0 )
            {
                RollBackDataBase();
                CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_DELETE_EVENT_ERROR ), sqlcode );
            }
            CommitDataBase();
        }
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::PODeleteProcess", "END" );
        return RC_OK;
    }

    //----------------------------------
    // Lot State
    //----------------------------------
    invoker_lotstate lotState = active;
    if ( CIMFWStrCmp( strLotInf.lotState, LOT_STATE_SHIPPED ) == 0 )
    {
        lotState = shipped;
    }
    else if ( CIMFWStrCmp( strLotInf.lotFinishedState, LOT_STATE_SCRAPPED ) == 0 )
    {
        lotState = scrapped;
    }
    else if ( CIMFWStrCmp( strLotInf.lotFinishedState, LOT_STATE_EMPTIED ) == 0 )
    {
        lotState = emptied;
    }
    else if ( CIMFWStrCmp( strLotInf.lotFinishedState, LOT_STATE_STACKED ) == 0 )
    {
        lotState = stacked;
    }

//DSIV00002757    //----------------------------------
//DSIV00002757    // Check Lot state and POMAINT_INACTIVE_ENABLED setting
//DSIV00002757    //----------------------------------
//DSIV00002757    if ( !gb_InactiveEnabled && lotState != active )
    //----------------------------------                      //DSIV00002757
    // Check Lot state and enabled settings                   //DSIV00002757
    //----------------------------------                      //DSIV00002757
    if ( ( !gb_ActiveEnabled   && lotState == active ) ||     //DSIV00002757
         ( !gb_InactiveEnabled && lotState != active )  )     //DSIV00002757
    {
        POMAINT_TRACE_VERBOSE2( 2, "The lot which is not target for deletion. lotState : ", LotStateStr[lotState] );
        if ( gb_EventDrivenEnabled )
        {
            sqlcode = DeleteEvent( currentTimeStamp, strLotInf.lotID );
            if ( sqlcode != 0 )
            {
                RollBackDataBase();
                CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_DELETE_EVENT_ERROR ), sqlcode );
            }
            CommitDataBase();
        }
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::PODeleteProcess", "END" );
        return RC_OK;
    }

    //----------------------------------
    // Check PO reserve period of Shipped, Scrapped and Stacked lot
    //----------------------------------
    CORBA::Boolean periodNotPassedFlag = FALSE;

    // Shipped Lot, Scrapped Lot or Stacked Lot
    if ( lotState == shipped || lotState == scrapped || lotState == stacked )
    {
        periodNotPassedFlag = CheckInactiveLotPeriodNotPassed( lotState, strLotInf.claimTime, currentTimeStamp );
    }

    CORBA::Boolean inactiveLotFlag = FALSE;

    //----------------------------------
    // Check Inactive Lot or Active Lot
    //----------------------------------
    if ( lotState != active && !periodNotPassedFlag )
    {
        // Inactive Lot
        inactiveLotFlag = TRUE;

        if ( gb_EventDrivenEnabled || CIMFWStrCmp( gb_Option, "-e" ) == 0 )
        {
            //----------------------------------
            // Delete PO from backup PO list
            //----------------------------------
            sqlcode = DeleteBackupPoList( strLotInf.pfxKey );
            if ( sqlcode != 0 && sqlcode != 100 )
            {
                RollBackDataBase();
                CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_DELETE_BACKUPPOLIST_PO_ERROR ), sqlcode );
            }
            else if ( sqlcode == 0 )
            {
                CommitDataBase();
                POMAINT_EVENT_LOG1( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_BACKUPPOLIST_PO ) ) ;
            }
        }
        else
        {
//DSIV00002757            POMAINT_EVENT_LOG1( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_BACKUPPOLIST_PO ) ) ;
//DSIV00002757 add start
            //----------------------------------
            // Backup PO list exist check
            //----------------------------------
            CORBA::Boolean existBackupPOListFlag = FALSE;
            sqlcode = ExistCheckBackupPoList( strLotInf.pfxKey, existBackupPOListFlag );
            if ( sqlcode != 0 )
            {
                CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_NOT_EXIST_BACKUP_PO_LIST_ERROR ), sqlcode );
            }
            else if ( existBackupPOListFlag )
            {
                POMAINT_EVENT_LOG1( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_BACKUPPOLIST_PO ) ) ;
            }
//DSIV00002757 add end
        }
    }

    //----------------------------------
    // Get latest PO SeqNo
    //----------------------------------
    int latestSeqNo;
    sqlcode = GetLatestPOSeqNo( strLotInf.pfxKey, &latestSeqNo );
    if ( sqlcode != 0 )
    {
        if ( sqlcode == 100 )
        {
            POMAINT_EVENT_LOG1( strLotInf.subLotType, strLotInf.lotID, sqlcode, getMessage( MSG_NOT_EXIST_PO_INF ) );
            POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::PODeleteProcess", "END" );
            return RC_OK;
        }
        else
        {
            CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_GET_LATEST_PO_ERROR ), sqlcode );
        }
    }

    //----------------------------------
    // Calculate target PO SeqNo
    //----------------------------------
    int targetSeqNo = latestSeqNo - keepCount;
    POMAINT_TRACE_VERBOSE2( 3, "targetSeqNo : ", targetSeqNo );

    CORBA::Long lotExitCount   = 0;
    CORBA::Long lotCommitCount = 0;

    CORBA::Boolean eventDelFlag       = TRUE;
    CORBA::Boolean commitRequiredFlag = FALSE;

    pomaintPOInfSequence strPOInfSeq;
    int previousSeqNo = -1;

    while ( !fEndOfProcess )
    {
//DSIV00002757 add start
        if ( 0 >= targetSeqNo )
        {
            // Exit while loop
            break;
        }

        //----------------------------------
        // Inactive lot with which the period has not passed
        //----------------------------------
        if ( lotState != active && periodNotPassedFlag )
        {
            // Event does not delete
            eventDelFlag = FALSE;
        }
//DSIV00002757 add end

        //----------------------------------
        // Get target PO list
        //----------------------------------
//DSIV00002757        sqlcode = GetTargetPOs( inactiveLotFlag, strLotInf.pfxObj, strLotInf.pfxKey, previousSeqNo, targetSeqNo, strPOInfSeq );
        sqlcode = GetTargetPOs( strLotInf.pfxObj, strLotInf.pfxKey, previousSeqNo, targetSeqNo, strPOInfSeq );  //DSIV00002757
        if ( sqlcode != 0 )
        {
            CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_GET_TARGET_PO_ERROR ), sqlcode );
        }

        CORBA::Long poInfCount = strPOInfSeq.length();

        if ( poInfCount == 0)
        {
            // Exit while loop
            break;
        }

        //----------------------------------
        // Target PO loop
        //----------------------------------
        for ( CORBA::Long poInfIndex = 0; poInfIndex < poInfCount; poInfIndex++ )
        {
            pomaintPOInf &strPOInf = strPOInfSeq[poInfIndex];

            //----------------------------------
            // Exit PO maintenance program
            //----------------------------------
            if ( fEndOfProcess )
            {
                RollBackDataBase();
                POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::PODeleteProcess", "END" );
                return RC_EXIT_PROGRAM;
            }

            //----------------------------------
            // Exit count check
            //----------------------------------
            if ( gb_ExitCount != 0 && lotExitCount >= gb_ExitCount )
            {
                POMAINT_TRACE_VERBOSE1( 2, "Exit count over." );
                // Event does not delete
                eventDelFlag = FALSE;
                // Exit target PO loop
                break;
            }

            //----------------------------------
            // Get PFX keys for active child lot
            //----------------------------------
            stringSequence childPfxKeySeq;
            sqlcode = GetPfxKeysForActiveChildLot( currentTimeStamp, strPOInf.poObj, strLotInf.pfxKey, childPfxKeySeq );
            if ( sqlcode != 0 )
            {
                POMAINT_TRACE_VERBOSE2( 2, getMessage( MSG_GET_ACTIVE_CHILD_LOT_PFX_ERROR ), strPOInf.seqNo );
                CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_GET_ACTIVE_CHILD_LOT_PFX_ERROR ), sqlcode );

                // To the next PO.
                continue;
            }

//DSIV00002757 add start
            CORBA::Long currentRefCnt = strPOInf.refCnt;

            CORBA::Boolean delDCItemFlag = FALSE;  //DSN000015229
            CORBA::Boolean delDCFlag    = FALSE;
            CORBA::Boolean delARPFlag   = FALSE;
            CORBA::Boolean delAPRFlag   = FALSE;
            CORBA::Boolean delOTHERFlag = FALSE;
//DSIV00002757 add end

            //----------------------------------
            // There is no active child lot at inactive lot
            //----------------------------------
            if ( inactiveLotFlag && childPfxKeySeq.length() == 0 )
            {
                POMAINT_TRACE_VERBOSE2( 2, getMessage( MSG_DELETE_FULLSET_PO ), strPOInf.seqNo );

                if ( gb_EventDrivenEnabled || CIMFWStrCmp( gb_Option, "-e" ) == 0 )
                {
                    //----------------------------------
                    // PO full set deletion
                    //----------------------------------
//DSIV00002757 add start
                    delDCItemFlag = TRUE;  //DSN000015229
                    delDCFlag    = TRUE;
                    delARPFlag   = TRUE;
                    delAPRFlag   = TRUE;
                    delOTHERFlag = TRUE;
//DSIV00002757 add end

//DSN000015229 add start
                    if ( lotState == emptied )
                    {
                        delDCItemFlag = FALSE;
                        delAPRFlag    = FALSE;

                        // Not deleted DC information or Assigned Process Resource information
                        if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_DC ) || !( strPOInf.refCnt & REF_CNT_DELETE_COMP_APR ) )
                        {
                            //----------------------------------
                            // Get PO detail information
                            //----------------------------------
                            pomaintPODetailInf strPODetailInf;
                            sqlcode = GetPODetailInformation( strPOInf.poObj, strPODetailInf );
                            if ( sqlcode != 0 )
                            {
                                CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_GET_PO_DETAIL_INF_ERROR ), sqlcode );
                            }
                            // PO detail are got
                            else
                            {
                                // Target PFX for check
                                stringSequence checkPfxKeySeq = childPfxKeySeq;

                                // PFX of parent lot is included in the target for check
                                CORBA::Long checkPfxKeyCount = checkPfxKeySeq.length();
                                checkPfxKeySeq.length( checkPfxKeyCount + 1 );
                                checkPfxKeySeq[checkPfxKeyCount] = strLotInf.pfxKey;

                                // Not deleted DC information
                                if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_DC ) )
                                {
                                    //----------------------------------
                                    // The PO is not a not-performed delta's pre operation for MainPD
                                    //----------------------------------
                                    CORBA::Boolean notPerformPostOpeFlag = FALSE;
                                    sqlcode = CheckDeltaOperationForMainPD( strPOInf, strPODetailInf, checkPfxKeySeq, notPerformPostOpeFlag );
                                    if ( sqlcode != 0 )
                                    {
                                        CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_MAINPD_DELTA_ERROR ), sqlcode );
                                    }
                                    // Not-performed delta's pre operation does not exist
                                    else if ( !notPerformPostOpeFlag )
                                    {
                                        //----------------------------------
                                        // The PO is not a not-performed delta's pre operation for ModulePD
                                        //----------------------------------
                                        sqlcode = CheckDeltaOperationForModulePD( strPOInf, strPODetailInf, checkPfxKeySeq, notPerformPostOpeFlag );
                                        if ( sqlcode != 0 )
                                        {
                                            CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_MODULEPD_DELTA_ERROR ), sqlcode );
                                        }
                                        // Not-performed delta's pre operation does not exist
                                        else if ( !notPerformPostOpeFlag )
                                        {
                                            // Delete flag ON
                                            delDCItemFlag = TRUE;
                                        }
                                    }
                                }

                                // Not deleted Assigned Process Resource information
                                if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_APR ) )
                                {
                                    //----------------------------------
                                    // The PO is not a not-performed Corresponding's pre operation for MainPD
                                    //----------------------------------
                                    CORBA::Boolean notPerformPostOpeFlag = FALSE;
                                    sqlcode = CheckCorrespondingOperationForMainPD( strPOInf, strPODetailInf, checkPfxKeySeq, notPerformPostOpeFlag );
                                    if ( sqlcode != 0 )
                                    {
                                        CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_MAINPD_CORRESPOND_ERROR ), sqlcode );
                                    }
                                    // Not-performed Corresponding's pre operation does not exist
                                    else if ( !notPerformPostOpeFlag )
                                    {
                                        //----------------------------------
                                        // The PO is not a not-performed Corresponding's pre operation for ModulePD
                                        //----------------------------------
                                        sqlcode = CheckCorrespondingOperationForModulePD( strPOInf, strPODetailInf, checkPfxKeySeq, notPerformPostOpeFlag );
                                        if ( sqlcode != 0 )
                                        {
                                            CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_MODULEPD_CORRESPOND_ERROR ), sqlcode );
                                        }
                                        // Not-performed Corresponding's pre operation does not exist
                                        else if ( !notPerformPostOpeFlag )
                                        {
                                            // Delete flag ON
                                            delAPRFlag = TRUE;
                                        }
                                    }
                                }
                            }
                        }
                    }
//DSN000015229 add end

//DSIV00002757                    sqlcode = DeleteFullSetPOInformation( strPOInf.poKey );
//DSN000015229                    sqlcode = DeleteFullSetPOInformation( strPOInf.poKey, delDCFlag, delARPFlag, delAPRFlag, delOTHERFlag );  //DSIV00002757
                    sqlcode = DeleteFullSetPOInformation( strPOInf.poKey, delDCItemFlag, delDCFlag, delARPFlag, delAPRFlag, delOTHERFlag );  //DSN000015229
                    if ( sqlcode != 0 )
                    {
                        RollBackDataBase();
                        CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_DELETE_FULLSET_PO_ERROR ), sqlcode );
                    }

//DSIV00002757                    strPOInf.refCnt = REF_CNT_DELETE_COMP_INACTIVE_PO_ALL;
                    strPOInf.refCnt = REF_CNT_DELETE_COMP_PO_CHILD_ALL;  //DSIV00002757

                    //----------------------------------
                    // Update PO REF_CNT
                    //----------------------------------
                    sqlcode = UpdatePORefCnt( strPOInf.poKey, strPOInf.refCnt );
                    if ( sqlcode != 0 )
                    {
                        RollBackDataBase();
                        CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_UPDATE_REFCNT_ERROR ), sqlcode );
                    }
                    POMAINT_TRACE_VERBOSE2( 2, "Update PO REF_CNT. PO's No : ", strPOInf.seqNo );

                    commitRequiredFlag = TRUE;
                    lotExitCount++;
                    lotCommitCount++;

                    //----------------------------------
                    // Commit count check
                    //----------------------------------
                    if ( lotCommitCount >= gb_CommitCount )
                    {
                        CommitDataBase();
                        commitRequiredFlag = FALSE;
                        lotCommitCount = 0;
                        POMAINT_EVENT_LOG1( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_PO_INF ) ) ;
                    }
                }
                else
                {
                    POMAINT_EVENT_LOG2( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_FULLSET_PO ), strPOInf.seqNo ) ;
                }

                // To the next PO.
                continue;
            }

//DSIV00002757            //----------------------------------
//DSIV00002757            // Inactive lot with which the period has not passed
//DSIV00002757            //----------------------------------
//DSIV00002757            if ( lotState != active && periodNotPassedFlag )
//DSIV00002757            {
//DSIV00002757                // There is no active child lot
//DSIV00002757                if ( childPfxKeySeq.length() == 0 )
//DSIV00002757                {
//DSIV00002757                    // Event does not delete
//DSIV00002757                    eventDelFlag = FALSE;
//DSIV00002757                }
//DSIV00002757            }

//DSIV00002757            //----------------------------------
//DSIV00002757            // Deletion of all active PO child tables is already finished
//DSIV00002757            //----------------------------------
//DSIV00002757            POMAINT_TRACE_VERBOSE2( 3, "REF_CNT : ", strPOInf.refCnt );
//DSIV00002757            if ( ( strPOInf.refCnt & REF_CNT_DELETE_COMP_ACTIVE_PO_ALL ) == REF_CNT_DELETE_COMP_ACTIVE_PO_ALL )
//DSIV00002757            {
//DSIV00002757                POMAINT_TRACE_VERBOSE2( 2, "Deletion of all active PO child tables is already finished. PO's No : ", strPOInf.seqNo );
//DSIV00002757                // To the next PO.
//DSIV00002757                continue;
//DSIV00002757            }

            // Not deleted DC information
            if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_DC ) )
            {
                //----------------------------------
                // DC information does not exist check
                //----------------------------------
                CORBA::Boolean notExistFlag = FALSE;
                sqlcode = NotExistCheckDCInfo( strPOInf.poKey, notExistFlag );
                if ( sqlcode != 0 )
                {
                    CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_NOT_EXIST_DC_INF_ERROR ), sqlcode );
                }
                else if ( notExistFlag )
                {
                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_DC;
                }
            }

            // Not deleted Assigned Recipe Parameter information
            if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_ARP ) )
            {
                //----------------------------------
                // Assigned Recipe Parameter information does not exist check
                //----------------------------------
                CORBA::Boolean notExistFlag = FALSE;
                sqlcode = NotExistCheckAssignRecipeParmInfo( strPOInf.poKey, notExistFlag );
                if ( sqlcode != 0 )
                {
                    CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_NOT_EXIST_ARP_INF_ERROR ), sqlcode );
                }
                else if ( notExistFlag )
                {
                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_ARP;
                }
            }

            // Not deleted Assigned Process Resource information
            if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_APR ) )
            {
                //----------------------------------
                // Assigned Process Resource information does not exist check
                //----------------------------------
                CORBA::Boolean notExistFlag = FALSE;
                sqlcode = NotExistCheckAssignProcessResourceInfo( strPOInf.poKey, notExistFlag );
                if ( sqlcode != 0 )
                {
                    CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_NOT_EXIST_APR_INF_ERROR ), sqlcode );
                }
                else if ( notExistFlag )
                {
                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_APR;
                }
            }

            //----------------------------------
            // Finishing deletion of all active PO child tables
            //----------------------------------
//DSIV00002757            if ( ( strPOInf.refCnt & REF_CNT_DELETE_COMP_ACTIVE_PO_ALL ) == REF_CNT_DELETE_COMP_ACTIVE_PO_ALL )
//DSIV00002757            {
//DSIV00002757                POMAINT_TRACE_VERBOSE2( 2, "Finishing deletion of all active PO child tables. PO's No : ", strPOInf.seqNo );
//DSIV00002757 add start
            if ( ( strPOInf.refCnt & REF_CNT_DELETE_COMP_PO_CHILD_ALL ) == REF_CNT_DELETE_COMP_PO_CHILD_ALL )
            {
                POMAINT_TRACE_VERBOSE2( 2, "Finishing deletion of all PO child tables. PO's No : ", strPOInf.seqNo );
//DSIV00002757 add end

                if ( gb_EventDrivenEnabled || CIMFWStrCmp( gb_Option, "-e" ) == 0 )
                {
                    //----------------------------------
                    // Update PO REF_CNT
                    //----------------------------------
                    sqlcode = UpdatePORefCnt( strPOInf.poKey, strPOInf.refCnt );
                    if ( sqlcode != 0 )
                    {
                        RollBackDataBase();
                        CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_UPDATE_REFCNT_ERROR ), sqlcode );
                    }

                    commitRequiredFlag = TRUE;
                    lotExitCount++;
                    lotCommitCount++;

                    //----------------------------------
                    // Commit count check
                    //----------------------------------
                    if ( lotCommitCount >= gb_CommitCount )
                    {
                        CommitDataBase();
                        commitRequiredFlag = FALSE;
                        lotCommitCount = 0;
                        POMAINT_EVENT_LOG1( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_PO_INF ) ) ;
                    }
                }
                // To the next PO.
                continue;
            }

            //----------------------------------
            // Check keep count of active child lot
            //----------------------------------
            rc = CheckKeepCountOfActiveChildLot( childPfxKeySeq, strPOInf.seqNo, keepCount, strLotInf.subLotType, strLotInf.lotID );
            if ( rc != RC_OK )
            {
                // Not over
                if ( rc == RC_NOT_OVER_KEEPCOUNT )
                {
                    POMAINT_TRACE_VERBOSE2( 2, getMessage( rc ), strPOInf.seqNo );

                    // To the next PO.
                    continue;
                }
                // DB connection error
                else if ( rc == RC_DATABASE_CONNECT_ERROR )
                {
                    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::PODeleteProcess", "END" );
                    return rc;
                }
                else
                {
                    POMAINT_TRACE_VERBOSE2( 2, "Keep count of active child lot Check error. PO's No : ", strPOInf.seqNo );

                    // To the next PO.
                    continue;
                }
            }

//DSIV00002757            CORBA::Boolean delDCFlag  = FALSE;
//DSIV00002757            CORBA::Boolean delARPFlag = FALSE;
//DSIV00002757            CORBA::Boolean delAPRFlag = FALSE;
//DSIV00002757 add start
            delDCFlag    = FALSE;
            delARPFlag   = FALSE;
            delAPRFlag   = FALSE;
            delOTHERFlag = FALSE;

            // Not deleted other child tables information
            if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_OTHER ) )
            {
                // Delete flag ON
                delOTHERFlag = TRUE;
            }
//DSIV00002757 add end

            // Not deleted Assigned Recipe Parameter information
            if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_ARP ) )
            {
                // Delete flag ON
                delARPFlag = TRUE;
            }

            //---------------------------------------------------------------------------
            //  Deletion check of DC information and Assigned Process Resource information
            //---------------------------------------------------------------------------
            // Not deleted DC information  or  Not deleted Assigned Process Resource information
            if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_DC ) || !( strPOInf.refCnt & REF_CNT_DELETE_COMP_APR ) )
            {
                //----------------------------------
                // Get PO detail information
                //----------------------------------
                pomaintPODetailInf strPODetailInf;
                sqlcode = GetPODetailInformation( strPOInf.poObj, strPODetailInf );
                if ( sqlcode != 0 )
                {
                    CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_GET_PO_DETAIL_INF_ERROR ), sqlcode );
                }
                // PO detail are got
                else
                {
                    // Target PFX for check
                    stringSequence checkPfxKeySeq = childPfxKeySeq;

                    // Active Lot
                    if ( !inactiveLotFlag )
                    {
                        // PFX of parent lot is included in the target for check
                        CORBA::Long checkPfxKeyCount = checkPfxKeySeq.length();
                        checkPfxKeySeq.length( checkPfxKeyCount + 1 );
                        checkPfxKeySeq[checkPfxKeyCount] = strLotInf.pfxKey;
                    }

                    // Not deleted DC information
                    if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_DC ) )
                    {
                        CORBA::Boolean existDCEventFlag = FALSE;

                        // Active Lot
                        if ( !inactiveLotFlag )
                        {
                            //----------------------------------
                            // DC event exist check
                            //----------------------------------
                            sqlcode = ExistCheckDCEvent( strPOInf.poObj, existDCEventFlag );
                            if ( sqlcode != 0 )
                            {
                                CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_EXIST_DC_EVENT_ERROR ), sqlcode );
                            }
                        }

                        //   Inactive Lot    or ( Active Lot and DC event does not exist => Finishing DC history creation )
                        if ( inactiveLotFlag || ( !inactiveLotFlag && !existDCEventFlag ) )
                        {
                            //----------------------------------
                            // The PO is not a not-performed delta's pre operation for MainPD
                            //----------------------------------
                            CORBA::Boolean notPerformPostOpeFlag = FALSE;
                            sqlcode = CheckDeltaOperationForMainPD( strPOInf, strPODetailInf, checkPfxKeySeq, notPerformPostOpeFlag );
                            if ( sqlcode != 0 )
                            {
                                CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_MAINPD_DELTA_ERROR ), sqlcode );
                            }
                            // Not-performed delta's pre operation does not exist
                            else if ( !notPerformPostOpeFlag )
                            {
                                //----------------------------------
                                // The PO is not a not-performed delta's pre operation for ModulePD
                                //----------------------------------
                                sqlcode = CheckDeltaOperationForModulePD( strPOInf, strPODetailInf, checkPfxKeySeq, notPerformPostOpeFlag );
                                if ( sqlcode != 0 )
                                {
                                    CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_MODULEPD_DELTA_ERROR ), sqlcode );
                                }
                                // Not-performed delta's pre operation does not exist
                                else if ( !notPerformPostOpeFlag )
                                {
                                    // Delete flag ON
                                    delDCFlag = TRUE;
                                }
                            }
                        }
                    }

                    // Not deleted Assigned Process Resource information
                    if ( !( strPOInf.refCnt & REF_CNT_DELETE_COMP_APR ) )
                    {
                        //----------------------------------
                        // The PO is not a not-performed Corresponding's pre operation for MainPD
                        //----------------------------------
                        CORBA::Boolean notPerformPostOpeFlag = FALSE;
                        sqlcode = CheckCorrespondingOperationForMainPD( strPOInf, strPODetailInf, checkPfxKeySeq, notPerformPostOpeFlag );
                        if ( sqlcode != 0 )
                        {
                            CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_MAINPD_CORRESPOND_ERROR ), sqlcode );
                        }
                        // Not-performed Corresponding's pre operation does not exist
                        else if ( !notPerformPostOpeFlag )
                        {
                            //----------------------------------
                            // The PO is not a not-performed Corresponding's pre operation for ModulePD
                            //----------------------------------
                            sqlcode = CheckCorrespondingOperationForModulePD( strPOInf, strPODetailInf, checkPfxKeySeq, notPerformPostOpeFlag );
                            if ( sqlcode != 0 )
                            {
                                CHECK_SQL_DB_CONNECTION_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_CHECK_MODULEPD_CORRESPOND_ERROR ), sqlcode );
                            }
                            // Not-performed Corresponding's pre operation does not exist
                            else if ( !notPerformPostOpeFlag )
                            {
                                // Delete flag ON
                                delAPRFlag = TRUE;
                            }
                        }
                    }
                }
            } // end of [Deletion check of DC information and Assigned Process Resource information]

            //---------------------------------------------------------------------------
            //  Perform to delete or display candidate PO information
            //---------------------------------------------------------------------------
            if ( gb_EventDrivenEnabled || CIMFWStrCmp( gb_Option, "-e" ) == 0 )    //Delete option is specified.
            {
//DSIV00002757                //---------------------------------------------------------------------------
//DSIV00002757                //  Perform to delete collected data candidate PO information
//DSIV00002757                //---------------------------------------------------------------------------
//DSIV00002757                if ( delDCFlag )
//DSIV00002757                {
//DSIV00002757                    sqlcode = DeleteDCInformation( strPOInf.poKey );
//DSIV00002757                    if ( sqlcode != 0 )
//DSIV00002757                    {
//DSIV00002757                        RollBackDataBase();
//DSIV00002757                        CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::DeleteDCInformation", getMessage( MSG_DELETE_PO_DC_ERROR ), sqlcode );
//DSIV00002757                    }
//DSIV00002757                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_DC;
//DSIV00002757                }
//DSIV00002757
//DSIV00002757                //----------------------------------------------------------------------------------
//DSIV00002757                //  Perform to delete Assign Recipe Parameter candidate PO information
//DSIV00002757                //----------------------------------------------------------------------------------
//DSIV00002757                if ( delARPFlag )
//DSIV00002757                {
//DSIV00002757                    sqlcode = DeleteAssignRecipeParmInformation( strPOInf.poKey );
//DSIV00002757                    if ( sqlcode != 0 )
//DSIV00002757                    {
//DSIV00002757                        RollBackDataBase();
//DSIV00002757                        CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::DeleteDCInformation", getMessage( MSG_DELETE_PO_ARP_ERROR ), sqlcode );
//DSIV00002757                    }
//DSIV00002757                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_ARP;
//DSIV00002757                }
//DSIV00002757
//DSIV00002757                //----------------------------------------------------------------------------------
//DSIV00002757                //  Perform to delete Assign Process Resource candidate PO information
//DSIV00002757                //----------------------------------------------------------------------------------
//DSIV00002757                if ( delAPRFlag )
//DSIV00002757                {
//DSIV00002757                    sqlcode = DeleteAssignProcessResourceInformation( strPOInf.poKey );
//DSIV00002757                    if ( sqlcode != 0 )
//DSIV00002757                    {
//DSIV00002757                        RollBackDataBase();
//DSIV00002757                        CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::DeleteDCInformation", getMessage( MSG_DELETE_PO_APR_ERROR ), sqlcode );
//DSIV00002757                    }
//DSIV00002757                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_APR;
//DSIV00002757                }
//DSIV00002757 add start
                //----------------------------------
                // PO full set deletion
                //----------------------------------
//DSN000015229                sqlcode = DeleteFullSetPOInformation( strPOInf.poKey, delDCFlag, delARPFlag, delAPRFlag, delOTHERFlag );
//DSN000015229 add start
                delDCItemFlag = delDCFlag;
                sqlcode = DeleteFullSetPOInformation( strPOInf.poKey, delDCItemFlag, delDCFlag, delARPFlag, delAPRFlag, delOTHERFlag );
//DSN000015229 add end
                if ( sqlcode != 0 )
                {
                    RollBackDataBase();
                    CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_DELETE_FULLSET_PO_ERROR ), sqlcode );
                }
                if ( delDCFlag )
                {
                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_DC;
                }
                if ( delARPFlag )
                {
                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_ARP;
                }
                if ( delAPRFlag )
                {
                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_APR;
                }
                if ( delOTHERFlag )
                {
                    strPOInf.refCnt |= REF_CNT_DELETE_COMP_OTHER;
                }

                if ( strPOInf.refCnt != currentRefCnt )
                {
//DSIV00002757 add end
                    //----------------------------------
                    // Update PO REF_CNT
                    //----------------------------------
                    sqlcode = UpdatePORefCnt( strPOInf.poKey, strPOInf.refCnt );
                    if ( sqlcode != 0 )
                    {
                        RollBackDataBase();
                        CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_UPDATE_REFCNT_ERROR ), sqlcode );
                    }
                    POMAINT_TRACE_VERBOSE2( 2, "Update PO REF_CNT. PO's No : ", strPOInf.seqNo );

                    commitRequiredFlag = TRUE;
                    lotExitCount++;
                    lotCommitCount++;

                    //----------------------------------
                    // Commit count check
                    //----------------------------------
                    if ( lotCommitCount >= gb_CommitCount )
                    {
                        CommitDataBase();
                        commitRequiredFlag = FALSE;
                        lotCommitCount = 0;
                        POMAINT_EVENT_LOG1( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_PO_INF ) );
                    }
//DSIV00002757 add start
                }
//DSIV00002757 add end
            }
            // Display candidate PO information.
            else
            {
                if ( delDCFlag )
                {
                    POMAINT_EVENT_LOG2( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_PO_DC ), strPOInf.seqNo ) ;
                }
                if ( delARPFlag )
                {
                    POMAINT_EVENT_LOG2( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_PO_ARP ), strPOInf.seqNo ) ;
                }
                if ( delAPRFlag )
                {
                    POMAINT_EVENT_LOG2( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_PO_APR ), strPOInf.seqNo ) ;
                }
//DSIV00002757 add start
                if ( delOTHERFlag )
                {
                    POMAINT_EVENT_LOG2( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_PO_OTHER ), strPOInf.seqNo ) ;
                }
//DSIV00002757 add end
            }
        } // end of Target PO loop

        // Finishing all target PO processes
        if ( poInfCount < DB_FETCH_COUNT_MAX_FOR_PO )
        {
            // Exit while loop
            break;
        }
        // Target PO remains
        else
        {
            // Last SeqNo is set to previous SeqNo
            previousSeqNo = strPOInfSeq[poInfCount - 1].seqNo;
        }
    } // end of while

//DSIV00002757 add start
    //----------------------------------
    // Exit PO maintenance program
    //----------------------------------
    if ( fEndOfProcess )
    {
        RollBackDataBase();
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::PODeleteProcess", "END" );
        return RC_EXIT_PROGRAM;
    }
//DSIV00002757 add end

    if ( gb_EventDrivenEnabled && ( lotState == active || eventDelFlag ) )
    {
        //----------------------------------
        // Event delete
        //----------------------------------
        sqlcode = DeleteEvent( currentTimeStamp, strLotInf.lotID );
        if ( sqlcode != 0 )
        {
            RollBackDataBase();
            CHECK_SQL_ERROR_RETURN( strLotInf.subLotType, strLotInf.lotID, "POMaintenanceProgram::PODeleteProcess", getMessage( MSG_DELETE_EVENT_ERROR ), sqlcode );
        }
        commitRequiredFlag = TRUE;
    }

    //----------------------------------
    // Commit required
    //----------------------------------
    if ( commitRequiredFlag )
    {
        CommitDataBase();
//DSIV00002757 add start
        if ( lotCommitCount > 0 )
        {
//DSIV00002757 add end
            POMAINT_EVENT_LOG1( strLotInf.subLotType, strLotInf.lotID, 0, getMessage( MSG_DELETE_PO_INF ) );
//DSIV00002757 add start
        }
//DSIV00002757 add end
    }

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::PODeleteProcess", "END" );

    return RC_OK;
}

//------------------------------------------------------------------------
//
//   startThreads
//
//  Input  Parameter
//              const int thread_count
//
//  Output Parameter
//              none
//
//  Return Code
//              0 : Normal end
//             -1 : Error end
//
//------------------------------------------------------------------------
int startThreads( const int thread_count )
{
    POMAINT_FUNCTION_TRACE_ENTRY( 2, "POMaintenanceProgram::startThreads" )

    int rc = 0;
    rc = pthread_mutex_init( &lock, NULL );
    if ( 0 != rc )
    {
        POMAINT_TRACE_VERBOSE2( 2, "initialize error! : rc = ", rc );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::startThreads" )
        return -1;
    }
    rc = pthread_cond_init( &sig, NULL );
    if ( 0 != rc )
    {
        POMAINT_TRACE_VERBOSE2( 2, "initialize error! : rc = ", rc );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::startThreads" )
        return -1;
    }

    if ( gb_ThreadCount <= 0 )
    {
        POMAINT_TRACE_VERBOSE1( 2, "Invalid Parameter!" );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::startThreads" )
        return -1;
    }

    pthreadinfos = new threadinfo[ (long)gb_ThreadCount ];
    if ( NULL == pthreadinfos )
    {
        POMAINT_TRACE_VERBOSE1( 2, "Allocate Thread information is failed!" );
        POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::startThreads" )
        return -1;
    }

    POMAINT_TRACE_VERBOSE2( 2, "Start thread x", gb_ThreadCount );

    for ( int i = 0 ; i < gb_ThreadCount; i++ )
    {
        threadinfo * pthreadinfo = &(pthreadinfos[ i ]);

        pthreadinfo->status = init;

        int rc = 0;
        rc += pthread_mutex_init( &(pthreadinfo->plock), NULL );
        POMAINT_TRACE_VERBOSE2( 2, "pthread_mutex_init : rc =", rc );
        rc += pthread_cond_init( &(pthreadinfo->psig), NULL );
        POMAINT_TRACE_VERBOSE2( 2, "pthread_cond_init : rc =", rc );
        rc += pthread_attr_init( &(pthreadinfo->pattr) );
        POMAINT_TRACE_VERBOSE2( 2, "pthread_attr_init : rc =", rc );
        rc += pthread_create( &(pthreadinfo->tid), &(pthreadinfo->pattr), (void*(*)(void*))threadFunc, (void*)pthreadinfo );
        POMAINT_TRACE_VERBOSE2( 2, "pthread_create : rc =", rc );

        if ( 0 != rc )
        {
            POMAINT_TRACE_VERBOSE1( 2, "Start thread error!" );
            POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::startThreads" )
            return -1;
        }
    }

    POMAINT_FUNCTION_TRACE_EXIT( 2, "POMaintenanceProgram::startThreads" )
    return 0;
}

//------------------------------------------------------------------------
//
//   get_specified_state_thread_count
//
//  Input  Parameter
//              const invoker_threadstatus status
//
//  Output Parameter
//              none
//
//  Return Code
//              int threadCount
//
//------------------------------------------------------------------------
int get_specified_state_thread_count( const invoker_threadstatus status )
{
    int count = 0;

    for( int i = 0 ; i < gb_ThreadCount; i++ )
    {
        threadinfo * pthreadinfo = &(pthreadinfos[ i ]);

        pthread_mutex_lock( &pthreadinfo->plock );
        if( pthreadinfo->status == status )
        {
            count++;
        }
        pthread_mutex_unlock( &pthreadinfo->plock );
    }

    return count;
}

//------------------------------------------------------------------------
//
//   wait_all_thread_start
//
//  Input  Parameter
//              none
//
//  Output Parameter
//              none
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void wait_all_thread_start( void )
{
    POMAINT_TRACE_VERBOSE1( 2, "Start waiting of all threads......" );
    while ( !fEndOfProcess )
    {
        int naThreadCount = get_specified_state_thread_count( init );
        if ( naThreadCount <= 0 )
        {
            break;
        }

        Pthread_cond_timedwait_sec( &sig, &lock, 1 );
    }
    POMAINT_TRACE_VERBOSE1( 2, "Start all threads." );
}

//------------------------------------------------------------------------
//
//   wait_all_thread_not_busy
//
//  Input  Parameter
//              none
//
//  Output Parameter
//              none
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void wait_all_thread_not_busy( void )
{
    POMAINT_TRACE_VERBOSE1( 2, "Completion waiting of all thread processes......" );
    while ( !fEndOfProcess )
    {
        int busyThreadCount = get_specified_state_thread_count( busy );
        if ( busyThreadCount <= 0 )
        {
            break;
        }

        //Wait for signal from worker threads
        pthread_mutex_lock( &lock );
        if( notify_count <= 0 )
        {
            Pthread_cond_timedwait_sec( &sig, &lock, 5 );
        }
        else
        {
            notify_count = 0;
        }
        pthread_mutex_unlock( &lock );
    }
    POMAINT_TRACE_VERBOSE1( 2, "Completion all thread processes." );
}

//------------------------------------------------------------------------
//
//   clear_all_thread_lotID
//
//  Input  Parameter
//              none
//
//  Output Parameter
//              none
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void clear_all_thread_lotID( void )
{
    for ( int i = 0; i < gb_ThreadCount; i++ )
    {
        threadinfo * pthreadinfo = &(pthreadinfos[ i ]);

        pthread_mutex_lock( &pthreadinfo->plock );
        pthreadinfo->lotID[0]  = 0;
        pthread_mutex_unlock( &pthreadinfo->plock );
    }
}

//------------------------------------------------------------------------
//
//   Pthread_cond_timedwait_sec
//
//  Input  Parameter
//              pthread_cond_t *cptr, pthread_mutex_t *mptr, long sec
//
//  Output Parameter
//              none
//
//  Return Code
//              int
//
//------------------------------------------------------------------------
int Pthread_cond_timedwait_sec ( pthread_cond_t *cptr, pthread_mutex_t *mptr, int sec )
{
    struct timeval     tv;
    struct timespec    ts;
    if( gettimeofday( &tv, NULL ) < 0 )
    {
        return -1;
    }
    ts.tv_sec = tv.tv_sec + sec;
    ts.tv_nsec = tv.tv_usec * 1000;

    return pthread_cond_timedwait( cptr, mptr, &ts ) ;
}

//------------------------------------------------------------------------
//
//   GetKeepCount
//
//  Input  Parameter
//              const char* subLotType
//
//  Output Parameter
//              none
//
//  Return Code
//              int keepCount
//
//------------------------------------------------------------------------
int GetKeepCount( const char* subLotType )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::GetKeepCount", "START" );

    int keepCount = gb_DefaultKeepCount;

    int inputFileCount = strInputFileLineSeq.length();
    for ( int inputFileIndex = 0; inputFileIndex < inputFileCount; inputFileIndex++ )
    {
        if ( CIMFWStrCmp( subLotType, strInputFileLineSeq[inputFileIndex].subLotType ) == 0 )
        {
            keepCount = strInputFileLineSeq[inputFileIndex].keepCount;
            break;
        }
    }

    POMAINT_TRACE_VERBOSE2( 3, "subLotType : ", subLotType );
    POMAINT_TRACE_VERBOSE2( 3, "keepCount  : ", keepCount );

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::GetKeepCount", "END" );

    return keepCount;
}

//------------------------------------------------------------------------
//
//   CheckInactiveLotPeriodNotPassed
//
//  Input  Parameter
//              const invoker_lotstate lotState
//              const char* claimTime
//              const char* currentTimeStamp
//
//  Output Parameter
//              none
//
//  Return Code
//              CORBA::Boolean PeriodNotPassedFlag
//
//------------------------------------------------------------------------
CORBA::Boolean CheckInactiveLotPeriodNotPassed( const invoker_lotstate lotState, const char* claimTime, const char* currentTimeStamp )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::CheckInactiveLotPeriodNotPassed", "START" );

    CORBA::Boolean retPeriodNotPassedFlag = FALSE;

    time_t        claimTimeSec;
    unsigned long claimTimeMsec;
    time_t        currentTimeSec;
    unsigned long currentTimeMsec;
    time_t        reservePeriodSec;

    //Shipped Lot
    if ( lotState == shipped )
    {
        reservePeriodSec = (time_t)gb_PoReservePeriodShipped;
    }
    //Scrapped Lot
    else if (lotState == scrapped )
    {
        reservePeriodSec = (time_t)gb_PoReservePeriodScrapped;
    }
    //Stacked Lot
    else if (lotState == stacked )
    {
        reservePeriodSec = (time_t)gb_PoReservePeriodStacked;
    }
    else
    {
        POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::CheckInactiveLotPeriodNotPassed", "END" );
        return FALSE;
    }
    reservePeriodSec *= (24 * 60 * 60);

    claimTimeSec   = TimestampToSeconds( claimTime,        &claimTimeMsec   );
    currentTimeSec = TimestampToSeconds( currentTimeStamp, &currentTimeMsec );

    currentTimeSec -= reservePeriodSec;

    if ( claimTimeSec == currentTimeSec )
    {
        // Period is not passed
        if ( claimTimeMsec >= currentTimeMsec )
        {
            POMAINT_TRACE_VERBOSE1( 3, "PO Reserve Period is not passed." );
            retPeriodNotPassedFlag = TRUE;
        }
    }
    // Period is not passed
    else if ( claimTimeSec >= currentTimeSec )
    {
        POMAINT_TRACE_VERBOSE1( 3, "PO Reserve Period is not passed." );
        retPeriodNotPassedFlag = TRUE;
    }

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::CheckInactiveLotPeriodNotPassed", "END" );

    return retPeriodNotPassedFlag;
}

//------------------------------------------------------------------------
//
//   CheckKeepCountOfActiveChildLot
//
//  Input  Parameter
//              const stringSequence& childPfxKeySeq
//              const int poSeqNo
//              const int keepCount
//              const char* parentSubLotType
//              const char* parentLotID
//
//  Output Parameter
//              none
//
//  Return Code
//              RC_OK
//              RC_NOT_OVER_KEEPCOUNT
//              RC_DATABASE_CONNECT_ERROR
//              RC_SYSTEM_ERROR
//
//------------------------------------------------------------------------
CORBA::Long CheckKeepCountOfActiveChildLot( const stringSequence& childPfxKeySeq, const int poSeqNo, const int keepCount, const char* parentSubLotType, const char* parentLotID )
{
    POMAINT_TRACE_VERBOSE1( 2, "" );
    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::CheckKeepCountOfActiveChildLot", "START" );

    CORBA::Long sqlcode = 0;

    CORBA::Long childPfxKeyCount = childPfxKeySeq.length();
    for ( CORBA::Long childPfxKeyIndex = 0; childPfxKeyIndex < childPfxKeyCount; childPfxKeyIndex++ )
    {
        char *childPfxKey = childPfxKeySeq[childPfxKeyIndex];

        //----------------------------------
        // Get latest PO SeqNo
        //----------------------------------
        int latestSeqNo;
        sqlcode = GetLatestPOSeqNo( childPfxKey, &latestSeqNo );
        if ( sqlcode != 0 )
        {
            if ( sqlcode == 100 )
            {
                POMAINT_TRACE_VERBOSE1( 2, getMessage( MSG_NOT_EXIST_PO_INF ) );
                continue;
            }
            else
            {
                CHECK_SQL_ERROR_RETURN( parentSubLotType, parentLotID, "POMaintenanceProgram::CheckKeepCountOfActiveChildLot", getMessage( MSG_GET_CHILED_LOT_LATEST_PO_ERROR ), sqlcode );
            }
        }

        // Not over the keep count
        if ( latestSeqNo - keepCount <= poSeqNo )
        {
            POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::CheckKeepCountOfActiveChildLot", "END" );
            return RC_NOT_OVER_KEEPCOUNT;
        }
    }

    POMAINT_TRACE_VERBOSE2( 2, "POMaintenanceProgram::CheckKeepCountOfActiveChildLot", "END" );

    return RC_OK;
}

//------------------------------------------------------------------------
//
//   getMessage
//
//  Input  Parameter
//              int msgid
//
//  Output Parameter
//              none
//
//  Return Code
//              char* message
//
//------------------------------------------------------------------------
char* getMessage( int msgid )
{
    char* message = catgets( catd, MS_SET1, msgid, "No message read !" );
    return message;
}

//------------------------------------------------------------------------
//
//   eventLog_put
//
//  Input  Parameter
//              char    *eventString
//
//  Output Parameter
//              None
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void eventLog_put( const char* subLotType, const char* lotID, const long returnCode, const char *message, char *format, ... )
{
    char            buf[BUFSIZE];
    struct tm       t;
    struct timeval  tv;

    /*get current time*/
    gettimeofday( &tv, NULL );
    localtime_r( &tv.tv_sec, &t );
    memset( buf, 0x00, sizeof( buf ) );

//DSN000030296    sprintf( buf,"%04d-%02d-%02d-%02d.%02d.%02d.%06d|%d|%d|%s|%s|%ld|%s|",
    sprintf( buf,"%04d-%02d-%02d-%02d.%02d.%02d.%06d|%d|%u|%s|%s|%ld|%s|",  //DSN000030296
            ( t.tm_year+1900 ),
            ( t.tm_mon+1 ),
            t.tm_mday,
            t.tm_hour,
            t.tm_min,
            t.tm_sec,
            tv.tv_usec,
            getpid(),
            pthread_self(),
            subLotType,
            lotID,
            returnCode,
            message );

    char * ptr  = (char*)&buf[0] + strlen( buf );
    va_list va;
    va_start( va, format );
    vsprintf( ptr, format, va );
    va_end( va );

    //put Event log
    if ( eventLogObj.isNil() )
    {
        // if no event log server, get an event log server object
        int ipckey=0x20001121; // default key
        const char* p= getenv( POMAINT_EVENT_LOG_IPCKEY );

        if ( p )
        {
            istrstream is(p);
            is >> hex >> ipckey;
            if ( ipckey == 0 ) ipckey= 0x20001121; // default key
        }

        eventLogObj = new SPEventLogControlObject( ipckey );
    }

    eventLogObj->putEventLogText( buf );
}

//------------------------------------------------------------------------
//
//   sigHandler
//
//  Input  Parameter
//              int code
//
//  Output Parameter
//              none
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void sigHandler( int code )
{
    fEndOfProcess = TRUE;
    // Event Driven Mode
    if ( gb_EventDrivenEnabled )
    {
        for ( int i = 0; i < gb_ThreadCount; i++ )
        {
            threadinfo * pthreadinfo = &(pthreadinfos[ i ]);
            pthread_cond_signal( &(pthreadinfo->psig) );
        }
        pthread_cond_signal( &sig );
    }
    cout << "PO Maintenance Program will be stopped in a while." << endl;
}

//------------------------------------------------------------------------
//
//   trace_verbose_printf
//
//  Input  Parameter
//              const char *filename, const int lineno, const char *format, ...
//
//  Output Parameter
//              none
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void trace_verbose_print( const char *filename, const int lineno, const char *str )
{
    char    buf[BUFSIZE];
    struct timeval tv;
    struct tm        t;
//DSN000030296    char    *header_format = "[%04.4d/%02.2d/%02.2d:%2.2d:%02.2d:%02.2d.%06.6d (%d) %s:%d] ";
    char    *header_format = "[%04.4d/%02.2d/%02.2d:%2.2d:%02.2d:%02.2d.%06.6d (%u) %s:%d] ";  //DSN000030296
    long    len;
    char    *ptr;

    gettimeofday( &tv, NULL );

    localtime_r( &tv.tv_sec, &t );

    sprintf( buf,
        header_format,
        (t.tm_year+1900),
        (t.tm_mon+1),
        t.tm_mday,
        t.tm_hour,
        t.tm_min,
        t.tm_sec,
        tv.tv_usec,
        pthread_self(),
        filename,
        lineno ) ;

    len = strlen(buf);
    ptr = &buf[len];
    strcpy( ptr, str );

    printf(buf);
    printf("\n");
    fflush(stdout);
}

//------------------------------------------------------------------------
//
//   TimestampToSeconds
//
//  Input  Parameter
//              const char* aTimeStamp
//
//  Output Parameter
//              unsigned long* microSeconds
//
//  Return Code
//              time_t seconds
//
//------------------------------------------------------------------------
time_t TimestampToSeconds( const char* aTimeStamp, unsigned long* microSeconds )
{
    time_t retSeconds;

    if ( aTimeStamp == NULL || CIMFWStrLen( aTimeStamp ) <= 0 || CIMFWStrLen( aTimeStamp ) != 26 || CIMFWStrCmp( aTimeStamp, "1901-01-01-00.00.00.000000" ) == 0 )
    {
        retSeconds = 0;
        *microSeconds = 0;
        return retSeconds;
    }
    else
    {
        char ch ;
        ch = 0 ;
        int aYear, aMonthIndex, aDay, Hours, Minutes, Seconds ;
        long MSeconds ;
        int out = 0 ;
        aYear = 0;
        aMonthIndex = 0;
        aDay = 0;
        Hours = 0;
        Minutes = 0;
        Seconds = 0;
        MSeconds = 0;
        out = sscanf( aTimeStamp, "%4d%c%2d%c%2d%c%2d%c%2d%c%2d%c%06ld", &aYear, &ch, &aMonthIndex, &ch, &aDay, &ch, &Hours, &ch, &Minutes, &ch, &Seconds, &ch, &MSeconds ) ;

        if ( out != 13 )
        {
            retSeconds = 0;
            *microSeconds = 0;
            return retSeconds;
        }

        struct tm       date ;
        time_t          secs ;

        date.tm_sec  = Seconds ;         // seconds after the minute [0-61]
        date.tm_min  = Minutes ;         // minutes after the hour [0-59]
        date.tm_hour = Hours ;           // hours since midnight [0-23] 
        date.tm_mday = aDay ;            // day of the month [1-31]     
        date.tm_mon  = aMonthIndex - 1 ; // months since January [0-11] 
        if ( aYear < 1900 )
        {
            date.tm_year = aYear ;  // years since 1900            
        }
        else
        {
            date.tm_year = aYear - 1900 ;  // years since 1900            
        }
        date.tm_isdst = -1;

        if ( ( secs = mktime( &date ) ) == -1 )
        {
            retSeconds = 0 ;
            *microSeconds = 0 ;
            return retSeconds;
        }
        retSeconds = secs ;
        *microSeconds = MSeconds ;

        return retSeconds;
    }
}

//------------------------------------------------------------------------
//
//   TimestampToSeconds
//
//  Input  Parameter
//              const time_t seconds
//              const unsigned long microSeconds
//
//  Output Parameter
//              char* aTimeStamp
//
//  Return Code
//              none
//
//------------------------------------------------------------------------
void SecondsToTimestamp( const time_t seconds, const unsigned long microSeconds, char* aTimeStamp )
{
    char retVal[27] ;
    struct timeb Tp ;

    memset( retVal, '\0', sizeof( char )*27 ) ;

    struct tm date ;
    Tp.time = seconds;
    if (localtime_r( &Tp.time, &date ) == 0 || Tp.time == 0 )
    {
        date.tm_year  = 1;
        date.tm_mon   = 0;
        date.tm_mday  = 1;
        date.tm_hour  = 0;
        date.tm_min   = 0;
        date.tm_yday  = 0;
        date.tm_wday  = 0;
    }

    sprintf( retVal, "%04d%s%02d%s%02d%s%02d%s%02d%s%02d%s%06d", date.tm_year+1900, "-", date.tm_mon+1, "-", date.tm_mday, "-", date.tm_hour, ".", date.tm_min, ".", date.tm_sec, ".", microSeconds ) ;
    strcpy( aTimeStamp, retVal );
}
