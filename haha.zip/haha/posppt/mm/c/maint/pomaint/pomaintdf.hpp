/************************************************************************************
**
**  System      : SiView Management of Process Operation's Data Program
**
**  Module name : pomaintdf.hpp
**
**  Description : Management of Process Operation's Data Program Global Define header
**
** (c) Copyright: IBM Japan Services Company Ltd, 1997, 2011. All rights reserved.
** (c) Copyright: International Business Machines Corporation, 1997, 2011. All rights reserved.
**
**
** Change history:
** Date       Defect#      Person         Comments
** ---------- ------------ -------------- -------------------------------------------
** 2010/10/14 DSIV00002270 K.Yamaoku      PO Maintenance Improvement
** 2011/01/11 DSIV00002757 K.Yamaoku      Improvement of PO Maintenance Program
** 2011/08/15 DSN000015229 K.Yamaoku      Advanced Wafer Level Control
**
*************************************************************************************/

#include "pptstr.hh"
#include "cimfwstr.hpp"
#include "pomaintstr.hh"
#include "pomaintmacros.hpp"

//-------------------------------
// Type Define
//-------------------------------
enum    invoker_threadstatus { na, idle, busy, stop, error, init };
enum    invoker_lotstate { active, shipped, scrapped, emptied, stacked };

struct  threadinfo
{
    pthread_t               tid;
    pthread_attr_t          pattr;
    pthread_cond_t          psig;
    pthread_mutex_t         plock;
    invoker_threadstatus    status;
    void                    *ctx;
    int                     dbConnectFlag;
    char                    lotID[128];
    char                    updateTime[128];
    int                     keepCount;

    threadinfo()
    {
        memset( &tid,   0, sizeof( tid   ) );
        memset( &pattr, 0, sizeof( pattr ) );
        memset( &psig,  0, sizeof( psig  ) );
        memset( &plock, 0, sizeof( plock ) );
        status = na;
        dbConnectFlag = 0;
        memset( &lotID,      0, sizeof( lotID     ) );
        memset( &updateTime, 0, sizeof( updateTime) );
        keepCount = 0;
    }
};

//-------------------------------
//  Variable Define
//-------------------------------
#ifdef INCL_MAIN
    SPEventLogControlObject_var         eventLogObj;

    nl_catd                             catd; // structure of Catalogue

    char                                *gb_InputFileName;
    char                                *gb_Option;

    char                                *gb_DBName;
    char                                *gb_DBUserName;
    char                                *gb_Password;
    int                                 gb_ExitCount;
    int                                 gb_CommitCount;
    int                                 gb_EventDrivenEnabled;
    int                                 gb_IntervalTime;
    int                                 gb_ActiveEnabled;    //DSIV00002757
    int                                 gb_InactiveEnabled;
    int                                 gb_PoReservePeriodShipped;
    int                                 gb_PoReservePeriodScrapped;
    int                                 gb_PoReservePeriodStacked;
    int                                 gb_AllSubLotTypeEnabled;
    int                                 gb_DefaultKeepCount;
    int                                 gb_ThreadCount;
    int                                 gb_DBRetryCount;
    int                                 gb_DBRetryInterval;
    int                                 gb_DebugFlagON = 1;
    int                                 gb_DebugLevel = 1;

    void                                *gb_ctx;
    int                                 gb_DBConnectFlag = 0;

    pomaintInputFileLineSequence        strInputFileLineSeq;
    pomaintEventQueueSequence           strEventQueueSeq;

    pthread_cond_t                      sig;
    pthread_mutex_t                     lock;
    threadinfo                          *pthreadinfos = NULL;
    int                                 notify_count  = 0;
#else
    extern  char                        *gb_InputFileName;
    extern  char                        *gb_Option;

    extern  char                        *gb_DBName;
    extern  char                        *gb_DBUserName;
    extern  char                        *gb_Password;
    extern  int                         gb_ExitCount;
    extern  int                         gb_CommitCount;
    extern  int                         gb_EventDrivenEnabled;
    extern  int                         gb_IntervalTime;
    extern  int                         gb_ActiveEnabled;    //DSIV00002757
    extern  int                         gb_InactiveEnabled;
    extern  int                         gb_PoReservePeriodShipped;
    extern  int                         gb_PoReservePeriodScrapped;
    extern  int                         gb_PoReservePeriodStacked;
    extern  int                         gb_AllSubLotTypeEnabled;
    extern  int                         gb_DefaultKeepCount;
    extern  int                         gb_ThreadCount;
    extern  int                         gb_DBRetryCount;
    extern  int                         gb_DBRetryInterval;
    extern  int                         gb_DebugFlagON;
    extern  int                         gb_DebugLevel;

    extern  void                        *gb_ctx;
    extern  int                         gb_DBConnectFlag;

    extern pomaintInputFileLineSequence strInputFileLineSeq;
    extern pomaintEventQueueSequence    strEventQueueSeq;

    extern  pthread_cond_t              sig;
    extern  pthread_mutex_t             lock;
    extern  threadinfo                  *pthreadinfos;
    extern  int                         notify_count;
#endif

//-------------------------------
// Define
//-------------------------------
#define POMAINT_DBNAME                       "POMAINT_DBNAME"
#define POMAINT_USERNAME                     "POMAINT_USERNAME"
#define POMAINT_PASSWORD                     "POMAINT_PASSWORD"
#define POMAINT_EXITCOUNT                    "POMAINT_EXITCOUNT"
#define POMAINT_COMMITCOUNT                  "POMAINT_COMMITCOUNT"
#define POMAINT_EVENTDRIVEN_ENABLED          "POMAINT_EVENTDRIVEN_ENABLED"
#define POMAINT_INTERVALTIME                 "POMAINT_INTERVALTIME"
#define POMAINT_ACTIVE_ENABLED               "POMAINT_ACTIVE_ENABLED"       //DSIV00002757
#define POMAINT_INACTIVE_ENABLED             "POMAINT_INACTIVE_ENABLED"
#define POMAINT_PO_RESERVE_PERIOD_SHIPPED    "POMAINT_PO_RESERVE_PERIOD_SHIPPED"
#define POMAINT_PO_RESERVE_PERIOD_SCRAPPED   "POMAINT_PO_RESERVE_PERIOD_SCRAPPED"
#define POMAINT_PO_RESERVE_PERIOD_STACKED    "POMAINT_PO_RESERVE_PERIOD_STACKED"
#define POMAINT_ALL_SUBLOTTYPE_ENABLED       "POMAINT_ALL_SUBLOTTYPE_ENABLED"
#define POMAINT_DEFAULT_KEEPCOUNT            "POMAINT_DEFAULT_KEEPCOUNT"
#define POMAINT_THREADCOUNT                  "POMAINT_THREADCOUNT"
#define POMAINT_DB_RETRY_COUNT               "POMAINT_DB_RETRY_COUNT"
#define POMAINT_DB_RETRY_INTERVAL            "POMAINT_DB_RETRY_INTERVAL"
#define POMAINT_EVENT_LOG_IPCKEY             "POMAINT_EVENT_LOG_IPCKEY"
#define POMAINT_DEBUG_FLAG_ON                "POMAINT_DEBUG_FLAG_ON"
#define POMAINT_DEBUG_LEVEL                  "POMAINT_DEBUG_LEVEL"
#define POMAINT_CATALOG_FILE                 "POMAINT_CATALOG_FILE"

#define EXIT_COUNT_MIN                       0
#define COMMIT_COUNT_MIN                     1
#define INTERVAL_TIME_MIN                    0
#define PO_RESERVE_PERIOD_MIN                0
#define DEFAULT_KEEP_COUNT_MIN               1
#define THREAD_COUNT_MIN                     1
#define THREAD_COUNT_MAX                     128               //When changing this value, the value of the SQL command of [GetLotsForEventDriven] function is also changed.
#define DB_RETRY_COUNT_MIN                   0
#define DB_RETRY_COUNT_MAX                   100
#define DB_RETRY_INTERVAL_MIN                0
#define DB_RETRY_INTERVAL_MAX                60

#define DB_FETCH_COUNT_MAX_FOR_LOT           THREAD_COUNT_MAX  //When changing this value, the value of the SQL command of [GetLotsForEventDriven] function is also changed.
#define DB_FETCH_COUNT_MAX_FOR_PO            1000              //When changing this value, the value of the SQL command of [GetTargetPOs] function is also changed.

#define Default_ExitCount                    0
#define Default_CommitCount                  50
#define Default_EventDrivenEnabled           0
#define Default_IntervalTime                 3600 //Sec
#define Default_ActiveEnabled                1    //DSIV00002757
#define Default_InactiveEnabled              0
#define Default_PoReservePeriodShipped       3    //Day
#define Default_PoReservePeriodScrapped      3    //Day
#define Default_PoReservePeriodStacked       3    //Day
#define Default_AllSubLotTypeEnabled         0
#define Default_DefaultKeepCount             5
#define Default_ThreadCount                  5
#define Default_DBRetryCount                 0
#define Default_DBRetryInterval              0    //Sec
#define Default_DebugFlagON                  0
#define Default_DebugLevel                   2

//-------------------------------
// Data Structure Define
//-------------------------------
#define BUFSIZE                                 8192     /*8 Kbytes*/

//-------------------------------
// LOT State
//-------------------------------
#define LOT_STATE_ACTIVE         "ACTIVE"
#define LOT_STATE_SHIPPED        "SHIPPED"
#define LOT_STATE_SCRAPPED       "SCRAPPED"
#define LOT_STATE_EMPTIED        "EMPTIED"
#define LOT_STATE_STACKED        "STACKED"

//-------------------------------
// FRPO REF_CNT value
//-------------------------------
#define REF_CNT_DELETE_COMP_DC               1       // The completion of Data Collection information deletion
#define REF_CNT_DELETE_COMP_ARP              2       // The completion of Assigned Recipe Parameter information deletion
#define REF_CNT_DELETE_COMP_APR              4       // The completion of Assigned Process Resource information deletion
#define REF_CNT_DELETE_COMP_OTHER            8       // The completion of other child tables information deletion
//DSIV00002757 #define REF_CNT_DELETE_COMP_ACTIVE_PO_ALL    ( REF_CNT_DELETE_COMP_DC | REF_CNT_DELETE_COMP_ARP | REF_CNT_DELETE_COMP_APR )
//DSIV00002757 #define REF_CNT_DELETE_COMP_INACTIVE_PO_ALL  ( REF_CNT_DELETE_COMP_ACTIVE_PO_ALL | REF_CNT_DELETE_COMP_OTHER )
#define REF_CNT_DELETE_COMP_PO_CHILD_ALL     ( REF_CNT_DELETE_COMP_DC | REF_CNT_DELETE_COMP_ARP | REF_CNT_DELETE_COMP_APR | REF_CNT_DELETE_COMP_OTHER )    //DSIV00002757

//-------------------------------
// Error Code Define
//-------------------------------
#define RC_OK                                 0
#define RC_NOT_OVER_KEEPCOUNT                 102
#define RC_EXIT_PROGRAM                       103
#define RC_NUMBER_OF_START_THREAD             104
#define RC_DELETE_BACKUPPOLIST_PO             105
#define RC_NOT_EXIST_PO_INF                   106
#define RC_DELETE_PO_INF                      107
#define RC_DELETE_FULLSET_PO                  108
#define RC_DELETE_PO_DC                       109
#define RC_DELETE_PO_ARP                      110
#define RC_DELETE_PO_APR                      111
#define RC_NOT_EXIST_LOT_INF                  112
#define RC_SYSTEM_ERROR                       113
#define RC_DATABASE_CONNECT_ERROR             114
#define RC_DATABASE_DISCONNECT_ERROR          115
#define RC_DATABASE_ROLLBACK_ERROR            116
#define RC_DATABASE_COMMIT_ERROR              117
#define RC_PROGRAMPARAMETER_ERROR             118
#define RC_INITIALIZE_SQL_CONTEXT_ERROR       119
#define RC_CLEANUP_SQL_CONTEXT_ERROR          120
#define RC_INPUTFILESETTING_ERROR             121
#define RC_UNNECESSARY_OPT_ERROR              122
#define RC_OPT_ERROR                          123
#define RC_INPUTFILENAME_ERROR                124
#define RC_START_THREAD_FAILED                125
#define RC_ALL_THREAD_INIT_ERROR              126
#define RC_DELETE_BACKUPPOLIST_PO_ERROR       127
#define RC_GET_LATEST_PO_ERROR                128
#define RC_GET_CHILED_LOT_LATEST_PO_ERROR     129
#define RC_DELETE_FULLSET_PO_ERROR            130
#define RC_DELETE_PO_DC_ERROR                 131
#define RC_DELETE_PO_ARP_ERROR                132
#define RC_DELETE_PO_APR_ERROR                133
#define RC_GET_CURRENT_TIMESTAMP_ERROR        134
#define RC_UPDATE_EVENT_TIMESTAMP_ERROR       135
#define RC_DELETE_OLD_EVENT_ERROR             136
#define RC_GET_LOT_INF_ERROR                  137
#define RC_GET_PARENT_LOT_INF_ERROR           138
#define RC_PUT_PARENT_LOT_EVENT_ERROR         139
#define RC_DB_DISCONNECTED                    140
#define RC_GET_ACTIVE_CHILD_LOT_PFX_ERROR     141
#define RC_CHECK_NOT_EXIST_DC_INF_ERROR       142
#define RC_CHECK_NOT_EXIST_ARP_INF_ERROR      143
#define RC_CHECK_NOT_EXIST_APR_INF_ERROR      144
#define RC_GET_PO_DETAIL_INF_ERROR            145
#define RC_CHECK_EXIST_DC_EVENT_ERROR         146
#define RC_CHECK_MAINPD_DELTA_ERROR           147
#define RC_CHECK_MODULEPD_DELTA_ERROR         148
#define RC_CHECK_MAINPD_CORRESPOND_ERROR      149
#define RC_CHECK_MODULEPD_CORRESPOND_ERROR    150
#define RC_GET_TARGET_LOT_ERROR               151
#define RC_GET_ACTIVE_LOT_ERROR               152
#define RC_GET_INACTIVE_LOT_ERROR             153
#define RC_DELETE_EVENT_ERROR                 154
#define RC_GET_TARGET_PO_ERROR                155
#define RC_UPDATE_REFCNT_ERROR                156

#ifdef INCL_MAIN
    extern int InitializeSqlContext( void **ctx, int *dbConnectFlag );
    extern int CleanupSqlContext( void **ctx, int *dbConnectFlag );
    extern int ConnectDataBase( void );
    extern int DisConnectDataBase( void );
    extern CORBA::Long RollBackDataBase( void );
    extern CORBA::Long CommitDataBase( void );
    extern CORBA::Long GetTimeStamp( char *currentTimeStamp );
    extern CORBA::Long GetLotsForEventDriven( const char* currentTimeStamp, const char* subLotType );
    extern CORBA::Long UpdateEventUpdateTime( const char* currentTimeStamp, const char* lotID, const char* updateTime );
    extern CORBA::Long DeleteOldEvent( const char* currentTimeStamp, const char* lotID );
    extern CORBA::Long DeleteEvent( const char* updateTime, const char* lotID );
    extern CORBA::Long GetLotInformation( const char* lotID, pomaintLotInf& strLotInf );
    extern CORBA::Long GetPfxKeysForActiveChildLot( const char* currentTimeStamp, const char* poObj, const char* pfxKey, stringSequence& childPfxKeySeq );
    extern CORBA::Long GetLatestPOSeqNo( const char* pfxKey, int* seqNo );
//DSIV00002757    extern CORBA::Long GetTargetPOs( const CORBA::Boolean inactiveLotFlag, const char* pfxObj, const char* pfxKey, const int previousSeqNo, const int targetSeqNo, pomaintPOInfSequence& strPOInfSeq );
    extern CORBA::Long GetTargetPOs( const char* pfxObj, const char* pfxKey, const int previousSeqNo, const int targetSeqNo, pomaintPOInfSequence& strPOInfSeq );  //DSIV00002757
    extern CORBA::Long NotExistCheckDCInfo( const char* poKey, CORBA::Boolean& notExistFlag );
    extern CORBA::Long NotExistCheckAssignRecipeParmInfo( const char* poKey, CORBA::Boolean& notExistFlag );
    extern CORBA::Long NotExistCheckAssignProcessResourceInfo( const char* poKey, CORBA::Boolean& notExistFlag );
    extern CORBA::Long ExistCheckDCEvent( const char* poObj, CORBA::Boolean& existFlag );
//DSIV00002757    extern CORBA::Long DeleteFullSetPOInformation( const char* poKey );
//DSN000015229    extern CORBA::Long DeleteFullSetPOInformation( const char* poKey, CORBA::Boolean& delDCFlag, CORBA::Boolean& delARPFlag, CORBA::Boolean& delAPRFlag, CORBA::Boolean& delOTHERFlag );  //DSIV00002757
    extern CORBA::Long DeleteFullSetPOInformation( const char* poKey, CORBA::Boolean& delDCItemFlag, CORBA::Boolean& delDCFlag, CORBA::Boolean& delARPFlag, CORBA::Boolean& delAPRFlag, CORBA::Boolean& delOTHERFlag );  //DSN000015229
    extern CORBA::Long DeleteBackupPoList( const char* pfxKey );
    extern CORBA::Long ExistCheckBackupPoList( const char* pfxKey, CORBA::Boolean& existFlag );  //DSIV00002757
    extern CORBA::Long UpdatePORefCnt( const char* poKey, const CORBA::Long& refCnt );
    extern CORBA::Long InsertEventQueue( const char* lotID, const char* subLotType );
    extern CORBA::Long GetPODetailInformation( const char* poObj, pomaintPODetailInf& strPODetailInf );
    extern CORBA::Long CheckDeltaOperationForMainPD( const pomaintPOInf& strPOInf, const pomaintPODetailInf& strPODetailInf, const stringSequence& checkPfxKeySeq, CORBA::Boolean& notPerformPostOpeFlag );
    extern CORBA::Long CheckDeltaOperationForModulePD( const pomaintPOInf& strPOInf, const pomaintPODetailInf& strPODetailInf, const stringSequence& checkPfxKeySeq, CORBA::Boolean& notPerformPostOpeFlag );
    extern CORBA::Long CheckCorrespondingOperationForMainPD( const pomaintPOInf& strPOInf, const pomaintPODetailInf& strPODetailInf, const stringSequence& checkPfxKeySeq, CORBA::Boolean& notPerformPostOpeFlag );
    extern CORBA::Long CheckCorrespondingOperationForModulePD( const pomaintPOInf& strPOInf, const pomaintPODetailInf& strPODetailInf, const stringSequence& checkPfxKeySeq, CORBA::Boolean& notPerformPostOpeFlag );
//DSIV00002757    extern CORBA::Long DeleteDCInformation( const char* poKey );
//DSIV00002757    extern CORBA::Long DeleteAssignRecipeParmInformation( const char* poKey );
//DSIV00002757    extern CORBA::Long DeleteAssignProcessResourceInformation( const char* poKey );
    extern CORBA::Long GetAllSubLotTypes( stringSequence& subLotTypeSeq );
    extern CORBA::Long GetActiveLotsForMaintenance( const char* subLotType, stringSequence& lotIDSeq );
    extern CORBA::Long GetInactiveLotsForMaintenance( const char* currentTimeStamp, const char* subLotType, stringSequence& lotIDSeq );
#endif
