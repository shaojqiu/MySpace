/*****************************************************************************
**
**  System      : SiView Management of Process Operation's Data Program
**
**  Module name : pomaintmacros.hpp
**
**  Description : Management of Process Operation's Data Program Global Define header
**
** (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
** (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
**
**
** Change history:
** Date       Defect#      Person         Comments
** ---------- ------------ -------------- -------------------------------------------
** 2010/10/14 DSIV00002270 K.Yamaoku      PO Maintenance Improvement
**
*****************************************************************************/

#include <strstream.h>

//-----------------------------------------------------------
// Following Macros are defined in this file.
//  1. POMAINT_FUNCTION_TRACE_ENTRY
//  2. POMAINT_FUNCTION_TRACE_EXIT
//  3. POMAINT_TRACE_VERBOSE
//  4. POMAINT_TRACE_VERBOSE1
//  5. POMAINT_TRACE_VERBOSE2
//  6. POMAINT_TRACE_VERBOSE3
//  7. POMAINT_TRACE_VERBOSE4
//  8. POMAINT_TRACE_VERBOSE5
//  9. POMAINT_TRACE_VERBOSE6
// 10. POMAINT_TRACE_VERBOSE7
// 11. POMAINT_TRACE_VERBOSE8
// 12. POMAINT_TRACE_VERBOSE9
// 13. POMAINT_TRACE_VERBOSE10
// 14. POMAINT_EVENT_LOG1
// 15. POMAINT_EVENT_LOG2
// 16. POMAINT_EVENT_LOG3
// 17. POMAINT_EVENT_LOG4
// 18. POMAINT_EVENT_LOG5
// 19. POMAINT_EVENT_LOG6
// 20. POMAINT_EVENT_LOG7
// 21. POMAINT_EVENT_LOG8
// 22. POMAINT_EVENT_LOG9
// 23. POMAINT_EVENT_LOG10

#define POMAINTDebugLevelMax 4
#define POMAINTDebugLevel    gb_DebugLevel
#define POMAINTDebugFlagON   gb_DebugFlagON

#ifdef RUNTIME_DEBUG_FACILITY
    #define DEBUG_MODE_IS_ON
#endif

#ifdef DEBUG_MODE_IS_ON
    #define POMAINT_FUNCTION_TRACE_ENTRY( X, componentID )\
    {\
        if( X < POMAINTDebugLevel )\
        {\
            ostrstream ostr;\
            ostr << "-------------------------------------" << ends;\
            trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
            ostr.rdbuf()->freeze(0);\
            ostr.seekp(0);\
            ostr << "Entering [" << componentID << "]" << ends;\
            trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
            ostr.rdbuf()->freeze(0);\
            ostr.seekp(0);\
            ostr << "-------------------------------------" << ends;\
            trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
            ostr.rdbuf()->freeze(0);\
        }\
    }

    #define POMAINT_FUNCTION_TRACE_EXIT( X, componentID  )\
    {\
        if( X < POMAINTDebugLevel )\
        {\
            ostrstream ostr;\
            ostr << "-------------------------------------" << ends;\
            trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
            ostr.rdbuf()->freeze(0);\
            ostr.seekp(0);\
            ostr << "Exiting [" << componentID << "]" << ends;\
            trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
            ostr.rdbuf()->freeze(0);\
            ostr.seekp(0);\
            ostr << "-------------------------------------" << ends;\
            trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
            ostr.rdbuf()->freeze(0);\
        }\
    }
#else
    #define POMAINT_FUNCTION_TRACE_ENTRY( X, componentID )
    #define POMAINT_FUNCTION_TRACE_EXIT( X, componentID  )
#endif

    #define FLAGCHECK(X)\
    if( POMAINTDebugFlagON && X <= POMAINTDebugLevel)

    #define POMAINT_TRACE_VERBOSE1( X, aParam1 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE2( X, aParam1, aParam2 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "]" << ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE3( X, aParam1, aParam2, aParam3 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "] [" << aParam3 << "]" <<ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE4( X, aParam1, aParam2, aParam3, aParam4 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "] [" << aParam3 << "] [" << aParam4 << "]" <<ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE5( X, aParam1, aParam2, aParam3, aParam4, aParam5 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "] [" << aParam3 << "] [" << aParam4 << "] [" << aParam5 << "]" <<ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE6( X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "] [" << aParam3 << "] [" << aParam4 << "] [" << aParam5 << "] [" << aParam6 << "]" <<ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE7( X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "] [" << aParam3 << "] [" << aParam4 << "] [" << aParam5 << "] [" << aParam6 << "] [" << aParam7 << "]" <<ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE8( X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7, aParam8 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "] [" << aParam3 << "] [" << aParam4 << "] [" << aParam5 << "] [" << aParam6 << "] [" << aParam7 << "] [" << aParam8 << "]" <<ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE9( X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7, aParam8, aParam9 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "] [" << aParam3 << "] [" << aParam4 << "] [" << aParam5 << "] [" << aParam6 << "] [" << aParam7 << "] [" << aParam8 << "] [" << aParam9 << "]" <<ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }
    #define POMAINT_TRACE_VERBOSE10( X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7, aParam8, aParam9, aParam10 )\
    FLAGCHECK(X)\
    {\
        ostrstream ostr;\
        ostr << aParam1 << " [" << aParam2 << "] [" << aParam3 << "] [" << aParam4 << "] [" << aParam5 << "] [" << aParam6 << "] [" << aParam7 << "] [" << aParam8 << "] [" << aParam9 << "] [" << aParam10 << "]" <<ends;\
        trace_verbose_print( __FILE__, __LINE__, ostr.str() );\
        ostr.rdbuf()->freeze(0);\
    }

#ifdef RUNTIME_DEBUG_FACILITY
//----------------------------------------------
//  Event Log
//----------------------------------------------
    #define POMAINT_EVENT_LOG1( subLotType,lotID,returnCode,aParam1 )\
    {\
        try\
        {\
            eventLog_put( subLotType,lotID,returnCode,aParam1 );\
        }\
        catch(...)\
        {\
            cout << "* POMAINT_EVENT_LOG1 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG2( subLotType,lotID,returnCode,aParam1,aParam2 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG2 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG3( subLotType,lotID,returnCode,aParam1,aParam2,aParam3 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << " " << aParam3 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG3 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG4( subLotType,lotID,returnCode,aParam1,aParam2,aParam3,aParam4 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << " " << aParam3 << " " << aParam4 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG4 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG5( subLotType,lotID,returnCode,aParam1,aParam2,aParam3,aParam4,aParam5 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << " " << aParam3 << " " << aParam4 << " " << aParam5 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG5 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG6( subLotType,lotID,returnCode,aParam1,aParam2,aParam3,aParam4,aParam5,aParam6 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << " " << aParam3 << " " << aParam4 << " " << aParam5 << " " << aParam6 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG6 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG7( subLotType,lotID,returnCode,aParam1,aParam2,aParam3,aParam4,aParam5,aParam6,aParam7 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << " " << aParam3 << " " << aParam4 << " " << aParam5 << " " << aParam6 << " " << aParam7 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG7 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG8( subLotType,lotID,returnCode,aParam1,aParam2,aParam3,aParam4,aParam5,aParam6,aParam7,aParam8 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << " " << aParam3 << " " << aParam4 << " " << aParam5 << " " << aParam6 << " " << aParam7 << " " << aParam8 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG8 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG9( subLotType,lotID,returnCode,aParam1,aParam2,aParam3,aParam4,aParam5,aParam6,aParam7,aParam8,aParam9 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << " " << aParam3 << " " << aParam4 << " " << aParam5 << " " << aParam6 << " " << aParam7 << " " << aParam8 << " " << aParam9 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG9 * " << endl;\
        }\
    }

    #define POMAINT_EVENT_LOG10( subLotType,lotID,returnCode,aParam1,aParam2,aParam3,aParam4,aParam5,aParam6,aParam7,aParam8,aParam9,aParam10 )\
    {\
        try\
        {\
            ostrstream ostr;\
            ostr << aParam2 << " " << aParam3 << " " << aParam4 << " " << aParam5 << " " << aParam6 << " " << aParam7 << " " << aParam8 << " " << aParam9 << " " << aParam10 << ends;\
            eventLog_put(subLotType,lotID,returnCode,aParam1,ostr.str());\
            ostr.rdbuf()->freeze(0);\
        }\
        catch(...)\
        {\
                cout << "* POMAINT_EVENT_LOG10 * " << endl;\
        }\
    }
#else
    #define POMAINT_TRACE_VERBOSE(X)
    #define POMAINT_TRACE_VERBOSE1(X, aParam1 )
    #define POMAINT_TRACE_VERBOSE2(X, aParam1, aParam2 )
    #define POMAINT_TRACE_VERBOSE3(X, aParam1, aParam2, aParam3 )
    #define POMAINT_TRACE_VERBOSE4(X, aParam1, aParam2, aParam3, aParam4 )
    #define POMAINT_TRACE_VERBOSE5(X, aParam1, aParam2, aParam3, aParam4, aParam5 )
    #define POMAINT_TRACE_VERBOSE6(X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6 )
    #define POMAINT_TRACE_VERBOSE7(X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7 )
    #define POMAINT_TRACE_VERBOSE8(X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7, aParam8 )
    #define POMAINT_TRACE_VERBOSE9(X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7, aParam8, aParam9 )
    #define POMAINT_TRACE_VERBOSE10(X, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7, aParam8, aParam9, aParam10 )
    #define POMAINT_EVENT_LOG1( subLotType, lotID, returnCode, aParam1 )
    #define POMAINT_EVENT_LOG2( subLotType, lotID, returnCode, aParam1, aParam2 )
    #define POMAINT_EVENT_LOG3( subLotType, lotID, returnCode, aParam1, aParam2, aParam3 )
    #define POMAINT_EVENT_LOG4( subLotType, lotID, returnCode, aParam1, aParam2, aParam3, aParam4 )
    #define POMAINT_EVENT_LOG5( subLotType, lotID, returnCode, aParam1, aParam2, aParam3, aParam4, aParam5 )
    #define POMAINT_EVENT_LOG6( subLotType, lotID, returnCode, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6 )
    #define POMAINT_EVENT_LOG7( subLotType, lotID, returnCode, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7 )
    #define POMAINT_EVENT_LOG8( subLotType, lotID, returnCode, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7,aParam8 )
    #define POMAINT_EVENT_LOG9( subLotType, lotID, returnCode, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7,aParam8, aParam9 )
    #define POMAINT_EVENT_LOG10( subLotType, lotID, returnCode, aParam1, aParam2, aParam3, aParam4, aParam5, aParam6, aParam7,aParam8, aParam9, aParam10 )
#endif

#ifndef _AIX
    #define     POMaintSleep( time)\
    {\
        Sleep( time*1000 );\
    }
#else
    #define     POMaintSleep   sleep
#endif

// Macro : CHECK_DB_CONNECTION_ERROR
//
// Description:
//  Check DB connection error
//
#define CHECK_DB_CONNECTION_ERROR( SUBLOTTYPE, LOTID, MSG, SQLCODE, connectFlag )\
if ( SQLCODE == -1024 || SQLCODE == -30081 || SQLCODE == -30108 )\
{\
    POMAINT_EVENT_LOG2( SUBLOTTYPE, LOTID, SQLCODE, MSG, getMessage( MSG_DB_DISCONNECTED ) );\
    connectFlag = 0;\
}\
else if ( SQLCODE != 0 )\
{\
    POMAINT_EVENT_LOG1( SUBLOTTYPE, LOTID, SQLCODE, MSG );\
}

// Macro : DB_CONNECTION_ERROR_RETURN
//
// Description:
//  Check DB connection error return
//
#define CHECK_SQL_DB_CONNECTION_ERROR_RETURN( SUBLOTTYPE, LOTID, FUNCTION, MSG, SQLCODE )\
if ( SQLCODE == -1024 || SQLCODE == -30081 || SQLCODE == -30108 )\
{\
    POMAINT_TRACE_VERBOSE2( 2, FUNCTION, "END" );\
    POMAINT_EVENT_LOG2( SUBLOTTYPE, LOTID, SQLCODE, MSG, getMessage( MSG_DB_DISCONNECTED ) );\
    return RC_DATABASE_CONNECT_ERROR;\
}

// Macro : DB_ERROR_RETURN
//
// Description:
//  Check DB error return
//
#define CHECK_SQL_ERROR_RETURN( SUBLOTTYPE, LOTID, FUNCTION, MSG, SQLCODE )\
{\
    CHECK_SQL_DB_CONNECTION_ERROR_RETURN( SUBLOTTYPE, LOTID, FUNCTION, MSG, SQLCODE )\
    else if ( SQLCODE != 0 )\
    {\
        POMAINT_TRACE_VERBOSE2( 2, FUNCTION, "END" );\
        POMAINT_EVENT_LOG1( SUBLOTTYPE, LOTID, SQLCODE, MSG );\
        return RC_SYSTEM_ERROR;\
    }\
}
