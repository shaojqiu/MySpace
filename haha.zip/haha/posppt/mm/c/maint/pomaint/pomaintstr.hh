//----------------------------------------------------------------------------
//
//  Generated from pomaintstr.idl
//  On Monday, April 10, 2017 6:30:39 PM JST
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _pomaintstr_server_defined
#ifndef _pomaintstr_hh_included
#define _pomaintstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef DB2PW
#define DB2PW
#endif


    class  pomaintInputFileLine_struct_var;
    struct  pomaintInputFileLine_struct {
        typedef pomaintInputFileLine_struct_var _var_type;
       ::CORBA::String_StructElem subLotType;
       ::CORBA::Long keepCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pomaintInputFileLine_struct();
       pomaintInputFileLine_struct(const pomaintInputFileLine_struct&);
       pomaintInputFileLine_struct& operator=(const pomaintInputFileLine_struct&);
       static CORBA::Info<pomaintInputFileLine_struct> pomaintInputFileLine_struct_Info;
   }; // struct pomaintInputFileLine_struct


typedef pomaintInputFileLine_struct* pomaintInputFileLine_struct_vPtr;
typedef const pomaintInputFileLine_struct* pomaintInputFileLine_struct_cvPtr;

class  pomaintInputFileLine_struct_var
{
    public:

    pomaintInputFileLine_struct_var ();

    pomaintInputFileLine_struct_var (pomaintInputFileLine_struct *_p);

    pomaintInputFileLine_struct_var (const pomaintInputFileLine_struct_var &_s);

    pomaintInputFileLine_struct_var &operator= (pomaintInputFileLine_struct *_p);

    pomaintInputFileLine_struct_var &operator= (const pomaintInputFileLine_struct_var &_s);

    ~pomaintInputFileLine_struct_var ();

    pomaintInputFileLine_struct* operator-> ();

    const pomaintInputFileLine_struct& in() const;
    pomaintInputFileLine_struct& inout();
    pomaintInputFileLine_struct*& out();
    pomaintInputFileLine_struct* _retn();

    operator pomaintInputFileLine_struct_cvPtr () const;

    operator pomaintInputFileLine_struct_vPtr& ();

    operator const pomaintInputFileLine_struct& () const;

    operator pomaintInputFileLine_struct& ();

    protected:
    pomaintInputFileLine_struct *_ptr;
};



class  pomaintInputFileLine_struct_out {
 public:
  pomaintInputFileLine_struct_out (pomaintInputFileLine_struct*&  p) : _ptr(p) { _ptr = NULL; }
  pomaintInputFileLine_struct_out (pomaintInputFileLine_struct_var& p) : _ptr(p.out()) {}
  pomaintInputFileLine_struct_out (const pomaintInputFileLine_struct_out& a) : _ptr(a._ptr) {}
  ~pomaintInputFileLine_struct_out () {}
  pomaintInputFileLine_struct_out& operator= (const pomaintInputFileLine_struct_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  pomaintInputFileLine_struct_out& operator= (pomaintInputFileLine_struct*  p) { _ptr = p; return *this; } 
  operator pomaintInputFileLine_struct*&  () { return _ptr; }
  pomaintInputFileLine_struct*&  ptr()       { return _ptr; }
  pomaintInputFileLine_struct*   operator->() { return _ptr; }
 private: 
  pomaintInputFileLine_struct*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const pomaintInputFileLine_struct_var&);
};

    extern  ::CORBA::TypeCode_ptr _tc_pomaintInputFileLine_struct;
    typedef pomaintInputFileLine_struct pomaintInputFileLine;
    typedef pomaintInputFileLine_struct_out pomaintInputFileLine_out;
    typedef pomaintInputFileLine_struct_var pomaintInputFileLine_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintInputFileLine;
class  _IDL_SEQ_pomaintInputFileLineSequence_0_var;
class  _IDL_SEQ_pomaintInputFileLineSequence_0 {
    public:
        typedef _IDL_SEQ_pomaintInputFileLineSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pomaintInputFileLine *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pomaintInputFileLineSequence_0 ();
    _IDL_SEQ_pomaintInputFileLineSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pomaintInputFileLineSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pomaintInputFileLine* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pomaintInputFileLineSequence_0 (const _IDL_SEQ_pomaintInputFileLineSequence_0&);

    ~_IDL_SEQ_pomaintInputFileLineSequence_0 ();

    _IDL_SEQ_pomaintInputFileLineSequence_0& operator= (const _IDL_SEQ_pomaintInputFileLineSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pomaintInputFileLine& operator [] (::CORBA::ULong indx);
    const pomaintInputFileLine& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pomaintInputFileLine* get_buffer (::CORBA::Boolean orphan=0);
    const pomaintInputFileLine* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pomaintInputFileLine* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintInputFileLine* src, pomaintInputFileLine* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintInputFileLine* data); 
  public:

    static pomaintInputFileLine* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pomaintInputFileLine* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pomaintInputFileLine* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pomaintInputFileLineSequence_0> pomaintInputFileLineSequence_0_Info;
};


typedef _IDL_SEQ_pomaintInputFileLineSequence_0* _IDL_SEQ_pomaintInputFileLineSequence_0_vPtr;
typedef const _IDL_SEQ_pomaintInputFileLineSequence_0* _IDL_SEQ_pomaintInputFileLineSequence_0_cvPtr;

class  _IDL_SEQ_pomaintInputFileLineSequence_0_var
{
    public:

    _IDL_SEQ_pomaintInputFileLineSequence_0_var ();

    _IDL_SEQ_pomaintInputFileLineSequence_0_var (_IDL_SEQ_pomaintInputFileLineSequence_0 *_p);

    _IDL_SEQ_pomaintInputFileLineSequence_0_var (const _IDL_SEQ_pomaintInputFileLineSequence_0_var &_s);

    _IDL_SEQ_pomaintInputFileLineSequence_0_var &operator= (_IDL_SEQ_pomaintInputFileLineSequence_0 *_p);

    _IDL_SEQ_pomaintInputFileLineSequence_0_var &operator= (const _IDL_SEQ_pomaintInputFileLineSequence_0_var &_s);

    ~_IDL_SEQ_pomaintInputFileLineSequence_0_var ();

    _IDL_SEQ_pomaintInputFileLineSequence_0* operator-> ();

    operator _IDL_SEQ_pomaintInputFileLineSequence_0_cvPtr () const;

    operator _IDL_SEQ_pomaintInputFileLineSequence_0_vPtr& ();

    operator _IDL_SEQ_pomaintInputFileLineSequence_0() const;

    const pomaintInputFileLine& operator[] (::CORBA::ULong index) const;
    pomaintInputFileLine& operator[] (::CORBA::ULong index);
    const pomaintInputFileLine& operator[] (int index) const;
    pomaintInputFileLine& operator[] (int index);
    const _IDL_SEQ_pomaintInputFileLineSequence_0& in() const;
    _IDL_SEQ_pomaintInputFileLineSequence_0& inout();
    _IDL_SEQ_pomaintInputFileLineSequence_0*& out();
    _IDL_SEQ_pomaintInputFileLineSequence_0* _retn();

    protected:
    _IDL_SEQ_pomaintInputFileLineSequence_0 *_ptr;
};



class  _IDL_SEQ_pomaintInputFileLineSequence_0_out {
 public:
  _IDL_SEQ_pomaintInputFileLineSequence_0_out (_IDL_SEQ_pomaintInputFileLineSequence_0*&  p) : _ptr(p) { _ptr = NULL; }
  _IDL_SEQ_pomaintInputFileLineSequence_0_out (_IDL_SEQ_pomaintInputFileLineSequence_0_var& p) : _ptr(p.out()) {}
  _IDL_SEQ_pomaintInputFileLineSequence_0_out (const _IDL_SEQ_pomaintInputFileLineSequence_0_out& a) : _ptr(a._ptr) {}
  ~_IDL_SEQ_pomaintInputFileLineSequence_0_out () {}
  _IDL_SEQ_pomaintInputFileLineSequence_0_out& operator= (const _IDL_SEQ_pomaintInputFileLineSequence_0_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  _IDL_SEQ_pomaintInputFileLineSequence_0_out& operator= (_IDL_SEQ_pomaintInputFileLineSequence_0*  p) { _ptr = p; return *this; } 
  operator _IDL_SEQ_pomaintInputFileLineSequence_0*&  () { return _ptr; }
  _IDL_SEQ_pomaintInputFileLineSequence_0*&  ptr()       { return _ptr; }
  _IDL_SEQ_pomaintInputFileLineSequence_0*   operator->() { return _ptr; }
 private: 
  _IDL_SEQ_pomaintInputFileLineSequence_0*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const _IDL_SEQ_pomaintInputFileLineSequence_0_var&);
};

    typedef _IDL_SEQ_pomaintInputFileLineSequence_0 _pomaintInputFileLineSequence_seq;
    typedef _IDL_SEQ_pomaintInputFileLineSequence_0 _pomaintInputFileLineSequence_seq_1;
    typedef _IDL_SEQ_pomaintInputFileLineSequence_0 pomaintInputFileLineSequence;
    typedef _IDL_SEQ_pomaintInputFileLineSequence_0_out pomaintInputFileLineSequence_out;
    typedef _IDL_SEQ_pomaintInputFileLineSequence_0_var pomaintInputFileLineSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintInputFileLineSequence;
    class  pomaintEventQueue_struct_var;
    struct  pomaintEventQueue_struct {
        typedef pomaintEventQueue_struct_var _var_type;
       ::CORBA::String_StructElem lotID;
       ::CORBA::String_StructElem updateTime;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pomaintEventQueue_struct();
       pomaintEventQueue_struct(const pomaintEventQueue_struct&);
       pomaintEventQueue_struct& operator=(const pomaintEventQueue_struct&);
       static CORBA::Info<pomaintEventQueue_struct> pomaintEventQueue_struct_Info;
   }; // struct pomaintEventQueue_struct


typedef pomaintEventQueue_struct* pomaintEventQueue_struct_vPtr;
typedef const pomaintEventQueue_struct* pomaintEventQueue_struct_cvPtr;

class  pomaintEventQueue_struct_var
{
    public:

    pomaintEventQueue_struct_var ();

    pomaintEventQueue_struct_var (pomaintEventQueue_struct *_p);

    pomaintEventQueue_struct_var (const pomaintEventQueue_struct_var &_s);

    pomaintEventQueue_struct_var &operator= (pomaintEventQueue_struct *_p);

    pomaintEventQueue_struct_var &operator= (const pomaintEventQueue_struct_var &_s);

    ~pomaintEventQueue_struct_var ();

    pomaintEventQueue_struct* operator-> ();

    const pomaintEventQueue_struct& in() const;
    pomaintEventQueue_struct& inout();
    pomaintEventQueue_struct*& out();
    pomaintEventQueue_struct* _retn();

    operator pomaintEventQueue_struct_cvPtr () const;

    operator pomaintEventQueue_struct_vPtr& ();

    operator const pomaintEventQueue_struct& () const;

    operator pomaintEventQueue_struct& ();

    protected:
    pomaintEventQueue_struct *_ptr;
};



class  pomaintEventQueue_struct_out {
 public:
  pomaintEventQueue_struct_out (pomaintEventQueue_struct*&  p) : _ptr(p) { _ptr = NULL; }
  pomaintEventQueue_struct_out (pomaintEventQueue_struct_var& p) : _ptr(p.out()) {}
  pomaintEventQueue_struct_out (const pomaintEventQueue_struct_out& a) : _ptr(a._ptr) {}
  ~pomaintEventQueue_struct_out () {}
  pomaintEventQueue_struct_out& operator= (const pomaintEventQueue_struct_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  pomaintEventQueue_struct_out& operator= (pomaintEventQueue_struct*  p) { _ptr = p; return *this; } 
  operator pomaintEventQueue_struct*&  () { return _ptr; }
  pomaintEventQueue_struct*&  ptr()       { return _ptr; }
  pomaintEventQueue_struct*   operator->() { return _ptr; }
 private: 
  pomaintEventQueue_struct*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const pomaintEventQueue_struct_var&);
};

    extern  ::CORBA::TypeCode_ptr _tc_pomaintEventQueue_struct;
    typedef pomaintEventQueue_struct pomaintEventQueue;
    typedef pomaintEventQueue_struct_out pomaintEventQueue_out;
    typedef pomaintEventQueue_struct_var pomaintEventQueue_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintEventQueue;
class  _IDL_SEQ_pomaintEventQueueSequence_0_var;
class  _IDL_SEQ_pomaintEventQueueSequence_0 {
    public:
        typedef _IDL_SEQ_pomaintEventQueueSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pomaintEventQueue *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pomaintEventQueueSequence_0 ();
    _IDL_SEQ_pomaintEventQueueSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pomaintEventQueueSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pomaintEventQueue* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pomaintEventQueueSequence_0 (const _IDL_SEQ_pomaintEventQueueSequence_0&);

    ~_IDL_SEQ_pomaintEventQueueSequence_0 ();

    _IDL_SEQ_pomaintEventQueueSequence_0& operator= (const _IDL_SEQ_pomaintEventQueueSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pomaintEventQueue& operator [] (::CORBA::ULong indx);
    const pomaintEventQueue& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pomaintEventQueue* get_buffer (::CORBA::Boolean orphan=0);
    const pomaintEventQueue* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pomaintEventQueue* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintEventQueue* src, pomaintEventQueue* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintEventQueue* data); 
  public:

    static pomaintEventQueue* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pomaintEventQueue* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pomaintEventQueue* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pomaintEventQueueSequence_0> pomaintEventQueueSequence_0_Info;
};


typedef _IDL_SEQ_pomaintEventQueueSequence_0* _IDL_SEQ_pomaintEventQueueSequence_0_vPtr;
typedef const _IDL_SEQ_pomaintEventQueueSequence_0* _IDL_SEQ_pomaintEventQueueSequence_0_cvPtr;

class  _IDL_SEQ_pomaintEventQueueSequence_0_var
{
    public:

    _IDL_SEQ_pomaintEventQueueSequence_0_var ();

    _IDL_SEQ_pomaintEventQueueSequence_0_var (_IDL_SEQ_pomaintEventQueueSequence_0 *_p);

    _IDL_SEQ_pomaintEventQueueSequence_0_var (const _IDL_SEQ_pomaintEventQueueSequence_0_var &_s);

    _IDL_SEQ_pomaintEventQueueSequence_0_var &operator= (_IDL_SEQ_pomaintEventQueueSequence_0 *_p);

    _IDL_SEQ_pomaintEventQueueSequence_0_var &operator= (const _IDL_SEQ_pomaintEventQueueSequence_0_var &_s);

    ~_IDL_SEQ_pomaintEventQueueSequence_0_var ();

    _IDL_SEQ_pomaintEventQueueSequence_0* operator-> ();

    operator _IDL_SEQ_pomaintEventQueueSequence_0_cvPtr () const;

    operator _IDL_SEQ_pomaintEventQueueSequence_0_vPtr& ();

    operator _IDL_SEQ_pomaintEventQueueSequence_0() const;

    const pomaintEventQueue& operator[] (::CORBA::ULong index) const;
    pomaintEventQueue& operator[] (::CORBA::ULong index);
    const pomaintEventQueue& operator[] (int index) const;
    pomaintEventQueue& operator[] (int index);
    const _IDL_SEQ_pomaintEventQueueSequence_0& in() const;
    _IDL_SEQ_pomaintEventQueueSequence_0& inout();
    _IDL_SEQ_pomaintEventQueueSequence_0*& out();
    _IDL_SEQ_pomaintEventQueueSequence_0* _retn();

    protected:
    _IDL_SEQ_pomaintEventQueueSequence_0 *_ptr;
};



class  _IDL_SEQ_pomaintEventQueueSequence_0_out {
 public:
  _IDL_SEQ_pomaintEventQueueSequence_0_out (_IDL_SEQ_pomaintEventQueueSequence_0*&  p) : _ptr(p) { _ptr = NULL; }
  _IDL_SEQ_pomaintEventQueueSequence_0_out (_IDL_SEQ_pomaintEventQueueSequence_0_var& p) : _ptr(p.out()) {}
  _IDL_SEQ_pomaintEventQueueSequence_0_out (const _IDL_SEQ_pomaintEventQueueSequence_0_out& a) : _ptr(a._ptr) {}
  ~_IDL_SEQ_pomaintEventQueueSequence_0_out () {}
  _IDL_SEQ_pomaintEventQueueSequence_0_out& operator= (const _IDL_SEQ_pomaintEventQueueSequence_0_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  _IDL_SEQ_pomaintEventQueueSequence_0_out& operator= (_IDL_SEQ_pomaintEventQueueSequence_0*  p) { _ptr = p; return *this; } 
  operator _IDL_SEQ_pomaintEventQueueSequence_0*&  () { return _ptr; }
  _IDL_SEQ_pomaintEventQueueSequence_0*&  ptr()       { return _ptr; }
  _IDL_SEQ_pomaintEventQueueSequence_0*   operator->() { return _ptr; }
 private: 
  _IDL_SEQ_pomaintEventQueueSequence_0*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const _IDL_SEQ_pomaintEventQueueSequence_0_var&);
};

    typedef _IDL_SEQ_pomaintEventQueueSequence_0 _pomaintEventQueueSequence_seq;
    typedef _IDL_SEQ_pomaintEventQueueSequence_0 _pomaintEventQueueSequence_seq_1;
    typedef _IDL_SEQ_pomaintEventQueueSequence_0 pomaintEventQueueSequence;
    typedef _IDL_SEQ_pomaintEventQueueSequence_0_out pomaintEventQueueSequence_out;
    typedef _IDL_SEQ_pomaintEventQueueSequence_0_var pomaintEventQueueSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintEventQueueSequence;
    class  pomaintLotInf_struct_var;
    struct  pomaintLotInf_struct {
        typedef pomaintLotInf_struct_var _var_type;
       ::CORBA::String_StructElem lotID;
       ::CORBA::String_StructElem subLotType;
       ::CORBA::String_StructElem lotState;
       ::CORBA::String_StructElem lotFinishedState;
       ::CORBA::String_StructElem claimTime;
       ::CORBA::String_StructElem pfxObj;
       ::CORBA::String_StructElem pfxKey;
       ::CORBA::String_StructElem splitLotID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pomaintLotInf_struct();
       pomaintLotInf_struct(const pomaintLotInf_struct&);
       pomaintLotInf_struct& operator=(const pomaintLotInf_struct&);
       static CORBA::Info<pomaintLotInf_struct> pomaintLotInf_struct_Info;
   }; // struct pomaintLotInf_struct


typedef pomaintLotInf_struct* pomaintLotInf_struct_vPtr;
typedef const pomaintLotInf_struct* pomaintLotInf_struct_cvPtr;

class  pomaintLotInf_struct_var
{
    public:

    pomaintLotInf_struct_var ();

    pomaintLotInf_struct_var (pomaintLotInf_struct *_p);

    pomaintLotInf_struct_var (const pomaintLotInf_struct_var &_s);

    pomaintLotInf_struct_var &operator= (pomaintLotInf_struct *_p);

    pomaintLotInf_struct_var &operator= (const pomaintLotInf_struct_var &_s);

    ~pomaintLotInf_struct_var ();

    pomaintLotInf_struct* operator-> ();

    const pomaintLotInf_struct& in() const;
    pomaintLotInf_struct& inout();
    pomaintLotInf_struct*& out();
    pomaintLotInf_struct* _retn();

    operator pomaintLotInf_struct_cvPtr () const;

    operator pomaintLotInf_struct_vPtr& ();

    operator const pomaintLotInf_struct& () const;

    operator pomaintLotInf_struct& ();

    protected:
    pomaintLotInf_struct *_ptr;
};



class  pomaintLotInf_struct_out {
 public:
  pomaintLotInf_struct_out (pomaintLotInf_struct*&  p) : _ptr(p) { _ptr = NULL; }
  pomaintLotInf_struct_out (pomaintLotInf_struct_var& p) : _ptr(p.out()) {}
  pomaintLotInf_struct_out (const pomaintLotInf_struct_out& a) : _ptr(a._ptr) {}
  ~pomaintLotInf_struct_out () {}
  pomaintLotInf_struct_out& operator= (const pomaintLotInf_struct_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  pomaintLotInf_struct_out& operator= (pomaintLotInf_struct*  p) { _ptr = p; return *this; } 
  operator pomaintLotInf_struct*&  () { return _ptr; }
  pomaintLotInf_struct*&  ptr()       { return _ptr; }
  pomaintLotInf_struct*   operator->() { return _ptr; }
 private: 
  pomaintLotInf_struct*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const pomaintLotInf_struct_var&);
};

    extern  ::CORBA::TypeCode_ptr _tc_pomaintLotInf_struct;
    typedef pomaintLotInf_struct pomaintLotInf;
    typedef pomaintLotInf_struct_out pomaintLotInf_out;
    typedef pomaintLotInf_struct_var pomaintLotInf_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintLotInf;
class  _IDL_SEQ_pomaintLotInfSequence_0_var;
class  _IDL_SEQ_pomaintLotInfSequence_0 {
    public:
        typedef _IDL_SEQ_pomaintLotInfSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pomaintLotInf *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pomaintLotInfSequence_0 ();
    _IDL_SEQ_pomaintLotInfSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pomaintLotInfSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pomaintLotInf* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pomaintLotInfSequence_0 (const _IDL_SEQ_pomaintLotInfSequence_0&);

    ~_IDL_SEQ_pomaintLotInfSequence_0 ();

    _IDL_SEQ_pomaintLotInfSequence_0& operator= (const _IDL_SEQ_pomaintLotInfSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pomaintLotInf& operator [] (::CORBA::ULong indx);
    const pomaintLotInf& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pomaintLotInf* get_buffer (::CORBA::Boolean orphan=0);
    const pomaintLotInf* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pomaintLotInf* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintLotInf* src, pomaintLotInf* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintLotInf* data); 
  public:

    static pomaintLotInf* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pomaintLotInf* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pomaintLotInf* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pomaintLotInfSequence_0> pomaintLotInfSequence_0_Info;
};


typedef _IDL_SEQ_pomaintLotInfSequence_0* _IDL_SEQ_pomaintLotInfSequence_0_vPtr;
typedef const _IDL_SEQ_pomaintLotInfSequence_0* _IDL_SEQ_pomaintLotInfSequence_0_cvPtr;

class  _IDL_SEQ_pomaintLotInfSequence_0_var
{
    public:

    _IDL_SEQ_pomaintLotInfSequence_0_var ();

    _IDL_SEQ_pomaintLotInfSequence_0_var (_IDL_SEQ_pomaintLotInfSequence_0 *_p);

    _IDL_SEQ_pomaintLotInfSequence_0_var (const _IDL_SEQ_pomaintLotInfSequence_0_var &_s);

    _IDL_SEQ_pomaintLotInfSequence_0_var &operator= (_IDL_SEQ_pomaintLotInfSequence_0 *_p);

    _IDL_SEQ_pomaintLotInfSequence_0_var &operator= (const _IDL_SEQ_pomaintLotInfSequence_0_var &_s);

    ~_IDL_SEQ_pomaintLotInfSequence_0_var ();

    _IDL_SEQ_pomaintLotInfSequence_0* operator-> ();

    operator _IDL_SEQ_pomaintLotInfSequence_0_cvPtr () const;

    operator _IDL_SEQ_pomaintLotInfSequence_0_vPtr& ();

    operator _IDL_SEQ_pomaintLotInfSequence_0() const;

    const pomaintLotInf& operator[] (::CORBA::ULong index) const;
    pomaintLotInf& operator[] (::CORBA::ULong index);
    const pomaintLotInf& operator[] (int index) const;
    pomaintLotInf& operator[] (int index);
    const _IDL_SEQ_pomaintLotInfSequence_0& in() const;
    _IDL_SEQ_pomaintLotInfSequence_0& inout();
    _IDL_SEQ_pomaintLotInfSequence_0*& out();
    _IDL_SEQ_pomaintLotInfSequence_0* _retn();

    protected:
    _IDL_SEQ_pomaintLotInfSequence_0 *_ptr;
};



class  _IDL_SEQ_pomaintLotInfSequence_0_out {
 public:
  _IDL_SEQ_pomaintLotInfSequence_0_out (_IDL_SEQ_pomaintLotInfSequence_0*&  p) : _ptr(p) { _ptr = NULL; }
  _IDL_SEQ_pomaintLotInfSequence_0_out (_IDL_SEQ_pomaintLotInfSequence_0_var& p) : _ptr(p.out()) {}
  _IDL_SEQ_pomaintLotInfSequence_0_out (const _IDL_SEQ_pomaintLotInfSequence_0_out& a) : _ptr(a._ptr) {}
  ~_IDL_SEQ_pomaintLotInfSequence_0_out () {}
  _IDL_SEQ_pomaintLotInfSequence_0_out& operator= (const _IDL_SEQ_pomaintLotInfSequence_0_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  _IDL_SEQ_pomaintLotInfSequence_0_out& operator= (_IDL_SEQ_pomaintLotInfSequence_0*  p) { _ptr = p; return *this; } 
  operator _IDL_SEQ_pomaintLotInfSequence_0*&  () { return _ptr; }
  _IDL_SEQ_pomaintLotInfSequence_0*&  ptr()       { return _ptr; }
  _IDL_SEQ_pomaintLotInfSequence_0*   operator->() { return _ptr; }
 private: 
  _IDL_SEQ_pomaintLotInfSequence_0*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const _IDL_SEQ_pomaintLotInfSequence_0_var&);
};

    typedef _IDL_SEQ_pomaintLotInfSequence_0 _pomaintLotInfSequence_seq;
    typedef _IDL_SEQ_pomaintLotInfSequence_0 _pomaintLotInfSequence_seq_1;
    typedef _IDL_SEQ_pomaintLotInfSequence_0 pomaintLotInfSequence;
    typedef _IDL_SEQ_pomaintLotInfSequence_0_out pomaintLotInfSequence_out;
    typedef _IDL_SEQ_pomaintLotInfSequence_0_var pomaintLotInfSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintLotInfSequence;
    class  pomaintPOInf_struct_var;
    struct  pomaintPOInf_struct {
        typedef pomaintPOInf_struct_var _var_type;
       ::CORBA::String_StructElem poObj;
       ::CORBA::String_StructElem poKey;
       ::CORBA::Long seqNo;
       ::CORBA::Long refCnt;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pomaintPOInf_struct();
       pomaintPOInf_struct(const pomaintPOInf_struct&);
       pomaintPOInf_struct& operator=(const pomaintPOInf_struct&);
       static CORBA::Info<pomaintPOInf_struct> pomaintPOInf_struct_Info;
   }; // struct pomaintPOInf_struct


typedef pomaintPOInf_struct* pomaintPOInf_struct_vPtr;
typedef const pomaintPOInf_struct* pomaintPOInf_struct_cvPtr;

class  pomaintPOInf_struct_var
{
    public:

    pomaintPOInf_struct_var ();

    pomaintPOInf_struct_var (pomaintPOInf_struct *_p);

    pomaintPOInf_struct_var (const pomaintPOInf_struct_var &_s);

    pomaintPOInf_struct_var &operator= (pomaintPOInf_struct *_p);

    pomaintPOInf_struct_var &operator= (const pomaintPOInf_struct_var &_s);

    ~pomaintPOInf_struct_var ();

    pomaintPOInf_struct* operator-> ();

    const pomaintPOInf_struct& in() const;
    pomaintPOInf_struct& inout();
    pomaintPOInf_struct*& out();
    pomaintPOInf_struct* _retn();

    operator pomaintPOInf_struct_cvPtr () const;

    operator pomaintPOInf_struct_vPtr& ();

    operator const pomaintPOInf_struct& () const;

    operator pomaintPOInf_struct& ();

    protected:
    pomaintPOInf_struct *_ptr;
};



class  pomaintPOInf_struct_out {
 public:
  pomaintPOInf_struct_out (pomaintPOInf_struct*&  p) : _ptr(p) { _ptr = NULL; }
  pomaintPOInf_struct_out (pomaintPOInf_struct_var& p) : _ptr(p.out()) {}
  pomaintPOInf_struct_out (const pomaintPOInf_struct_out& a) : _ptr(a._ptr) {}
  ~pomaintPOInf_struct_out () {}
  pomaintPOInf_struct_out& operator= (const pomaintPOInf_struct_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  pomaintPOInf_struct_out& operator= (pomaintPOInf_struct*  p) { _ptr = p; return *this; } 
  operator pomaintPOInf_struct*&  () { return _ptr; }
  pomaintPOInf_struct*&  ptr()       { return _ptr; }
  pomaintPOInf_struct*   operator->() { return _ptr; }
 private: 
  pomaintPOInf_struct*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const pomaintPOInf_struct_var&);
};

    extern  ::CORBA::TypeCode_ptr _tc_pomaintPOInf_struct;
    typedef pomaintPOInf_struct pomaintPOInf;
    typedef pomaintPOInf_struct_out pomaintPOInf_out;
    typedef pomaintPOInf_struct_var pomaintPOInf_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintPOInf;
class  _IDL_SEQ_pomaintPOInfSequence_0_var;
class  _IDL_SEQ_pomaintPOInfSequence_0 {
    public:
        typedef _IDL_SEQ_pomaintPOInfSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pomaintPOInf *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pomaintPOInfSequence_0 ();
    _IDL_SEQ_pomaintPOInfSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pomaintPOInfSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pomaintPOInf* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pomaintPOInfSequence_0 (const _IDL_SEQ_pomaintPOInfSequence_0&);

    ~_IDL_SEQ_pomaintPOInfSequence_0 ();

    _IDL_SEQ_pomaintPOInfSequence_0& operator= (const _IDL_SEQ_pomaintPOInfSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pomaintPOInf& operator [] (::CORBA::ULong indx);
    const pomaintPOInf& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pomaintPOInf* get_buffer (::CORBA::Boolean orphan=0);
    const pomaintPOInf* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pomaintPOInf* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintPOInf* src, pomaintPOInf* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintPOInf* data); 
  public:

    static pomaintPOInf* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pomaintPOInf* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pomaintPOInf* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pomaintPOInfSequence_0> pomaintPOInfSequence_0_Info;
};


typedef _IDL_SEQ_pomaintPOInfSequence_0* _IDL_SEQ_pomaintPOInfSequence_0_vPtr;
typedef const _IDL_SEQ_pomaintPOInfSequence_0* _IDL_SEQ_pomaintPOInfSequence_0_cvPtr;

class  _IDL_SEQ_pomaintPOInfSequence_0_var
{
    public:

    _IDL_SEQ_pomaintPOInfSequence_0_var ();

    _IDL_SEQ_pomaintPOInfSequence_0_var (_IDL_SEQ_pomaintPOInfSequence_0 *_p);

    _IDL_SEQ_pomaintPOInfSequence_0_var (const _IDL_SEQ_pomaintPOInfSequence_0_var &_s);

    _IDL_SEQ_pomaintPOInfSequence_0_var &operator= (_IDL_SEQ_pomaintPOInfSequence_0 *_p);

    _IDL_SEQ_pomaintPOInfSequence_0_var &operator= (const _IDL_SEQ_pomaintPOInfSequence_0_var &_s);

    ~_IDL_SEQ_pomaintPOInfSequence_0_var ();

    _IDL_SEQ_pomaintPOInfSequence_0* operator-> ();

    operator _IDL_SEQ_pomaintPOInfSequence_0_cvPtr () const;

    operator _IDL_SEQ_pomaintPOInfSequence_0_vPtr& ();

    operator _IDL_SEQ_pomaintPOInfSequence_0() const;

    const pomaintPOInf& operator[] (::CORBA::ULong index) const;
    pomaintPOInf& operator[] (::CORBA::ULong index);
    const pomaintPOInf& operator[] (int index) const;
    pomaintPOInf& operator[] (int index);
    const _IDL_SEQ_pomaintPOInfSequence_0& in() const;
    _IDL_SEQ_pomaintPOInfSequence_0& inout();
    _IDL_SEQ_pomaintPOInfSequence_0*& out();
    _IDL_SEQ_pomaintPOInfSequence_0* _retn();

    protected:
    _IDL_SEQ_pomaintPOInfSequence_0 *_ptr;
};



class  _IDL_SEQ_pomaintPOInfSequence_0_out {
 public:
  _IDL_SEQ_pomaintPOInfSequence_0_out (_IDL_SEQ_pomaintPOInfSequence_0*&  p) : _ptr(p) { _ptr = NULL; }
  _IDL_SEQ_pomaintPOInfSequence_0_out (_IDL_SEQ_pomaintPOInfSequence_0_var& p) : _ptr(p.out()) {}
  _IDL_SEQ_pomaintPOInfSequence_0_out (const _IDL_SEQ_pomaintPOInfSequence_0_out& a) : _ptr(a._ptr) {}
  ~_IDL_SEQ_pomaintPOInfSequence_0_out () {}
  _IDL_SEQ_pomaintPOInfSequence_0_out& operator= (const _IDL_SEQ_pomaintPOInfSequence_0_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  _IDL_SEQ_pomaintPOInfSequence_0_out& operator= (_IDL_SEQ_pomaintPOInfSequence_0*  p) { _ptr = p; return *this; } 
  operator _IDL_SEQ_pomaintPOInfSequence_0*&  () { return _ptr; }
  _IDL_SEQ_pomaintPOInfSequence_0*&  ptr()       { return _ptr; }
  _IDL_SEQ_pomaintPOInfSequence_0*   operator->() { return _ptr; }
 private: 
  _IDL_SEQ_pomaintPOInfSequence_0*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const _IDL_SEQ_pomaintPOInfSequence_0_var&);
};

    typedef _IDL_SEQ_pomaintPOInfSequence_0 _pomaintPOInfSequence_seq;
    typedef _IDL_SEQ_pomaintPOInfSequence_0 _pomaintPOInfSequence_seq_1;
    typedef _IDL_SEQ_pomaintPOInfSequence_0 pomaintPOInfSequence;
    typedef _IDL_SEQ_pomaintPOInfSequence_0_out pomaintPOInfSequence_out;
    typedef _IDL_SEQ_pomaintPOInfSequence_0_var pomaintPOInfSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintPOInfSequence;
    class  pomaintPODetailInf_struct_var;
    struct  pomaintPODetailInf_struct {
        typedef pomaintPODetailInf_struct_var _var_type;
       ::CORBA::String_StructElem poObj;
       ::CORBA::String_StructElem pfObj;
       ::CORBA::String_StructElem opeNo;
       ::CORBA::String_StructElem mainPdID;
       ::CORBA::Long passCount;
       ::CORBA::String_StructElem modulePfObj;
       ::CORBA::String_StructElem moduleOpeNo;
       ::CORBA::String_StructElem modulePdID;
       ::CORBA::String_StructElem moduleNo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pomaintPODetailInf_struct();
       pomaintPODetailInf_struct(const pomaintPODetailInf_struct&);
       pomaintPODetailInf_struct& operator=(const pomaintPODetailInf_struct&);
       static CORBA::Info<pomaintPODetailInf_struct> pomaintPODetailInf_struct_Info;
   }; // struct pomaintPODetailInf_struct


typedef pomaintPODetailInf_struct* pomaintPODetailInf_struct_vPtr;
typedef const pomaintPODetailInf_struct* pomaintPODetailInf_struct_cvPtr;

class  pomaintPODetailInf_struct_var
{
    public:

    pomaintPODetailInf_struct_var ();

    pomaintPODetailInf_struct_var (pomaintPODetailInf_struct *_p);

    pomaintPODetailInf_struct_var (const pomaintPODetailInf_struct_var &_s);

    pomaintPODetailInf_struct_var &operator= (pomaintPODetailInf_struct *_p);

    pomaintPODetailInf_struct_var &operator= (const pomaintPODetailInf_struct_var &_s);

    ~pomaintPODetailInf_struct_var ();

    pomaintPODetailInf_struct* operator-> ();

    const pomaintPODetailInf_struct& in() const;
    pomaintPODetailInf_struct& inout();
    pomaintPODetailInf_struct*& out();
    pomaintPODetailInf_struct* _retn();

    operator pomaintPODetailInf_struct_cvPtr () const;

    operator pomaintPODetailInf_struct_vPtr& ();

    operator const pomaintPODetailInf_struct& () const;

    operator pomaintPODetailInf_struct& ();

    protected:
    pomaintPODetailInf_struct *_ptr;
};



class  pomaintPODetailInf_struct_out {
 public:
  pomaintPODetailInf_struct_out (pomaintPODetailInf_struct*&  p) : _ptr(p) { _ptr = NULL; }
  pomaintPODetailInf_struct_out (pomaintPODetailInf_struct_var& p) : _ptr(p.out()) {}
  pomaintPODetailInf_struct_out (const pomaintPODetailInf_struct_out& a) : _ptr(a._ptr) {}
  ~pomaintPODetailInf_struct_out () {}
  pomaintPODetailInf_struct_out& operator= (const pomaintPODetailInf_struct_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  pomaintPODetailInf_struct_out& operator= (pomaintPODetailInf_struct*  p) { _ptr = p; return *this; } 
  operator pomaintPODetailInf_struct*&  () { return _ptr; }
  pomaintPODetailInf_struct*&  ptr()       { return _ptr; }
  pomaintPODetailInf_struct*   operator->() { return _ptr; }
 private: 
  pomaintPODetailInf_struct*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const pomaintPODetailInf_struct_var&);
};

    extern  ::CORBA::TypeCode_ptr _tc_pomaintPODetailInf_struct;
    typedef pomaintPODetailInf_struct pomaintPODetailInf;
    typedef pomaintPODetailInf_struct_out pomaintPODetailInf_out;
    typedef pomaintPODetailInf_struct_var pomaintPODetailInf_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintPODetailInf;
class  _IDL_SEQ_pomaintPODetailInfSequence_0_var;
class  _IDL_SEQ_pomaintPODetailInfSequence_0 {
    public:
        typedef _IDL_SEQ_pomaintPODetailInfSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pomaintPODetailInf *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pomaintPODetailInfSequence_0 ();
    _IDL_SEQ_pomaintPODetailInfSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pomaintPODetailInfSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pomaintPODetailInf* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pomaintPODetailInfSequence_0 (const _IDL_SEQ_pomaintPODetailInfSequence_0&);

    ~_IDL_SEQ_pomaintPODetailInfSequence_0 ();

    _IDL_SEQ_pomaintPODetailInfSequence_0& operator= (const _IDL_SEQ_pomaintPODetailInfSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pomaintPODetailInf& operator [] (::CORBA::ULong indx);
    const pomaintPODetailInf& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pomaintPODetailInf* get_buffer (::CORBA::Boolean orphan=0);
    const pomaintPODetailInf* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pomaintPODetailInf* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintPODetailInf* src, pomaintPODetailInf* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pomaintPODetailInf* data); 
  public:

    static pomaintPODetailInf* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pomaintPODetailInf* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pomaintPODetailInf* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pomaintPODetailInfSequence_0> pomaintPODetailInfSequence_0_Info;
};


typedef _IDL_SEQ_pomaintPODetailInfSequence_0* _IDL_SEQ_pomaintPODetailInfSequence_0_vPtr;
typedef const _IDL_SEQ_pomaintPODetailInfSequence_0* _IDL_SEQ_pomaintPODetailInfSequence_0_cvPtr;

class  _IDL_SEQ_pomaintPODetailInfSequence_0_var
{
    public:

    _IDL_SEQ_pomaintPODetailInfSequence_0_var ();

    _IDL_SEQ_pomaintPODetailInfSequence_0_var (_IDL_SEQ_pomaintPODetailInfSequence_0 *_p);

    _IDL_SEQ_pomaintPODetailInfSequence_0_var (const _IDL_SEQ_pomaintPODetailInfSequence_0_var &_s);

    _IDL_SEQ_pomaintPODetailInfSequence_0_var &operator= (_IDL_SEQ_pomaintPODetailInfSequence_0 *_p);

    _IDL_SEQ_pomaintPODetailInfSequence_0_var &operator= (const _IDL_SEQ_pomaintPODetailInfSequence_0_var &_s);

    ~_IDL_SEQ_pomaintPODetailInfSequence_0_var ();

    _IDL_SEQ_pomaintPODetailInfSequence_0* operator-> ();

    operator _IDL_SEQ_pomaintPODetailInfSequence_0_cvPtr () const;

    operator _IDL_SEQ_pomaintPODetailInfSequence_0_vPtr& ();

    operator _IDL_SEQ_pomaintPODetailInfSequence_0() const;

    const pomaintPODetailInf& operator[] (::CORBA::ULong index) const;
    pomaintPODetailInf& operator[] (::CORBA::ULong index);
    const pomaintPODetailInf& operator[] (int index) const;
    pomaintPODetailInf& operator[] (int index);
    const _IDL_SEQ_pomaintPODetailInfSequence_0& in() const;
    _IDL_SEQ_pomaintPODetailInfSequence_0& inout();
    _IDL_SEQ_pomaintPODetailInfSequence_0*& out();
    _IDL_SEQ_pomaintPODetailInfSequence_0* _retn();

    protected:
    _IDL_SEQ_pomaintPODetailInfSequence_0 *_ptr;
};



class  _IDL_SEQ_pomaintPODetailInfSequence_0_out {
 public:
  _IDL_SEQ_pomaintPODetailInfSequence_0_out (_IDL_SEQ_pomaintPODetailInfSequence_0*&  p) : _ptr(p) { _ptr = NULL; }
  _IDL_SEQ_pomaintPODetailInfSequence_0_out (_IDL_SEQ_pomaintPODetailInfSequence_0_var& p) : _ptr(p.out()) {}
  _IDL_SEQ_pomaintPODetailInfSequence_0_out (const _IDL_SEQ_pomaintPODetailInfSequence_0_out& a) : _ptr(a._ptr) {}
  ~_IDL_SEQ_pomaintPODetailInfSequence_0_out () {}
  _IDL_SEQ_pomaintPODetailInfSequence_0_out& operator= (const _IDL_SEQ_pomaintPODetailInfSequence_0_out& a) { 
    _ptr = a._ptr;  return *this; 
  }
  _IDL_SEQ_pomaintPODetailInfSequence_0_out& operator= (_IDL_SEQ_pomaintPODetailInfSequence_0*  p) { _ptr = p; return *this; } 
  operator _IDL_SEQ_pomaintPODetailInfSequence_0*&  () { return _ptr; }
  _IDL_SEQ_pomaintPODetailInfSequence_0*&  ptr()       { return _ptr; }
  _IDL_SEQ_pomaintPODetailInfSequence_0*   operator->() { return _ptr; }
 private: 
  _IDL_SEQ_pomaintPODetailInfSequence_0*& _ptr;
  // assignment from _var is intentionally not allowed
  void operator=(const _IDL_SEQ_pomaintPODetailInfSequence_0_var&);
};

    typedef _IDL_SEQ_pomaintPODetailInfSequence_0 _pomaintPODetailInfSequence_seq;
    typedef _IDL_SEQ_pomaintPODetailInfSequence_0 _pomaintPODetailInfSequence_seq_1;
    typedef _IDL_SEQ_pomaintPODetailInfSequence_0 pomaintPODetailInfSequence;
    typedef _IDL_SEQ_pomaintPODetailInfSequence_0_out pomaintPODetailInfSequence_out;
    typedef _IDL_SEQ_pomaintPODetailInfSequence_0_var pomaintPODetailInfSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pomaintPODetailInfSequence;
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_pomaintstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_pomaintstr_ANYOPERATOR__
#undef __NOTUSE_pomaintstr_ANYOPERATOR__
#endif //__USE_pomaintstr_ANYOPERATOR__
#ifndef __NOTUSE_pomaintstr_ANYOPERATOR__
#define _DCL_ANYOPS_pomaintInputFileLine_struct
#define _DCL_ANYOPS_pomaintInputFileLineSequence
#define _DCL_ANYOPS_pomaintEventQueue_struct
#define _DCL_ANYOPS_pomaintEventQueueSequence
#define _DCL_ANYOPS_pomaintLotInf_struct
#define _DCL_ANYOPS_pomaintLotInfSequence
#define _DCL_ANYOPS_pomaintPOInf_struct
#define _DCL_ANYOPS_pomaintPOInfSequence
#define _DCL_ANYOPS_pomaintPODetailInf_struct
#define _DCL_ANYOPS_pomaintPODetailInfSequence
#endif //__NOTUSE_pomaintstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_pomaintInputFileLine_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintInputFileLine_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintInputFileLine_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintInputFileLine_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintInputFileLine_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintInputFileLine_struct
#ifdef _DCL_ANYOPS_pomaintInputFileLineSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintInputFileLineSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintInputFileLineSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintInputFileLineSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintInputFileLineSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintInputFileLineSequence
#ifdef _DCL_ANYOPS_pomaintEventQueue_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintEventQueue_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintEventQueue_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintEventQueue_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintEventQueue_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintEventQueue_struct
#ifdef _DCL_ANYOPS_pomaintEventQueueSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintEventQueueSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintEventQueueSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintEventQueueSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintEventQueueSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintEventQueueSequence
#ifdef _DCL_ANYOPS_pomaintLotInf_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintLotInf_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintLotInf_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintLotInf_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintLotInf_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintLotInf_struct
#ifdef _DCL_ANYOPS_pomaintLotInfSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintLotInfSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintLotInfSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintLotInfSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintLotInfSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintLotInfSequence
#ifdef _DCL_ANYOPS_pomaintPOInf_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintPOInf_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintPOInf_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintPOInf_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintPOInf_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintPOInf_struct
#ifdef _DCL_ANYOPS_pomaintPOInfSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintPOInfSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintPOInfSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintPOInfSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintPOInfSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintPOInfSequence
#ifdef _DCL_ANYOPS_pomaintPODetailInf_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintPODetailInf_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintPODetailInf_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintPODetailInf_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintPODetailInf_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintPODetailInf_struct
#ifdef _DCL_ANYOPS_pomaintPODetailInfSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pomaintPODetailInfSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pomaintPODetailInfSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pomaintPODetailInfSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pomaintPODetailInfSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pomaintPODetailInfSequence

#endif /* _pomaintstr_hh_included */

#endif /* _pomaintstr_server_defined */
