/*****************************************************************************
**
**  System      : SiView Standard Management of Process Flow Data Program
**
**  Module name : pfmaintmacros.hpp
**
**  Description : Management of Process Flow Data Program Macros Define hesder
**
** (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
** (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
**
** Change history:
** Date       Defect#      Person         Comments
** ---------- ------------ -------------- -------------------------------------------
** 2012/04/17 DSN000041091 K.Yamaoku      Garbage Main POS Maintenance
**
*****************************************************************************/
#ifndef PFMAINTMACROS_HPP

// Macro : PFMaintSleep
//
// Description:
//
//
#ifndef _AIX
    #define     PFMaintSleep( time)\
    {\
        Sleep( time*1000 );\
    }
#else
    #define     PFMaintSleep   sleep
#endif

// Macro : PFMaintExtendSequence
//
// Description:
//
//

#define PFMaintExtendSequence( sequence, extendCount, totalLen, dataCount )\
{\
    if( dataCount >= totalLen )\
    {\
        totalLen += extendCount;\
        sequence.length( totalLen );\
    }\
}

// Macro : CATCH_TX_EXCEPTION
//
// Description:
//
//

#define CATCH_TX_EXCEPTION( method, otsmethod, exception )\
catch ( CosTransactions::exception& ex)\
{ \
    cout << "CosTransactions::exception :" << (const CORBA::Exception )ex << endl;\
    cout << "Method ID : " << #method << "OTS Method : " << #otsmethod <<endl;\
}

// Macro : CATCH_TX_SYSTEM_EXCEPTION
//
// Description:
//
//

#define CATCH_TX_SYSTEM_EXCEPTION( method, otsmethod)\
catch (const CORBA::SystemException& SysEx)\
{\
    try\
    {\
        CosTransactions::Current::rollback();\
    }\
    catch(...)\
    {\
    }\
    cout << "const CORBA::SystemException :" << (const CORBA::Exception )SysEx << endl;\
    cout << "Method ID : " << #method << "OTS Method : " << #otsmethod <<endl;\
}

// Macro : CATCH_TX_UNKNOWN_EXCEPTION
//
// Description:
//
//

#define CATCH_TX_UNKNOWN_EXCEPTION( method, otsmethod)\
catch (...)\
{ \
    try\
    {\
        CosTransactions::Current::rollback();\
    }\
    catch(...)\
    {\
    }\
    cout << "CosTransactions::exception " << endl;\
    cout << "Method ID : " << #method << "OTS Method : " << #otsmethod <<endl;\
}

// Macro : CATCH_AND_THROW_TX_EXCEPTION
//
// Description:
//

#define CATCH_AND_THROW_TX_EXCEPTION( method, otsmethod, exception )\
catch ( CosTransactions::exception& ex)\
{ \
    cout << "CosTransactions::exception :" << (const CORBA::Exception )ex << endl;\
    cout << "Method ID : " << #method << "OTS Method : " << #otsmethod <<endl;\
    throw; \
}


// Macro : CATCH_AND_THROW_TX_SYSTEM_EXCEPTION
//
// Description:
//

#define CATCH_AND_THROW_TX_SYSTEM_EXCEPTION( method, otsmethod)\
catch (const CORBA::SystemException& SysEx)\
{\
    try\
    {\
        CosTransactions::Current::rollback();\
    }\
    catch(...)\
    {\
    }\
    cout << "const CORBA::SystemException :" << (const CORBA::Exception )SysEx << endl;\
    cout << "Method ID : " << #method << "OTS Method : " << #otsmethod <<endl;\
    throw; \
}

// Macro : CATCH_AND_THROW_TX_UNKNOWN_EXCEPTION
//
// Description:
//
//

#define CATCH_AND_THROW_TX_UNKNOWN_EXCEPTION( method, otsmethod)\
catch (...)\
{ \
    try\
    {\
        CosTransactions::Current::rollback();\
    }\
    catch(...)\
    {\
    }\
    cout << "CosTransactions::exception " << endl;\
    cout << "Method ID : " << #method << "OTS Method : " << #otsmethod <<endl;\
    throw; \
}


// Macro : CATCH_TX_BEGIN_EXCEPTIONS
//
// Description:
//
//

#define CATCH_TX_BEGIN_EXCEPTIONS( method )\
CATCH_TX_EXCEPTION( method , BEGIN , SubtransactionsUnavailable)\
CATCH_TX_SYSTEM_EXCEPTION( method, BEGIN)\
CATCH_TX_UNKNOWN_EXCEPTION( method, BEGIN ) 


// Macro : CATCH_TX_COMMIT_EXCEPTIONS
//
// Description:
//
//

#define CATCH_TX_COMMIT_EXCEPTIONS( method )\
CATCH_AND_THROW_TX_EXCEPTION( method, COMMIT, TransactionRolledBack)\
CATCH_AND_THROW_TX_EXCEPTION( method, COMMIT, NoTransaction        )\
CATCH_AND_THROW_TX_EXCEPTION( method, COMMIT, HeuristicMixed       )\
CATCH_AND_THROW_TX_EXCEPTION( method, COMMIT, HeuristicHazard      )\
CATCH_AND_THROW_TX_SYSTEM_EXCEPTION( method, COMMIT)\
CATCH_AND_THROW_TX_UNKNOWN_EXCEPTION( method, COMMIT)


// CATCH_TX_EXCEPTION( method, COMMIT, RollBackFailed       , MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR)
// Macro : CATCH_TX_ROLLBACK_EXCEPTIONS
//
// Description:
//
//

#define CATCH_TX_ROLLBACK_EXCEPTIONS( method )\
CATCH_TX_EXCEPTION( method, ROLLBACK, NoTransaction )\
CATCH_TX_SYSTEM_EXCEPTION( method, ROLLBACK)\
CATCH_TX_UNKNOWN_EXCEPTION( method, ROLLBACK) 


// Macro : TX_INITIALIZE
//
// Description:
//
//
#define TX_INITIALIZE()     Encina::Client::Initialize() ;

// Macro : TX_BEGIN
//
// Description:
//
//

#define TX_BEGIN(method)\
try\
{ \
    CosTransactions::Current::begin(); \
} \
CATCH_TX_BEGIN_EXCEPTIONS( method )

                        
// Macro : TX_ROLLBACK
//
// Description:
//
//

#define TX_ROLLBACK(method)\
try\
{\
    CosTransactions::Current::rollback();\
}\
CATCH_TX_ROLLBACK_EXCEPTIONS(method)

                        
// Macro : TX_COMMIT
//
// Description:
//
//

#define TX_COMMIT(method)\
try\
{\
    CosTransactions::Current::commit() ;\
} \
CATCH_TX_COMMIT_EXCEPTIONS(method)

// Macro : TX_EXIT
//
// Description:
//
//
#define TX_EXIT(param)      Encina::Client::Exit(param) ;

#endif
