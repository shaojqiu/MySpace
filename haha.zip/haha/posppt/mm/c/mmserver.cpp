#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spclass/spfwbins/mmserver.cpp, mm_srv_90e_spcl, mm_srv_90e_spcl 4/17/07 13:34:36 [ 7/14/07 00:37:16 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// Siview
// Name: mmserver.cpp
// Description:
//   This is mainline for Material Manager server.
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 05/24/05 D6000308 S.Yamamoto     Initial Release
// 06/08/05 D6000288 K.Murakami     Add Version Check
// 06/08/05 D6000279 K.Murakami     Set up UUID and PortNo and ORB type for eBroker.
// 07/04/06 P7000317 S.Yamamoto     Remove code for creation of BRSVariableInfoManager.
// 11/08/06 D8000038 K.Kido         Add new WhatNextLogics object for "UTS".
// 11/16/09 D8000029 F.Masada       Remove WhereNextLogic object.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/06/16 DSIV00001049 R.Okano        Add environment variable check for Authserver
// 2009-11-11 PSIV00001581 R.Iriguchi     Fix memory leak
// 2010-0414  DSIV00001926 S.Yamamoto     Support web service.
// 2010/09/06 DSIV00002334 T.Ishida       Compiler XLC10.1 support
// 2012/06/01 DSN000041641 K.Yamaoku      Add for Post Process Execution with additional parameters.
// 2012/09/11 DSN000052888 M.Nakano       Trace log improvement.
// 2013/01/23 DSN000050720 M.Ogawa        Post Process parallel execution
// 2013/04/11 DSN000073319 S.Yamamoto     Improvement of sptraceclt interface.
// 2013/01/14 DSN000081739 M.Ogawa        Add new WhatNextLogics object for "EQP-MONITOR".
// 2015/08/20 DSN000096126 K.Yamaoku      Durable Process Flow Control
// 2017/04/06 DSN000104773 K.Yamaoku      Startup error log improvement
//

#ifdef _AIX
   #include <unistd.h>
#endif

#include <iostream.h>
#include <stdlib.h>

#include <ots/cborb/encina_cborb.H>
#include <cs_loader.hpp>
#include "mmserver.hpp"

#define CIMFWNAM_DECLARE
#define SPFWNAME_DECLARE
#define BUILD_MMSERVER
#define BUILD_PPTSERVER
#define BUILD_BRSSERVER

short int cimfw_global_db_shared = 0;

#ifdef _AIX
    #include <assert.h>
#endif

#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <spbos.h>
#include <CFLocator.h>
#include <srv_svc.h>

#include <IIOPInitialSetup.hpp>
#undef SIVIEW_EBROKER
#include <CosNaming.hh>
#define SIVIEW_EBROKER
#include "sprel_eb.hpp"   //D6000288
#include "sprel.hh"       //D6000288

#include "aplpf_eb.hpp"
#include "spebmarker.hpp"

#ifdef _WIN32
    #include <winsock.h>
    #include <direct.h>
#endif

extern GlobalComposedObjectTable* global_func();

#include "cimfwtrc.hpp"

#include "pfwgls.hpp"     //DSN000041641
#include "spfwtrc.hpp"
#include "spfwname.hpp"
#include "parseini.hpp"

#include "splock.hpp"
#include "tracelogmgr.hpp"
#include "threadpostproc.hpp"   //DSN000050720

//----------------------
// Manager Interfaces
//----------------------
#include "pathmgr.hh"
#include "pcdmgr.hh"
#include "pdcmgr.hh"
#include "pdpmg.hh"
#include "pdrmg.hh"
#include "pevmg.hh"
#include "pfactry.hh"
#include "pmcmg.hh"
#include "pmsdnmg.hh"
#include "pqtimmg.hh"
#include "ppcdfmg.hh"
#include "pplmgr.hh"
#include "pprmgr.hh"
#include "pprspmg.hh"
#include "ppsmgr.hh"
#include "prcmg.hh"
#include "peninmg.hh"
#include "pptsmg.hh"
#include "pptysetmg.hh"
#include "pcmpmgfc.hh"
#include "brsvariableinfoimizedmgr.hh"
#include "brsmanager.hh"
#include "posuserdefparm.hpp"

#ifdef BUILD_MMSERVER

//-------------------------------
// Object Factorys for MM Server
//-------------------------------
#include "abclsp.hpp"
#include "athmnsp.hpp"
#include "codemnsp.hpp"
#include "dtcllcsp.hpp"
#include "dsptchsp.hpp"
#include "drblmnsp.hpp"
#include "evmgsp.hpp"
#include "fctrycsp.hpp"
#include "mchnmnsp.hpp"
#include "msdsmnsp.hpp"
#include "prcssdsp.hpp"
#include "plnngsp.hpp"
#include "prdctmsp.hpp"
#include "prdctssp.hpp"
#include "prsnmnsp.hpp"
#include "rcpmngsp.hpp"
#include "entinsp.hpp"
#include "partssp.hpp"
#include "pptysetmg.hpp"
#include "pcmpmgfc.hpp"
#include "sptrclog.hpp"

#include "peninmg.hpp"
#include "pdpmg.hpp"
//------------------------------
// What'sNext logic Interfaces
//------------------------------
#include "pwtedd.hpp"
#include "pwtesd.hpp"
#include "pwtextp.hpp"
#include "pwtfifo.hpp"
#include "pwtintp.hpp"
#include "pwtlrt.hpp"
#include "pwtmaxq.hpp"
#include "pwtpcls.hpp"
#include "pwtpeqp.hpp"
#include "pwtplns.hpp"
#include "pwtsrt.hpp"
#include "pwtsst.hpp"
//D8000029 #include "pwrdflt.hpp"
#include "pwtflwb.hpp"
#include "pwtqttt.hpp"
#include "pwtpcmp.hpp"
#include "pwtuts.hpp"     // D8000038
#include "pwtemon.hpp"      //DSN000081739
#include "pwtdesd.hpp"      //DSN000096126
#include "pwtdfifo.hpp"     //DSN000096126
#include "pwtdlrt.hpp"      //DSN000096126
#include "pwtdmaxq.hpp"     //DSN000096126
#include "pwtdpcmp.hpp"     //DSN000096126
#include "pwtdsrt.hpp"      //DSN000096126

#else  // BUILD_MMSERVER

//-------------------------------
// Object Factorys for MM Server
//-------------------------------
#include "abclsp.hh"
#include "athmnsp.hh"
#include "codemnsp.hh"
#include "dtcllcsp.hh"
#include "dsptchsp.hh"
#include "drblmnsp.hh"
#include "evmgsp.hh"
#include "fctrycsp.hh"
#include "mchnmnsp.hh"
#include "msdsmnsp.hh"
#include "prcssdsp.hh"
#include "pcmnsp.hh"
#include "plnngsp.hh"
#include "prdctmsp.hh"
#include "prdctssp.hh"
#include "prsnmnsp.hh"
#include "rcpmngsp.hh"
#include "entinsp.hh"
#include "partssp.hh"
#include "pptysetmg.hh"
#include "pcmpmgfc.hh"
#include "sptrclog.hpp"
//------------------------------
// What'sNext logic Interfaces
//------------------------------
#include "pwtedd.hh"
#include "pwtesd.hh"
#include "pwtextp.hh"
#include "pwtfifo.hh"
#include "pwtintp.hh"
#include "pwtlrt.hh"
#include "pwtmaxq.hh"
#include "pwtpcls.hh"
#include "pwtpeqp.hh"
#include "pwtplns.hh"
#include "pwtsrt.hh"
#include "pwtsst.hh"
//D8000029 #include "pwrdflt.hh"
#include "pwtflwb.hh"
#include "pwtqttt.hh"
#include "pwtpcmp.hh"
#include "pwtuts.hh"     // D8000038
#include "pwtemon.hh"       //DSN000081739
#include "pwtdesd.hh"       //DSN000096126
#include "pwtdfifo.hh"      //DSN000096126
#include "pwtdlrt.hh"       //DSN000096126
#include "pwtdmaxq.hh"      //DSN000096126
#include "pwtdpcmp.hh"      //DSN000096126
#include "pwtdsrt.hh"       //DSN000096126

#endif  // BUILD_MMSERVER

//-------------------------------
// Object Factorys for BRS Server
//-------------------------------
#ifdef BUILD_BRSSERVER
#include "brsvarmgrfac.hpp"
#include "brsmanagerfac.hpp"
#else  // BUILD_BRSSERVER
#include "brsvarmgrfac.hh"
#include "brsmanagerfac.hh"
#endif  // BUILD_BRSSERVER

//------------------------------------
// PPT Service Manager Object Factory
// PPT Manager Object Factory
//------------------------------------
#include <locale.h>
#ifdef BUILD_PPTSERVER
#include "pptsvcmf.hpp"
#include "pptmgrof.hpp"
#else  // BUILD_PPTSERVER
#include "pptsvcmf.hh"
#include "pptmgrof.hh"
#endif  // BUILD_PPTSERVER


#ifdef _AIX
#include "diagnose.hpp"    // for diag interface
#endif

// DSN000052888 add start
//DSN000073319#include "bufferedtracelogmgr.hpp"
//DSN000073319#include "bufferedloggerkkutil.hpp"
//DSN000073319#include "bufferedlogger_kicker_pic.hpp"
#include "bufferedlogger_kicker_mm.hpp"
// DSN000052888 add end


void            InitBOSServer( const char* pgm_name );
void            SuperPOSEIDONServer( void );
void            CleanUpServerAndExit( void );
void            CreateComponentManagers( void );
void            CreateComponentObjectFactories( void );
CORBA::Boolean  RegisterComponentManager( ComponentManager_ptr CmpntManager );
//P7000317void            CreateDefaultVariablesAndDataTypes() ;
void            SetDebugParameterSettings();

int bindObjects(PPTServiceManagerObjectFactory_var,const char *,const char *);
static const char* SIVIEW = "siview" ;
static const char* NS_OBJ = "PPTServiceManagerObjectFactory" ;

void setPerRequestServiceContextHandler();

const char* getComponentManagerMarker(const char* default_envvar, const char* defaultmarker);

//DSN000073319// DSN000052888 add start
//DSN000073319void setBufferedLoggerHandler();
//DSN000073319void initBufferedLogger();
//DSN000073319// DSN000052888 add end


static const char* IMCONFIGINI_FILE         = "IMCONFIG_FILE" ;
static const char* ENCINA_LOGDEVICE         = "ENCINA_LOGDEVICE" ;
static const char* ENCINA_RESTARTFILES      = "ENCINA_RESTARTFILES" ;
static const char* SPFW_TRACE_VERBOSE       = "SPFW_TRACE_VERBOSE" ;
static const char* SPFW_TRACE_DEBUG_VERBOSE = "SPFW_TRACE_DEBUG_VERBOSE" ;
static const char* CIMFW_DEBUG_DO_LEVEL     = "SPFW_TRACE_DO_VERBOSE" ;
static const char* PPT_TRACE_VERBOSE        = "PPT_TRACE_VERBOSE" ;

char*                                            inputHitListFileName = NULL ;

//--------------------------------
// Framework compornent managers
//--------------------------------
PosMESFactory_var                                thePosMESFactory ;
PosAuthenticationManager_var                     thePosAuthenticationManager ;
PosCodeManager_var                               thePosCodeManager ;
PosDataCollectionSpecificationManager_var        thePosDataCollectionSpecificationManager ;
PosDispatchingManager_var                        thePosDispatchingManager ;
PosDurableManager_var                            thePosDurableManager ;
PosEventManager_var                              thePosEventManager ;
PosMachineManager_var                            thePosMachineManager ;
PosMessageDistributionManager_var                thePosMessageDistributionManager ;
PosProcessDefinitionManager_var                  thePosProcessDefinitionManager ;
PosQTimeRestrictionManager_var                   thePosQTimeRestrictionManager ;
PosPlanManager_var                               thePosPlanManager ;
PosProductManager_var                            thePosProductManager ;
PosProductSpecificationManager_var               thePosProductSpecificationManager ;
PosPersonManager_var                             thePosPersonManager ;
PosRecipeManager_var                             thePosRecipeManager ;
PosEntityInhibitManager_var                      thePosEntityInhibitManager ;
PosPartsManager_var                              thePosPartsManager ;
PosPropertySetManager_var                        thePosPropertySetManager ;

//----------------------
// BRScript server
//----------------------
BRSVariableInfoIMizedMgr_var                     theUserParameterManager ;
BRSManager_var                                   theBRSManager ;


//-----------------------------------------------
// Framework compornent manager object factories
//-----------------------------------------------
PosComponentManagerObjectFactory_var             theComponentManagerObjectFactory ;
SPAbstractClassObjectFactory_var                 theAbstractClassObjectFactory ;
SPAuthenticationManagementObjectFactory_var      theAuthenticationManagementObjectFactory ;
SPCodeManagementObjectFactory_var                theCodeManagementObjectFactory ;
SPDataCollectionManagementObjectFactory_var      theDataCollectionManagementObjectFactory ;
SPDispatchingManagementObjectFactory_var         theDispatchingManagementObjectFactory ;
SPDurableManagementObjectFactory_var             theDurableManagementObjectFactory ;
SPEventManagementObjectFactory_var               theEventManagementObjectFactory ;
SPFactoryManagementObjectFactory_var             theFactoryManagementObjectFactory ;
SPMachineManagementObjectFactory_var             theMachineManagementObjectFactory ;
SPMessageDistributionManagementObjectFactory_var theMessageDistributionManagementObjectFactory ;
SPProcessDefinitionObjectFactory_var             theProcessDefinitionManagementObjectFactory ;
SPPlanningObjectFactory_var                      thePlanningObjectFactory ;
SPProductManagementObjectFactory_var             theProductManagementObjectFactory ;
SPProductSpecificationObjectFactory_var          theProductSpecificationManagementObjectFactory ;
SPPersonManagementObjectFactory_var              thePersonManagementObjectFactory ;
SPRecipeManagementObjectFactory_var              theRecipeManagementObjectFactory ;
SPEntityInhibitManagementObjectFactory_var       theEntityInhibitManagementObjectFactory ;
SPPartsManagementObjectFactory_var               thePartsManagementObjectFactory ;

SPFactoryManagementObjectFactory_var     theAreaObjectFactory ;
SPFactoryManagementObjectFactory_var     theBankObjectFactory ;
SPFactoryManagementObjectFactory_var     theCalendarDateObjectFactory ;
SPFactoryManagementObjectFactory_var     theFactoryNoteObjectFactory ;
SPFactoryManagementObjectFactory_var     theStageObjectFactory ;
SPFactoryManagementObjectFactory_var     theStageGroupObjectFactory ;

SPCodeManagementObjectFactory_var        theCategoryObjectFactory ;
SPCodeManagementObjectFactory_var        theCodeObjectFactory ;
SPCodeManagementObjectFactory_var        theScriptObjectFactory ;
SPCodeManagementObjectFactory_var        theSystemMessageCodeObjectFactory ;
SPCodeManagementObjectFactory_var        theE10StateObjectFactory ;
SPCodeManagementObjectFactory_var        theMachineStateObjectFactory ;
SPCodeManagementObjectFactory_var        theRawMachineStateSetObjectFactory ;

SPDataCollectionManagementObjectFactory_var   theDataCollectionDefinitionObjectFactory ;
SPDataCollectionManagementObjectFactory_var   theDataCollectionSpecificationObjectFactory ;

SPDispatchingManagementObjectFactory_var      theDispatcherObjectFactory ;
SPDispatchingManagementObjectFactory_var      theFlowBatchObjectFactory ;
SPDispatchingManagementObjectFactory_var      theFlowBatchDispatcherObjectFactory ;
SPDispatchingManagementObjectFactory_var      theDispatchingManagerObjectFactory ;

SPDurableManagementObjectFactory_var          theCassetteObjectFactory ;
SPDurableManagementObjectFactory_var          theProcessDurableCapabilityObjectFactory ;
SPDurableManagementObjectFactory_var          theProcessDurableObjectFactory ;
SPDurableManagementObjectFactory_var          theTransportGroupObjectFactory ;
SPDurableManagementObjectFactory_var          theReticlePodObjectFactory ;

//FactoryMaterialMovement

SPMachineManagementObjectFactory_var          theBufferResourceObjectFactory ;
SPMachineManagementObjectFactory_var          theMachineObjectFactory ;
SPMachineManagementObjectFactory_var          theMachineNoteObjectFactory ;
SPMachineManagementObjectFactory_var          theMachineOperationProcedureObjectFactory ;
SPMachineManagementObjectFactory_var          theMachinePropertySetObjectFactory ;
SPMachineManagementObjectFactory_var          theMaterialLocationObjectFactory ;
SPMachineManagementObjectFactory_var          theMaterialSupplyResourceObjectFactory ;
SPMachineManagementObjectFactory_var          thePortResourceObjectFactory ;
SPMachineManagementObjectFactory_var          theProcessResourceObjectFactory ;
SPMachineManagementObjectFactory_var          theStorageMachineObjectFactory ;
SPMachineManagementObjectFactory_var          theTransportResourceObjectFactory ;

SPMessageDistributionManagementObjectFactory_var theMessageDefinitionObjectFactory ;

SPProcessDefinitionObjectFactory_var     theProcessDefinitionObjectFactory ;
SPProcessDefinitionObjectFactory_var     theProcessFlowObjectFactory ;
SPProcessDefinitionObjectFactory_var     theProcessFlowContextObjectFactory ;
SPProcessDefinitionObjectFactory_var     theProcessOperationObjectFactory ;
SPProcessDefinitionObjectFactory_var     theProcessOperationPropertySetObjectFactory ;
SPProcessDefinitionObjectFactory_var     theProcessOperationSpecificationObjectFactory ;
SPProcessDefinitionObjectFactory_var     theQTimeRestrictionObjectFactory ;

SPPlanningObjectFactory_var              theLotOperationScheduleObjectFactory ;
SPPlanningObjectFactory_var              theLotScheduleObjectFactory ;
SPPlanningObjectFactory_var              theProductRequestObjectFactory ;

SPProductManagementObjectFactory_var     theDieObjectFactory ;
SPProductManagementObjectFactory_var     theLotObjectFactory ;
SPProductManagementObjectFactory_var     theLotCommentObjectFactory ;
SPProductManagementObjectFactory_var     theLotFamilyObjectFactory ;
SPProductManagementObjectFactory_var     theLotNoteObjectFactory ;
SPProductManagementObjectFactory_var     theLotOperationNoteObjectFactory ;
SPProductManagementObjectFactory_var     theLotPropertySetObjectFactory ;
SPProductManagementObjectFactory_var     theLotTypeObjectFactory ;
SPProductManagementObjectFactory_var     theMonitorGroupObjectFactory ;
SPProductManagementObjectFactory_var     thePackageObjectFactory ;
SPProductManagementObjectFactory_var     theProcessGroupObjectFactory ;
SPProductManagementObjectFactory_var     theWaferObjectFactory ;

SPProductSpecificationObjectFactory_var  theBinDefinitionObjectFactory ;
SPProductSpecificationObjectFactory_var  theCustomerObjectFactory ;
SPProductSpecificationObjectFactory_var  theCustomerProductObjectFactory ;
SPProductSpecificationObjectFactory_var  theProductCategoryObjectFactory ;
SPProductSpecificationObjectFactory_var  theProductGroupObjectFactory ;
SPProductSpecificationObjectFactory_var  theProductSpecificationObjectFactory ;
SPProductSpecificationObjectFactory_var  theProductSpecificationPropertySetObjectFactory ;
SPProductSpecificationObjectFactory_var  theSamplingCriteriaObjectFactory ;
SPProductSpecificationObjectFactory_var  theTechnologyObjectFactory ;
SPProductSpecificationObjectFactory_var  theTestSpecificationObjectFactory ;
SPProductSpecificationObjectFactory_var  theBinSpecificationObjectFactory ;
SPProductSpecificationObjectFactory_var  theTestTypeObjectFactory ;

SPPersonManagementObjectFactory_var      theAreaGroupObjectFactory ;
SPPersonManagementObjectFactory_var      theBRMFunctionGroupObjectFactory ;
SPPersonManagementObjectFactory_var      thePersonObjectFactory ;
SPPersonManagementObjectFactory_var      thePPTFunctionGroupObjectFactory ;
SPPersonManagementObjectFactory_var      theQualificationDataObjectFactory ;
SPPersonManagementObjectFactory_var      theSchedulerFunctionGroupObjectFactory ;
SPPersonManagementObjectFactory_var      thePrivilegeGroupObjectFactory ;

SPRecipeManagementObjectFactory_var      theLogicalRecipeObjectFactory ;
SPRecipeManagementObjectFactory_var      theMachineRecipeObjectFactory ;

SPEntityInhibitManagementObjectFactory_var  theEntityInhibitObjectFactory ;

//-----------------------------------------------
// BRScript server object factories
//-----------------------------------------------
BRSVariableManagerObjectFactory_var              theBRSVariableManagerObjectFactory ;
BRSManagerObjectFactory_var                      theBRSManagerObjectFactory ;

//-----------------------------------------------
// PPT Service Manager object factories
//-----------------------------------------------
PPTServiceManagerObjectFactory_var  thePPTServiceManagerObjectFactory ;
PPTManagerObjectFactory_var         thePPTManagerObjectFactory ;

//-----------------------------------------------
// Dispatching logic objects
//-----------------------------------------------
PosWhatNextEDD_var               thePosWhatNextEDD ;
PosWhatNextESD_var               thePosWhatNextESD ;
PosWhatNextExternalPriority_var  thePosWhatNextExternalPriority ;
PosWhatNextFIFO_var              thePosWhatNextFIFO ;
PosWhatNextInternalPriority_var  thePosWhatNextInternalPriority ;
PosWhatNextLRT_var               thePosWhatNextLRT ;
PosWhatNextMaxQTimeFIFO_var      thePosWhatNextMaxQTimeFIFO ;
PosWhatNextPriorityClass_var     thePosWhatNextPriorityClass ;
PosWhatNextPlanEqp_var           thePosWhatNextPlanEqp ;
PosWhatNextPlanStart_var         thePosWhatNextPlanStart ;
PosWhatNextSRT_var               thePosWhatNextSRT ;
PosWhatNextSST_var               thePosWhatNextSST ;
//D8000029 PosWhereNextDefault_var          thePosWhereNextDefault ;
PosWhatNextFlowBatch_var         thePosWhatNextFlowBatch ;
PosWhatNextQTimeTargetTime_var   thePosWhatNextQTimeTargetTime;
PosWhatNextPreCompTime_var       thePosWhatNextPreCompTime ;
PosWhatNextUTS_var               thePosWhatNextUTS;             // D8000038
PosWhatNextEqpMonitor_var        thePosWhatNextEqpMonitor;      //DSN000081739
PosWhatNextDurableESD_var          thePosWhatNextDurableESD;           //DSN000096126
PosWhatNextDurableFIFO_var         thePosWhatNextDurableFIFO;          //DSN000096126
PosWhatNextDurableLRT_var          thePosWhatNextDurableLRT;           //DSN000096126
PosWhatNextDurableMaxQTimeFIFO_var thePosWhatNextDurableMaxQTimeFIFO;  //DSN000096126
PosWhatNextDurableSRT_var          thePosWhatNextDurableSRT;           //DSN000096126
PosWhatNextDurablePreCompTime_var  thePosWhatNextDurablePreCompTime;   //DSN000096126

//-----------------------------------------------
// TraceLog ControlObject
//-----------------------------------------------
SPTraceLogControlObject_var      theSPTraceLogControlObject ;

//DSN000050720 Add Start
extern SPThreadPostProc*   thePostProcThreadArray;
extern pthread_mutex_t     MutexForPostProcessThreadPool;
//DSN000050720 Add End

MFGBOS_Server     BOSServer ;
CFLocator         FactoryFinder ;
IMFW_Factory_var  pIMFactory;
CORBA::Boolean    bServerReady = 0;

static void sigHandle( int code )
{
    CleanUpServerAndExit() ;
    MFGBOS_Server::Exit(0) ;   // do graceful exit
}

#ifdef _AIX

#define ORBIXD_PGM  "orbixd"
pid_t findProcess( const char* program_name );
pid_t findProcessForAllInstances( const char* program_name );

#include "spmail.hpp"
static SPMail* pSpmail= 0;

char *theSiviewMMServer = NULL;

static void pagingDanger( int code ){

    if ( pSpmail ){
        pSpmail->deliver( "PAGING SPACE LOW" );
    }

    SPMAIN_TRACE_VERBOSE1("received SIGDANGER");
    cout << "###################################################################################" << endl;
    cout << "received SIGDANGER received, paging space is low or this server wastes huge memory." << endl;
    cout << "###################################################################################" << endl;

    signal( SIGDANGER, pagingDanger); // set the handler again
} // end of pagingDanger
#endif

char *sp_del_hyphen( const char *uuid, char *buf, int buf_len );
#define SP_DEL_UUID_HYPHEN( uuid, buf, buf_len ) sp_del_hyphen( uuid, buf, buf_len )

//D6000288 add start
class mm_PortableInterceptorInitializer
{
public:
    mm_PortableInterceptorInitializer()
    {
        initApplicationProcessFilter();
        setPerRequestServiceContextHandler();
//DSN000073319        initBufferedLogger();          //DSN000052888

    }
    ~mm_PortableInterceptorInitializer()
    {
    }
} mm_initInterceptor;
//D6000288 add end

int main( int argc, char **argv )
{
    SPMAIN_TRACEENTRY("main");

//D6000279 add start
    theSiviewMMServer =  MMServerName;
    cout << "servername:" << theSiviewMMServer << endl;

    CORBA::ImplDef * imp = new CORBA::ImplDef();
    char ServerUUID[256];
    CIMFWStrCpy(ServerUUID, ++SiviewMMServerName);
    SiviewMMServerName--;
    char *pos = strchr( ServerUUID, ':' );
    if( pos != NULL )
    {
        *pos = 0;
    }
//D6000279 add end
    try
    {
        imp->set_id( ServerUUID );             //D6000279
//DSIV00001926        imp->set_protocols("TCPIP");
        //DSIV00001926 add start
        char *protocols = getenv( SP_EBROKER_PROTOCOLS);
        if( NULL == protocols ) protocols = "TCPIP";
        imp->set_protocols( protocols );
        //DSIV00001926 add end
        imp->set_alias( theSiviewMMServer );   //D6000279

        cout << "UUID:" << imp->get_id() << endl;

        CORBA::ORB_ptr op = CORBA::ORB_init(argc, argv, "DSOM");
        CORBA::BOA_ptr bp = op->BOA_init(argc, argv, "DSOM_BOA");

        bp->impl_is_ready(imp);

        TraceLogManagerFactory* theTraceLogManagerFactory = new TraceLogManagerFactory();
        ParameterLogManagerFactory *theParameterLogManager= new ParameterLogManagerFactory();
    }
    catch( CORBA::SystemException& ex )
    {
        cout << "SystemException is happened!:" << ex << endl;
        CleanUpServerAndExit() ;
    }
    catch(...)
    {
        cout << "Unknown SystemException is happened!" << endl;
        CleanUpServerAndExit() ;
    }

    initTraceEnabledThreadFlag();  //pthread_key_create for trace enabled thread handling
    initThreadSpecificDataString();  //DSN000041641
    
    kickermm = new KickerMM();     //DSN000052888

    setlocale( LC_ALL, "" ) ;

    // set diagnose utility
    #ifdef _AIX
        initializeDiagInterface(); // create Diag Interface object
    #endif

    // to support customizing server. the conversion table must be defined
    // to bind polymorphically objects
    cs_loader* csl = new cs_loader( theSiviewMMServer, "markerconv.lst" );


    // set server name for SPIOR
    char uuid_buf[64];
    SP_IIOP_INITIAL_SETUP( SP_DEL_UUID_HYPHEN( imp->get_id(), uuid_buf, sizeof(uuid_buf) ) );

    // initialize BOS server
    SPMAIN_TRACE_VERBOSE1("Initialize BOS Server");

    char* pgm_name= strrchr( argv[0], '/' );
    if ( pgm_name) pgm_name++;
    else pgm_name= argv[0];

    InitBOSServer(pgm_name) ;

    // set Trace Log Control Object
    theSPTraceLogControlObject = new SPTraceLogControlObject_i() ;

    // get Max Connection Threads

    #ifdef _AIX
        SPMail_var spmail_var= pSpmail; // pSpmail is created in InitBOSServer
    #endif

//DSIV00001049 add start
    // check environment variable for Authserver (only when Authserver mode)
    const char* authAvail = getenv( "SP_AUTH_AUTHSERVER_AVAILABLE" );
    if ( 0 == CIMFWStrCmp( authAvail, "1" ) )
    {
        SPMAIN_TRACE_VERBOSE2("### Starting MMServer by Authserver mode...  authAvail = ", authAvail);

        const char* authHostName   = getenv( "SP_AUTH_HOST_NAME"   );
        const char* authMarkerName = getenv( "SP_AUTH_MARKER_NAME" );
        const char* authServerName = getenv( "SP_AUTH_SERVER_NAME" );
        if( 0 != CIMFWStrLen( authHostName   ) &&
            0 != CIMFWStrLen( authMarkerName ) &&
            0 != CIMFWStrLen( authServerName ) )
        {
            SPMAIN_TRACE_VERBOSE2( "### Authserver Host Name   = ", authHostName );
            SPMAIN_TRACE_VERBOSE2( "### Authserver Marker Name = ", authMarkerName );
            SPMAIN_TRACE_VERBOSE2( "### Authserver Server Name = ", authServerName );
        }
        else
        {
            SPMAIN_TRACE_VERBOSE1( "### ERROR!! Environment variable for Authserver should be filled. Terminate MMServer..." );
            CleanUpServerAndExit();
        }
    }
//DSIV00001049 add end

    // creates component manager's ALFs
    try
    {
        SPMAIN_TRACE_VERBOSE1("Create Component Object Factories");
        CreateComponentObjectFactories() ;
    }
    catch(FrameworkErrorSignal &fwes)
    {
        SPMAIN_TRACE_FRAMEWORKERRORSIGNAL(fwes);
        CleanUpServerAndExit() ;
    }
    catch(CORBA::SystemException &sex)
    {
        SPMAIN_TRACE_VERBOSE2("Caught CORBA::SystemException",sex.minor());
        CleanUpServerAndExit() ;
    }
    catch(...)
    {
        SPMAIN_TRACE_VERBOSE2("Caught exception:","unknown");
        CleanUpServerAndExit() ;
    }

    // creates commponent managers.
    try
    {
        SPMAIN_TRACE_VERBOSE1("Create Component Managers");
        CreateComponentManagers() ;
    }
    catch(FrameworkErrorSignal &fwes)
    {
        SPMAIN_TRACE_FRAMEWORKERRORSIGNAL(fwes);
        CleanUpServerAndExit() ;
    }
    catch(CORBA::SystemException &sex)
    {
        SPMAIN_TRACE_VERBOSE2("Caught CORBA::SystemException",sex.minor());
        CleanUpServerAndExit() ;
    }
    catch(...)
    {
        SPMAIN_TRACE_VERBOSE2("Caught exception:","unknown");
        CleanUpServerAndExit() ;
    }

//DSN000050720 add start
    SPThread_pthread_mutex_init(&MutexForPostProcessThreadPool, NULL);

    // create thread pool for PostProc thread
    char* parallelSwitch = getenv( "SP_POSTPROC_PARALLEL_SWITCH" );
    if ( 0 == CIMFWStrLen(parallelSwitch) )
    {
        parallelSwitch = CIMFWStrDup("0");
    }

    int   nPostProcThreadCnt = 0;
    char* postProcThreadCnt = NULL;
    postProcThreadCnt = getenv( "SP_POSTPROC_PARALLEL_THREADCOUNT" );
    if ( 0 < CIMFWStrLen ( postProcThreadCnt ) )
    {
        nPostProcThreadCnt = atoi( postProcThreadCnt );
        if ( nPostProcThreadCnt == 0 && postProcThreadCnt[0] != '0' )
        {
            nPostProcThreadCnt = 0;
        }
        else if ( nPostProcThreadCnt > 100 )
        {
            nPostProcThreadCnt = 100;
        }
        else if ( nPostProcThreadCnt < 0 )
        {
            nPostProcThreadCnt = 0;
        }
        else
        {
            //Specified value is used
        }
    }
    else
    {
        nPostProcThreadCnt = 0;
    }

    if ( 0 == CIMFWStrCmp( parallelSwitch, "1" )
      && 0 < nPostProcThreadCnt )
    {
        thePostProcThreadArray = new SPThreadPostProc[nPostProcThreadCnt];
        if( NULL == thePostProcThreadArray )
        {
            SPMAIN_TRACE_VERBOSE1("Error in creating SPThreadPostProc array. Terminate MMServer...");
            CleanUpServerAndExit();
        }
        
        // PPTServiceManager and PPTManager is already initialized and create returned pointer to them
        PPTServiceManager_var thePPTServiceManager= thePPTServiceManagerObjectFactory->createPPTServiceManager();
        PPTManager_var        thePPTManager       = thePPTManagerObjectFactory->createPPTManager();

        SPMAIN_TRACE_VERBOSE2("Create thread for PostProcess parallel execution.", nPostProcThreadCnt);

        int i = 0;
        SPThreadPostProc *p;
        p = thePostProcThreadArray;
        for( i = 0; i < nPostProcThreadCnt; i++ )
        {
            // Set thread information
            p->initialize( thePPTServiceManager, thePPTManager );
            p->startThread();
            p++;
        }
    }
    else
    {
        // Thread isn't created.
        SPMAIN_TRACE_VERBOSE1("not create thread for PostProcess parallel execution.");
    }
//DSN000050720 add end

    char* NamingServiceRegister = getenv("SP_NAMINGSERVICE_REGISTER");
    SPMAIN_TRACE_VERBOSE2("Get naming service register flag : ",NamingServiceRegister);
    if(NamingServiceRegister != NULL)
    {
      long nNamingServiceRegister = atol(NamingServiceRegister);
      if(nNamingServiceRegister==ON){
        SPMAIN_TRACE_VERBOSE1("Binding thePPTServiceManagerObjectFactory to Naming Service");
        bindObjects(thePPTServiceManagerObjectFactory,theSiviewMMServer,NS_OBJ);
     }
    }

    char* PPTObjName = ::IMRegistry::orbPtr->object_to_string( thePPTServiceManagerObjectFactory );
    SPMAIN_TRACE_VERBOSE2("object_to_string( thePPTServiceManagerObjectFactory )", PPTObjName);

    const char* mmserverName = getenv( "MM_SERVER_NAME" );
    const char* hostName     = getenv( "MM_HOST_NAME" );
    const char* sambaPath    = getenv( "SP_EBROKERTCS_SAMBAPATH" );
    char TCS_EBrokerFilePath[1024];
    memset(TCS_EBrokerFilePath, 0, sizeof(TCS_EBrokerFilePath));

    SPMAIN_TRACE_VERBOSE2("MM_SERVER_NAME----------->", mmserverName);
    SPMAIN_TRACE_VERBOSE2("MM_HOST_NAME------------->", hostName);
    SPMAIN_TRACE_VERBOSE2("SP_EBROKERTCS_SAMBAPATH-->", sambaPath);

    char* mmSevNameOnly = NULL;
    if ( NULL != mmserverName && NULL != hostName )
    {
        mmSevNameOnly = strchr(mmserverName, ':');
        if ( NULL != mmSevNameOnly )
        {
            mmSevNameOnly++;
            if ( 0 == strlen(mmSevNameOnly) )
            {
                mmSevNameOnly = NULL;
            }
        }
        else
        {
            mmSevNameOnly = (char*)mmserverName;
        }
    }

    if ( NULL != sambaPath && 0 < CIMFWStrLen(sambaPath) )
    {
        CIMFWStrCat(TCS_EBrokerFilePath, sambaPath);
        if ( '/' != TCS_EBrokerFilePath[CIMFWStrLen(TCS_EBrokerFilePath)-1] )
        {
            CIMFWStrCat(TCS_EBrokerFilePath, "/");
        }
    }

    if ( NULL != mmSevNameOnly )
    {
        CIMFWStrCat(TCS_EBrokerFilePath, mmSevNameOnly);
        CIMFWStrCat(TCS_EBrokerFilePath, ".");
        CIMFWStrCat(TCS_EBrokerFilePath, hostName);
    }
    else
    {
        CIMFWStrCat(TCS_EBrokerFilePath, "MMOBJREF.OUT");
    }
    SPMAIN_TRACE_VERBOSE2("ObjRef file name===>", TCS_EBrokerFilePath);

    FILE* fp = fopen(TCS_EBrokerFilePath, "w");
    if ( NULL == fp )
    {
        SPMAIN_TRACE_VERBOSE1("ObjRef file can not open!!");
    }
    else
    {
        fprintf(fp, "%s", PPTObjName);
        fclose(fp);
    }

    // Start server for all CIM FW components.
    SPMAIN_TRACE_VERBOSE1("Start BOS Server");
    SuperPOSEIDONServer() ;

    // Delete/release all objects or object references.
    SPMAIN_TRACE_VERBOSE();
    CleanUpServerAndExit() ;

    SPMAIN_TRACEEXIT("main");
    return 0 ;
}


// Cleans up and exits the process.
//
void CleanUpServerAndExit( void )
{
    SPMAIN_TRACEENTRY("CleanUpServerAndExit");

    #ifndef CIMFWEVENTS_DISABLED
        CIMFWDeleteEventChannels();
    #endif
    SPMAIN_TRACEEXIT("CleanUpServerAndExit");
    fflush(stdout); //DSN000104773
    MFGBOS_Server::Exit(0) ;   // do graceful exit
}


void InitBOSServer( const char* pgm_name )
{
    SPMAIN_TRACEENTRY("InitBOSServer");
    const char* MyLogDevice    = getenv( ENCINA_LOGDEVICE ) ;
    const char* MyRestartFiles = getenv( ENCINA_RESTARTFILES );
    const char* MyConfigFile   = getenv( IMCONFIGINI_FILE ) ;


    signal( SIGINT   , sigHandle ) ;

#ifdef _AIX
    signal( SIGDANGER, pagingDanger );
#endif

    if( MyLogDevice!=NULL && MyConfigFile!=NULL )
    {
        SPMAIN_TRACE_VERBOSE2("Encina Log Device File = ", MyLogDevice);
        SPMAIN_TRACE_VERBOSE2("Encina Restart Files   = ", MyRestartFiles);
        SPMAIN_TRACE_VERBOSE2("IM Config File         = ", MyConfigFile);

        #ifdef _WIN32
            BOSServer.Initialize( CORBA::Orbix.myServer(), MyLogDevice, MyRestartFiles, global_func, MyConfigFile ) ;
        #endif

        #ifdef _AIX

            SPMAIN_TRACE_VERBOSE1("Checking if another server is running ...");
            SPMAIN_TRACE_VERBOSE2("Duplicate process check for ", pgm_name);
            pid_t pid= findProcess( pgm_name );
            if ( pid != 0 )
            {
                SPMAIN_TRACE_VERBOSE5("Another process for ", pgm_name, " PID:", pid, " is already running.");
                cerr << "Another process for " << pgm_name <<  " PID:" <<  pid <<  " is already running." << endl;
                fflush(stdout); //DSN000104773
                MFGBOS_Server::Exit(1) ;
            }

            SPMAIN_TRACE_VERBOSE1("Creating SPMail ...");
            pSpmail= new SPMail( ::IMRegistry::ServerName );

            SPMAIN_TRACE_VERBOSE1("Before Initialize ...");
//DSN000104773 add start
            fflush(stdout);
            try
            {
//DSN000104773 add end
                BOSServer.Initialize( theSiviewMMServer, MyLogDevice, MyRestartFiles, global_func, MyConfigFile ) ;
//DSN000104773 add start
            }
            catch (...)
            {
                SPMAIN_TRACE_VERBOSE1("Error in initializing BOSServer.");
                fflush(stdout);
                MFGBOS_Server::Exit(1) ;
            }
//DSN000104773 add end
            SPMAIN_TRACE_VERBOSE1("After  Initialize ...");

            EB_SiView_initMarkerToObject( ::IMRegistry::boaPtr );
        #endif
    }
    else
    {
//DSN000104773 add start
        SPMAIN_TRACE_VERBOSE1("Error Encina Log Device File is NULL or IM Config File is NULL.");
        SPMAIN_TRACE_VERBOSE2("Encina Log Device File = ", MyLogDevice);
        SPMAIN_TRACE_VERBOSE2("IM Config File         = ", MyConfigFile);
//DSN000104773 add end
        SPMAIN_TRACE_VERBOSE();
        SPMAIN_TRACEEXIT("InitBOSServer");
        fflush(stdout); //DSN000104773
        MFGBOS_Server::Exit(1) ;
    }
    SPMAIN_TRACE_VERBOSE();
    SPMAIN_TRACEEXIT("InitBOSServer");
}


// Helper function to the registerManagers() thread function.
//
CORBA::Boolean RegisterComponentManager( ComponentManager_ptr CmpntManager )
{
    SPMAIN_TRACEENTRY("RegisterComponentManager");

    if( CORBA::is_nil(CmpntManager) )
    {
        SPMAIN_TRACE_VERBOSE();
        SPMAIN_TRACEEXIT("RegisterComponentManager");
        return FALSE ;
    }
    ComponentManager_var ReturnedManager = ComponentManager::_nil() ;

    try
    {
        ReturnedManager = thePosMESFactory->registerManager( CmpntManager ) ;
        if( CORBA::is_nil(ReturnedManager) )
        {
             SPMAIN_TRACE_VERBOSE2("Error in registering ",CmpntManager->getName());
        }
    }
    catch( CORBA::SystemException &sysEx )
    {
        SPMAIN_TRACE_VERBOSE1("Caught CORBA::SystemException");
        SPMAIN_TRACEEXIT("RegisterComponentManager");
        return FALSE ;
    }
    catch (...)
    {
        SPMAIN_TRACE_VERBOSE1("Caught unknown exception");
        SPMAIN_TRACEEXIT("RegisterComponentManager");
        return FALSE ;
    }
    SPMAIN_TRACE_VERBOSE();
    SPMAIN_TRACEEXIT("RegisterComponentManager");
    return TRUE ;
}

CORBA::Boolean RegisterComponentManager( BRSVariableInfoIMizedMgr_ptr BRSVarInfoManager )
{
    SPMAIN_TRACEENTRY("RegisterComponentManager");

    if( CORBA::is_nil(BRSVarInfoManager) )
    {
        SPMAIN_TRACE_VERBOSE();
        SPMAIN_TRACEEXIT("RegisterComponentManager");
        return FALSE ;
    }

    try
    {
        SPMAIN_TRACE_VERBOSE();
        thePosMESFactory->setUserParameterManager (BRSVarInfoManager) ;
        SPMAIN_TRACE_VERBOSE();
    }
    catch( CORBA::SystemException &sysEx )
    {
        SPMAIN_TRACE_VERBOSE1("Caught CORBA::SystemException");
        SPMAIN_TRACEEXIT("RegisterComponentManager");
        return FALSE ;
    }
    catch (...)
    {
        SPMAIN_TRACE_VERBOSE1("Caught unknown exception");
        SPMAIN_TRACEEXIT("RegisterComponentManager");
        return FALSE ;
    }
    SPMAIN_TRACEEXIT("RegisterComponentManager");
    return TRUE ;
}

// Thread function to create SPFW component Factories.
//
void CreateComponentObjectFactories( void )
{
    SPMAIN_TRACEENTRY("CreateComponentObjectFactories");

#ifdef BUILD_MMSERVER
    CREATE_COMPONENT_FACTORY( PosComponentManagerObjectFactory, theComponentManagerObjectFactory, P0, F0, SiviewMMHostName, SiviewMMServerName ) ;
    CREATE_COMPONENT_FACTORY( SPFactoryManagementObjectFactory, theFactoryManagementObjectFactory, P2, F2, SPFactoryManagementObjectFactoryHostName, SPFactoryManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPCodeManagementObjectFactory, theCodeManagementObjectFactory, P4, F4, SPCodeManagementObjectFactoryHostName, SPCodeManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPDataCollectionManagementObjectFactory, theDataCollectionManagementObjectFactory, P5, F5, SPDataCollectionManagementObjectFactoryHostName, SPDataCollectionManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPDispatchingManagementObjectFactory, theDispatchingManagementObjectFactory, P7, F7, SPDispatchingManagementObjectFactoryHostName, SPDispatchingManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPDurableManagementObjectFactory, theDurableManagementObjectFactory, P8, F8, SPDurableManagementObjectFactoryHostName, SPDurableManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPMachineManagementObjectFactory, theMachineManagementObjectFactory, P10, F10, SPMachineManagementObjectFactoryHostName, SPMachineManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPMessageDistributionManagementObjectFactory, theMessageDistributionManagementObjectFactory, P11, F11, SPMessageDistributionManagementObjectFactoryHostName, SPMessageDistributionManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPProcessDefinitionObjectFactory, theProcessDefinitionManagementObjectFactory, P13, F13, SPProcessDefinitionObjectFactoryHostName, SPProcessDefinitionObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPPlanningObjectFactory, thePlanningObjectFactory, P15, F15, SPPlanningObjectFactoryHostName, SPPlanningObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPProductManagementObjectFactory , theProductManagementObjectFactory , P16, F16, SPProductManagementObjectFactoryHostName, SPProductManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPProductSpecificationObjectFactory, theProductSpecificationManagementObjectFactory, P17, F17, SPProductSpecificationObjectFactoryHostName, SPProductSpecificationObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPPersonManagementObjectFactory, thePersonManagementObjectFactory, P18, F18, SPPersonManagementObjectFactoryHostName, SPPersonManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPRecipeManagementObjectFactory, theRecipeManagementObjectFactory, P19, F19, SPRecipeManagementObjectFactoryHostName, SPRecipeManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPEntityInhibitManagementObjectFactory, theEntityInhibitManagementObjectFactory, P28, F28, SPEntityInhibitManagementObjectFactoryHostName, SPEntityInhibitManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPPartsManagementObjectFactory, thePartsManagementObjectFactory, P30, F30, SPPartsManagementObjectFactoryHostName, SPPartsManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPEventManagementObjectFactory, theEventManagementObjectFactory, P23, F23, SPEventManagementObjectFactoryHostName, SPEventManagementObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( SPAbstractClassObjectFactory, theAbstractClassObjectFactory, P26, F26, SPAbstractClassObjectFactoryHostName, SPAbstractClassObjectFactoryServerName ) ;


#endif  // BUILD_MMSERVER

#ifdef BUILD_BRSSERVER
    CREATE_COMPONENT_FACTORY( BRSVariableManagerObjectFactory, theBRSVariableManagerObjectFactory, P27, F27, BRSVariableManagerObjectFactoryHostName, BRSVariableManagerObjectFactoryServerName ) ;
    CREATE_COMPONENT_FACTORY( BRSManagerObjectFactory, theBRSManagerObjectFactory, P29, F29, BRSManagerObjectFactoryHostName, BRSManagerObjectFactoryServerName ) ;
#endif  // BUILD_BRSSERVER

#ifdef BUILD_PPTSERVER
    PPTServiceManagerObjectFactory_i * aPPTSvcMgrObjFactory = new PPTServiceManagerObjectFactory_i();
    thePPTServiceManagerObjectFactory = new PPTServiceManagerObjectFactory_i();

    char *marker = getenv("MM_MARKER_NAME");
    if ( marker == NULL )
    {
        marker = "MMS"; // default name of marker
    }

    thePPTServiceManagerObjectFactory->_marker(marker);

     EB_SiView_registObjectWithMarker( thePPTServiceManagerObjectFactory->_marker(), thePPTServiceManagerObjectFactory );

    CREATE_COMPONENT_FACTORY( PPTManagerObjectFactory, thePPTManagerObjectFactory, P25, F25, PPTManagerObjectFactoryHostName, PPTManagerObjectFactoryServerName ) ;
#endif  // BUILD_PPTSERVER
    SPMAIN_TRACEEXIT("CreateComponentObjectFactories");
}


// Thread function to create SPFW component managers.
// It also registers the EventBroker.
//
void CreateComponentManagers( void )
{
    SPMAIN_TRACEENTRY("CreateComponentManagers");

#ifdef BUILD_MMSERVER

    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosMESFactory, PosMESFactory, newMESFactory, theComponentManagerObjectFactory, SPMESFactoryObjectFactoryHostName, SPMESFactoryObjectFactoryServerName ) ;
    CosTransactions::Current::commit();

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosAuthenticationManager, PosAuthenticationManager, newAuthenticationManager, theComponentManagerObjectFactory, SPAuthenticationManagementObjectFactoryHostName, SPAuthenticationManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosCodeManager, PosCodeManager, newCodeManager, theComponentManagerObjectFactory, SPCodeManagementObjectFactoryHostName, SPCodeManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosDataCollectionSpecificationManager, PosDataCollectionSpecificationManager, newDataCollectionSpecificationManager, theComponentManagerObjectFactory, SPDataCollectionManagementObjectFactoryHostName, SPDataCollectionManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosDurableManager, PosDurableManager, newDurableManager, theComponentManagerObjectFactory, SPDurableManagementObjectFactoryHostName, SPDurableManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosEventManager, PosEventManager, newEventManager, theComponentManagerObjectFactory, SPEventManagementObjectFactoryHostName, SPEventManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosMachineManager, PosMachineManager, newMachineManager, theComponentManagerObjectFactory, SPMachineManagementObjectFactoryHostName, SPMachineManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosMessageDistributionManager, PosMessageDistributionManager, newMessageDistributionManager, theComponentManagerObjectFactory, SPMessageDistributionManagementObjectFactoryHostName, SPMessageDistributionManagementObjectFactoryServerName  ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosProcessDefinitionManager, PosProcessDefinitionManager, newProcessDefinitionManager, theComponentManagerObjectFactory, SPProcessDefinitionObjectFactoryHostName, SPProcessDefinitionObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosQTimeRestrictionManager, PosQTimeRestrictionManager, newQTimeRestrictionManager, theComponentManagerObjectFactory, SPProcessDefinitionObjectFactoryHostName, SPProcessDefinitionObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosPlanManager, PosPlanManager, newPlanManager, theComponentManagerObjectFactory, SPPlanningObjectFactoryHostName, SPPlanningObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosProductManager, PosProductManager, newProductManager, theComponentManagerObjectFactory, SPProductManagementObjectFactoryHostName, SPProductManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosProductSpecificationManager, PosProductSpecificationManager, newProductSpecificationManager, theComponentManagerObjectFactory, SPProductSpecificationObjectFactoryHostName, SPProductSpecificationObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosPersonManager, PosPersonManager, newPersonManager, theComponentManagerObjectFactory, SPPersonManagementObjectFactoryHostName, SPPersonManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosRecipeManager, PosRecipeManager, newRecipeManager, theComponentManagerObjectFactory, SPRecipeManagementObjectFactoryHostName, SPRecipeManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    if ( !CIMFWStrCmp(SiviewMMHostName, SPEntityInhibitManagementObjectFactoryHostName) &&
          strstr(SPEntityInhibitManagementObjectFactoryServerName, SiviewMMServerName)!=NULL )
    {
        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::begin() ;
        try
        {
            SPMAIN_TRACE_VERBOSE();

            thePosEntityInhibitManager = new PosEntityInhibitManager_i() ;

            if( CORBA::is_nil(thePosEntityInhibitManager) )
            {
                SPMAIN_TRACE_VERBOSE1("Error in creating PosEntityInhibitManager");
                CleanUpServerAndExit() ;
            }
            thePosEntityInhibitManager->_marker("P0/#PosEntityInhibitManager#F0#PosEntityInhibitManager");
            thePosEntityInhibitManager->setTheTIEObject( thePosEntityInhibitManager );

            SPMAIN_TRACE_VERBOSE();
            thePosEntityInhibitManager->touchMe();
            SPMAIN_TRACE_VERBOSE();

            EB_SiView_registObjectWithMarker( thePosEntityInhibitManager->_marker(), thePosEntityInhibitManager );
        }
        catch( CORBA::Exception &Ex )
        {
            SPMAIN_TRACE_VERBOSE1("Caught CORBA::Exception");
            CleanUpServerAndExit() ;
        }
        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::commit() ;
    }

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosPartsManager, PosPartsManager, newPartsManager, theComponentManagerObjectFactory, SPPartsManagementObjectFactoryHostName, SPPartsManagementObjectFactoryServerName ) ;
    CosTransactions::Current::commit() ;

    SPMAIN_TRACE_VERBOSE();
    if ( CIMFWStrCmp( SiviewMMHostName, SPDispatchingManagementObjectFactoryHostName ) == 0 &&
         strstr( SPDispatchingManagementObjectFactoryServerName, SiviewMMServerName ) != NULL )
    {
        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::begin() ;
        try
        {
            SPMAIN_TRACE_VERBOSE();

            thePosDispatchingManager = new PosDispatchingManager_i();

            if( CORBA::is_nil( thePosDispatchingManager ) )
            {
                SPMAIN_TRACE_VERBOSE1("Error in creating PosDispatchingManager");
                CleanUpServerAndExit() ;
            }
            thePosDispatchingManager->_marker( "P0/#PosDispatchingManager#F0#PosDispatchingManager" );
            thePosDispatchingManager->setTheTIEObject( thePosDispatchingManager );

            SPMAIN_TRACE_VERBOSE();
            thePosDispatchingManager->touchMe();
            SPMAIN_TRACE_VERBOSE();
            EB_SiView_registObjectWithMarker( thePosDispatchingManager->_marker(), thePosDispatchingManager );
        }
        catch( CORBA::Exception &Ex )
        {
            SPMAIN_TRACE_VERBOSE1("Caught CORBA::Exception");
            CleanUpServerAndExit() ;
        }
        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::commit() ;
    }

    SPMAIN_TRACE_VERBOSE();
    CosTransactions::Current::begin() ;
    CREATE_COMPONENT_MANAGER( thePosPropertySetManager, PosPropertySetManager, newPropertySetManager, theComponentManagerObjectFactory, SPAbstractClassObjectFactoryHostName, SPAbstractClassObjectFactoryServerName );
    CosTransactions::Current::commit() ;

        // create dispatching logic objects

        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::begin() ;

        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextEDD ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextESD ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextExternalPriority ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextFIFO ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextInternalPriority ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextLRT ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextMaxQTimeFIFO ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextPriorityClass ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextPlanEqp ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextPlanStart ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextSRT ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextSST ) ;
        SPMAIN_TRACE_VERBOSE();
//D8000029        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhereNextDefault ) ;
//D8000029        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextFlowBatch ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextQTimeTargetTime ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextPreCompTime ) ;
        SPMAIN_TRACE_VERBOSE();
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextUTS ) ;              // D8000038
        SPMAIN_TRACE_VERBOSE();                                         //DSN000081739
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextEqpMonitor ) ;         //DSN000081739
        SPMAIN_TRACE_VERBOSE();                                         //DSN000096126
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextDurableESD );          //DSN000096126
        SPMAIN_TRACE_VERBOSE();                                         //DSN000096126
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextDurableFIFO );         //DSN000096126
        SPMAIN_TRACE_VERBOSE();                                         //DSN000096126
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextDurableLRT );          //DSN000096126
        SPMAIN_TRACE_VERBOSE();                                         //DSN000096126
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextDurableMaxQTimeFIFO ); //DSN000096126
        SPMAIN_TRACE_VERBOSE();                                         //DSN000096126
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextDurableSRT );          //DSN000096126
        SPMAIN_TRACE_VERBOSE();                                         //DSN000096126
        CREATE_A_SPFW_SPECIAL_OBJECT( PosWhatNextDurablePreCompTime );  //DSN000096126


        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::commit( FALSE ) ;

        // set dispatching logic objects into dispatching manager

        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::begin() ;

        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextEDD ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextESD ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextExternalPriority ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextFIFO ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextInternalPriority ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextLRT ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextMaxQTimeFIFO ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextPriorityClass ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextPlanEqp ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextPlanStart ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextSRT ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextSST ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextFlowBatch ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextQTimeTargetTime ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextPreCompTime ) ;
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextUTS ) ;              // D8000038
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextEqpMonitor ) ;         //DSN000081739
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextDurableESD );          //DSN000096126
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextDurableFIFO );         //DSN000096126
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextDurableLRT );          //DSN000096126
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextDurableMaxQTimeFIFO ); //DSN000096126
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextDurableSRT );          //DSN000096126
        thePosDispatchingManager->registerWhatNextLogicObject( thePosWhatNextDurablePreCompTime );  //DSN000096126

//D8000029        thePosDispatchingManager->registerWhereNextLogicObject( thePosWhereNextDefault ) ;

        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::commit( FALSE ) ;

        SPMAIN_TRACE_VERBOSE();

#endif // BUILD_MMSERVER

#ifdef BUILD_BRSSERVER
    // Create BRSManager
    if ( strstr(BRSManagerObjectFactoryServerName,SiviewMMServerName)!=NULL &&
         !CIMFWStrCmp(SiviewMMHostName,BRSManagerObjectFactoryHostName) )
    {
        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::begin() ;
        try
        {
            SPMAIN_TRACE_VERBOSE1("Try to create BRSManager");
            theBRSManager = theBRSManagerObjectFactory->createBRSManager();
            EB_SiView_registObjectWithMarker( theBRSManager->_marker(), theBRSManager );
            SPMAIN_TRACE_VERBOSE1("Succeed");
        }
        catch(FrameworkErrorSignal &fwes)
        {
            SPMAIN_TRACE_FRAMEWORKERRORSIGNAL(fwes);
            CleanUpServerAndExit() ;
        }
        catch(CosTransactions::SubtransactionsUnavailable)
        {
            SPMAIN_TRACE_VERBOSE1("Caught CosTransactions::SubtransactionsUnavailable");
            CleanUpServerAndExit() ;
        }
        catch(CosTransactions::NoTransaction)
        {
            SPMAIN_TRACE_VERBOSE1("Caught CosTransactions::NoTransaction");
            CleanUpServerAndExit() ;
        }
        catch(CosTransactions::HeuristicMixed)
        {
            SPMAIN_TRACE_VERBOSE1("Caught CosTransactions::HeuristicMixed");
            CleanUpServerAndExit() ;
        }
        catch(CosTransactions::HeuristicHazard)
        {
            SPMAIN_TRACE_VERBOSE1("Caught CosTransactions::HeuristicHazard");
            CleanUpServerAndExit() ;
        }
        catch(CORBA::SystemException &sex)
        {
            SPMAIN_TRACE_VERBOSE2("Caught CORBA::SystemException",sex.minor());
            CleanUpServerAndExit() ;
        }
        catch(...)
        {
            SPMAIN_TRACE_VERBOSE2("Caught exception:","unknown");
            CleanUpServerAndExit() ;
        }
        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::commit() ;
    }

    // Create BRSVariableInfoManager
    if ( !CIMFWStrCmp(SiviewMMHostName, BRSVariableManagerObjectFactoryHostName) &&
         strstr(BRSVariableManagerObjectFactoryServerName, SiviewMMServerName)!=NULL )
    {
        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::begin() ;
        char *aVarMgrStrObjRef = NULL;

        try
        {
            SPMAIN_TRACE_VERBOSE();
            aVarMgrStrObjRef = theBRSVariableManagerObjectFactory->getVariableInfoManagerObjectReference();
            SPMAIN_TRACE_VERBOSE();
        }
        catch (...)
        {
            SPMAIN_TRACE_VERBOSE1("Caught unknown exception");
            CleanUpServerAndExit() ;
        }

        if ( aVarMgrStrObjRef == NULL || !CIMFWStrLen(aVarMgrStrObjRef) )
        {
            SPMAIN_TRACE_VERBOSE1("BRSVariableInfoIMizedMgr is not found");
            SPMAIN_TRACE_VERBOSE();
//P7000317            theUserParameterManager = theBRSVariableManagerObjectFactory->newBRSVariableInfoIMizedMgr() ;
//P7000317            SPMAIN_TRACE_VERBOSE();
//P7000317            if ( CORBA::is_nil(theUserParameterManager) )
//P7000317            {
//P7000317                SPMAIN_TRACE_VERBOSE1("Error in creating BRSVarialeInfoIMizedMgr");
                CleanUpServerAndExit() ;
//P7000317            }
//P7000317            SPMAIN_TRACE_VERBOSE();
//P7000317            CreateDefaultVariablesAndDataTypes() ;
        }
        else
        {
           SPMAIN_TRACE_VERBOSE2("BRSVariableInfoIMizedMgr is found ", aVarMgrStrObjRef);
           try
           {
                SPMAIN_TRACE_VERBOSE();
                CORBA::Object_var anObj = SP_STRING_TO_OBJECT( aVarMgrStrObjRef ) ;
                SPMAIN_TRACE_VERBOSE();
                if( CORBA::is_nil(anObj) )
                {
                    SPMAIN_TRACE_VERBOSE1("Error in reactivating BRSVariableInfoIMizedMgr");
                    CleanUpServerAndExit() ;
                }
                SPMAIN_TRACE_VERBOSE();
                theUserParameterManager = BRSVariableInfoIMizedMgr::_narrow( anObj ) ;
                SPMAIN_TRACE_VERBOSE();
                theUserParameterManager->touchMe();
                SPMAIN_TRACE_VERBOSE();
            }
            catch( CORBA::Exception &Ex )
            {
                SPMAIN_TRACE_VERBOSE1("Caught CORBA::Exception");
            }
        }
        SPMAIN_TRACE_VERBOSE();
        delete aVarMgrStrObjRef;
        CosTransactions::Current::commit() ;
    }
#endif // BUILD_BRSSERVER

    // Register component managers in MESFactory
    if ( strstr(PosMESFactoryServerName,SiviewMMServerName)!=NULL &&
         !CIMFWStrCmp(SiviewMMHostName,PosMESFactoryHostName) )
    {
        SPMAIN_TRACE_VERBOSE1("Regisering component managers to MES Factory" )

        CosTransactions::Current::begin() ;

        REGISTER_COMPONENT_MANAGER( thePosAuthenticationManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosCodeManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosDataCollectionSpecificationManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosDispatchingManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosDurableManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosEventManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosMachineManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosMessageDistributionManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosProcessDefinitionManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosQTimeRestrictionManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosPlanManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosProductManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosProductSpecificationManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosPersonManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosRecipeManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosEntityInhibitManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosPartsManager ) ;
        REGISTER_COMPONENT_MANAGER( theUserParameterManager ) ;
        REGISTER_COMPONENT_MANAGER( thePosPropertySetManager ) ;

        SPMAIN_TRACE_VERBOSE();
        CosTransactions::Current::commit() ;

        SPMAIN_TRACE_VERBOSE1("Complete regiser component managers to MES Factory" )
    }

// PPTServiceManager and PPTManager instances will be created in process filter
// when they are in different server from framework.
// If they are created before server ready, it causes infinite messaging loop at commit.

    if ( !CIMFWStrCmp(SiviewMMServerName,strchr(PPTServiceManagerObjectFactoryServerName,':')) &&
         !CIMFWStrCmp(SiviewMMHostName,PPTServiceManagerObjectFactoryHostName)        )
    {
        SPMAIN_TRACE_VERBOSE();
        try
        {
            SPMAIN_TRACE_VERBOSE1("Create PPT Service Manager ");
            char* svcmgrName = getenv( "MM_SVCMGR_MARKER_NAME" );
            if( svcmgrName == NULL )
            {
                svcmgrName = "thePPTServiceManager" ;
            }
            SPMAIN_TRACE_VERBOSE2("PPTServiceManager\'s Marker  = ", svcmgrName);

            PPTServiceManager_ptr thePPTServiceManager = thePPTServiceManagerObjectFactory->createPPTServiceManager();
            thePPTServiceManager->_marker( svcmgrName );

            EB_SiView_registObjectWithMarker( thePPTServiceManager->_marker(), thePPTServiceManager );

            SPMAIN_TRACE_VERBOSE1("Write ServiceManager's object reference");
//PSIV00001581            char* PPTObjName = ::IMRegistry::orbPtr->object_to_string( thePPTServiceManager );
            CORBA::String_var PPTObjName = ::IMRegistry::orbPtr->object_to_string( thePPTServiceManager );  //PSIV00001581

            const char* mmserverName = getenv( "MM_SERVER_NAME" );
            const char* hostName     = getenv( "MM_HOST_NAME" );
            const char* sambaPath    = getenv( "SP_EBROKERTCS_SAMBAPATH" );
            char TCS_EBrokerFilePath[1024];
            memset(TCS_EBrokerFilePath, 0, sizeof(TCS_EBrokerFilePath));

            SPMAIN_TRACE_VERBOSE2("MM_SERVER_NAME----------->", mmserverName);
            SPMAIN_TRACE_VERBOSE2("MM_HOST_NAME------------->", hostName);
            SPMAIN_TRACE_VERBOSE2("SP_EBROKERTCS_SAMBAPATH-->", sambaPath);

            char* mmSevNameOnly = NULL;
            if ( NULL != mmserverName && NULL != hostName )
            {
                mmSevNameOnly = strchr(mmserverName, ':');
                if ( NULL != mmSevNameOnly )
                {
                    mmSevNameOnly++;
                    if ( 0 == CIMFWStrLen(mmSevNameOnly) )
                    {
                        mmSevNameOnly = NULL;
                    }
                }
                else
                {
                    mmSevNameOnly = (char*)mmserverName;
                }
            }

            if ( NULL != sambaPath && 0 < CIMFWStrLen(sambaPath) )
            {
                CIMFWStrCat(TCS_EBrokerFilePath, sambaPath);
                if ( '/' != TCS_EBrokerFilePath[CIMFWStrLen(TCS_EBrokerFilePath)-1] )
                {
                    CIMFWStrCat(TCS_EBrokerFilePath, "/");
                }
            }

            if ( NULL != mmSevNameOnly )
            {
                CIMFWStrCat(TCS_EBrokerFilePath, mmSevNameOnly);
                CIMFWStrCat(TCS_EBrokerFilePath, SP_MMOBJREF_SUFFIX_FOR_STCS);
                CIMFWStrCat(TCS_EBrokerFilePath, ".");
                CIMFWStrCat(TCS_EBrokerFilePath, hostName);
            }
            else
            {
                CIMFWStrCat(TCS_EBrokerFilePath, "MMOBJREF2.OUT");
            }
            SPMAIN_TRACE_VERBOSE2("ObjRef file name===>", TCS_EBrokerFilePath);

            FILE* fp = fopen(TCS_EBrokerFilePath, "w");
            if ( NULL == fp )
            {
                SPMAIN_TRACE_VERBOSE1("ObjRef file can not open!!");
            }
            else
            {
//DSIV00002334                fprintf(fp, "%s", PPTObjName);
                fprintf(fp, "%s", (const char*)PPTObjName);     //DSIV00002334
                fclose(fp);
            }
        }
        catch(FrameworkErrorSignal &fwes)
        {
            SPMAIN_TRACE_FRAMEWORKERRORSIGNAL(fwes);
            CleanUpServerAndExit() ;
        }
        catch(CosTransactions::SubtransactionsUnavailable)
        {
            SPMAIN_TRACE_VERBOSE1("Caught CosTransactions::SubtransactionsUnavailable");
            CleanUpServerAndExit() ;
        }
        catch(CosTransactions::NoTransaction)
        {
            SPMAIN_TRACE_VERBOSE1("Caught CosTransactions::NoTransaction");
            CleanUpServerAndExit() ;
        }
        catch(CosTransactions::HeuristicMixed)
        {
            SPMAIN_TRACE_VERBOSE1("Caught CosTransactions::HeuristicMixed");
            CleanUpServerAndExit() ;
        }
        catch(CosTransactions::HeuristicHazard)
        {
            SPMAIN_TRACE_VERBOSE1("Caught CosTransactions::HeuristicHazard");
            CleanUpServerAndExit() ;
        }
        catch(CORBA::SystemException &sex)
        {
            SPMAIN_TRACE_VERBOSE2("Caught CORBA::SystemException",sex.minor());
            CleanUpServerAndExit() ;
        }
        catch(...)
        {
            SPMAIN_TRACE_VERBOSE2("Caught exception:","unknown");
            CleanUpServerAndExit() ;
        }
        SPMAIN_TRACE_VERBOSE();
    }

    SPMAIN_TRACEEXIT("CreateComponentManagers");
}


// Function to execute server for all SPFW components.
void SuperPOSEIDONServer( void )
{
    SPMAIN_TRACEENTRY("SuperPOSEIDONServer");
    try
    {
        SPMAIN_TRACE_VERBOSE();
        BOSServer.Listen() ;
        SPMAIN_TRACE_VERBOSE();
    }
    catch( CORBA::SystemException &sysEx )
    {
        SPMAIN_TRACE_VERBOSE1("Caught CORBA::SystemException");
        CleanUpServerAndExit() ;

    }
    catch (...)
    {
        SPMAIN_TRACE_VERBOSE1("Caught unknown exception");
        CleanUpServerAndExit() ;
    }
    SPMAIN_TRACEEXIT("SuperPOSEIDONServer");
}

// Creation of default Data Types and System Variables required for BRScript
//P7000317void CreateDefaultVariablesAndDataTypes()
//P7000317{
//P7000317    SPMAIN_TRACEENTRY("CreateDefaultVariablesAndDataTypes");
//P7000317
//P7000317    SPMAIN_TRACE_VERBOSE();
//P7000317    theUserParameterManager->createDataTypeNamed( SP_ParValType_String ) ;
//P7000317    theUserParameterManager->createDataTypeNamed( SP_ParValType_Integer ) ;
//P7000317    theUserParameterManager->createDataTypeNamed( SP_ParValType_Real ) ;
//P7000317    theUserParameterManager->createDataTypeNamed( SP_ParValType_TableSS ) ;
//P7000317    theUserParameterManager->createDataTypeNamed( SP_ParValType_TableSI ) ;
//P7000317    theUserParameterManager->createDataTypeNamed( SP_ParValType_TableSR ) ;
//P7000317    theUserParameterManager->createDataTypeNamed( SP_ParValType_StrSeq ) ;
//P7000317
//P7000317    SPMAIN_TRACE_VERBOSE();
//P7000317    theUserParameterManager->createSystemVariableNamed( "MESFactory", SP_ParValType_String, "Dummy System variable required for Parameter class default ID", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "CurrentDate", SP_ParValType_String, "YYYYMMDD", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "CurrentTime", SP_ParValType_String, "HHMMSS", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "CurrentTimeStamp", SP_ParValType_String, "YYYY-MM-DD-HH.MM.SS.nnnnnn (ISO Format)", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "CurrentUser", SP_ParValType_String, "User ID who claimed", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotID", SP_ParValType_String, "Lot ID", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotCustomerCode", SP_ParValType_String, "Customer Code of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotOrderNumber", SP_ParValType_String, "Order Number of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotCommitDueDate", SP_ParValType_String, "Commit Due Date YYMMDD of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotOwner", SP_ParValType_String, "Owner of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotType", SP_ParValType_String, "Lot Type of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotWaferQuantity", SP_ParValType_Integer, "Wafer quantity of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotDieQuantity", SP_ParValType_Integer, "Good Die Quantity of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotCarrierID", SP_ParValType_String, "Carrier ID of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotTechnologyID", SP_ParValType_String, "Technology ID of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotProductID", SP_ParValType_String, "Product ID of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotRouteID", SP_ParValType_String, "Route ID of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotHoldState", SP_ParValType_String, "Hold state of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotHoldTypes", SP_ParValType_StrSeq, "Hold types of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotFinishedState", SP_ParValType_String, "Finished state of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotInventoryState", SP_ParValType_String, "Inventory State of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotBank", SP_ParValType_String, "Bank ID the lot is in", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotPriorityClass", SP_ParValType_String, "Priority class of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LastUser", SP_ParValType_String, "User ID who claimed for the lot at last", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LastTimeStamp", SP_ParValType_String, "Time stamp when the lot was claimed at last", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotQrestTargetOperations", SP_ParValType_StrSeq, "Operation code of Q-restriction target", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotQrestTimes", SP_ParValType_StrSeq, "Q-restriction time stamp at the target operation", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "CompletedOperationRouteID", SP_ParValType_String, "Completed Operation Number", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "CompletedOperation", SP_ParValType_String, "Completed Operation Code", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "CompletedOperationPassCount", SP_ParValType_Integer, "Completed Operation Pass count", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "CompletedProcess", SP_ParValType_String, "Completed Process Definition ID", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "UsedEquipment", SP_ParValType_String, "Equipment ID used for the process", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "UsedLogicalRecipe", SP_ParValType_String, "Logical Recipe ID used for the process", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "UsedRecipe", SP_ParValType_String, "Recipe ID used for the process", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "UsedFixture", SP_ParValType_String, "UsedFixture[0]", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "UsedReticle", SP_ParValType_String, "UsedReticle[0]", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "UsedFixtures", SP_ParValType_StrSeq, "Fixture IDs used for the process", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "UsedReticles", SP_ParValType_StrSeq, "Reticle IDs used for the process", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317    theUserParameterManager->createSystemVariableNamed( "LotProductGroupID", SP_ParValType_String, "Product Group ID of the lot", "ALL;PRE1;PRE2;POST;" ) ;
//P7000317
//P7000317    SPMAIN_TRACE_VERBOSE();
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Lot, "LotID" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Eqp, "UsedEquipment" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_LogicalRecipe, "UsedLogicalRecipe" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_MachineRecipe, "UsedRecipe" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Reticle, "UsedReticle" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Fixture, "UsedFixture" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Route, "LotRouteID" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Process, "CompletedProcess" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Product, "LotProductID" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Technology, "LotTechnologyID" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_User, "CurrentUser" ) ;
//P7000317    theUserParameterManager->createParameterClassNamed( SP_ParValClass_Factory, "MESFactory" ) ;
//P7000317
//P7000317    SPMAIN_TRACEEXIT("CreateDefaultVariablesAndDataTypes");
//P7000317}

const char* getComponentManagerMarker(const char* marker_envvar, const char* defaultmarker)
{
     const char* retVal = getenv(marker_envvar);

     if ( retVal == NULL )
     {
         retVal = defaultmarker;
     }

     return retVal;
}


#ifdef _AIX
static int SignalsDefault= 0; // should be zero for production, 1 for debug
#endif

#define NS_FAIL -1
// Binding Object Name to Naming Service
int bindObjects(PPTServiceManagerObjectFactory_var ptr,const char *subName,const char *nsName)
{
    CORBA::ORB_var orbVar;
    CORBA::Object_var objVar;
    CosNaming::NamingContext_var rootContext;
    CosNaming::Name_var name;

    // Searching Naming Service Root Context
    try  // for siview
    {
        objVar  = orbVar->resolve_initial_references("NameService");

        if(rootContext=CosNaming::NamingContext::_narrow(objVar))
        {
            SPMAIN_TRACE_VERBOSE1("Getting Root Context Succeeded");
        }
        else
        {
            SPMAIN_TRACE_VERBOSE1("Can not get root context");
            return(NS_FAIL);
        }
    }
    catch (...)
    {
        SPMAIN_TRACE_VERBOSE1("Unexpected Exception at getrootcontext");
        return(NS_FAIL);
    }

    // Searching Object in Naming Service
    SPMAIN_TRACE_VERBOSE1(SIVIEW);
    SPMAIN_TRACE_VERBOSE1(subName);
    SPMAIN_TRACE_VERBOSE1(nsName);

    // binding siview context
    name = new CosNaming::Name();
    name->length(4);
    (*name)[0].id=CORBA::string_dup(SIVIEW);
    (*name)[0].kind=CORBA::string_dup("");
    (*name)[1].id=CORBA::string_dup(subName);
    (*name)[1].kind=CORBA::string_dup("");
    (*name)[2].id=CORBA::string_dup(nsName);
    (*name)[2].kind=CORBA::string_dup("");
    (*name)[3].id=CORBA::string_dup(nsName);
    (*name)[3].kind=CORBA::string_dup("object");

    try
    {
        CORBA::Object_var obj;
        SPMAIN_TRACE_VERBOSE1("about to call resolve to find an object in naming space");
        obj = rootContext->resolve(name);
        SPMAIN_TRACE_VERBOSE1("Found an object in naming space");
        rootContext->rebind(name,ptr);     // Rebind Existing Object
        return(0);
    }
    catch (const CosNaming::NamingContext::NotFound& resolve_nf)
    {
        SPMAIN_TRACE_VERBOSE1("Fail to resolve name due to CosNaming::NamingContext::NotFound");

        SPMAIN_TRACE_VERBOSE1("Not found reason is not_context");

        // creating context "root.siview"
        CosNaming::NamingContext_var siviewContext;
        CosNaming::Name_var siviewName = new CosNaming::Name();
        siviewName->length(1);
        (*siviewName)[0].id   = CORBA::string_dup(SIVIEW);
        (*siviewName)[0].kind = CORBA::string_dup("");

        try
        {
            SPMAIN_TRACE_VERBOSE1("About to create new context for siview");
            siviewContext = rootContext->bind_new_context(siviewName);
            SPMAIN_TRACE_VERBOSE1("Completed to create the context for siview");
        }
        catch (const CosNaming::NamingContext::AlreadyBound& bindnew_ab)
        {
            SPMAIN_TRACE_VERBOSE1("Already the context for siview exists");

            try
            {
                SPMAIN_TRACE_VERBOSE1("About to resolve context for siview");
                CORBA::Object_var obj = rootContext->resolve(siviewName);
                siviewContext = CosNaming::NamingContext::_narrow(obj);
                SPMAIN_TRACE_VERBOSE1("Completed to resolve context for siview");
            }
            catch (...)
            {
                SPMAIN_TRACE_VERBOSE1("Fail to binding new context for siview");
                return(NS_FAIL);
            }

        }
        catch (...)
        {
            SPMAIN_TRACE_VERBOSE1("Fail to creating new context for siview");
            return(NS_FAIL);
        }

        // creating context "root.siview.server"
        CosNaming::NamingContext_var serverContext;
        CosNaming::Name_var serverName = new CosNaming::Name();
        serverName->length(1);
        (*serverName)[0].id   = CORBA::string_dup(subName);
        (*serverName)[0].kind = CORBA::string_dup("");

        try
        {
            SPMAIN_TRACE_VERBOSE1("About to create new context for siview.server");
            serverContext = siviewContext->bind_new_context(serverName);
            SPMAIN_TRACE_VERBOSE1("Completed to create the context for siview.server");
        }
        catch (const CosNaming::NamingContext::AlreadyBound& bindnew_ab)
        {
            SPMAIN_TRACE_VERBOSE1("Already the context for siview.server exists");

            try
            {
                SPMAIN_TRACE_VERBOSE1("About to resolve context for siview.server");
                CORBA::Object_var obj = siviewContext->resolve(serverName);
                serverContext = CosNaming::NamingContext::_narrow(obj);
                SPMAIN_TRACE_VERBOSE1("Completed to create the context for siview.server");
            }
            catch (...)
            {
                SPMAIN_TRACE_VERBOSE1("Fail to binding new context for siview.server");
                return(NS_FAIL);
            }

        }
        catch (...)
        {
            SPMAIN_TRACE_VERBOSE1("Fail to creating new context for siview.server");
            return(NS_FAIL);
        }

        // creating context "root.siview.server.class"
        CosNaming::NamingContext_var classContext;
        CosNaming::Name_var className = new CosNaming::Name();
        className->length(1);
        (*className)[0].id   = CORBA::string_dup(nsName);
        (*className)[0].kind = CORBA::string_dup("");

        try
        {
            SPMAIN_TRACE_VERBOSE1("About to create new context for siview.server.class");
            classContext = serverContext->bind_new_context(className);
            SPMAIN_TRACE_VERBOSE1("Completed to create the context for siview.server.class");
        }
        catch (const CosNaming::NamingContext::AlreadyBound& bindnew_ab)
        {
            SPMAIN_TRACE_VERBOSE1("Already the context for siview.server.class exists");

            try
            {
                SPMAIN_TRACE_VERBOSE1("About to resolve context for siview.server.class");
                CORBA::Object_var obj = serverContext->resolve(className);
                classContext = CosNaming::NamingContext::_narrow(obj);
                SPMAIN_TRACE_VERBOSE1("Completed to create the context for siview.server.class");
            }
            catch (...)
            {
                SPMAIN_TRACE_VERBOSE1("Fail to binding new context for siview.server");
                return(NS_FAIL);
            }

        }
        catch (...)
        {
            SPMAIN_TRACE_VERBOSE1("Fail to creating new context for siview.server.class");
            return(NS_FAIL);
        }

        // binding object
        CosNaming::Name_var objectName = new CosNaming::Name;
        objectName->length(1);
        (*objectName)[0].id   = CORBA::string_dup(nsName);
        (*objectName)[0].kind = CORBA::string_dup("object");
        try
        {
            SPMAIN_TRACE_VERBOSE1("about to call bind an object into naming space");
            classContext->bind(objectName,ptr);
            SPMAIN_TRACE_VERBOSE1("Bound an object into naming space");
            return(0);
        }
        catch (const CosNaming::NamingContext::NotFound& bind_nf)
        {
            SPMAIN_TRACE_VERBOSE1("Fail to bind object due to CosNaming::NamingContext::NotFound");
            switch ( bind_nf.why )
            {
                case CosNaming::NamingContext::missing_node:
                     SPMAIN_TRACE_VERBOSE1("Not found reason is missing_node");
                     break;
                case CosNaming::NamingContext::not_context:
                     SPMAIN_TRACE_VERBOSE1("Not found reason is not_context");
                     break;
                case CosNaming::NamingContext::not_object:
                     SPMAIN_TRACE_VERBOSE1("Not found reason is not_object");
                     break;
            }

            return(NS_FAIL);
        }
        catch (const CosNaming::NamingContext::CannotProceed& bind_cp)
        {
            SPMAIN_TRACE_VERBOSE1("Fail to bind object due to CosNaming::NamingContext::CannotProceed");
            return(NS_FAIL);
        }
        catch (const CosNaming::NamingContext::AlreadyBound& bind_ab)
        {
            SPMAIN_TRACE_VERBOSE1("Fail to bind object due to CosNaming::NamingContext::AlreadyBound");
            return(NS_FAIL);
        }
        catch (const CosNaming::NamingContext::InvalidName& bind_in)
        {
            SPMAIN_TRACE_VERBOSE1("Fail to bind object due to CosNaming::NamingContext::InvalidName");
            return(NS_FAIL);
        }
        catch (...)
        {
            SPMAIN_TRACE_VERBOSE1("Fail to bind object");
            return(NS_FAIL);
        }
    }
    catch (...)
    {
      SPMAIN_TRACE_VERBOSE1("Fail to bind object");
      cout << "Unexpected Exception.." << endl;
      return(NS_FAIL);
    }
}

void setPerRequestServiceContextHandler()
{

    SPMAIN_TRACE_VERBOSE1("Get Secure Release Version set to  : ");

    // Data Initialize for Version Check
    long nchkSVSecureReleaseVersion=0;
    long nchkMMSSecureReleaseVersion=0;
    long nchkTCSSecureReleaseVersion=0;
    long nchkXMSSecureReleaseVersion=0;
    long nchkSPCSecureReleaseVersion=0;

    // Check SP_SECURE_RELEASEVERSION ENV Value
    char* chkSVSecureReleaseVersion= getenv("SP_SECURE_RELEASEVERSION");
    if(chkSVSecureReleaseVersion != NULL)
    {
      nchkSVSecureReleaseVersion= atol(chkSVSecureReleaseVersion);
    }

    // Check SP_SECURE_RELEASEVERSION_MMS
    char* chkMMSSecureReleaseVersion= getenv("SP_SECURE_RELEASEVERSION_MMS");
    if(chkMMSSecureReleaseVersion != NULL)
    {
      // If Secure Release Version is on
      nchkMMSSecureReleaseVersion= atol(chkMMSSecureReleaseVersion);
    }

    // Check SP_SECURE_RELEASEVERSION_TCS
    char* chkTCSSecureReleaseVersion= getenv("SP_SECURE_RELEASEVERSION_TCS");
    if(chkTCSSecureReleaseVersion != NULL)
    {
      nchkTCSSecureReleaseVersion= atol(chkTCSSecureReleaseVersion);
    }

    // Check SP_SECURE_RELEASEVERSION_XMS
    char* chkXMSSecureReleaseVersion= getenv("SP_SECURE_RELEASEVERSION_XMS");
    if(chkXMSSecureReleaseVersion != NULL)
    {
      // If Secure Release Version is on
      nchkXMSSecureReleaseVersion= atol(chkXMSSecureReleaseVersion);
    }

    // Check SP_SECURE_RELEASEVERSION_SPC
    char* chkSPCSecureReleaseVersion= getenv("SP_SECURE_RELEASEVERSION_SPC");
    if(chkSPCSecureReleaseVersion != NULL)
    {
      // If Secure Release Version is on
      nchkSPCSecureReleaseVersion= atol(chkSPCSecureReleaseVersion);
    }

    // If there is at least 1 flag  , set Version Check Logic
    if( (nchkSVSecureReleaseVersion  == 1) || (nchkMMSSecureReleaseVersion == 1 ) ||
        (nchkTCSSecureReleaseVersion == 1) || (nchkXMSSecureReleaseVersion == 1 ) ||
        (nchkSPCSecureReleaseVersion == 1) )
    {
      SPMAIN_TRACE_VERBOSE1("Setting Version Check Server/Client");
      MyServerInitializer_ptr initObj = new MyServerInitializer_Impl();
      PortableInterceptor::register_orb_initializer ( initObj );
    }
}

//DSN000073319// DSN000052888 add start
//DSN000073319void setBufferedLoggerHandler()
//DSN000073319{
//DSN000073319    SPMAIN_TRACE_VERBOSE1("Setting Buffered logger for tracelog");
//DSN000073319    BufferedLoggerKickerPICInitializer_ptr kickerInitPtr = new BufferedLoggerKickerPICInitializer_Impl();
//DSN000073319    PortableInterceptor::register_orb_initializer(kickerInitPtr);
//DSN000073319}
//DSN000073319// DSN000052888 add end
//DSN000073319
//DSN000073319// DSN000052888 add start
//DSN000073319void initBufferedLogger()
//DSN000073319{
//DSN000073319    setBufferedLoggerHandler();
//DSN000073319    bufferedloggerutil::init_threadkey();
//DSN000073319    bufferedloggerutil::init_kickerkey();
//DSN000073319}
//DSN000073319// DSN000052888 add end
