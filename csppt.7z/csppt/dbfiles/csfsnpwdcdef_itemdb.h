//
// Modification History :
// Date       Version       Author          Request No.          Comment
// ---------- ------------- --------------  -------------------- -------------------------------
// 2017/10/24 INN-R170016   Yangxiaojun     INN-R170016          NPW Monitor Customization
//

char            hCSFSNPWDCDEF_ITEMDCDEF_ID[65];
sqlint32        hCSFSNPWDCDEF_ITEMSEQ_NO;
char            hCSFSNPWDCDEF_ITEMDCITEM_NAME[65];
char            hCSFSNPWDCDEF_ITEMDATA_TYPE[13];
char            hCSFSNPWDCDEF_ITEMCLAIM_USER_ID[65];
char            hCSFSNPWDCDEF_ITEMCLAIM_TIME[27];
