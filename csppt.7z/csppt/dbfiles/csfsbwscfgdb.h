//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  Cheng Li       INN-R170017          Initial Release
//
char             hCSFSBWSCFGBWS_ID[65];
sqlint32         hCSFSBWSCFGMAX_CAPACITY;
char             hCSFSBWSCFGCLAIM_TIME[27];
char             hCSFSBWSCFGCLAIM_USER_ID[65];
char             hCSFSBWSCFGCLAIM_MEMO[257];
