//
// Modification History :
// Date       Version       Author          Request No.          Comment
// ---------- ------------- --------------  -------------------- -------------------------------
// 2017/10/24 INN-R170016   Yangxiaojun     INN-R170016          NPW Monitor Customization
//

char            hCSFSNPWSTBBWS_ID[65];
char            hCSFSNPWSTBPORT_ID[65];
char            hCSFSNPWSTBCAST_ID[65];
char            hCSFSNPWSTBNPW_TYPE[21];
char            hCSFSNPWSTBEQPMON_ID[65];
char            hCSFSNPWSTBCLAIM_USER_ID[65];
char            hCSFSNPWSTBCLAIM_TIME[27];

char            hCSFSNPWSTB_SLOTMAPCAST_ID[65];
sqlint32        hCSFSNPWSTB_SLOTMAPPOSITION;
char            hCSFSNPWSTB_SLOTMAPWAFER_ID[65];
char            hCSFSNPWSTB_SLOTMAPLOT_ID[65];
char            hCSFSNPWSTB_SLOTMAPPRODSPEC_ID[65];
char            hCSFSNPWSTB_SLOTMAPDEST_PRODSPEC_ID[65];
char            hCSFSNPWSTB_SLOTMAPSUB_LOT_TYPE[65];

