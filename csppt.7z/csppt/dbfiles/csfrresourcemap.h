//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// xxxx/xx/xx INN-R17001720  XXX            INN-R170020          Initial Release
//

sqlint32         hCSFRRESOURCEMAPSEQUENCE_ID;
char             hCSFRRESOURCEMAPCHAMBER_ID[65];
char             hCSFRRESOURCEMAPREPRESENTATION_ID[2];
