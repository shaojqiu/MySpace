//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView - CS PPT Service Manager Event Log
// Name : cs_ppteventlog.hpp
//
// Change history:
//
// Date     Defect#      Person        Comments
// -------- ------------ ------------- ----------------------------------------------
// 01/07/13 DSN000079252 S.Yamamoto    Initial release
//
#include "ppteventlog.hpp"

//override PPTEventLog
class CS_PPTEventLog : public PPTEventLog
{
public:
    CS_PPTEventLog();
    CS_PPTEventLog(void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms);
    ~CS_PPTEventLog();
     void resetParameters(void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms);
};

class CS_PPTEventLogFactory
{
public:
    CS_PPTEventLogFactory();
    ~CS_PPTEventLogFactory();

public:
    static PPTEventLogBase* createEventLogObject( void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms );
};
