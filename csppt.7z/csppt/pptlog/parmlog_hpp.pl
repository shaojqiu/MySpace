################################################################################
#
# SCCS ID: @(#) 1.1 superpos/src/spppt/source/posppt/pptlog/parmlog_hpp.pl, mm_srv_40a_ppt, mm_srv_40a_ppt 11/12/01 15:04:47 [ 11/12/01 15:04:48 ]
#
# Parameter Log Output - Code Generator
#
# (c) Copyright: Information Technology Solutions Co., Ltd, 2001. All rights reserved
# (c) Copyright: International Business Machines Coorporation, 2001. All rights reserved.
#
# File Name:
#	parmlog_hpp.pl
#
# Description:
#	Generate parameter(structures) output codes. 
#
# Histroy:
# Date	      No.      Person          Comments
# ---------- -------- --------------- ------------------------------------
# 2001/11/12 D40A0013 Y.Yamaguchi     Newly created. 
# 2011/03/16 SIV00003059 S.Yamamoto   add code for avoid duplicate error.
#
################################################################################

$debug = 0;		# debug mode

# application definition
require "parmlog.pl";

# output header
&outputHeader("Parameter output headers");

# analyze interface definition
require "analyzetypedef.pl";

# do each struct
foreach $struct ( @structList )
{
	$structName = $$struct[0];
	$typedefName = $typedefStruct{ $structName };
	@memberList = @{$$struct[1]};

	if( ! $typedefName )
	{
		die "Not found typedef for \"$structName\" !\n";
	}

	print "//structName = $structName\n" if $debug;
	print "//typedefName = $typedefName\n" if $debug;

	# function name
	print "void outVariable( const $typedefName& object, char* name );\n";
}

# do each sequence
foreach $sequenceType ( @sequenceList )
{
	$typedefName = $typedefSequence{ $sequenceType };
	if( ! $typedefName )
	{
		die "Not found typedef for sequence of \"$sequenceType\" !\n";
	}

	if( $sequenceType =~ ',[1-9]' ){ print "#ifdef EBROKER\n"; } #SIV00003059

	print "//sequenceType = $sequenceType\n" if $debug;
	print "//typedefName = $typedefName\n" if $debug;

	#function name
	print "void outVariable( const $typedefName& object, char* name );\n";

    if( $sequenceType =~ ',[1-9]' ){ print "#endif\n"; } #SIV00003059
}

# do each exception
foreach $exception ( @exceptionList )
{
	$exceptionName = $$exception[0];
	@memberList = @{$$exception[1]};

	print "//exceptionName = $exceptionName\n" if $debug;

	# function name
	print "void outVariable( const $exceptionName& object, char* name );\n";
}
