################################################################################
#
# SCCS ID: @(#) 1.3 superpos/src/csppt/source/posppt/pptlog/cs_parmlog_cpp.pl, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:00:31 [ 6/9/03 14:00:33 ]
#
# Parameter Log Output - Code Generator
#
# (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2003. All rights reserved
# (c) Copyright: International Business Machines Coorporation, 2003. All rights reserved.
#
# File Name:
#	cs_paramlog_cpp.pl
#
# Description:
#	Generate parameter(structures) output codes. 
#
# ** Notice **
#   This is a sample code for customizing a PPT ServiceManager.
#   IBM desn't ensure  the behaviour in all cases and all situations.
#   If you customize PPT ServiceManager using this examples from this code,
#   you have to ensure the behavior of your code through your test process.
#
# Histroy:
# Date	      No.      Person          Comments
# ---------- -------- --------------- ------------------------------------
# 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
# 2011/03/16 SIV00003059 S.Yamamoto   add code for avoid duplicate error.
#
################################################################################

$debug = 0;		# debug mode

# application definition
require "parmlog.pl";

# output header
&outputHeader("Parameter output for structures");

# analyze interface definition
require "analyzetypedef.pl";

# do each struct
foreach $struct ( @structList )
{
	$structName = $$struct[0];
	$typedefName = $typedefStruct{ $structName };
	@memberList = @{$$struct[1]};

	if( ! $typedefName )
	{
		die "Not found typedef for \"$structName\" !\n";
	}

	print "\n";
	print "//structName = $structName\n" if $debug;
	print "//typedefName = $typedefName\n" if $debug;

	# function name
	print "void CS_LogFile::outVariable( const $typedefName& object, char* name )\n";

	# start function
	print "{\n";
	print "\tLOG_STRUCT($typedefName);\n";

	# do each member
	foreach $memberName ( @memberList )
	{
		print "\tLOG_MEMBER($memberName);\n";
	}

	#end function
	print "\tLOG_END;\n";
	print "}\n";
}

# do each sequence
foreach $sequenceType ( @sequenceList )
{
	$typedefName = $typedefSequence{ $sequenceType };
	if( ! $typedefName )
	{
		die "Not found typedef for sequence of \"$sequenceType\" !\n";
	}

	print "\n";
    if( $sequenceType =~ ',[1-9]' ){ print "#ifdef EBROKER\n"; } #SIV00003059

	print "//sequenceType = $sequenceType\n" if $debug;
	print "//typedefName = $typedefName\n" if $debug;

	#function name
	print "void CS_LogFile::outVariable( const $typedefName& object, char* name )\n";

	# start function
	print "{\n";
	print "\tLOG_SEQUENCE($typedefName);\n";

	# end function
	print "}\n";

    if( $sequenceType =~ ',[1-9]' ){ print "#endif\n"; } #SIV00003059
}

# do each exception
foreach $exception ( @exceptionList )
{
	$exceptionName = $$exception[0];
	@memberList = @{$$exception[1]};

	print "\n";
	print "//exceptionName = $exceptionName\n" if $debug;

	# function name
	print "void CS_LogFile::outVariable( const $exceptionName& object, char* name )\n";

	# start function
	print "{\n";
	print "\tLOG_STRUCT($exceptionName);\n";

	# do each member
	foreach $memberName ( @memberList )
	{
		print "\tLOG_MEMBER($memberName);\n";
	}

	#end function
	print "\tLOG_END;\n";
	print "}\n";
}
