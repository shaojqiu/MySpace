#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptlog/cs_pptparmlog.cpp, mm_srv_90e_cspp, mm_srv_90e_cspp 7/13/07 19:59:59 [ 7/13/07 20:00:00 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// Siview 
// Name: cs_pptparmlog.cpp
// Description : Implementation of Customized Parameter Log
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2005/06/13 D6000354 K.Murakami      follow up for eBroker.
// -------- ------------ ------------- ----------------------------------------------
// 29/07/13 DSN000079778 S.Yamamoto    Performance Improvement of Any
// 
//

#include <time.h>
#include <iomanip.h>

#include "cs_pptparmlog.hpp"

CS_PPTParameterLog::CS_PPTParameterLog( const char* opname, const char* node, const char* user, const char* desc ) : 
ParameterLog( opname, node, user, desc )
{
    #ifdef PARMLOG_DEBUG
    cout << "entering CS_PPTParameterLog::CS_PPTParameterLog" << endl;
    #endif
}

CS_PPTParameterLog::~CS_PPTParameterLog()
{
    #ifdef PARMLOG_DEBUG
    cout << "entering CS_PPTParameterLog::~CS_PPTParameterLog" << endl;
    #endif
}

void CS_PPTParameterLog::outVariable( CORBA::SystemException& object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":(CORBA::SystemException)" << endl;
    _indent++;
    outVariable( object.minor()    , "minor"     );
    outVariable( object.id()       , "id"        );
#ifndef EBROKER                                     //D6000354
    outVariable( object.param()    , "param"     );
#endif                                              //D6000354
    outVariable( object.completed(), "completed" );
    _indent--;
}

void CS_PPTParameterLog::outVariable( const int object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":" << object << endl;
}

void CS_PPTParameterLog::outVariable( const char* object, char* name )
{
    *record << setw( _indent ) << "";
    if( object == NULL )
        *record << name << ":" << endl;
    else
        *record << name << ":\"" << object << "\"" << endl;
}


#include "outvariable.cpp"
#include "cs_outvariable.cpp"


//DSN000079778 add start
typedef  bool (*PExtractFunc)( CS_PPTParameterLog *paramlog, const CORBA::Any& object, char *name );

#include <strstream>
#include "pptparmlogutil.hpp"

CallBackFuncTable<PExtractFunc> callbackFuncs;

void CS_PPTParameterLog_genJumpTable();

static char * getKeyFromTypeCode( const CORBA::TypeCode_ptr tc );
//DSN000079778 add end


//D6000354 void CS_PPTParameterLog::outVariable( const CORBA::any& object, char* name )
void CS_PPTParameterLog::outVariable( const CORBA::Any& object, char* name )         //D6000354
{
    if( object.value() == NULL )    //0.01
    {
        *record << setw( _indent ) << "";
        *record << name << ":(any[])" << endl;
        return;
    }
    CS_PPTParameterLog_genJumpTable(); //DSN000079778

    LOG_ANY_TYPE(CORBA::Short,short);
    LOG_ANY_TYPE(CORBA::Long,long);
    LOG_ANY_TYPE(CORBA::UShort,unsigned short);
    LOG_ANY_TYPE(CORBA::ULong,unsigned long);
    LOG_ANY_TYPE(CORBA::Float,float);
    LOG_ANY_TYPE(CORBA::Double,double);
    LOG_ANY_TYPE(char*,string);

    LOG_ANY_CHAR(CORBA::Boolean,boolean,CORBA::Any::to_boolean);
    LOG_ANY_CHAR(CORBA::Octet,octet,CORBA::Any::to_octet);
    LOG_ANY_CHAR(CORBA::Char,char,CORBA::Any::to_char);

    LOG_ANY_CLASS(stringSequence);

//DSN000079778    #include "outany.cpp"
//DSN000079778    #include "cs_outany.cpp"
//DSN000079778 add start
    CORBA::TypeCode_var tc = object.type();
    
    CORBA::String_var key = getKeyFromTypeCode( tc ) ;

    PExtractFunc pFunc = callbackFuncs.findFunc( (const char*)key );
    if( pFunc != NULL )
    {
        if( false != (*pFunc)( this, object, name ) )
        {
            return;
        }
    }
//DSN000079778 add end

    *record << setw( _indent ) << "";
    *record << name << ":(any[unknown])" << endl;
}


//DSN000079778 add start
class _CS_PPTParameterLog : public CS_PPTParameterLog
{
public:
    _CS_PPTParameterLog();//not implement
    ~_CS_PPTParameterLog();//not implement

    ostrstream &Record() { return *record; }
    int &Indent() { return _indent; }
};

#undef LOG_ANY_CLASS
#define LOG_ANY_CLASS(x)\
static bool CS_PPTParameterLog_extract##x( CS_PPTParameterLog *parmlog, const CORBA::Any& object, char *name )\
    {\
        _CS_PPTParameterLog *_paramlog = (_CS_PPTParameterLog *)parmlog;\
        x *tobj;\
        if( object >>= tobj )\
        {\
            _paramlog->Record() << setw( _paramlog->Indent() ) << ""; \
            _paramlog->Record() << name << ":(any[" #x "])" << endl;\
            _paramlog->Indent()++;\
            parmlog->outVariable(*tobj, name);\
            _paramlog->Indent()--;\
            return true;\
        }\
        return false;\
    }

//define extract methods
#include "outany.cpp"
#include "cs_outany.cpp"

char *getKeyFromTypeCode( const CORBA::TypeCode_ptr ptc )
{
    char buf[512];
    buf[0] = 0;
    std::ostrstream key(buf,sizeof(buf)-1);

    CORBA::TypeCode_ptr tc = (CORBA::TypeCode_ptr)ptc;
    CORBA::TypeCode_var _tc;//don't set tc here. ( original tc is managed by caller. )
    while(1)
    {
        while( tc->kind() == CORBA::tk_alias )
        {
            tc = tc->content_type();
            _tc = tc;
        }
        CORBA::TCKind kind = tc->kind();
        if( kind == CORBA::tk_struct )
        {
            key << tc->id();
            break;
        }
        else if( kind == CORBA::tk_sequence )
        {
            tc = tc->content_type();
            _tc = tc;
            
            key << "sequence:";
            continue;
        }
        else
        {
            key << (int)kind;
            break;
        }
    }
    key << std::ends;
    return CORBA::string_dup(key.str());
}

//register method
void CS_PPTParameterLog_registExtractor( const char *typeName, const CORBA::TypeCode_ptr ptc, PExtractFunc func )
{
    if( ptc->kind() == CORBA::tk_struct )
    {
        callbackFuncs.set( (char*)ptc->id() , func );//for reduction of memory usage
    }
    else
    {
        char *key = getKeyFromTypeCode( ptc );
        callbackFuncs.set( key , func );
    }
}

#undef LOG_ANY_CLASS
#define LOG_ANY_CLASS(x)\
    CS_PPTParameterLog_registExtractor(#x,_tc_##x,&CS_PPTParameterLog_extract##x);

//generate type id vs function table for extraction
static void CS_PPTParameterLog_generateFunctionTable()
{
    #include "outany.cpp"
    #include "cs_outany.cpp"
}

//for initialize at 1st time only
#include <pthread.h>

static pthread_once_t CS_PPTParameterLog_once_key = PTHREAD_ONCE_INIT;

//for external
void CS_PPTParameterLog_genJumpTable()
{
    pthread_once( &CS_PPTParameterLog_once_key, CS_PPTParameterLog_generateFunctionTable );
}
//DSN000079778 add end
