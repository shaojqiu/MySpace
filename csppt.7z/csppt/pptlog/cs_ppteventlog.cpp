//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SuperPOSEIDON
// Name: cs_ppteventlog.cpp
//
// Change history:
//
// Date     Defect#  Person            Comments
// -------- ------------ ------------- ----------------------------------------------
// 01/07/13 DSN000079252 S.Yamamoto    Initial release
//

#include "cs_ppteventlog.hpp"

//registration for Customized PPTEventLog class.
class CS_PPTEventLogInitializer
{
public:
	CS_PPTEventLogInitializer()
	{
		PPTEventLogFactory::registCreateEventLogFunction( CS_PPTEventLogFactory::createEventLogObject );
	}
	~CS_PPTEventLogInitializer()
	{
	}
};

static CS_PPTEventLogInitializer registrationOfCS_PPTEventLog;

//ctor
CS_PPTEventLog::CS_PPTEventLog() : PPTEventLog()
{
//	cout << __FUNCTION__ << endl;
}

CS_PPTEventLog::CS_PPTEventLog(void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms )
 : PPTEventLog( retVal, objCommonIn, parms )
{
//	cout << __FUNCTION__ << endl;

#if 1
	//call sendMessage
	PPTEventLog::sendMessage(INCOMING);
#else
	//sample 1
	pptObjCommonIn *pOriginal = theObjCommonIn;
	pptObjCommonIn tmp = *theObjCommonIn;
	tmp.strUser.clientNode = "HOGEHOGE1"; //overwrite event log column
	theObjCommonIn = &tmp;
	PPTEventLog::sendMessage(INCOMING);
	theObjCommonIn = pOriginal;
#endif
}

//dtor
CS_PPTEventLog::~CS_PPTEventLog()
{
//	cout << __FUNCTION__ << endl;

#if 1
	//call sendMessage
	PPTEventLog::sendMessage(OUTGOING);
#else
	//sample 1
	pptObjCommonIn *pOriginal = theObjCommonIn;
	pptObjCommonIn tmp = *theObjCommonIn;
	tmp.strUser.clientNode = "HOGEHOGE1"; //overwrite event log column
	theObjCommonIn = &tmp;
	PPTEventLog::sendMessage(OUTGOING);
	theObjCommonIn = pOriginal;
#endif
}

//resetParameters
void CS_PPTEventLog::resetParameters( void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms)
{
//	cout << __FUNCTION__ << endl;
	//call original function
	PPTEventLog::resetParameters(retVal, objCommonIn, parms);
}

//create method of CS Event log class
PPTEventLogBase *CS_PPTEventLogFactory::createEventLogObject( void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms)
{
//	cout << "return CS_PPTEventLog" << endl;
	//return CS_PPTEventLog instance 
	return new CS_PPTEventLog( retVal, objCommonIn, parms );
}

