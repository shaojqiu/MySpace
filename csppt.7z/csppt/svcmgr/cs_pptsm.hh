//----------------------------------------------------------------------------
//
//  Generated from cs_pptsm.idl
//  On Tuesday, November 14, 2017 11:54:47 AM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_pptsm_server_defined
#ifndef _cs_pptsm_hh_included
#define _cs_pptsm_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif
#ifndef _DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT
#define _DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT 
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_PPTServiceManager_idl 
#define CS_PPTServiceManager_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _pptsm_hh_included
#include <pptsm.hh>
#endif
#else
#ifndef _pptsm_hh_included
#include "pptsm.hh"
#endif
#endif

// Begin mapping for interface ::CS_PPTServiceManager

#ifndef _DCL_CS_PPTServiceManager
#define _DCL_CS_PPTServiceManager
#ifndef _DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT
#define _DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT 
#endif
class _DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT
   CS_PPTServiceManager
    ;
class _DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT CS_PPTServiceManager_var;
typedef CS_PPTServiceManager* CS_PPTServiceManager_ptr;
typedef CS_PPTServiceManager* CS_PPTServiceManagerRef;

_DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT CORBA::Object_ptr SOMLINK CS_PPTServiceManager_getBase(void *);

_DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT CS_PPTServiceManager_ptr SOMLINK CS_PPTServiceManager_aux_duplicate(CS_PPTServiceManager_ptr);
_DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT CS_PPTServiceManager_ptr SOMLINK CS_PPTServiceManager_aux_narrow(::CORBA::Object_ptr);
_DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT CS_PPTServiceManager_ptr SOMLINK CS_PPTServiceManager_aux_nil();
_DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT const char* SOMLINK CS_PPTServiceManager_aux_CN();

    class _DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT CS_PPTServiceManager_StructElem
    {
        public:

        CS_PPTServiceManager_StructElem ();

        CS_PPTServiceManager_StructElem (const CS_PPTServiceManager_StructElem &s);

        CS_PPTServiceManager_StructElem &operator= (CS_PPTServiceManager_ptr p);

        CS_PPTServiceManager_StructElem &operator= (CS_PPTServiceManager_var v);

        CS_PPTServiceManager_StructElem &operator= (const CS_PPTServiceManager_StructElem &s);

        ~CS_PPTServiceManager_StructElem ();

        operator ::CORBA::Object_ptr() const;

        operator CS_PPTServiceManager_ptr () const;

        CS_PPTServiceManager_ptr _ptr;

    }; // CS_PPTServiceManager_StructElem

    class _DCL_CS_PPTServiceManager_SOM_IMPORTEXPORT CS_PPTServiceManager_SeqElem
    {
       public:

       CS_PPTServiceManager_SeqElem (CS_PPTServiceManager_ptr* p, unsigned char rel);

       CS_PPTServiceManager_SeqElem &operator= (CS_PPTServiceManager_ptr p);

        CS_PPTServiceManager_SeqElem &operator= (CS_PPTServiceManager_var v);

       CS_PPTServiceManager_SeqElem &operator= (const CS_PPTServiceManager_SeqElem &s);

       operator CS_PPTServiceManager_ptr () const;

       CS_PPTServiceManager_ptr operator->() const;

       protected:
       CS_PPTServiceManager_ptr *_ptr;
       unsigned char _release;
   }; // CS_PPTServiceManager_SeqElem


class  CS_PPTServiceManager_var : public ::CORBA::__vb__
{
    public:

    CS_PPTServiceManager_var ();
    CS_PPTServiceManager_var (CS_PPTServiceManager *p);
    CS_PPTServiceManager_var (const CS_PPTServiceManager_var &s);
    CS_PPTServiceManager_var (const CS_PPTServiceManager_StructElem &s);
    CS_PPTServiceManager_var (const CS_PPTServiceManager_SeqElem &s);
    CS_PPTServiceManager_var &operator= (CS_PPTServiceManager *p);
    CS_PPTServiceManager_var &operator= (const CS_PPTServiceManager_var &s);
    CS_PPTServiceManager_var &operator= (const CS_PPTServiceManager_StructElem &s);
    CS_PPTServiceManager_var &operator= (const CS_PPTServiceManager_SeqElem &s);
    ~CS_PPTServiceManager_var ();
    CS_PPTServiceManager_ptr in() const;
    CS_PPTServiceManager_ptr& inout();
    CS_PPTServiceManager_ptr& out();
    CS_PPTServiceManager_ptr _retn();
    CS_PPTServiceManager_ptr operator-> ();
    operator CS_PPTServiceManager_ptr& ();
    operator const CS_PPTServiceManager_ptr& () const;
#ifdef __sun
    operator CS_PPTServiceManager_ptr () { return _ptr; };
#endif

    protected:
       CS_PPTServiceManager *_ptr;

    private:
       ::CORBA::__vb__& operator= (::CORBA::__vb__&);

};  // CS_PPTServiceManager_var

#endif /* _DCL_CS_PPTServiceManager */ 


class 

   CS_PPTServiceManager
: virtual public ::PPTServiceManager {

public: 
    static const char* CS_PPTServiceManager_CN;
    static const char* CS_PPTServiceManager_RID;
    typedef CS_PPTServiceManager_ptr _ptr_type;
    typedef CS_PPTServiceManager_var _var_type;

    /* for Orbix compatibility */
    virtual void *_deref();

protected: 
    /* constructor */

   CS_PPTServiceManager
();
protected: 
    virtual ~

   CS_PPTServiceManager
();
private: 

   CS_PPTServiceManager
    (const 
   CS_PPTServiceManager
     &); // unimplemented

    void operator=(const 
   CS_PPTServiceManager
     &); // unimplemented
public: 

    static CS_PPTServiceManager_ptr SOMLINK _duplicate(CS_PPTServiceManager_ptr obj);

    static CS_PPTServiceManager_ptr SOMLINK _narrow (::CORBA::Object_ptr);

    virtual void* _has_ancestor(const char* classname);
    static CS_PPTServiceManager_ptr SOMLINK _nil ();

    CS_PPTServiceManager_ptr _self();
    CS_PPTServiceManager_ptr _this();
    virtual void *_SOMThis(const char *& ifname);


    virtual  ::CORBA::Void  CS_PPTServiceManager_init (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Void  _req_CS_PPTServiceManager_init (::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Void  CS_PPTServiceManager_uninit (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Void  _req_CS_PPTServiceManager_uninit (::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csTestFunctionResult*  TxTestFunction (const ::pptUser& requestUserID, const char* FunctionID, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& routeID, const char* operationNumber, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csTestFunctionResult*  _req_TxTestFunction (const ::pptUser& requestUserID, const char* FunctionID, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& routeID, const char* operationNumber, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpInAuditListInqResult*  CS_TxEqpInAuditListInq (const ::pptUser& requestUserID, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpInAuditListInqResult*  _req_CS_TxEqpInAuditListInq (const ::pptUser& requestUserID, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpListByOwnerInqResult*  CS_TxEqpListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpListByOwnerInqResult*  _req_CS_TxEqpListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpRMSFlgInqResult*  CS_TxEqpRMSFlgInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpRMSFlgInqResult*  _req_CS_TxEqpRMSFlgInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csPrivilegeCheckForRMSReqResult*  CS_TxPrivilegeCheckForRMSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csPrivilegeCheckForRMSReqResult*  _req_CS_TxPrivilegeCheckForRMSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpInfoListByOwnerInqResult*  CS_TxEqpInfoListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpInfoListByOwnerInqResult*  _req_CS_TxEqpInfoListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpRelatedRecipeIDAuditFlagListInqResult*  CS_TxEqpRelatedRecipeIDAuditFlagListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean getAuditFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpRelatedRecipeIDAuditFlagListInqResult*  _req_CS_TxEqpRelatedRecipeIDAuditFlagListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean getAuditFlag, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csCassetteInspectionTimeResetReqResult*  CS_TxCassetteInspectionTimeResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csCassetteInspectionTimeResetReqResult*  _req_CS_TxCassetteInspectionTimeResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csCassettePMTimeResetReqResult*  CS_TxCassettePMTimeResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csCassettePMTimeResetReqResult*  _req_CS_TxCassettePMTimeResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csReticleWaferCountResetReqResult*  CS_TxReticleWaferCountResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csReticleWaferCountResetReqResult*  _req_CS_TxReticleWaferCountResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csReticleUsedDurationResetReqResult*  CS_TxReticleUsedDurationResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csReticleUsedDurationResetReqResult*  _req_CS_TxReticleUsedDurationResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csVendorLotReserveReqResult*  CS_TxVendorLotReserveReq (const ::pptUser& requestUserID, const ::objectIdentifier& bankID, const char* lotType, const char* subLotType, const char* sourceProduct, const ::pptNewLotAttributes& strNewLotAttributes, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csVendorLotReserveReqResult*  _req_CS_TxVendorLotReserveReq (const ::pptUser& requestUserID, const ::objectIdentifier& bankID, const char* lotType, const char* subLotType, const char* sourceProduct, const ::pptNewLotAttributes& strNewLotAttributes, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csVendorLotReserveCancelReqResult*  CS_TxVendorLotReserveCancelReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csVendorLotReserveCancelReqResult*  _req_CS_TxVendorLotReserveCancelReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csVendorLotReserveListInqResult*  CS_TxVendorLotReserveListInq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csVendorLotReserveListInqResult*  _req_CS_TxVendorLotReserveListInq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csUserCertifiedSkillDeleteReqResult*  CS_TxUserCertifiedSkillDeleteReq (const ::pptUser& requestUserID, const ::csUserCertifiedSkillDeleteReqInParm& strUserCertifiedSkillDeleteReqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csUserCertifiedSkillDeleteReqResult*  _req_CS_TxUserCertifiedSkillDeleteReq (const ::pptUser& requestUserID, const ::csUserCertifiedSkillDeleteReqInParm& strUserCertifiedSkillDeleteReqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csUserCertifiedSkillUpdateReqResult*  CS_TxUserCertifiedSkillUpdateReq (const ::pptUser& requestUserID, const ::csUserCertifiedSkillUpdateReqInParm& strUserCertifiedSkillUpdateReqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csUserCertifiedSkillUpdateReqResult*  _req_CS_TxUserCertifiedSkillUpdateReq (const ::pptUser& requestUserID, const ::csUserCertifiedSkillUpdateReqInParm& strUserCertifiedSkillUpdateReqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csUserCertifyCheckInqResult*  CS_TxUserCertifyCheckInq (const ::pptUser& requestUserID, const ::csUserCertifyCheckInqInParm& strUserCertifyCheckInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csUserCertifyCheckInqResult*  _req_CS_TxUserCertifyCheckInq (const ::pptUser& requestUserID, const ::csUserCertifyCheckInqInParm& strUserCertifyCheckInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csUserCertifiedEqpTypeSkillInqResult*  CS_TxUserCertifiedEqpTypeSkillInq (const ::pptUser& requestUserID, const ::csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csUserCertifiedEqpTypeSkillInqResult*  _req_CS_TxUserCertifiedEqpTypeSkillInq (const ::pptUser& requestUserID, const ::csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csFixtureTouchCountRptResult*  CS_TxFixtureTouchCountRpt (const ::pptUser& requestUserID, const ::csFixtureTouchCountRptInParm& strFixtureTouchCountRptInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csFixtureTouchCountRptResult*  _req_CS_TxFixtureTouchCountRpt (const ::pptUser& requestUserID, const ::csFixtureTouchCountRptInParm& strFixtureTouchCountRptInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csCarrierUsageTypeChangeReqResult*  CS_TxCarrierUsageTypeChangeReq (const ::pptUser& requestUserID, const ::csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csCarrierUsageTypeChangeReqResult*  _req_CS_TxCarrierUsageTypeChangeReq (const ::pptUser& requestUserID, const ::csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptStartLotsReservationForInternalBufferReqResult*  CS_TxStartLotsReservationForInternalBufferReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean skipBatchSizeFlag, ::CORBA::Boolean skipWaferCountFlag, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptStartLotsReservationForInternalBufferReqResult*  _req_CS_TxStartLotsReservationForInternalBufferReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean skipBatchSizeFlag, ::CORBA::Boolean skipWaferCountFlag, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csLotComplicatedHoldReqResult*  CS_TxLotComplicatedHoldReq (const ::pptUser& requestUserID, const ::csLotComplicatedHoldReqInParam& strLotComplicatedHoldReqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csLotComplicatedHoldReqResult*  _req_CS_TxLotComplicatedHoldReq (const ::pptUser& requestUserID, const ::csLotComplicatedHoldReqInParam& strLotComplicatedHoldReqInParam, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpMonitorInventoryListInqResult*  CS_TxEqpMonitorInventoryListInq (const ::pptUser& requestUserID, const ::csEqpMonitorInventoryListInqInParm& strEqpMonitorInventoryListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpMonitorInventoryListInqResult*  _req_CS_TxEqpMonitorInventoryListInq (const ::pptUser& requestUserID, const ::csEqpMonitorInventoryListInqInParm& strEqpMonitorInventoryListInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpMonitorInventoryUpdateReqResult*  CS_TxEqpMonitorInventoryUpdateReq (const ::pptUser& requestUserID, const ::csEqpMonitorInventoryUpdateReqInParm& strEqpMonitorInventoryUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpMonitorInventoryUpdateReqResult*  _req_CS_TxEqpMonitorInventoryUpdateReq (const ::pptUser& requestUserID, const ::csEqpMonitorInventoryUpdateReqInParm& strEqpMonitorInventoryUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csBWSWaferOutAndSTBReqResult*  CS_TxBWSWaferOutAndSTBReq (const ::pptUser& requestUserID, const ::csBWSWaferOutAndSTBReqInParm& strBWSWaferOutAndSTBReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csBWSWaferOutAndSTBReqResult*  _req_CS_TxBWSWaferOutAndSTBReq (const ::pptUser& requestUserID, const ::csBWSWaferOutAndSTBReqInParm& strBWSWaferOutAndSTBReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpMonitorLotSTBReqResult*  CS_TxEqpMonitorLotSTBReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotSTBReqInParm& strEqpMonitorLotSTBReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpMonitorLotSTBReqResult*  _req_CS_TxEqpMonitorLotSTBReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotSTBReqInParm& strEqpMonitorLotSTBReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpMonitorLotAllBranchReqResult*  CS_TxEqpMonitorLotAllBranchReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotAllBranchReqInParm& strEqpMonitorLotAllBranchReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpMonitorLotAllBranchReqResult*  _req_CS_TxEqpMonitorLotAllBranchReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotAllBranchReqInParm& strEqpMonitorLotAllBranchReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpMonitorLotPrepareIDResetReqResult*  CS_TxEqpMonitorLotPrepareIDResetReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotPrepareIDResetReqInParm& strEqpMonitorLotPrepareIDResetReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpMonitorLotPrepareIDResetReqResult*  _req_CS_TxEqpMonitorLotPrepareIDResetReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotPrepareIDResetReqInParm& strEqpMonitorLotPrepareIDResetReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDowngradeItemListInqResult*  CS_TxDowngradeItemListInq (const ::pptUser& requestUserID, const ::csDowngradeItemListInqInParm& strDowngradeItemListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDowngradeItemListInqResult*  _req_CS_TxDowngradeItemListInq (const ::pptUser& requestUserID, const ::csDowngradeItemListInqInParm& strDowngradeItemListInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDowngradeItemUpdateReqResult*  CS_TxDowngradeItemUpdateReq (const ::pptUser& requestUserID, const ::csDowngradeItemUpdateReqInParm& strDowngradeItemUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDowngradeItemUpdateReqResult*  _req_CS_TxDowngradeItemUpdateReq (const ::pptUser& requestUserID, const ::csDowngradeItemUpdateReqInParm& strDowngradeItemUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDowngradeSettingListInqResult*  CS_TxDowngradeSettingListInq (const ::pptUser& requestUserID, const ::csDowngradeSettingListInqInParm& strDowngradeSettingListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDowngradeSettingListInqResult*  _req_CS_TxDowngradeSettingListInq (const ::pptUser& requestUserID, const ::csDowngradeSettingListInqInParm& strDowngradeSettingListInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDowngradeSettingUpdateReqResult*  CS_TxDowngradeSettingUpdateReq (const ::pptUser& requestUserID, const ::csDowngradeSettingUpdateReqInParm& strDowngradeSettingUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDowngradeSettingUpdateReqResult*  _req_CS_TxDowngradeSettingUpdateReq (const ::pptUser& requestUserID, const ::csDowngradeSettingUpdateReqInParm& strDowngradeSettingUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpMonitorListInqResult*  CS_TxEqpMonitorListInq (const ::pptUser& requestUserID, const ::pptEqpMonitorListInqInParm& strEqpMonitorListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpMonitorListInqResult*  _req_CS_TxEqpMonitorListInq (const ::pptUser& requestUserID, const ::pptEqpMonitorListInqInParm& strEqpMonitorListInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptEqpMonitorUpdateReqResult*  CS_TxEqpMonitorUpdateReq (const ::pptUser& requestUserID, const ::csEqpMonitorUpdateReqInParm& strEqpMonitorUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptEqpMonitorUpdateReqResult*  _req_CS_TxEqpMonitorUpdateReq (const ::pptUser& requestUserID, const ::csEqpMonitorUpdateReqInParm& strEqpMonitorUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpMonitorSourceCandidateInfoInqResult*  CS_TxEqpMonitorSourceCandidateInfoInq (const ::pptUser& requestUserID, const ::csEqpMonitorSourceCandidateInfoInqInParm& strEqpMonitorSourceCandidateInfoInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpMonitorSourceCandidateInfoInqResult*  _req_CS_TxEqpMonitorSourceCandidateInfoInq (const ::pptUser& requestUserID, const ::csEqpMonitorSourceCandidateInfoInqInParm& strEqpMonitorSourceCandidateInfoInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csBWSWaferListInqResult*  CS_TxBWSWaferListInq (const ::pptUser& requestUserID, const ::csBWSWaferListInqInParm& strBWSWaferListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csBWSWaferListInqResult*  _req_CS_TxBWSWaferListInq (const ::pptUser& requestUserID, const ::csBWSWaferListInqInParm& strBWSWaferListInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csNPWProductChangeReqResult*  CS_TxNPWProductChangeReq (const ::pptUser& requestUserID, const ::csNPWProductChangeReqInParm& strNPWProductChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csNPWProductChangeReqResult*  _req_CS_TxNPWProductChangeReq (const ::pptUser& requestUserID, const ::csNPWProductChangeReqInParm& strNPWProductChangeReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csBWSConfigInfoInqResult*  CS_TxBWSConfigInfoInq (const ::pptUser& requestUserID, const ::csBWSConfigInfoInqInParm& strBWSConfigInfoInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csBWSConfigInfoInqResult*  _req_CS_TxBWSConfigInfoInq (const ::pptUser& requestUserID, const ::csBWSConfigInfoInqInParm& strBWSConfigInfoInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csBWSConfigChangeReqResult*  CS_TxBWSConfigChangeReq (const ::pptUser& requestUserID, const ::csBWSConfigChangeReqInParm& strBWSConfigChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csBWSConfigChangeReqResult*  _req_CS_TxBWSConfigChangeReq (const ::pptUser& requestUserID, const ::csBWSConfigChangeReqInParm& strBWSConfigChangeReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csBWSInventoryReqResult*  CS_TxBWSInventoryReq (const ::pptUser& requestUserID, const ::csBWSInventoryReqInParm& strBWSInventoryReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csBWSInventoryReqResult*  _req_CS_TxBWSInventoryReq (const ::pptUser& requestUserID, const ::csBWSInventoryReqInParm& strBWSInventoryReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDurableDeliveryReqResult*  CS_TxDurableDeliveryReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDurableDeliveryReqResult*  _req_CS_TxDurableDeliveryReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDurableOpeCompForInternalBufferReqResult*  CS_TxDurableOpeCompForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOpeCompForInternalBufferReqInParam& strDurableOpeCompForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDurableOpeCompForInternalBufferReqResult*  _req_CS_TxDurableOpeCompForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOpeCompForInternalBufferReqInParam& strDurableOpeCompForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDurableOperationStartCancelForInternalBufferReqResult*  CS_TxDurableOperationStartCancelForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOperationStartCancelForInternalBufferReqInParam& strDurableOperationStartCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDurableOperationStartCancelForInternalBufferReqResult*  _req_CS_TxDurableOperationStartCancelForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOperationStartCancelForInternalBufferReqInParam& strDurableOperationStartCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDurableOperationStartForInternalBufferReqResult*  CS_TxDurableOperationStartForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOperationStartForInternalBufferReqInParam& strDurableOperationStartForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDurableOperationStartForInternalBufferReqResult*  _req_CS_TxDurableOperationStartForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOperationStartForInternalBufferReqInParam& strDurableOperationStartForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDurablesInfoForOpeStartForInternalBufferInqResult*  CS_TxDurablesInfoForOpeStartForInternalBufferInq (const ::pptUser& requestUserID, const ::csDurablesInfoForOpeStartForInternalBufferInqInParam& strDurablesInfoForOpeStartForInternalBufferInqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDurablesInfoForOpeStartForInternalBufferInqResult*  _req_CS_TxDurablesInfoForOpeStartForInternalBufferInq (const ::pptUser& requestUserID, const ::csDurablesInfoForOpeStartForInternalBufferInqInParam& strDurablesInfoForOpeStartForInternalBufferInqInParam, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csDurablesInfoForStartReservationForInternalBufferInqResult*  CS_TxDurablesInfoForStartReservationForInternalBufferInq (const ::pptUser& requestUserID, const ::csDurablesInfoForStartReservationForInternalBufferInqInParam& strDurablesInfoForStartReservationForInternalBufferInqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csDurablesInfoForStartReservationForInternalBufferInqResult*  _req_CS_TxDurablesInfoForStartReservationForInternalBufferInq (const ::pptUser& requestUserID, const ::csDurablesInfoForStartReservationForInternalBufferInqInParam& strDurablesInfoForStartReservationForInternalBufferInqInParam, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csStartDurablesReservationCancelForInternalBufferReqResult*  CS_TxStartDurablesReservationCancelForInternalBufferReq (const ::pptUser& requestUserID, const ::csStartDurablesReservationCancelForInternalBufferReqInParam& strStartDurablesReservationCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csStartDurablesReservationCancelForInternalBufferReqResult*  _req_CS_TxStartDurablesReservationCancelForInternalBufferReq (const ::pptUser& requestUserID, const ::csStartDurablesReservationCancelForInternalBufferReqInParam& strStartDurablesReservationCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csStartDurablesReservationForInternalBufferReqResult*  CS_TxStartDurablesReservationForInternalBufferReq (const ::pptUser& requestUserID, const ::csStartDurablesReservationForInternalBufferReqInParam& strStartDurablesReservationForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csStartDurablesReservationForInternalBufferReqResult*  _req_CS_TxStartDurablesReservationForInternalBufferReq (const ::pptUser& requestUserID, const ::csStartDurablesReservationForInternalBufferReqInParam& strStartDurablesReservationForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:

}; // end nesting scope for interface class ::CS_PPTServiceManager

#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif

class  CS_PPTServiceManager_ORBProxy : virtual public 

   CS_PPTServiceManager
, virtual public ::PPTServiceManager_ORBProxy {

public: 
    CS_PPTServiceManager_ORBProxy ();

    virtual  ::CORBA::Void  CS_PPTServiceManager_init (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Void  CS_PPTServiceManager_uninit (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csTestFunctionResult*  TxTestFunction (const ::pptUser& requestUserID, const char* FunctionID, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& routeID, const char* operationNumber, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpInAuditListInqResult*  CS_TxEqpInAuditListInq (const ::pptUser& requestUserID, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpListByOwnerInqResult*  CS_TxEqpListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpRMSFlgInqResult*  CS_TxEqpRMSFlgInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csPrivilegeCheckForRMSReqResult*  CS_TxPrivilegeCheckForRMSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpInfoListByOwnerInqResult*  CS_TxEqpInfoListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpRelatedRecipeIDAuditFlagListInqResult*  CS_TxEqpRelatedRecipeIDAuditFlagListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean getAuditFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csCassetteInspectionTimeResetReqResult*  CS_TxCassetteInspectionTimeResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csCassettePMTimeResetReqResult*  CS_TxCassettePMTimeResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csReticleWaferCountResetReqResult*  CS_TxReticleWaferCountResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csReticleUsedDurationResetReqResult*  CS_TxReticleUsedDurationResetReq (const ::pptUser& requestUserID, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csVendorLotReserveReqResult*  CS_TxVendorLotReserveReq (const ::pptUser& requestUserID, const ::objectIdentifier& bankID, const char* lotType, const char* subLotType, const char* sourceProduct, const ::pptNewLotAttributes& strNewLotAttributes, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csVendorLotReserveCancelReqResult*  CS_TxVendorLotReserveCancelReq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csVendorLotReserveListInqResult*  CS_TxVendorLotReserveListInq (const ::pptUser& requestUserID, const ::objectIdentifier& cassetteID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csUserCertifiedSkillDeleteReqResult*  CS_TxUserCertifiedSkillDeleteReq (const ::pptUser& requestUserID, const ::csUserCertifiedSkillDeleteReqInParm& strUserCertifiedSkillDeleteReqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csUserCertifiedSkillUpdateReqResult*  CS_TxUserCertifiedSkillUpdateReq (const ::pptUser& requestUserID, const ::csUserCertifiedSkillUpdateReqInParm& strUserCertifiedSkillUpdateReqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csUserCertifyCheckInqResult*  CS_TxUserCertifyCheckInq (const ::pptUser& requestUserID, const ::csUserCertifyCheckInqInParm& strUserCertifyCheckInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csUserCertifiedEqpTypeSkillInqResult*  CS_TxUserCertifiedEqpTypeSkillInq (const ::pptUser& requestUserID, const ::csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csFixtureTouchCountRptResult*  CS_TxFixtureTouchCountRpt (const ::pptUser& requestUserID, const ::csFixtureTouchCountRptInParm& strFixtureTouchCountRptInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csCarrierUsageTypeChangeReqResult*  CS_TxCarrierUsageTypeChangeReq (const ::pptUser& requestUserID, const ::csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptStartLotsReservationForInternalBufferReqResult*  CS_TxStartLotsReservationForInternalBufferReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean skipBatchSizeFlag, ::CORBA::Boolean skipWaferCountFlag, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csLotComplicatedHoldReqResult*  CS_TxLotComplicatedHoldReq (const ::pptUser& requestUserID, const ::csLotComplicatedHoldReqInParam& strLotComplicatedHoldReqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpMonitorInventoryListInqResult*  CS_TxEqpMonitorInventoryListInq (const ::pptUser& requestUserID, const ::csEqpMonitorInventoryListInqInParm& strEqpMonitorInventoryListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpMonitorInventoryUpdateReqResult*  CS_TxEqpMonitorInventoryUpdateReq (const ::pptUser& requestUserID, const ::csEqpMonitorInventoryUpdateReqInParm& strEqpMonitorInventoryUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csBWSWaferOutAndSTBReqResult*  CS_TxBWSWaferOutAndSTBReq (const ::pptUser& requestUserID, const ::csBWSWaferOutAndSTBReqInParm& strBWSWaferOutAndSTBReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpMonitorLotSTBReqResult*  CS_TxEqpMonitorLotSTBReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotSTBReqInParm& strEqpMonitorLotSTBReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpMonitorLotAllBranchReqResult*  CS_TxEqpMonitorLotAllBranchReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotAllBranchReqInParm& strEqpMonitorLotAllBranchReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpMonitorLotPrepareIDResetReqResult*  CS_TxEqpMonitorLotPrepareIDResetReq (const ::pptUser& requestUserID, const ::csEqpMonitorLotPrepareIDResetReqInParm& strEqpMonitorLotPrepareIDResetReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDowngradeItemListInqResult*  CS_TxDowngradeItemListInq (const ::pptUser& requestUserID, const ::csDowngradeItemListInqInParm& strDowngradeItemListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDowngradeItemUpdateReqResult*  CS_TxDowngradeItemUpdateReq (const ::pptUser& requestUserID, const ::csDowngradeItemUpdateReqInParm& strDowngradeItemUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDowngradeSettingListInqResult*  CS_TxDowngradeSettingListInq (const ::pptUser& requestUserID, const ::csDowngradeSettingListInqInParm& strDowngradeSettingListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDowngradeSettingUpdateReqResult*  CS_TxDowngradeSettingUpdateReq (const ::pptUser& requestUserID, const ::csDowngradeSettingUpdateReqInParm& strDowngradeSettingUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpMonitorListInqResult*  CS_TxEqpMonitorListInq (const ::pptUser& requestUserID, const ::pptEqpMonitorListInqInParm& strEqpMonitorListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptEqpMonitorUpdateReqResult*  CS_TxEqpMonitorUpdateReq (const ::pptUser& requestUserID, const ::csEqpMonitorUpdateReqInParm& strEqpMonitorUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpMonitorSourceCandidateInfoInqResult*  CS_TxEqpMonitorSourceCandidateInfoInq (const ::pptUser& requestUserID, const ::csEqpMonitorSourceCandidateInfoInqInParm& strEqpMonitorSourceCandidateInfoInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csBWSWaferListInqResult*  CS_TxBWSWaferListInq (const ::pptUser& requestUserID, const ::csBWSWaferListInqInParm& strBWSWaferListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csNPWProductChangeReqResult*  CS_TxNPWProductChangeReq (const ::pptUser& requestUserID, const ::csNPWProductChangeReqInParm& strNPWProductChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csBWSConfigInfoInqResult*  CS_TxBWSConfigInfoInq (const ::pptUser& requestUserID, const ::csBWSConfigInfoInqInParm& strBWSConfigInfoInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csBWSConfigChangeReqResult*  CS_TxBWSConfigChangeReq (const ::pptUser& requestUserID, const ::csBWSConfigChangeReqInParm& strBWSConfigChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csBWSInventoryReqResult*  CS_TxBWSInventoryReq (const ::pptUser& requestUserID, const ::csBWSInventoryReqInParm& strBWSInventoryReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDurableDeliveryReqResult*  CS_TxDurableDeliveryReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDurableOpeCompForInternalBufferReqResult*  CS_TxDurableOpeCompForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOpeCompForInternalBufferReqInParam& strDurableOpeCompForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDurableOperationStartCancelForInternalBufferReqResult*  CS_TxDurableOperationStartCancelForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOperationStartCancelForInternalBufferReqInParam& strDurableOperationStartCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDurableOperationStartForInternalBufferReqResult*  CS_TxDurableOperationStartForInternalBufferReq (const ::pptUser& requestUserID, const ::csDurableOperationStartForInternalBufferReqInParam& strDurableOperationStartForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDurablesInfoForOpeStartForInternalBufferInqResult*  CS_TxDurablesInfoForOpeStartForInternalBufferInq (const ::pptUser& requestUserID, const ::csDurablesInfoForOpeStartForInternalBufferInqInParam& strDurablesInfoForOpeStartForInternalBufferInqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csDurablesInfoForStartReservationForInternalBufferInqResult*  CS_TxDurablesInfoForStartReservationForInternalBufferInq (const ::pptUser& requestUserID, const ::csDurablesInfoForStartReservationForInternalBufferInqInParam& strDurablesInfoForStartReservationForInternalBufferInqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csStartDurablesReservationCancelForInternalBufferReqResult*  CS_TxStartDurablesReservationCancelForInternalBufferReq (const ::pptUser& requestUserID, const ::csStartDurablesReservationCancelForInternalBufferReqInParam& strStartDurablesReservationCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csStartDurablesReservationForInternalBufferReqResult*  CS_TxStartDurablesReservationForInternalBufferReq (const ::pptUser& requestUserID, const ::csStartDurablesReservationForInternalBufferReqInParam& strStartDurablesReservationForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

}; /* end of ::CS_PPTServiceManager_ORBProxy*/
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
class  CS_PPTServiceManagerProxyFactory : virtual public ::PPTServiceManagerProxyFactory {

public:
   CS_PPTServiceManagerProxyFactory (::CORBA::Boolean is_default = 0);

   virtual ::CORBA::Object_ptr create_proxy (const char* classname);
   virtual ::CORBA::Object_ptr asObject(void *obj);
}; // CS_PPTServiceManagerProxyFactory


class  CS_PPTServiceManager_Dispatcher : virtual public ::PPTServiceManager_Dispatcher {

  public:

   CS_PPTServiceManager_Dispatcher (::CORBA::Object_ptr target);

   CS_PPTServiceManager_Dispatcher (); 

   virtual ::CORBA::Boolean dispatch (::CORBA::Request &request);
#ifdef _MSC_VER
   ::CORBA::Boolean __CS_PPTServiceManager__dispatch(::CORBA::Request &_req);
#endif // _MSC_VER
}; // CS_PPTServiceManager_Dispatcher
#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
class  CS_PPTServiceManagerBOAImpl : virtual public 

   CS_PPTServiceManager
, virtual public ::CORBA::Object_ORBProxy { 
   public:
     CS_PPTServiceManagerBOAImpl() ;

     virtual ~CS_PPTServiceManagerBOAImpl();
     CS_PPTServiceManagerBOAImpl &operator= (const CS_PPTServiceManagerBOAImpl &s);
     CS_PPTServiceManagerBOAImpl (const CS_PPTServiceManagerBOAImpl &s);
};  // CS_PPTServiceManagerBOAImpl

    extern  ::CORBA::TypeCode_ptr _tc_CS_PPTServiceManager;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_pptsm_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_pptsm_ANYOPERATOR__
#undef __NOTUSE_cs_pptsm_ANYOPERATOR__
#endif //__USE_cs_pptsm_ANYOPERATOR__
#ifndef __NOTUSE_cs_pptsm_ANYOPERATOR__
#define _DCL_ANYOPS_CS_PPTServiceManager
#endif //__NOTUSE_cs_pptsm_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_CS_PPTServiceManager
#ifndef __NOTUSE_ANYOPERATOR_INTERFACE__
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_PPTServiceManager_ptr _data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_PPTServiceManager_ptr *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_PPTServiceManager_ptr& _data);
#endif
#endif //__NOTUSE_ANYOPERATOR_INTERFACE__
#endif // _DCL_ANYOPS_CS_PPTServiceManager

#endif /* _cs_pptsm_hh_included */

#endif /* _cs_pptsm_server_defined */
