// @(#) 1.3 superpos/src/csppt/source/posppt/svcmgr/cs_pptmacros.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:02:49 [ 6/9/03 14:02:50 ] 
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// File : CS PPT Service Manager
// Description : Definition of Macros for Customized Tx
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date        Defect#  Person         Comments
// ---------- -------- -------------- ----------------------------------------------------
// 2003/03/06 D5000014 C.Tsuchiya     Initial Release
// 
//
// Innotron Modification history :
// Date       Defect#           Person           Comments
// ---------- -----------       --------------   -------------------------------------------
// 2017/09/01 INN-R170003       Vera Chen        Add SI_PPT_USERDATA_SET_STRING,
//                                                    SI_PPT_USERDATA_SET_INTEGER,
//                                                    SI_PPT_SET_USERDATA_DEL
// 2017/09/04 INN-R170003       JJ.Zhang         Add SI_PPT_USERDATA_GET_INTEGER
//                                                SI_PPT_USERDATA_GET_STRING
//                                                SI_PPT_USERDATA_GET_REAL
//                                                SI_PPT_USERDATA_SET_REAL
//                                                SI_PPT_USERDATA_GET_STRINGSEQ
//                                                CS_SET_MSG_RC
//                                                CS_PPT_SET_MSG_RC_KEY1
//                                                CS_PPT_SET_MSG_RC_KEY2
//                                                CS_PPT_SET_MSG_RC_KEY3
//                                                CS_PPT_SET_MSG_RC_KEY4
// 
// 2017/10/23 INN-R170003-01    Vera Chen       add SP_SET_REASONTEXT_DEFMSG( Struct_out.strResult.reasonText, rcid ) ;
// Following Macros are defined in this file.
//

#ifndef CS_PPTMacros_hpp
#define CS_PPTMacros_hpp

#include "pptmacros.hpp"
#include "cs_pptmsg.hpp"

// Marco :SI_PPT_USERDATA_SET_STRING
//
// Description:
//      ObjRef : Object reference
//      Name : user data name
//      Value : char *
//      This marco must be used as usual method call of FW.
//      that means this marco must used in try block and catch must be done.
//
#define SI_PPT_USERDATA_SET_STRING( ObjRef , Name , Value ) \
{ \
    userDataSet* aTempUserData = new userDataSet;\
    userDataSet_var aTempUserDataVar;\
    aTempUserDataVar = aTempUserData;\
    aTempUserData->name = CIMFWStrDup(Name);\
    aTempUserData->type = CIMFWStrDup("String");\
    aTempUserData->value = CIMFWStrDup(Value);\
    aTempUserData->originator = CIMFWStrDup("MM");\
    ObjRef->setUserDataSetNamed(*aTempUserData);\
}
// Marco :SI_PPT_USERDATA_SET_INTEGER
//
// Description:
//      ObjRef : Object reference
//      Name : user data name
//      Value : long
//      This marco must be used as usual method call of FW.
//      that means this marco must used in try block and catch must be done.
//
#define SI_PPT_USERDATA_SET_INTEGER(ObjRef,Name,Value) \
{ \
    userDataSet* aTempUserData = new userDataSet;\
    userDataSet_var aTempUserDataVar;\
    aTempUserDataVar = aTempUserData;\
    aTempUserData->name = CIMFWStrDup(Name);\
    aTempUserData->type = CIMFWStrDup("Integer");\
    char aTempCharArray[20];\
    sprintf(aTempCharArray,"%ld",Value);\
    aTempUserData->value = CIMFWStrDup(aTempCharArray);\
    aTempUserData->originator = CIMFWStrDup("MM");\
    ObjRef->setUserDataSetNamed(*aTempUserData);\
}
// Marco :SI_PPT_USERDATA_DEL(ObjRef,Name)
//
// Description:
//      ObjRef : Object reference
//      Name : user data name
//      This marco must be used as usual method call of FW.
//      that means this marco must used in try block and catch must be done.
//
#define SI_PPT_USERDATA_DEL(ObjRef,Name) \
{ \
   ObjRef->removeUserDatasetNamed(Name);\
}

// Macro : SI_PPT_USERDATA_GET_INTEGER
//
// Description:
//     This macro will get user data named as the passed name of the passed object.
//     Then return value as long.
//           ObjRef : Object reference
//           Name   : user data name
//           Value  : long
//     This Macro must be used as usual method call of FW.
//     That means this macro must be used in try block and catch must be done.
//
#define SI_PPT_USERDATA_GET_INTEGER( ObjRef, Name, Value )\
{\
    CORBA::String_var aTempValue;\
    aTempValue = ObjRef->getUserDataNamed(Name);\
    Value = atol(aTempValue);\
}

// Macro : SI_PPT_USERDATA_GET_STRING
//
// Description:
//     This macro will get user data named as the passed name of the passed object.
//     Then return value as string.
//           ObjRef : Object reference
//           Name   : user data name
//           Value  : char*
//     This Macro must be used as usual method call of FW.
//     That means this macro must be used in try block and catch must be done.
//
#define SI_PPT_USERDATA_GET_STRING( ObjRef, Name, Value )\
{\
    Value = ObjRef->getUserDataNamed(Name);\
}

// Macro : SI_PPT_USERDATA_GET_REAL
//
// Description:
//     This macro will get user data named as the passed name of the passed object.
//     Then return value as double.
//           ObjRef : Object reference
//           Name   : user data name
//           Value  : double
//     This Macro must be used as usual method call of FW.
//     That means this macro must be used in try block and catch must be done.
//
#define SI_PPT_USERDATA_GET_REAL( ObjRef, Name, Value )\
{\
    CORBA::String_var aTempValue;\
    aTempValue = ObjRef->getUserDataNamed(Name);\
    Value = atof(aTempValue);\
}

// Macro : SI_PPT_USERDATA_SET_REAL
//
// Description:
//     This macro will set user data named as the passed name of the passed object.
//           ObjRef : Object reference
//           Name   : user data name
//           Value  : double
//     This Macro must be used as usual method call of FW.
//     That means this macro must be used in try block and catch must be done.
//
#define SI_PPT_USERDATA_SET_REAL( ObjRef, Name, Value )\
{\
    userDataSet* aTempUserData = new userDataSet;\
    userDataSet_var aTempUserDataVar;\
    aTempUserDataVar = aTempUserData;\
    aTempUserData->name = CIMFWStrDup(Name);\
    aTempUserData->type = CIMFWStrDup("Double");\
    char aTempCharArray[50];\
    sprintf(aTempCharArray, "%e", Value);\
    aTempUserData->value = CIMFWStrDup(aTempCharArray);\
    aTempUserData->originator = CIMFWStrDup("MM");\
    ObjRef->setUserDataSetNamed(*aTempUserData);\
}

// Macro : SI_PPT_USERDATA_GET_STRINGSEQ
//
// Description:
//     This macro will get the sequence of user data named as the passed name of the passed object.
//     Then return value as stringSequence.
//           ObjRef : Object reference
//           Name   : user data name
//           Value  : stringSequence*
//     This Macro must be used as usual method call of FW.
//     That means this macro must be used in try block and catch must be done.
//
#define SI_PPT_USERDATA_GET_STRINGSEQ( ObjRef, Name, Value )\
{\
    Value = ObjRef->getUserDataSequenceNamed(Name);\
}

//-----------------------------------------
// local macros for setting messages
//-----------------------------------------
#define CS_SET_MSG_RC(Struct_out,msgid,rcid)\
{/*INN-R170003-01*/\
   cs_set_message_and_returncode(&(Struct_out.strResult),msgid,rcid); \
   SP_SET_REASONTEXT_DEFMSG( Struct_out.strResult.reasonText, rcid ); /*INN-R170003-01*/ \
}/*INN-R170003-01*/

#define CS_PPT_SET_MSG_RC_KEY1(Struct_out,msgid,rcid,key1)\
{/*INN-R170003-01*/\
   cs_set_message_and_returncode(&(Struct_out.strResult),msgid,rcid,key1); \
   SP_SET_REASONTEXT_DEFMSG( Struct_out.strResult.reasonText, rcid ); /*INN-R170003-01*/ \
}/*INN-R170003-01*/

#define CS_PPT_SET_MSG_RC_KEY2(Struct_out,msgid,rcid,key1,key2)\
{/*INN-R170003-01*/\
   cs_set_message_and_returncode(&(Struct_out.strResult),msgid,rcid,key1,key2); \
   SP_SET_REASONTEXT_DEFMSG( Struct_out.strResult.reasonText, rcid ); /*INN-R170003-01*/ \
}/*INN-R170003-01*/

#define CS_PPT_SET_MSG_RC_KEY3(Struct_out,msgid,rcid,key1,key2,key3)\
{/*INN-R170003-01*/\
   cs_set_message_and_returncode(&(Struct_out.strResult),msgid,rcid,key1,key2,key3); \
   SP_SET_REASONTEXT_DEFMSG( Struct_out.strResult.reasonText, rcid ); /*INN-R170003-01*/ \
}/*INN-R170003-01*/

#define CS_PPT_SET_MSG_RC_KEY4(Struct_out,msgid,rcid,key1,key2,key3,key4)\
{/*INN-R170003-01*/ \
   cs_set_message_and_returncode(&(Struct_out.strResult),msgid,rcid,key1,key2,key3,key4); \
   SP_SET_REASONTEXT_DEFMSG( Struct_out.strResult.reasonText, rcid ); /*INN-R170003-01*/\
}/*INN-R170003-01*/

#endif

