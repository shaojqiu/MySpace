#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/svcmgr/txmethods/TxTestFunction.cpp, mm_srv_90e_cspp, mm_srv_90e_cspp 7/13/07 19:59:00 [ 7/13/07 19:59:01 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: TxTestFunction.cpp
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//


#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"

// Class: CS_PPTSvcMgr
//
// Service: TxTestFunction
// Transaction Id : TXTST001
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami      eBrokerMigration.
//
// INNOTRON Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/27 INN-R170009  Gary Ke         170009: APC Condition check 
// Description:
//
// Return: csTestFunctionResult
//
// Parameter:
//         in  pptUser       requestUserID;
//         in  string        functionID;
//         in  objectIdentifier lotID;
//         in  objectIdentifier equipmentID;
//         in  string        claimMemo;
//
// Require:
//      none (Condition)
// Ensure:
//      none (after)
// Exception:
//      none
// Pseudo code:
//
csTestFunctionResult* CS_PPTServiceManager_i::TxTestFunction(
                                      const pptUser& requestUserID,
                                      const char *FunctionID,
                                      const objectIdentifier& lotID,
                                      const objectIdentifier& equipmentID,
                                      //INN-R170009 add start
                                      const objectIdentifier& routeID,
                                      const char *operationNumber,
                                      //INN-R170009 add end
                                      const char *claimMemo   //D6000025
                                      CORBAENV_LAST_CPP)      //D6000025
                                  //D6000025    const char *claimMemo,
                                  //D6000025    CORBA::Environment &IT_env)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);

    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: TxTestFunction")
    CS_PPT_PARMTRACE_VERBOSE7(requestUserID,FunctionID,lotID,equipmentID,routeID,operationNumber,claimMemo);

    /*------------------------------------------------------------------------*/
    /*   Pre Process                                                          */
    /*------------------------------------------------------------------------*/
    csTestFunctionResult*               retVal = new csTestFunctionResult;
    pptEventParameterSequence           strEventParameter;
    objCalendar_GetCurrentTimeDR_out    strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn                      strObjCommonIn ;
    CORBA::Long                         rc = 0 ;

    // Initialising strObjCommonIn's first two parameters

    strObjCommonIn.transactionID = CIMFWStrDup("TXTST001") ;
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup("TXTST001") ;

    // Incoming Log Put

    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
	
    if(PPTEnv::logIncoming)
    {
        retVal->strResult.transactionID = CIMFWStrDup("TXTST001") ;
        retVal->strResult.returnCode = CIMFWStrDup("Incoming") ;

        CORBA::Long     nLen = strEventParameter.length() ;
        //INN-R170009 strEventParameter.length( nLen + 3 ) ;
        strEventParameter.length( nLen + 5 ) ; //INN-R170009
        strEventParameter[nLen].parameterName = CIMFWStrDup("FUNCTION_ID") ;
        strEventParameter[nLen].parameterValue =  CIMFWStrDup( FunctionID ) ;
        strEventParameter[nLen+1].parameterName = CIMFWStrDup("LOT_ID") ;
        strEventParameter[nLen+1].parameterValue =  CIMFWStrDup( lotID.identifier ) ;
        strEventParameter[nLen+2].parameterName = CIMFWStrDup("EQP_ID") ;
        strEventParameter[nLen+2].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
        //INN-R170009 add start
        strEventParameter[nLen+3].parameterName = CIMFWStrDup("ROUTE_ID") ;
        strEventParameter[nLen+3].parameterValue =  CIMFWStrDup( routeID.identifier ) ;
        strEventParameter[nLen+4].parameterName = CIMFWStrDup("OPE_NO") ;
        strEventParameter[nLen+4].parameterValue =  CIMFWStrDup( operationNumber ) ;
        //INN-R170009 add end
        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        strEventParameter.length( 0 ) ;
        nLen = 0 ;
    }

    CREATE_TX_OBJ

    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        strObjCommonIn.strUser.functionID = CIMFWStrDup( "TXTST001" ) ;
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: TxTestFunction ", "rc != RC_OK")
        TX_ROLLBACK(calendar_GetCurrentTimeDR)
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup("TXTST001") ;

        CORBA::Long     nLen = strEventParameter.length() ;
        //INN-R170009 strEventParameter.length( nLen + 3 ) ;
        strEventParameter.length( nLen + 5 ) ; //INN-R170009
        strEventParameter[nLen].parameterName = CIMFWStrDup("FUNCTION_ID") ;
        strEventParameter[nLen].parameterValue =  CIMFWStrDup( FunctionID ) ;
        strEventParameter[nLen+1].parameterName = CIMFWStrDup("LOT_ID") ;
        strEventParameter[nLen+1].parameterValue =  CIMFWStrDup( lotID.identifier ) ;
        strEventParameter[nLen+2].parameterName = CIMFWStrDup("EQP_ID") ;
        strEventParameter[nLen+2].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
        //INN-R170009 add start
        strEventParameter[nLen+3].parameterName = CIMFWStrDup("ROUTE_ID") ;
        strEventParameter[nLen+3].parameterValue =  CIMFWStrDup( routeID.identifier ) ;
        strEventParameter[nLen+4].parameterName = CIMFWStrDup("OPE_NO") ;
        strEventParameter[nLen+4].parameterValue =  CIMFWStrDup( operationNumber ) ;
        //INN-R170009 add end
        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR)
/*
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);
    objectIdentifierSequence lotIDs;
    lotIDs.length(1);
    lotIDs[0] = lotID;

    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,dummy,dummy,dummyIDs,dummyIDs,lotIDs,dummyIDs);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: TxTestFunction ", "rc != RC_OK")
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("TXTST001") ;

        CORBA::Long     nLen = strEventParameter.length() ;
        strEventParameter.length( nLen + 3 ) ;
        strEventParameter[nLen].parameterName = CIMFWStrDup("FUNCTION_ID") ;
        strEventParameter[nLen].parameterValue =  CIMFWStrDup( FunctionID ) ;
        strEventParameter[nLen+1].parameterName = CIMFWStrDup("LOT_ID") ;
        strEventParameter[nLen+1].parameterValue =  CIMFWStrDup( lotID.identifier ) ;
        strEventParameter[nLen+2].parameterName = CIMFWStrDup("EQP_ID") ;
        strEventParameter[nLen+2].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)
*/
    /*------------------------------------------------------------------------*/
    /*   Main Process                                                         */
    /*------------------------------------------------------------------------*/
    TX_BEGIN(cs_txTestFunction)

    try
    {
          
        // Test  by Qufd 
        objectIdentifier controlJobID;
        char *eventID;
         
        rc = theCS_PPTManager->cs_txTestFunction(*retVal, strObjCommonIn, FunctionID, lotID, equipmentID, routeID, operationNumber, controlJobID,eventID,claimMemo);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txTestFunction)
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: TxTestFunction ", "rc == RC_OK")
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txTestFunction)
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: TxTestFunction ", "rc != RC_OK")
        TX_ROLLBACK(cs_txTestFunction)
        retVal->strResult.transactionID = CIMFWStrDup("TXTST001") ;

        CORBA::Long     nLen = strEventParameter.length() ;
        //INN-R170009 strEventParameter.length( nLen + 3 ) ;
        strEventParameter.length( nLen + 5 ) ; //INN-R170009
        strEventParameter[nLen].parameterName = CIMFWStrDup("FUNCTION_ID") ;
        strEventParameter[nLen].parameterValue =  CIMFWStrDup( FunctionID ) ;
        strEventParameter[nLen+1].parameterName = CIMFWStrDup("LOT_ID") ;
        strEventParameter[nLen+1].parameterValue =  CIMFWStrDup( lotID.identifier ) ;
        strEventParameter[nLen+2].parameterName = CIMFWStrDup("EQP_ID") ;
        strEventParameter[nLen+2].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
        //INN-R170009 add start
        strEventParameter[nLen+3].parameterName = CIMFWStrDup("ROUTE_ID") ;
        strEventParameter[nLen+3].parameterValue =  CIMFWStrDup( routeID.identifier ) ;
        strEventParameter[nLen+4].parameterName = CIMFWStrDup("OPE_NO") ;
        strEventParameter[nLen+4].parameterValue =  CIMFWStrDup( operationNumber ) ;
        //INN-R170009 add end
        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal ;
    }

    /*------------------------------------------------------------------------*/
    /*   Post Process                                                         */
    /*------------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup("TXTST001") ;

    CORBA::Long     nLen = strEventParameter.length() ;
    //INN-R170009 strEventParameter.length( nLen + 3 ) ;
    strEventParameter.length( nLen + 5 ) ; //INN-R170009
    strEventParameter[nLen].parameterName = CIMFWStrDup("FUNCTION_ID") ;
    strEventParameter[nLen].parameterValue =  CIMFWStrDup( FunctionID ) ;
    strEventParameter[nLen+1].parameterName = CIMFWStrDup("LOT_ID") ;
    strEventParameter[nLen+1].parameterValue =  CIMFWStrDup( lotID.identifier ) ;
    strEventParameter[nLen+2].parameterName = CIMFWStrDup("EQP_ID") ;
    strEventParameter[nLen+2].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
    //INN-R170009 add start
    strEventParameter[nLen+3].parameterName = CIMFWStrDup("ROUTE_ID") ;
    strEventParameter[nLen+3].parameterValue =  CIMFWStrDup( routeID.identifier ) ;
    strEventParameter[nLen+4].parameterName = CIMFWStrDup("OPE_NO") ;
    strEventParameter[nLen+4].parameterValue =  CIMFWStrDup( operationNumber ) ;
    //INN-R170009 add end
    eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: TxTestFunction")
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal ;

}
