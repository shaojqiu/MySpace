#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/svcmgr/txmethods/TxCassetteDeliveryForInternalBufferReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:52:49 [ 7/13/07 21:52:50 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: TxCassetteDeliveryForInternalBufferReq.cpp
//

#include "cs_pptsm.hpp"

#include "pptdefs.h"
//D4000012  #include "pptenv.hpp"
#include "pptenv.hpp"          //D4100134 restore
#include "spfunc.hpp"
#include "ppteventlog.hpp"     //D4200212

//=============================================================================
// For TXDSC012 : TxCassetteDeliveryForInternalBufferReq
//=============================================================================
// Class: CS_PPTServiceManager
//
// Service: TxCassetteDeliveryForInternalBufferReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/06/26 D4000015 K.Matsuei      Internal Buffuer Contorl.
// 2001/06/27 D4000012 H.Mutoh        add environment variable control(PPTEnv::logIncoming change)
// 2001/09/14 0.03     K.Matsuei      Change Logic of Sned SystemMessage.  (D4000015)
// 2002-02-14 D4100014 H.Adachi       Add Parameter Log and Trace Log Filter
// 2002-02-25 D4100134 C.Tsuchiya     Delete thePPT_TRACE_INCOMING
// 2002/03/05 P4100197 K.Matsuei      SystemMsgRpt of CassetteDelivery isn't sent.
// 2002/12/12 D4200212 C.Tsuchiya     EventLog enhancement
// 2004/08/11 D51M0000 K.Tachibana    APC I/F Enhance for Interface Spec-B
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/04/11 D6000215 K.Kido         Delete timeStamp_DoCalculation. (Migrated into txEntityInhibitReq)
// 2005-08-09 D6000220 A.Tomari       Add the following document infomation
//                                    -<Method Summary>
//                                    -<MRM>
//                                    -<Sample Code>
//                                    -<IN-parm's description>
// 2006/07/19 D7000294    M.Murata       Add the logic to inhibit when APC I/F occurs.
// 2006/12/06 D8000112    K.Matsuei   CassetteDeliveryForIB always performs SystemMsgRpt.
// 2007/04/20 D9000001 K.Kido         64bit support.
// 2007/06/25 D9000003 M.Nakano       Add logic to commit txLotHoldReq() when wafer sampling error occurs.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/02 DSIV00001365 R.Okano        Entity Inhibit Improvement. (R101)
//
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/08 INN-R170002  JJ.Zhang       Contamination Control
//
// Description:
//<Method Summary>
//This function selects the best Lot and sends requests for Carrier transfer to Internal Buffer Equipment or Stocker.
//
//This function has the following purposes.
//-Select the best Lot from WIPLots and send a request to transfer the Carrier to Equipment.
//-Send a request to transfer the Carrier, which has been finished processing on Equipment, to Stocker.
//-Send a request to transfer the Carrier, which has been finished processing on Equipment, to Equipment for the next operation.
//
//When RTD (Real Time Dispatcher) is Available, the priority is given to WIPLot information or Stocker information that are returned from RTD.
//If Equipment needs Empty Carrier, the best EmptyCarrier will also be selected.
//</Method Summary>
//
//<MRM>
//DIS4-2. : Carrier Delivery Request for Auto Dispatch Mode
//</MRM>
//
// Return:
//     pptCassetteDeliveryForInternalBufferReqResult
//
// Parameter:
//
//    const pptUser&           requestUserID,
//    const objectIdentifier&  equipmentID,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>
//    //m_pSvcMgr is PPTServiceManager class
//    //m_User is pptUser struct
//
//objectIdentifier eqpID;
//eqpID.identifier = CORBA::string_dup("CL001");
//
//pptCassetteDeliveryForInternalBufferReqResult* pRet = NULL;
//m_pSvcMgr->TxCassetteDeliveryForInternalBufferReq(
//    m_User,
//    eqpID
//    );
//</Sample Code>
//
//<Method Start>
//INN-R170002 pptCassetteDeliveryForInternalBufferReqResult* PPTServiceManager_i:: TxCassetteDeliveryForInternalBufferReq (
pptCassetteDeliveryForInternalBufferReqResult* CS_PPTServiceManager_i::TxCassetteDeliveryForInternalBufferReq (    //INN-R170002 
            const pptUser&           requestUserID,  //<i>R/Request User ID
//D6000025             const objectIdentifier&  equipmentID,
//D6000025             CORBA::Environment&      IT_env )
            const objectIdentifier&  equipmentID     //<i>R/Equipment ID     //D6000025
            CORBAENV_LAST_CPP )                      //<i>O/IT Environment   //D6000025
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);    //D4100014
    //INN-R170002 PPT_METHODTRACE_ENTRY("PPTServiceManager_i:: TxCassetteDeliveryForInternalBufferReq")
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::TxCassetteDeliveryForInternalBufferReq")    //INN-R170002 
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID,equipmentID );    //D4100014
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/

    pptCassetteDeliveryForInternalBufferReqResult*  retVal = new pptCassetteDeliveryForInternalBufferReqResult;
    pptEventParameterSequence                       strEventParameter;
    objCalendar_GetCurrentTimeDR_out                strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn                                  strObjCommonIn ;
    CORBA::Long                                     rc = 0 ;

    // Initialising strObjCommonIn's first two parameters

    strObjCommonIn.transactionID = CIMFWStrDup("TXDSC012") ;
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                                           strObjCommonIn.strTimeStamp.reportTimeStamp;
//D4000012  if (PPTEnv::logIncoming)
//D4100134    if (thePPT_TRACE_INCOMING)    //D4000012
//D4200212    if(PPTEnv::logIncoming)    //D4100134
//D4200212    {
//D4200212        retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;
//D4200212        retVal->strResult.returnCode = CIMFWStrDup("Incoming") ;
//D4200212
//D4200212        CORBA::Long     nLen = strEventParameter.length() ;
//D4200212        strEventParameter.length( nLen + 1 ) ;
//D4200212        strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
//D4200212        strEventParameter[nLen].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
//D4200212
//D4200212        eventLog_Put(strEventParameter, strObjCommonIn, retVal->strResult);
//D4200212        strEventParameter.length( 0 ) ;
//D4200212        nLen = 0 ;
//D4200212    }

//D4200212 add start
    CORBA::Long     nLen = strEventParameter.length() ;
    strEventParameter.length( nLen + 1 ) ;
    strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
    strEventParameter[nLen].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );
//D4200212 add end

    CREATE_TX_OBJ;

    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        strObjCommonIn.strUser.functionID = CIMFWStrDup( "TXDSC012" ) ;
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK");
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;

//D4200212        CORBA::Long     nLen = strEventParameter.length() ;
//D4200212        strEventParameter.length( nLen + 1 ) ;
//D4200212        strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
//D4200212        strEventParameter[nLen].parameterValue = CIMFWStrDup( equipmentID.identifier ) ;

//D4200212        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,equipmentID,dummy, dummyIDs,dummyIDs,dummyIDs,dummyIDs);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK");
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;

//D4200212        CORBA::Long     nLen = strEventParameter.length() ;
//D4200212        strEventParameter.length( nLen + 1 ) ;
//D4200212        strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
//D4200212        strEventParameter[nLen].parameterValue = CIMFWStrDup( equipmentID.identifier ) ;

//D4200212        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(txCassetteDeliveryForInternalBufferReq);
    try
    {
        rc = theCS_PPTManager->txCassetteDeliveryForInternalBufferReq(*retVal, strObjCommonIn, equipmentID);
        PPT_METHODTRACE_V2("","txCassetteDeliveryForInternalBufferReq() rc", rc);  //D9000003
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txCassetteDeliveryForInternalBufferReq);
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(txCassetteDeliveryForInternalBufferReq);
    }
//D9000003 add start
    else if(rc == RC_NO_PROCESSJOBEXECFLAG || rc == RC_INVALID_SMPL_SETTING)
    {
        PPT_METHODTRACE_V1("", "rc == RC_NO_PROCESSJOBEXECFLAG || rc == RC_INVALID_SMPL_SETTING");
        TX_COMMIT(txCassetteDeliveryForInternalBufferReq);
    }
//D9000003 add end
//INN-R170002 add start
    else if(rc == CS_RC_CARRIER_CONTAMINATION_MISMATCH)
    {
        PPT_METHODTRACE_V1("", "rc == CS_RC_CARRIER_CONTAMINATION_MISMATCH");
        TX_ROLLBACK(txCassetteDeliveryForInternalBufferReq)
        retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;

        csCassetteDeliveryForInternalBufferReqResult_siInfo* strCassetteDeliveryForInternalBufferReqResult_siInfo;
        if( retVal->siInfo >>= strCassetteDeliveryForInternalBufferReqResult_siInfo)
        {
            CORBA::Long holdLotLen = strCassetteDeliveryForInternalBufferReqResult_siInfo->holdLotIDs.length() ;
            PPT_METHODTRACE_V2( "", "strCassetteDeliveryForInternalBufferReqResult_siInfo->holdLotIDs.length", holdLotLen);

            pptHoldLotReqResult strHoldLotReqResult ;
            pptHoldListSequence strLotHoldReqList ;
            strLotHoldReqList.length(1) ;

            strLotHoldReqList[0].holdType                 = CIMFWStrDup(SP_HoldType_LotHold) ;
            strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
            strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
            strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup(SP_ResponsibleOperation_Current) ;
            strLotHoldReqList[0].claimMemo                = CIMFWStrDup("") ;

            for( CORBA::Long i=0 ; i<holdLotLen ;i++)
            {
                PPT_METHODTRACE_V2("","holdLotID...",strCassetteDeliveryForInternalBufferReqResult_siInfo->holdLotIDs[i].identifier) ;

                TX_BEGIN(txHoldLotReq)
                try
                {
                    rc = theCS_PPTManager->txHoldLotReq ( strHoldLotReqResult,
                                                       strObjCommonIn,
                                                       strCassetteDeliveryForInternalBufferReqResult_siInfo->holdLotIDs[i],
                                                       strLotHoldReqList ) ;
                }
                CATCH_TX_TIMEOUT_EXCEPTIONS(txHoldLotReq)

                if (rc == RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq :rc == RC_OK");
                    TX_COMMIT(txHoldLotReq);
                }
                else
                {
                    PPT_METHODTRACE_V2("", "txHoldLotReq :rc 1= RC_OK", rc);
                    TX_ROLLBACK(txHoldLotReq) ;
                }
            }
        }
    }
//INN-R170002 add end
//0.03 start
    else
    {
        TX_ROLLBACK(txCassetteDeliveryForInternalBufferReq)
        retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;
//D4200212        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
    } //D8000112

        // Call System Message
        CORBA::Long lenSysMsg = retVal->strSysMstStockInfoSequence.length();
        PPT_METHODTRACE_V2("", "retVal->strSysMstStockInfoSequence.length", lenSysMsg);
        if (0 < lenSysMsg)
        {
            TX_BEGIN(txSystemMsgRpt)
            CORBA::Long saveRc = rc;            //D51M0000

            pptSystemMsgRptResult strSystemMsgRptResult;
            for (CORBA::Long i=0; i < lenSysMsg; i++ )
            {
                PPT_METHODTRACE_V2("", "---------------------------------------SendMsg[i]", i);
                PPT_METHODTRACE_V2("", "subSystemID.........", retVal->strSysMstStockInfoSequence[i].subSystemID);
                PPT_METHODTRACE_V2("", "systemMessageCode...", retVal->strSysMstStockInfoSequence[i].systemMessageCode);
                PPT_METHODTRACE_V2("", "systemMessageText...", retVal->strSysMstStockInfoSequence[i].systemMessageText);

//P4100197 start
                char sysMsg[1024];
                memset(sysMsg, '\0', sizeof(sysMsg));
                if ( 1020 < CIMFWStrLen(retVal->strSysMstStockInfoSequence[i].systemMessageText) )
                {
                    PPT_METHODTRACE_V1("", "Cut SystemMessageText");
                    strncpy( sysMsg, retVal->strSysMstStockInfoSequence[i].systemMessageText, 1020 );
                    strcat(sysMsg, "...");
                    retVal->strSysMstStockInfoSequence[i].systemMessageText = CIMFWStrDup(sysMsg);
                }
//P4100197 end

                try
                {
                    rc = theCS_PPTManager->txSystemMsgRpt( strSystemMsgRptResult,
                                                        strObjCommonIn,
                                                        retVal->strSysMstStockInfoSequence[i].subSystemID,
                                                        retVal->strSysMstStockInfoSequence[i].systemMessageCode,
                                                        retVal->strSysMstStockInfoSequence[i].systemMessageText,
                                                        retVal->strSysMstStockInfoSequence[i].notifyFlag,
                                                        retVal->strSysMstStockInfoSequence[i].equipmentID,
                                                        retVal->strSysMstStockInfoSequence[i].equipmentStatus,
                                                        retVal->strSysMstStockInfoSequence[i].stockerID,
                                                        retVal->strSysMstStockInfoSequence[i].stockerStatus,
                                                        retVal->strSysMstStockInfoSequence[i].AGVID,
                                                        retVal->strSysMstStockInfoSequence[i].AGVStatus,
                                                        retVal->strSysMstStockInfoSequence[i].lotID,
                                                        retVal->strSysMstStockInfoSequence[i].lotStatus,
                                                        retVal->strSysMstStockInfoSequence[i].routeID,
                                                        retVal->strSysMstStockInfoSequence[i].operationID,
                                                        retVal->strSysMstStockInfoSequence[i].operationNumber,
                                                        retVal->strSysMstStockInfoSequence[i].systemMessageTimeStamp,
                                                        "" );
                }
                CATCH_TX_TIMEOUT_EXCEPTIONS(txSystemMsgRpt)

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txSystemMsgRpt failed.")
                    TX_ROLLBACK(txSystemMsgRpt)
                    retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;
                    //D4200212 eventLog_Put(strEventParameter,strObjCommonIn,strSystemMsgRptResult.strResult);
                    return retVal;
                }
            }

            PPT_METHODTRACE_V1("", "txSystemMsgRpt succeed")
            PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
            TX_COMMIT(txSystemMsgRpt)

//D7000294 add start
            //------------------------------------------
            //  Entity Inhibit enable check.
            //  SP_INHIBIT_WHEN_APC_RPARMADJUST_NG
            //       0 --> Inhibit disable
            //       1 --> Inhibit enable
            //------------------------------------------
//D9000001            CORBA::Long envInhibitWhenAPC = atol(getenv(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG));
            CORBA::Long envInhibitWhenAPC = atoi(getenv(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG));       //D9000001
            if( envInhibitWhenAPC == 1 )
            {
//D7000294 add end & following Logic was nested
//D51M0000 add start
                PPT_METHODTRACE_V2("", "small Tx return error. saveRc:", saveRc);

                if( saveRc == RC_NO_RESPONSE_APC      ||
                    saveRc == RC_APC_SERVER_BIND_FAIL ||
                    saveRc == RC_APC_RUNTIMECAPABILITY_ERROR  ||
                    saveRc == RC_APC_RECIPEPARAMETERREQ_ERROR ||
                    saveRc == RC_APC_RETURN_DUPLICATE_PARAMETERNAME )
                {

                    CORBA::String_var strClaimMemo = CIMFWStrDup("APC IF Error.");

//D6000215      //--------------------------------
//D6000215      // Calculate EndTime for Inhibit
//D6000215      //--------------------------------
//D6000215      objTimeStamp_DoCalculation_out      strTimeStamp_DoCalculation_out;
//D6000215      CORBA::String_var targetTimeStamp;
//D6000215
//D6000215      TX_BEGIN(timeStamp_DoCalculation);
//D6000215      try
//D6000215      {
//D6000215          CORBA::Long inhibitDuration          = atol(getenv(SP_INHIBIT_DURATION));
//D6000215          CORBA::String_var tmpReportTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
//D6000215          rc = theCS_PPTManager->timeStamp_DoCalculation( strTimeStamp_DoCalculation_out,
//D6000215                                                       strObjCommonIn,
//D6000215                                                       tmpReportTimeStamp,
//D6000215                                                       inhibitDuration,
//D6000215                                                       0,0,0,0);
//D6000215      }
//D6000215      CATCH_TX_TIMEOUT_EXCEPTIONS(timeStamp_DoCalculation);
//D6000215
//D6000215      if ( rc == RC_OK )
//D6000215      {
//D6000215          PPT_METHODTRACE_V1("", "timeStamp_DoCalculation rc == RC_OK");
//D6000215          TX_COMMIT(timeStamp_DoCalculation);
//D6000215          targetTimeStamp = CIMFWStrDup(strTimeStamp_DoCalculation_out.targetTimeStamp);
//D6000215      }
//D6000215      else if ( rc != RC_OK )
//D6000215      {
//D6000215          PPT_METHODTRACE_V1("", "timeStamp_DoCalculation rc != RC_OK");
//D6000215          TX_ROLLBACK(timeStamp_DoCalculation);
//D6000215          targetTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
//D6000215      }

                    //-------------------------------------------
                    // Inhibit Equipment for APC I/F Errors
                    //-------------------------------------------
//DSIV00001365                    TX_BEGIN(txEntityInhibitReq);
                    TX_BEGIN(txEntityInhibitReq__101);    //DSIV00001365
                    try
                    {
//DSIV00001365                        pptEntityInhibitAttributes strEntityInhibitions;
                        pptEntityInhibitDetailAttributes strEntityInhibitions;    //DSIV00001365

                        PPT_METHODTRACE_V2("", "equipment ID to inhibit req", equipmentID.identifier);

                        strEntityInhibitions.entities.length(1);
                        strEntityInhibitions.entities[0].className           = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strEntityInhibitions.entities[0].objectID            = equipmentID;
                        strEntityInhibitions.entities[0].attrib              = CIMFWStrDup("");
                        strEntityInhibitions.subLotTypes.length(0);
                        strEntityInhibitions.startTimeStamp                  = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
//D6000215          strEntityInhibitions.endTimeStamp                    = CIMFWStrDup(targetTimeStamp);

                        if( saveRc == RC_NO_RESPONSE_APC ||
                            saveRc == RC_APC_SERVER_BIND_FAIL )
                        {
                            strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCNoResponse);
                        }
                        else if( saveRc == RC_APC_RUNTIMECAPABILITY_ERROR ||
                                 saveRc == RC_APC_RECIPEPARAMETERREQ_ERROR)
                        {
                            strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCReturnCodeNG);
                        }
                        else if( saveRc == RC_APC_RETURN_DUPLICATE_PARAMETERNAME )
                        {
                            strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCReturnValueError);
                        }

                        strEntityInhibitions.ownerID          = strObjCommonIn.strUser.userID;
                        strEntityInhibitions.claimedTimeStamp = CIMFWStrDup("");

//DSIV00001365                        pptEntityInhibitReqResult strEntityInhibitReqResult;
//DSIV00001365                        rc = theCS_PPTManager->txEntityInhibitReq(strEntityInhibitReqResult,
//DSIV00001365                                                               strObjCommonIn,
//DSIV00001365                                                               strEntityInhibitions,
//DSIV00001365                                                               strClaimMemo);
//DSIV00001365                    }
//DSIV00001365                    CATCH_TX_TIMEOUT_EXCEPTIONS(txEntityInhibitReq);
//DSIV00001365                    if (rc == RC_OK)
//DSIV00001365                    {
//DSIV00001365                        PPT_METHODTRACE_V1("", "txEntityInhibitReq returns RC_OK");
//DSIV00001365                        TX_COMMIT(txEntityInhibitReq);
//DSIV00001365                    }
//DSIV00001365                    else
//DSIV00001365                    {
//DSIV00001365                        PPT_METHODTRACE_V2("", "txEntityInhibitReq returns Error.", rc);
//DSIV00001365                        TX_ROLLBACK(txEntityInhibitReq);
//DSIV00001365                    }
//DSIV00001365 add start
                        pptEntityInhibitReqResult__101 strEntityInhibitReqResult;
                        rc = theCS_PPTManager->txEntityInhibitReq__101(strEntityInhibitReqResult,
                                                                    strObjCommonIn,
                                                                    strEntityInhibitions,
                                                                    strClaimMemo);
                    }
                    CATCH_TX_TIMEOUT_EXCEPTIONS(txEntityInhibitReq__101);    //DSIV00001365
                    if (rc == RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "txEntityInhibitReq__101 returns RC_OK");
                        TX_COMMIT(txEntityInhibitReq__101);
                    }
                    else
                    {
                        PPT_METHODTRACE_V2("", "txEntityInhibitReq__101 returns Error.", rc);
                        TX_ROLLBACK(txEntityInhibitReq__101);
                    }
//DSIV00001365 add end
                }
//D51M0000 add end
            }    //D7000294

//D8000112            retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;
            //D4200212 eventLog_Put(strEventParameter, strObjCommonIn, strSystemMsgRptResult.strResult);

//D8000112            PPT_METHODTRACE_EXIT("PPTServiceManager_i:: TxCassetteDeliveryForInternalBufferReq")
//D8000112            return retVal ;
        }
//D8000112    }
//0.03 end

//0.03//2000.11.24 sug add start
//0.03    //-----------------------------------------
//0.03    //  If <txCassetteDeliveryForInternalBufferReq> failed and
//0.03    //  Target Equipment has Unload Cassette,
//0.03    //  Re-Create Unload request only
//0.03    //-----------------------------------------
//0.03    else if(rc == RC_START_LOT_RESERVATION_FAIL)
//0.03    {
//0.03        PPT_METHODTRACE_V1("", "rc == RC_START_LOT_RESERVATION_FAIL")
//0.03        PPT_METHODTRACE_V1("", "Now rollback txCassetteDeliveryReq and start txLotCassetteForceXferReq.")
//0.03        TX_ROLLBACK(txCassetteDeliveryForInternalBufferReq)
//0.03
//0.03        retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;
//0.03        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
//0.03
//0.03        //PTR2200127 Start
//0.03        TX_BEGIN(txSystemMsgRpt)
//0.03
//0.03        // Call System Message
//0.03        pptSystemMsgRptResult strSystemMsgRptResult;
//0.03        objectIdentifier      dummy;
//0.03
//0.03        try
//0.03        {
//0.03            rc = theCS_PPTManager->txSystemMsgRpt( strSystemMsgRptResult,
//0.03                                                strObjCommonIn,
//0.03                                                SP_SubSystemID_MM,
//0.03                                                SP_SystemMsgCode_DeliveryError,
//0.03                                                retVal->strResult.reasonText,
//0.03                                                TRUE,
//0.03                                                equipmentID,
//0.03                                                "",
//0.03                                                dummy,
//0.03                                                "",
//0.03                                                dummy,
//0.03                                                "",
//0.03                                                dummy,
//0.03                                                "",
//0.03                                                dummy,
//0.03                                                dummy,
//0.03                                                "",
//0.03                                                strObjCommonIn.strTimeStamp.reportTimeStamp,
//0.03                                                "" );
//0.03        }
//0.03        CATCH_TX_TIMEOUT_EXCEPTIONS(txSystemMsgRpt)
//0.03
//0.03        if (rc == RC_OK)
//0.03        {
//0.03            PPT_METHODTRACE_V1("", "txSystemMsgRpt succeed")
//0.03            PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
//0.03            TX_COMMIT(txSystemMsgRpt)
//0.03
//0.03            retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;
//0.03            eventLog_Put(strEventParameter,strObjCommonIn,strSystemMsgRptResult.strResult);
//0.03
//0.03            PPT_METHODTRACE_EXIT("PPTServiceManager_i:: TxCassetteDeliveryForInternalBufferReq")
//0.03            return retVal ;
//0.03        }
//0.03        else
//0.03        {
//0.03            PPT_METHODTRACE_V1("", "txSystemMsgRpt failed.")
//0.03            TX_ROLLBACK(txSystemMsgRpt)
//0.03            retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;
//0.03            eventLog_Put(strEventParameter,strObjCommonIn,strSystemMsgRptResult.strResult);
//0.03            return retVal;
//0.03        }
//0.03    }
//0.03//2000.11.24 sug add end
//0.03    else
//0.03    {
//0.03        PPT_METHODTRACE_V1("", "rc != RC_OK");
//0.03        TX_ROLLBACK(txCassetteDeliveryForInternalBufferReq);
//0.03    }

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup("TXDSC012") ;

//D4200212    CORBA::Long     nLen = strEventParameter.length() ;
//D4200212    strEventParameter.length( nLen + 1 ) ;
//D4200212    strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
//D4200212    strEventParameter[nLen].parameterValue = CIMFWStrDup( equipmentID.identifier ) ;

//D4200212    eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);

    //INN-R170002  PPT_METHODTRACE_EXIT("PPTServiceManager_i:: TxCassetteDeliveryForInternalBufferReq")
    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::TxCassetteDeliveryForInternalBufferReq")    //INN-R170002
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);    //D4100014
    return retVal ;
}
