//
// (c) Copyright: IBM Services Company Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2037. All rights reserved.
//
// SiView
// Name: CS_TxBWSConfigChangeReq.cpp
//
// Class: CS_PPTServiceManager
//
// Service: CS_TxBWSConfigChangeReq()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/23 INN-R170017 Cheng Li       Initial Release
//
// Description:
//
// Return:
//     csBWSConfigChangeReqResult
//
// Parameter:
//        const pptUser&                      requestUserID,
//        const csBWSConfigChangeReqInParm&   strBWSConfigChangeReqInParm,
//        const char *                        claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>

//</Sample Code>
//
//<Method Start>

#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"
#define TRANSACTION_ID "CSEQC001"
csBWSConfigChangeReqResult* CS_PPTServiceManager_i:: CS_TxBWSConfigChangeReq (
        const pptUser&                      requestUserID,
        const csBWSConfigChangeReqInParm&   strBWSConfigChangeReqInParm,
        const char *                        claimMemo
        CORBAENV_LAST_CPP )
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_TxBWSConfigChangeReq");
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID, strBWSConfigChangeReqInParm);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csBWSConfigChangeReqResult* retVal = new csBWSConfigChangeReqResult;
    pptEventParameterSequence strEventParameter;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn strObjCommonIn;
    CORBA::Long rc = 0;

    strObjCommonIn.transactionID    = CIMFWStrDup("CSEQC001");
    strObjCommonIn.strUser          = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup("CSEQC001");

    // Set time stamp.
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    // setting event parameters
    CORBA::ULong nLen = 0;
    strEventParameter.length(1);
    strEventParameter[nLen].parameterName  = CIMFWStrDup( "ACTION_TYPE" );
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strBWSConfigChangeReqInParm.actionType );
    nLen++;

    CORBA::Long nLenBWSConfig = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq.length();
    if(nLenBWSConfig > 0)
    {
        strEventParameter.length(nLen + 1);
        strEventParameter[nLen].parameterName  = CIMFWStrDup( "BWS_ID" );
        strEventParameter[nLen].parameterValue = CIMFWStrDup( strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[0].BWSID.identifier );
        nLen++;
    }
    
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CREATE_TX_OBJ

    //-------------------------------------
    // calendar_GetCurrentTimeDR
    //-------------------------------------
    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn);
        strObjCommonIn.strTimeStamp       = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        if ( CIMFWStrLen(strObjCommonIn.strUser.functionID)==0 )
        {
            strObjCommonIn.strUser.functionID = CIMFWStrDup( "CSEQC001" );
        }
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "calendar_GetCurrentTimeDR:rc != RC_OK");
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult;


        retVal->strResult.transactionID = CIMFWStrDup("CSEQC001");
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //-------------------------------------
    // Privilege Check
    //-------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifier eqpID;
    if(nLenBWSConfig > 0)
    {
        eqpID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[0].BWSID;
    }
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        PPT_METHODTRACE_V1("", "CS_TxBWSConfigChangeReq start txPrivilegeCheckReq");
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult, 
                                                   strObjCommonIn, 
                                                   eqpID, 
                                                   dummy, 
                                                   dummyIDs,
                                                   dummyIDs, 
                                                   dummyIDs, 
                                                   dummyIDs);
        PPT_METHODTRACE_V1("", "CS_TxBWSConfigChangeReq end txPrivilegeCheckReq");
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "txPrivilegeCheckReq:rc != RC_OK");
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("CSEQC001");
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/

    TX_BEGIN(cs_txBWSConfigChangeReq);
    try
    {
        rc = theCS_PPTManager->cs_txBWSConfigChangeReq( *retVal, strObjCommonIn, strBWSConfigChangeReqInParm, claimMemo);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txBWSConfigChangeReq);
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1( "", "rc == RC_OK" );
        TX_COMMIT( cs_txBWSConfigChangeReq );
    }
    else
    {
        PPT_METHODTRACE_V1( "", "rc != RC_OK" );
        TX_ROLLBACK( cs_txBWSConfigChangeReq );
        retVal->strResult.transactionID = CIMFWStrDup( "CSEQC001" );
        return retVal;
    }

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
    retVal->strResult.transactionID = CIMFWStrDup("CSEQC001");
    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_TxBWSConfigChangeReq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
