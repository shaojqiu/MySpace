#ifndef lint
static char *sccsid =  "@(#) 1.1 /superpos/src/csppt/source/posppt/svcmgr/txmethods/CS_TxDowngradeSettingListInq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:51:36 [ 7/13/07 21:51:36 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: CS_TxDowngradeSettingListInq.cpp
//
//
#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"
//
// Class: CS_PPTServiceManager
//
// Service: CS_TxDowngradeSettingListInq()
//
// Change history:
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-17 INN-R170016   JJ.Zhang       NPW Management Initial Release

// Description:
//<Method Summary>

//</Method Summary>

//<MRM>

//</MRM>
//
// Return:
//     csDowngradeSettingListInqResult
//
// Parameter:
//
//     const pptUser&                           requestUserID
//     const csDowngradeSettingListInqInParm&   strDowngradeSettingListInqInParm
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>

//</Sample Code>
//
//<Method Start>

#define  TRANSACTION_ID "CSPCQ002"
csDowngradeSettingListInqResult* CS_PPTServiceManager_i:: CS_TxDowngradeSettingListInq (
    const pptUser&                           requestUserID,
    const csDowngradeSettingListInqInParm&   strDowngradeSettingListInqInParm
    CORBAENV_LAST_CPP)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);    
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxDowngradeSettingListInq ")
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID,strDowngradeSettingListInqInParm);  

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csDowngradeSettingListInqResult* retVal = new csDowngradeSettingListInqResult;
    pptEventParameterSequence strEventParameter;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn strObjCommonIn;
    CORBA::Long rc = 0;

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID);
    strObjCommonIn.strUser = requestUserID;
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                       strObjCommonIn.strTimeStamp.reportTimeStamp;

    CORBA::ULong nLen = strEventParameter.length();
    strEventParameter.length( nLen + 1 );
    strEventParameter[nLen].parameterName    = CIMFWStrDup( "PROD_ID");
    strEventParameter[nLen++].parameterValue = strDowngradeSettingListInqInParm.productID;

    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CREATE_TX_OBJ;

    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn);
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        if ( CIMFWStrLen(strObjCommonIn.strUser.functionID)==0 )
        {
            strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID);
        }
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;

    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,dummy,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(cs_txDowngradeSettingListInq);

    try
    {
        rc = theCS_PPTManager->cs_txDowngradeSettingListInq( *retVal, strObjCommonIn, strDowngradeSettingListInqInParm );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txDowngradeSettingListInq);

    if(rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "cs_txDowngradeSettingListInq() == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txDowngradeSettingListInq)
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txDowngradeSettingListInq() != RC_OK", rc);
        TX_ROLLBACK(cs_txDowngradeSettingListInq);
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
        return retVal;
    }

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/

    /*------------------------------------------------------------------------*/
    /*   Make Event Log                                                       */
    /*------------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: CS_TxDowngradeSettingListInq ")
    PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
