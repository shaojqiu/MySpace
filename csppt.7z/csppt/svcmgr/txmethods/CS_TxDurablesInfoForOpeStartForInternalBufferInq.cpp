//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : CS_TxDurablesInfoForOpeStartForInternalBufferInq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "ppteventlog.hpp"

#define TRANSACTION_ID "CSPDQ002"
csDurablesInfoForOpeStartForInternalBufferInqResult* CS_PPTServiceManager_i::CS_TxDurablesInfoForOpeStartForInternalBufferInq
(
    const pptUser&                                              requestUserID,                                          //<i>R/Requeat User ID
    const csDurablesInfoForOpeStartForInternalBufferInqInParam& strDurablesInfoForOpeStartForInternalBufferInqInParam   //<i>R/In Parameters
    CORBAENV_LAST_CPP                                                                                                   //<i>O/IT Environment
)
{
    CS_PPT_METHODPARMTRACELOG_FILTER( requestUserID.clientNode, requestUserID.userID.identifier );
    PPT_METHODTRACE_ENTRY( "CS_PPTServiceManager_i::CS_TxDurablesInfoForOpeStartForInternalBufferInq" );
    CS_PPT_PARMTRACE_VERBOSE2( requestUserID, strDurablesInfoForOpeStartForInternalBufferInqInParam );

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csDurablesInfoForOpeStartForInternalBufferInqResult* retVal = new csDurablesInfoForOpeStartForInternalBufferInqResult;

    pptEventParameterSequence         strEventParameter;
    objCalendar_GetCurrentTimeDR_out  strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn                    strObjCommonIn;
    CORBA::Long                       rc = 0;

    retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup( TRANSACTION_ID );
    strObjCommonIn.strUser       = requestUserID ;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp                   = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    // setting event parameters
    CORBA::ULong nLen = 0;
    CORBA::ULong durableLen = strDurablesInfoForOpeStartForInternalBufferInqInParam.durableIDs.length();
    strEventParameter.length( durableLen+3 );

    strEventParameter[nLen].parameterName  = CIMFWStrDup("EQUIPMENT_ID");
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strDurablesInfoForOpeStartForInternalBufferInqInParam.equipmentID.identifier );
    nLen++;

    strEventParameter[nLen].parameterName  = CIMFWStrDup("DURABLE_CATEGORY");
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strDurablesInfoForOpeStartForInternalBufferInqInParam.durableCategory );
    nLen++;

    strEventParameter[nLen].parameterName  = CIMFWStrDup("DURABLE_CONTROLJOB_ID");
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strDurablesInfoForOpeStartForInternalBufferInqInParam.durableControlJobID.identifier );
    nLen++;

    for (CORBA::ULong i=0; i<durableLen; i++)
    {
        strEventParameter[nLen].parameterName  = CIMFWStrDup("DURABLE_ID");
        strEventParameter[nLen].parameterValue = CIMFWStrDup( strDurablesInfoForOpeStartForInternalBufferInqInParam.durableIDs[i].identifier );
        nLen++;
    }

    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CREATE_TX_OBJ

    //-------------------------------------
    // calendar_GetCurrentTimeDR
    //-------------------------------------
    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn);
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        if ( CIMFWStrLen(strObjCommonIn.strUser.functionID) == 0 )
        {
            strObjCommonIn.strUser.functionID = CIMFWStrDup( TRANSACTION_ID );
        }
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "calendar_GetCurrentTimeDR:rc != RC_OK");
        TX_ROLLBACK(calendar_GetCurrentTimeDR)
        retVal->strResult               = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );
        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR)

    //-------------------------------------
    // Privilege Check
    //-------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummyID;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,
                                                    strObjCommonIn,
                                                    strDurablesInfoForOpeStartForInternalBufferInqInParam.equipmentID, //equipmentID
                                                    dummyID,                                                           //stockerID
                                                    dummyIDs,                                                          //productIDs
                                                    dummyIDs,                                                          //routeIDs
                                                    dummyIDs,                                                          //lotIDs
                                                    dummyIDs );                                                        //machineRecipeIDs
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "txPrivilegeCheckReq:rc != RC_OK");
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult               = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(CS_TxDurablesInfoForOpeStartForInternalBufferInq)
    try
    {
        rc = theCS_PPTManager->cs_txDurablesInfoForOpeStartForInternalBufferInq(*retVal, strObjCommonIn, strDurablesInfoForOpeStartForInternalBufferInqInParam);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(CS_TxDurablesInfoForOpeStartForInternalBufferInq)

    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc == RC_OK")
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(CS_TxDurablesInfoForOpeStartForInternalBufferInq)
    }
    else
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK")
        TX_ROLLBACK(CS_TxDurablesInfoForOpeStartForInternalBufferInq)
    }

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_TxDurablesInfoForOpeStartForInternalBufferInq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);

    return retVal;
}
