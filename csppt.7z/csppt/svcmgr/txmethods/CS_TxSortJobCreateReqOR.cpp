#ifndef lint
static char *sccsid =  "@(#) 1.10 superpos/src/spppt/source/posppt/svcmgr/txmethods/TxSortJobCreateReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/28/07 15:06:36 [ 11/28/07 15:06:37 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: TxSortJobCreateReq.cpp
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"

// Class: PPTServiceManager
//
// Service: TxSortJobCreateReq()
//
// Change history:
// Date        Defect#    Person         Comments
// ----------- ---------- -------------- -------------------------------------------
// 2007/06/29  D9000005   M.Murata       Initial (R9.0) 
// 2007/10/23  D9000098   M.Murata       Divided Library
// 2007/11/21  D9000007   D.Tamura       EventLog Enhancement.
// 
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/09 DSIV00000201 M.Ishino       Improvement of Post-Processing.
// 2010/11/25 PSIV00002617 A.Tomari       Add the following document information
//                                        -<IN-parm's description>
// 2013/08/13 DSN000080226 W.Zhang        Add for Priviledge Check for lotID
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/11/09 INN-R170017  Evie Su        Initial Release
// 
// 
//Description:
//<Method Summary>
//  This fuction creates Sorter Job information.
//</Method Summary>
// 
//<MRM>
//    EPQ10-3. : Wafer Sorter Automation
//</MRM>
// 
// Return:
//   pptSortJobCreateReqResult
//  
// Parameter:
//        const pptUser&                                      requestUserID
//        const pptSorterComponentJobListAttributesSequence&  strSorterComponentJobListAttributesSequence
//        const objectIdentifier&                             equipmentID
//        const char *                                        portGroupID
//        CORBA::Boolean                                      waferIDReadFlag
//        const char *                                        claimMemo
//  
// Require:
//  
// Ensure:
//  
// Exception:
//  
// Pseudo code:
//  
// Sample code:
//<Sample Code>
//  //m_pSvcMgr is PPTServiceManager class
//  //m_User is pptUser struct
// 
// 
//  objectIdentifier equipmentID;
//  CORBA::String_var portGroupID;
//  CORBA::Boolean waferIDReadFlag;
//  equipmentID.identifier  = CORBA::string_dup("EQP-001");
//  portGroupID             = CORBA::string_dup("PG1");
//  waferIDReadFlag         = FALSE;
//  
//  strSorterComponentJobListAttributesSequence.length(1);
//  strSorterComponentJobListAttributesSequence[0].sorterComponentJobID.identifier          = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].requestTimeStamp                         = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].originalCarrierID.identifier             = CORBA::string_dup("CARR-001");
//  strSorterComponentJobListAttributesSequence[0].originalPortID.identifier                = CORBA::string_dup("P1");
//  strSorterComponentJobListAttributesSequence[0].originalCarrierXferStatus                = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].originalCarrierEquipmentID.identifier    = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].originalCarrierStockerID.identifier      = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].destinationCarrierID.identifier          = CORBA::string_dup("CARR-002");
//  strSorterComponentJobListAttributesSequence[0].destinationPortID.identifier             = CORBA::string_dup("P2");
//  strSorterComponentJobListAttributesSequence[0].destinationCarrierXferStatus             = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].destinationCarrierEquipmentID.identifier = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].destinationCarrierStockerID.identifier   = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].componentSorterJobStatus                 = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].preSorterComponentJobID.identifier       = CORBA::string_dup("");
// 
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence.length(1);
// 
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].portGroup                          = CORBA::string_dup("PG1");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].equipmentID.identifier             = CORBA::string_dup("EQP-001");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].actionCode                         = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].requestTime                        = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].direction                          = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].waferID                            = CORBA::string_dup("LOT000A.01.01");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].lotID                              = CORBA::string_dup("LOT000A.01");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].destinationCassetteID              = CORBA::string_dup("CARR-002");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].destinationPortID.identifier       = CORBA::string_dup("P2");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].bDestinationCassetteManagedBySiView= TRUE;
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].destinationSlotNumber              = 1;
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].originalCassetteID.identifier      = CORBA::string_dup("CARR-001");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].originalPortID.identifier          = CORBA::string_dup("P1");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].bOriginalCassetteManagedBySiView   = TRUE;
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].originalSlotNumber                 = 3;
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].requestUserID.identifier           = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].replyTime                          = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].sorterStatus                       = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].slotMapCompareStatus               = CORBA::string_dup("");
//  strSorterComponentJobListAttributesSequence[0].strWaferSorterSlotMapSequence[0].mmCompareStatus                    = CORBA::string_dup("");
//                                                                                  
//  pptSortJobCreateReqResult * pRet  = NULL;
//  CORBA::String_var claimMemo = CORBA::string_dup("Claim Memo");
//  
//  pRet = m_pSvcMgr->TxSortJobCreateReq(
//      m_User,
//      strSorterComponentJobListAttributesSequence,
//      equipmentID,
//      portGroupID,
//      waferIDReadFlag,
//      claimMemo);
//     
//</Sample Code>
//<Method Start>
//INN-R170017 pptSortJobCreateReqResult* PPTServiceManager_i:: TxSortJobCreateReq( 
pptSortJobCreateReqResult* CS_PPTServiceManager_i:: TxSortJobCreateReq(  //INN-R170017
        const pptUser&                                      requestUserID,                                 //<i>R/Request User ID  //PSIV00002617
        const pptSorterComponentJobListAttributesSequence&  strSorterComponentJobListAttributesSequence,    //<i>R/Sorter Component Job List Attribute
        const objectIdentifier&                             equipmentID,                                   //<i>R/Equipment ID
        const char *                                        portGroupID,                                   //<i>R/Port Group ID
        CORBA::Boolean                                      waferIDReadFlag,                               //<i>R/Wafer ID Read Flag
        const char *                                        claimMemo                                      //<i>O/Claim Memo
        CORBAENV_LAST_CPP )                                                                                //<i>O/IT Environment
//D9000098 add start
#ifndef PPT_OPTIONS
{
    PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("PPTServiceManager_i:: TxSortJobCreateReq");
    PPT_PARMTRACE_VERBOSE6(requestUserID, strSorterComponentJobListAttributesSequence, equipmentID, portGroupID, waferIDReadFlag, claimMemo);

    pptSortJobCreateReqResult* retVal = new pptSortJobCreateReqResult;
    pptObjCommonIn            strObjCommonIn ;
    strObjCommonIn.strUser                      = requestUserID ;
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strObjCommonIn.transactionID                = CIMFWStrDup("TXEQC015") ;
    retVal->strResult.transactionID             = CIMFWStrDup("TXEQC015") ;

    pptEventParameterSequence strEventParameter ;
    strEventParameter.length(0);
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    PPT_METHODTRACE_V1("", "This function is currently disabled.")
    PPT_SET_TX_MSG((*retVal), MSG_FUNCTION_DISABLE, RC_FUNCTION_DISABLE);

    PPT_METHODTRACE_EXIT("PPTServiceManager_i:: TxSortJobCreateReq")
    PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal ;
}
#else
//D9000098 add end 
{
    PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("PPTServiceManager_i:: TxSortJobCreateReq");
    PPT_PARMTRACE_VERBOSE6(requestUserID, strSorterComponentJobListAttributesSequence, equipmentID, portGroupID, waferIDReadFlag, claimMemo);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    pptSortJobCreateReqResult* retVal = new pptSortJobCreateReqResult;

    pptEventParameterSequence strEventParameter;
    strEventParameter.length(0);

    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn strObjCommonIn;
    CORBA::Long rc = 0;
    
    CORBA::Boolean bSkipOrigCast = FALSE; //INN-R170017
    CORBA::Boolean bSkipDestCast = FALSE; //INN-R170017

    //---------------------------------------------
    // Set transaction ID TXEQC015 and user ID.
    //---------------------------------------------
    CORBA::String_var TX_ID = CIMFWStrDup("TXEQC015");

    strObjCommonIn.transactionID    = CIMFWStrDup(TX_ID);
    strObjCommonIn.strUser          = requestUserID;
    retVal->strResult.transactionID = CIMFWStrDup(TX_ID);

    //---------------------------------------------
    // Set time stamp.
    //---------------------------------------------
    strObjCommonIn.strTimeStamp.reportTimeStamp                   = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    //---------------------------------------------
    // Put Incoming Log.
    //---------------------------------------------
    CORBA::Long nSrtComp = strSorterComponentJobListAttributesSequence.length();
    CORBA::Long i = 0;
    CORBA::Long nLen = strEventParameter.length();
    strEventParameter.length( nLen + 4 );
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("EQP_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( equipmentID.identifier );
//D9000007    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_GROUP_ID");
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_GRP");//D900007
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( portGroupID );
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("WAFER_ID_READ_FLAG");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( (waferIDReadFlag ==TRUE)?"TRUE":"FALSE" ) ;
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ATTRIBUTES");

    ostrstream eventBuf;
    for(i=0; i<nSrtComp; i++)
    {
        ostrstream tmpBuf;
        tmpBuf << "[" ;
//D9000007        tmpBuf << "ORGINAL_CAST_ID:" << strSorterComponentJobListAttributesSequence[i].originalCarrierID.identifier     << "," ;
//D9000007        tmpBuf << "ORGINAL_PORT_ID:" << strSorterComponentJobListAttributesSequence[i].originalPortID.identifier        << "," ;
//D9000007        tmpBuf << "DSTINATION_CAST_ID:" << strSorterComponentJobListAttributesSequence[i].destinationCarrierID.identifier  << "," ;
//D9000007        tmpBuf << "DSTINATION_CAST_ID:" << strSorterComponentJobListAttributesSequence[i].destinationCarrierID.identifier  ;
//D9000007 add start
        tmpBuf << "ORG_STK_ID:"         << strSorterComponentJobListAttributesSequence[i].originalCarrierStockerID.identifier      << "," ;
        tmpBuf << "ORG_EQP_ID:"         << strSorterComponentJobListAttributesSequence[i].originalCarrierEquipmentID.identifier    << "," ;
        tmpBuf << "ORG_PORT_ID:"        << strSorterComponentJobListAttributesSequence[i].originalPortID.identifier                << "," ;
        tmpBuf << "ORG_CAST_ID:"        << strSorterComponentJobListAttributesSequence[i].originalCarrierID.identifier             << "," ;
        tmpBuf << "ORG_CAST_XFER_STAT:" << strSorterComponentJobListAttributesSequence[i].originalCarrierXferStatus                << "," ;
 
        tmpBuf << "DEST_STK_ID:"         << strSorterComponentJobListAttributesSequence[i].destinationCarrierStockerID.identifier   << "," ;
        tmpBuf << "DEST_EQP_ID:"         << strSorterComponentJobListAttributesSequence[i].destinationCarrierEquipmentID.identifier << "," ;
        tmpBuf << "DEST_PORT_ID:"        << strSorterComponentJobListAttributesSequence[i].destinationPortID.identifier             << "," ;
        tmpBuf << "DEST_CAST_ID:"        << strSorterComponentJobListAttributesSequence[i].destinationCarrierID.identifier          << "," ;
        tmpBuf << "DEST_CAST_XFER_STAT:" << strSorterComponentJobListAttributesSequence[i].destinationCarrierXferStatus;
//D9000007 add end
        tmpBuf << "]" ;
        if( nSrtComp -1 != i )
        {
            tmpBuf << "," ;
        }
        tmpBuf << ends;

        eventBuf << tmpBuf.str();

        tmpBuf.rdbuf()->freeze(0);
    }
    eventBuf << ends;
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( eventBuf.str() );
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    eventBuf.rdbuf()->freeze(0);

    //---------------------------------------------
    // Get calendar
    //---------------------------------------------
    CREATE_TX_OBJ;

    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        //INN-R170017 rc = thePPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn);
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn); //INN-R170017
        strObjCommonIn.strTimeStamp       = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        strObjCommonIn.strUser.functionID = CIMFWStrDup( TX_ID );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "calendar_GetCurrentTimeDR() != RC_OK");
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult               = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TX_ID);
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //---------------------------------------------
    // Check privilege
    //---------------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    dummy.identifier = CIMFWStrDup("");
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

//DSN000080226 Add Start
    objectIdentifierSequence lotIDs;
    CORBA::Long count = 0 ;
    CORBA::Long lotLen = 25;
    lotIDs.length(lotLen);
    
    CORBA::Long sorterJobListNum = strSorterComponentJobListAttributesSequence.length();
    PPT_METHODTRACE_V2("", " strSorterComponentJobListAttributesSequence length=", sorterJobListNum);
    for(CORBA::Long sorterJobIndex=0; sorterJobIndex<sorterJobListNum; sorterJobIndex++)
    {
        CORBA::Long waferNum = strSorterComponentJobListAttributesSequence[sorterJobIndex].strWaferSorterSlotMapSequence.length();
        PPT_METHODTRACE_V2("", " strWaferSorterSlotMapSequence length=", waferNum);
        for(CORBA::Long waferIndex=0; waferIndex<waferNum; waferIndex++)
        {
            //INN-R170017 add start
            PPT_METHODTRACE_V2( "", "## actionCode", strSorterComponentJobListAttributesSequence[sorterJobIndex].strWaferSorterSlotMapSequence[waferIndex].actionCode );
            if( 0 == CIMFWStrCmp( CS_WaferTransfer_BWSIn,
                                  strSorterComponentJobListAttributesSequence[sorterJobIndex].strWaferSorterSlotMapSequence[waferIndex].actionCode ) )
            {
                bSkipDestCast = TRUE;
            }

            if( 0 == CIMFWStrCmp( CS_WaferTransfer_BWSOut,
                                  strSorterComponentJobListAttributesSequence[sorterJobIndex].strWaferSorterSlotMapSequence[waferIndex].actionCode ) )
            {
                bSkipOrigCast = TRUE;
            }
            PPT_METHODTRACE_V2( "", "## bSkipOrigCast=", (bSkipOrigCast?"TRUE":"FALSE") );
            PPT_METHODTRACE_V2( "", "## bSkipDestCast=", (bSkipDestCast?"TRUE":"FALSE") );
            //INN-R170017 add end

            objectIdentifier tempLotID = strSorterComponentJobListAttributesSequence[sorterJobIndex].strWaferSorterSlotMapSequence[waferIndex].lotID;
            PPT_METHODTRACE_V2("", " waferIndex ...", waferIndex);
            for(CORBA::Long lotIndex=0; lotIndex<count; lotIndex++)
            {
                PPT_METHODTRACE_V2("", " check lotID index ...", lotIndex);
                if(0 == CIMFWStrCmp(lotIDs[lotIndex].identifier, tempLotID.identifier))
                {
                    PPT_METHODTRACE_V1("", " the lotID have in lotIDs.");
                    break;
                }
            }
            if(lotIndex>=count)
            {
                PPT_METHODTRACE_V2("", " add lotID index ...", count);
                if( count >= lotLen )
                {
                    lotLen += 10;
                    lotIDs.length(lotLen);
                }
                lotIDs[count] = tempLotID;
                count++;
            }
        }    
    }
    lotIDs.length(count);
//DSN000080226 Add End

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
//DSN000080226        rc = thePPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult, strObjCommonIn, equipmentID, dummy, dummyIDs, dummyIDs, dummyIDs, dummyIDs);
        //INN-R170017 rc = thePPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult, strObjCommonIn, equipmentID, dummy, dummyIDs, dummyIDs, lotIDs, dummyIDs); //DSN000080226
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult, strObjCommonIn, equipmentID, dummy, dummyIDs, dummyIDs, lotIDs, dummyIDs);  //INN-R170017
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "txPrivilegeCheckReq() != RC_OK");
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult               = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TX_ID);

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(txSortJobCreateReq);

    try
    {
        //INN-R170017 rc = thePPTManager->txSortJobCreateReq(*retVal, strObjCommonIn,
        rc = theCS_PPTManager->txSortJobCreateReq(*retVal, strObjCommonIn,  //INN-R170017
                                               strSorterComponentJobListAttributesSequence,
                                               equipmentID,
                                               portGroupID,
                                               waferIDReadFlag,
                                               claimMemo);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txSortJobCreateReq);


//DSIV00000201    pptPostProcessActionRegistReqResult     strPostProcessActionRegistReqResult;
    pptPostProcessActionRegistReqResult__100     strPostProcessActionRegistReqResult;   //DSIV00000201
    if( rc == RC_OK) 
    {
        PPT_METHODTRACE_V1("", "txSortJobCreateReq() == RC_OK. Registration of Post Process...");
        objectIdentifierSequence  tmpCassetteIDs;

        CORBA::Long castCnt = 0;
        tmpCassetteIDs.length(nSrtComp * 2);
        
        //INN-R170017 add start
        if( bSkipOrigCast == TRUE )
        {
            PPT_METHODTRACE_V1( "", "## For BWSOut ==> add dest. cassette, not original cassette(zone)." );
            for(i=0; i<nSrtComp; i++)
            {
                tmpCassetteIDs[castCnt++] = strSorterComponentJobListAttributesSequence[i].destinationCarrierID;
            }
            tmpCassetteIDs.length(castCnt);
        }
        else if( bSkipDestCast == TRUE )
        {
            PPT_METHODTRACE_V1( "", "## For BWSIn ==> add original cassette, not dest. cassette(zone)." );
            for(i=0; i<nSrtComp; i++)
            {
                tmpCassetteIDs[castCnt++] = strSorterComponentJobListAttributesSequence[i].originalCarrierID;
            }
            tmpCassetteIDs.length(castCnt);
        }
        else
        {
        //INN-R170017 add end
        for(i=0; i<nSrtComp; i++)
        {
            tmpCassetteIDs[castCnt++] = strSorterComponentJobListAttributesSequence[i].originalCarrierID;
            tmpCassetteIDs[castCnt++] = strSorterComponentJobListAttributesSequence[i].destinationCarrierID;
        }
        } //INN-R170017

        objectIdentifierSequence  cassetteIDs;
        CORBA::Long castLen = tmpCassetteIDs.length();
        cassetteIDs.length(castLen);
        castCnt = 0;
        for(i=0; i<castLen; i++)
        {
            CORBA::Boolean findFlag = FALSE;
            for(CORBA::Long j = i + 1  ; j<castLen; j++)
            {
                if( 0 == CIMFWStrCmp( tmpCassetteIDs[i].identifier, tmpCassetteIDs[j].identifier ) )
                {
                    findFlag = TRUE;
                    break;
                }
            }
            if( FALSE == findFlag )
            {
                cassetteIDs[castCnt]  = tmpCassetteIDs[i];
                castCnt++;
            }
        }
        cassetteIDs.length(castCnt);
        
        //INN-R170017 add start
        PPT_METHODTRACE_V2( "", "castCnt", castCnt );
        for( i=0; i<castCnt; i++ )
        {
            PPT_METHODTRACE_V2( "", "i", i );
            PPT_METHODTRACE_V2( "", "cassetteIDs", cassetteIDs[i].identifier );
        }
        //INN-R170017 add end

        //-----------------------------------------------
        // Call txPostProcessActionRegistReq__100
        //-----------------------------------------------
        pptPostProcessRegistrationParm          strPostProcessRegistrationParm;
        strPostProcessRegistrationParm.cassetteIDs = cassetteIDs;
        try
        {
//DSIV00000201            rc = thePPTManager->txPostProcessActionRegistReq( strPostProcessActionRegistReqResult,
            //INN-R170017 rc = thePPTManager->txPostProcessActionRegistReq__100( strPostProcessActionRegistReqResult, //DSIV00000201
            rc = theCS_PPTManager->txPostProcessActionRegistReq__100( strPostProcessActionRegistReqResult,  //INN-R170017
                                                              strObjCommonIn,
                                                              strObjCommonIn.transactionID,    //TXEQC015  TXID
                                                              NULL,                            //patternID
                                                              NULL,                            //dkey
                                                              -1,                              //seqNo
                                                              strPostProcessRegistrationParm,
                                                              claimMemo );
        }
        CATCH_TX_TIMEOUT_EXCEPTIONS(txPostProcessActionRegistReq__100); //DSIV00000201
//DSIV00000201        CATCH_TX_TIMEOUT_EXCEPTIONS(txPostProcessActionRegistReq);
        
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "Registration of Post Process:rc != RC_OK");
            retVal->strResult = strPostProcessActionRegistReqResult.strResult;
        }
    }

    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "txSortJobCreateReq and txPostProcessActionRegistReq__100 : rc == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(txSortJobCreateReq);

        /*-----------------------------------------------------------------------*/
        /*   Post Process                                                        */
        /*-----------------------------------------------------------------------*/
        //--------------------------------------
        // Call TxPostProcessExeqReq            
        //--------------------------------------
//DSIV00000201        pptPostProcessExecReqResult_var result  = TxPostProcessExecReq( requestUserID, strPostProcessActionRegistReqResult.dKey, 1, 0, NULL, "" );
        pptPostProcessExecReqResult__100_var result  = TxPostProcessExecReq__100( requestUserID, strPostProcessActionRegistReqResult.dKey, 1, 0, NULL, "" );    //DSIV00000201
        
        rc = atoi( result->strResult.returnCode ); 
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "TxPostProcessExecReq__100 :rc != RC_OK");
            retVal->strResult = result->strResult;                      //Error Message
        }
        else
        {
            PPT_METHODTRACE_V1("", "TxPostProcessExecReq__100 :rc == RC_OK");
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "txSortJobCreateReq or txPostProcessActionRegistReq__100  != RC_OK");
        TX_ROLLBACK(txSortJobCreateReq);
    }

    //Event Log reSet
    nLen      = strEventParameter.length();
    strEventParameter.length( nLen + 1 );
//D9000007    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("SORTJOB_ID");
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("SORT_JOB_ID");//D9000007
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( retVal->sorterJobID.identifier );

    PPTEVENTLOG_SET( retVal, &strObjCommonIn, &strEventParameter );

    retVal->strResult.transactionID = CIMFWStrDup(TX_ID);

    PPT_METHODTRACE_EXIT("PPTServiceManager_i:: TxSortJobCreateReq");
    PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
//D9000098 add start
#endif
//D9000098 add end
