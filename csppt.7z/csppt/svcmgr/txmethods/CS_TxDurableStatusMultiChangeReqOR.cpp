//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: CS_TxDurableStatusMultiChangeReqOR.cpp
//

//INN-R170003 #include "pptsm.hpp"
#include "cs_pptsm.hpp"    //INN-R170003

#include "pptdefs.h"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"

// Class: CS_PPTServiceManager
//
// Service: TxDurableStatusMultiChangeReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2016/07/25 DSN000101569 C.Mo           Durable Sub Status Control Support.
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/11/02 INN-R170003  Nick Tsai      Support Fixture
//
// Description:
//<Method Summary>
//  This function changes Status and Sub Status of multiple Durables to the same status.
//</Method Summary>
//
//<MRM>
//DRB6-2. : Durable Status / Sub-Status Change
//</MRM>
//
// Return:
//    pptDurableStatusMultiChangeReqResult
//
// Parameter:
//    const pptUser&                               requestUserID,
//    const pptDurableStatusMultiChangeReqInParm&  strDurableStatusMultiChangeReqInParm,
//    const char*                                  claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>
//    //m_pSvcMgr is PPTServiceManager class
//    //m_User is pptUser struct
//
//    pptDurableStatusMultiChangeReqInParm strDurableStatusMultiChangeReqInParm;
//    strDurableStatusMultiChangeReqInParm.durableStatus               = CORBA::string_dup("NOTAVAILABLE");
//    strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier = CORBA::string_dup("NA_SUB01");
//    strDurableStatusMultiChangeReqInParm.durableCategory             = CORBA::string_dup("Cassette");
//    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq.length(1);
//    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID.identifier = CORBA::string_dup("Cast001");
//    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus        = CORBA::string_dup("NOTAVAILABLE");
//    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus     = CORBA::string_dup("NA_SUB02");
//    pptDurableStatusMultiChangeReqResult* pRet = NULL;
//    pRet = pptSvcMgr->TxDurableStatusMultiChangeReq(m_User, strDurableStatusMultiChangeReqInParm, claimMemo);
//</Sample Code>
//
//<Method Start>
//INN-R170003 pptDurableStatusMultiChangeReqResult* PPTServiceManager_i:: TxDurableStatusMultiChangeReq (
pptDurableStatusMultiChangeReqResult* CS_PPTServiceManager_i:: TxDurableStatusMultiChangeReq (     //INN-R170003
    const  pptUser&                               requestUserID,                        //<i>R/Request User ID
    const  pptDurableStatusMultiChangeReqInParm&  strDurableStatusMultiChangeReqInParm, //<i>R/In Parameters
    const char*                                   claimMemo                             //<i>R/Claim Memo
    CORBAENV_LAST_CPP)                                                                  //<i>O/IT Environment
{
    PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: TxDurableStatusMultiChangeReq")
    PPT_PARMTRACE_VERBOSE3(requestUserID, strDurableStatusMultiChangeReqInParm, claimMemo);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    pptDurableStatusMultiChangeReqResult* retVal = new pptDurableStatusMultiChangeReqResult;
    pptEventParameterSequence        strEventParameter;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn                   strObjCommonIn;
    CORBA::Long                      rc = 0;
    CORBA::String_var                txID;

    //-----------------------------------------------------------------------//
    //   Decide TX_ID                                                        //
    //-----------------------------------------------------------------------//
    if (0 == CIMFWStrCmp(SP_DurableCat_Reticle, strDurableStatusMultiChangeReqInParm.durableCategory))
    {
        txID = CIMFWStrDup("TXPDC065");
    }
    else if (0 == CIMFWStrCmp(SP_DurableCat_ReticlePod, strDurableStatusMultiChangeReqInParm.durableCategory))
    {
        txID = CIMFWStrDup("TXPDC066");
    }
    //INN-R170003 add start
    else if (0 == CIMFWStrCmp(SP_DurableCat_Fixture, strDurableStatusMultiChangeReqInParm.durableCategory))
    {
        txID = CIMFWStrDup("CSPDC011");
    }
    //INN-R170003 add end
    else
    {
        txID = CIMFWStrDup("TXPDC064");
    }
    PPT_METHODTRACE_V2("", "TransactionID", txID);

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = txID;
    strObjCommonIn.strUser = requestUserID;

    retVal->strResult.transactionID = txID;

    //---------------------------------------------
    // Set time stamp.
    //---------------------------------------------
    strObjCommonIn.strTimeStamp.reportTimeStamp                   = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    //---------------------------------------------
    // Put Incoming Log.
    //---------------------------------------------
    CORBA::ULong nLen = strEventParameter.length();
    strEventParameter.length(nLen + 3);
    strEventParameter[nLen].parameterName    = CIMFWStrDup("DURABLE_STATUS");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strDurableStatusMultiChangeReqInParm.durableStatus);
    strEventParameter[nLen].parameterName    = CIMFWStrDup("DURABLE_SUBSTATUS");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier);
    strEventParameter[nLen].parameterName    = CIMFWStrDup("DURABLE_CATEGORY");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strDurableStatusMultiChangeReqInParm.durableCategory);

    CORBA::ULong durableLen = strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq.length();
    CORBA::ULong durableCnt = 0;
    PPT_METHODTRACE_V2("", "Current Durable Stauts Length", durableLen);
    if (durableLen > 0)
    {
        CORBA::ULong strDurableLen = 0;
        for (durableCnt = 0; durableCnt < durableLen; durableCnt++)
        {
            strDurableLen += CIMFWStrLen(strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID.identifier) + 1;
            PPT_METHODTRACE_V2("", "strDurableLen", strDurableLen);
        }
        char* strDurable = CORBA::string_alloc(strDurableLen + 1);
        strDurable[0] = '\0';

        for (durableCnt = 0; durableCnt < durableLen; durableCnt++)
        {
            CIMFWStrCat(strDurable, (const char *)strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID.identifier);
            CIMFWStrCat(strDurable, "," );
        }
        strDurable[--strDurableLen] = '\0';
        PPT_METHODTRACE_V2("", "Collected Durable ID", strDurable);

        nLen = strEventParameter.length();
        strEventParameter.length(nLen + 1);
        strEventParameter[nLen].parameterName  = CIMFWStrDup("DURABLE_ID");
        strEventParameter[nLen].parameterValue = strDurable;
    }

    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);

    CREATE_TX_OBJ

    //---------------------------------------------
    // Get calendar
    //---------------------------------------------
    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = thePPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn);
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        strObjCommonIn.strUser.functionID = txID;
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult               = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = txID;
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //---------------------------------------------
    // Check privilege
    //---------------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = thePPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,
                                                strObjCommonIn,
                                                dummy,
                                                dummy,
                                                dummyIDs,
                                                dummyIDs,
                                                dummyIDs,
                                                dummyIDs);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult               = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = txID;
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(txDurableStatusMultiChangeReq)
    try
    {
        rc = thePPTManager->txDurableStatusMultiChangeReq(*retVal, strObjCommonIn, strDurableStatusMultiChangeReqInParm, claimMemo);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txDurableStatusMultiChangeReq)

    //-------------------------------------
    // Post-Processing Registration Section
    //-------------------------------------
    pptPostProcessActionRegistReqResult__100 strPostProcessActionRegistReqResult;

    if(0 == CIMFWStrCmp(SP_DurableCat_Cassette, strDurableStatusMultiChangeReqInParm.durableCategory))
    {
        if(rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "txDurableStatusMultiChangeReq :rc == RC_OK");

            // Register post pattern
            pptPostProcessRegistrationParm strPostProcessRegistrationParm;
            strPostProcessRegistrationParm.cassetteIDs.length(durableLen);
            for (durableCnt = 0; durableCnt < durableLen; durableCnt++)
            {
                strPostProcessRegistrationParm.cassetteIDs[durableCnt]
                    = strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID;
            }

            //Post-Processing Registration
            try
            {
                rc = thePPTManager->txPostProcessActionRegistReq__100( strPostProcessActionRegistReqResult,
                                                                       strObjCommonIn,
                                                                       strObjCommonIn.transactionID,    //TXID
                                                                       NULL,                            //patternID
                                                                       NULL,                            //dkey
                                                                       -1,                              //seqNo
                                                                       strPostProcessRegistrationParm,
                                                                       claimMemo );
            }
            CATCH_TX_TIMEOUT_EXCEPTIONS(txPostProcessActionRegistReq__100);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "Registration of Post Process rc != RC_OK");
                retVal->strResult = strPostProcessActionRegistReqResult.strResult;
            }
        }
    }

    if(rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "txDurableStatusMultiChangeReq :rc == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(txDurableStatusMultiChangeReq)

        if(0 == CIMFWStrCmp(SP_DurableCat_Cassette, strDurableStatusMultiChangeReqInParm.durableCategory))
        {
            //Post Process Execution
            pptPostProcessExecReqResult__100_var result = TxPostProcessExecReq__100(requestUserID,
                                                                                    strPostProcessActionRegistReqResult.dKey,
                                                                                    1,
                                                                                    0,
                                                                                    NULL,
                                                                                    "");

            rc = atoi(result->strResult.returnCode);
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "TxPostProcessExecReq__100 :rc != RC_OK");
                retVal->strResult = result->strResult;
            }
        }
    }
    else
    {
        PPT_METHODTRACE_V2("", "txDurableStatusMultiChangeReq() != RC_OK", rc);
        TX_ROLLBACK(txDurableStatusMultiChangeReq)
    }

    //-----------------------------------------------------------------------
    //   Post Process
    //-----------------------------------------------------------------------
    retVal->strResult.transactionID = txID;
    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::TxDurableStatusMultiChangeReq");
    PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
