//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : CS_TxDurableOperationStartCancelForInternalBufferReq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"
#include "pfwgls.hpp"

#define TRANSACTION_ID "CSPDC009"
csDurableOperationStartCancelForInternalBufferReqResult* CS_PPTServiceManager_i::CS_TxDurableOperationStartCancelForInternalBufferReq
(
    const pptUser&                                                  requestUserID,                                              //<i>R/Request User ID
    const csDurableOperationStartCancelForInternalBufferReqInParam& strDurableOperationStartCancelForInternalBufferReqInParam,  //<i>R/In Parameters
    const char*                                                     claimMemo                                                   //<i>R/Claim Memo
    CORBAENV_LAST_CPP                                                                                                           //<i>O/IT Environment
)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_TxDurableOperationStartCancelForInternalBufferReq");
    CS_PPT_PARMTRACE_VERBOSE3(requestUserID, strDurableOperationStartCancelForInternalBufferReqInParam, claimMemo);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csDurableOperationStartCancelForInternalBufferReqResult* retVal = new csDurableOperationStartCancelForInternalBufferReqResult;

    pptEventParameterSequence         strEventParameter;
    objCalendar_GetCurrentTimeDR_out  strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn                    strObjCommonIn;
    CORBA::Long                       rc = 0;

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID    = CIMFWStrDup( TRANSACTION_ID );
    strObjCommonIn.strUser          = requestUserID;

    retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );

    //---------------------------------------------
    // Set time stamp.
    //---------------------------------------------
    strObjCommonIn.strTimeStamp.reportTimeStamp                   = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    //---------------------------------------------
    // Put Incoming Log.
    //---------------------------------------------
    CORBA::ULong nLen = strEventParameter.length();
    strEventParameter.length(nLen + 2);
    strEventParameter[nLen].parameterName    = CIMFWStrDup("EQP_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( strDurableOperationStartCancelForInternalBufferReqInParam.equipmentID.identifier );
    strEventParameter[nLen].parameterName    = CIMFWStrDup("DURABLE_CONTROL_JOB_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( strDurableOperationStartCancelForInternalBufferReqInParam.durableControlJobID.identifier );
    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);

    CREATE_TX_OBJ;

    try
    {
        PPT_METHODTRACE_V1("", "Call clearThreadSpecificDataString");
//        clearThreadSpecificDataString();
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(clearThreadSpecificDataString);

    //---------------------------------------------
    // Get calendar
    //---------------------------------------------
    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR( strCalendar_GetCurrentTimeDR_out, strObjCommonIn );
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        strObjCommonIn.strUser.functionID = CIMFWStrDup( TRANSACTION_ID );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult               = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //---------------------------------------------
    // Check privilege
    //---------------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummyID;
    dummyID.identifier = CIMFWStrDup("");
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,
                                                    strObjCommonIn,
                                                    strDurableOperationStartCancelForInternalBufferReqInParam.equipmentID, //equipmentID
                                                    dummyID,                                                               //stockerID
                                                    dummyIDs,                                                              //productIDs
                                                    dummyIDs,                                                              //routeIDs
                                                    dummyIDs,                                                              //lotIDs
                                                    dummyIDs );                                                            //machineRecipeIDs
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult               = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(cs_txDurableOperationStartCancelForInternalBufferReq);
    try
    {
        rc = theCS_PPTManager->cs_txDurableOperationStartCancelForInternalBufferReq( *retVal,
                                                                                     strObjCommonIn,
                                                                                     strDurableOperationStartCancelForInternalBufferReqInParam,
                                                                                     claimMemo );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txDurableOperationStartCancelForInternalBufferReq);

    //-------------------------------------
    // Post-Processing Registration Section
    //-------------------------------------
    pptDurablePostProcessActionRegistReqResult strPostProcessActionRegistReqResult;

    if ( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_txDurableOperationStartCancelForInternalBufferReq :rc == RC_OK");

        pptDurablePostProcessActionRegistReqInParam strDurablePostProcessActionRegistReqInParam;
        strDurablePostProcessActionRegistReqInParam.txID = strObjCommonIn.transactionID;
        strDurablePostProcessActionRegistReqInParam.patternID = CIMFWStrDup("");
        strDurablePostProcessActionRegistReqInParam.key = CIMFWStrDup("");
        strDurablePostProcessActionRegistReqInParam.seqNo = -1;
        CORBA::Long durableLen = retVal->strStartDurables.length();
        strDurablePostProcessActionRegistReqInParam.strDurablePostProcessRegistrationParm.durableIDs.length(durableLen);
        for(CORBA::Long durableSeq = 0; durableSeq < durableLen; durableSeq++)
        {
            strDurablePostProcessActionRegistReqInParam.strDurablePostProcessRegistrationParm.durableIDs[durableSeq]
                = retVal->strStartDurables[durableSeq].durableID;
        }
        strDurablePostProcessActionRegistReqInParam.strDurablePostProcessRegistrationParm.equipmentID = strDurableOperationStartCancelForInternalBufferReqInParam.equipmentID;
        strDurablePostProcessActionRegistReqInParam.strDurablePostProcessRegistrationParm.durableControlJobID = strDurableOperationStartCancelForInternalBufferReqInParam.durableControlJobID;
        strDurablePostProcessActionRegistReqInParam.strDurablePostProcessRegistrationParm.durableCategory = retVal->durableCategory;

        //Post-Processing Registration for durable
        try
        {
            rc = theCS_PPTManager->txDurablePostProcessActionRegistReq(strPostProcessActionRegistReqResult,
                                                                       strObjCommonIn,
                                                                       strDurablePostProcessActionRegistReqInParam,
                                                                       claimMemo);
        }
        CATCH_TX_TIMEOUT_EXCEPTIONS(txDurablePostProcessActionRegistReq);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "Registration of Post Process for OpeCompedLot:rc != RC_OK");
            retVal->strResult = strPostProcessActionRegistReqResult.strResult;
        }

        //----------------------------------
        // Post-Processing Update Section
        //----------------------------------
        if ( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_txDurableOperationStartCancelForInternalBufferReq and Post Process task Registration : rc == RC_OK");

            //  Update postProcessQueue
            pptPostProcessAdditionalInfoSequence strPostProcessAdditionalInfoSeq;
            strPostProcessAdditionalInfoSeq.length(1);
            CORBA::Boolean additionalInfoFlag = FALSE;
            for ( CORBA::ULong iCnt=0; iCnt < strPostProcessActionRegistReqResult.strPostProcessActionInfoSeq.length(); iCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to strPostProcessActionRegistReqResult.strPostProcessActionInfoSeq.length()", iCnt);
                if (0 == CIMFWStrCmp (strPostProcessActionRegistReqResult.strPostProcessActionInfoSeq[iCnt].postProcID, SP_PostProcess_ActionID_RunWaferInfoUpdate))
                {
                    PPT_METHODTRACE_V1("", "RunWaferInfoUpdate exists = ");
                    strPostProcessAdditionalInfoSeq[0].dKey  = strPostProcessActionRegistReqResult.strPostProcessActionInfoSeq[iCnt].dKey;
                    strPostProcessAdditionalInfoSeq[0].seqNo = strPostProcessActionRegistReqResult.strPostProcessActionInfoSeq[iCnt].seqNo;
                    strPostProcessAdditionalInfoSeq[0].name  = SP_ThreadSpecificData_Key_OpeStartCnt;
                    strPostProcessAdditionalInfoSeq[0].value = CIMFWStrDup("1");
                    additionalInfoFlag = TRUE;
                    break;
                }
            }

            if ( TRUE == additionalInfoFlag )
            {
                PPT_METHODTRACE_V1("", "additionalInfoFlag is TRUE");
                pptPostProcessActionUpdateReqResult__100 strPostProcessActionUpdateReqResult;
                try
                {
                    rc = theCS_PPTManager->txPostProcessActionUpdateReq__130( strPostProcessActionUpdateReqResult,
                                                                              strObjCommonIn,
                                                                              SP_PostProcessActionInfo_AddAdditionalInfo,
                                                                              strPostProcessActionRegistReqResult.strPostProcessActionInfoSeq,
                                                                              strPostProcessAdditionalInfoSeq,
                                                                              claimMemo );
                }
                CATCH_TX_TIMEOUT_EXCEPTIONS(txPostProcessActionUpdateReq__130);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "Update of Post Process:rc != RC_OK");
                    retVal->strResult = strPostProcessActionUpdateReqResult.strResult;
                }
            }
        }
    }

    if ( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_txDurableOperationStartCancelForInternalBufferReq() == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txDurableOperationStartCancelForInternalBufferReq);

        //Post Process Execution
        pptPostProcessExecReqResult__100_var result;
        result = TxPostProcessExecReq__100( requestUserID, strPostProcessActionRegistReqResult.dKey, 1, 0, NULL, "" );

        rc = atoi( result->strResult.returnCode );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "TxPostProcessExecReq__100() != RC_OK", rc);
            retVal->strResult = result->strResult;                      //Error Message
        }
        else
        {
            PPT_METHODTRACE_V1("", "TxPostProcessExecReq__100() == RC_OK");
        }
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txDurableOperationStartCancelForInternalBufferReq() != RC_OK", rc);
        TX_ROLLBACK(cs_txDurableOperationStartCancelForInternalBufferReq);
    }

    //-----------------------------------------------------------------------
    //   Post Process
    //-----------------------------------------------------------------------
    retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );

    try
    {
        PPT_METHODTRACE_V1("", "Call clearThreadSpecificDataString");
//        clearThreadSpecificDataString();
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(clearThreadSpecificDataString);

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_TxDurableOperationStartCancelForInternalBufferReq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
