#ifndef lint
static char *sccsid =  "@(#) 1.1 /superpos/src/csppt/source/posppt/svcmgr/txmethods/CS_TxCassetteInspectionTimeResetReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:51:36 [ 7/13/07 21:51:36 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: CS_TxCassetteInspectionTimeResetReq.cpp
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"          
#include "spfunc.hpp"  
#include "ppteventlog.hpp"     
// Class: PPTServiceManager
//
// Service: CS_TxCassetteInspectionTimeResetReq()
//
// Change history:
// Date       Defect#       Person          Comments
// ---------- --------      --------------  -------------------------------------------
// 2017/08/31 INN-R170003   Helios Zhen     Durable Management Enhancement

// Description:
//<Method Summary>

//</Method Summary>

//<MRM>

//</MRM>
//
// Return:
//     csCassetteInspectionTimeResetReqResult
//
// Parameter:
//
//     const pptUser& requestUserID
//     const objectIdentifier& cassetteID
//	   const char *            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>

//</Sample Code>
//
//<Method Start>

#define	 TRANSACTION_ID "CSPDC001"
csCassetteInspectionTimeResetReqResult* CS_PPTServiceManager_i:: CS_TxCassetteInspectionTimeResetReq (
    const pptUser&               requestUserID, //<i>R/Request User ID 
    const objectIdentifier&      cassetteID,  //<i>R/cassetteID
    const char*                  claimMemo //<i>O/Claim Memo
    CORBAENV_LAST_CPP)                     //<i>O/IT Environment        
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);   
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxCassetteInspectionTimeResetReq ");
    CS_PPT_PARMTRACE_VERBOSE3(requestUserID,cassetteID,claimMemo); 
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
	csCassetteInspectionTimeResetReqResult* retVal = new csCassetteInspectionTimeResetReqResult;
	pptEventParameterSequence strEventParameter ;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn strObjCommonIn ;
    
    CORBA::Long rc = 0 ;
    
    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                       strObjCommonIn.strTimeStamp.reportTimeStamp;

    CORBA::Long     nLen = strEventParameter.length() ;
    strEventParameter.length( nLen + 1 ) ;
    strEventParameter[nLen].parameterName = CIMFWStrDup("CAST_ID") ;
    strEventParameter[nLen].parameterValue =  CIMFWStrDup( cassetteID.identifier ) ;
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CREATE_TX_OBJ

    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID) ;  
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() rc != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,dummy,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs); 
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() rc != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)   

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/

    TX_BEGIN(cs_txCassetteInspectionTimeResetReq)

    try
    {
        rc = theCS_PPTManager->cs_txCassetteInspectionTimeResetReq(*retVal, strObjCommonIn, cassetteID, claimMemo) ;
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txCassetteInspectionTimeResetReq)
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_txCassetteInspectionTimeResetReq() rc == RC_OK", rc);
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txCassetteInspectionTimeResetReq);
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txCassetteInspectionTimeResetReq() rc != RC_OK", rc);
        TX_ROLLBACK(cs_txCassetteInspectionTimeResetReq);
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal;
    }


    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;


    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: CS_TxCassetteInspectionTimeResetReq ");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);    
    return retVal ;
}