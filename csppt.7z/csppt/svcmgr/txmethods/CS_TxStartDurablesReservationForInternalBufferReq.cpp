//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : CS_TxStartDurablesReservationForInternalBufferReq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"

#define TRANSACTION_ID "CSPDC006"
csStartDurablesReservationForInternalBufferReqResult* CS_PPTServiceManager_i::CS_TxStartDurablesReservationForInternalBufferReq
(
    const pptUser&                                                  requestUserID,                                          //<i>R/Request User ID
    const csStartDurablesReservationForInternalBufferReqInParam&    strStartDurablesReservationForInternalBufferReqInParam, //<i>R/In Parameters
    const char*                                                     claimMemo                                               //<i>R/Claim Memo
    CORBAENV_LAST_CPP                                                                                                       //<i>O/IT Environment
)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_TxStartDurablesReservationForInternalBufferReq");
    CS_PPT_PARMTRACE_VERBOSE3(requestUserID, strStartDurablesReservationForInternalBufferReqInParam, claimMemo);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csStartDurablesReservationForInternalBufferReqResult* retVal = new csStartDurablesReservationForInternalBufferReqResult;

    pptEventParameterSequence         strEventParameter;
    objCalendar_GetCurrentTimeDR_out  strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn                    strObjCommonIn;
    CORBA::Long                       rc = 0;

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID    = CIMFWStrDup( TRANSACTION_ID );
    strObjCommonIn.strUser          = requestUserID;

    retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );

    //---------------------------------------------
    // Set time stamp.
    //---------------------------------------------
    strObjCommonIn.strTimeStamp.reportTimeStamp                   = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    //---------------------------------------------
    // Put Incoming Log.
    //---------------------------------------------
    CORBA::ULong nLen = strEventParameter.length();
    strEventParameter.length(nLen + 1);
    strEventParameter[nLen].parameterName  = CIMFWStrDup("EQP_ID");
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strStartDurablesReservationForInternalBufferReqInParam.equipmentID.identifier );
    CORBA::ULong durableLen = strStartDurablesReservationForInternalBufferReqInParam.strStartDurables.length();
    PPT_METHODTRACE_V2("", "durableLen", durableLen);

    if ( durableLen > 0 )
    {
        PPT_METHODTRACE_V1("", "durableLen > 0");
        for ( CORBA::ULong durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "Collected Durable ID", strStartDurablesReservationForInternalBufferReqInParam.strStartDurables[durableCnt].durableID.identifier);
            nLen = strEventParameter.length();
            strEventParameter.length(nLen + 3);
            strEventParameter[nLen].parameterName    = CIMFWStrDup("LOAD_PORT_ID");
            strEventParameter[nLen++].parameterValue = CIMFWStrDup( strStartDurablesReservationForInternalBufferReqInParam.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier );
            strEventParameter[nLen].parameterName    = CIMFWStrDup("UNLOAD_PORT_ID");
            strEventParameter[nLen++].parameterValue = CIMFWStrDup( strStartDurablesReservationForInternalBufferReqInParam.strStartDurables[durableCnt].strStartDurablePort.unloadPortID.identifier );
            strEventParameter[nLen].parameterName    = CIMFWStrDup("DURABLE_ID");
            strEventParameter[nLen].parameterValue   = CIMFWStrDup( strStartDurablesReservationForInternalBufferReqInParam.strStartDurables[durableCnt].durableID.identifier );
        }
    }
    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);

    CREATE_TX_OBJ;

    //---------------------------------------------
    // Get calendar
    //---------------------------------------------
    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR( strCalendar_GetCurrentTimeDR_out, strObjCommonIn );
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        strObjCommonIn.strUser.functionID = CIMFWStrDup( TRANSACTION_ID );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult               = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //---------------------------------------------
    // Check privilege
    //---------------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummyID;
    dummyID.identifier = CIMFWStrDup("");
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,
                                                    strObjCommonIn,
                                                    strStartDurablesReservationForInternalBufferReqInParam.equipmentID, //equipmentID
                                                    dummyID,                                                            //stockerID
                                                    dummyIDs,                                                           //productIDs
                                                    dummyIDs,                                                           //routeIDs
                                                    dummyIDs,                                                           //lotIDs
                                                    dummyIDs );                                                         //machineRecipeIDs
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult               = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(cs_txStartDurablesReservationForInternalBufferReq);
    try
    {
        rc = theCS_PPTManager->cs_txStartDurablesReservationForInternalBufferReq( *retVal,
                                                                                  strObjCommonIn,
                                                                                  strStartDurablesReservationForInternalBufferReqInParam,
                                                                                  claimMemo );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txStartDurablesReservationForInternalBufferReq);

    if ( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_txStartDurablesReservationForInternalBufferReq() == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txStartDurablesReservationForInternalBufferReq);
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txStartDurablesReservationForInternalBufferReq() != RC_OK", rc);
        TX_ROLLBACK(cs_txStartDurablesReservationForInternalBufferReq);
    }

    //-----------------------------------------------------------------------
    //   Post Process
    //-----------------------------------------------------------------------
    retVal->strResult.transactionID = CIMFWStrDup( TRANSACTION_ID );

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_TxStartDurablesReservationForInternalBufferReq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
