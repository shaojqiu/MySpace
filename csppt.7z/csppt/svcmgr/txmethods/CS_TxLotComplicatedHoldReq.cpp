//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: CS_TxLotComplicatedHoldReq.cpp
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"

// Class: CS_PPTServiceManager
//
// Service: CS_TxLotComplicatedHoldReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/12 INN-R170009  Nick Tsai      add lot hold for external system
//
// Description:
//
//
// Return:
//     csLotComplicatedHoldReqResult
//
// Parameter:
//
//    const pptUser&                            requestUserID,
//    const csLotComplicatedHoldReqInParam&     strLotComplicatedHoldReqInParam
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//<Method Start>
#define TRANSACTION_ID "CSTRC003"
csLotComplicatedHoldReqResult* CS_PPTServiceManager_i:: CS_TxLotComplicatedHoldReq (
    const pptUser&                          requestUserID,
    const csLotComplicatedHoldReqInParam&   strLotComplicatedHoldReqInParam
    CORBAENV_LAST_CPP
)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxLotComplicatedHoldReq ");
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID, strLotComplicatedHoldReqInParam);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csLotComplicatedHoldReqResult* retVal = new csLotComplicatedHoldReqResult;
    pptEventParameterSequence           strEventParameter;
    objCalendar_GetCurrentTimeDR_out    strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn                      strObjCommonIn;
    CORBA::Long                         rc = 0;

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID);
    strObjCommonIn.strUser = requestUserID;

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);

    //---------------------------------------------
    // Set time stamp.
    //---------------------------------------------
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    //---------------------------------------------
    // Put Incoming Log.
    //---------------------------------------------
    CORBA::Long lLotLen = strLotComplicatedHoldReqInParam.lotIDs.length();
    if( lLotLen > 0 )
    {
        CORBA::Boolean firstCondition = TRUE;
        CORBA::Long lLotStrLen = 0;
        for( CORBA::Long lLotIdx = 0; lLotIdx < lLotLen; lLotIdx ++ )
        {
            if( firstCondition )
            {
                lLotStrLen += CIMFWStrLen( strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier );
                firstCondition = FALSE;
            }
            else
            {
                lLotStrLen += CIMFWStrLen( strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier) + 1;
            }
        }

        firstCondition = TRUE;
        char* pLotIDs = CORBA::string_alloc( (CORBA::ULong) lLotStrLen + 1 );
        pLotIDs[0] = NULL;

        for( lLotIdx = 0; lLotIdx < lLotLen; lLotIdx ++ )
        {
            if( firstCondition )
            {
                CIMFWStrCat( pLotIDs, (const char *)strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier );
                firstCondition = FALSE;
            }
            else
            {
                CIMFWStrCat( pLotIDs, "," );
                CIMFWStrCat( pLotIDs, (const char *)strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier );
            }
        }

        CORBA::ULong nLen = strEventParameter.length();
        strEventParameter.length(nLen + 1);
        strEventParameter[nLen].parameterName  = CIMFWStrDup("LOT_IDS");
        strEventParameter[nLen].parameterValue = pLotIDs;
    }

    CORBA::ULong nLen = strEventParameter.length();
    strEventParameter.length(nLen + 7);
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("REASON_CODE");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strLotComplicatedHoldReqInParam.reasonCode.identifier);
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ACTION");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strLotComplicatedHoldReqInParam.action);
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("RELATED_LOT_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strLotComplicatedHoldReqInParam.relatedLotID.identifier);
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("FUTURE_HOLD_ROUTE_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strLotComplicatedHoldReqInParam.strFutureHoldInfo.routeID.identifier);
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("FUTURE_HOLD_OPENO");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strLotComplicatedHoldReqInParam.strFutureHoldInfo.operationNumber);
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("FUTURE_HOLD_POST_FLAG");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup(strLotComplicatedHoldReqInParam.strFutureHoldInfo.postFlag? "TRUE":"FALSE");
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("FUTURE_HOLD_SINGLE_TRIGGER");
    strEventParameter[nLen  ].parameterValue = CIMFWStrDup(strLotComplicatedHoldReqInParam.strFutureHoldInfo.singleTriggerFlag? "TRUE":"FALSE");

    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);

    CREATE_TX_OBJ;

    //---------------------------------------------
    // Get calendar
    //---------------------------------------------
    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn);
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        if( CIMFWStrLen(strObjCommonIn.strUser.functionID) == 0 )
        {
            strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID);
        }
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);

        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //---------------------------------------------
    // Check privilege
    //---------------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,
                                                   strObjCommonIn,
                                                   dummy,
                                                   dummy,
                                                   dummyIDs,
                                                   dummyIDs,
                                                   strLotComplicatedHoldReqInParam.lotIDs,
                                                   dummyIDs);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(cs_txLotComplicatedHoldReq);

    try
    {
        rc = theCS_PPTManager->cs_txLotComplicatedHoldReq(*retVal, strObjCommonIn, strLotComplicatedHoldReqInParam);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txLotComplicatedHoldReq);

    if(rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "cs_txLotComplicatedHoldReq() rc == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txLotComplicatedHoldReq);
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txLotComplicatedHoldReq() rc != RC_OK", rc);
        TX_ROLLBACK(cs_txLotComplicatedHoldReq);
    }

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: CS_TxLotComplicatedHoldReq ");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
