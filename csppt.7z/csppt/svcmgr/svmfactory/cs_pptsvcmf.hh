//----------------------------------------------------------------------------
//
//  Generated from cs_pptsvcmf.idl
//  On Tuesday, November 14, 2017 11:54:36 AM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_pptsvcmf_server_defined
#ifndef _cs_pptsvcmf_hh_included
#define _cs_pptsvcmf_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif
#ifndef _DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT
#define _DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT 
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_PPTSMOF 
#define CS_PPTSMOF 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _pptsvcmf_hh_included
#include <pptsvcmf.hh>
#endif
#else
#ifndef _pptsvcmf_hh_included
#include "pptsvcmf.hh"
#endif
#endif

// Begin mapping for interface ::CS_PPTServiceManagerObjectFactory

#ifndef _DCL_CS_PPTServiceManagerObjectFactory
#define _DCL_CS_PPTServiceManagerObjectFactory
#ifndef _DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT
#define _DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT 
#endif
class _DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT
   CS_PPTServiceManagerObjectFactory
    ;
class _DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTServiceManagerObjectFactory_var;
typedef CS_PPTServiceManagerObjectFactory* CS_PPTServiceManagerObjectFactory_ptr;
typedef CS_PPTServiceManagerObjectFactory* CS_PPTServiceManagerObjectFactoryRef;

_DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT CORBA::Object_ptr SOMLINK CS_PPTServiceManagerObjectFactory_getBase(void *);

_DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTServiceManagerObjectFactory_ptr SOMLINK CS_PPTServiceManagerObjectFactory_aux_duplicate(CS_PPTServiceManagerObjectFactory_ptr);
_DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTServiceManagerObjectFactory_ptr SOMLINK CS_PPTServiceManagerObjectFactory_aux_narrow(::CORBA::Object_ptr);
_DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTServiceManagerObjectFactory_ptr SOMLINK CS_PPTServiceManagerObjectFactory_aux_nil();
_DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT const char* SOMLINK CS_PPTServiceManagerObjectFactory_aux_CN();

    class _DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTServiceManagerObjectFactory_StructElem
    {
        public:

        CS_PPTServiceManagerObjectFactory_StructElem ();

        CS_PPTServiceManagerObjectFactory_StructElem (const CS_PPTServiceManagerObjectFactory_StructElem &s);

        CS_PPTServiceManagerObjectFactory_StructElem &operator= (CS_PPTServiceManagerObjectFactory_ptr p);

        CS_PPTServiceManagerObjectFactory_StructElem &operator= (CS_PPTServiceManagerObjectFactory_var v);

        CS_PPTServiceManagerObjectFactory_StructElem &operator= (const CS_PPTServiceManagerObjectFactory_StructElem &s);

        ~CS_PPTServiceManagerObjectFactory_StructElem ();

        operator ::CORBA::Object_ptr() const;

        operator CS_PPTServiceManagerObjectFactory_ptr () const;

        CS_PPTServiceManagerObjectFactory_ptr _ptr;

    }; // CS_PPTServiceManagerObjectFactory_StructElem

    class _DCL_CS_PPTServiceManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTServiceManagerObjectFactory_SeqElem
    {
       public:

       CS_PPTServiceManagerObjectFactory_SeqElem (CS_PPTServiceManagerObjectFactory_ptr* p, unsigned char rel);

       CS_PPTServiceManagerObjectFactory_SeqElem &operator= (CS_PPTServiceManagerObjectFactory_ptr p);

        CS_PPTServiceManagerObjectFactory_SeqElem &operator= (CS_PPTServiceManagerObjectFactory_var v);

       CS_PPTServiceManagerObjectFactory_SeqElem &operator= (const CS_PPTServiceManagerObjectFactory_SeqElem &s);

       operator CS_PPTServiceManagerObjectFactory_ptr () const;

       CS_PPTServiceManagerObjectFactory_ptr operator->() const;

       protected:
       CS_PPTServiceManagerObjectFactory_ptr *_ptr;
       unsigned char _release;
   }; // CS_PPTServiceManagerObjectFactory_SeqElem


class  CS_PPTServiceManagerObjectFactory_var : public ::CORBA::__vb__
{
    public:

    CS_PPTServiceManagerObjectFactory_var ();
    CS_PPTServiceManagerObjectFactory_var (CS_PPTServiceManagerObjectFactory *p);
    CS_PPTServiceManagerObjectFactory_var (const CS_PPTServiceManagerObjectFactory_var &s);
    CS_PPTServiceManagerObjectFactory_var (const CS_PPTServiceManagerObjectFactory_StructElem &s);
    CS_PPTServiceManagerObjectFactory_var (const CS_PPTServiceManagerObjectFactory_SeqElem &s);
    CS_PPTServiceManagerObjectFactory_var &operator= (CS_PPTServiceManagerObjectFactory *p);
    CS_PPTServiceManagerObjectFactory_var &operator= (const CS_PPTServiceManagerObjectFactory_var &s);
    CS_PPTServiceManagerObjectFactory_var &operator= (const CS_PPTServiceManagerObjectFactory_StructElem &s);
    CS_PPTServiceManagerObjectFactory_var &operator= (const CS_PPTServiceManagerObjectFactory_SeqElem &s);
    ~CS_PPTServiceManagerObjectFactory_var ();
    CS_PPTServiceManagerObjectFactory_ptr in() const;
    CS_PPTServiceManagerObjectFactory_ptr& inout();
    CS_PPTServiceManagerObjectFactory_ptr& out();
    CS_PPTServiceManagerObjectFactory_ptr _retn();
    CS_PPTServiceManagerObjectFactory_ptr operator-> ();
    operator CS_PPTServiceManagerObjectFactory_ptr& ();
    operator const CS_PPTServiceManagerObjectFactory_ptr& () const;
#ifdef __sun
    operator CS_PPTServiceManagerObjectFactory_ptr () { return _ptr; };
#endif

    protected:
       CS_PPTServiceManagerObjectFactory *_ptr;

    private:
       ::CORBA::__vb__& operator= (::CORBA::__vb__&);

};  // CS_PPTServiceManagerObjectFactory_var

#endif /* _DCL_CS_PPTServiceManagerObjectFactory */ 


class 

   CS_PPTServiceManagerObjectFactory
: virtual public ::PPTServiceManagerObjectFactory {

public: 
    static const char* CS_PPTServiceManagerObjectFactory_CN;
    static const char* CS_PPTServiceManagerObjectFactory_RID;
    typedef CS_PPTServiceManagerObjectFactory_ptr _ptr_type;
    typedef CS_PPTServiceManagerObjectFactory_var _var_type;

    /* for Orbix compatibility */
    virtual void *_deref();

protected: 
    /* constructor */

   CS_PPTServiceManagerObjectFactory
();
protected: 
    virtual ~

   CS_PPTServiceManagerObjectFactory
();
private: 

   CS_PPTServiceManagerObjectFactory
    (const 
   CS_PPTServiceManagerObjectFactory
     &); // unimplemented

    void operator=(const 
   CS_PPTServiceManagerObjectFactory
     &); // unimplemented
public: 

    static CS_PPTServiceManagerObjectFactory_ptr SOMLINK _duplicate(CS_PPTServiceManagerObjectFactory_ptr obj);

    static CS_PPTServiceManagerObjectFactory_ptr SOMLINK _narrow (::CORBA::Object_ptr);

    virtual void* _has_ancestor(const char* classname);
    static CS_PPTServiceManagerObjectFactory_ptr SOMLINK _nil ();

    CS_PPTServiceManagerObjectFactory_ptr _self();
    CS_PPTServiceManagerObjectFactory_ptr _this();
    virtual void *_SOMThis(const char *& ifname);


    virtual  ::CORBA::Void  CS_PPTServiceManagerObjectFactory_init (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Void  _req_CS_PPTServiceManagerObjectFactory_init (::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Void  CS_PPTServiceManagerObjectFactory_uninit (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Void  _req_CS_PPTServiceManagerObjectFactory_uninit (::CORBA::Request &_req, ::CORBA::Environment &env);

public:

}; // end nesting scope for interface class ::CS_PPTServiceManagerObjectFactory

#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif

class  CS_PPTServiceManagerObjectFactory_ORBProxy : virtual public 

   CS_PPTServiceManagerObjectFactory
, virtual public ::PPTServiceManagerObjectFactory_ORBProxy {

public: 
    CS_PPTServiceManagerObjectFactory_ORBProxy ();

    virtual  ::CORBA::Void  CS_PPTServiceManagerObjectFactory_init (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Void  CS_PPTServiceManagerObjectFactory_uninit (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

}; /* end of ::CS_PPTServiceManagerObjectFactory_ORBProxy*/
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
class  CS_PPTServiceManagerObjectFactoryProxyFactory : virtual public ::PPTServiceManagerObjectFactoryProxyFactory {

public:
   CS_PPTServiceManagerObjectFactoryProxyFactory (::CORBA::Boolean is_default = 0);

   virtual ::CORBA::Object_ptr create_proxy (const char* classname);
   virtual ::CORBA::Object_ptr asObject(void *obj);
}; // CS_PPTServiceManagerObjectFactoryProxyFactory


class  CS_PPTServiceManagerObjectFactory_Dispatcher : virtual public ::PPTServiceManagerObjectFactory_Dispatcher {

  public:

   CS_PPTServiceManagerObjectFactory_Dispatcher (::CORBA::Object_ptr target);

   CS_PPTServiceManagerObjectFactory_Dispatcher (); 

   virtual ::CORBA::Boolean dispatch (::CORBA::Request &request);
#ifdef _MSC_VER
   ::CORBA::Boolean __CS_PPTServiceManagerObjectFactory__dispatch(::CORBA::Request &_req);
#endif // _MSC_VER
}; // CS_PPTServiceManagerObjectFactory_Dispatcher
#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
class  CS_PPTServiceManagerObjectFactoryBOAImpl : virtual public 

   CS_PPTServiceManagerObjectFactory
, virtual public ::CORBA::Object_ORBProxy { 
   public:
     CS_PPTServiceManagerObjectFactoryBOAImpl() ;

     virtual ~CS_PPTServiceManagerObjectFactoryBOAImpl();
     CS_PPTServiceManagerObjectFactoryBOAImpl &operator= (const CS_PPTServiceManagerObjectFactoryBOAImpl &s);
     CS_PPTServiceManagerObjectFactoryBOAImpl (const CS_PPTServiceManagerObjectFactoryBOAImpl &s);
};  // CS_PPTServiceManagerObjectFactoryBOAImpl

    extern  ::CORBA::TypeCode_ptr _tc_CS_PPTServiceManagerObjectFactory;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_pptsvcmf_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_pptsvcmf_ANYOPERATOR__
#undef __NOTUSE_cs_pptsvcmf_ANYOPERATOR__
#endif //__USE_cs_pptsvcmf_ANYOPERATOR__
#ifndef __NOTUSE_cs_pptsvcmf_ANYOPERATOR__
#define _DCL_ANYOPS_CS_PPTServiceManagerObjectFactory
#endif //__NOTUSE_cs_pptsvcmf_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_CS_PPTServiceManagerObjectFactory
#ifndef __NOTUSE_ANYOPERATOR_INTERFACE__
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_PPTServiceManagerObjectFactory_ptr _data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_PPTServiceManagerObjectFactory_ptr *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_PPTServiceManagerObjectFactory_ptr& _data);
#endif
#endif //__NOTUSE_ANYOPERATOR_INTERFACE__
#endif // _DCL_ANYOPS_CS_PPTServiceManagerObjectFactory

#endif /* _cs_pptsvcmf_hh_included */

#endif /* _cs_pptsvcmf_server_defined */
