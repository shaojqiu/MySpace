// @(#) 1.3 superpos/src/csppt/source/posppt/svcmgr/svmfactory/cs_pptsvcmf.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:09:11 [ 6/9/03 14:09:12 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// File : cs_pptsvcmf.hpp
// Description : Definition of Customized PPT ServiceManagerObjectFactory
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
//
// Modeficaiton History:
// Date       Defect   Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami      BOAImpl was added in order to make it TIE to BOA.
//                                     eBrokerMigration.
//

#ifndef cs_pptsvcmf_ih
#define cs_pptsvcmf_ih


#include "pptsvcmf.hpp"
#include "cs_pptsvcmf.hh"

#ifdef MO_BOA   //D6000025
class CS_PPTServiceManagerObjectFactory_i : public virtual PPTServiceManagerObjectFactory_i, virtual public CS_PPTServiceManagerObjectFactoryBOAImpl  //D6000025
#else    //D6000025
class CS_PPTServiceManagerObjectFactory_i : public virtual PPTServiceManagerObjectFactory_i
#endif   //D6000025
{
public:
                CS_PPTServiceManagerObjectFactory_i();
                virtual ~CS_PPTServiceManagerObjectFactory_i();
//D6000025                virtual void CS_PPTServiceManagerObjectFactory_init (CORBA::Environment &IT_env = CORBA::default_environment) ;
                virtual void CS_PPTServiceManagerObjectFactory_init (CORBAENV_ONLY_HPP) ; //D6000025
//D6000025                virtual void CS_PPTServiceManagerObjectFactory_uninit (CORBA::Environment &IT_env = CORBA::default_environment) ;
                virtual void CS_PPTServiceManagerObjectFactory_uninit (CORBAENV_ONLY_HPP) ;  //D6000025

public:
//D6000025                virtual PPTServiceManager_ptr createPPTServiceManager (CORBA::Environment &IT_env=CORBA::default_environment) ;
                virtual PPTServiceManager_ptr createPPTServiceManager (CORBAENV_ONLY_HPP) ; //D6000025
    };

#ifndef MO_BOA   //D6000025
DEF_TIE_CS_PPTServiceManagerObjectFactory(CS_PPTServiceManagerObjectFactory_i);
#endif           //D6000025


#endif

