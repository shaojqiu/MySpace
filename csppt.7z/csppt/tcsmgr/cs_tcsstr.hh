//----------------------------------------------------------------------------
//
//  Generated from cs_tcsstr.idl
//  On Tuesday, November 14, 2017 11:54:53 AM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_tcsstr_server_defined
#ifndef _cs_tcsstr_hh_included
#define _cs_tcsstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_TCSSTR_IDL 
#define CS_TCSSTR_IDL 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
    class  tcsRecipe_struct_var;
    struct  tcsRecipe_struct {
        typedef tcsRecipe_struct_var _var_type;
       ::objectIdentifier machineRecipeID;
       ::CORBA::String_StructElem physicalRecipeID;
       ::CORBA::Boolean mainRecipeFlag;
       ::CORBA::String_StructElem recipeFileName;
       ::CORBA::String_StructElem type;
       ::CORBA::String_StructElem recipeLevel;
       ::CORBA::String_StructElem option;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       tcsRecipe_struct();
       tcsRecipe_struct(const tcsRecipe_struct&);
       tcsRecipe_struct& operator=(const tcsRecipe_struct&);
       static CORBA::Info<tcsRecipe_struct> tcsRecipe_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct tcsRecipe_struct


typedef tcsRecipe_struct* tcsRecipe_struct_vPtr;
typedef const tcsRecipe_struct* tcsRecipe_struct_cvPtr;

class  tcsRecipe_struct_var
{
    public:

    tcsRecipe_struct_var ();

    tcsRecipe_struct_var (tcsRecipe_struct *_p);

    tcsRecipe_struct_var (const tcsRecipe_struct_var &_s);

    tcsRecipe_struct_var &operator= (tcsRecipe_struct *_p);

    tcsRecipe_struct_var &operator= (const tcsRecipe_struct_var &_s);

    ~tcsRecipe_struct_var ();

    tcsRecipe_struct* operator-> ();

    const tcsRecipe_struct& in() const;
    tcsRecipe_struct& inout();
    tcsRecipe_struct*& out();
    tcsRecipe_struct* _retn();

    operator tcsRecipe_struct_cvPtr () const;

    operator tcsRecipe_struct_vPtr& ();

    operator const tcsRecipe_struct& () const;

    operator tcsRecipe_struct& ();

    protected:
    tcsRecipe_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_tcsRecipe_struct;
    typedef tcsRecipe_struct tcsRecipe;
    typedef tcsRecipe_struct_var tcsRecipe_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsRecipe;
class  _IDL_SEQ_tcsRecipeSequence_0_var;
class  _IDL_SEQ_tcsRecipeSequence_0 {
    public:
        typedef _IDL_SEQ_tcsRecipeSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    tcsRecipe *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_tcsRecipeSequence_0 ();
    _IDL_SEQ_tcsRecipeSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_tcsRecipeSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, tcsRecipe* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_tcsRecipeSequence_0 (const _IDL_SEQ_tcsRecipeSequence_0&);

    ~_IDL_SEQ_tcsRecipeSequence_0 ();

    _IDL_SEQ_tcsRecipeSequence_0& operator= (const _IDL_SEQ_tcsRecipeSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    tcsRecipe& operator [] (::CORBA::ULong indx);
    const tcsRecipe& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    tcsRecipe* get_buffer (::CORBA::Boolean orphan=0);
    const tcsRecipe* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, tcsRecipe* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, tcsRecipe* src, tcsRecipe* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, tcsRecipe* data); 
  public:

    static tcsRecipe* SOMLINK allocbuf(::CORBA::ULong nelems);
    static tcsRecipe* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(tcsRecipe* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_tcsRecipeSequence_0> tcsRecipeSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_tcsRecipeSequence_0* _IDL_SEQ_tcsRecipeSequence_0_vPtr;
typedef const _IDL_SEQ_tcsRecipeSequence_0* _IDL_SEQ_tcsRecipeSequence_0_cvPtr;

class  _IDL_SEQ_tcsRecipeSequence_0_var
{
    public:

    _IDL_SEQ_tcsRecipeSequence_0_var ();

    _IDL_SEQ_tcsRecipeSequence_0_var (_IDL_SEQ_tcsRecipeSequence_0 *_p);

    _IDL_SEQ_tcsRecipeSequence_0_var (const _IDL_SEQ_tcsRecipeSequence_0_var &_s);

    _IDL_SEQ_tcsRecipeSequence_0_var &operator= (_IDL_SEQ_tcsRecipeSequence_0 *_p);

    _IDL_SEQ_tcsRecipeSequence_0_var &operator= (const _IDL_SEQ_tcsRecipeSequence_0_var &_s);

    ~_IDL_SEQ_tcsRecipeSequence_0_var ();

    _IDL_SEQ_tcsRecipeSequence_0* operator-> ();

    operator _IDL_SEQ_tcsRecipeSequence_0_cvPtr () const;

    operator _IDL_SEQ_tcsRecipeSequence_0_vPtr& ();

    operator _IDL_SEQ_tcsRecipeSequence_0() const;

    const tcsRecipe& operator[] (::CORBA::ULong index) const;
    tcsRecipe& operator[] (::CORBA::ULong index);
    const tcsRecipe& operator[] (int index) const;
    tcsRecipe& operator[] (int index);
    const _IDL_SEQ_tcsRecipeSequence_0& in() const;
    _IDL_SEQ_tcsRecipeSequence_0& inout();
    _IDL_SEQ_tcsRecipeSequence_0*& out();
    _IDL_SEQ_tcsRecipeSequence_0* _retn();

    protected:
    _IDL_SEQ_tcsRecipeSequence_0 *_ptr;
};

    typedef _IDL_SEQ_tcsRecipeSequence_0 _tcsRecipeSequence_seq;
    typedef _IDL_SEQ_tcsRecipeSequence_0 _tcsRecipeSequence_seq_1;
    typedef _IDL_SEQ_tcsRecipeSequence_0 tcsRecipeSequence;
    typedef _IDL_SEQ_tcsRecipeSequence_0_var tcsRecipeSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsRecipeSequence;
    typedef pptBaseResult tcsRecipeUploadReqResult;
    typedef pptBaseResult_var tcsRecipeUploadReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsRecipeUploadReqResult;
    class  tcsConstantName_struct_var;
    struct  tcsConstantName_struct {
        typedef tcsConstantName_struct_var _var_type;
       ::CORBA::String_StructElem name;
       ::CORBA::String_StructElem value;
       ::CORBA::String_StructElem listPath;
       ::CORBA::String_StructElem maxValue;
       ::CORBA::String_StructElem minValue;
       ::CORBA::String_StructElem defaultValue;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       tcsConstantName_struct();
       tcsConstantName_struct(const tcsConstantName_struct&);
       tcsConstantName_struct& operator=(const tcsConstantName_struct&);
       static CORBA::Info<tcsConstantName_struct> tcsConstantName_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct tcsConstantName_struct


typedef tcsConstantName_struct* tcsConstantName_struct_vPtr;
typedef const tcsConstantName_struct* tcsConstantName_struct_cvPtr;

class  tcsConstantName_struct_var
{
    public:

    tcsConstantName_struct_var ();

    tcsConstantName_struct_var (tcsConstantName_struct *_p);

    tcsConstantName_struct_var (const tcsConstantName_struct_var &_s);

    tcsConstantName_struct_var &operator= (tcsConstantName_struct *_p);

    tcsConstantName_struct_var &operator= (const tcsConstantName_struct_var &_s);

    ~tcsConstantName_struct_var ();

    tcsConstantName_struct* operator-> ();

    const tcsConstantName_struct& in() const;
    tcsConstantName_struct& inout();
    tcsConstantName_struct*& out();
    tcsConstantName_struct* _retn();

    operator tcsConstantName_struct_cvPtr () const;

    operator tcsConstantName_struct_vPtr& ();

    operator const tcsConstantName_struct& () const;

    operator tcsConstantName_struct& ();

    protected:
    tcsConstantName_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_tcsConstantName_struct;
    typedef tcsConstantName_struct tcsConstantName;
    typedef tcsConstantName_struct_var tcsConstantName_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsConstantName;
class  _IDL_SEQ_tcsConstantNameSequence_0_var;
class  _IDL_SEQ_tcsConstantNameSequence_0 {
    public:
        typedef _IDL_SEQ_tcsConstantNameSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    tcsConstantName *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_tcsConstantNameSequence_0 ();
    _IDL_SEQ_tcsConstantNameSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_tcsConstantNameSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, tcsConstantName* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_tcsConstantNameSequence_0 (const _IDL_SEQ_tcsConstantNameSequence_0&);

    ~_IDL_SEQ_tcsConstantNameSequence_0 ();

    _IDL_SEQ_tcsConstantNameSequence_0& operator= (const _IDL_SEQ_tcsConstantNameSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    tcsConstantName& operator [] (::CORBA::ULong indx);
    const tcsConstantName& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    tcsConstantName* get_buffer (::CORBA::Boolean orphan=0);
    const tcsConstantName* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, tcsConstantName* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, tcsConstantName* src, tcsConstantName* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, tcsConstantName* data); 
  public:

    static tcsConstantName* SOMLINK allocbuf(::CORBA::ULong nelems);
    static tcsConstantName* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(tcsConstantName* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_tcsConstantNameSequence_0> tcsConstantNameSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_tcsConstantNameSequence_0* _IDL_SEQ_tcsConstantNameSequence_0_vPtr;
typedef const _IDL_SEQ_tcsConstantNameSequence_0* _IDL_SEQ_tcsConstantNameSequence_0_cvPtr;

class  _IDL_SEQ_tcsConstantNameSequence_0_var
{
    public:

    _IDL_SEQ_tcsConstantNameSequence_0_var ();

    _IDL_SEQ_tcsConstantNameSequence_0_var (_IDL_SEQ_tcsConstantNameSequence_0 *_p);

    _IDL_SEQ_tcsConstantNameSequence_0_var (const _IDL_SEQ_tcsConstantNameSequence_0_var &_s);

    _IDL_SEQ_tcsConstantNameSequence_0_var &operator= (_IDL_SEQ_tcsConstantNameSequence_0 *_p);

    _IDL_SEQ_tcsConstantNameSequence_0_var &operator= (const _IDL_SEQ_tcsConstantNameSequence_0_var &_s);

    ~_IDL_SEQ_tcsConstantNameSequence_0_var ();

    _IDL_SEQ_tcsConstantNameSequence_0* operator-> ();

    operator _IDL_SEQ_tcsConstantNameSequence_0_cvPtr () const;

    operator _IDL_SEQ_tcsConstantNameSequence_0_vPtr& ();

    operator _IDL_SEQ_tcsConstantNameSequence_0() const;

    const tcsConstantName& operator[] (::CORBA::ULong index) const;
    tcsConstantName& operator[] (::CORBA::ULong index);
    const tcsConstantName& operator[] (int index) const;
    tcsConstantName& operator[] (int index);
    const _IDL_SEQ_tcsConstantNameSequence_0& in() const;
    _IDL_SEQ_tcsConstantNameSequence_0& inout();
    _IDL_SEQ_tcsConstantNameSequence_0*& out();
    _IDL_SEQ_tcsConstantNameSequence_0* _retn();

    protected:
    _IDL_SEQ_tcsConstantNameSequence_0 *_ptr;
};

    typedef _IDL_SEQ_tcsConstantNameSequence_0 _tcsConstantNameSequence_seq;
    typedef _IDL_SEQ_tcsConstantNameSequence_0 _tcsConstantNameSequence_seq_1;
    typedef _IDL_SEQ_tcsConstantNameSequence_0 tcsConstantNameSequence;
    typedef _IDL_SEQ_tcsConstantNameSequence_0_var tcsConstantNameSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsConstantNameSequence;
    class  tcsEqpConstant_struct_var;
    struct  tcsEqpConstant_struct {
        typedef tcsEqpConstant_struct_var _var_type;
       ::CORBA::String_StructElem constantID;
       ::CORBA::String_StructElem type;
       ::tcsConstantNameSequence constantNames;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       tcsEqpConstant_struct();
       tcsEqpConstant_struct(const tcsEqpConstant_struct&);
       tcsEqpConstant_struct& operator=(const tcsEqpConstant_struct&);
       static CORBA::Info<tcsEqpConstant_struct> tcsEqpConstant_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct tcsEqpConstant_struct


typedef tcsEqpConstant_struct* tcsEqpConstant_struct_vPtr;
typedef const tcsEqpConstant_struct* tcsEqpConstant_struct_cvPtr;

class  tcsEqpConstant_struct_var
{
    public:

    tcsEqpConstant_struct_var ();

    tcsEqpConstant_struct_var (tcsEqpConstant_struct *_p);

    tcsEqpConstant_struct_var (const tcsEqpConstant_struct_var &_s);

    tcsEqpConstant_struct_var &operator= (tcsEqpConstant_struct *_p);

    tcsEqpConstant_struct_var &operator= (const tcsEqpConstant_struct_var &_s);

    ~tcsEqpConstant_struct_var ();

    tcsEqpConstant_struct* operator-> ();

    const tcsEqpConstant_struct& in() const;
    tcsEqpConstant_struct& inout();
    tcsEqpConstant_struct*& out();
    tcsEqpConstant_struct* _retn();

    operator tcsEqpConstant_struct_cvPtr () const;

    operator tcsEqpConstant_struct_vPtr& ();

    operator const tcsEqpConstant_struct& () const;

    operator tcsEqpConstant_struct& ();

    protected:
    tcsEqpConstant_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpConstant_struct;
    typedef tcsEqpConstant_struct tcsEqpConstant;
    typedef tcsEqpConstant_struct_var tcsEqpConstant_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpConstant;
class  _IDL_SEQ_tcsEqpConstantSequence_0_var;
class  _IDL_SEQ_tcsEqpConstantSequence_0 {
    public:
        typedef _IDL_SEQ_tcsEqpConstantSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    tcsEqpConstant *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_tcsEqpConstantSequence_0 ();
    _IDL_SEQ_tcsEqpConstantSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_tcsEqpConstantSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, tcsEqpConstant* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_tcsEqpConstantSequence_0 (const _IDL_SEQ_tcsEqpConstantSequence_0&);

    ~_IDL_SEQ_tcsEqpConstantSequence_0 ();

    _IDL_SEQ_tcsEqpConstantSequence_0& operator= (const _IDL_SEQ_tcsEqpConstantSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    tcsEqpConstant& operator [] (::CORBA::ULong indx);
    const tcsEqpConstant& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    tcsEqpConstant* get_buffer (::CORBA::Boolean orphan=0);
    const tcsEqpConstant* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, tcsEqpConstant* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, tcsEqpConstant* src, tcsEqpConstant* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, tcsEqpConstant* data); 
  public:

    static tcsEqpConstant* SOMLINK allocbuf(::CORBA::ULong nelems);
    static tcsEqpConstant* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(tcsEqpConstant* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_tcsEqpConstantSequence_0> tcsEqpConstantSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_tcsEqpConstantSequence_0* _IDL_SEQ_tcsEqpConstantSequence_0_vPtr;
typedef const _IDL_SEQ_tcsEqpConstantSequence_0* _IDL_SEQ_tcsEqpConstantSequence_0_cvPtr;

class  _IDL_SEQ_tcsEqpConstantSequence_0_var
{
    public:

    _IDL_SEQ_tcsEqpConstantSequence_0_var ();

    _IDL_SEQ_tcsEqpConstantSequence_0_var (_IDL_SEQ_tcsEqpConstantSequence_0 *_p);

    _IDL_SEQ_tcsEqpConstantSequence_0_var (const _IDL_SEQ_tcsEqpConstantSequence_0_var &_s);

    _IDL_SEQ_tcsEqpConstantSequence_0_var &operator= (_IDL_SEQ_tcsEqpConstantSequence_0 *_p);

    _IDL_SEQ_tcsEqpConstantSequence_0_var &operator= (const _IDL_SEQ_tcsEqpConstantSequence_0_var &_s);

    ~_IDL_SEQ_tcsEqpConstantSequence_0_var ();

    _IDL_SEQ_tcsEqpConstantSequence_0* operator-> ();

    operator _IDL_SEQ_tcsEqpConstantSequence_0_cvPtr () const;

    operator _IDL_SEQ_tcsEqpConstantSequence_0_vPtr& ();

    operator _IDL_SEQ_tcsEqpConstantSequence_0() const;

    const tcsEqpConstant& operator[] (::CORBA::ULong index) const;
    tcsEqpConstant& operator[] (::CORBA::ULong index);
    const tcsEqpConstant& operator[] (int index) const;
    tcsEqpConstant& operator[] (int index);
    const _IDL_SEQ_tcsEqpConstantSequence_0& in() const;
    _IDL_SEQ_tcsEqpConstantSequence_0& inout();
    _IDL_SEQ_tcsEqpConstantSequence_0*& out();
    _IDL_SEQ_tcsEqpConstantSequence_0* _retn();

    protected:
    _IDL_SEQ_tcsEqpConstantSequence_0 *_ptr;
};

    typedef _IDL_SEQ_tcsEqpConstantSequence_0 _tcsEqpConstantSequence_seq;
    typedef _IDL_SEQ_tcsEqpConstantSequence_0 _tcsEqpConstantSequence_seq_1;
    typedef _IDL_SEQ_tcsEqpConstantSequence_0 tcsEqpConstantSequence;
    typedef _IDL_SEQ_tcsEqpConstantSequence_0_var tcsEqpConstantSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpConstantSequence;
    class  tcsEqpConstantInqResult_struct_var;
    struct  tcsEqpConstantInqResult_struct {
        typedef tcsEqpConstantInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::tcsEqpConstantSequence ECIDs;
       ::tcsEqpConstantSequence SVIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       tcsEqpConstantInqResult_struct();
       tcsEqpConstantInqResult_struct(const tcsEqpConstantInqResult_struct&);
       tcsEqpConstantInqResult_struct& operator=(const tcsEqpConstantInqResult_struct&);
       static CORBA::Info<tcsEqpConstantInqResult_struct> tcsEqpConstantInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct tcsEqpConstantInqResult_struct


typedef tcsEqpConstantInqResult_struct* tcsEqpConstantInqResult_struct_vPtr;
typedef const tcsEqpConstantInqResult_struct* tcsEqpConstantInqResult_struct_cvPtr;

class  tcsEqpConstantInqResult_struct_var
{
    public:

    tcsEqpConstantInqResult_struct_var ();

    tcsEqpConstantInqResult_struct_var (tcsEqpConstantInqResult_struct *_p);

    tcsEqpConstantInqResult_struct_var (const tcsEqpConstantInqResult_struct_var &_s);

    tcsEqpConstantInqResult_struct_var &operator= (tcsEqpConstantInqResult_struct *_p);

    tcsEqpConstantInqResult_struct_var &operator= (const tcsEqpConstantInqResult_struct_var &_s);

    ~tcsEqpConstantInqResult_struct_var ();

    tcsEqpConstantInqResult_struct* operator-> ();

    const tcsEqpConstantInqResult_struct& in() const;
    tcsEqpConstantInqResult_struct& inout();
    tcsEqpConstantInqResult_struct*& out();
    tcsEqpConstantInqResult_struct* _retn();

    operator tcsEqpConstantInqResult_struct_cvPtr () const;

    operator tcsEqpConstantInqResult_struct_vPtr& ();

    operator const tcsEqpConstantInqResult_struct& () const;

    operator tcsEqpConstantInqResult_struct& ();

    protected:
    tcsEqpConstantInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpConstantInqResult_struct;
    typedef tcsEqpConstantInqResult_struct tcsEqpConstantInqResult;
    typedef tcsEqpConstantInqResult_struct_var tcsEqpConstantInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpConstantInqResult;
    typedef pptBaseResult tcsRecipeDownloadReqResult;
    typedef pptBaseResult_var tcsRecipeDownloadReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsRecipeDownloadReqResult;
    typedef pptOpeCompWithDataReqResult tcsTCSForceCompleteReqResult;
    typedef pptOpeCompWithDataReqResult_var tcsTCSForceCompleteReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsTCSForceCompleteReqResult;
    typedef pptBaseResult tcsTCSStartLotsReservationForSorterReqResult;
    typedef pptBaseResult_var tcsTCSStartLotsReservationForSorterReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsTCSStartLotsReservationForSorterReqResult;
    typedef pptBaseResult tcsTCSStartLotsReservationCancelForSorterReqResult;
    typedef pptBaseResult_var tcsTCSStartLotsReservationCancelForSorterReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsTCSStartLotsReservationCancelForSorterReqResult;
    typedef pptBaseResult tcsFurnaceBoatStatusChangeReqResult;
    typedef pptBaseResult_var tcsFurnaceBoatStatusChangeReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsFurnaceBoatStatusChangeReqResult;
    typedef pptBaseResult tcsChemicalStatusChangeReqResult;
    typedef pptBaseResult_var tcsChemicalStatusChangeReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsChemicalStatusChangeReqResult;
    class  tcsEqpChamberInProcessWaferCount_struct_var;
    struct  tcsEqpChamberInProcessWaferCount_struct {
        typedef tcsEqpChamberInProcessWaferCount_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::objectIdentifier chamberID;
       ::CORBA::Long processedWaferCount;
       ::CORBA::Long notProcessedWaferCount;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       tcsEqpChamberInProcessWaferCount_struct();
       tcsEqpChamberInProcessWaferCount_struct(const tcsEqpChamberInProcessWaferCount_struct&);
       tcsEqpChamberInProcessWaferCount_struct& operator=(const tcsEqpChamberInProcessWaferCount_struct&);
       static CORBA::Info<tcsEqpChamberInProcessWaferCount_struct> tcsEqpChamberInProcessWaferCount_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct tcsEqpChamberInProcessWaferCount_struct


typedef tcsEqpChamberInProcessWaferCount_struct* tcsEqpChamberInProcessWaferCount_struct_vPtr;
typedef const tcsEqpChamberInProcessWaferCount_struct* tcsEqpChamberInProcessWaferCount_struct_cvPtr;

class  tcsEqpChamberInProcessWaferCount_struct_var
{
    public:

    tcsEqpChamberInProcessWaferCount_struct_var ();

    tcsEqpChamberInProcessWaferCount_struct_var (tcsEqpChamberInProcessWaferCount_struct *_p);

    tcsEqpChamberInProcessWaferCount_struct_var (const tcsEqpChamberInProcessWaferCount_struct_var &_s);

    tcsEqpChamberInProcessWaferCount_struct_var &operator= (tcsEqpChamberInProcessWaferCount_struct *_p);

    tcsEqpChamberInProcessWaferCount_struct_var &operator= (const tcsEqpChamberInProcessWaferCount_struct_var &_s);

    ~tcsEqpChamberInProcessWaferCount_struct_var ();

    tcsEqpChamberInProcessWaferCount_struct* operator-> ();

    const tcsEqpChamberInProcessWaferCount_struct& in() const;
    tcsEqpChamberInProcessWaferCount_struct& inout();
    tcsEqpChamberInProcessWaferCount_struct*& out();
    tcsEqpChamberInProcessWaferCount_struct* _retn();

    operator tcsEqpChamberInProcessWaferCount_struct_cvPtr () const;

    operator tcsEqpChamberInProcessWaferCount_struct_vPtr& ();

    operator const tcsEqpChamberInProcessWaferCount_struct& () const;

    operator tcsEqpChamberInProcessWaferCount_struct& ();

    protected:
    tcsEqpChamberInProcessWaferCount_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpChamberInProcessWaferCount_struct;
    typedef tcsEqpChamberInProcessWaferCount_struct tcsEqpChamberInProcessWaferCount;
    typedef tcsEqpChamberInProcessWaferCount_struct_var tcsEqpChamberInProcessWaferCount_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpChamberInProcessWaferCount;
class  _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var;
class  _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 {
    public:
        typedef _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    tcsEqpChamberInProcessWaferCount *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 ();
    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, tcsEqpChamberInProcessWaferCount* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 (const _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0&);

    ~_IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 ();

    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0& operator= (const _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    tcsEqpChamberInProcessWaferCount& operator [] (::CORBA::ULong indx);
    const tcsEqpChamberInProcessWaferCount& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    tcsEqpChamberInProcessWaferCount* get_buffer (::CORBA::Boolean orphan=0);
    const tcsEqpChamberInProcessWaferCount* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, tcsEqpChamberInProcessWaferCount* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, tcsEqpChamberInProcessWaferCount* src, tcsEqpChamberInProcessWaferCount* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, tcsEqpChamberInProcessWaferCount* data); 
  public:

    static tcsEqpChamberInProcessWaferCount* SOMLINK allocbuf(::CORBA::ULong nelems);
    static tcsEqpChamberInProcessWaferCount* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(tcsEqpChamberInProcessWaferCount* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0> tcsEqpChamberInProcessWaferCountSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0* _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_vPtr;
typedef const _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0* _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_cvPtr;

class  _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var
{
    public:

    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var ();

    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var (_IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 *_p);

    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var (const _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var &_s);

    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var &operator= (_IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 *_p);

    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var &operator= (const _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var &_s);

    ~_IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var ();

    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0* operator-> ();

    operator _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_cvPtr () const;

    operator _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_vPtr& ();

    operator _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0() const;

    const tcsEqpChamberInProcessWaferCount& operator[] (::CORBA::ULong index) const;
    tcsEqpChamberInProcessWaferCount& operator[] (::CORBA::ULong index);
    const tcsEqpChamberInProcessWaferCount& operator[] (int index) const;
    tcsEqpChamberInProcessWaferCount& operator[] (int index);
    const _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0& in() const;
    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0& inout();
    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0*& out();
    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0* _retn();

    protected:
    _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 *_ptr;
};

    typedef _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 _tcsEqpChamberInProcessWaferCountSequence_seq;
    typedef _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 _tcsEqpChamberInProcessWaferCountSequence_seq_1;
    typedef _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0 tcsEqpChamberInProcessWaferCountSequence;
    typedef _IDL_SEQ_tcsEqpChamberInProcessWaferCountSequence_0_var tcsEqpChamberInProcessWaferCountSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpChamberInProcessWaferCountSequence;
    class  tcsEqpChamberInProcessWaferCountInqResult_struct_var;
    struct  tcsEqpChamberInProcessWaferCountInqResult_struct {
        typedef tcsEqpChamberInProcessWaferCountInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::tcsEqpChamberInProcessWaferCountSequence strEqpChamberInProcessWaferCountSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       tcsEqpChamberInProcessWaferCountInqResult_struct();
       tcsEqpChamberInProcessWaferCountInqResult_struct(const tcsEqpChamberInProcessWaferCountInqResult_struct&);
       tcsEqpChamberInProcessWaferCountInqResult_struct& operator=(const tcsEqpChamberInProcessWaferCountInqResult_struct&);
       static CORBA::Info<tcsEqpChamberInProcessWaferCountInqResult_struct> tcsEqpChamberInProcessWaferCountInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct tcsEqpChamberInProcessWaferCountInqResult_struct


typedef tcsEqpChamberInProcessWaferCountInqResult_struct* tcsEqpChamberInProcessWaferCountInqResult_struct_vPtr;
typedef const tcsEqpChamberInProcessWaferCountInqResult_struct* tcsEqpChamberInProcessWaferCountInqResult_struct_cvPtr;

class  tcsEqpChamberInProcessWaferCountInqResult_struct_var
{
    public:

    tcsEqpChamberInProcessWaferCountInqResult_struct_var ();

    tcsEqpChamberInProcessWaferCountInqResult_struct_var (tcsEqpChamberInProcessWaferCountInqResult_struct *_p);

    tcsEqpChamberInProcessWaferCountInqResult_struct_var (const tcsEqpChamberInProcessWaferCountInqResult_struct_var &_s);

    tcsEqpChamberInProcessWaferCountInqResult_struct_var &operator= (tcsEqpChamberInProcessWaferCountInqResult_struct *_p);

    tcsEqpChamberInProcessWaferCountInqResult_struct_var &operator= (const tcsEqpChamberInProcessWaferCountInqResult_struct_var &_s);

    ~tcsEqpChamberInProcessWaferCountInqResult_struct_var ();

    tcsEqpChamberInProcessWaferCountInqResult_struct* operator-> ();

    const tcsEqpChamberInProcessWaferCountInqResult_struct& in() const;
    tcsEqpChamberInProcessWaferCountInqResult_struct& inout();
    tcsEqpChamberInProcessWaferCountInqResult_struct*& out();
    tcsEqpChamberInProcessWaferCountInqResult_struct* _retn();

    operator tcsEqpChamberInProcessWaferCountInqResult_struct_cvPtr () const;

    operator tcsEqpChamberInProcessWaferCountInqResult_struct_vPtr& ();

    operator const tcsEqpChamberInProcessWaferCountInqResult_struct& () const;

    operator tcsEqpChamberInProcessWaferCountInqResult_struct& ();

    protected:
    tcsEqpChamberInProcessWaferCountInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpChamberInProcessWaferCountInqResult_struct;
    typedef tcsEqpChamberInProcessWaferCountInqResult_struct tcsEqpChamberInProcessWaferCountInqResult;
    typedef tcsEqpChamberInProcessWaferCountInqResult_struct_var tcsEqpChamberInProcessWaferCountInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsEqpChamberInProcessWaferCountInqResult;
    class  tcsBWSInventoryInqResult_struct_var;
    struct  tcsBWSInventoryInqResult_struct {
        typedef tcsBWSInventoryInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSInventoryInfo strBWSInventoryInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       tcsBWSInventoryInqResult_struct();
       tcsBWSInventoryInqResult_struct(const tcsBWSInventoryInqResult_struct&);
       tcsBWSInventoryInqResult_struct& operator=(const tcsBWSInventoryInqResult_struct&);
       static CORBA::Info<tcsBWSInventoryInqResult_struct> tcsBWSInventoryInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct tcsBWSInventoryInqResult_struct


typedef tcsBWSInventoryInqResult_struct* tcsBWSInventoryInqResult_struct_vPtr;
typedef const tcsBWSInventoryInqResult_struct* tcsBWSInventoryInqResult_struct_cvPtr;

class  tcsBWSInventoryInqResult_struct_var
{
    public:

    tcsBWSInventoryInqResult_struct_var ();

    tcsBWSInventoryInqResult_struct_var (tcsBWSInventoryInqResult_struct *_p);

    tcsBWSInventoryInqResult_struct_var (const tcsBWSInventoryInqResult_struct_var &_s);

    tcsBWSInventoryInqResult_struct_var &operator= (tcsBWSInventoryInqResult_struct *_p);

    tcsBWSInventoryInqResult_struct_var &operator= (const tcsBWSInventoryInqResult_struct_var &_s);

    ~tcsBWSInventoryInqResult_struct_var ();

    tcsBWSInventoryInqResult_struct* operator-> ();

    const tcsBWSInventoryInqResult_struct& in() const;
    tcsBWSInventoryInqResult_struct& inout();
    tcsBWSInventoryInqResult_struct*& out();
    tcsBWSInventoryInqResult_struct* _retn();

    operator tcsBWSInventoryInqResult_struct_cvPtr () const;

    operator tcsBWSInventoryInqResult_struct_vPtr& ();

    operator const tcsBWSInventoryInqResult_struct& () const;

    operator tcsBWSInventoryInqResult_struct& ();

    protected:
    tcsBWSInventoryInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_tcsBWSInventoryInqResult_struct;
    typedef tcsBWSInventoryInqResult_struct tcsBWSInventoryInqResult;
    typedef tcsBWSInventoryInqResult_struct_var tcsBWSInventoryInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_tcsBWSInventoryInqResult;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_tcsstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_tcsstr_ANYOPERATOR__
#undef __NOTUSE_cs_tcsstr_ANYOPERATOR__
#endif //__USE_cs_tcsstr_ANYOPERATOR__
#ifndef __NOTUSE_cs_tcsstr_ANYOPERATOR__
#define _DCL_ANYOPS_tcsRecipe_struct
#define _DCL_ANYOPS_tcsRecipeSequence
#define _DCL_ANYOPS_tcsConstantName_struct
#define _DCL_ANYOPS_tcsConstantNameSequence
#define _DCL_ANYOPS_tcsEqpConstant_struct
#define _DCL_ANYOPS_tcsEqpConstantSequence
#define _DCL_ANYOPS_tcsEqpConstantInqResult_struct
#define _DCL_ANYOPS_tcsEqpChamberInProcessWaferCount_struct
#define _DCL_ANYOPS_tcsEqpChamberInProcessWaferCountSequence
#define _DCL_ANYOPS_tcsEqpChamberInProcessWaferCountInqResult_struct
#define _DCL_ANYOPS_tcsBWSInventoryInqResult_struct
#endif //__NOTUSE_cs_tcsstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_tcsRecipe_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsRecipe_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsRecipe_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsRecipe_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsRecipe_struct*& _data);
#endif
#endif // _DCL_ANYOPS_tcsRecipe_struct
#ifdef _DCL_ANYOPS_tcsRecipeSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsRecipeSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsRecipeSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsRecipeSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsRecipeSequence*& _data);
#endif
#endif // _DCL_ANYOPS_tcsRecipeSequence
#ifdef _DCL_ANYOPS_tcsConstantName_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsConstantName_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsConstantName_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsConstantName_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsConstantName_struct*& _data);
#endif
#endif // _DCL_ANYOPS_tcsConstantName_struct
#ifdef _DCL_ANYOPS_tcsConstantNameSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsConstantNameSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsConstantNameSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsConstantNameSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsConstantNameSequence*& _data);
#endif
#endif // _DCL_ANYOPS_tcsConstantNameSequence
#ifdef _DCL_ANYOPS_tcsEqpConstant_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsEqpConstant_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsEqpConstant_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsEqpConstant_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsEqpConstant_struct*& _data);
#endif
#endif // _DCL_ANYOPS_tcsEqpConstant_struct
#ifdef _DCL_ANYOPS_tcsEqpConstantSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsEqpConstantSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsEqpConstantSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsEqpConstantSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsEqpConstantSequence*& _data);
#endif
#endif // _DCL_ANYOPS_tcsEqpConstantSequence
#ifdef _DCL_ANYOPS_tcsEqpConstantInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsEqpConstantInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsEqpConstantInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsEqpConstantInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsEqpConstantInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_tcsEqpConstantInqResult_struct
#ifdef _DCL_ANYOPS_tcsEqpChamberInProcessWaferCount_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsEqpChamberInProcessWaferCount_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsEqpChamberInProcessWaferCount_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsEqpChamberInProcessWaferCount_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsEqpChamberInProcessWaferCount_struct*& _data);
#endif
#endif // _DCL_ANYOPS_tcsEqpChamberInProcessWaferCount_struct
#ifdef _DCL_ANYOPS_tcsEqpChamberInProcessWaferCountSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsEqpChamberInProcessWaferCountSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsEqpChamberInProcessWaferCountSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsEqpChamberInProcessWaferCountSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsEqpChamberInProcessWaferCountSequence*& _data);
#endif
#endif // _DCL_ANYOPS_tcsEqpChamberInProcessWaferCountSequence
#ifdef _DCL_ANYOPS_tcsEqpChamberInProcessWaferCountInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsEqpChamberInProcessWaferCountInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsEqpChamberInProcessWaferCountInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsEqpChamberInProcessWaferCountInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsEqpChamberInProcessWaferCountInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_tcsEqpChamberInProcessWaferCountInqResult_struct
#ifdef _DCL_ANYOPS_tcsBWSInventoryInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::tcsBWSInventoryInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::tcsBWSInventoryInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::tcsBWSInventoryInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::tcsBWSInventoryInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_tcsBWSInventoryInqResult_struct

#endif /* _cs_tcsstr_hh_included */

#endif /* _cs_tcsstr_server_defined */
