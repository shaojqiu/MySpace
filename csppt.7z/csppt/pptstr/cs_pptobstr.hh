//----------------------------------------------------------------------------
//
//  Generated from cs_pptobstr.idl
//  On Tuesday, November 14, 2017 11:54:03 AM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_pptobstr_server_defined
#ifndef _cs_pptobstr_hh_included
#define _cs_pptobstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_PPT_Object_Method_Structures_idl 
#define CS_PPT_Object_Method_Structures_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _pptobstr_hh_included
#include <pptobstr.hh>
#endif
#else
#ifndef _pptobstr_hh_included
#include "pptobstr.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
    class  objSample_Obj_struct_var;
    struct  objSample_Obj_struct {
        typedef objSample_Obj_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       objSample_Obj_struct();
       objSample_Obj_struct(const objSample_Obj_struct&);
       objSample_Obj_struct& operator=(const objSample_Obj_struct&);
       static CORBA::Info<objSample_Obj_struct> objSample_Obj_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct objSample_Obj_struct


typedef objSample_Obj_struct* objSample_Obj_struct_vPtr;
typedef const objSample_Obj_struct* objSample_Obj_struct_cvPtr;

class  objSample_Obj_struct_var
{
    public:

    objSample_Obj_struct_var ();

    objSample_Obj_struct_var (objSample_Obj_struct *_p);

    objSample_Obj_struct_var (const objSample_Obj_struct_var &_s);

    objSample_Obj_struct_var &operator= (objSample_Obj_struct *_p);

    objSample_Obj_struct_var &operator= (const objSample_Obj_struct_var &_s);

    ~objSample_Obj_struct_var ();

    objSample_Obj_struct* operator-> ();

    const objSample_Obj_struct& in() const;
    objSample_Obj_struct& inout();
    objSample_Obj_struct*& out();
    objSample_Obj_struct* _retn();

    operator objSample_Obj_struct_cvPtr () const;

    operator objSample_Obj_struct_vPtr& ();

    operator const objSample_Obj_struct& () const;

    operator objSample_Obj_struct& ();

    protected:
    objSample_Obj_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_objSample_Obj_struct;
    typedef objSample_Obj_struct objSample_Obj_out;
    typedef objSample_Obj_struct_var objSample_Obj_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_objSample_Obj_out;
    class  objTestFunction_Obj_struct_var;
    struct  objTestFunction_Obj_struct {
        typedef objTestFunction_Obj_struct_var _var_type;
       ::pptRetCode strResult;
       ::csTestFunctionInfoSequence infos;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       objTestFunction_Obj_struct();
       objTestFunction_Obj_struct(const objTestFunction_Obj_struct&);
       objTestFunction_Obj_struct& operator=(const objTestFunction_Obj_struct&);
       static CORBA::Info<objTestFunction_Obj_struct> objTestFunction_Obj_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct objTestFunction_Obj_struct


typedef objTestFunction_Obj_struct* objTestFunction_Obj_struct_vPtr;
typedef const objTestFunction_Obj_struct* objTestFunction_Obj_struct_cvPtr;

class  objTestFunction_Obj_struct_var
{
    public:

    objTestFunction_Obj_struct_var ();

    objTestFunction_Obj_struct_var (objTestFunction_Obj_struct *_p);

    objTestFunction_Obj_struct_var (const objTestFunction_Obj_struct_var &_s);

    objTestFunction_Obj_struct_var &operator= (objTestFunction_Obj_struct *_p);

    objTestFunction_Obj_struct_var &operator= (const objTestFunction_Obj_struct_var &_s);

    ~objTestFunction_Obj_struct_var ();

    objTestFunction_Obj_struct* operator-> ();

    const objTestFunction_Obj_struct& in() const;
    objTestFunction_Obj_struct& inout();
    objTestFunction_Obj_struct*& out();
    objTestFunction_Obj_struct* _retn();

    operator objTestFunction_Obj_struct_cvPtr () const;

    operator objTestFunction_Obj_struct_vPtr& ();

    operator const objTestFunction_Obj_struct& () const;

    operator objTestFunction_Obj_struct& ();

    protected:
    objTestFunction_Obj_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_objTestFunction_Obj_struct;
    typedef objTestFunction_Obj_struct objTestFunction_Obj_out;
    typedef objTestFunction_Obj_struct_var objTestFunction_Obj_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_objTestFunction_Obj_out;
    class  csObjEquipment_InAuditList_GetDR_out_struct_var;
    struct  csObjEquipment_InAuditList_GetDR_out_struct {
        typedef csObjEquipment_InAuditList_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifierSequence EquipmentIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_InAuditList_GetDR_out_struct();
       csObjEquipment_InAuditList_GetDR_out_struct(const csObjEquipment_InAuditList_GetDR_out_struct&);
       csObjEquipment_InAuditList_GetDR_out_struct& operator=(const csObjEquipment_InAuditList_GetDR_out_struct&);
       static CORBA::Info<csObjEquipment_InAuditList_GetDR_out_struct> csObjEquipment_InAuditList_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_InAuditList_GetDR_out_struct


typedef csObjEquipment_InAuditList_GetDR_out_struct* csObjEquipment_InAuditList_GetDR_out_struct_vPtr;
typedef const csObjEquipment_InAuditList_GetDR_out_struct* csObjEquipment_InAuditList_GetDR_out_struct_cvPtr;

class  csObjEquipment_InAuditList_GetDR_out_struct_var
{
    public:

    csObjEquipment_InAuditList_GetDR_out_struct_var ();

    csObjEquipment_InAuditList_GetDR_out_struct_var (csObjEquipment_InAuditList_GetDR_out_struct *_p);

    csObjEquipment_InAuditList_GetDR_out_struct_var (const csObjEquipment_InAuditList_GetDR_out_struct_var &_s);

    csObjEquipment_InAuditList_GetDR_out_struct_var &operator= (csObjEquipment_InAuditList_GetDR_out_struct *_p);

    csObjEquipment_InAuditList_GetDR_out_struct_var &operator= (const csObjEquipment_InAuditList_GetDR_out_struct_var &_s);

    ~csObjEquipment_InAuditList_GetDR_out_struct_var ();

    csObjEquipment_InAuditList_GetDR_out_struct* operator-> ();

    const csObjEquipment_InAuditList_GetDR_out_struct& in() const;
    csObjEquipment_InAuditList_GetDR_out_struct& inout();
    csObjEquipment_InAuditList_GetDR_out_struct*& out();
    csObjEquipment_InAuditList_GetDR_out_struct* _retn();

    operator csObjEquipment_InAuditList_GetDR_out_struct_cvPtr () const;

    operator csObjEquipment_InAuditList_GetDR_out_struct_vPtr& ();

    operator const csObjEquipment_InAuditList_GetDR_out_struct& () const;

    operator csObjEquipment_InAuditList_GetDR_out_struct& ();

    protected:
    csObjEquipment_InAuditList_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_InAuditList_GetDR_out_struct;
    typedef csObjEquipment_InAuditList_GetDR_out_struct csObjEquipment_InAuditList_GetDR_out;
    typedef csObjEquipment_InAuditList_GetDR_out_struct_var csObjEquipment_InAuditList_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_InAuditList_GetDR_out;
    class  csObjEquipment_ListByOwnerDR_out_struct_var;
    struct  csObjEquipment_ListByOwnerDR_out_struct {
        typedef csObjEquipment_ListByOwnerDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpsByOwnerSequence strEqpsByOwners;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_ListByOwnerDR_out_struct();
       csObjEquipment_ListByOwnerDR_out_struct(const csObjEquipment_ListByOwnerDR_out_struct&);
       csObjEquipment_ListByOwnerDR_out_struct& operator=(const csObjEquipment_ListByOwnerDR_out_struct&);
       static CORBA::Info<csObjEquipment_ListByOwnerDR_out_struct> csObjEquipment_ListByOwnerDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_ListByOwnerDR_out_struct


typedef csObjEquipment_ListByOwnerDR_out_struct* csObjEquipment_ListByOwnerDR_out_struct_vPtr;
typedef const csObjEquipment_ListByOwnerDR_out_struct* csObjEquipment_ListByOwnerDR_out_struct_cvPtr;

class  csObjEquipment_ListByOwnerDR_out_struct_var
{
    public:

    csObjEquipment_ListByOwnerDR_out_struct_var ();

    csObjEquipment_ListByOwnerDR_out_struct_var (csObjEquipment_ListByOwnerDR_out_struct *_p);

    csObjEquipment_ListByOwnerDR_out_struct_var (const csObjEquipment_ListByOwnerDR_out_struct_var &_s);

    csObjEquipment_ListByOwnerDR_out_struct_var &operator= (csObjEquipment_ListByOwnerDR_out_struct *_p);

    csObjEquipment_ListByOwnerDR_out_struct_var &operator= (const csObjEquipment_ListByOwnerDR_out_struct_var &_s);

    ~csObjEquipment_ListByOwnerDR_out_struct_var ();

    csObjEquipment_ListByOwnerDR_out_struct* operator-> ();

    const csObjEquipment_ListByOwnerDR_out_struct& in() const;
    csObjEquipment_ListByOwnerDR_out_struct& inout();
    csObjEquipment_ListByOwnerDR_out_struct*& out();
    csObjEquipment_ListByOwnerDR_out_struct* _retn();

    operator csObjEquipment_ListByOwnerDR_out_struct_cvPtr () const;

    operator csObjEquipment_ListByOwnerDR_out_struct_vPtr& ();

    operator const csObjEquipment_ListByOwnerDR_out_struct& () const;

    operator csObjEquipment_ListByOwnerDR_out_struct& ();

    protected:
    csObjEquipment_ListByOwnerDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_ListByOwnerDR_out_struct;
    typedef csObjEquipment_ListByOwnerDR_out_struct csObjEquipment_ListByOwnerDR_out;
    typedef csObjEquipment_ListByOwnerDR_out_struct_var csObjEquipment_ListByOwnerDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_ListByOwnerDR_out;
    class  csObjRMSMgr_GetServiceManager_out_struct_var;
    struct  csObjRMSMgr_GetServiceManager_out_struct {
        typedef csObjRMSMgr_GetServiceManager_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem RMSSvcMgr;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjRMSMgr_GetServiceManager_out_struct();
       csObjRMSMgr_GetServiceManager_out_struct(const csObjRMSMgr_GetServiceManager_out_struct&);
       csObjRMSMgr_GetServiceManager_out_struct& operator=(const csObjRMSMgr_GetServiceManager_out_struct&);
       static CORBA::Info<csObjRMSMgr_GetServiceManager_out_struct> csObjRMSMgr_GetServiceManager_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjRMSMgr_GetServiceManager_out_struct


typedef csObjRMSMgr_GetServiceManager_out_struct* csObjRMSMgr_GetServiceManager_out_struct_vPtr;
typedef const csObjRMSMgr_GetServiceManager_out_struct* csObjRMSMgr_GetServiceManager_out_struct_cvPtr;

class  csObjRMSMgr_GetServiceManager_out_struct_var
{
    public:

    csObjRMSMgr_GetServiceManager_out_struct_var ();

    csObjRMSMgr_GetServiceManager_out_struct_var (csObjRMSMgr_GetServiceManager_out_struct *_p);

    csObjRMSMgr_GetServiceManager_out_struct_var (const csObjRMSMgr_GetServiceManager_out_struct_var &_s);

    csObjRMSMgr_GetServiceManager_out_struct_var &operator= (csObjRMSMgr_GetServiceManager_out_struct *_p);

    csObjRMSMgr_GetServiceManager_out_struct_var &operator= (const csObjRMSMgr_GetServiceManager_out_struct_var &_s);

    ~csObjRMSMgr_GetServiceManager_out_struct_var ();

    csObjRMSMgr_GetServiceManager_out_struct* operator-> ();

    const csObjRMSMgr_GetServiceManager_out_struct& in() const;
    csObjRMSMgr_GetServiceManager_out_struct& inout();
    csObjRMSMgr_GetServiceManager_out_struct*& out();
    csObjRMSMgr_GetServiceManager_out_struct* _retn();

    operator csObjRMSMgr_GetServiceManager_out_struct_cvPtr () const;

    operator csObjRMSMgr_GetServiceManager_out_struct_vPtr& ();

    operator const csObjRMSMgr_GetServiceManager_out_struct& () const;

    operator csObjRMSMgr_GetServiceManager_out_struct& ();

    protected:
    csObjRMSMgr_GetServiceManager_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjRMSMgr_GetServiceManager_out_struct;
    typedef csObjRMSMgr_GetServiceManager_out_struct csObjRMSMgr_GetServiceManager_out;
    typedef csObjRMSMgr_GetServiceManager_out_struct_var csObjRMSMgr_GetServiceManager_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjRMSMgr_GetServiceManager_out;
    class  csObjEquipment_constantsManageFlag_Get_out_struct_var;
    struct  csObjEquipment_constantsManageFlag_Get_out_struct {
        typedef csObjEquipment_constantsManageFlag_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean equipmentConstantsManageFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_constantsManageFlag_Get_out_struct();
       csObjEquipment_constantsManageFlag_Get_out_struct(const csObjEquipment_constantsManageFlag_Get_out_struct&);
       csObjEquipment_constantsManageFlag_Get_out_struct& operator=(const csObjEquipment_constantsManageFlag_Get_out_struct&);
       static CORBA::Info<csObjEquipment_constantsManageFlag_Get_out_struct> csObjEquipment_constantsManageFlag_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_constantsManageFlag_Get_out_struct


typedef csObjEquipment_constantsManageFlag_Get_out_struct* csObjEquipment_constantsManageFlag_Get_out_struct_vPtr;
typedef const csObjEquipment_constantsManageFlag_Get_out_struct* csObjEquipment_constantsManageFlag_Get_out_struct_cvPtr;

class  csObjEquipment_constantsManageFlag_Get_out_struct_var
{
    public:

    csObjEquipment_constantsManageFlag_Get_out_struct_var ();

    csObjEquipment_constantsManageFlag_Get_out_struct_var (csObjEquipment_constantsManageFlag_Get_out_struct *_p);

    csObjEquipment_constantsManageFlag_Get_out_struct_var (const csObjEquipment_constantsManageFlag_Get_out_struct_var &_s);

    csObjEquipment_constantsManageFlag_Get_out_struct_var &operator= (csObjEquipment_constantsManageFlag_Get_out_struct *_p);

    csObjEquipment_constantsManageFlag_Get_out_struct_var &operator= (const csObjEquipment_constantsManageFlag_Get_out_struct_var &_s);

    ~csObjEquipment_constantsManageFlag_Get_out_struct_var ();

    csObjEquipment_constantsManageFlag_Get_out_struct* operator-> ();

    const csObjEquipment_constantsManageFlag_Get_out_struct& in() const;
    csObjEquipment_constantsManageFlag_Get_out_struct& inout();
    csObjEquipment_constantsManageFlag_Get_out_struct*& out();
    csObjEquipment_constantsManageFlag_Get_out_struct* _retn();

    operator csObjEquipment_constantsManageFlag_Get_out_struct_cvPtr () const;

    operator csObjEquipment_constantsManageFlag_Get_out_struct_vPtr& ();

    operator const csObjEquipment_constantsManageFlag_Get_out_struct& () const;

    operator csObjEquipment_constantsManageFlag_Get_out_struct& ();

    protected:
    csObjEquipment_constantsManageFlag_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_constantsManageFlag_Get_out_struct;
    typedef csObjEquipment_constantsManageFlag_Get_out_struct csObjEquipment_constantsManageFlag_Get_out;
    typedef csObjEquipment_constantsManageFlag_Get_out_struct_var csObjEquipment_constantsManageFlag_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_constantsManageFlag_Get_out;
    class  csObjRecipe_compareFlag_Get_out_struct_var;
    struct  csObjRecipe_compareFlag_Get_out_struct {
        typedef csObjRecipe_compareFlag_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csMachineRecipeInfoSequence machineRecipeInfos;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjRecipe_compareFlag_Get_out_struct();
       csObjRecipe_compareFlag_Get_out_struct(const csObjRecipe_compareFlag_Get_out_struct&);
       csObjRecipe_compareFlag_Get_out_struct& operator=(const csObjRecipe_compareFlag_Get_out_struct&);
       static CORBA::Info<csObjRecipe_compareFlag_Get_out_struct> csObjRecipe_compareFlag_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjRecipe_compareFlag_Get_out_struct


typedef csObjRecipe_compareFlag_Get_out_struct* csObjRecipe_compareFlag_Get_out_struct_vPtr;
typedef const csObjRecipe_compareFlag_Get_out_struct* csObjRecipe_compareFlag_Get_out_struct_cvPtr;

class  csObjRecipe_compareFlag_Get_out_struct_var
{
    public:

    csObjRecipe_compareFlag_Get_out_struct_var ();

    csObjRecipe_compareFlag_Get_out_struct_var (csObjRecipe_compareFlag_Get_out_struct *_p);

    csObjRecipe_compareFlag_Get_out_struct_var (const csObjRecipe_compareFlag_Get_out_struct_var &_s);

    csObjRecipe_compareFlag_Get_out_struct_var &operator= (csObjRecipe_compareFlag_Get_out_struct *_p);

    csObjRecipe_compareFlag_Get_out_struct_var &operator= (const csObjRecipe_compareFlag_Get_out_struct_var &_s);

    ~csObjRecipe_compareFlag_Get_out_struct_var ();

    csObjRecipe_compareFlag_Get_out_struct* operator-> ();

    const csObjRecipe_compareFlag_Get_out_struct& in() const;
    csObjRecipe_compareFlag_Get_out_struct& inout();
    csObjRecipe_compareFlag_Get_out_struct*& out();
    csObjRecipe_compareFlag_Get_out_struct* _retn();

    operator csObjRecipe_compareFlag_Get_out_struct_cvPtr () const;

    operator csObjRecipe_compareFlag_Get_out_struct_vPtr& ();

    operator const csObjRecipe_compareFlag_Get_out_struct& () const;

    operator csObjRecipe_compareFlag_Get_out_struct& ();

    protected:
    csObjRecipe_compareFlag_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjRecipe_compareFlag_Get_out_struct;
    typedef csObjRecipe_compareFlag_Get_out_struct csObjRecipe_compareFlag_Get_out;
    typedef csObjRecipe_compareFlag_Get_out_struct_var csObjRecipe_compareFlag_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjRecipe_compareFlag_Get_out;
    typedef objBase_out csObjRMSMgr_SendRecipeAuditReq_out;
    typedef objBase_out_var csObjRMSMgr_SendRecipeAuditReq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjRMSMgr_SendRecipeAuditReq_out;
    typedef objBase_out csObjPerson_PrivilegeCheckForRMS_out;
    typedef objBase_out_var csObjPerson_PrivilegeCheckForRMS_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_PrivilegeCheckForRMS_out;
    class  csObjEquipmentInfo_ListByOwnerDR_out_struct_var;
    struct  csObjEquipmentInfo_ListByOwnerDR_out_struct {
        typedef csObjEquipmentInfo_ListByOwnerDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpInfosByOwnerSequence strEqpInfosByOwners;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipmentInfo_ListByOwnerDR_out_struct();
       csObjEquipmentInfo_ListByOwnerDR_out_struct(const csObjEquipmentInfo_ListByOwnerDR_out_struct&);
       csObjEquipmentInfo_ListByOwnerDR_out_struct& operator=(const csObjEquipmentInfo_ListByOwnerDR_out_struct&);
       static CORBA::Info<csObjEquipmentInfo_ListByOwnerDR_out_struct> csObjEquipmentInfo_ListByOwnerDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipmentInfo_ListByOwnerDR_out_struct


typedef csObjEquipmentInfo_ListByOwnerDR_out_struct* csObjEquipmentInfo_ListByOwnerDR_out_struct_vPtr;
typedef const csObjEquipmentInfo_ListByOwnerDR_out_struct* csObjEquipmentInfo_ListByOwnerDR_out_struct_cvPtr;

class  csObjEquipmentInfo_ListByOwnerDR_out_struct_var
{
    public:

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var ();

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var (csObjEquipmentInfo_ListByOwnerDR_out_struct *_p);

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var (const csObjEquipmentInfo_ListByOwnerDR_out_struct_var &_s);

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var &operator= (csObjEquipmentInfo_ListByOwnerDR_out_struct *_p);

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var &operator= (const csObjEquipmentInfo_ListByOwnerDR_out_struct_var &_s);

    ~csObjEquipmentInfo_ListByOwnerDR_out_struct_var ();

    csObjEquipmentInfo_ListByOwnerDR_out_struct* operator-> ();

    const csObjEquipmentInfo_ListByOwnerDR_out_struct& in() const;
    csObjEquipmentInfo_ListByOwnerDR_out_struct& inout();
    csObjEquipmentInfo_ListByOwnerDR_out_struct*& out();
    csObjEquipmentInfo_ListByOwnerDR_out_struct* _retn();

    operator csObjEquipmentInfo_ListByOwnerDR_out_struct_cvPtr () const;

    operator csObjEquipmentInfo_ListByOwnerDR_out_struct_vPtr& ();

    operator const csObjEquipmentInfo_ListByOwnerDR_out_struct& () const;

    operator csObjEquipmentInfo_ListByOwnerDR_out_struct& ();

    protected:
    csObjEquipmentInfo_ListByOwnerDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipmentInfo_ListByOwnerDR_out_struct;
    typedef csObjEquipmentInfo_ListByOwnerDR_out_struct csObjEquipmentInfo_ListByOwnerDR_out;
    typedef csObjEquipmentInfo_ListByOwnerDR_out_struct_var csObjEquipmentInfo_ListByOwnerDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipmentInfo_ListByOwnerDR_out;
    class  csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var;
    struct  csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct {
        typedef csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csMandPRecipeInfoSequence strMandPRecipeInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct();
       csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct(const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct&);
       csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& operator=(const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct&);
       static CORBA::Info<csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct> csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct


typedef csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct* csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_vPtr;
typedef const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct* csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_cvPtr;

class  csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var
{
    public:

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var ();

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var (csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct *_p);

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var (const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var &_s);

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var &operator= (csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct *_p);

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var &operator= (const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var &_s);

    ~csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var ();

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct* operator-> ();

    const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& in() const;
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& inout();
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct*& out();
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct* _retn();

    operator csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_cvPtr () const;

    operator csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_vPtr& ();

    operator const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& () const;

    operator csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& ();

    protected:
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct;
    typedef csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out;
    typedef csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out;
    class  csObjCassette_InspectionTime_Reset_out_struct_var;
    struct  csObjCassette_InspectionTime_Reset_out_struct {
        typedef csObjCassette_InspectionTime_Reset_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier cassetteID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjCassette_InspectionTime_Reset_out_struct();
       csObjCassette_InspectionTime_Reset_out_struct(const csObjCassette_InspectionTime_Reset_out_struct&);
       csObjCassette_InspectionTime_Reset_out_struct& operator=(const csObjCassette_InspectionTime_Reset_out_struct&);
       static CORBA::Info<csObjCassette_InspectionTime_Reset_out_struct> csObjCassette_InspectionTime_Reset_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjCassette_InspectionTime_Reset_out_struct


typedef csObjCassette_InspectionTime_Reset_out_struct* csObjCassette_InspectionTime_Reset_out_struct_vPtr;
typedef const csObjCassette_InspectionTime_Reset_out_struct* csObjCassette_InspectionTime_Reset_out_struct_cvPtr;

class  csObjCassette_InspectionTime_Reset_out_struct_var
{
    public:

    csObjCassette_InspectionTime_Reset_out_struct_var ();

    csObjCassette_InspectionTime_Reset_out_struct_var (csObjCassette_InspectionTime_Reset_out_struct *_p);

    csObjCassette_InspectionTime_Reset_out_struct_var (const csObjCassette_InspectionTime_Reset_out_struct_var &_s);

    csObjCassette_InspectionTime_Reset_out_struct_var &operator= (csObjCassette_InspectionTime_Reset_out_struct *_p);

    csObjCassette_InspectionTime_Reset_out_struct_var &operator= (const csObjCassette_InspectionTime_Reset_out_struct_var &_s);

    ~csObjCassette_InspectionTime_Reset_out_struct_var ();

    csObjCassette_InspectionTime_Reset_out_struct* operator-> ();

    const csObjCassette_InspectionTime_Reset_out_struct& in() const;
    csObjCassette_InspectionTime_Reset_out_struct& inout();
    csObjCassette_InspectionTime_Reset_out_struct*& out();
    csObjCassette_InspectionTime_Reset_out_struct* _retn();

    operator csObjCassette_InspectionTime_Reset_out_struct_cvPtr () const;

    operator csObjCassette_InspectionTime_Reset_out_struct_vPtr& ();

    operator const csObjCassette_InspectionTime_Reset_out_struct& () const;

    operator csObjCassette_InspectionTime_Reset_out_struct& ();

    protected:
    csObjCassette_InspectionTime_Reset_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjCassette_InspectionTime_Reset_out_struct;
    typedef csObjCassette_InspectionTime_Reset_out_struct csObjCassette_InspectionTime_Reset_out;
    typedef csObjCassette_InspectionTime_Reset_out_struct_var csObjCassette_InspectionTime_Reset_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjCassette_InspectionTime_Reset_out;
    class  csObjCassette_PMTime_Reset_out_struct_var;
    struct  csObjCassette_PMTime_Reset_out_struct {
        typedef csObjCassette_PMTime_Reset_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier cassetteID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjCassette_PMTime_Reset_out_struct();
       csObjCassette_PMTime_Reset_out_struct(const csObjCassette_PMTime_Reset_out_struct&);
       csObjCassette_PMTime_Reset_out_struct& operator=(const csObjCassette_PMTime_Reset_out_struct&);
       static CORBA::Info<csObjCassette_PMTime_Reset_out_struct> csObjCassette_PMTime_Reset_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjCassette_PMTime_Reset_out_struct


typedef csObjCassette_PMTime_Reset_out_struct* csObjCassette_PMTime_Reset_out_struct_vPtr;
typedef const csObjCassette_PMTime_Reset_out_struct* csObjCassette_PMTime_Reset_out_struct_cvPtr;

class  csObjCassette_PMTime_Reset_out_struct_var
{
    public:

    csObjCassette_PMTime_Reset_out_struct_var ();

    csObjCassette_PMTime_Reset_out_struct_var (csObjCassette_PMTime_Reset_out_struct *_p);

    csObjCassette_PMTime_Reset_out_struct_var (const csObjCassette_PMTime_Reset_out_struct_var &_s);

    csObjCassette_PMTime_Reset_out_struct_var &operator= (csObjCassette_PMTime_Reset_out_struct *_p);

    csObjCassette_PMTime_Reset_out_struct_var &operator= (const csObjCassette_PMTime_Reset_out_struct_var &_s);

    ~csObjCassette_PMTime_Reset_out_struct_var ();

    csObjCassette_PMTime_Reset_out_struct* operator-> ();

    const csObjCassette_PMTime_Reset_out_struct& in() const;
    csObjCassette_PMTime_Reset_out_struct& inout();
    csObjCassette_PMTime_Reset_out_struct*& out();
    csObjCassette_PMTime_Reset_out_struct* _retn();

    operator csObjCassette_PMTime_Reset_out_struct_cvPtr () const;

    operator csObjCassette_PMTime_Reset_out_struct_vPtr& ();

    operator const csObjCassette_PMTime_Reset_out_struct& () const;

    operator csObjCassette_PMTime_Reset_out_struct& ();

    protected:
    csObjCassette_PMTime_Reset_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjCassette_PMTime_Reset_out_struct;
    typedef csObjCassette_PMTime_Reset_out_struct csObjCassette_PMTime_Reset_out;
    typedef csObjCassette_PMTime_Reset_out_struct_var csObjCassette_PMTime_Reset_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjCassette_PMTime_Reset_out;
    class  csObjReticle_WaferCount_Reset_out_struct_var;
    struct  csObjReticle_WaferCount_Reset_out_struct {
        typedef csObjReticle_WaferCount_Reset_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier reticleID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Reset_out_struct();
       csObjReticle_WaferCount_Reset_out_struct(const csObjReticle_WaferCount_Reset_out_struct&);
       csObjReticle_WaferCount_Reset_out_struct& operator=(const csObjReticle_WaferCount_Reset_out_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Reset_out_struct> csObjReticle_WaferCount_Reset_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Reset_out_struct


typedef csObjReticle_WaferCount_Reset_out_struct* csObjReticle_WaferCount_Reset_out_struct_vPtr;
typedef const csObjReticle_WaferCount_Reset_out_struct* csObjReticle_WaferCount_Reset_out_struct_cvPtr;

class  csObjReticle_WaferCount_Reset_out_struct_var
{
    public:

    csObjReticle_WaferCount_Reset_out_struct_var ();

    csObjReticle_WaferCount_Reset_out_struct_var (csObjReticle_WaferCount_Reset_out_struct *_p);

    csObjReticle_WaferCount_Reset_out_struct_var (const csObjReticle_WaferCount_Reset_out_struct_var &_s);

    csObjReticle_WaferCount_Reset_out_struct_var &operator= (csObjReticle_WaferCount_Reset_out_struct *_p);

    csObjReticle_WaferCount_Reset_out_struct_var &operator= (const csObjReticle_WaferCount_Reset_out_struct_var &_s);

    ~csObjReticle_WaferCount_Reset_out_struct_var ();

    csObjReticle_WaferCount_Reset_out_struct* operator-> ();

    const csObjReticle_WaferCount_Reset_out_struct& in() const;
    csObjReticle_WaferCount_Reset_out_struct& inout();
    csObjReticle_WaferCount_Reset_out_struct*& out();
    csObjReticle_WaferCount_Reset_out_struct* _retn();

    operator csObjReticle_WaferCount_Reset_out_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Reset_out_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Reset_out_struct& () const;

    operator csObjReticle_WaferCount_Reset_out_struct& ();

    protected:
    csObjReticle_WaferCount_Reset_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Reset_out_struct;
    typedef csObjReticle_WaferCount_Reset_out_struct csObjReticle_WaferCount_Reset_out;
    typedef csObjReticle_WaferCount_Reset_out_struct_var csObjReticle_WaferCount_Reset_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Reset_out;
    class  csObjReticle_UsedDuration_Reset_out_struct_var;
    struct  csObjReticle_UsedDuration_Reset_out_struct {
        typedef csObjReticle_UsedDuration_Reset_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier reticleID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_UsedDuration_Reset_out_struct();
       csObjReticle_UsedDuration_Reset_out_struct(const csObjReticle_UsedDuration_Reset_out_struct&);
       csObjReticle_UsedDuration_Reset_out_struct& operator=(const csObjReticle_UsedDuration_Reset_out_struct&);
       static CORBA::Info<csObjReticle_UsedDuration_Reset_out_struct> csObjReticle_UsedDuration_Reset_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_UsedDuration_Reset_out_struct


typedef csObjReticle_UsedDuration_Reset_out_struct* csObjReticle_UsedDuration_Reset_out_struct_vPtr;
typedef const csObjReticle_UsedDuration_Reset_out_struct* csObjReticle_UsedDuration_Reset_out_struct_cvPtr;

class  csObjReticle_UsedDuration_Reset_out_struct_var
{
    public:

    csObjReticle_UsedDuration_Reset_out_struct_var ();

    csObjReticle_UsedDuration_Reset_out_struct_var (csObjReticle_UsedDuration_Reset_out_struct *_p);

    csObjReticle_UsedDuration_Reset_out_struct_var (const csObjReticle_UsedDuration_Reset_out_struct_var &_s);

    csObjReticle_UsedDuration_Reset_out_struct_var &operator= (csObjReticle_UsedDuration_Reset_out_struct *_p);

    csObjReticle_UsedDuration_Reset_out_struct_var &operator= (const csObjReticle_UsedDuration_Reset_out_struct_var &_s);

    ~csObjReticle_UsedDuration_Reset_out_struct_var ();

    csObjReticle_UsedDuration_Reset_out_struct* operator-> ();

    const csObjReticle_UsedDuration_Reset_out_struct& in() const;
    csObjReticle_UsedDuration_Reset_out_struct& inout();
    csObjReticle_UsedDuration_Reset_out_struct*& out();
    csObjReticle_UsedDuration_Reset_out_struct* _retn();

    operator csObjReticle_UsedDuration_Reset_out_struct_cvPtr () const;

    operator csObjReticle_UsedDuration_Reset_out_struct_vPtr& ();

    operator const csObjReticle_UsedDuration_Reset_out_struct& () const;

    operator csObjReticle_UsedDuration_Reset_out_struct& ();

    protected:
    csObjReticle_UsedDuration_Reset_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_UsedDuration_Reset_out_struct;
    typedef csObjReticle_UsedDuration_Reset_out_struct csObjReticle_UsedDuration_Reset_out;
    typedef csObjReticle_UsedDuration_Reset_out_struct_var csObjReticle_UsedDuration_Reset_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_UsedDuration_Reset_out;
    class  csObjReticle_WaferCount_Increment_out_struct_var;
    struct  csObjReticle_WaferCount_Increment_out_struct {
        typedef csObjReticle_WaferCount_Increment_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Increment_out_struct();
       csObjReticle_WaferCount_Increment_out_struct(const csObjReticle_WaferCount_Increment_out_struct&);
       csObjReticle_WaferCount_Increment_out_struct& operator=(const csObjReticle_WaferCount_Increment_out_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Increment_out_struct> csObjReticle_WaferCount_Increment_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Increment_out_struct


typedef csObjReticle_WaferCount_Increment_out_struct* csObjReticle_WaferCount_Increment_out_struct_vPtr;
typedef const csObjReticle_WaferCount_Increment_out_struct* csObjReticle_WaferCount_Increment_out_struct_cvPtr;

class  csObjReticle_WaferCount_Increment_out_struct_var
{
    public:

    csObjReticle_WaferCount_Increment_out_struct_var ();

    csObjReticle_WaferCount_Increment_out_struct_var (csObjReticle_WaferCount_Increment_out_struct *_p);

    csObjReticle_WaferCount_Increment_out_struct_var (const csObjReticle_WaferCount_Increment_out_struct_var &_s);

    csObjReticle_WaferCount_Increment_out_struct_var &operator= (csObjReticle_WaferCount_Increment_out_struct *_p);

    csObjReticle_WaferCount_Increment_out_struct_var &operator= (const csObjReticle_WaferCount_Increment_out_struct_var &_s);

    ~csObjReticle_WaferCount_Increment_out_struct_var ();

    csObjReticle_WaferCount_Increment_out_struct* operator-> ();

    const csObjReticle_WaferCount_Increment_out_struct& in() const;
    csObjReticle_WaferCount_Increment_out_struct& inout();
    csObjReticle_WaferCount_Increment_out_struct*& out();
    csObjReticle_WaferCount_Increment_out_struct* _retn();

    operator csObjReticle_WaferCount_Increment_out_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Increment_out_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Increment_out_struct& () const;

    operator csObjReticle_WaferCount_Increment_out_struct& ();

    protected:
    csObjReticle_WaferCount_Increment_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Increment_out_struct;
    typedef csObjReticle_WaferCount_Increment_out_struct csObjReticle_WaferCount_Increment_out;
    typedef csObjReticle_WaferCount_Increment_out_struct_var csObjReticle_WaferCount_Increment_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Increment_out;
    class  csObjReticle_WaferCount_Increment_in_struct_var;
    struct  csObjReticle_WaferCount_Increment_in_struct {
        typedef csObjReticle_WaferCount_Increment_in_struct_var _var_type;
       ::objectIdentifier reticleID;
       ::CORBA::Long waferCount;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Increment_in_struct();
       csObjReticle_WaferCount_Increment_in_struct(const csObjReticle_WaferCount_Increment_in_struct&);
       csObjReticle_WaferCount_Increment_in_struct& operator=(const csObjReticle_WaferCount_Increment_in_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Increment_in_struct> csObjReticle_WaferCount_Increment_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Increment_in_struct


typedef csObjReticle_WaferCount_Increment_in_struct* csObjReticle_WaferCount_Increment_in_struct_vPtr;
typedef const csObjReticle_WaferCount_Increment_in_struct* csObjReticle_WaferCount_Increment_in_struct_cvPtr;

class  csObjReticle_WaferCount_Increment_in_struct_var
{
    public:

    csObjReticle_WaferCount_Increment_in_struct_var ();

    csObjReticle_WaferCount_Increment_in_struct_var (csObjReticle_WaferCount_Increment_in_struct *_p);

    csObjReticle_WaferCount_Increment_in_struct_var (const csObjReticle_WaferCount_Increment_in_struct_var &_s);

    csObjReticle_WaferCount_Increment_in_struct_var &operator= (csObjReticle_WaferCount_Increment_in_struct *_p);

    csObjReticle_WaferCount_Increment_in_struct_var &operator= (const csObjReticle_WaferCount_Increment_in_struct_var &_s);

    ~csObjReticle_WaferCount_Increment_in_struct_var ();

    csObjReticle_WaferCount_Increment_in_struct* operator-> ();

    const csObjReticle_WaferCount_Increment_in_struct& in() const;
    csObjReticle_WaferCount_Increment_in_struct& inout();
    csObjReticle_WaferCount_Increment_in_struct*& out();
    csObjReticle_WaferCount_Increment_in_struct* _retn();

    operator csObjReticle_WaferCount_Increment_in_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Increment_in_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Increment_in_struct& () const;

    operator csObjReticle_WaferCount_Increment_in_struct& ();

    protected:
    csObjReticle_WaferCount_Increment_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Increment_in_struct;
    typedef csObjReticle_WaferCount_Increment_in_struct csObjReticle_WaferCount_Increment_in;
    typedef csObjReticle_WaferCount_Increment_in_struct_var csObjReticle_WaferCount_Increment_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Increment_in;
    class  csObjReticle_WaferCount_Decrement_out_struct_var;
    struct  csObjReticle_WaferCount_Decrement_out_struct {
        typedef csObjReticle_WaferCount_Decrement_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Decrement_out_struct();
       csObjReticle_WaferCount_Decrement_out_struct(const csObjReticle_WaferCount_Decrement_out_struct&);
       csObjReticle_WaferCount_Decrement_out_struct& operator=(const csObjReticle_WaferCount_Decrement_out_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Decrement_out_struct> csObjReticle_WaferCount_Decrement_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Decrement_out_struct


typedef csObjReticle_WaferCount_Decrement_out_struct* csObjReticle_WaferCount_Decrement_out_struct_vPtr;
typedef const csObjReticle_WaferCount_Decrement_out_struct* csObjReticle_WaferCount_Decrement_out_struct_cvPtr;

class  csObjReticle_WaferCount_Decrement_out_struct_var
{
    public:

    csObjReticle_WaferCount_Decrement_out_struct_var ();

    csObjReticle_WaferCount_Decrement_out_struct_var (csObjReticle_WaferCount_Decrement_out_struct *_p);

    csObjReticle_WaferCount_Decrement_out_struct_var (const csObjReticle_WaferCount_Decrement_out_struct_var &_s);

    csObjReticle_WaferCount_Decrement_out_struct_var &operator= (csObjReticle_WaferCount_Decrement_out_struct *_p);

    csObjReticle_WaferCount_Decrement_out_struct_var &operator= (const csObjReticle_WaferCount_Decrement_out_struct_var &_s);

    ~csObjReticle_WaferCount_Decrement_out_struct_var ();

    csObjReticle_WaferCount_Decrement_out_struct* operator-> ();

    const csObjReticle_WaferCount_Decrement_out_struct& in() const;
    csObjReticle_WaferCount_Decrement_out_struct& inout();
    csObjReticle_WaferCount_Decrement_out_struct*& out();
    csObjReticle_WaferCount_Decrement_out_struct* _retn();

    operator csObjReticle_WaferCount_Decrement_out_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Decrement_out_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Decrement_out_struct& () const;

    operator csObjReticle_WaferCount_Decrement_out_struct& ();

    protected:
    csObjReticle_WaferCount_Decrement_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Decrement_out_struct;
    typedef csObjReticle_WaferCount_Decrement_out_struct csObjReticle_WaferCount_Decrement_out;
    typedef csObjReticle_WaferCount_Decrement_out_struct_var csObjReticle_WaferCount_Decrement_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Decrement_out;
    class  csObjReticle_WaferCount_Decrement_in_struct_var;
    struct  csObjReticle_WaferCount_Decrement_in_struct {
        typedef csObjReticle_WaferCount_Decrement_in_struct_var _var_type;
       ::objectIdentifier reticleID;
       ::CORBA::Long waferCount;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Decrement_in_struct();
       csObjReticle_WaferCount_Decrement_in_struct(const csObjReticle_WaferCount_Decrement_in_struct&);
       csObjReticle_WaferCount_Decrement_in_struct& operator=(const csObjReticle_WaferCount_Decrement_in_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Decrement_in_struct> csObjReticle_WaferCount_Decrement_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Decrement_in_struct


typedef csObjReticle_WaferCount_Decrement_in_struct* csObjReticle_WaferCount_Decrement_in_struct_vPtr;
typedef const csObjReticle_WaferCount_Decrement_in_struct* csObjReticle_WaferCount_Decrement_in_struct_cvPtr;

class  csObjReticle_WaferCount_Decrement_in_struct_var
{
    public:

    csObjReticle_WaferCount_Decrement_in_struct_var ();

    csObjReticle_WaferCount_Decrement_in_struct_var (csObjReticle_WaferCount_Decrement_in_struct *_p);

    csObjReticle_WaferCount_Decrement_in_struct_var (const csObjReticle_WaferCount_Decrement_in_struct_var &_s);

    csObjReticle_WaferCount_Decrement_in_struct_var &operator= (csObjReticle_WaferCount_Decrement_in_struct *_p);

    csObjReticle_WaferCount_Decrement_in_struct_var &operator= (const csObjReticle_WaferCount_Decrement_in_struct_var &_s);

    ~csObjReticle_WaferCount_Decrement_in_struct_var ();

    csObjReticle_WaferCount_Decrement_in_struct* operator-> ();

    const csObjReticle_WaferCount_Decrement_in_struct& in() const;
    csObjReticle_WaferCount_Decrement_in_struct& inout();
    csObjReticle_WaferCount_Decrement_in_struct*& out();
    csObjReticle_WaferCount_Decrement_in_struct* _retn();

    operator csObjReticle_WaferCount_Decrement_in_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Decrement_in_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Decrement_in_struct& () const;

    operator csObjReticle_WaferCount_Decrement_in_struct& ();

    protected:
    csObjReticle_WaferCount_Decrement_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Decrement_in_struct;
    typedef csObjReticle_WaferCount_Decrement_in_struct csObjReticle_WaferCount_Decrement_in;
    typedef csObjReticle_WaferCount_Decrement_in_struct_var csObjReticle_WaferCount_Decrement_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Decrement_in;
    class  csObjUserData_GetByLotOperation_out_struct_var;
    struct  csObjUserData_GetByLotOperation_out_struct {
        typedef csObjUserData_GetByLotOperation_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjUserData_GetByLotOperation_out_struct();
       csObjUserData_GetByLotOperation_out_struct(const csObjUserData_GetByLotOperation_out_struct&);
       csObjUserData_GetByLotOperation_out_struct& operator=(const csObjUserData_GetByLotOperation_out_struct&);
       static CORBA::Info<csObjUserData_GetByLotOperation_out_struct> csObjUserData_GetByLotOperation_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjUserData_GetByLotOperation_out_struct


typedef csObjUserData_GetByLotOperation_out_struct* csObjUserData_GetByLotOperation_out_struct_vPtr;
typedef const csObjUserData_GetByLotOperation_out_struct* csObjUserData_GetByLotOperation_out_struct_cvPtr;

class  csObjUserData_GetByLotOperation_out_struct_var
{
    public:

    csObjUserData_GetByLotOperation_out_struct_var ();

    csObjUserData_GetByLotOperation_out_struct_var (csObjUserData_GetByLotOperation_out_struct *_p);

    csObjUserData_GetByLotOperation_out_struct_var (const csObjUserData_GetByLotOperation_out_struct_var &_s);

    csObjUserData_GetByLotOperation_out_struct_var &operator= (csObjUserData_GetByLotOperation_out_struct *_p);

    csObjUserData_GetByLotOperation_out_struct_var &operator= (const csObjUserData_GetByLotOperation_out_struct_var &_s);

    ~csObjUserData_GetByLotOperation_out_struct_var ();

    csObjUserData_GetByLotOperation_out_struct* operator-> ();

    const csObjUserData_GetByLotOperation_out_struct& in() const;
    csObjUserData_GetByLotOperation_out_struct& inout();
    csObjUserData_GetByLotOperation_out_struct*& out();
    csObjUserData_GetByLotOperation_out_struct* _retn();

    operator csObjUserData_GetByLotOperation_out_struct_cvPtr () const;

    operator csObjUserData_GetByLotOperation_out_struct_vPtr& ();

    operator const csObjUserData_GetByLotOperation_out_struct& () const;

    operator csObjUserData_GetByLotOperation_out_struct& ();

    protected:
    csObjUserData_GetByLotOperation_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByLotOperation_out_struct;
    typedef csObjUserData_GetByLotOperation_out_struct csObjUserData_GetByLotOperation_out;
    typedef csObjUserData_GetByLotOperation_out_struct_var csObjUserData_GetByLotOperation_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByLotOperation_out;
    class  csObjUserData_GetByLotOperation_in_struct_var;
    struct  csObjUserData_GetByLotOperation_in_struct {
        typedef csObjUserData_GetByLotOperation_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::stringSequence userDataNameSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjUserData_GetByLotOperation_in_struct();
       csObjUserData_GetByLotOperation_in_struct(const csObjUserData_GetByLotOperation_in_struct&);
       csObjUserData_GetByLotOperation_in_struct& operator=(const csObjUserData_GetByLotOperation_in_struct&);
       static CORBA::Info<csObjUserData_GetByLotOperation_in_struct> csObjUserData_GetByLotOperation_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjUserData_GetByLotOperation_in_struct


typedef csObjUserData_GetByLotOperation_in_struct* csObjUserData_GetByLotOperation_in_struct_vPtr;
typedef const csObjUserData_GetByLotOperation_in_struct* csObjUserData_GetByLotOperation_in_struct_cvPtr;

class  csObjUserData_GetByLotOperation_in_struct_var
{
    public:

    csObjUserData_GetByLotOperation_in_struct_var ();

    csObjUserData_GetByLotOperation_in_struct_var (csObjUserData_GetByLotOperation_in_struct *_p);

    csObjUserData_GetByLotOperation_in_struct_var (const csObjUserData_GetByLotOperation_in_struct_var &_s);

    csObjUserData_GetByLotOperation_in_struct_var &operator= (csObjUserData_GetByLotOperation_in_struct *_p);

    csObjUserData_GetByLotOperation_in_struct_var &operator= (const csObjUserData_GetByLotOperation_in_struct_var &_s);

    ~csObjUserData_GetByLotOperation_in_struct_var ();

    csObjUserData_GetByLotOperation_in_struct* operator-> ();

    const csObjUserData_GetByLotOperation_in_struct& in() const;
    csObjUserData_GetByLotOperation_in_struct& inout();
    csObjUserData_GetByLotOperation_in_struct*& out();
    csObjUserData_GetByLotOperation_in_struct* _retn();

    operator csObjUserData_GetByLotOperation_in_struct_cvPtr () const;

    operator csObjUserData_GetByLotOperation_in_struct_vPtr& ();

    operator const csObjUserData_GetByLotOperation_in_struct& () const;

    operator csObjUserData_GetByLotOperation_in_struct& ();

    protected:
    csObjUserData_GetByLotOperation_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByLotOperation_in_struct;
    typedef csObjUserData_GetByLotOperation_in_struct csObjUserData_GetByLotOperation_in;
    typedef csObjUserData_GetByLotOperation_in_struct_var csObjUserData_GetByLotOperation_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByLotOperation_in;
    class  csObjReticlePod_Empty_Check_out_struct_var;
    struct  csObjReticlePod_Empty_Check_out_struct {
        typedef csObjReticlePod_Empty_Check_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean isEmpty;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticlePod_Empty_Check_out_struct();
       csObjReticlePod_Empty_Check_out_struct(const csObjReticlePod_Empty_Check_out_struct&);
       csObjReticlePod_Empty_Check_out_struct& operator=(const csObjReticlePod_Empty_Check_out_struct&);
       static CORBA::Info<csObjReticlePod_Empty_Check_out_struct> csObjReticlePod_Empty_Check_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticlePod_Empty_Check_out_struct


typedef csObjReticlePod_Empty_Check_out_struct* csObjReticlePod_Empty_Check_out_struct_vPtr;
typedef const csObjReticlePod_Empty_Check_out_struct* csObjReticlePod_Empty_Check_out_struct_cvPtr;

class  csObjReticlePod_Empty_Check_out_struct_var
{
    public:

    csObjReticlePod_Empty_Check_out_struct_var ();

    csObjReticlePod_Empty_Check_out_struct_var (csObjReticlePod_Empty_Check_out_struct *_p);

    csObjReticlePod_Empty_Check_out_struct_var (const csObjReticlePod_Empty_Check_out_struct_var &_s);

    csObjReticlePod_Empty_Check_out_struct_var &operator= (csObjReticlePod_Empty_Check_out_struct *_p);

    csObjReticlePod_Empty_Check_out_struct_var &operator= (const csObjReticlePod_Empty_Check_out_struct_var &_s);

    ~csObjReticlePod_Empty_Check_out_struct_var ();

    csObjReticlePod_Empty_Check_out_struct* operator-> ();

    const csObjReticlePod_Empty_Check_out_struct& in() const;
    csObjReticlePod_Empty_Check_out_struct& inout();
    csObjReticlePod_Empty_Check_out_struct*& out();
    csObjReticlePod_Empty_Check_out_struct* _retn();

    operator csObjReticlePod_Empty_Check_out_struct_cvPtr () const;

    operator csObjReticlePod_Empty_Check_out_struct_vPtr& ();

    operator const csObjReticlePod_Empty_Check_out_struct& () const;

    operator csObjReticlePod_Empty_Check_out_struct& ();

    protected:
    csObjReticlePod_Empty_Check_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticlePod_Empty_Check_out_struct;
    typedef csObjReticlePod_Empty_Check_out_struct csObjReticlePod_Empty_Check_out;
    typedef csObjReticlePod_Empty_Check_out_struct_var csObjReticlePod_Empty_Check_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticlePod_Empty_Check_out;
    class  csObjReticlePod_Empty_Check_in_struct_var;
    struct  csObjReticlePod_Empty_Check_in_struct {
        typedef csObjReticlePod_Empty_Check_in_struct_var _var_type;
       ::objectIdentifier reticlePodID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticlePod_Empty_Check_in_struct();
       csObjReticlePod_Empty_Check_in_struct(const csObjReticlePod_Empty_Check_in_struct&);
       csObjReticlePod_Empty_Check_in_struct& operator=(const csObjReticlePod_Empty_Check_in_struct&);
       static CORBA::Info<csObjReticlePod_Empty_Check_in_struct> csObjReticlePod_Empty_Check_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticlePod_Empty_Check_in_struct


typedef csObjReticlePod_Empty_Check_in_struct* csObjReticlePod_Empty_Check_in_struct_vPtr;
typedef const csObjReticlePod_Empty_Check_in_struct* csObjReticlePod_Empty_Check_in_struct_cvPtr;

class  csObjReticlePod_Empty_Check_in_struct_var
{
    public:

    csObjReticlePod_Empty_Check_in_struct_var ();

    csObjReticlePod_Empty_Check_in_struct_var (csObjReticlePod_Empty_Check_in_struct *_p);

    csObjReticlePod_Empty_Check_in_struct_var (const csObjReticlePod_Empty_Check_in_struct_var &_s);

    csObjReticlePod_Empty_Check_in_struct_var &operator= (csObjReticlePod_Empty_Check_in_struct *_p);

    csObjReticlePod_Empty_Check_in_struct_var &operator= (const csObjReticlePod_Empty_Check_in_struct_var &_s);

    ~csObjReticlePod_Empty_Check_in_struct_var ();

    csObjReticlePod_Empty_Check_in_struct* operator-> ();

    const csObjReticlePod_Empty_Check_in_struct& in() const;
    csObjReticlePod_Empty_Check_in_struct& inout();
    csObjReticlePod_Empty_Check_in_struct*& out();
    csObjReticlePod_Empty_Check_in_struct* _retn();

    operator csObjReticlePod_Empty_Check_in_struct_cvPtr () const;

    operator csObjReticlePod_Empty_Check_in_struct_vPtr& ();

    operator const csObjReticlePod_Empty_Check_in_struct& () const;

    operator csObjReticlePod_Empty_Check_in_struct& ();

    protected:
    csObjReticlePod_Empty_Check_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticlePod_Empty_Check_in_struct;
    typedef csObjReticlePod_Empty_Check_in_struct csObjReticlePod_Empty_Check_in;
    typedef csObjReticlePod_Empty_Check_in_struct_var csObjReticlePod_Empty_Check_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticlePod_Empty_Check_in;
    typedef objBase_out csObjVendorLotReserve_AddDR_out;
    typedef objBase_out_var csObjVendorLotReserve_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjVendorLotReserve_AddDR_out;
    typedef objBase_out csObjVendorLotReserve_DelDR_out;
    typedef objBase_out_var csObjVendorLotReserve_DelDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjVendorLotReserve_DelDR_out;
    class  csObjVendorLotReserve_SelDR_out_struct_var;
    struct  csObjVendorLotReserve_SelDR_out_struct {
        typedef csObjVendorLotReserve_SelDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csVendorLotReserveDataSequence strVendorLotReserveDataSequence;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjVendorLotReserve_SelDR_out_struct();
       csObjVendorLotReserve_SelDR_out_struct(const csObjVendorLotReserve_SelDR_out_struct&);
       csObjVendorLotReserve_SelDR_out_struct& operator=(const csObjVendorLotReserve_SelDR_out_struct&);
       static CORBA::Info<csObjVendorLotReserve_SelDR_out_struct> csObjVendorLotReserve_SelDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjVendorLotReserve_SelDR_out_struct


typedef csObjVendorLotReserve_SelDR_out_struct* csObjVendorLotReserve_SelDR_out_struct_vPtr;
typedef const csObjVendorLotReserve_SelDR_out_struct* csObjVendorLotReserve_SelDR_out_struct_cvPtr;

class  csObjVendorLotReserve_SelDR_out_struct_var
{
    public:

    csObjVendorLotReserve_SelDR_out_struct_var ();

    csObjVendorLotReserve_SelDR_out_struct_var (csObjVendorLotReserve_SelDR_out_struct *_p);

    csObjVendorLotReserve_SelDR_out_struct_var (const csObjVendorLotReserve_SelDR_out_struct_var &_s);

    csObjVendorLotReserve_SelDR_out_struct_var &operator= (csObjVendorLotReserve_SelDR_out_struct *_p);

    csObjVendorLotReserve_SelDR_out_struct_var &operator= (const csObjVendorLotReserve_SelDR_out_struct_var &_s);

    ~csObjVendorLotReserve_SelDR_out_struct_var ();

    csObjVendorLotReserve_SelDR_out_struct* operator-> ();

    const csObjVendorLotReserve_SelDR_out_struct& in() const;
    csObjVendorLotReserve_SelDR_out_struct& inout();
    csObjVendorLotReserve_SelDR_out_struct*& out();
    csObjVendorLotReserve_SelDR_out_struct* _retn();

    operator csObjVendorLotReserve_SelDR_out_struct_cvPtr () const;

    operator csObjVendorLotReserve_SelDR_out_struct_vPtr& ();

    operator const csObjVendorLotReserve_SelDR_out_struct& () const;

    operator csObjVendorLotReserve_SelDR_out_struct& ();

    protected:
    csObjVendorLotReserve_SelDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjVendorLotReserve_SelDR_out_struct;
    typedef csObjVendorLotReserve_SelDR_out_struct csObjVendorLotReserve_SelDR_out;
    typedef csObjVendorLotReserve_SelDR_out_struct_var csObjVendorLotReserve_SelDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjVendorLotReserve_SelDR_out;
    class  csObjLot_ContaminationInfo_Get_in_struct_var;
    struct  csObjLot_ContaminationInfo_Get_in_struct {
        typedef csObjLot_ContaminationInfo_Get_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_Get_in_struct();
       csObjLot_ContaminationInfo_Get_in_struct(const csObjLot_ContaminationInfo_Get_in_struct&);
       csObjLot_ContaminationInfo_Get_in_struct& operator=(const csObjLot_ContaminationInfo_Get_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_Get_in_struct> csObjLot_ContaminationInfo_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_Get_in_struct


typedef csObjLot_ContaminationInfo_Get_in_struct* csObjLot_ContaminationInfo_Get_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_Get_in_struct* csObjLot_ContaminationInfo_Get_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_Get_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_Get_in_struct_var ();

    csObjLot_ContaminationInfo_Get_in_struct_var (csObjLot_ContaminationInfo_Get_in_struct *_p);

    csObjLot_ContaminationInfo_Get_in_struct_var (const csObjLot_ContaminationInfo_Get_in_struct_var &_s);

    csObjLot_ContaminationInfo_Get_in_struct_var &operator= (csObjLot_ContaminationInfo_Get_in_struct *_p);

    csObjLot_ContaminationInfo_Get_in_struct_var &operator= (const csObjLot_ContaminationInfo_Get_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_Get_in_struct_var ();

    csObjLot_ContaminationInfo_Get_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_Get_in_struct& in() const;
    csObjLot_ContaminationInfo_Get_in_struct& inout();
    csObjLot_ContaminationInfo_Get_in_struct*& out();
    csObjLot_ContaminationInfo_Get_in_struct* _retn();

    operator csObjLot_ContaminationInfo_Get_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_Get_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_Get_in_struct& () const;

    operator csObjLot_ContaminationInfo_Get_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Get_in_struct;
    typedef csObjLot_ContaminationInfo_Get_in_struct csObjLot_ContaminationInfo_Get_in;
    typedef csObjLot_ContaminationInfo_Get_in_struct_var csObjLot_ContaminationInfo_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Get_in;
    class  csObjLot_ContaminationInfo_Get_out_struct_var;
    struct  csObjLot_ContaminationInfo_Get_out_struct {
        typedef csObjLot_ContaminationInfo_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csLotContaminationInfo strLotContaminationInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_Get_out_struct();
       csObjLot_ContaminationInfo_Get_out_struct(const csObjLot_ContaminationInfo_Get_out_struct&);
       csObjLot_ContaminationInfo_Get_out_struct& operator=(const csObjLot_ContaminationInfo_Get_out_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_Get_out_struct> csObjLot_ContaminationInfo_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_Get_out_struct


typedef csObjLot_ContaminationInfo_Get_out_struct* csObjLot_ContaminationInfo_Get_out_struct_vPtr;
typedef const csObjLot_ContaminationInfo_Get_out_struct* csObjLot_ContaminationInfo_Get_out_struct_cvPtr;

class  csObjLot_ContaminationInfo_Get_out_struct_var
{
    public:

    csObjLot_ContaminationInfo_Get_out_struct_var ();

    csObjLot_ContaminationInfo_Get_out_struct_var (csObjLot_ContaminationInfo_Get_out_struct *_p);

    csObjLot_ContaminationInfo_Get_out_struct_var (const csObjLot_ContaminationInfo_Get_out_struct_var &_s);

    csObjLot_ContaminationInfo_Get_out_struct_var &operator= (csObjLot_ContaminationInfo_Get_out_struct *_p);

    csObjLot_ContaminationInfo_Get_out_struct_var &operator= (const csObjLot_ContaminationInfo_Get_out_struct_var &_s);

    ~csObjLot_ContaminationInfo_Get_out_struct_var ();

    csObjLot_ContaminationInfo_Get_out_struct* operator-> ();

    const csObjLot_ContaminationInfo_Get_out_struct& in() const;
    csObjLot_ContaminationInfo_Get_out_struct& inout();
    csObjLot_ContaminationInfo_Get_out_struct*& out();
    csObjLot_ContaminationInfo_Get_out_struct* _retn();

    operator csObjLot_ContaminationInfo_Get_out_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_Get_out_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_Get_out_struct& () const;

    operator csObjLot_ContaminationInfo_Get_out_struct& ();

    protected:
    csObjLot_ContaminationInfo_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Get_out_struct;
    typedef csObjLot_ContaminationInfo_Get_out_struct csObjLot_ContaminationInfo_Get_out;
    typedef csObjLot_ContaminationInfo_Get_out_struct_var csObjLot_ContaminationInfo_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Get_out;
    class  csObjLot_ContaminationInfo_Set_in_struct_var;
    struct  csObjLot_ContaminationInfo_Set_in_struct {
        typedef csObjLot_ContaminationInfo_Set_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_Set_in_struct();
       csObjLot_ContaminationInfo_Set_in_struct(const csObjLot_ContaminationInfo_Set_in_struct&);
       csObjLot_ContaminationInfo_Set_in_struct& operator=(const csObjLot_ContaminationInfo_Set_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_Set_in_struct> csObjLot_ContaminationInfo_Set_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_Set_in_struct


typedef csObjLot_ContaminationInfo_Set_in_struct* csObjLot_ContaminationInfo_Set_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_Set_in_struct* csObjLot_ContaminationInfo_Set_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_Set_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_Set_in_struct_var ();

    csObjLot_ContaminationInfo_Set_in_struct_var (csObjLot_ContaminationInfo_Set_in_struct *_p);

    csObjLot_ContaminationInfo_Set_in_struct_var (const csObjLot_ContaminationInfo_Set_in_struct_var &_s);

    csObjLot_ContaminationInfo_Set_in_struct_var &operator= (csObjLot_ContaminationInfo_Set_in_struct *_p);

    csObjLot_ContaminationInfo_Set_in_struct_var &operator= (const csObjLot_ContaminationInfo_Set_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_Set_in_struct_var ();

    csObjLot_ContaminationInfo_Set_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_Set_in_struct& in() const;
    csObjLot_ContaminationInfo_Set_in_struct& inout();
    csObjLot_ContaminationInfo_Set_in_struct*& out();
    csObjLot_ContaminationInfo_Set_in_struct* _retn();

    operator csObjLot_ContaminationInfo_Set_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_Set_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_Set_in_struct& () const;

    operator csObjLot_ContaminationInfo_Set_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_Set_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Set_in_struct;
    typedef csObjLot_ContaminationInfo_Set_in_struct csObjLot_ContaminationInfo_Set_in;
    typedef csObjLot_ContaminationInfo_Set_in_struct_var csObjLot_ContaminationInfo_Set_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Set_in;
    typedef objBase_out csObjLot_ContaminationInfo_Set_out;
    typedef objBase_out_var csObjLot_ContaminationInfo_Set_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Set_out;
    class  csObjLot_ContaminationInfo_CheckForMove_in_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForMove_in_struct {
        typedef csObjLot_ContaminationInfo_CheckForMove_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::objectIdentifier carrierID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForMove_in_struct();
       csObjLot_ContaminationInfo_CheckForMove_in_struct(const csObjLot_ContaminationInfo_CheckForMove_in_struct&);
       csObjLot_ContaminationInfo_CheckForMove_in_struct& operator=(const csObjLot_ContaminationInfo_CheckForMove_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForMove_in_struct> csObjLot_ContaminationInfo_CheckForMove_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForMove_in_struct


typedef csObjLot_ContaminationInfo_CheckForMove_in_struct* csObjLot_ContaminationInfo_CheckForMove_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForMove_in_struct* csObjLot_ContaminationInfo_CheckForMove_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForMove_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var (csObjLot_ContaminationInfo_CheckForMove_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var (const csObjLot_ContaminationInfo_CheckForMove_in_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var &operator= (csObjLot_ContaminationInfo_CheckForMove_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForMove_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForMove_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForMove_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForMove_in_struct& in() const;
    csObjLot_ContaminationInfo_CheckForMove_in_struct& inout();
    csObjLot_ContaminationInfo_CheckForMove_in_struct*& out();
    csObjLot_ContaminationInfo_CheckForMove_in_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForMove_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForMove_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForMove_in_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForMove_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForMove_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForMove_in_struct;
    typedef csObjLot_ContaminationInfo_CheckForMove_in_struct csObjLot_ContaminationInfo_CheckForMove_in;
    typedef csObjLot_ContaminationInfo_CheckForMove_in_struct_var csObjLot_ContaminationInfo_CheckForMove_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForMove_in;
    class  csObjLot_ContaminationInfo_CheckForMove_out_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForMove_out_struct {
        typedef csObjLot_ContaminationInfo_CheckForMove_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean holdReqFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForMove_out_struct();
       csObjLot_ContaminationInfo_CheckForMove_out_struct(const csObjLot_ContaminationInfo_CheckForMove_out_struct&);
       csObjLot_ContaminationInfo_CheckForMove_out_struct& operator=(const csObjLot_ContaminationInfo_CheckForMove_out_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForMove_out_struct> csObjLot_ContaminationInfo_CheckForMove_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForMove_out_struct


typedef csObjLot_ContaminationInfo_CheckForMove_out_struct* csObjLot_ContaminationInfo_CheckForMove_out_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForMove_out_struct* csObjLot_ContaminationInfo_CheckForMove_out_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForMove_out_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var (csObjLot_ContaminationInfo_CheckForMove_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var (const csObjLot_ContaminationInfo_CheckForMove_out_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var &operator= (csObjLot_ContaminationInfo_CheckForMove_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForMove_out_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForMove_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForMove_out_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForMove_out_struct& in() const;
    csObjLot_ContaminationInfo_CheckForMove_out_struct& inout();
    csObjLot_ContaminationInfo_CheckForMove_out_struct*& out();
    csObjLot_ContaminationInfo_CheckForMove_out_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForMove_out_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForMove_out_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForMove_out_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForMove_out_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForMove_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForMove_out_struct;
    typedef csObjLot_ContaminationInfo_CheckForMove_out_struct csObjLot_ContaminationInfo_CheckForMove_out;
    typedef csObjLot_ContaminationInfo_CheckForMove_out_struct_var csObjLot_ContaminationInfo_CheckForMove_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForMove_out;
    class  csObjLot_ContaminationInfo_CheckForProcess_in_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForProcess_in_struct {
        typedef csObjLot_ContaminationInfo_CheckForProcess_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::objectIdentifier carrierID;
       ::pptLotInCassetteSequence strLotInCassette;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForProcess_in_struct();
       csObjLot_ContaminationInfo_CheckForProcess_in_struct(const csObjLot_ContaminationInfo_CheckForProcess_in_struct&);
       csObjLot_ContaminationInfo_CheckForProcess_in_struct& operator=(const csObjLot_ContaminationInfo_CheckForProcess_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForProcess_in_struct> csObjLot_ContaminationInfo_CheckForProcess_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForProcess_in_struct


typedef csObjLot_ContaminationInfo_CheckForProcess_in_struct* csObjLot_ContaminationInfo_CheckForProcess_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForProcess_in_struct* csObjLot_ContaminationInfo_CheckForProcess_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForProcess_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var (csObjLot_ContaminationInfo_CheckForProcess_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var (const csObjLot_ContaminationInfo_CheckForProcess_in_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var &operator= (csObjLot_ContaminationInfo_CheckForProcess_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForProcess_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForProcess_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForProcess_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForProcess_in_struct& in() const;
    csObjLot_ContaminationInfo_CheckForProcess_in_struct& inout();
    csObjLot_ContaminationInfo_CheckForProcess_in_struct*& out();
    csObjLot_ContaminationInfo_CheckForProcess_in_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForProcess_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForProcess_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForProcess_in_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForProcess_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForProcess_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForProcess_in_struct;
    typedef csObjLot_ContaminationInfo_CheckForProcess_in_struct csObjLot_ContaminationInfo_CheckForProcess_in;
    typedef csObjLot_ContaminationInfo_CheckForProcess_in_struct_var csObjLot_ContaminationInfo_CheckForProcess_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForProcess_in;
    class  csObjLot_ContaminationInfo_CheckForProcess_out_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForProcess_out_struct {
        typedef csObjLot_ContaminationInfo_CheckForProcess_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean matchFlag;
       ::objectIdentifierSequence holdLotIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForProcess_out_struct();
       csObjLot_ContaminationInfo_CheckForProcess_out_struct(const csObjLot_ContaminationInfo_CheckForProcess_out_struct&);
       csObjLot_ContaminationInfo_CheckForProcess_out_struct& operator=(const csObjLot_ContaminationInfo_CheckForProcess_out_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForProcess_out_struct> csObjLot_ContaminationInfo_CheckForProcess_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForProcess_out_struct


typedef csObjLot_ContaminationInfo_CheckForProcess_out_struct* csObjLot_ContaminationInfo_CheckForProcess_out_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForProcess_out_struct* csObjLot_ContaminationInfo_CheckForProcess_out_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForProcess_out_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var (csObjLot_ContaminationInfo_CheckForProcess_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var (const csObjLot_ContaminationInfo_CheckForProcess_out_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var &operator= (csObjLot_ContaminationInfo_CheckForProcess_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForProcess_out_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForProcess_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForProcess_out_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForProcess_out_struct& in() const;
    csObjLot_ContaminationInfo_CheckForProcess_out_struct& inout();
    csObjLot_ContaminationInfo_CheckForProcess_out_struct*& out();
    csObjLot_ContaminationInfo_CheckForProcess_out_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForProcess_out_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForProcess_out_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForProcess_out_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForProcess_out_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForProcess_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForProcess_out_struct;
    typedef csObjLot_ContaminationInfo_CheckForProcess_out_struct csObjLot_ContaminationInfo_CheckForProcess_out;
    typedef csObjLot_ContaminationInfo_CheckForProcess_out_struct_var csObjLot_ContaminationInfo_CheckForProcess_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForProcess_out;
    class  csObjLot_udata_CopyToChild_in_struct_var;
    struct  csObjLot_udata_CopyToChild_in_struct {
        typedef csObjLot_udata_CopyToChild_in_struct_var _var_type;
       ::objectIdentifier parentLotID;
       ::objectIdentifier childLotID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_udata_CopyToChild_in_struct();
       csObjLot_udata_CopyToChild_in_struct(const csObjLot_udata_CopyToChild_in_struct&);
       csObjLot_udata_CopyToChild_in_struct& operator=(const csObjLot_udata_CopyToChild_in_struct&);
       static CORBA::Info<csObjLot_udata_CopyToChild_in_struct> csObjLot_udata_CopyToChild_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_udata_CopyToChild_in_struct


typedef csObjLot_udata_CopyToChild_in_struct* csObjLot_udata_CopyToChild_in_struct_vPtr;
typedef const csObjLot_udata_CopyToChild_in_struct* csObjLot_udata_CopyToChild_in_struct_cvPtr;

class  csObjLot_udata_CopyToChild_in_struct_var
{
    public:

    csObjLot_udata_CopyToChild_in_struct_var ();

    csObjLot_udata_CopyToChild_in_struct_var (csObjLot_udata_CopyToChild_in_struct *_p);

    csObjLot_udata_CopyToChild_in_struct_var (const csObjLot_udata_CopyToChild_in_struct_var &_s);

    csObjLot_udata_CopyToChild_in_struct_var &operator= (csObjLot_udata_CopyToChild_in_struct *_p);

    csObjLot_udata_CopyToChild_in_struct_var &operator= (const csObjLot_udata_CopyToChild_in_struct_var &_s);

    ~csObjLot_udata_CopyToChild_in_struct_var ();

    csObjLot_udata_CopyToChild_in_struct* operator-> ();

    const csObjLot_udata_CopyToChild_in_struct& in() const;
    csObjLot_udata_CopyToChild_in_struct& inout();
    csObjLot_udata_CopyToChild_in_struct*& out();
    csObjLot_udata_CopyToChild_in_struct* _retn();

    operator csObjLot_udata_CopyToChild_in_struct_cvPtr () const;

    operator csObjLot_udata_CopyToChild_in_struct_vPtr& ();

    operator const csObjLot_udata_CopyToChild_in_struct& () const;

    operator csObjLot_udata_CopyToChild_in_struct& ();

    protected:
    csObjLot_udata_CopyToChild_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_udata_CopyToChild_in_struct;
    typedef csObjLot_udata_CopyToChild_in_struct csObjLot_udata_CopyToChild_in;
    typedef csObjLot_udata_CopyToChild_in_struct_var csObjLot_udata_CopyToChild_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_udata_CopyToChild_in;
    typedef objBase_out csObjLot_udata_CopyToChild_out;
    typedef objBase_out_var csObjLot_udata_CopyToChild_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_udata_CopyToChild_out;
    class  csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct {
        typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var _var_type;
       ::objectIdentifier carrierID;
       ::objectIdentifierSequence lotIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct();
       csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct(const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct&);
       csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& operator=(const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct> csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct


typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct* csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct* csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var (csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var (const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var &operator= (csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& in() const;
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& inout();
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct*& out();
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct;
    typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct csObjLot_ContaminationInfo_CheckForCarrierExchange_in;
    typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var csObjLot_ContaminationInfo_CheckForCarrierExchange_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForCarrierExchange_in;
    class  csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct {
        typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean matchFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct();
       csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct(const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct&);
       csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& operator=(const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct> csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct


typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct* csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct* csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var (csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var (const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var &operator= (csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& in() const;
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& inout();
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct*& out();
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct;
    typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct csObjLot_ContaminationInfo_CheckForCarrierExchange_out;
    typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var csObjLot_ContaminationInfo_CheckForCarrierExchange_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForCarrierExchange_out;
    class  csObjEquipment_udata_GetDR_in_struct_var;
    struct  csObjEquipment_udata_GetDR_in_struct {
        typedef csObjEquipment_udata_GetDR_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::stringSequence udataName;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_udata_GetDR_in_struct();
       csObjEquipment_udata_GetDR_in_struct(const csObjEquipment_udata_GetDR_in_struct&);
       csObjEquipment_udata_GetDR_in_struct& operator=(const csObjEquipment_udata_GetDR_in_struct&);
       static CORBA::Info<csObjEquipment_udata_GetDR_in_struct> csObjEquipment_udata_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_udata_GetDR_in_struct


typedef csObjEquipment_udata_GetDR_in_struct* csObjEquipment_udata_GetDR_in_struct_vPtr;
typedef const csObjEquipment_udata_GetDR_in_struct* csObjEquipment_udata_GetDR_in_struct_cvPtr;

class  csObjEquipment_udata_GetDR_in_struct_var
{
    public:

    csObjEquipment_udata_GetDR_in_struct_var ();

    csObjEquipment_udata_GetDR_in_struct_var (csObjEquipment_udata_GetDR_in_struct *_p);

    csObjEquipment_udata_GetDR_in_struct_var (const csObjEquipment_udata_GetDR_in_struct_var &_s);

    csObjEquipment_udata_GetDR_in_struct_var &operator= (csObjEquipment_udata_GetDR_in_struct *_p);

    csObjEquipment_udata_GetDR_in_struct_var &operator= (const csObjEquipment_udata_GetDR_in_struct_var &_s);

    ~csObjEquipment_udata_GetDR_in_struct_var ();

    csObjEquipment_udata_GetDR_in_struct* operator-> ();

    const csObjEquipment_udata_GetDR_in_struct& in() const;
    csObjEquipment_udata_GetDR_in_struct& inout();
    csObjEquipment_udata_GetDR_in_struct*& out();
    csObjEquipment_udata_GetDR_in_struct* _retn();

    operator csObjEquipment_udata_GetDR_in_struct_cvPtr () const;

    operator csObjEquipment_udata_GetDR_in_struct_vPtr& ();

    operator const csObjEquipment_udata_GetDR_in_struct& () const;

    operator csObjEquipment_udata_GetDR_in_struct& ();

    protected:
    csObjEquipment_udata_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_udata_GetDR_in_struct;
    typedef csObjEquipment_udata_GetDR_in_struct csObjEquipment_udata_GetDR_in;
    typedef csObjEquipment_udata_GetDR_in_struct_var csObjEquipment_udata_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_udata_GetDR_in;
    class  csObjEquipment_udata_GetDR_out_struct_var;
    struct  csObjEquipment_udata_GetDR_out_struct {
        typedef csObjEquipment_udata_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::stringSequence udataValue;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_udata_GetDR_out_struct();
       csObjEquipment_udata_GetDR_out_struct(const csObjEquipment_udata_GetDR_out_struct&);
       csObjEquipment_udata_GetDR_out_struct& operator=(const csObjEquipment_udata_GetDR_out_struct&);
       static CORBA::Info<csObjEquipment_udata_GetDR_out_struct> csObjEquipment_udata_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_udata_GetDR_out_struct


typedef csObjEquipment_udata_GetDR_out_struct* csObjEquipment_udata_GetDR_out_struct_vPtr;
typedef const csObjEquipment_udata_GetDR_out_struct* csObjEquipment_udata_GetDR_out_struct_cvPtr;

class  csObjEquipment_udata_GetDR_out_struct_var
{
    public:

    csObjEquipment_udata_GetDR_out_struct_var ();

    csObjEquipment_udata_GetDR_out_struct_var (csObjEquipment_udata_GetDR_out_struct *_p);

    csObjEquipment_udata_GetDR_out_struct_var (const csObjEquipment_udata_GetDR_out_struct_var &_s);

    csObjEquipment_udata_GetDR_out_struct_var &operator= (csObjEquipment_udata_GetDR_out_struct *_p);

    csObjEquipment_udata_GetDR_out_struct_var &operator= (const csObjEquipment_udata_GetDR_out_struct_var &_s);

    ~csObjEquipment_udata_GetDR_out_struct_var ();

    csObjEquipment_udata_GetDR_out_struct* operator-> ();

    const csObjEquipment_udata_GetDR_out_struct& in() const;
    csObjEquipment_udata_GetDR_out_struct& inout();
    csObjEquipment_udata_GetDR_out_struct*& out();
    csObjEquipment_udata_GetDR_out_struct* _retn();

    operator csObjEquipment_udata_GetDR_out_struct_cvPtr () const;

    operator csObjEquipment_udata_GetDR_out_struct_vPtr& ();

    operator const csObjEquipment_udata_GetDR_out_struct& () const;

    operator csObjEquipment_udata_GetDR_out_struct& ();

    protected:
    csObjEquipment_udata_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_udata_GetDR_out_struct;
    typedef csObjEquipment_udata_GetDR_out_struct csObjEquipment_udata_GetDR_out;
    typedef csObjEquipment_udata_GetDR_out_struct_var csObjEquipment_udata_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_udata_GetDR_out;
    class  csObjCarrier_UsageTypeChange_in_struct_var;
    struct  csObjCarrier_UsageTypeChange_in_struct {
        typedef csObjCarrier_UsageTypeChange_in_struct_var _var_type;
       ::objectIdentifierSequence carrierIDs;
       ::CORBA::String_StructElem usageType;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjCarrier_UsageTypeChange_in_struct();
       csObjCarrier_UsageTypeChange_in_struct(const csObjCarrier_UsageTypeChange_in_struct&);
       csObjCarrier_UsageTypeChange_in_struct& operator=(const csObjCarrier_UsageTypeChange_in_struct&);
       static CORBA::Info<csObjCarrier_UsageTypeChange_in_struct> csObjCarrier_UsageTypeChange_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjCarrier_UsageTypeChange_in_struct


typedef csObjCarrier_UsageTypeChange_in_struct* csObjCarrier_UsageTypeChange_in_struct_vPtr;
typedef const csObjCarrier_UsageTypeChange_in_struct* csObjCarrier_UsageTypeChange_in_struct_cvPtr;

class  csObjCarrier_UsageTypeChange_in_struct_var
{
    public:

    csObjCarrier_UsageTypeChange_in_struct_var ();

    csObjCarrier_UsageTypeChange_in_struct_var (csObjCarrier_UsageTypeChange_in_struct *_p);

    csObjCarrier_UsageTypeChange_in_struct_var (const csObjCarrier_UsageTypeChange_in_struct_var &_s);

    csObjCarrier_UsageTypeChange_in_struct_var &operator= (csObjCarrier_UsageTypeChange_in_struct *_p);

    csObjCarrier_UsageTypeChange_in_struct_var &operator= (const csObjCarrier_UsageTypeChange_in_struct_var &_s);

    ~csObjCarrier_UsageTypeChange_in_struct_var ();

    csObjCarrier_UsageTypeChange_in_struct* operator-> ();

    const csObjCarrier_UsageTypeChange_in_struct& in() const;
    csObjCarrier_UsageTypeChange_in_struct& inout();
    csObjCarrier_UsageTypeChange_in_struct*& out();
    csObjCarrier_UsageTypeChange_in_struct* _retn();

    operator csObjCarrier_UsageTypeChange_in_struct_cvPtr () const;

    operator csObjCarrier_UsageTypeChange_in_struct_vPtr& ();

    operator const csObjCarrier_UsageTypeChange_in_struct& () const;

    operator csObjCarrier_UsageTypeChange_in_struct& ();

    protected:
    csObjCarrier_UsageTypeChange_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjCarrier_UsageTypeChange_in_struct;
    typedef csObjCarrier_UsageTypeChange_in_struct csObjCarrier_UsageTypeChange_in;
    typedef csObjCarrier_UsageTypeChange_in_struct_var csObjCarrier_UsageTypeChange_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjCarrier_UsageTypeChange_in;
    typedef objBase_out csObjCarrier_UsageTypeChange_out;
    typedef objBase_out_var csObjCarrier_UsageTypeChange_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjCarrier_UsageTypeChange_out;
    class  csObjLot_requiredCarrierCategory_CheckDR_in_struct_var;
    struct  csObjLot_requiredCarrierCategory_CheckDR_in_struct {
        typedef csObjLot_requiredCarrierCategory_CheckDR_in_struct_var _var_type;
       ::objectIdentifier carrierID;
       ::objectIdentifier lotID;
       ::CORBA::String_StructElem curCastCategory;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_requiredCarrierCategory_CheckDR_in_struct();
       csObjLot_requiredCarrierCategory_CheckDR_in_struct(const csObjLot_requiredCarrierCategory_CheckDR_in_struct&);
       csObjLot_requiredCarrierCategory_CheckDR_in_struct& operator=(const csObjLot_requiredCarrierCategory_CheckDR_in_struct&);
       static CORBA::Info<csObjLot_requiredCarrierCategory_CheckDR_in_struct> csObjLot_requiredCarrierCategory_CheckDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_requiredCarrierCategory_CheckDR_in_struct


typedef csObjLot_requiredCarrierCategory_CheckDR_in_struct* csObjLot_requiredCarrierCategory_CheckDR_in_struct_vPtr;
typedef const csObjLot_requiredCarrierCategory_CheckDR_in_struct* csObjLot_requiredCarrierCategory_CheckDR_in_struct_cvPtr;

class  csObjLot_requiredCarrierCategory_CheckDR_in_struct_var
{
    public:

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var ();

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var (csObjLot_requiredCarrierCategory_CheckDR_in_struct *_p);

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var (const csObjLot_requiredCarrierCategory_CheckDR_in_struct_var &_s);

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var &operator= (csObjLot_requiredCarrierCategory_CheckDR_in_struct *_p);

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var &operator= (const csObjLot_requiredCarrierCategory_CheckDR_in_struct_var &_s);

    ~csObjLot_requiredCarrierCategory_CheckDR_in_struct_var ();

    csObjLot_requiredCarrierCategory_CheckDR_in_struct* operator-> ();

    const csObjLot_requiredCarrierCategory_CheckDR_in_struct& in() const;
    csObjLot_requiredCarrierCategory_CheckDR_in_struct& inout();
    csObjLot_requiredCarrierCategory_CheckDR_in_struct*& out();
    csObjLot_requiredCarrierCategory_CheckDR_in_struct* _retn();

    operator csObjLot_requiredCarrierCategory_CheckDR_in_struct_cvPtr () const;

    operator csObjLot_requiredCarrierCategory_CheckDR_in_struct_vPtr& ();

    operator const csObjLot_requiredCarrierCategory_CheckDR_in_struct& () const;

    operator csObjLot_requiredCarrierCategory_CheckDR_in_struct& ();

    protected:
    csObjLot_requiredCarrierCategory_CheckDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_requiredCarrierCategory_CheckDR_in_struct;
    typedef csObjLot_requiredCarrierCategory_CheckDR_in_struct csObjLot_requiredCarrierCategory_CheckDR_in;
    typedef csObjLot_requiredCarrierCategory_CheckDR_in_struct_var csObjLot_requiredCarrierCategory_CheckDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_requiredCarrierCategory_CheckDR_in;
    typedef objBase_out csObjLot_requiredCarrierCategory_CheckDR_out;
    typedef objBase_out_var csObjLot_requiredCarrierCategory_CheckDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_requiredCarrierCategory_CheckDR_out;
    class  csObjPerson_SkillList_GetDR_out_struct_var;
    struct  csObjPerson_SkillList_GetDR_out_struct {
        typedef csObjPerson_SkillList_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csUserSkillInfo strUserSkillInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_GetDR_out_struct();
       csObjPerson_SkillList_GetDR_out_struct(const csObjPerson_SkillList_GetDR_out_struct&);
       csObjPerson_SkillList_GetDR_out_struct& operator=(const csObjPerson_SkillList_GetDR_out_struct&);
       static CORBA::Info<csObjPerson_SkillList_GetDR_out_struct> csObjPerson_SkillList_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_GetDR_out_struct


typedef csObjPerson_SkillList_GetDR_out_struct* csObjPerson_SkillList_GetDR_out_struct_vPtr;
typedef const csObjPerson_SkillList_GetDR_out_struct* csObjPerson_SkillList_GetDR_out_struct_cvPtr;

class  csObjPerson_SkillList_GetDR_out_struct_var
{
    public:

    csObjPerson_SkillList_GetDR_out_struct_var ();

    csObjPerson_SkillList_GetDR_out_struct_var (csObjPerson_SkillList_GetDR_out_struct *_p);

    csObjPerson_SkillList_GetDR_out_struct_var (const csObjPerson_SkillList_GetDR_out_struct_var &_s);

    csObjPerson_SkillList_GetDR_out_struct_var &operator= (csObjPerson_SkillList_GetDR_out_struct *_p);

    csObjPerson_SkillList_GetDR_out_struct_var &operator= (const csObjPerson_SkillList_GetDR_out_struct_var &_s);

    ~csObjPerson_SkillList_GetDR_out_struct_var ();

    csObjPerson_SkillList_GetDR_out_struct* operator-> ();

    const csObjPerson_SkillList_GetDR_out_struct& in() const;
    csObjPerson_SkillList_GetDR_out_struct& inout();
    csObjPerson_SkillList_GetDR_out_struct*& out();
    csObjPerson_SkillList_GetDR_out_struct* _retn();

    operator csObjPerson_SkillList_GetDR_out_struct_cvPtr () const;

    operator csObjPerson_SkillList_GetDR_out_struct_vPtr& ();

    operator const csObjPerson_SkillList_GetDR_out_struct& () const;

    operator csObjPerson_SkillList_GetDR_out_struct& ();

    protected:
    csObjPerson_SkillList_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_GetDR_out_struct;
    typedef csObjPerson_SkillList_GetDR_out_struct csObjPerson_SkillList_GetDR_out;
    typedef csObjPerson_SkillList_GetDR_out_struct_var csObjPerson_SkillList_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_GetDR_out;
    typedef objBase_out csObjPerson_SkillList_SetDR_out;
    typedef objBase_out_var csObjPerson_SkillList_SetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_SetDR_out;
    typedef objBase_out csObjPerson_SkillList_AddDR_out;
    typedef objBase_out_var csObjPerson_SkillList_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_AddDR_out;
    typedef objBase_out csObjPerson_SkillList_DelDR_out;
    typedef objBase_out_var csObjPerson_SkillList_DelDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_DelDR_out;
    typedef objBase_out csObjPerson_PrivilegeCheckForTACertify_out;
    typedef objBase_out_var csObjPerson_PrivilegeCheckForTACertify_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_PrivilegeCheckForTACertify_out;
    class  csObjPerson_SkillList_GetDR_in_strcut_var;
    struct  csObjPerson_SkillList_GetDR_in_strcut {
        typedef csObjPerson_SkillList_GetDR_in_strcut_var _var_type;
       ::objectIdentifier userID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_GetDR_in_strcut();
       csObjPerson_SkillList_GetDR_in_strcut(const csObjPerson_SkillList_GetDR_in_strcut&);
       csObjPerson_SkillList_GetDR_in_strcut& operator=(const csObjPerson_SkillList_GetDR_in_strcut&);
       static CORBA::Info<csObjPerson_SkillList_GetDR_in_strcut> csObjPerson_SkillList_GetDR_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_GetDR_in_strcut


typedef csObjPerson_SkillList_GetDR_in_strcut* csObjPerson_SkillList_GetDR_in_strcut_vPtr;
typedef const csObjPerson_SkillList_GetDR_in_strcut* csObjPerson_SkillList_GetDR_in_strcut_cvPtr;

class  csObjPerson_SkillList_GetDR_in_strcut_var
{
    public:

    csObjPerson_SkillList_GetDR_in_strcut_var ();

    csObjPerson_SkillList_GetDR_in_strcut_var (csObjPerson_SkillList_GetDR_in_strcut *_p);

    csObjPerson_SkillList_GetDR_in_strcut_var (const csObjPerson_SkillList_GetDR_in_strcut_var &_s);

    csObjPerson_SkillList_GetDR_in_strcut_var &operator= (csObjPerson_SkillList_GetDR_in_strcut *_p);

    csObjPerson_SkillList_GetDR_in_strcut_var &operator= (const csObjPerson_SkillList_GetDR_in_strcut_var &_s);

    ~csObjPerson_SkillList_GetDR_in_strcut_var ();

    csObjPerson_SkillList_GetDR_in_strcut* operator-> ();

    const csObjPerson_SkillList_GetDR_in_strcut& in() const;
    csObjPerson_SkillList_GetDR_in_strcut& inout();
    csObjPerson_SkillList_GetDR_in_strcut*& out();
    csObjPerson_SkillList_GetDR_in_strcut* _retn();

    operator csObjPerson_SkillList_GetDR_in_strcut_cvPtr () const;

    operator csObjPerson_SkillList_GetDR_in_strcut_vPtr& ();

    operator const csObjPerson_SkillList_GetDR_in_strcut& () const;

    operator csObjPerson_SkillList_GetDR_in_strcut& ();

    protected:
    csObjPerson_SkillList_GetDR_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_GetDR_in_strcut;
    typedef csObjPerson_SkillList_GetDR_in_strcut csObjPerson_SkillList_GetDR_in;
    typedef csObjPerson_SkillList_GetDR_in_strcut_var csObjPerson_SkillList_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_GetDR_in;
    class  csObjPerson_SkillList_AddDR_in_strcut_var;
    struct  csObjPerson_SkillList_AddDR_in_strcut {
        typedef csObjPerson_SkillList_AddDR_in_strcut_var _var_type;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_AddDR_in_strcut();
       csObjPerson_SkillList_AddDR_in_strcut(const csObjPerson_SkillList_AddDR_in_strcut&);
       csObjPerson_SkillList_AddDR_in_strcut& operator=(const csObjPerson_SkillList_AddDR_in_strcut&);
       static CORBA::Info<csObjPerson_SkillList_AddDR_in_strcut> csObjPerson_SkillList_AddDR_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_AddDR_in_strcut


typedef csObjPerson_SkillList_AddDR_in_strcut* csObjPerson_SkillList_AddDR_in_strcut_vPtr;
typedef const csObjPerson_SkillList_AddDR_in_strcut* csObjPerson_SkillList_AddDR_in_strcut_cvPtr;

class  csObjPerson_SkillList_AddDR_in_strcut_var
{
    public:

    csObjPerson_SkillList_AddDR_in_strcut_var ();

    csObjPerson_SkillList_AddDR_in_strcut_var (csObjPerson_SkillList_AddDR_in_strcut *_p);

    csObjPerson_SkillList_AddDR_in_strcut_var (const csObjPerson_SkillList_AddDR_in_strcut_var &_s);

    csObjPerson_SkillList_AddDR_in_strcut_var &operator= (csObjPerson_SkillList_AddDR_in_strcut *_p);

    csObjPerson_SkillList_AddDR_in_strcut_var &operator= (const csObjPerson_SkillList_AddDR_in_strcut_var &_s);

    ~csObjPerson_SkillList_AddDR_in_strcut_var ();

    csObjPerson_SkillList_AddDR_in_strcut* operator-> ();

    const csObjPerson_SkillList_AddDR_in_strcut& in() const;
    csObjPerson_SkillList_AddDR_in_strcut& inout();
    csObjPerson_SkillList_AddDR_in_strcut*& out();
    csObjPerson_SkillList_AddDR_in_strcut* _retn();

    operator csObjPerson_SkillList_AddDR_in_strcut_cvPtr () const;

    operator csObjPerson_SkillList_AddDR_in_strcut_vPtr& ();

    operator const csObjPerson_SkillList_AddDR_in_strcut& () const;

    operator csObjPerson_SkillList_AddDR_in_strcut& ();

    protected:
    csObjPerson_SkillList_AddDR_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_AddDR_in_strcut;
    typedef csObjPerson_SkillList_AddDR_in_strcut csObjPerson_SkillList_AddDR_in;
    typedef csObjPerson_SkillList_AddDR_in_strcut_var csObjPerson_SkillList_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_AddDR_in;
    class  csObjPerson_SkillList_DelDR_in_strcut_var;
    struct  csObjPerson_SkillList_DelDR_in_strcut {
        typedef csObjPerson_SkillList_DelDR_in_strcut_var _var_type;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_DelDR_in_strcut();
       csObjPerson_SkillList_DelDR_in_strcut(const csObjPerson_SkillList_DelDR_in_strcut&);
       csObjPerson_SkillList_DelDR_in_strcut& operator=(const csObjPerson_SkillList_DelDR_in_strcut&);
       static CORBA::Info<csObjPerson_SkillList_DelDR_in_strcut> csObjPerson_SkillList_DelDR_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_DelDR_in_strcut


typedef csObjPerson_SkillList_DelDR_in_strcut* csObjPerson_SkillList_DelDR_in_strcut_vPtr;
typedef const csObjPerson_SkillList_DelDR_in_strcut* csObjPerson_SkillList_DelDR_in_strcut_cvPtr;

class  csObjPerson_SkillList_DelDR_in_strcut_var
{
    public:

    csObjPerson_SkillList_DelDR_in_strcut_var ();

    csObjPerson_SkillList_DelDR_in_strcut_var (csObjPerson_SkillList_DelDR_in_strcut *_p);

    csObjPerson_SkillList_DelDR_in_strcut_var (const csObjPerson_SkillList_DelDR_in_strcut_var &_s);

    csObjPerson_SkillList_DelDR_in_strcut_var &operator= (csObjPerson_SkillList_DelDR_in_strcut *_p);

    csObjPerson_SkillList_DelDR_in_strcut_var &operator= (const csObjPerson_SkillList_DelDR_in_strcut_var &_s);

    ~csObjPerson_SkillList_DelDR_in_strcut_var ();

    csObjPerson_SkillList_DelDR_in_strcut* operator-> ();

    const csObjPerson_SkillList_DelDR_in_strcut& in() const;
    csObjPerson_SkillList_DelDR_in_strcut& inout();
    csObjPerson_SkillList_DelDR_in_strcut*& out();
    csObjPerson_SkillList_DelDR_in_strcut* _retn();

    operator csObjPerson_SkillList_DelDR_in_strcut_cvPtr () const;

    operator csObjPerson_SkillList_DelDR_in_strcut_vPtr& ();

    operator const csObjPerson_SkillList_DelDR_in_strcut& () const;

    operator csObjPerson_SkillList_DelDR_in_strcut& ();

    protected:
    csObjPerson_SkillList_DelDR_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_DelDR_in_strcut;
    typedef csObjPerson_SkillList_DelDR_in_strcut csObjPerson_SkillList_DelDR_in;
    typedef csObjPerson_SkillList_DelDR_in_strcut_var csObjPerson_SkillList_DelDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_DelDR_in;
    class  csObjPerson_SkillList_SetDR_in_strcut_var;
    struct  csObjPerson_SkillList_SetDR_in_strcut {
        typedef csObjPerson_SkillList_SetDR_in_strcut_var _var_type;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_SetDR_in_strcut();
       csObjPerson_SkillList_SetDR_in_strcut(const csObjPerson_SkillList_SetDR_in_strcut&);
       csObjPerson_SkillList_SetDR_in_strcut& operator=(const csObjPerson_SkillList_SetDR_in_strcut&);
       static CORBA::Info<csObjPerson_SkillList_SetDR_in_strcut> csObjPerson_SkillList_SetDR_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_SetDR_in_strcut


typedef csObjPerson_SkillList_SetDR_in_strcut* csObjPerson_SkillList_SetDR_in_strcut_vPtr;
typedef const csObjPerson_SkillList_SetDR_in_strcut* csObjPerson_SkillList_SetDR_in_strcut_cvPtr;

class  csObjPerson_SkillList_SetDR_in_strcut_var
{
    public:

    csObjPerson_SkillList_SetDR_in_strcut_var ();

    csObjPerson_SkillList_SetDR_in_strcut_var (csObjPerson_SkillList_SetDR_in_strcut *_p);

    csObjPerson_SkillList_SetDR_in_strcut_var (const csObjPerson_SkillList_SetDR_in_strcut_var &_s);

    csObjPerson_SkillList_SetDR_in_strcut_var &operator= (csObjPerson_SkillList_SetDR_in_strcut *_p);

    csObjPerson_SkillList_SetDR_in_strcut_var &operator= (const csObjPerson_SkillList_SetDR_in_strcut_var &_s);

    ~csObjPerson_SkillList_SetDR_in_strcut_var ();

    csObjPerson_SkillList_SetDR_in_strcut* operator-> ();

    const csObjPerson_SkillList_SetDR_in_strcut& in() const;
    csObjPerson_SkillList_SetDR_in_strcut& inout();
    csObjPerson_SkillList_SetDR_in_strcut*& out();
    csObjPerson_SkillList_SetDR_in_strcut* _retn();

    operator csObjPerson_SkillList_SetDR_in_strcut_cvPtr () const;

    operator csObjPerson_SkillList_SetDR_in_strcut_vPtr& ();

    operator const csObjPerson_SkillList_SetDR_in_strcut& () const;

    operator csObjPerson_SkillList_SetDR_in_strcut& ();

    protected:
    csObjPerson_SkillList_SetDR_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_SetDR_in_strcut;
    typedef csObjPerson_SkillList_SetDR_in_strcut csObjPerson_SkillList_SetDR_in;
    typedef csObjPerson_SkillList_SetDR_in_strcut_var csObjPerson_SkillList_SetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_SetDR_in;
    class  csObjPerson_PrivilegeCheckForTACertify_in_strcut_var;
    struct  csObjPerson_PrivilegeCheckForTACertify_in_strcut {
        typedef csObjPerson_PrivilegeCheckForTACertify_in_strcut_var _var_type;
       ::objectIdentifier userID;
       ::objectIdentifier equipmentID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_PrivilegeCheckForTACertify_in_strcut();
       csObjPerson_PrivilegeCheckForTACertify_in_strcut(const csObjPerson_PrivilegeCheckForTACertify_in_strcut&);
       csObjPerson_PrivilegeCheckForTACertify_in_strcut& operator=(const csObjPerson_PrivilegeCheckForTACertify_in_strcut&);
       static CORBA::Info<csObjPerson_PrivilegeCheckForTACertify_in_strcut> csObjPerson_PrivilegeCheckForTACertify_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_PrivilegeCheckForTACertify_in_strcut


typedef csObjPerson_PrivilegeCheckForTACertify_in_strcut* csObjPerson_PrivilegeCheckForTACertify_in_strcut_vPtr;
typedef const csObjPerson_PrivilegeCheckForTACertify_in_strcut* csObjPerson_PrivilegeCheckForTACertify_in_strcut_cvPtr;

class  csObjPerson_PrivilegeCheckForTACertify_in_strcut_var
{
    public:

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var ();

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var (csObjPerson_PrivilegeCheckForTACertify_in_strcut *_p);

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var (const csObjPerson_PrivilegeCheckForTACertify_in_strcut_var &_s);

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var &operator= (csObjPerson_PrivilegeCheckForTACertify_in_strcut *_p);

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var &operator= (const csObjPerson_PrivilegeCheckForTACertify_in_strcut_var &_s);

    ~csObjPerson_PrivilegeCheckForTACertify_in_strcut_var ();

    csObjPerson_PrivilegeCheckForTACertify_in_strcut* operator-> ();

    const csObjPerson_PrivilegeCheckForTACertify_in_strcut& in() const;
    csObjPerson_PrivilegeCheckForTACertify_in_strcut& inout();
    csObjPerson_PrivilegeCheckForTACertify_in_strcut*& out();
    csObjPerson_PrivilegeCheckForTACertify_in_strcut* _retn();

    operator csObjPerson_PrivilegeCheckForTACertify_in_strcut_cvPtr () const;

    operator csObjPerson_PrivilegeCheckForTACertify_in_strcut_vPtr& ();

    operator const csObjPerson_PrivilegeCheckForTACertify_in_strcut& () const;

    operator csObjPerson_PrivilegeCheckForTACertify_in_strcut& ();

    protected:
    csObjPerson_PrivilegeCheckForTACertify_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_PrivilegeCheckForTACertify_in_strcut;
    typedef csObjPerson_PrivilegeCheckForTACertify_in_strcut csObjPerson_PrivilegeCheckForTACertify_in;
    typedef csObjPerson_PrivilegeCheckForTACertify_in_strcut_var csObjPerson_PrivilegeCheckForTACertify_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_PrivilegeCheckForTACertify_in;
    class  csObjFixture_touchCountSet_in_struct_var;
    struct  csObjFixture_touchCountSet_in_struct {
        typedef csObjFixture_touchCountSet_in_struct_var _var_type;
       ::objectIdentifier fixtureID;
       ::csFixtureTouchCountInfo strFixtureTouchCountInfo;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjFixture_touchCountSet_in_struct();
       csObjFixture_touchCountSet_in_struct(const csObjFixture_touchCountSet_in_struct&);
       csObjFixture_touchCountSet_in_struct& operator=(const csObjFixture_touchCountSet_in_struct&);
       static CORBA::Info<csObjFixture_touchCountSet_in_struct> csObjFixture_touchCountSet_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjFixture_touchCountSet_in_struct


typedef csObjFixture_touchCountSet_in_struct* csObjFixture_touchCountSet_in_struct_vPtr;
typedef const csObjFixture_touchCountSet_in_struct* csObjFixture_touchCountSet_in_struct_cvPtr;

class  csObjFixture_touchCountSet_in_struct_var
{
    public:

    csObjFixture_touchCountSet_in_struct_var ();

    csObjFixture_touchCountSet_in_struct_var (csObjFixture_touchCountSet_in_struct *_p);

    csObjFixture_touchCountSet_in_struct_var (const csObjFixture_touchCountSet_in_struct_var &_s);

    csObjFixture_touchCountSet_in_struct_var &operator= (csObjFixture_touchCountSet_in_struct *_p);

    csObjFixture_touchCountSet_in_struct_var &operator= (const csObjFixture_touchCountSet_in_struct_var &_s);

    ~csObjFixture_touchCountSet_in_struct_var ();

    csObjFixture_touchCountSet_in_struct* operator-> ();

    const csObjFixture_touchCountSet_in_struct& in() const;
    csObjFixture_touchCountSet_in_struct& inout();
    csObjFixture_touchCountSet_in_struct*& out();
    csObjFixture_touchCountSet_in_struct* _retn();

    operator csObjFixture_touchCountSet_in_struct_cvPtr () const;

    operator csObjFixture_touchCountSet_in_struct_vPtr& ();

    operator const csObjFixture_touchCountSet_in_struct& () const;

    operator csObjFixture_touchCountSet_in_struct& ();

    protected:
    csObjFixture_touchCountSet_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCountSet_in_struct;
    typedef csObjFixture_touchCountSet_in_struct csObjFixture_touchCount_Set_in;
    typedef csObjFixture_touchCountSet_in_struct_var csObjFixture_touchCount_Set_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Set_in;
    class  csObjFixture_touchCountSet_out_struct_var;
    struct  csObjFixture_touchCountSet_out_struct {
        typedef csObjFixture_touchCountSet_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csFixtureTouchCountInfo strFixtureTouchCountInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjFixture_touchCountSet_out_struct();
       csObjFixture_touchCountSet_out_struct(const csObjFixture_touchCountSet_out_struct&);
       csObjFixture_touchCountSet_out_struct& operator=(const csObjFixture_touchCountSet_out_struct&);
       static CORBA::Info<csObjFixture_touchCountSet_out_struct> csObjFixture_touchCountSet_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjFixture_touchCountSet_out_struct


typedef csObjFixture_touchCountSet_out_struct* csObjFixture_touchCountSet_out_struct_vPtr;
typedef const csObjFixture_touchCountSet_out_struct* csObjFixture_touchCountSet_out_struct_cvPtr;

class  csObjFixture_touchCountSet_out_struct_var
{
    public:

    csObjFixture_touchCountSet_out_struct_var ();

    csObjFixture_touchCountSet_out_struct_var (csObjFixture_touchCountSet_out_struct *_p);

    csObjFixture_touchCountSet_out_struct_var (const csObjFixture_touchCountSet_out_struct_var &_s);

    csObjFixture_touchCountSet_out_struct_var &operator= (csObjFixture_touchCountSet_out_struct *_p);

    csObjFixture_touchCountSet_out_struct_var &operator= (const csObjFixture_touchCountSet_out_struct_var &_s);

    ~csObjFixture_touchCountSet_out_struct_var ();

    csObjFixture_touchCountSet_out_struct* operator-> ();

    const csObjFixture_touchCountSet_out_struct& in() const;
    csObjFixture_touchCountSet_out_struct& inout();
    csObjFixture_touchCountSet_out_struct*& out();
    csObjFixture_touchCountSet_out_struct* _retn();

    operator csObjFixture_touchCountSet_out_struct_cvPtr () const;

    operator csObjFixture_touchCountSet_out_struct_vPtr& ();

    operator const csObjFixture_touchCountSet_out_struct& () const;

    operator csObjFixture_touchCountSet_out_struct& ();

    protected:
    csObjFixture_touchCountSet_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCountSet_out_struct;
    typedef csObjFixture_touchCountSet_out_struct csObjFixture_touchCount_Set_out;
    typedef csObjFixture_touchCountSet_out_struct_var csObjFixture_touchCount_Set_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Set_out;
    class  csObjFixture_touchCount_Get_in_struct_var;
    struct  csObjFixture_touchCount_Get_in_struct {
        typedef csObjFixture_touchCount_Get_in_struct_var _var_type;
       ::objectIdentifier fixtureID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjFixture_touchCount_Get_in_struct();
       csObjFixture_touchCount_Get_in_struct(const csObjFixture_touchCount_Get_in_struct&);
       csObjFixture_touchCount_Get_in_struct& operator=(const csObjFixture_touchCount_Get_in_struct&);
       static CORBA::Info<csObjFixture_touchCount_Get_in_struct> csObjFixture_touchCount_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjFixture_touchCount_Get_in_struct


typedef csObjFixture_touchCount_Get_in_struct* csObjFixture_touchCount_Get_in_struct_vPtr;
typedef const csObjFixture_touchCount_Get_in_struct* csObjFixture_touchCount_Get_in_struct_cvPtr;

class  csObjFixture_touchCount_Get_in_struct_var
{
    public:

    csObjFixture_touchCount_Get_in_struct_var ();

    csObjFixture_touchCount_Get_in_struct_var (csObjFixture_touchCount_Get_in_struct *_p);

    csObjFixture_touchCount_Get_in_struct_var (const csObjFixture_touchCount_Get_in_struct_var &_s);

    csObjFixture_touchCount_Get_in_struct_var &operator= (csObjFixture_touchCount_Get_in_struct *_p);

    csObjFixture_touchCount_Get_in_struct_var &operator= (const csObjFixture_touchCount_Get_in_struct_var &_s);

    ~csObjFixture_touchCount_Get_in_struct_var ();

    csObjFixture_touchCount_Get_in_struct* operator-> ();

    const csObjFixture_touchCount_Get_in_struct& in() const;
    csObjFixture_touchCount_Get_in_struct& inout();
    csObjFixture_touchCount_Get_in_struct*& out();
    csObjFixture_touchCount_Get_in_struct* _retn();

    operator csObjFixture_touchCount_Get_in_struct_cvPtr () const;

    operator csObjFixture_touchCount_Get_in_struct_vPtr& ();

    operator const csObjFixture_touchCount_Get_in_struct& () const;

    operator csObjFixture_touchCount_Get_in_struct& ();

    protected:
    csObjFixture_touchCount_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Get_in_struct;
    typedef csObjFixture_touchCount_Get_in_struct csObjFixture_touchCount_Get_in;
    typedef csObjFixture_touchCount_Get_in_struct_var csObjFixture_touchCount_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Get_in;
    class  csObjFixture_touchCount_Get_out_struct_var;
    struct  csObjFixture_touchCount_Get_out_struct {
        typedef csObjFixture_touchCount_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csFixtureTouchCountInfo strFixtureTouchCountInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjFixture_touchCount_Get_out_struct();
       csObjFixture_touchCount_Get_out_struct(const csObjFixture_touchCount_Get_out_struct&);
       csObjFixture_touchCount_Get_out_struct& operator=(const csObjFixture_touchCount_Get_out_struct&);
       static CORBA::Info<csObjFixture_touchCount_Get_out_struct> csObjFixture_touchCount_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjFixture_touchCount_Get_out_struct


typedef csObjFixture_touchCount_Get_out_struct* csObjFixture_touchCount_Get_out_struct_vPtr;
typedef const csObjFixture_touchCount_Get_out_struct* csObjFixture_touchCount_Get_out_struct_cvPtr;

class  csObjFixture_touchCount_Get_out_struct_var
{
    public:

    csObjFixture_touchCount_Get_out_struct_var ();

    csObjFixture_touchCount_Get_out_struct_var (csObjFixture_touchCount_Get_out_struct *_p);

    csObjFixture_touchCount_Get_out_struct_var (const csObjFixture_touchCount_Get_out_struct_var &_s);

    csObjFixture_touchCount_Get_out_struct_var &operator= (csObjFixture_touchCount_Get_out_struct *_p);

    csObjFixture_touchCount_Get_out_struct_var &operator= (const csObjFixture_touchCount_Get_out_struct_var &_s);

    ~csObjFixture_touchCount_Get_out_struct_var ();

    csObjFixture_touchCount_Get_out_struct* operator-> ();

    const csObjFixture_touchCount_Get_out_struct& in() const;
    csObjFixture_touchCount_Get_out_struct& inout();
    csObjFixture_touchCount_Get_out_struct*& out();
    csObjFixture_touchCount_Get_out_struct* _retn();

    operator csObjFixture_touchCount_Get_out_struct_cvPtr () const;

    operator csObjFixture_touchCount_Get_out_struct_vPtr& ();

    operator const csObjFixture_touchCount_Get_out_struct& () const;

    operator csObjFixture_touchCount_Get_out_struct& ();

    protected:
    csObjFixture_touchCount_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Get_out_struct;
    typedef csObjFixture_touchCount_Get_out_struct csObjFixture_touchCount_Get_out;
    typedef csObjFixture_touchCount_Get_out_struct_var csObjFixture_touchCount_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Get_out;
    class  csObjWafer_userDataInfo_GetDR_in_struct_var;
    struct  csObjWafer_userDataInfo_GetDR_in_struct {
        typedef csObjWafer_userDataInfo_GetDR_in_struct_var _var_type;
       ::objectIdentifier waferID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjWafer_userDataInfo_GetDR_in_struct();
       csObjWafer_userDataInfo_GetDR_in_struct(const csObjWafer_userDataInfo_GetDR_in_struct&);
       csObjWafer_userDataInfo_GetDR_in_struct& operator=(const csObjWafer_userDataInfo_GetDR_in_struct&);
       static CORBA::Info<csObjWafer_userDataInfo_GetDR_in_struct> csObjWafer_userDataInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjWafer_userDataInfo_GetDR_in_struct


typedef csObjWafer_userDataInfo_GetDR_in_struct* csObjWafer_userDataInfo_GetDR_in_struct_vPtr;
typedef const csObjWafer_userDataInfo_GetDR_in_struct* csObjWafer_userDataInfo_GetDR_in_struct_cvPtr;

class  csObjWafer_userDataInfo_GetDR_in_struct_var
{
    public:

    csObjWafer_userDataInfo_GetDR_in_struct_var ();

    csObjWafer_userDataInfo_GetDR_in_struct_var (csObjWafer_userDataInfo_GetDR_in_struct *_p);

    csObjWafer_userDataInfo_GetDR_in_struct_var (const csObjWafer_userDataInfo_GetDR_in_struct_var &_s);

    csObjWafer_userDataInfo_GetDR_in_struct_var &operator= (csObjWafer_userDataInfo_GetDR_in_struct *_p);

    csObjWafer_userDataInfo_GetDR_in_struct_var &operator= (const csObjWafer_userDataInfo_GetDR_in_struct_var &_s);

    ~csObjWafer_userDataInfo_GetDR_in_struct_var ();

    csObjWafer_userDataInfo_GetDR_in_struct* operator-> ();

    const csObjWafer_userDataInfo_GetDR_in_struct& in() const;
    csObjWafer_userDataInfo_GetDR_in_struct& inout();
    csObjWafer_userDataInfo_GetDR_in_struct*& out();
    csObjWafer_userDataInfo_GetDR_in_struct* _retn();

    operator csObjWafer_userDataInfo_GetDR_in_struct_cvPtr () const;

    operator csObjWafer_userDataInfo_GetDR_in_struct_vPtr& ();

    operator const csObjWafer_userDataInfo_GetDR_in_struct& () const;

    operator csObjWafer_userDataInfo_GetDR_in_struct& ();

    protected:
    csObjWafer_userDataInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjWafer_userDataInfo_GetDR_in_struct;
    typedef csObjWafer_userDataInfo_GetDR_in_struct csObjWafer_userDataInfo_GetDR_in;
    typedef csObjWafer_userDataInfo_GetDR_in_struct_var csObjWafer_userDataInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjWafer_userDataInfo_GetDR_in;
    class  csObjWafer_userDataInfo_GetDR_out_struct_var;
    struct  csObjWafer_userDataInfo_GetDR_out_struct {
        typedef csObjWafer_userDataInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjWafer_userDataInfo_GetDR_out_struct();
       csObjWafer_userDataInfo_GetDR_out_struct(const csObjWafer_userDataInfo_GetDR_out_struct&);
       csObjWafer_userDataInfo_GetDR_out_struct& operator=(const csObjWafer_userDataInfo_GetDR_out_struct&);
       static CORBA::Info<csObjWafer_userDataInfo_GetDR_out_struct> csObjWafer_userDataInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjWafer_userDataInfo_GetDR_out_struct


typedef csObjWafer_userDataInfo_GetDR_out_struct* csObjWafer_userDataInfo_GetDR_out_struct_vPtr;
typedef const csObjWafer_userDataInfo_GetDR_out_struct* csObjWafer_userDataInfo_GetDR_out_struct_cvPtr;

class  csObjWafer_userDataInfo_GetDR_out_struct_var
{
    public:

    csObjWafer_userDataInfo_GetDR_out_struct_var ();

    csObjWafer_userDataInfo_GetDR_out_struct_var (csObjWafer_userDataInfo_GetDR_out_struct *_p);

    csObjWafer_userDataInfo_GetDR_out_struct_var (const csObjWafer_userDataInfo_GetDR_out_struct_var &_s);

    csObjWafer_userDataInfo_GetDR_out_struct_var &operator= (csObjWafer_userDataInfo_GetDR_out_struct *_p);

    csObjWafer_userDataInfo_GetDR_out_struct_var &operator= (const csObjWafer_userDataInfo_GetDR_out_struct_var &_s);

    ~csObjWafer_userDataInfo_GetDR_out_struct_var ();

    csObjWafer_userDataInfo_GetDR_out_struct* operator-> ();

    const csObjWafer_userDataInfo_GetDR_out_struct& in() const;
    csObjWafer_userDataInfo_GetDR_out_struct& inout();
    csObjWafer_userDataInfo_GetDR_out_struct*& out();
    csObjWafer_userDataInfo_GetDR_out_struct* _retn();

    operator csObjWafer_userDataInfo_GetDR_out_struct_cvPtr () const;

    operator csObjWafer_userDataInfo_GetDR_out_struct_vPtr& ();

    operator const csObjWafer_userDataInfo_GetDR_out_struct& () const;

    operator csObjWafer_userDataInfo_GetDR_out_struct& ();

    protected:
    csObjWafer_userDataInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjWafer_userDataInfo_GetDR_out_struct;
    typedef csObjWafer_userDataInfo_GetDR_out_struct csObjWafer_userDataInfo_GetDR_out;
    typedef csObjWafer_userDataInfo_GetDR_out_struct_var csObjWafer_userDataInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjWafer_userDataInfo_GetDR_out;
    class  csObjDurable_userDataInfo_GetDR_in_struct_var;
    struct  csObjDurable_userDataInfo_GetDR_in_struct {
        typedef csObjDurable_userDataInfo_GetDR_in_struct_var _var_type;
       ::objectIdentifier durableID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDurable_userDataInfo_GetDR_in_struct();
       csObjDurable_userDataInfo_GetDR_in_struct(const csObjDurable_userDataInfo_GetDR_in_struct&);
       csObjDurable_userDataInfo_GetDR_in_struct& operator=(const csObjDurable_userDataInfo_GetDR_in_struct&);
       static CORBA::Info<csObjDurable_userDataInfo_GetDR_in_struct> csObjDurable_userDataInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDurable_userDataInfo_GetDR_in_struct


typedef csObjDurable_userDataInfo_GetDR_in_struct* csObjDurable_userDataInfo_GetDR_in_struct_vPtr;
typedef const csObjDurable_userDataInfo_GetDR_in_struct* csObjDurable_userDataInfo_GetDR_in_struct_cvPtr;

class  csObjDurable_userDataInfo_GetDR_in_struct_var
{
    public:

    csObjDurable_userDataInfo_GetDR_in_struct_var ();

    csObjDurable_userDataInfo_GetDR_in_struct_var (csObjDurable_userDataInfo_GetDR_in_struct *_p);

    csObjDurable_userDataInfo_GetDR_in_struct_var (const csObjDurable_userDataInfo_GetDR_in_struct_var &_s);

    csObjDurable_userDataInfo_GetDR_in_struct_var &operator= (csObjDurable_userDataInfo_GetDR_in_struct *_p);

    csObjDurable_userDataInfo_GetDR_in_struct_var &operator= (const csObjDurable_userDataInfo_GetDR_in_struct_var &_s);

    ~csObjDurable_userDataInfo_GetDR_in_struct_var ();

    csObjDurable_userDataInfo_GetDR_in_struct* operator-> ();

    const csObjDurable_userDataInfo_GetDR_in_struct& in() const;
    csObjDurable_userDataInfo_GetDR_in_struct& inout();
    csObjDurable_userDataInfo_GetDR_in_struct*& out();
    csObjDurable_userDataInfo_GetDR_in_struct* _retn();

    operator csObjDurable_userDataInfo_GetDR_in_struct_cvPtr () const;

    operator csObjDurable_userDataInfo_GetDR_in_struct_vPtr& ();

    operator const csObjDurable_userDataInfo_GetDR_in_struct& () const;

    operator csObjDurable_userDataInfo_GetDR_in_struct& ();

    protected:
    csObjDurable_userDataInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_userDataInfo_GetDR_in_struct;
    typedef csObjDurable_userDataInfo_GetDR_in_struct csObjDurable_userDataInfo_GetDR_in;
    typedef csObjDurable_userDataInfo_GetDR_in_struct_var csObjDurable_userDataInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_userDataInfo_GetDR_in;
    class  csObjDurable_userDataInfo_GetDR_out_struct_var;
    struct  csObjDurable_userDataInfo_GetDR_out_struct {
        typedef csObjDurable_userDataInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDurable_userDataInfo_GetDR_out_struct();
       csObjDurable_userDataInfo_GetDR_out_struct(const csObjDurable_userDataInfo_GetDR_out_struct&);
       csObjDurable_userDataInfo_GetDR_out_struct& operator=(const csObjDurable_userDataInfo_GetDR_out_struct&);
       static CORBA::Info<csObjDurable_userDataInfo_GetDR_out_struct> csObjDurable_userDataInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDurable_userDataInfo_GetDR_out_struct


typedef csObjDurable_userDataInfo_GetDR_out_struct* csObjDurable_userDataInfo_GetDR_out_struct_vPtr;
typedef const csObjDurable_userDataInfo_GetDR_out_struct* csObjDurable_userDataInfo_GetDR_out_struct_cvPtr;

class  csObjDurable_userDataInfo_GetDR_out_struct_var
{
    public:

    csObjDurable_userDataInfo_GetDR_out_struct_var ();

    csObjDurable_userDataInfo_GetDR_out_struct_var (csObjDurable_userDataInfo_GetDR_out_struct *_p);

    csObjDurable_userDataInfo_GetDR_out_struct_var (const csObjDurable_userDataInfo_GetDR_out_struct_var &_s);

    csObjDurable_userDataInfo_GetDR_out_struct_var &operator= (csObjDurable_userDataInfo_GetDR_out_struct *_p);

    csObjDurable_userDataInfo_GetDR_out_struct_var &operator= (const csObjDurable_userDataInfo_GetDR_out_struct_var &_s);

    ~csObjDurable_userDataInfo_GetDR_out_struct_var ();

    csObjDurable_userDataInfo_GetDR_out_struct* operator-> ();

    const csObjDurable_userDataInfo_GetDR_out_struct& in() const;
    csObjDurable_userDataInfo_GetDR_out_struct& inout();
    csObjDurable_userDataInfo_GetDR_out_struct*& out();
    csObjDurable_userDataInfo_GetDR_out_struct* _retn();

    operator csObjDurable_userDataInfo_GetDR_out_struct_cvPtr () const;

    operator csObjDurable_userDataInfo_GetDR_out_struct_vPtr& ();

    operator const csObjDurable_userDataInfo_GetDR_out_struct& () const;

    operator csObjDurable_userDataInfo_GetDR_out_struct& ();

    protected:
    csObjDurable_userDataInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_userDataInfo_GetDR_out_struct;
    typedef csObjDurable_userDataInfo_GetDR_out_struct csObjDurable_userDataInfo_GetDR_out;
    typedef csObjDurable_userDataInfo_GetDR_out_struct_var csObjDurable_userDataInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_userDataInfo_GetDR_out;
    class  csObjUserData_GetByOperation_in_struct_var;
    struct  csObjUserData_GetByOperation_in_struct {
        typedef csObjUserData_GetByOperation_in_struct_var _var_type;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::stringSequence userDataNameSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjUserData_GetByOperation_in_struct();
       csObjUserData_GetByOperation_in_struct(const csObjUserData_GetByOperation_in_struct&);
       csObjUserData_GetByOperation_in_struct& operator=(const csObjUserData_GetByOperation_in_struct&);
       static CORBA::Info<csObjUserData_GetByOperation_in_struct> csObjUserData_GetByOperation_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjUserData_GetByOperation_in_struct


typedef csObjUserData_GetByOperation_in_struct* csObjUserData_GetByOperation_in_struct_vPtr;
typedef const csObjUserData_GetByOperation_in_struct* csObjUserData_GetByOperation_in_struct_cvPtr;

class  csObjUserData_GetByOperation_in_struct_var
{
    public:

    csObjUserData_GetByOperation_in_struct_var ();

    csObjUserData_GetByOperation_in_struct_var (csObjUserData_GetByOperation_in_struct *_p);

    csObjUserData_GetByOperation_in_struct_var (const csObjUserData_GetByOperation_in_struct_var &_s);

    csObjUserData_GetByOperation_in_struct_var &operator= (csObjUserData_GetByOperation_in_struct *_p);

    csObjUserData_GetByOperation_in_struct_var &operator= (const csObjUserData_GetByOperation_in_struct_var &_s);

    ~csObjUserData_GetByOperation_in_struct_var ();

    csObjUserData_GetByOperation_in_struct* operator-> ();

    const csObjUserData_GetByOperation_in_struct& in() const;
    csObjUserData_GetByOperation_in_struct& inout();
    csObjUserData_GetByOperation_in_struct*& out();
    csObjUserData_GetByOperation_in_struct* _retn();

    operator csObjUserData_GetByOperation_in_struct_cvPtr () const;

    operator csObjUserData_GetByOperation_in_struct_vPtr& ();

    operator const csObjUserData_GetByOperation_in_struct& () const;

    operator csObjUserData_GetByOperation_in_struct& ();

    protected:
    csObjUserData_GetByOperation_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByOperation_in_struct;
    typedef csObjUserData_GetByOperation_in_struct csObjUserData_GetByOperation_in;
    typedef csObjUserData_GetByOperation_in_struct_var csObjUserData_GetByOperation_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByOperation_in;
    class  csObjUserData_GetByOperation_out_struct_var;
    struct  csObjUserData_GetByOperation_out_struct {
        typedef csObjUserData_GetByOperation_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjUserData_GetByOperation_out_struct();
       csObjUserData_GetByOperation_out_struct(const csObjUserData_GetByOperation_out_struct&);
       csObjUserData_GetByOperation_out_struct& operator=(const csObjUserData_GetByOperation_out_struct&);
       static CORBA::Info<csObjUserData_GetByOperation_out_struct> csObjUserData_GetByOperation_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjUserData_GetByOperation_out_struct


typedef csObjUserData_GetByOperation_out_struct* csObjUserData_GetByOperation_out_struct_vPtr;
typedef const csObjUserData_GetByOperation_out_struct* csObjUserData_GetByOperation_out_struct_cvPtr;

class  csObjUserData_GetByOperation_out_struct_var
{
    public:

    csObjUserData_GetByOperation_out_struct_var ();

    csObjUserData_GetByOperation_out_struct_var (csObjUserData_GetByOperation_out_struct *_p);

    csObjUserData_GetByOperation_out_struct_var (const csObjUserData_GetByOperation_out_struct_var &_s);

    csObjUserData_GetByOperation_out_struct_var &operator= (csObjUserData_GetByOperation_out_struct *_p);

    csObjUserData_GetByOperation_out_struct_var &operator= (const csObjUserData_GetByOperation_out_struct_var &_s);

    ~csObjUserData_GetByOperation_out_struct_var ();

    csObjUserData_GetByOperation_out_struct* operator-> ();

    const csObjUserData_GetByOperation_out_struct& in() const;
    csObjUserData_GetByOperation_out_struct& inout();
    csObjUserData_GetByOperation_out_struct*& out();
    csObjUserData_GetByOperation_out_struct* _retn();

    operator csObjUserData_GetByOperation_out_struct_cvPtr () const;

    operator csObjUserData_GetByOperation_out_struct_vPtr& ();

    operator const csObjUserData_GetByOperation_out_struct& () const;

    operator csObjUserData_GetByOperation_out_struct& ();

    protected:
    csObjUserData_GetByOperation_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByOperation_out_struct;
    typedef csObjUserData_GetByOperation_out_struct csObjUserData_GetByOperation_out;
    typedef csObjUserData_GetByOperation_out_struct_var csObjUserData_GetByOperation_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByOperation_out;
    class  csObjAPC_LithoAvailable_CheckCondition_in_struct_var;
    struct  csObjAPC_LithoAvailable_CheckCondition_in_struct {
        typedef csObjAPC_LithoAvailable_CheckCondition_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoAvailable_CheckCondition_in_struct();
       csObjAPC_LithoAvailable_CheckCondition_in_struct(const csObjAPC_LithoAvailable_CheckCondition_in_struct&);
       csObjAPC_LithoAvailable_CheckCondition_in_struct& operator=(const csObjAPC_LithoAvailable_CheckCondition_in_struct&);
       static CORBA::Info<csObjAPC_LithoAvailable_CheckCondition_in_struct> csObjAPC_LithoAvailable_CheckCondition_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoAvailable_CheckCondition_in_struct


typedef csObjAPC_LithoAvailable_CheckCondition_in_struct* csObjAPC_LithoAvailable_CheckCondition_in_struct_vPtr;
typedef const csObjAPC_LithoAvailable_CheckCondition_in_struct* csObjAPC_LithoAvailable_CheckCondition_in_struct_cvPtr;

class  csObjAPC_LithoAvailable_CheckCondition_in_struct_var
{
    public:

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var ();

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var (csObjAPC_LithoAvailable_CheckCondition_in_struct *_p);

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var (const csObjAPC_LithoAvailable_CheckCondition_in_struct_var &_s);

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var &operator= (csObjAPC_LithoAvailable_CheckCondition_in_struct *_p);

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var &operator= (const csObjAPC_LithoAvailable_CheckCondition_in_struct_var &_s);

    ~csObjAPC_LithoAvailable_CheckCondition_in_struct_var ();

    csObjAPC_LithoAvailable_CheckCondition_in_struct* operator-> ();

    const csObjAPC_LithoAvailable_CheckCondition_in_struct& in() const;
    csObjAPC_LithoAvailable_CheckCondition_in_struct& inout();
    csObjAPC_LithoAvailable_CheckCondition_in_struct*& out();
    csObjAPC_LithoAvailable_CheckCondition_in_struct* _retn();

    operator csObjAPC_LithoAvailable_CheckCondition_in_struct_cvPtr () const;

    operator csObjAPC_LithoAvailable_CheckCondition_in_struct_vPtr& ();

    operator const csObjAPC_LithoAvailable_CheckCondition_in_struct& () const;

    operator csObjAPC_LithoAvailable_CheckCondition_in_struct& ();

    protected:
    csObjAPC_LithoAvailable_CheckCondition_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoAvailable_CheckCondition_in_struct;
    typedef csObjAPC_LithoAvailable_CheckCondition_in_struct csObjAPC_LithoAvailable_CheckCondition_in;
    typedef csObjAPC_LithoAvailable_CheckCondition_in_struct_var csObjAPC_LithoAvailable_CheckCondition_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoAvailable_CheckCondition_in;
    class  csObjAPC_LithoAvailable_CheckCondition_out_struct_var;
    struct  csObjAPC_LithoAvailable_CheckCondition_out_struct {
        typedef csObjAPC_LithoAvailable_CheckCondition_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem inquireType;
       ::CORBA::Boolean recommendFlag;
       ::CORBA::Boolean usedFlag;
       ::CORBA::Boolean metrologyFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoAvailable_CheckCondition_out_struct();
       csObjAPC_LithoAvailable_CheckCondition_out_struct(const csObjAPC_LithoAvailable_CheckCondition_out_struct&);
       csObjAPC_LithoAvailable_CheckCondition_out_struct& operator=(const csObjAPC_LithoAvailable_CheckCondition_out_struct&);
       static CORBA::Info<csObjAPC_LithoAvailable_CheckCondition_out_struct> csObjAPC_LithoAvailable_CheckCondition_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoAvailable_CheckCondition_out_struct


typedef csObjAPC_LithoAvailable_CheckCondition_out_struct* csObjAPC_LithoAvailable_CheckCondition_out_struct_vPtr;
typedef const csObjAPC_LithoAvailable_CheckCondition_out_struct* csObjAPC_LithoAvailable_CheckCondition_out_struct_cvPtr;

class  csObjAPC_LithoAvailable_CheckCondition_out_struct_var
{
    public:

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var ();

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var (csObjAPC_LithoAvailable_CheckCondition_out_struct *_p);

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var (const csObjAPC_LithoAvailable_CheckCondition_out_struct_var &_s);

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var &operator= (csObjAPC_LithoAvailable_CheckCondition_out_struct *_p);

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var &operator= (const csObjAPC_LithoAvailable_CheckCondition_out_struct_var &_s);

    ~csObjAPC_LithoAvailable_CheckCondition_out_struct_var ();

    csObjAPC_LithoAvailable_CheckCondition_out_struct* operator-> ();

    const csObjAPC_LithoAvailable_CheckCondition_out_struct& in() const;
    csObjAPC_LithoAvailable_CheckCondition_out_struct& inout();
    csObjAPC_LithoAvailable_CheckCondition_out_struct*& out();
    csObjAPC_LithoAvailable_CheckCondition_out_struct* _retn();

    operator csObjAPC_LithoAvailable_CheckCondition_out_struct_cvPtr () const;

    operator csObjAPC_LithoAvailable_CheckCondition_out_struct_vPtr& ();

    operator const csObjAPC_LithoAvailable_CheckCondition_out_struct& () const;

    operator csObjAPC_LithoAvailable_CheckCondition_out_struct& ();

    protected:
    csObjAPC_LithoAvailable_CheckCondition_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoAvailable_CheckCondition_out_struct;
    typedef csObjAPC_LithoAvailable_CheckCondition_out_struct csObjAPC_LithoAvailable_CheckCondition_out;
    typedef csObjAPC_LithoAvailable_CheckCondition_out_struct_var csObjAPC_LithoAvailable_CheckCondition_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoAvailable_CheckCondition_out;
    class  csObjAPC_LithoLotDataInfo_Get_in_struct_var;
    struct  csObjAPC_LithoLotDataInfo_Get_in_struct {
        typedef csObjAPC_LithoLotDataInfo_Get_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoLotDataInfo_Get_in_struct();
       csObjAPC_LithoLotDataInfo_Get_in_struct(const csObjAPC_LithoLotDataInfo_Get_in_struct&);
       csObjAPC_LithoLotDataInfo_Get_in_struct& operator=(const csObjAPC_LithoLotDataInfo_Get_in_struct&);
       static CORBA::Info<csObjAPC_LithoLotDataInfo_Get_in_struct> csObjAPC_LithoLotDataInfo_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoLotDataInfo_Get_in_struct


typedef csObjAPC_LithoLotDataInfo_Get_in_struct* csObjAPC_LithoLotDataInfo_Get_in_struct_vPtr;
typedef const csObjAPC_LithoLotDataInfo_Get_in_struct* csObjAPC_LithoLotDataInfo_Get_in_struct_cvPtr;

class  csObjAPC_LithoLotDataInfo_Get_in_struct_var
{
    public:

    csObjAPC_LithoLotDataInfo_Get_in_struct_var ();

    csObjAPC_LithoLotDataInfo_Get_in_struct_var (csObjAPC_LithoLotDataInfo_Get_in_struct *_p);

    csObjAPC_LithoLotDataInfo_Get_in_struct_var (const csObjAPC_LithoLotDataInfo_Get_in_struct_var &_s);

    csObjAPC_LithoLotDataInfo_Get_in_struct_var &operator= (csObjAPC_LithoLotDataInfo_Get_in_struct *_p);

    csObjAPC_LithoLotDataInfo_Get_in_struct_var &operator= (const csObjAPC_LithoLotDataInfo_Get_in_struct_var &_s);

    ~csObjAPC_LithoLotDataInfo_Get_in_struct_var ();

    csObjAPC_LithoLotDataInfo_Get_in_struct* operator-> ();

    const csObjAPC_LithoLotDataInfo_Get_in_struct& in() const;
    csObjAPC_LithoLotDataInfo_Get_in_struct& inout();
    csObjAPC_LithoLotDataInfo_Get_in_struct*& out();
    csObjAPC_LithoLotDataInfo_Get_in_struct* _retn();

    operator csObjAPC_LithoLotDataInfo_Get_in_struct_cvPtr () const;

    operator csObjAPC_LithoLotDataInfo_Get_in_struct_vPtr& ();

    operator const csObjAPC_LithoLotDataInfo_Get_in_struct& () const;

    operator csObjAPC_LithoLotDataInfo_Get_in_struct& ();

    protected:
    csObjAPC_LithoLotDataInfo_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoLotDataInfo_Get_in_struct;
    typedef csObjAPC_LithoLotDataInfo_Get_in_struct csObjAPC_LithoLotDataInfo_Get_in;
    typedef csObjAPC_LithoLotDataInfo_Get_in_struct_var csObjAPC_LithoLotDataInfo_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoLotDataInfo_Get_in;
    class  csObjAPC_LithoLotDataInfo_Get_out_struct_var;
    struct  csObjAPC_LithoLotDataInfo_Get_out_struct {
        typedef csObjAPC_LithoLotDataInfo_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csLithoLotDataInfo strLithoLotDataInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoLotDataInfo_Get_out_struct();
       csObjAPC_LithoLotDataInfo_Get_out_struct(const csObjAPC_LithoLotDataInfo_Get_out_struct&);
       csObjAPC_LithoLotDataInfo_Get_out_struct& operator=(const csObjAPC_LithoLotDataInfo_Get_out_struct&);
       static CORBA::Info<csObjAPC_LithoLotDataInfo_Get_out_struct> csObjAPC_LithoLotDataInfo_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoLotDataInfo_Get_out_struct


typedef csObjAPC_LithoLotDataInfo_Get_out_struct* csObjAPC_LithoLotDataInfo_Get_out_struct_vPtr;
typedef const csObjAPC_LithoLotDataInfo_Get_out_struct* csObjAPC_LithoLotDataInfo_Get_out_struct_cvPtr;

class  csObjAPC_LithoLotDataInfo_Get_out_struct_var
{
    public:

    csObjAPC_LithoLotDataInfo_Get_out_struct_var ();

    csObjAPC_LithoLotDataInfo_Get_out_struct_var (csObjAPC_LithoLotDataInfo_Get_out_struct *_p);

    csObjAPC_LithoLotDataInfo_Get_out_struct_var (const csObjAPC_LithoLotDataInfo_Get_out_struct_var &_s);

    csObjAPC_LithoLotDataInfo_Get_out_struct_var &operator= (csObjAPC_LithoLotDataInfo_Get_out_struct *_p);

    csObjAPC_LithoLotDataInfo_Get_out_struct_var &operator= (const csObjAPC_LithoLotDataInfo_Get_out_struct_var &_s);

    ~csObjAPC_LithoLotDataInfo_Get_out_struct_var ();

    csObjAPC_LithoLotDataInfo_Get_out_struct* operator-> ();

    const csObjAPC_LithoLotDataInfo_Get_out_struct& in() const;
    csObjAPC_LithoLotDataInfo_Get_out_struct& inout();
    csObjAPC_LithoLotDataInfo_Get_out_struct*& out();
    csObjAPC_LithoLotDataInfo_Get_out_struct* _retn();

    operator csObjAPC_LithoLotDataInfo_Get_out_struct_cvPtr () const;

    operator csObjAPC_LithoLotDataInfo_Get_out_struct_vPtr& ();

    operator const csObjAPC_LithoLotDataInfo_Get_out_struct& () const;

    operator csObjAPC_LithoLotDataInfo_Get_out_struct& ();

    protected:
    csObjAPC_LithoLotDataInfo_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoLotDataInfo_Get_out_struct;
    typedef csObjAPC_LithoLotDataInfo_Get_out_struct csObjAPC_LithoLotDataInfo_Get_out;
    typedef csObjAPC_LithoLotDataInfo_Get_out_struct_var csObjAPC_LithoLotDataInfo_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoLotDataInfo_Get_out;
    class  csObjAPC_LithoContextInfo_Get_in_struct_var;
    struct  csObjAPC_LithoContextInfo_Get_in_struct {
        typedef csObjAPC_LithoContextInfo_Get_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::objectIdentifier lotID;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::pptStartReticleSequence strStartReticleSeq;
       ::pptStartRecipeParameterSequence strStartRecipeParameterSeq;
       ::CORBA::String_StructElem action;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoContextInfo_Get_in_struct();
       csObjAPC_LithoContextInfo_Get_in_struct(const csObjAPC_LithoContextInfo_Get_in_struct&);
       csObjAPC_LithoContextInfo_Get_in_struct& operator=(const csObjAPC_LithoContextInfo_Get_in_struct&);
       static CORBA::Info<csObjAPC_LithoContextInfo_Get_in_struct> csObjAPC_LithoContextInfo_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoContextInfo_Get_in_struct


typedef csObjAPC_LithoContextInfo_Get_in_struct* csObjAPC_LithoContextInfo_Get_in_struct_vPtr;
typedef const csObjAPC_LithoContextInfo_Get_in_struct* csObjAPC_LithoContextInfo_Get_in_struct_cvPtr;

class  csObjAPC_LithoContextInfo_Get_in_struct_var
{
    public:

    csObjAPC_LithoContextInfo_Get_in_struct_var ();

    csObjAPC_LithoContextInfo_Get_in_struct_var (csObjAPC_LithoContextInfo_Get_in_struct *_p);

    csObjAPC_LithoContextInfo_Get_in_struct_var (const csObjAPC_LithoContextInfo_Get_in_struct_var &_s);

    csObjAPC_LithoContextInfo_Get_in_struct_var &operator= (csObjAPC_LithoContextInfo_Get_in_struct *_p);

    csObjAPC_LithoContextInfo_Get_in_struct_var &operator= (const csObjAPC_LithoContextInfo_Get_in_struct_var &_s);

    ~csObjAPC_LithoContextInfo_Get_in_struct_var ();

    csObjAPC_LithoContextInfo_Get_in_struct* operator-> ();

    const csObjAPC_LithoContextInfo_Get_in_struct& in() const;
    csObjAPC_LithoContextInfo_Get_in_struct& inout();
    csObjAPC_LithoContextInfo_Get_in_struct*& out();
    csObjAPC_LithoContextInfo_Get_in_struct* _retn();

    operator csObjAPC_LithoContextInfo_Get_in_struct_cvPtr () const;

    operator csObjAPC_LithoContextInfo_Get_in_struct_vPtr& ();

    operator const csObjAPC_LithoContextInfo_Get_in_struct& () const;

    operator csObjAPC_LithoContextInfo_Get_in_struct& ();

    protected:
    csObjAPC_LithoContextInfo_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoContextInfo_Get_in_struct;
    typedef csObjAPC_LithoContextInfo_Get_in_struct csObjAPC_LithoContextInfo_Get_in;
    typedef csObjAPC_LithoContextInfo_Get_in_struct_var csObjAPC_LithoContextInfo_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoContextInfo_Get_in;
    class  csObjAPC_LithoContextInfo_Get_out_struct_var;
    struct  csObjAPC_LithoContextInfo_Get_out_struct {
        typedef csObjAPC_LithoContextInfo_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csAPCLithoContextInfo strAPCLithoContextInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoContextInfo_Get_out_struct();
       csObjAPC_LithoContextInfo_Get_out_struct(const csObjAPC_LithoContextInfo_Get_out_struct&);
       csObjAPC_LithoContextInfo_Get_out_struct& operator=(const csObjAPC_LithoContextInfo_Get_out_struct&);
       static CORBA::Info<csObjAPC_LithoContextInfo_Get_out_struct> csObjAPC_LithoContextInfo_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoContextInfo_Get_out_struct


typedef csObjAPC_LithoContextInfo_Get_out_struct* csObjAPC_LithoContextInfo_Get_out_struct_vPtr;
typedef const csObjAPC_LithoContextInfo_Get_out_struct* csObjAPC_LithoContextInfo_Get_out_struct_cvPtr;

class  csObjAPC_LithoContextInfo_Get_out_struct_var
{
    public:

    csObjAPC_LithoContextInfo_Get_out_struct_var ();

    csObjAPC_LithoContextInfo_Get_out_struct_var (csObjAPC_LithoContextInfo_Get_out_struct *_p);

    csObjAPC_LithoContextInfo_Get_out_struct_var (const csObjAPC_LithoContextInfo_Get_out_struct_var &_s);

    csObjAPC_LithoContextInfo_Get_out_struct_var &operator= (csObjAPC_LithoContextInfo_Get_out_struct *_p);

    csObjAPC_LithoContextInfo_Get_out_struct_var &operator= (const csObjAPC_LithoContextInfo_Get_out_struct_var &_s);

    ~csObjAPC_LithoContextInfo_Get_out_struct_var ();

    csObjAPC_LithoContextInfo_Get_out_struct* operator-> ();

    const csObjAPC_LithoContextInfo_Get_out_struct& in() const;
    csObjAPC_LithoContextInfo_Get_out_struct& inout();
    csObjAPC_LithoContextInfo_Get_out_struct*& out();
    csObjAPC_LithoContextInfo_Get_out_struct* _retn();

    operator csObjAPC_LithoContextInfo_Get_out_struct_cvPtr () const;

    operator csObjAPC_LithoContextInfo_Get_out_struct_vPtr& ();

    operator const csObjAPC_LithoContextInfo_Get_out_struct& () const;

    operator csObjAPC_LithoContextInfo_Get_out_struct& ();

    protected:
    csObjAPC_LithoContextInfo_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoContextInfo_Get_out_struct;
    typedef csObjAPC_LithoContextInfo_Get_out_struct csObjAPC_LithoContextInfo_Get_out;
    typedef csObjAPC_LithoContextInfo_Get_out_struct_var csObjAPC_LithoContextInfo_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoContextInfo_Get_out;
    class  csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var;
    struct  csObjAPCMgr_SendLithoUsedInfoReq_in_struct {
        typedef csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoUsedInfoReq_in_struct();
       csObjAPCMgr_SendLithoUsedInfoReq_in_struct(const csObjAPCMgr_SendLithoUsedInfoReq_in_struct&);
       csObjAPCMgr_SendLithoUsedInfoReq_in_struct& operator=(const csObjAPCMgr_SendLithoUsedInfoReq_in_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoUsedInfoReq_in_struct> csObjAPCMgr_SendLithoUsedInfoReq_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoUsedInfoReq_in_struct


typedef csObjAPCMgr_SendLithoUsedInfoReq_in_struct* csObjAPCMgr_SendLithoUsedInfoReq_in_struct_vPtr;
typedef const csObjAPCMgr_SendLithoUsedInfoReq_in_struct* csObjAPCMgr_SendLithoUsedInfoReq_in_struct_cvPtr;

class  csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var
{
    public:

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var ();

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var (csObjAPCMgr_SendLithoUsedInfoReq_in_struct *_p);

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var (const csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var &_s);

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var &operator= (csObjAPCMgr_SendLithoUsedInfoReq_in_struct *_p);

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var &operator= (const csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var &_s);

    ~csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var ();

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct* operator-> ();

    const csObjAPCMgr_SendLithoUsedInfoReq_in_struct& in() const;
    csObjAPCMgr_SendLithoUsedInfoReq_in_struct& inout();
    csObjAPCMgr_SendLithoUsedInfoReq_in_struct*& out();
    csObjAPCMgr_SendLithoUsedInfoReq_in_struct* _retn();

    operator csObjAPCMgr_SendLithoUsedInfoReq_in_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoUsedInfoReq_in_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoUsedInfoReq_in_struct& () const;

    operator csObjAPCMgr_SendLithoUsedInfoReq_in_struct& ();

    protected:
    csObjAPCMgr_SendLithoUsedInfoReq_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoUsedInfoReq_in_struct;
    typedef csObjAPCMgr_SendLithoUsedInfoReq_in_struct csObjAPCMgr_SendLithoUsedInfoReq_in;
    typedef csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var csObjAPCMgr_SendLithoUsedInfoReq_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoUsedInfoReq_in;
    class  csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var;
    struct  csObjAPCMgr_SendLithoUsedInfoReq_out_struct {
        typedef csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoUsedInfoReq_out_struct();
       csObjAPCMgr_SendLithoUsedInfoReq_out_struct(const csObjAPCMgr_SendLithoUsedInfoReq_out_struct&);
       csObjAPCMgr_SendLithoUsedInfoReq_out_struct& operator=(const csObjAPCMgr_SendLithoUsedInfoReq_out_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoUsedInfoReq_out_struct> csObjAPCMgr_SendLithoUsedInfoReq_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoUsedInfoReq_out_struct


typedef csObjAPCMgr_SendLithoUsedInfoReq_out_struct* csObjAPCMgr_SendLithoUsedInfoReq_out_struct_vPtr;
typedef const csObjAPCMgr_SendLithoUsedInfoReq_out_struct* csObjAPCMgr_SendLithoUsedInfoReq_out_struct_cvPtr;

class  csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var
{
    public:

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var ();

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var (csObjAPCMgr_SendLithoUsedInfoReq_out_struct *_p);

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var (const csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var &_s);

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var &operator= (csObjAPCMgr_SendLithoUsedInfoReq_out_struct *_p);

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var &operator= (const csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var &_s);

    ~csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var ();

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct* operator-> ();

    const csObjAPCMgr_SendLithoUsedInfoReq_out_struct& in() const;
    csObjAPCMgr_SendLithoUsedInfoReq_out_struct& inout();
    csObjAPCMgr_SendLithoUsedInfoReq_out_struct*& out();
    csObjAPCMgr_SendLithoUsedInfoReq_out_struct* _retn();

    operator csObjAPCMgr_SendLithoUsedInfoReq_out_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoUsedInfoReq_out_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoUsedInfoReq_out_struct& () const;

    operator csObjAPCMgr_SendLithoUsedInfoReq_out_struct& ();

    protected:
    csObjAPCMgr_SendLithoUsedInfoReq_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoUsedInfoReq_out_struct;
    typedef csObjAPCMgr_SendLithoUsedInfoReq_out_struct csObjAPCMgr_SendLithoUsedInfoReq_out;
    typedef csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var csObjAPCMgr_SendLithoUsedInfoReq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoUsedInfoReq_out;
    class  csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var;
    struct  csObjAPCMgr_SendLithoRecommendInfoInq_in_struct {
        typedef csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::String_StructElem action;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoRecommendInfoInq_in_struct();
       csObjAPCMgr_SendLithoRecommendInfoInq_in_struct(const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct&);
       csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& operator=(const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoRecommendInfoInq_in_struct> csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoRecommendInfoInq_in_struct


typedef csObjAPCMgr_SendLithoRecommendInfoInq_in_struct* csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_vPtr;
typedef const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct* csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_cvPtr;

class  csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var
{
    public:

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var ();

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var (csObjAPCMgr_SendLithoRecommendInfoInq_in_struct *_p);

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var (const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var &_s);

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var &operator= (csObjAPCMgr_SendLithoRecommendInfoInq_in_struct *_p);

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var &operator= (const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var &_s);

    ~csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var ();

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct* operator-> ();

    const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& in() const;
    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& inout();
    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct*& out();
    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct* _retn();

    operator csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& () const;

    operator csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& ();

    protected:
    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoRecommendInfoInq_in_struct;
    typedef csObjAPCMgr_SendLithoRecommendInfoInq_in_struct csObjAPCMgr_SendLithoRecommendInfoInq_in;
    typedef csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var csObjAPCMgr_SendLithoRecommendInfoInq_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoRecommendInfoInq_in;
    class  csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var;
    struct  csObjAPCMgr_SendLithoRecommendInfoInq_out_struct {
        typedef csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoRecommendInfoInq_out_struct();
       csObjAPCMgr_SendLithoRecommendInfoInq_out_struct(const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct&);
       csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& operator=(const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoRecommendInfoInq_out_struct> csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoRecommendInfoInq_out_struct


typedef csObjAPCMgr_SendLithoRecommendInfoInq_out_struct* csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_vPtr;
typedef const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct* csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_cvPtr;

class  csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var
{
    public:

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var ();

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var (csObjAPCMgr_SendLithoRecommendInfoInq_out_struct *_p);

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var (const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var &_s);

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var &operator= (csObjAPCMgr_SendLithoRecommendInfoInq_out_struct *_p);

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var &operator= (const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var &_s);

    ~csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var ();

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct* operator-> ();

    const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& in() const;
    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& inout();
    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct*& out();
    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct* _retn();

    operator csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& () const;

    operator csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& ();

    protected:
    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoRecommendInfoInq_out_struct;
    typedef csObjAPCMgr_SendLithoRecommendInfoInq_out_struct csObjAPCMgr_SendLithoRecommendInfoInq_out;
    typedef csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var csObjAPCMgr_SendLithoRecommendInfoInq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoRecommendInfoInq_out;
    class  csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var;
    struct  csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct {
        typedef csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct();
       csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct(const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct&);
       csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& operator=(const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct> csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct


typedef csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct* csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_vPtr;
typedef const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct* csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_cvPtr;

class  csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var
{
    public:

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var ();

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var (csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct *_p);

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var (const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var &_s);

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var &operator= (csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct *_p);

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var &operator= (const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var &_s);

    ~csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var ();

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct* operator-> ();

    const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& in() const;
    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& inout();
    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct*& out();
    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct* _retn();

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& () const;

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& ();

    protected:
    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct;
    typedef csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct csObjAPCMgr_SendLithoMetrologyInfoReq_in;
    typedef csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var csObjAPCMgr_SendLithoMetrologyInfoReq_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoMetrologyInfoReq_in;
    class  csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var;
    struct  csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct {
        typedef csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct();
       csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct(const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct&);
       csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& operator=(const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct> csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct


typedef csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct* csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_vPtr;
typedef const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct* csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_cvPtr;

class  csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var
{
    public:

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var ();

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var (csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct *_p);

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var (const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var &_s);

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var &operator= (csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct *_p);

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var &operator= (const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var &_s);

    ~csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var ();

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct* operator-> ();

    const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& in() const;
    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& inout();
    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct*& out();
    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct* _retn();

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& () const;

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& ();

    protected:
    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct;
    typedef csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct csObjAPCMgr_SendLithoMetrologyInfoReq_out;
    typedef csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var csObjAPCMgr_SendLithoMetrologyInfoReq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoMetrologyInfoReq_out;
    class  csObjControlJob_BatchSize_Check_out_struct_var;
    struct  csObjControlJob_BatchSize_Check_out_struct {
        typedef csObjControlJob_BatchSize_Check_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjControlJob_BatchSize_Check_out_struct();
       csObjControlJob_BatchSize_Check_out_struct(const csObjControlJob_BatchSize_Check_out_struct&);
       csObjControlJob_BatchSize_Check_out_struct& operator=(const csObjControlJob_BatchSize_Check_out_struct&);
       static CORBA::Info<csObjControlJob_BatchSize_Check_out_struct> csObjControlJob_BatchSize_Check_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjControlJob_BatchSize_Check_out_struct


typedef csObjControlJob_BatchSize_Check_out_struct* csObjControlJob_BatchSize_Check_out_struct_vPtr;
typedef const csObjControlJob_BatchSize_Check_out_struct* csObjControlJob_BatchSize_Check_out_struct_cvPtr;

class  csObjControlJob_BatchSize_Check_out_struct_var
{
    public:

    csObjControlJob_BatchSize_Check_out_struct_var ();

    csObjControlJob_BatchSize_Check_out_struct_var (csObjControlJob_BatchSize_Check_out_struct *_p);

    csObjControlJob_BatchSize_Check_out_struct_var (const csObjControlJob_BatchSize_Check_out_struct_var &_s);

    csObjControlJob_BatchSize_Check_out_struct_var &operator= (csObjControlJob_BatchSize_Check_out_struct *_p);

    csObjControlJob_BatchSize_Check_out_struct_var &operator= (const csObjControlJob_BatchSize_Check_out_struct_var &_s);

    ~csObjControlJob_BatchSize_Check_out_struct_var ();

    csObjControlJob_BatchSize_Check_out_struct* operator-> ();

    const csObjControlJob_BatchSize_Check_out_struct& in() const;
    csObjControlJob_BatchSize_Check_out_struct& inout();
    csObjControlJob_BatchSize_Check_out_struct*& out();
    csObjControlJob_BatchSize_Check_out_struct* _retn();

    operator csObjControlJob_BatchSize_Check_out_struct_cvPtr () const;

    operator csObjControlJob_BatchSize_Check_out_struct_vPtr& ();

    operator const csObjControlJob_BatchSize_Check_out_struct& () const;

    operator csObjControlJob_BatchSize_Check_out_struct& ();

    protected:
    csObjControlJob_BatchSize_Check_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjControlJob_BatchSize_Check_out_struct;
    typedef csObjControlJob_BatchSize_Check_out_struct csObjControlJob_BatchSize_Check_out;
    typedef csObjControlJob_BatchSize_Check_out_struct_var csObjControlJob_BatchSize_Check_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjControlJob_BatchSize_Check_out;
    class  csObjControlJob_BatchSize_Check_in_struct_var;
    struct  csObjControlJob_BatchSize_Check_in_struct {
        typedef csObjControlJob_BatchSize_Check_in_struct_var _var_type;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::Boolean skipBatchSizeFlag;
       ::CORBA::Boolean skipWaferCountFlag;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjControlJob_BatchSize_Check_in_struct();
       csObjControlJob_BatchSize_Check_in_struct(const csObjControlJob_BatchSize_Check_in_struct&);
       csObjControlJob_BatchSize_Check_in_struct& operator=(const csObjControlJob_BatchSize_Check_in_struct&);
       static CORBA::Info<csObjControlJob_BatchSize_Check_in_struct> csObjControlJob_BatchSize_Check_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjControlJob_BatchSize_Check_in_struct


typedef csObjControlJob_BatchSize_Check_in_struct* csObjControlJob_BatchSize_Check_in_struct_vPtr;
typedef const csObjControlJob_BatchSize_Check_in_struct* csObjControlJob_BatchSize_Check_in_struct_cvPtr;

class  csObjControlJob_BatchSize_Check_in_struct_var
{
    public:

    csObjControlJob_BatchSize_Check_in_struct_var ();

    csObjControlJob_BatchSize_Check_in_struct_var (csObjControlJob_BatchSize_Check_in_struct *_p);

    csObjControlJob_BatchSize_Check_in_struct_var (const csObjControlJob_BatchSize_Check_in_struct_var &_s);

    csObjControlJob_BatchSize_Check_in_struct_var &operator= (csObjControlJob_BatchSize_Check_in_struct *_p);

    csObjControlJob_BatchSize_Check_in_struct_var &operator= (const csObjControlJob_BatchSize_Check_in_struct_var &_s);

    ~csObjControlJob_BatchSize_Check_in_struct_var ();

    csObjControlJob_BatchSize_Check_in_struct* operator-> ();

    const csObjControlJob_BatchSize_Check_in_struct& in() const;
    csObjControlJob_BatchSize_Check_in_struct& inout();
    csObjControlJob_BatchSize_Check_in_struct*& out();
    csObjControlJob_BatchSize_Check_in_struct* _retn();

    operator csObjControlJob_BatchSize_Check_in_struct_cvPtr () const;

    operator csObjControlJob_BatchSize_Check_in_struct_vPtr& ();

    operator const csObjControlJob_BatchSize_Check_in_struct& () const;

    operator csObjControlJob_BatchSize_Check_in_struct& ();

    protected:
    csObjControlJob_BatchSize_Check_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjControlJob_BatchSize_Check_in_struct;
    typedef csObjControlJob_BatchSize_Check_in_struct csObjControlJob_BatchSize_Check_in;
    typedef csObjControlJob_BatchSize_Check_in_struct_var csObjControlJob_BatchSize_Check_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjControlJob_BatchSize_Check_in;
    class  csObjLotID_ControlInfo_GetDR_in_struct_var;
    struct  csObjLotID_ControlInfo_GetDR_in_struct {
        typedef csObjLotID_ControlInfo_GetDR_in_struct_var _var_type;
       ::CORBA::String_StructElem leadingChar;
       ::CORBA::String_StructElem year;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLotID_ControlInfo_GetDR_in_struct();
       csObjLotID_ControlInfo_GetDR_in_struct(const csObjLotID_ControlInfo_GetDR_in_struct&);
       csObjLotID_ControlInfo_GetDR_in_struct& operator=(const csObjLotID_ControlInfo_GetDR_in_struct&);
       static CORBA::Info<csObjLotID_ControlInfo_GetDR_in_struct> csObjLotID_ControlInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjLotID_ControlInfo_GetDR_in_struct


typedef csObjLotID_ControlInfo_GetDR_in_struct* csObjLotID_ControlInfo_GetDR_in_struct_vPtr;
typedef const csObjLotID_ControlInfo_GetDR_in_struct* csObjLotID_ControlInfo_GetDR_in_struct_cvPtr;

class  csObjLotID_ControlInfo_GetDR_in_struct_var
{
    public:

    csObjLotID_ControlInfo_GetDR_in_struct_var ();

    csObjLotID_ControlInfo_GetDR_in_struct_var (csObjLotID_ControlInfo_GetDR_in_struct *_p);

    csObjLotID_ControlInfo_GetDR_in_struct_var (const csObjLotID_ControlInfo_GetDR_in_struct_var &_s);

    csObjLotID_ControlInfo_GetDR_in_struct_var &operator= (csObjLotID_ControlInfo_GetDR_in_struct *_p);

    csObjLotID_ControlInfo_GetDR_in_struct_var &operator= (const csObjLotID_ControlInfo_GetDR_in_struct_var &_s);

    ~csObjLotID_ControlInfo_GetDR_in_struct_var ();

    csObjLotID_ControlInfo_GetDR_in_struct* operator-> ();

    const csObjLotID_ControlInfo_GetDR_in_struct& in() const;
    csObjLotID_ControlInfo_GetDR_in_struct& inout();
    csObjLotID_ControlInfo_GetDR_in_struct*& out();
    csObjLotID_ControlInfo_GetDR_in_struct* _retn();

    operator csObjLotID_ControlInfo_GetDR_in_struct_cvPtr () const;

    operator csObjLotID_ControlInfo_GetDR_in_struct_vPtr& ();

    operator const csObjLotID_ControlInfo_GetDR_in_struct& () const;

    operator csObjLotID_ControlInfo_GetDR_in_struct& ();

    protected:
    csObjLotID_ControlInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_GetDR_in_struct;
    typedef csObjLotID_ControlInfo_GetDR_in_struct csObjLotID_ControlInfo_GetDR_in;
    typedef csObjLotID_ControlInfo_GetDR_in_struct_var csObjLotID_ControlInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_GetDR_in;
    class  csObjLotID_ControlInfo_GetDR_out_struct_var;
    struct  csObjLotID_ControlInfo_GetDR_out_struct {
        typedef csObjLotID_ControlInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem leadingChar;
       ::CORBA::Long lastUsedNumber;
       ::CORBA::String_StructElem year;
       ::CORBA::String_StructElem subChar;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLotID_ControlInfo_GetDR_out_struct();
       csObjLotID_ControlInfo_GetDR_out_struct(const csObjLotID_ControlInfo_GetDR_out_struct&);
       csObjLotID_ControlInfo_GetDR_out_struct& operator=(const csObjLotID_ControlInfo_GetDR_out_struct&);
       static CORBA::Info<csObjLotID_ControlInfo_GetDR_out_struct> csObjLotID_ControlInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLotID_ControlInfo_GetDR_out_struct


typedef csObjLotID_ControlInfo_GetDR_out_struct* csObjLotID_ControlInfo_GetDR_out_struct_vPtr;
typedef const csObjLotID_ControlInfo_GetDR_out_struct* csObjLotID_ControlInfo_GetDR_out_struct_cvPtr;

class  csObjLotID_ControlInfo_GetDR_out_struct_var
{
    public:

    csObjLotID_ControlInfo_GetDR_out_struct_var ();

    csObjLotID_ControlInfo_GetDR_out_struct_var (csObjLotID_ControlInfo_GetDR_out_struct *_p);

    csObjLotID_ControlInfo_GetDR_out_struct_var (const csObjLotID_ControlInfo_GetDR_out_struct_var &_s);

    csObjLotID_ControlInfo_GetDR_out_struct_var &operator= (csObjLotID_ControlInfo_GetDR_out_struct *_p);

    csObjLotID_ControlInfo_GetDR_out_struct_var &operator= (const csObjLotID_ControlInfo_GetDR_out_struct_var &_s);

    ~csObjLotID_ControlInfo_GetDR_out_struct_var ();

    csObjLotID_ControlInfo_GetDR_out_struct* operator-> ();

    const csObjLotID_ControlInfo_GetDR_out_struct& in() const;
    csObjLotID_ControlInfo_GetDR_out_struct& inout();
    csObjLotID_ControlInfo_GetDR_out_struct*& out();
    csObjLotID_ControlInfo_GetDR_out_struct* _retn();

    operator csObjLotID_ControlInfo_GetDR_out_struct_cvPtr () const;

    operator csObjLotID_ControlInfo_GetDR_out_struct_vPtr& ();

    operator const csObjLotID_ControlInfo_GetDR_out_struct& () const;

    operator csObjLotID_ControlInfo_GetDR_out_struct& ();

    protected:
    csObjLotID_ControlInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_GetDR_out_struct;
    typedef csObjLotID_ControlInfo_GetDR_out_struct csObjLotID_ControlInfo_GetDR_out;
    typedef csObjLotID_ControlInfo_GetDR_out_struct_var csObjLotID_ControlInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_GetDR_out;
    class  csObjLotID_ControlInfo_SetDR_in_struct_var;
    struct  csObjLotID_ControlInfo_SetDR_in_struct {
        typedef csObjLotID_ControlInfo_SetDR_in_struct_var _var_type;
       ::CORBA::String_StructElem leadingChar;
       ::CORBA::Long lastUsedNumber;
       ::CORBA::String_StructElem year;
       ::CORBA::String_StructElem subChar;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLotID_ControlInfo_SetDR_in_struct();
       csObjLotID_ControlInfo_SetDR_in_struct(const csObjLotID_ControlInfo_SetDR_in_struct&);
       csObjLotID_ControlInfo_SetDR_in_struct& operator=(const csObjLotID_ControlInfo_SetDR_in_struct&);
       static CORBA::Info<csObjLotID_ControlInfo_SetDR_in_struct> csObjLotID_ControlInfo_SetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjLotID_ControlInfo_SetDR_in_struct


typedef csObjLotID_ControlInfo_SetDR_in_struct* csObjLotID_ControlInfo_SetDR_in_struct_vPtr;
typedef const csObjLotID_ControlInfo_SetDR_in_struct* csObjLotID_ControlInfo_SetDR_in_struct_cvPtr;

class  csObjLotID_ControlInfo_SetDR_in_struct_var
{
    public:

    csObjLotID_ControlInfo_SetDR_in_struct_var ();

    csObjLotID_ControlInfo_SetDR_in_struct_var (csObjLotID_ControlInfo_SetDR_in_struct *_p);

    csObjLotID_ControlInfo_SetDR_in_struct_var (const csObjLotID_ControlInfo_SetDR_in_struct_var &_s);

    csObjLotID_ControlInfo_SetDR_in_struct_var &operator= (csObjLotID_ControlInfo_SetDR_in_struct *_p);

    csObjLotID_ControlInfo_SetDR_in_struct_var &operator= (const csObjLotID_ControlInfo_SetDR_in_struct_var &_s);

    ~csObjLotID_ControlInfo_SetDR_in_struct_var ();

    csObjLotID_ControlInfo_SetDR_in_struct* operator-> ();

    const csObjLotID_ControlInfo_SetDR_in_struct& in() const;
    csObjLotID_ControlInfo_SetDR_in_struct& inout();
    csObjLotID_ControlInfo_SetDR_in_struct*& out();
    csObjLotID_ControlInfo_SetDR_in_struct* _retn();

    operator csObjLotID_ControlInfo_SetDR_in_struct_cvPtr () const;

    operator csObjLotID_ControlInfo_SetDR_in_struct_vPtr& ();

    operator const csObjLotID_ControlInfo_SetDR_in_struct& () const;

    operator csObjLotID_ControlInfo_SetDR_in_struct& ();

    protected:
    csObjLotID_ControlInfo_SetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_SetDR_in_struct;
    typedef csObjLotID_ControlInfo_SetDR_in_struct csObjLotID_ControlInfo_SetDR_in;
    typedef csObjLotID_ControlInfo_SetDR_in_struct_var csObjLotID_ControlInfo_SetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_SetDR_in;
    typedef objBase_out csObjLotID_ControlInfo_SetDR_out;
    typedef objBase_out_var csObjLotID_ControlInfo_SetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_SetDR_out;
    class  csObjLotID_ControlInfo_AddDR_in_struct_var;
    struct  csObjLotID_ControlInfo_AddDR_in_struct {
        typedef csObjLotID_ControlInfo_AddDR_in_struct_var _var_type;
       ::CORBA::String_StructElem leadingChar;
       ::CORBA::Long lastUsedNumber;
       ::CORBA::String_StructElem year;
       ::CORBA::String_StructElem subChar;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLotID_ControlInfo_AddDR_in_struct();
       csObjLotID_ControlInfo_AddDR_in_struct(const csObjLotID_ControlInfo_AddDR_in_struct&);
       csObjLotID_ControlInfo_AddDR_in_struct& operator=(const csObjLotID_ControlInfo_AddDR_in_struct&);
       static CORBA::Info<csObjLotID_ControlInfo_AddDR_in_struct> csObjLotID_ControlInfo_AddDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjLotID_ControlInfo_AddDR_in_struct


typedef csObjLotID_ControlInfo_AddDR_in_struct* csObjLotID_ControlInfo_AddDR_in_struct_vPtr;
typedef const csObjLotID_ControlInfo_AddDR_in_struct* csObjLotID_ControlInfo_AddDR_in_struct_cvPtr;

class  csObjLotID_ControlInfo_AddDR_in_struct_var
{
    public:

    csObjLotID_ControlInfo_AddDR_in_struct_var ();

    csObjLotID_ControlInfo_AddDR_in_struct_var (csObjLotID_ControlInfo_AddDR_in_struct *_p);

    csObjLotID_ControlInfo_AddDR_in_struct_var (const csObjLotID_ControlInfo_AddDR_in_struct_var &_s);

    csObjLotID_ControlInfo_AddDR_in_struct_var &operator= (csObjLotID_ControlInfo_AddDR_in_struct *_p);

    csObjLotID_ControlInfo_AddDR_in_struct_var &operator= (const csObjLotID_ControlInfo_AddDR_in_struct_var &_s);

    ~csObjLotID_ControlInfo_AddDR_in_struct_var ();

    csObjLotID_ControlInfo_AddDR_in_struct* operator-> ();

    const csObjLotID_ControlInfo_AddDR_in_struct& in() const;
    csObjLotID_ControlInfo_AddDR_in_struct& inout();
    csObjLotID_ControlInfo_AddDR_in_struct*& out();
    csObjLotID_ControlInfo_AddDR_in_struct* _retn();

    operator csObjLotID_ControlInfo_AddDR_in_struct_cvPtr () const;

    operator csObjLotID_ControlInfo_AddDR_in_struct_vPtr& ();

    operator const csObjLotID_ControlInfo_AddDR_in_struct& () const;

    operator csObjLotID_ControlInfo_AddDR_in_struct& ();

    protected:
    csObjLotID_ControlInfo_AddDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_AddDR_in_struct;
    typedef csObjLotID_ControlInfo_AddDR_in_struct csObjLotID_ControlInfo_AddDR_in;
    typedef csObjLotID_ControlInfo_AddDR_in_struct_var csObjLotID_ControlInfo_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_AddDR_in;
    typedef objBase_out csObjLotID_ControlInfo_AddDR_out;
    typedef objBase_out_var csObjLotID_ControlInfo_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_AddDR_out;
    class  csObjBWS_Config_GetDR_in_struct_var;
    struct  csObjBWS_Config_GetDR_in_struct {
        typedef csObjBWS_Config_GetDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_GetDR_in_struct();
       csObjBWS_Config_GetDR_in_struct(const csObjBWS_Config_GetDR_in_struct&);
       csObjBWS_Config_GetDR_in_struct& operator=(const csObjBWS_Config_GetDR_in_struct&);
       static CORBA::Info<csObjBWS_Config_GetDR_in_struct> csObjBWS_Config_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_GetDR_in_struct


typedef csObjBWS_Config_GetDR_in_struct* csObjBWS_Config_GetDR_in_struct_vPtr;
typedef const csObjBWS_Config_GetDR_in_struct* csObjBWS_Config_GetDR_in_struct_cvPtr;

class  csObjBWS_Config_GetDR_in_struct_var
{
    public:

    csObjBWS_Config_GetDR_in_struct_var ();

    csObjBWS_Config_GetDR_in_struct_var (csObjBWS_Config_GetDR_in_struct *_p);

    csObjBWS_Config_GetDR_in_struct_var (const csObjBWS_Config_GetDR_in_struct_var &_s);

    csObjBWS_Config_GetDR_in_struct_var &operator= (csObjBWS_Config_GetDR_in_struct *_p);

    csObjBWS_Config_GetDR_in_struct_var &operator= (const csObjBWS_Config_GetDR_in_struct_var &_s);

    ~csObjBWS_Config_GetDR_in_struct_var ();

    csObjBWS_Config_GetDR_in_struct* operator-> ();

    const csObjBWS_Config_GetDR_in_struct& in() const;
    csObjBWS_Config_GetDR_in_struct& inout();
    csObjBWS_Config_GetDR_in_struct*& out();
    csObjBWS_Config_GetDR_in_struct* _retn();

    operator csObjBWS_Config_GetDR_in_struct_cvPtr () const;

    operator csObjBWS_Config_GetDR_in_struct_vPtr& ();

    operator const csObjBWS_Config_GetDR_in_struct& () const;

    operator csObjBWS_Config_GetDR_in_struct& ();

    protected:
    csObjBWS_Config_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_GetDR_in_struct;
    typedef csObjBWS_Config_GetDR_in_struct csObjBWS_Config_GetDR_in;
    typedef csObjBWS_Config_GetDR_in_struct_var csObjBWS_Config_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_GetDR_in;
    class  csObjBWS_Config_GetDR_out_struct_var;
    struct  csObjBWS_Config_GetDR_out_struct {
        typedef csObjBWS_Config_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSConfigInfoSequence strBWSConfigInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_GetDR_out_struct();
       csObjBWS_Config_GetDR_out_struct(const csObjBWS_Config_GetDR_out_struct&);
       csObjBWS_Config_GetDR_out_struct& operator=(const csObjBWS_Config_GetDR_out_struct&);
       static CORBA::Info<csObjBWS_Config_GetDR_out_struct> csObjBWS_Config_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_GetDR_out_struct


typedef csObjBWS_Config_GetDR_out_struct* csObjBWS_Config_GetDR_out_struct_vPtr;
typedef const csObjBWS_Config_GetDR_out_struct* csObjBWS_Config_GetDR_out_struct_cvPtr;

class  csObjBWS_Config_GetDR_out_struct_var
{
    public:

    csObjBWS_Config_GetDR_out_struct_var ();

    csObjBWS_Config_GetDR_out_struct_var (csObjBWS_Config_GetDR_out_struct *_p);

    csObjBWS_Config_GetDR_out_struct_var (const csObjBWS_Config_GetDR_out_struct_var &_s);

    csObjBWS_Config_GetDR_out_struct_var &operator= (csObjBWS_Config_GetDR_out_struct *_p);

    csObjBWS_Config_GetDR_out_struct_var &operator= (const csObjBWS_Config_GetDR_out_struct_var &_s);

    ~csObjBWS_Config_GetDR_out_struct_var ();

    csObjBWS_Config_GetDR_out_struct* operator-> ();

    const csObjBWS_Config_GetDR_out_struct& in() const;
    csObjBWS_Config_GetDR_out_struct& inout();
    csObjBWS_Config_GetDR_out_struct*& out();
    csObjBWS_Config_GetDR_out_struct* _retn();

    operator csObjBWS_Config_GetDR_out_struct_cvPtr () const;

    operator csObjBWS_Config_GetDR_out_struct_vPtr& ();

    operator const csObjBWS_Config_GetDR_out_struct& () const;

    operator csObjBWS_Config_GetDR_out_struct& ();

    protected:
    csObjBWS_Config_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_GetDR_out_struct;
    typedef csObjBWS_Config_GetDR_out_struct csObjBWS_Config_GetDR_out;
    typedef csObjBWS_Config_GetDR_out_struct_var csObjBWS_Config_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_GetDR_out;
    class  csObjBWS_Config_AddDR_in_struct_var;
    struct  csObjBWS_Config_AddDR_in_struct {
        typedef csObjBWS_Config_AddDR_in_struct_var _var_type;
       ::csBWSConfigInfo strBWSConfigInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_AddDR_in_struct();
       csObjBWS_Config_AddDR_in_struct(const csObjBWS_Config_AddDR_in_struct&);
       csObjBWS_Config_AddDR_in_struct& operator=(const csObjBWS_Config_AddDR_in_struct&);
       static CORBA::Info<csObjBWS_Config_AddDR_in_struct> csObjBWS_Config_AddDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_AddDR_in_struct


typedef csObjBWS_Config_AddDR_in_struct* csObjBWS_Config_AddDR_in_struct_vPtr;
typedef const csObjBWS_Config_AddDR_in_struct* csObjBWS_Config_AddDR_in_struct_cvPtr;

class  csObjBWS_Config_AddDR_in_struct_var
{
    public:

    csObjBWS_Config_AddDR_in_struct_var ();

    csObjBWS_Config_AddDR_in_struct_var (csObjBWS_Config_AddDR_in_struct *_p);

    csObjBWS_Config_AddDR_in_struct_var (const csObjBWS_Config_AddDR_in_struct_var &_s);

    csObjBWS_Config_AddDR_in_struct_var &operator= (csObjBWS_Config_AddDR_in_struct *_p);

    csObjBWS_Config_AddDR_in_struct_var &operator= (const csObjBWS_Config_AddDR_in_struct_var &_s);

    ~csObjBWS_Config_AddDR_in_struct_var ();

    csObjBWS_Config_AddDR_in_struct* operator-> ();

    const csObjBWS_Config_AddDR_in_struct& in() const;
    csObjBWS_Config_AddDR_in_struct& inout();
    csObjBWS_Config_AddDR_in_struct*& out();
    csObjBWS_Config_AddDR_in_struct* _retn();

    operator csObjBWS_Config_AddDR_in_struct_cvPtr () const;

    operator csObjBWS_Config_AddDR_in_struct_vPtr& ();

    operator const csObjBWS_Config_AddDR_in_struct& () const;

    operator csObjBWS_Config_AddDR_in_struct& ();

    protected:
    csObjBWS_Config_AddDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_AddDR_in_struct;
    typedef csObjBWS_Config_AddDR_in_struct csObjBWS_Config_AddDR_in;
    typedef csObjBWS_Config_AddDR_in_struct_var csObjBWS_Config_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_AddDR_in;
    typedef objBase_out csObjBWS_Config_AddDR_out;
    typedef objBase_out_var csObjBWS_Config_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_AddDR_out;
    class  csObjBWS_Config_DeleteDR_in_struct_var;
    struct  csObjBWS_Config_DeleteDR_in_struct {
        typedef csObjBWS_Config_DeleteDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_DeleteDR_in_struct();
       csObjBWS_Config_DeleteDR_in_struct(const csObjBWS_Config_DeleteDR_in_struct&);
       csObjBWS_Config_DeleteDR_in_struct& operator=(const csObjBWS_Config_DeleteDR_in_struct&);
       static CORBA::Info<csObjBWS_Config_DeleteDR_in_struct> csObjBWS_Config_DeleteDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_DeleteDR_in_struct


typedef csObjBWS_Config_DeleteDR_in_struct* csObjBWS_Config_DeleteDR_in_struct_vPtr;
typedef const csObjBWS_Config_DeleteDR_in_struct* csObjBWS_Config_DeleteDR_in_struct_cvPtr;

class  csObjBWS_Config_DeleteDR_in_struct_var
{
    public:

    csObjBWS_Config_DeleteDR_in_struct_var ();

    csObjBWS_Config_DeleteDR_in_struct_var (csObjBWS_Config_DeleteDR_in_struct *_p);

    csObjBWS_Config_DeleteDR_in_struct_var (const csObjBWS_Config_DeleteDR_in_struct_var &_s);

    csObjBWS_Config_DeleteDR_in_struct_var &operator= (csObjBWS_Config_DeleteDR_in_struct *_p);

    csObjBWS_Config_DeleteDR_in_struct_var &operator= (const csObjBWS_Config_DeleteDR_in_struct_var &_s);

    ~csObjBWS_Config_DeleteDR_in_struct_var ();

    csObjBWS_Config_DeleteDR_in_struct* operator-> ();

    const csObjBWS_Config_DeleteDR_in_struct& in() const;
    csObjBWS_Config_DeleteDR_in_struct& inout();
    csObjBWS_Config_DeleteDR_in_struct*& out();
    csObjBWS_Config_DeleteDR_in_struct* _retn();

    operator csObjBWS_Config_DeleteDR_in_struct_cvPtr () const;

    operator csObjBWS_Config_DeleteDR_in_struct_vPtr& ();

    operator const csObjBWS_Config_DeleteDR_in_struct& () const;

    operator csObjBWS_Config_DeleteDR_in_struct& ();

    protected:
    csObjBWS_Config_DeleteDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_DeleteDR_in_struct;
    typedef csObjBWS_Config_DeleteDR_in_struct csObjBWS_Config_DeleteDR_in;
    typedef csObjBWS_Config_DeleteDR_in_struct_var csObjBWS_Config_DeleteDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_DeleteDR_in;
    typedef objBase_out csObjBWS_Config_DeleteDR_out;
    typedef objBase_out_var csObjBWS_Config_DeleteDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_DeleteDR_out;
    class  csObjBWS_Config_UpdateDR_in_struct_var;
    struct  csObjBWS_Config_UpdateDR_in_struct {
        typedef csObjBWS_Config_UpdateDR_in_struct_var _var_type;
       ::csBWSConfigInfo strBWSConfigInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_UpdateDR_in_struct();
       csObjBWS_Config_UpdateDR_in_struct(const csObjBWS_Config_UpdateDR_in_struct&);
       csObjBWS_Config_UpdateDR_in_struct& operator=(const csObjBWS_Config_UpdateDR_in_struct&);
       static CORBA::Info<csObjBWS_Config_UpdateDR_in_struct> csObjBWS_Config_UpdateDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_UpdateDR_in_struct


typedef csObjBWS_Config_UpdateDR_in_struct* csObjBWS_Config_UpdateDR_in_struct_vPtr;
typedef const csObjBWS_Config_UpdateDR_in_struct* csObjBWS_Config_UpdateDR_in_struct_cvPtr;

class  csObjBWS_Config_UpdateDR_in_struct_var
{
    public:

    csObjBWS_Config_UpdateDR_in_struct_var ();

    csObjBWS_Config_UpdateDR_in_struct_var (csObjBWS_Config_UpdateDR_in_struct *_p);

    csObjBWS_Config_UpdateDR_in_struct_var (const csObjBWS_Config_UpdateDR_in_struct_var &_s);

    csObjBWS_Config_UpdateDR_in_struct_var &operator= (csObjBWS_Config_UpdateDR_in_struct *_p);

    csObjBWS_Config_UpdateDR_in_struct_var &operator= (const csObjBWS_Config_UpdateDR_in_struct_var &_s);

    ~csObjBWS_Config_UpdateDR_in_struct_var ();

    csObjBWS_Config_UpdateDR_in_struct* operator-> ();

    const csObjBWS_Config_UpdateDR_in_struct& in() const;
    csObjBWS_Config_UpdateDR_in_struct& inout();
    csObjBWS_Config_UpdateDR_in_struct*& out();
    csObjBWS_Config_UpdateDR_in_struct* _retn();

    operator csObjBWS_Config_UpdateDR_in_struct_cvPtr () const;

    operator csObjBWS_Config_UpdateDR_in_struct_vPtr& ();

    operator const csObjBWS_Config_UpdateDR_in_struct& () const;

    operator csObjBWS_Config_UpdateDR_in_struct& ();

    protected:
    csObjBWS_Config_UpdateDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_UpdateDR_in_struct;
    typedef csObjBWS_Config_UpdateDR_in_struct csObjBWS_Config_UpdateDR_in;
    typedef csObjBWS_Config_UpdateDR_in_struct_var csObjBWS_Config_UpdateDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_UpdateDR_in;
    typedef objBase_out csObjBWS_Config_UpdateDR_out;
    typedef objBase_out_var csObjBWS_Config_UpdateDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_UpdateDR_out;
    typedef csBWSWaferListInqInParm csObjBWS_WaferList_GetDR_in;
    typedef csBWSWaferListInqInParm_var csObjBWS_WaferList_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_GetDR_in;
    class  csObjBWS_WaferList_GetDR_out_struct_var;
    struct  csObjBWS_WaferList_GetDR_out_struct {
        typedef csObjBWS_WaferList_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSDataSequence strBWSDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_WaferList_GetDR_out_struct();
       csObjBWS_WaferList_GetDR_out_struct(const csObjBWS_WaferList_GetDR_out_struct&);
       csObjBWS_WaferList_GetDR_out_struct& operator=(const csObjBWS_WaferList_GetDR_out_struct&);
       static CORBA::Info<csObjBWS_WaferList_GetDR_out_struct> csObjBWS_WaferList_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_WaferList_GetDR_out_struct


typedef csObjBWS_WaferList_GetDR_out_struct* csObjBWS_WaferList_GetDR_out_struct_vPtr;
typedef const csObjBWS_WaferList_GetDR_out_struct* csObjBWS_WaferList_GetDR_out_struct_cvPtr;

class  csObjBWS_WaferList_GetDR_out_struct_var
{
    public:

    csObjBWS_WaferList_GetDR_out_struct_var ();

    csObjBWS_WaferList_GetDR_out_struct_var (csObjBWS_WaferList_GetDR_out_struct *_p);

    csObjBWS_WaferList_GetDR_out_struct_var (const csObjBWS_WaferList_GetDR_out_struct_var &_s);

    csObjBWS_WaferList_GetDR_out_struct_var &operator= (csObjBWS_WaferList_GetDR_out_struct *_p);

    csObjBWS_WaferList_GetDR_out_struct_var &operator= (const csObjBWS_WaferList_GetDR_out_struct_var &_s);

    ~csObjBWS_WaferList_GetDR_out_struct_var ();

    csObjBWS_WaferList_GetDR_out_struct* operator-> ();

    const csObjBWS_WaferList_GetDR_out_struct& in() const;
    csObjBWS_WaferList_GetDR_out_struct& inout();
    csObjBWS_WaferList_GetDR_out_struct*& out();
    csObjBWS_WaferList_GetDR_out_struct* _retn();

    operator csObjBWS_WaferList_GetDR_out_struct_cvPtr () const;

    operator csObjBWS_WaferList_GetDR_out_struct_vPtr& ();

    operator const csObjBWS_WaferList_GetDR_out_struct& () const;

    operator csObjBWS_WaferList_GetDR_out_struct& ();

    protected:
    csObjBWS_WaferList_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_GetDR_out_struct;
    typedef csObjBWS_WaferList_GetDR_out_struct csObjBWS_WaferList_GetDR_out;
    typedef csObjBWS_WaferList_GetDR_out_struct_var csObjBWS_WaferList_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_GetDR_out;
    class  csObjBWS_WaferList_AddDR_in_struct_var;
    struct  csObjBWS_WaferList_AddDR_in_struct {
        typedef csObjBWS_WaferList_AddDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::csBWSWaferDataSequence strBWSWaferDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_WaferList_AddDR_in_struct();
       csObjBWS_WaferList_AddDR_in_struct(const csObjBWS_WaferList_AddDR_in_struct&);
       csObjBWS_WaferList_AddDR_in_struct& operator=(const csObjBWS_WaferList_AddDR_in_struct&);
       static CORBA::Info<csObjBWS_WaferList_AddDR_in_struct> csObjBWS_WaferList_AddDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_WaferList_AddDR_in_struct


typedef csObjBWS_WaferList_AddDR_in_struct* csObjBWS_WaferList_AddDR_in_struct_vPtr;
typedef const csObjBWS_WaferList_AddDR_in_struct* csObjBWS_WaferList_AddDR_in_struct_cvPtr;

class  csObjBWS_WaferList_AddDR_in_struct_var
{
    public:

    csObjBWS_WaferList_AddDR_in_struct_var ();

    csObjBWS_WaferList_AddDR_in_struct_var (csObjBWS_WaferList_AddDR_in_struct *_p);

    csObjBWS_WaferList_AddDR_in_struct_var (const csObjBWS_WaferList_AddDR_in_struct_var &_s);

    csObjBWS_WaferList_AddDR_in_struct_var &operator= (csObjBWS_WaferList_AddDR_in_struct *_p);

    csObjBWS_WaferList_AddDR_in_struct_var &operator= (const csObjBWS_WaferList_AddDR_in_struct_var &_s);

    ~csObjBWS_WaferList_AddDR_in_struct_var ();

    csObjBWS_WaferList_AddDR_in_struct* operator-> ();

    const csObjBWS_WaferList_AddDR_in_struct& in() const;
    csObjBWS_WaferList_AddDR_in_struct& inout();
    csObjBWS_WaferList_AddDR_in_struct*& out();
    csObjBWS_WaferList_AddDR_in_struct* _retn();

    operator csObjBWS_WaferList_AddDR_in_struct_cvPtr () const;

    operator csObjBWS_WaferList_AddDR_in_struct_vPtr& ();

    operator const csObjBWS_WaferList_AddDR_in_struct& () const;

    operator csObjBWS_WaferList_AddDR_in_struct& ();

    protected:
    csObjBWS_WaferList_AddDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_AddDR_in_struct;
    typedef csObjBWS_WaferList_AddDR_in_struct csObjBWS_WaferList_AddDR_in;
    typedef csObjBWS_WaferList_AddDR_in_struct_var csObjBWS_WaferList_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_AddDR_in;
    typedef objBase_out csObjBWS_WaferList_AddDR_out;
    typedef objBase_out_var csObjBWS_WaferList_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_AddDR_out;
    class  csObjBWS_WaferList_DeleteDR_in_struct_var;
    struct  csObjBWS_WaferList_DeleteDR_in_struct {
        typedef csObjBWS_WaferList_DeleteDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::objectIdentifierSequence waferIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_WaferList_DeleteDR_in_struct();
       csObjBWS_WaferList_DeleteDR_in_struct(const csObjBWS_WaferList_DeleteDR_in_struct&);
       csObjBWS_WaferList_DeleteDR_in_struct& operator=(const csObjBWS_WaferList_DeleteDR_in_struct&);
       static CORBA::Info<csObjBWS_WaferList_DeleteDR_in_struct> csObjBWS_WaferList_DeleteDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_WaferList_DeleteDR_in_struct


typedef csObjBWS_WaferList_DeleteDR_in_struct* csObjBWS_WaferList_DeleteDR_in_struct_vPtr;
typedef const csObjBWS_WaferList_DeleteDR_in_struct* csObjBWS_WaferList_DeleteDR_in_struct_cvPtr;

class  csObjBWS_WaferList_DeleteDR_in_struct_var
{
    public:

    csObjBWS_WaferList_DeleteDR_in_struct_var ();

    csObjBWS_WaferList_DeleteDR_in_struct_var (csObjBWS_WaferList_DeleteDR_in_struct *_p);

    csObjBWS_WaferList_DeleteDR_in_struct_var (const csObjBWS_WaferList_DeleteDR_in_struct_var &_s);

    csObjBWS_WaferList_DeleteDR_in_struct_var &operator= (csObjBWS_WaferList_DeleteDR_in_struct *_p);

    csObjBWS_WaferList_DeleteDR_in_struct_var &operator= (const csObjBWS_WaferList_DeleteDR_in_struct_var &_s);

    ~csObjBWS_WaferList_DeleteDR_in_struct_var ();

    csObjBWS_WaferList_DeleteDR_in_struct* operator-> ();

    const csObjBWS_WaferList_DeleteDR_in_struct& in() const;
    csObjBWS_WaferList_DeleteDR_in_struct& inout();
    csObjBWS_WaferList_DeleteDR_in_struct*& out();
    csObjBWS_WaferList_DeleteDR_in_struct* _retn();

    operator csObjBWS_WaferList_DeleteDR_in_struct_cvPtr () const;

    operator csObjBWS_WaferList_DeleteDR_in_struct_vPtr& ();

    operator const csObjBWS_WaferList_DeleteDR_in_struct& () const;

    operator csObjBWS_WaferList_DeleteDR_in_struct& ();

    protected:
    csObjBWS_WaferList_DeleteDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_DeleteDR_in_struct;
    typedef csObjBWS_WaferList_DeleteDR_in_struct csObjBWS_WaferList_DeleteDR_in;
    typedef csObjBWS_WaferList_DeleteDR_in_struct_var csObjBWS_WaferList_DeleteDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_DeleteDR_in;
    typedef objBase_out csObjBWS_WaferList_DeleteDR_out;
    typedef objBase_out_var csObjBWS_WaferList_DeleteDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_DeleteDR_out;
    class  csObjEqpMonitorInventory_ListGetDR_in_struct_var;
    struct  csObjEqpMonitorInventory_ListGetDR_in_struct {
        typedef csObjEqpMonitorInventory_ListGetDR_in_struct_var _var_type;
       ::CORBA::String_StructElem npwType;
       ::CORBA::String_StructElem productID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitorInventory_ListGetDR_in_struct();
       csObjEqpMonitorInventory_ListGetDR_in_struct(const csObjEqpMonitorInventory_ListGetDR_in_struct&);
       csObjEqpMonitorInventory_ListGetDR_in_struct& operator=(const csObjEqpMonitorInventory_ListGetDR_in_struct&);
       static CORBA::Info<csObjEqpMonitorInventory_ListGetDR_in_struct> csObjEqpMonitorInventory_ListGetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjEqpMonitorInventory_ListGetDR_in_struct


typedef csObjEqpMonitorInventory_ListGetDR_in_struct* csObjEqpMonitorInventory_ListGetDR_in_struct_vPtr;
typedef const csObjEqpMonitorInventory_ListGetDR_in_struct* csObjEqpMonitorInventory_ListGetDR_in_struct_cvPtr;

class  csObjEqpMonitorInventory_ListGetDR_in_struct_var
{
    public:

    csObjEqpMonitorInventory_ListGetDR_in_struct_var ();

    csObjEqpMonitorInventory_ListGetDR_in_struct_var (csObjEqpMonitorInventory_ListGetDR_in_struct *_p);

    csObjEqpMonitorInventory_ListGetDR_in_struct_var (const csObjEqpMonitorInventory_ListGetDR_in_struct_var &_s);

    csObjEqpMonitorInventory_ListGetDR_in_struct_var &operator= (csObjEqpMonitorInventory_ListGetDR_in_struct *_p);

    csObjEqpMonitorInventory_ListGetDR_in_struct_var &operator= (const csObjEqpMonitorInventory_ListGetDR_in_struct_var &_s);

    ~csObjEqpMonitorInventory_ListGetDR_in_struct_var ();

    csObjEqpMonitorInventory_ListGetDR_in_struct* operator-> ();

    const csObjEqpMonitorInventory_ListGetDR_in_struct& in() const;
    csObjEqpMonitorInventory_ListGetDR_in_struct& inout();
    csObjEqpMonitorInventory_ListGetDR_in_struct*& out();
    csObjEqpMonitorInventory_ListGetDR_in_struct* _retn();

    operator csObjEqpMonitorInventory_ListGetDR_in_struct_cvPtr () const;

    operator csObjEqpMonitorInventory_ListGetDR_in_struct_vPtr& ();

    operator const csObjEqpMonitorInventory_ListGetDR_in_struct& () const;

    operator csObjEqpMonitorInventory_ListGetDR_in_struct& ();

    protected:
    csObjEqpMonitorInventory_ListGetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_ListGetDR_in_struct;
    typedef csObjEqpMonitorInventory_ListGetDR_in_struct csObjEqpMonitorInventory_ListGetDR_in;
    typedef csObjEqpMonitorInventory_ListGetDR_in_struct_var csObjEqpMonitorInventory_ListGetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_ListGetDR_in;
    class  csObjEqpMonitorInventory_ListGetDR_out_struct_var;
    struct  csObjEqpMonitorInventory_ListGetDR_out_struct {
        typedef csObjEqpMonitorInventory_ListGetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpMonitorInventoryInfoSequence strEqpMonitorInventoryInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitorInventory_ListGetDR_out_struct();
       csObjEqpMonitorInventory_ListGetDR_out_struct(const csObjEqpMonitorInventory_ListGetDR_out_struct&);
       csObjEqpMonitorInventory_ListGetDR_out_struct& operator=(const csObjEqpMonitorInventory_ListGetDR_out_struct&);
       static CORBA::Info<csObjEqpMonitorInventory_ListGetDR_out_struct> csObjEqpMonitorInventory_ListGetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEqpMonitorInventory_ListGetDR_out_struct


typedef csObjEqpMonitorInventory_ListGetDR_out_struct* csObjEqpMonitorInventory_ListGetDR_out_struct_vPtr;
typedef const csObjEqpMonitorInventory_ListGetDR_out_struct* csObjEqpMonitorInventory_ListGetDR_out_struct_cvPtr;

class  csObjEqpMonitorInventory_ListGetDR_out_struct_var
{
    public:

    csObjEqpMonitorInventory_ListGetDR_out_struct_var ();

    csObjEqpMonitorInventory_ListGetDR_out_struct_var (csObjEqpMonitorInventory_ListGetDR_out_struct *_p);

    csObjEqpMonitorInventory_ListGetDR_out_struct_var (const csObjEqpMonitorInventory_ListGetDR_out_struct_var &_s);

    csObjEqpMonitorInventory_ListGetDR_out_struct_var &operator= (csObjEqpMonitorInventory_ListGetDR_out_struct *_p);

    csObjEqpMonitorInventory_ListGetDR_out_struct_var &operator= (const csObjEqpMonitorInventory_ListGetDR_out_struct_var &_s);

    ~csObjEqpMonitorInventory_ListGetDR_out_struct_var ();

    csObjEqpMonitorInventory_ListGetDR_out_struct* operator-> ();

    const csObjEqpMonitorInventory_ListGetDR_out_struct& in() const;
    csObjEqpMonitorInventory_ListGetDR_out_struct& inout();
    csObjEqpMonitorInventory_ListGetDR_out_struct*& out();
    csObjEqpMonitorInventory_ListGetDR_out_struct* _retn();

    operator csObjEqpMonitorInventory_ListGetDR_out_struct_cvPtr () const;

    operator csObjEqpMonitorInventory_ListGetDR_out_struct_vPtr& ();

    operator const csObjEqpMonitorInventory_ListGetDR_out_struct& () const;

    operator csObjEqpMonitorInventory_ListGetDR_out_struct& ();

    protected:
    csObjEqpMonitorInventory_ListGetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_ListGetDR_out_struct;
    typedef csObjEqpMonitorInventory_ListGetDR_out_struct csObjEqpMonitorInventory_ListGetDR_out;
    typedef csObjEqpMonitorInventory_ListGetDR_out_struct_var csObjEqpMonitorInventory_ListGetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_ListGetDR_out;
    class  csObjEqpMonitorInventory_info_Update_in_struct_var;
    struct  csObjEqpMonitorInventory_info_Update_in_struct {
        typedef csObjEqpMonitorInventory_info_Update_in_struct_var _var_type;
       ::csEqpMonitorInventoryInfo strEqpMonitorInventoryInfo;
       ::CORBA::String_StructElem actionCode;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitorInventory_info_Update_in_struct();
       csObjEqpMonitorInventory_info_Update_in_struct(const csObjEqpMonitorInventory_info_Update_in_struct&);
       csObjEqpMonitorInventory_info_Update_in_struct& operator=(const csObjEqpMonitorInventory_info_Update_in_struct&);
       static CORBA::Info<csObjEqpMonitorInventory_info_Update_in_struct> csObjEqpMonitorInventory_info_Update_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEqpMonitorInventory_info_Update_in_struct


typedef csObjEqpMonitorInventory_info_Update_in_struct* csObjEqpMonitorInventory_info_Update_in_struct_vPtr;
typedef const csObjEqpMonitorInventory_info_Update_in_struct* csObjEqpMonitorInventory_info_Update_in_struct_cvPtr;

class  csObjEqpMonitorInventory_info_Update_in_struct_var
{
    public:

    csObjEqpMonitorInventory_info_Update_in_struct_var ();

    csObjEqpMonitorInventory_info_Update_in_struct_var (csObjEqpMonitorInventory_info_Update_in_struct *_p);

    csObjEqpMonitorInventory_info_Update_in_struct_var (const csObjEqpMonitorInventory_info_Update_in_struct_var &_s);

    csObjEqpMonitorInventory_info_Update_in_struct_var &operator= (csObjEqpMonitorInventory_info_Update_in_struct *_p);

    csObjEqpMonitorInventory_info_Update_in_struct_var &operator= (const csObjEqpMonitorInventory_info_Update_in_struct_var &_s);

    ~csObjEqpMonitorInventory_info_Update_in_struct_var ();

    csObjEqpMonitorInventory_info_Update_in_struct* operator-> ();

    const csObjEqpMonitorInventory_info_Update_in_struct& in() const;
    csObjEqpMonitorInventory_info_Update_in_struct& inout();
    csObjEqpMonitorInventory_info_Update_in_struct*& out();
    csObjEqpMonitorInventory_info_Update_in_struct* _retn();

    operator csObjEqpMonitorInventory_info_Update_in_struct_cvPtr () const;

    operator csObjEqpMonitorInventory_info_Update_in_struct_vPtr& ();

    operator const csObjEqpMonitorInventory_info_Update_in_struct& () const;

    operator csObjEqpMonitorInventory_info_Update_in_struct& ();

    protected:
    csObjEqpMonitorInventory_info_Update_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_info_Update_in_struct;
    typedef csObjEqpMonitorInventory_info_Update_in_struct csObjEqpMonitorInventory_info_Update_in;
    typedef csObjEqpMonitorInventory_info_Update_in_struct_var csObjEqpMonitorInventory_info_Update_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_info_Update_in;
    typedef objBase_out csObjEqpMonitorInventory_info_Update_out;
    typedef objBase_out_var csObjEqpMonitorInventory_info_Update_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_info_Update_out;
    class  csObjNPW_sameBWSID_Get_in_struct_var;
    struct  csObjNPW_sameBWSID_Get_in_struct {
        typedef csObjNPW_sameBWSID_Get_in_struct_var _var_type;
       ::stringSequence strOrgBWSIDSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjNPW_sameBWSID_Get_in_struct();
       csObjNPW_sameBWSID_Get_in_struct(const csObjNPW_sameBWSID_Get_in_struct&);
       csObjNPW_sameBWSID_Get_in_struct& operator=(const csObjNPW_sameBWSID_Get_in_struct&);
       static CORBA::Info<csObjNPW_sameBWSID_Get_in_struct> csObjNPW_sameBWSID_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjNPW_sameBWSID_Get_in_struct


typedef csObjNPW_sameBWSID_Get_in_struct* csObjNPW_sameBWSID_Get_in_struct_vPtr;
typedef const csObjNPW_sameBWSID_Get_in_struct* csObjNPW_sameBWSID_Get_in_struct_cvPtr;

class  csObjNPW_sameBWSID_Get_in_struct_var
{
    public:

    csObjNPW_sameBWSID_Get_in_struct_var ();

    csObjNPW_sameBWSID_Get_in_struct_var (csObjNPW_sameBWSID_Get_in_struct *_p);

    csObjNPW_sameBWSID_Get_in_struct_var (const csObjNPW_sameBWSID_Get_in_struct_var &_s);

    csObjNPW_sameBWSID_Get_in_struct_var &operator= (csObjNPW_sameBWSID_Get_in_struct *_p);

    csObjNPW_sameBWSID_Get_in_struct_var &operator= (const csObjNPW_sameBWSID_Get_in_struct_var &_s);

    ~csObjNPW_sameBWSID_Get_in_struct_var ();

    csObjNPW_sameBWSID_Get_in_struct* operator-> ();

    const csObjNPW_sameBWSID_Get_in_struct& in() const;
    csObjNPW_sameBWSID_Get_in_struct& inout();
    csObjNPW_sameBWSID_Get_in_struct*& out();
    csObjNPW_sameBWSID_Get_in_struct* _retn();

    operator csObjNPW_sameBWSID_Get_in_struct_cvPtr () const;

    operator csObjNPW_sameBWSID_Get_in_struct_vPtr& ();

    operator const csObjNPW_sameBWSID_Get_in_struct& () const;

    operator csObjNPW_sameBWSID_Get_in_struct& ();

    protected:
    csObjNPW_sameBWSID_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sameBWSID_Get_in_struct;
    typedef csObjNPW_sameBWSID_Get_in_struct csObjNPW_sameBWSID_Get_in;
    typedef csObjNPW_sameBWSID_Get_in_struct_var csObjNPW_sameBWSID_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sameBWSID_Get_in;
    class  csObjNPW_sameBWSID_Get_out_struct_var;
    struct  csObjNPW_sameBWSID_Get_out_struct {
        typedef csObjNPW_sameBWSID_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::stringSequence BWSIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjNPW_sameBWSID_Get_out_struct();
       csObjNPW_sameBWSID_Get_out_struct(const csObjNPW_sameBWSID_Get_out_struct&);
       csObjNPW_sameBWSID_Get_out_struct& operator=(const csObjNPW_sameBWSID_Get_out_struct&);
       static CORBA::Info<csObjNPW_sameBWSID_Get_out_struct> csObjNPW_sameBWSID_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjNPW_sameBWSID_Get_out_struct


typedef csObjNPW_sameBWSID_Get_out_struct* csObjNPW_sameBWSID_Get_out_struct_vPtr;
typedef const csObjNPW_sameBWSID_Get_out_struct* csObjNPW_sameBWSID_Get_out_struct_cvPtr;

class  csObjNPW_sameBWSID_Get_out_struct_var
{
    public:

    csObjNPW_sameBWSID_Get_out_struct_var ();

    csObjNPW_sameBWSID_Get_out_struct_var (csObjNPW_sameBWSID_Get_out_struct *_p);

    csObjNPW_sameBWSID_Get_out_struct_var (const csObjNPW_sameBWSID_Get_out_struct_var &_s);

    csObjNPW_sameBWSID_Get_out_struct_var &operator= (csObjNPW_sameBWSID_Get_out_struct *_p);

    csObjNPW_sameBWSID_Get_out_struct_var &operator= (const csObjNPW_sameBWSID_Get_out_struct_var &_s);

    ~csObjNPW_sameBWSID_Get_out_struct_var ();

    csObjNPW_sameBWSID_Get_out_struct* operator-> ();

    const csObjNPW_sameBWSID_Get_out_struct& in() const;
    csObjNPW_sameBWSID_Get_out_struct& inout();
    csObjNPW_sameBWSID_Get_out_struct*& out();
    csObjNPW_sameBWSID_Get_out_struct* _retn();

    operator csObjNPW_sameBWSID_Get_out_struct_cvPtr () const;

    operator csObjNPW_sameBWSID_Get_out_struct_vPtr& ();

    operator const csObjNPW_sameBWSID_Get_out_struct& () const;

    operator csObjNPW_sameBWSID_Get_out_struct& ();

    protected:
    csObjNPW_sameBWSID_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sameBWSID_Get_out_struct;
    typedef csObjNPW_sameBWSID_Get_out_struct csObjNPW_sameBWSID_Get_out;
    typedef csObjNPW_sameBWSID_Get_out_struct_var csObjNPW_sameBWSID_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sameBWSID_Get_out;
    class  csObjDowngradeItemList_GetDR_in_struct_var;
    struct  csObjDowngradeItemList_GetDR_in_struct {
        typedef csObjDowngradeItemList_GetDR_in_struct_var _var_type;
       ::objectIdentifier dcDefID;
       ::CORBA::Boolean candidateFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDowngradeItemList_GetDR_in_struct();
       csObjDowngradeItemList_GetDR_in_struct(const csObjDowngradeItemList_GetDR_in_struct&);
       csObjDowngradeItemList_GetDR_in_struct& operator=(const csObjDowngradeItemList_GetDR_in_struct&);
       static CORBA::Info<csObjDowngradeItemList_GetDR_in_struct> csObjDowngradeItemList_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDowngradeItemList_GetDR_in_struct


typedef csObjDowngradeItemList_GetDR_in_struct* csObjDowngradeItemList_GetDR_in_struct_vPtr;
typedef const csObjDowngradeItemList_GetDR_in_struct* csObjDowngradeItemList_GetDR_in_struct_cvPtr;

class  csObjDowngradeItemList_GetDR_in_struct_var
{
    public:

    csObjDowngradeItemList_GetDR_in_struct_var ();

    csObjDowngradeItemList_GetDR_in_struct_var (csObjDowngradeItemList_GetDR_in_struct *_p);

    csObjDowngradeItemList_GetDR_in_struct_var (const csObjDowngradeItemList_GetDR_in_struct_var &_s);

    csObjDowngradeItemList_GetDR_in_struct_var &operator= (csObjDowngradeItemList_GetDR_in_struct *_p);

    csObjDowngradeItemList_GetDR_in_struct_var &operator= (const csObjDowngradeItemList_GetDR_in_struct_var &_s);

    ~csObjDowngradeItemList_GetDR_in_struct_var ();

    csObjDowngradeItemList_GetDR_in_struct* operator-> ();

    const csObjDowngradeItemList_GetDR_in_struct& in() const;
    csObjDowngradeItemList_GetDR_in_struct& inout();
    csObjDowngradeItemList_GetDR_in_struct*& out();
    csObjDowngradeItemList_GetDR_in_struct* _retn();

    operator csObjDowngradeItemList_GetDR_in_struct_cvPtr () const;

    operator csObjDowngradeItemList_GetDR_in_struct_vPtr& ();

    operator const csObjDowngradeItemList_GetDR_in_struct& () const;

    operator csObjDowngradeItemList_GetDR_in_struct& ();

    protected:
    csObjDowngradeItemList_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeItemList_GetDR_in_struct;
    typedef csObjDowngradeItemList_GetDR_in_struct csObjDowngradeItemList_GetDR_in;
    typedef csObjDowngradeItemList_GetDR_in_struct_var csObjDowngradeItemList_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeItemList_GetDR_in;
    class  csObjDowngradeItemList_GetDR_out_struct_var;
    struct  csObjDowngradeItemList_GetDR_out_struct {
        typedef csObjDowngradeItemList_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier dcDefID;
       ::csDowngradeItemSequence selectedDCItems;
       ::stringSequence candidateDCItems;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDowngradeItemList_GetDR_out_struct();
       csObjDowngradeItemList_GetDR_out_struct(const csObjDowngradeItemList_GetDR_out_struct&);
       csObjDowngradeItemList_GetDR_out_struct& operator=(const csObjDowngradeItemList_GetDR_out_struct&);
       static CORBA::Info<csObjDowngradeItemList_GetDR_out_struct> csObjDowngradeItemList_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDowngradeItemList_GetDR_out_struct


typedef csObjDowngradeItemList_GetDR_out_struct* csObjDowngradeItemList_GetDR_out_struct_vPtr;
typedef const csObjDowngradeItemList_GetDR_out_struct* csObjDowngradeItemList_GetDR_out_struct_cvPtr;

class  csObjDowngradeItemList_GetDR_out_struct_var
{
    public:

    csObjDowngradeItemList_GetDR_out_struct_var ();

    csObjDowngradeItemList_GetDR_out_struct_var (csObjDowngradeItemList_GetDR_out_struct *_p);

    csObjDowngradeItemList_GetDR_out_struct_var (const csObjDowngradeItemList_GetDR_out_struct_var &_s);

    csObjDowngradeItemList_GetDR_out_struct_var &operator= (csObjDowngradeItemList_GetDR_out_struct *_p);

    csObjDowngradeItemList_GetDR_out_struct_var &operator= (const csObjDowngradeItemList_GetDR_out_struct_var &_s);

    ~csObjDowngradeItemList_GetDR_out_struct_var ();

    csObjDowngradeItemList_GetDR_out_struct* operator-> ();

    const csObjDowngradeItemList_GetDR_out_struct& in() const;
    csObjDowngradeItemList_GetDR_out_struct& inout();
    csObjDowngradeItemList_GetDR_out_struct*& out();
    csObjDowngradeItemList_GetDR_out_struct* _retn();

    operator csObjDowngradeItemList_GetDR_out_struct_cvPtr () const;

    operator csObjDowngradeItemList_GetDR_out_struct_vPtr& ();

    operator const csObjDowngradeItemList_GetDR_out_struct& () const;

    operator csObjDowngradeItemList_GetDR_out_struct& ();

    protected:
    csObjDowngradeItemList_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeItemList_GetDR_out_struct;
    typedef csObjDowngradeItemList_GetDR_out_struct csObjDowngradeItemList_GetDR_out;
    typedef csObjDowngradeItemList_GetDR_out_struct_var csObjDowngradeItemList_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeItemList_GetDR_out;
    class  csObjDowngradeItemList_UpdateDR_in_struct_var;
    struct  csObjDowngradeItemList_UpdateDR_in_struct {
        typedef csObjDowngradeItemList_UpdateDR_in_struct_var _var_type;
       ::objectIdentifier dcDefID;
       ::csDowngradeItemSequence selectedDCItems;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDowngradeItemList_UpdateDR_in_struct();
       csObjDowngradeItemList_UpdateDR_in_struct(const csObjDowngradeItemList_UpdateDR_in_struct&);
       csObjDowngradeItemList_UpdateDR_in_struct& operator=(const csObjDowngradeItemList_UpdateDR_in_struct&);
       static CORBA::Info<csObjDowngradeItemList_UpdateDR_in_struct> csObjDowngradeItemList_UpdateDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDowngradeItemList_UpdateDR_in_struct


typedef csObjDowngradeItemList_UpdateDR_in_struct* csObjDowngradeItemList_UpdateDR_in_struct_vPtr;
typedef const csObjDowngradeItemList_UpdateDR_in_struct* csObjDowngradeItemList_UpdateDR_in_struct_cvPtr;

class  csObjDowngradeItemList_UpdateDR_in_struct_var
{
    public:

    csObjDowngradeItemList_UpdateDR_in_struct_var ();

    csObjDowngradeItemList_UpdateDR_in_struct_var (csObjDowngradeItemList_UpdateDR_in_struct *_p);

    csObjDowngradeItemList_UpdateDR_in_struct_var (const csObjDowngradeItemList_UpdateDR_in_struct_var &_s);

    csObjDowngradeItemList_UpdateDR_in_struct_var &operator= (csObjDowngradeItemList_UpdateDR_in_struct *_p);

    csObjDowngradeItemList_UpdateDR_in_struct_var &operator= (const csObjDowngradeItemList_UpdateDR_in_struct_var &_s);

    ~csObjDowngradeItemList_UpdateDR_in_struct_var ();

    csObjDowngradeItemList_UpdateDR_in_struct* operator-> ();

    const csObjDowngradeItemList_UpdateDR_in_struct& in() const;
    csObjDowngradeItemList_UpdateDR_in_struct& inout();
    csObjDowngradeItemList_UpdateDR_in_struct*& out();
    csObjDowngradeItemList_UpdateDR_in_struct* _retn();

    operator csObjDowngradeItemList_UpdateDR_in_struct_cvPtr () const;

    operator csObjDowngradeItemList_UpdateDR_in_struct_vPtr& ();

    operator const csObjDowngradeItemList_UpdateDR_in_struct& () const;

    operator csObjDowngradeItemList_UpdateDR_in_struct& ();

    protected:
    csObjDowngradeItemList_UpdateDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeItemList_UpdateDR_in_struct;
    typedef csObjDowngradeItemList_UpdateDR_in_struct csObjDowngradeItemList_UpdateDR_in;
    typedef csObjDowngradeItemList_UpdateDR_in_struct_var csObjDowngradeItemList_UpdateDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeItemList_UpdateDR_in;
    typedef objBase_out csObjDowngradeItemList_UpdateDR_out;
    typedef objBase_out_var csObjDowngradeItemList_UpdateDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeItemList_UpdateDR_out;
    class  csObjEqpMonitor_list_GetDR_out_struct_var;
    struct  csObjEqpMonitor_list_GetDR_out_struct {
        typedef csObjEqpMonitor_list_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpMonitorDetailInfoSequence strEqpMonitorDetailInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitor_list_GetDR_out_struct();
       csObjEqpMonitor_list_GetDR_out_struct(const csObjEqpMonitor_list_GetDR_out_struct&);
       csObjEqpMonitor_list_GetDR_out_struct& operator=(const csObjEqpMonitor_list_GetDR_out_struct&);
       static CORBA::Info<csObjEqpMonitor_list_GetDR_out_struct> csObjEqpMonitor_list_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEqpMonitor_list_GetDR_out_struct


typedef csObjEqpMonitor_list_GetDR_out_struct* csObjEqpMonitor_list_GetDR_out_struct_vPtr;
typedef const csObjEqpMonitor_list_GetDR_out_struct* csObjEqpMonitor_list_GetDR_out_struct_cvPtr;

class  csObjEqpMonitor_list_GetDR_out_struct_var
{
    public:

    csObjEqpMonitor_list_GetDR_out_struct_var ();

    csObjEqpMonitor_list_GetDR_out_struct_var (csObjEqpMonitor_list_GetDR_out_struct *_p);

    csObjEqpMonitor_list_GetDR_out_struct_var (const csObjEqpMonitor_list_GetDR_out_struct_var &_s);

    csObjEqpMonitor_list_GetDR_out_struct_var &operator= (csObjEqpMonitor_list_GetDR_out_struct *_p);

    csObjEqpMonitor_list_GetDR_out_struct_var &operator= (const csObjEqpMonitor_list_GetDR_out_struct_var &_s);

    ~csObjEqpMonitor_list_GetDR_out_struct_var ();

    csObjEqpMonitor_list_GetDR_out_struct* operator-> ();

    const csObjEqpMonitor_list_GetDR_out_struct& in() const;
    csObjEqpMonitor_list_GetDR_out_struct& inout();
    csObjEqpMonitor_list_GetDR_out_struct*& out();
    csObjEqpMonitor_list_GetDR_out_struct* _retn();

    operator csObjEqpMonitor_list_GetDR_out_struct_cvPtr () const;

    operator csObjEqpMonitor_list_GetDR_out_struct_vPtr& ();

    operator const csObjEqpMonitor_list_GetDR_out_struct& () const;

    operator csObjEqpMonitor_list_GetDR_out_struct& ();

    protected:
    csObjEqpMonitor_list_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitor_list_GetDR_out_struct;
    typedef csObjEqpMonitor_list_GetDR_out_struct csObjEqpMonitor_list_GetDR_out;
    typedef csObjEqpMonitor_list_GetDR_out_struct_var csObjEqpMonitor_list_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitor_list_GetDR_out;
    class  csObjEqpMonitor_info_Update_in_struct_var;
    struct  csObjEqpMonitor_info_Update_in_struct {
        typedef csObjEqpMonitor_info_Update_in_struct_var _var_type;
       ::csEqpMonitorDetailInfo strEqpMonitorDetailInfo;
       ::CORBA::String_StructElem actionType;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitor_info_Update_in_struct();
       csObjEqpMonitor_info_Update_in_struct(const csObjEqpMonitor_info_Update_in_struct&);
       csObjEqpMonitor_info_Update_in_struct& operator=(const csObjEqpMonitor_info_Update_in_struct&);
       static CORBA::Info<csObjEqpMonitor_info_Update_in_struct> csObjEqpMonitor_info_Update_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEqpMonitor_info_Update_in_struct


typedef csObjEqpMonitor_info_Update_in_struct* csObjEqpMonitor_info_Update_in_struct_vPtr;
typedef const csObjEqpMonitor_info_Update_in_struct* csObjEqpMonitor_info_Update_in_struct_cvPtr;

class  csObjEqpMonitor_info_Update_in_struct_var
{
    public:

    csObjEqpMonitor_info_Update_in_struct_var ();

    csObjEqpMonitor_info_Update_in_struct_var (csObjEqpMonitor_info_Update_in_struct *_p);

    csObjEqpMonitor_info_Update_in_struct_var (const csObjEqpMonitor_info_Update_in_struct_var &_s);

    csObjEqpMonitor_info_Update_in_struct_var &operator= (csObjEqpMonitor_info_Update_in_struct *_p);

    csObjEqpMonitor_info_Update_in_struct_var &operator= (const csObjEqpMonitor_info_Update_in_struct_var &_s);

    ~csObjEqpMonitor_info_Update_in_struct_var ();

    csObjEqpMonitor_info_Update_in_struct* operator-> ();

    const csObjEqpMonitor_info_Update_in_struct& in() const;
    csObjEqpMonitor_info_Update_in_struct& inout();
    csObjEqpMonitor_info_Update_in_struct*& out();
    csObjEqpMonitor_info_Update_in_struct* _retn();

    operator csObjEqpMonitor_info_Update_in_struct_cvPtr () const;

    operator csObjEqpMonitor_info_Update_in_struct_vPtr& ();

    operator const csObjEqpMonitor_info_Update_in_struct& () const;

    operator csObjEqpMonitor_info_Update_in_struct& ();

    protected:
    csObjEqpMonitor_info_Update_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitor_info_Update_in_struct;
    typedef csObjEqpMonitor_info_Update_in_struct csObjEqpMonitor_info_Update_in;
    typedef csObjEqpMonitor_info_Update_in_struct_var csObjEqpMonitor_info_Update_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitor_info_Update_in;
    class  csObjDowngradeSettingList_GetDR_in_struct_var;
    struct  csObjDowngradeSettingList_GetDR_in_struct {
        typedef csObjDowngradeSettingList_GetDR_in_struct_var _var_type;
       ::CORBA::Any siInfo;
       ::CORBA::String_StructElem productID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDowngradeSettingList_GetDR_in_struct();
       csObjDowngradeSettingList_GetDR_in_struct(const csObjDowngradeSettingList_GetDR_in_struct&);
       csObjDowngradeSettingList_GetDR_in_struct& operator=(const csObjDowngradeSettingList_GetDR_in_struct&);
       static CORBA::Info<csObjDowngradeSettingList_GetDR_in_struct> csObjDowngradeSettingList_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjDowngradeSettingList_GetDR_in_struct


typedef csObjDowngradeSettingList_GetDR_in_struct* csObjDowngradeSettingList_GetDR_in_struct_vPtr;
typedef const csObjDowngradeSettingList_GetDR_in_struct* csObjDowngradeSettingList_GetDR_in_struct_cvPtr;

class  csObjDowngradeSettingList_GetDR_in_struct_var
{
    public:

    csObjDowngradeSettingList_GetDR_in_struct_var ();

    csObjDowngradeSettingList_GetDR_in_struct_var (csObjDowngradeSettingList_GetDR_in_struct *_p);

    csObjDowngradeSettingList_GetDR_in_struct_var (const csObjDowngradeSettingList_GetDR_in_struct_var &_s);

    csObjDowngradeSettingList_GetDR_in_struct_var &operator= (csObjDowngradeSettingList_GetDR_in_struct *_p);

    csObjDowngradeSettingList_GetDR_in_struct_var &operator= (const csObjDowngradeSettingList_GetDR_in_struct_var &_s);

    ~csObjDowngradeSettingList_GetDR_in_struct_var ();

    csObjDowngradeSettingList_GetDR_in_struct* operator-> ();

    const csObjDowngradeSettingList_GetDR_in_struct& in() const;
    csObjDowngradeSettingList_GetDR_in_struct& inout();
    csObjDowngradeSettingList_GetDR_in_struct*& out();
    csObjDowngradeSettingList_GetDR_in_struct* _retn();

    operator csObjDowngradeSettingList_GetDR_in_struct_cvPtr () const;

    operator csObjDowngradeSettingList_GetDR_in_struct_vPtr& ();

    operator const csObjDowngradeSettingList_GetDR_in_struct& () const;

    operator csObjDowngradeSettingList_GetDR_in_struct& ();

    protected:
    csObjDowngradeSettingList_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeSettingList_GetDR_in_struct;
    typedef csObjDowngradeSettingList_GetDR_in_struct csObjDowngradeSettingList_GetDR_in;
    typedef csObjDowngradeSettingList_GetDR_in_struct_var csObjDowngradeSettingList_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeSettingList_GetDR_in;
    class  csObjDowngradeSettingList_GetDR_out_struct_var;
    struct  csObjDowngradeSettingList_GetDR_out_struct {
        typedef csObjDowngradeSettingList_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csDowngradeSettingInfoSequence strDowngradeSettingInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDowngradeSettingList_GetDR_out_struct();
       csObjDowngradeSettingList_GetDR_out_struct(const csObjDowngradeSettingList_GetDR_out_struct&);
       csObjDowngradeSettingList_GetDR_out_struct& operator=(const csObjDowngradeSettingList_GetDR_out_struct&);
       static CORBA::Info<csObjDowngradeSettingList_GetDR_out_struct> csObjDowngradeSettingList_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDowngradeSettingList_GetDR_out_struct


typedef csObjDowngradeSettingList_GetDR_out_struct* csObjDowngradeSettingList_GetDR_out_struct_vPtr;
typedef const csObjDowngradeSettingList_GetDR_out_struct* csObjDowngradeSettingList_GetDR_out_struct_cvPtr;

class  csObjDowngradeSettingList_GetDR_out_struct_var
{
    public:

    csObjDowngradeSettingList_GetDR_out_struct_var ();

    csObjDowngradeSettingList_GetDR_out_struct_var (csObjDowngradeSettingList_GetDR_out_struct *_p);

    csObjDowngradeSettingList_GetDR_out_struct_var (const csObjDowngradeSettingList_GetDR_out_struct_var &_s);

    csObjDowngradeSettingList_GetDR_out_struct_var &operator= (csObjDowngradeSettingList_GetDR_out_struct *_p);

    csObjDowngradeSettingList_GetDR_out_struct_var &operator= (const csObjDowngradeSettingList_GetDR_out_struct_var &_s);

    ~csObjDowngradeSettingList_GetDR_out_struct_var ();

    csObjDowngradeSettingList_GetDR_out_struct* operator-> ();

    const csObjDowngradeSettingList_GetDR_out_struct& in() const;
    csObjDowngradeSettingList_GetDR_out_struct& inout();
    csObjDowngradeSettingList_GetDR_out_struct*& out();
    csObjDowngradeSettingList_GetDR_out_struct* _retn();

    operator csObjDowngradeSettingList_GetDR_out_struct_cvPtr () const;

    operator csObjDowngradeSettingList_GetDR_out_struct_vPtr& ();

    operator const csObjDowngradeSettingList_GetDR_out_struct& () const;

    operator csObjDowngradeSettingList_GetDR_out_struct& ();

    protected:
    csObjDowngradeSettingList_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeSettingList_GetDR_out_struct;
    typedef csObjDowngradeSettingList_GetDR_out_struct csObjDowngradeSettingList_GetDR_out;
    typedef csObjDowngradeSettingList_GetDR_out_struct_var csObjDowngradeSettingList_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeSettingList_GetDR_out;
    class  csObjDowngradeSetting_UpdateDR_in_struct_var;
    struct  csObjDowngradeSetting_UpdateDR_in_struct {
        typedef csObjDowngradeSetting_UpdateDR_in_struct_var _var_type;
       ::csDowngradeSettingInfoSequence strDowngradeSettingInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDowngradeSetting_UpdateDR_in_struct();
       csObjDowngradeSetting_UpdateDR_in_struct(const csObjDowngradeSetting_UpdateDR_in_struct&);
       csObjDowngradeSetting_UpdateDR_in_struct& operator=(const csObjDowngradeSetting_UpdateDR_in_struct&);
       static CORBA::Info<csObjDowngradeSetting_UpdateDR_in_struct> csObjDowngradeSetting_UpdateDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDowngradeSetting_UpdateDR_in_struct


typedef csObjDowngradeSetting_UpdateDR_in_struct* csObjDowngradeSetting_UpdateDR_in_struct_vPtr;
typedef const csObjDowngradeSetting_UpdateDR_in_struct* csObjDowngradeSetting_UpdateDR_in_struct_cvPtr;

class  csObjDowngradeSetting_UpdateDR_in_struct_var
{
    public:

    csObjDowngradeSetting_UpdateDR_in_struct_var ();

    csObjDowngradeSetting_UpdateDR_in_struct_var (csObjDowngradeSetting_UpdateDR_in_struct *_p);

    csObjDowngradeSetting_UpdateDR_in_struct_var (const csObjDowngradeSetting_UpdateDR_in_struct_var &_s);

    csObjDowngradeSetting_UpdateDR_in_struct_var &operator= (csObjDowngradeSetting_UpdateDR_in_struct *_p);

    csObjDowngradeSetting_UpdateDR_in_struct_var &operator= (const csObjDowngradeSetting_UpdateDR_in_struct_var &_s);

    ~csObjDowngradeSetting_UpdateDR_in_struct_var ();

    csObjDowngradeSetting_UpdateDR_in_struct* operator-> ();

    const csObjDowngradeSetting_UpdateDR_in_struct& in() const;
    csObjDowngradeSetting_UpdateDR_in_struct& inout();
    csObjDowngradeSetting_UpdateDR_in_struct*& out();
    csObjDowngradeSetting_UpdateDR_in_struct* _retn();

    operator csObjDowngradeSetting_UpdateDR_in_struct_cvPtr () const;

    operator csObjDowngradeSetting_UpdateDR_in_struct_vPtr& ();

    operator const csObjDowngradeSetting_UpdateDR_in_struct& () const;

    operator csObjDowngradeSetting_UpdateDR_in_struct& ();

    protected:
    csObjDowngradeSetting_UpdateDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeSetting_UpdateDR_in_struct;
    typedef csObjDowngradeSetting_UpdateDR_in_struct csObjDowngradeSetting_UpdateDR_in;
    typedef csObjDowngradeSetting_UpdateDR_in_struct_var csObjDowngradeSetting_UpdateDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeSetting_UpdateDR_in;
    typedef objBase_out csObjDowngradeSetting_UpdateDR_out;
    typedef objBase_out_var csObjDowngradeSetting_UpdateDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDowngradeSetting_UpdateDR_out;
    class  csObjBWSOutSTB_slotMap_InsertDR_in_struct_var;
    struct  csObjBWSOutSTB_slotMap_InsertDR_in_struct {
        typedef csObjBWSOutSTB_slotMap_InsertDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::objectIdentifier portID;
       ::objectIdentifier carrierID;
       ::CORBA::String_StructElem npwType;
       ::objectIdentifier eqpMonitorID;
       ::csNPWSTB_SlotMapSequence strNPWSTB_SlotMapSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWSOutSTB_slotMap_InsertDR_in_struct();
       csObjBWSOutSTB_slotMap_InsertDR_in_struct(const csObjBWSOutSTB_slotMap_InsertDR_in_struct&);
       csObjBWSOutSTB_slotMap_InsertDR_in_struct& operator=(const csObjBWSOutSTB_slotMap_InsertDR_in_struct&);
       static CORBA::Info<csObjBWSOutSTB_slotMap_InsertDR_in_struct> csObjBWSOutSTB_slotMap_InsertDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWSOutSTB_slotMap_InsertDR_in_struct


typedef csObjBWSOutSTB_slotMap_InsertDR_in_struct* csObjBWSOutSTB_slotMap_InsertDR_in_struct_vPtr;
typedef const csObjBWSOutSTB_slotMap_InsertDR_in_struct* csObjBWSOutSTB_slotMap_InsertDR_in_struct_cvPtr;

class  csObjBWSOutSTB_slotMap_InsertDR_in_struct_var
{
    public:

    csObjBWSOutSTB_slotMap_InsertDR_in_struct_var ();

    csObjBWSOutSTB_slotMap_InsertDR_in_struct_var (csObjBWSOutSTB_slotMap_InsertDR_in_struct *_p);

    csObjBWSOutSTB_slotMap_InsertDR_in_struct_var (const csObjBWSOutSTB_slotMap_InsertDR_in_struct_var &_s);

    csObjBWSOutSTB_slotMap_InsertDR_in_struct_var &operator= (csObjBWSOutSTB_slotMap_InsertDR_in_struct *_p);

    csObjBWSOutSTB_slotMap_InsertDR_in_struct_var &operator= (const csObjBWSOutSTB_slotMap_InsertDR_in_struct_var &_s);

    ~csObjBWSOutSTB_slotMap_InsertDR_in_struct_var ();

    csObjBWSOutSTB_slotMap_InsertDR_in_struct* operator-> ();

    const csObjBWSOutSTB_slotMap_InsertDR_in_struct& in() const;
    csObjBWSOutSTB_slotMap_InsertDR_in_struct& inout();
    csObjBWSOutSTB_slotMap_InsertDR_in_struct*& out();
    csObjBWSOutSTB_slotMap_InsertDR_in_struct* _retn();

    operator csObjBWSOutSTB_slotMap_InsertDR_in_struct_cvPtr () const;

    operator csObjBWSOutSTB_slotMap_InsertDR_in_struct_vPtr& ();

    operator const csObjBWSOutSTB_slotMap_InsertDR_in_struct& () const;

    operator csObjBWSOutSTB_slotMap_InsertDR_in_struct& ();

    protected:
    csObjBWSOutSTB_slotMap_InsertDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_InsertDR_in_struct;
    typedef csObjBWSOutSTB_slotMap_InsertDR_in_struct csObjBWSOutSTB_slotMap_InsertDR_in;
    typedef csObjBWSOutSTB_slotMap_InsertDR_in_struct_var csObjBWSOutSTB_slotMap_InsertDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_InsertDR_in;
    typedef objBase_out csObjBWSOutSTB_slotMap_InsertDR_out;
    typedef objBase_out_var csObjBWSOutSTB_slotMap_InsertDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_InsertDR_out;
    class  csObjBWSOutSTB_slotMap_GetDR_in_struct_var;
    struct  csObjBWSOutSTB_slotMap_GetDR_in_struct {
        typedef csObjBWSOutSTB_slotMap_GetDR_in_struct_var _var_type;
       ::objectIdentifier carrierID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWSOutSTB_slotMap_GetDR_in_struct();
       csObjBWSOutSTB_slotMap_GetDR_in_struct(const csObjBWSOutSTB_slotMap_GetDR_in_struct&);
       csObjBWSOutSTB_slotMap_GetDR_in_struct& operator=(const csObjBWSOutSTB_slotMap_GetDR_in_struct&);
       static CORBA::Info<csObjBWSOutSTB_slotMap_GetDR_in_struct> csObjBWSOutSTB_slotMap_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWSOutSTB_slotMap_GetDR_in_struct


typedef csObjBWSOutSTB_slotMap_GetDR_in_struct* csObjBWSOutSTB_slotMap_GetDR_in_struct_vPtr;
typedef const csObjBWSOutSTB_slotMap_GetDR_in_struct* csObjBWSOutSTB_slotMap_GetDR_in_struct_cvPtr;

class  csObjBWSOutSTB_slotMap_GetDR_in_struct_var
{
    public:

    csObjBWSOutSTB_slotMap_GetDR_in_struct_var ();

    csObjBWSOutSTB_slotMap_GetDR_in_struct_var (csObjBWSOutSTB_slotMap_GetDR_in_struct *_p);

    csObjBWSOutSTB_slotMap_GetDR_in_struct_var (const csObjBWSOutSTB_slotMap_GetDR_in_struct_var &_s);

    csObjBWSOutSTB_slotMap_GetDR_in_struct_var &operator= (csObjBWSOutSTB_slotMap_GetDR_in_struct *_p);

    csObjBWSOutSTB_slotMap_GetDR_in_struct_var &operator= (const csObjBWSOutSTB_slotMap_GetDR_in_struct_var &_s);

    ~csObjBWSOutSTB_slotMap_GetDR_in_struct_var ();

    csObjBWSOutSTB_slotMap_GetDR_in_struct* operator-> ();

    const csObjBWSOutSTB_slotMap_GetDR_in_struct& in() const;
    csObjBWSOutSTB_slotMap_GetDR_in_struct& inout();
    csObjBWSOutSTB_slotMap_GetDR_in_struct*& out();
    csObjBWSOutSTB_slotMap_GetDR_in_struct* _retn();

    operator csObjBWSOutSTB_slotMap_GetDR_in_struct_cvPtr () const;

    operator csObjBWSOutSTB_slotMap_GetDR_in_struct_vPtr& ();

    operator const csObjBWSOutSTB_slotMap_GetDR_in_struct& () const;

    operator csObjBWSOutSTB_slotMap_GetDR_in_struct& ();

    protected:
    csObjBWSOutSTB_slotMap_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_GetDR_in_struct;
    typedef csObjBWSOutSTB_slotMap_GetDR_in_struct csObjBWSOutSTB_slotMap_GetDR_in;
    typedef csObjBWSOutSTB_slotMap_GetDR_in_struct_var csObjBWSOutSTB_slotMap_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_GetDR_in;
    class  csObjBWSOutSTB_slotMap_GetDR_out_struct_var;
    struct  csObjBWSOutSTB_slotMap_GetDR_out_struct {
        typedef csObjBWSOutSTB_slotMap_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier BWSID;
       ::objectIdentifier portID;
       ::objectIdentifier carrierID;
       ::CORBA::String_StructElem npwType;
       ::objectIdentifier eqpMonitorID;
       ::csNPWSTB_SlotMapSequence strNPWSTB_SlotMapSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWSOutSTB_slotMap_GetDR_out_struct();
       csObjBWSOutSTB_slotMap_GetDR_out_struct(const csObjBWSOutSTB_slotMap_GetDR_out_struct&);
       csObjBWSOutSTB_slotMap_GetDR_out_struct& operator=(const csObjBWSOutSTB_slotMap_GetDR_out_struct&);
       static CORBA::Info<csObjBWSOutSTB_slotMap_GetDR_out_struct> csObjBWSOutSTB_slotMap_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWSOutSTB_slotMap_GetDR_out_struct


typedef csObjBWSOutSTB_slotMap_GetDR_out_struct* csObjBWSOutSTB_slotMap_GetDR_out_struct_vPtr;
typedef const csObjBWSOutSTB_slotMap_GetDR_out_struct* csObjBWSOutSTB_slotMap_GetDR_out_struct_cvPtr;

class  csObjBWSOutSTB_slotMap_GetDR_out_struct_var
{
    public:

    csObjBWSOutSTB_slotMap_GetDR_out_struct_var ();

    csObjBWSOutSTB_slotMap_GetDR_out_struct_var (csObjBWSOutSTB_slotMap_GetDR_out_struct *_p);

    csObjBWSOutSTB_slotMap_GetDR_out_struct_var (const csObjBWSOutSTB_slotMap_GetDR_out_struct_var &_s);

    csObjBWSOutSTB_slotMap_GetDR_out_struct_var &operator= (csObjBWSOutSTB_slotMap_GetDR_out_struct *_p);

    csObjBWSOutSTB_slotMap_GetDR_out_struct_var &operator= (const csObjBWSOutSTB_slotMap_GetDR_out_struct_var &_s);

    ~csObjBWSOutSTB_slotMap_GetDR_out_struct_var ();

    csObjBWSOutSTB_slotMap_GetDR_out_struct* operator-> ();

    const csObjBWSOutSTB_slotMap_GetDR_out_struct& in() const;
    csObjBWSOutSTB_slotMap_GetDR_out_struct& inout();
    csObjBWSOutSTB_slotMap_GetDR_out_struct*& out();
    csObjBWSOutSTB_slotMap_GetDR_out_struct* _retn();

    operator csObjBWSOutSTB_slotMap_GetDR_out_struct_cvPtr () const;

    operator csObjBWSOutSTB_slotMap_GetDR_out_struct_vPtr& ();

    operator const csObjBWSOutSTB_slotMap_GetDR_out_struct& () const;

    operator csObjBWSOutSTB_slotMap_GetDR_out_struct& ();

    protected:
    csObjBWSOutSTB_slotMap_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_GetDR_out_struct;
    typedef csObjBWSOutSTB_slotMap_GetDR_out_struct csObjBWSOutSTB_slotMap_GetDR_out;
    typedef csObjBWSOutSTB_slotMap_GetDR_out_struct_var csObjBWSOutSTB_slotMap_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_GetDR_out;
    class  csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var;
    struct  csObjBWSOutSTB_slotMap_DeleteDR_in_struct {
        typedef csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var _var_type;
       ::objectIdentifier carrierID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWSOutSTB_slotMap_DeleteDR_in_struct();
       csObjBWSOutSTB_slotMap_DeleteDR_in_struct(const csObjBWSOutSTB_slotMap_DeleteDR_in_struct&);
       csObjBWSOutSTB_slotMap_DeleteDR_in_struct& operator=(const csObjBWSOutSTB_slotMap_DeleteDR_in_struct&);
       static CORBA::Info<csObjBWSOutSTB_slotMap_DeleteDR_in_struct> csObjBWSOutSTB_slotMap_DeleteDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWSOutSTB_slotMap_DeleteDR_in_struct


typedef csObjBWSOutSTB_slotMap_DeleteDR_in_struct* csObjBWSOutSTB_slotMap_DeleteDR_in_struct_vPtr;
typedef const csObjBWSOutSTB_slotMap_DeleteDR_in_struct* csObjBWSOutSTB_slotMap_DeleteDR_in_struct_cvPtr;

class  csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var
{
    public:

    csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var ();

    csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var (csObjBWSOutSTB_slotMap_DeleteDR_in_struct *_p);

    csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var (const csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var &_s);

    csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var &operator= (csObjBWSOutSTB_slotMap_DeleteDR_in_struct *_p);

    csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var &operator= (const csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var &_s);

    ~csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var ();

    csObjBWSOutSTB_slotMap_DeleteDR_in_struct* operator-> ();

    const csObjBWSOutSTB_slotMap_DeleteDR_in_struct& in() const;
    csObjBWSOutSTB_slotMap_DeleteDR_in_struct& inout();
    csObjBWSOutSTB_slotMap_DeleteDR_in_struct*& out();
    csObjBWSOutSTB_slotMap_DeleteDR_in_struct* _retn();

    operator csObjBWSOutSTB_slotMap_DeleteDR_in_struct_cvPtr () const;

    operator csObjBWSOutSTB_slotMap_DeleteDR_in_struct_vPtr& ();

    operator const csObjBWSOutSTB_slotMap_DeleteDR_in_struct& () const;

    operator csObjBWSOutSTB_slotMap_DeleteDR_in_struct& ();

    protected:
    csObjBWSOutSTB_slotMap_DeleteDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_DeleteDR_in_struct;
    typedef csObjBWSOutSTB_slotMap_DeleteDR_in_struct csObjBWSOutSTB_slotMap_DeleteDR_in;
    typedef csObjBWSOutSTB_slotMap_DeleteDR_in_struct_var csObjBWSOutSTB_slotMap_DeleteDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_DeleteDR_in;
    typedef objBase_out csObjBWSOutSTB_slotMap_DeleteDR_out;
    typedef objBase_out_var csObjBWSOutSTB_slotMap_DeleteDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSOutSTB_slotMap_DeleteDR_out;
    class  csObjEqpMonitor_info_Get_out_struct_var;
    struct  csObjEqpMonitor_info_Get_out_struct {
        typedef csObjEqpMonitor_info_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpMonitorDetailInfoSequence strEqpMonitorDetailInfos;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitor_info_Get_out_struct();
       csObjEqpMonitor_info_Get_out_struct(const csObjEqpMonitor_info_Get_out_struct&);
       csObjEqpMonitor_info_Get_out_struct& operator=(const csObjEqpMonitor_info_Get_out_struct&);
       static CORBA::Info<csObjEqpMonitor_info_Get_out_struct> csObjEqpMonitor_info_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEqpMonitor_info_Get_out_struct


typedef csObjEqpMonitor_info_Get_out_struct* csObjEqpMonitor_info_Get_out_struct_vPtr;
typedef const csObjEqpMonitor_info_Get_out_struct* csObjEqpMonitor_info_Get_out_struct_cvPtr;

class  csObjEqpMonitor_info_Get_out_struct_var
{
    public:

    csObjEqpMonitor_info_Get_out_struct_var ();

    csObjEqpMonitor_info_Get_out_struct_var (csObjEqpMonitor_info_Get_out_struct *_p);

    csObjEqpMonitor_info_Get_out_struct_var (const csObjEqpMonitor_info_Get_out_struct_var &_s);

    csObjEqpMonitor_info_Get_out_struct_var &operator= (csObjEqpMonitor_info_Get_out_struct *_p);

    csObjEqpMonitor_info_Get_out_struct_var &operator= (const csObjEqpMonitor_info_Get_out_struct_var &_s);

    ~csObjEqpMonitor_info_Get_out_struct_var ();

    csObjEqpMonitor_info_Get_out_struct* operator-> ();

    const csObjEqpMonitor_info_Get_out_struct& in() const;
    csObjEqpMonitor_info_Get_out_struct& inout();
    csObjEqpMonitor_info_Get_out_struct*& out();
    csObjEqpMonitor_info_Get_out_struct* _retn();

    operator csObjEqpMonitor_info_Get_out_struct_cvPtr () const;

    operator csObjEqpMonitor_info_Get_out_struct_vPtr& ();

    operator const csObjEqpMonitor_info_Get_out_struct& () const;

    operator csObjEqpMonitor_info_Get_out_struct& ();

    protected:
    csObjEqpMonitor_info_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitor_info_Get_out_struct;
    typedef csObjEqpMonitor_info_Get_out_struct csObjEqpMonitor_info_Get_out;
    typedef csObjEqpMonitor_info_Get_out_struct_var csObjEqpMonitor_info_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitor_info_Get_out;
    class  csObjEqpMonitorLot_prepareIDSet_in_struct_var;
    struct  csObjEqpMonitorLot_prepareIDSet_in_struct {
        typedef csObjEqpMonitorLot_prepareIDSet_in_struct_var _var_type;
       ::objectIdentifier eqpMonitorID;
       ::objectIdentifier carrierID;
       ::objectIdentifierSequence lotIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitorLot_prepareIDSet_in_struct();
       csObjEqpMonitorLot_prepareIDSet_in_struct(const csObjEqpMonitorLot_prepareIDSet_in_struct&);
       csObjEqpMonitorLot_prepareIDSet_in_struct& operator=(const csObjEqpMonitorLot_prepareIDSet_in_struct&);
       static CORBA::Info<csObjEqpMonitorLot_prepareIDSet_in_struct> csObjEqpMonitorLot_prepareIDSet_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEqpMonitorLot_prepareIDSet_in_struct


typedef csObjEqpMonitorLot_prepareIDSet_in_struct* csObjEqpMonitorLot_prepareIDSet_in_struct_vPtr;
typedef const csObjEqpMonitorLot_prepareIDSet_in_struct* csObjEqpMonitorLot_prepareIDSet_in_struct_cvPtr;

class  csObjEqpMonitorLot_prepareIDSet_in_struct_var
{
    public:

    csObjEqpMonitorLot_prepareIDSet_in_struct_var ();

    csObjEqpMonitorLot_prepareIDSet_in_struct_var (csObjEqpMonitorLot_prepareIDSet_in_struct *_p);

    csObjEqpMonitorLot_prepareIDSet_in_struct_var (const csObjEqpMonitorLot_prepareIDSet_in_struct_var &_s);

    csObjEqpMonitorLot_prepareIDSet_in_struct_var &operator= (csObjEqpMonitorLot_prepareIDSet_in_struct *_p);

    csObjEqpMonitorLot_prepareIDSet_in_struct_var &operator= (const csObjEqpMonitorLot_prepareIDSet_in_struct_var &_s);

    ~csObjEqpMonitorLot_prepareIDSet_in_struct_var ();

    csObjEqpMonitorLot_prepareIDSet_in_struct* operator-> ();

    const csObjEqpMonitorLot_prepareIDSet_in_struct& in() const;
    csObjEqpMonitorLot_prepareIDSet_in_struct& inout();
    csObjEqpMonitorLot_prepareIDSet_in_struct*& out();
    csObjEqpMonitorLot_prepareIDSet_in_struct* _retn();

    operator csObjEqpMonitorLot_prepareIDSet_in_struct_cvPtr () const;

    operator csObjEqpMonitorLot_prepareIDSet_in_struct_vPtr& ();

    operator const csObjEqpMonitorLot_prepareIDSet_in_struct& () const;

    operator csObjEqpMonitorLot_prepareIDSet_in_struct& ();

    protected:
    csObjEqpMonitorLot_prepareIDSet_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorLot_prepareIDSet_in_struct;
    typedef csObjEqpMonitorLot_prepareIDSet_in_struct csObjEqpMonitorLot_prepareIDSet_in;
    typedef csObjEqpMonitorLot_prepareIDSet_in_struct_var csObjEqpMonitorLot_prepareIDSet_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorLot_prepareIDSet_in;
    typedef objBase_out csObjEqpMonitorLot_prepareIDSet_out;
    typedef objBase_out_var csObjEqpMonitorLot_prepareIDSet_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorLot_prepareIDSet_out;
    class  csObjNPW_sourceProductInfo_GetDR_in_struct_var;
    struct  csObjNPW_sourceProductInfo_GetDR_in_struct {
        typedef csObjNPW_sourceProductInfo_GetDR_in_struct_var _var_type;
       ::objectIdentifier productID;
       ::objectIdentifier bankID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjNPW_sourceProductInfo_GetDR_in_struct();
       csObjNPW_sourceProductInfo_GetDR_in_struct(const csObjNPW_sourceProductInfo_GetDR_in_struct&);
       csObjNPW_sourceProductInfo_GetDR_in_struct& operator=(const csObjNPW_sourceProductInfo_GetDR_in_struct&);
       static CORBA::Info<csObjNPW_sourceProductInfo_GetDR_in_struct> csObjNPW_sourceProductInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjNPW_sourceProductInfo_GetDR_in_struct


typedef csObjNPW_sourceProductInfo_GetDR_in_struct* csObjNPW_sourceProductInfo_GetDR_in_struct_vPtr;
typedef const csObjNPW_sourceProductInfo_GetDR_in_struct* csObjNPW_sourceProductInfo_GetDR_in_struct_cvPtr;

class  csObjNPW_sourceProductInfo_GetDR_in_struct_var
{
    public:

    csObjNPW_sourceProductInfo_GetDR_in_struct_var ();

    csObjNPW_sourceProductInfo_GetDR_in_struct_var (csObjNPW_sourceProductInfo_GetDR_in_struct *_p);

    csObjNPW_sourceProductInfo_GetDR_in_struct_var (const csObjNPW_sourceProductInfo_GetDR_in_struct_var &_s);

    csObjNPW_sourceProductInfo_GetDR_in_struct_var &operator= (csObjNPW_sourceProductInfo_GetDR_in_struct *_p);

    csObjNPW_sourceProductInfo_GetDR_in_struct_var &operator= (const csObjNPW_sourceProductInfo_GetDR_in_struct_var &_s);

    ~csObjNPW_sourceProductInfo_GetDR_in_struct_var ();

    csObjNPW_sourceProductInfo_GetDR_in_struct* operator-> ();

    const csObjNPW_sourceProductInfo_GetDR_in_struct& in() const;
    csObjNPW_sourceProductInfo_GetDR_in_struct& inout();
    csObjNPW_sourceProductInfo_GetDR_in_struct*& out();
    csObjNPW_sourceProductInfo_GetDR_in_struct* _retn();

    operator csObjNPW_sourceProductInfo_GetDR_in_struct_cvPtr () const;

    operator csObjNPW_sourceProductInfo_GetDR_in_struct_vPtr& ();

    operator const csObjNPW_sourceProductInfo_GetDR_in_struct& () const;

    operator csObjNPW_sourceProductInfo_GetDR_in_struct& ();

    protected:
    csObjNPW_sourceProductInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sourceProductInfo_GetDR_in_struct;
    typedef csObjNPW_sourceProductInfo_GetDR_in_struct csObjNPW_sourceProductInfo_GetDR_in;
    typedef csObjNPW_sourceProductInfo_GetDR_in_struct_var csObjNPW_sourceProductInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sourceProductInfo_GetDR_in;
    class  csObjNPW_sourceProductInfo_GetDR_out_struct_var;
    struct  csObjNPW_sourceProductInfo_GetDR_out_struct {
        typedef csObjNPW_sourceProductInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csSourceProductInBWSSequence sourceProductSeq;
       ::CORBA::Long totalAvailableQty;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjNPW_sourceProductInfo_GetDR_out_struct();
       csObjNPW_sourceProductInfo_GetDR_out_struct(const csObjNPW_sourceProductInfo_GetDR_out_struct&);
       csObjNPW_sourceProductInfo_GetDR_out_struct& operator=(const csObjNPW_sourceProductInfo_GetDR_out_struct&);
       static CORBA::Info<csObjNPW_sourceProductInfo_GetDR_out_struct> csObjNPW_sourceProductInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjNPW_sourceProductInfo_GetDR_out_struct


typedef csObjNPW_sourceProductInfo_GetDR_out_struct* csObjNPW_sourceProductInfo_GetDR_out_struct_vPtr;
typedef const csObjNPW_sourceProductInfo_GetDR_out_struct* csObjNPW_sourceProductInfo_GetDR_out_struct_cvPtr;

class  csObjNPW_sourceProductInfo_GetDR_out_struct_var
{
    public:

    csObjNPW_sourceProductInfo_GetDR_out_struct_var ();

    csObjNPW_sourceProductInfo_GetDR_out_struct_var (csObjNPW_sourceProductInfo_GetDR_out_struct *_p);

    csObjNPW_sourceProductInfo_GetDR_out_struct_var (const csObjNPW_sourceProductInfo_GetDR_out_struct_var &_s);

    csObjNPW_sourceProductInfo_GetDR_out_struct_var &operator= (csObjNPW_sourceProductInfo_GetDR_out_struct *_p);

    csObjNPW_sourceProductInfo_GetDR_out_struct_var &operator= (const csObjNPW_sourceProductInfo_GetDR_out_struct_var &_s);

    ~csObjNPW_sourceProductInfo_GetDR_out_struct_var ();

    csObjNPW_sourceProductInfo_GetDR_out_struct* operator-> ();

    const csObjNPW_sourceProductInfo_GetDR_out_struct& in() const;
    csObjNPW_sourceProductInfo_GetDR_out_struct& inout();
    csObjNPW_sourceProductInfo_GetDR_out_struct*& out();
    csObjNPW_sourceProductInfo_GetDR_out_struct* _retn();

    operator csObjNPW_sourceProductInfo_GetDR_out_struct_cvPtr () const;

    operator csObjNPW_sourceProductInfo_GetDR_out_struct_vPtr& ();

    operator const csObjNPW_sourceProductInfo_GetDR_out_struct& () const;

    operator csObjNPW_sourceProductInfo_GetDR_out_struct& ();

    protected:
    csObjNPW_sourceProductInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sourceProductInfo_GetDR_out_struct;
    typedef csObjNPW_sourceProductInfo_GetDR_out_struct csObjNPW_sourceProductInfo_GetDR_out;
    typedef csObjNPW_sourceProductInfo_GetDR_out_struct_var csObjNPW_sourceProductInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sourceProductInfo_GetDR_out;
    class  csObjNPW_sourceWaferInfo_GetDR_in_struct_var;
    struct  csObjNPW_sourceWaferInfo_GetDR_in_struct {
        typedef csObjNPW_sourceWaferInfo_GetDR_in_struct_var _var_type;
       ::CORBA::String_StructElem BWSID;
       ::csAutoBWSOutProductInfoSequence strAutoBWSOutProductInfos;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjNPW_sourceWaferInfo_GetDR_in_struct();
       csObjNPW_sourceWaferInfo_GetDR_in_struct(const csObjNPW_sourceWaferInfo_GetDR_in_struct&);
       csObjNPW_sourceWaferInfo_GetDR_in_struct& operator=(const csObjNPW_sourceWaferInfo_GetDR_in_struct&);
       static CORBA::Info<csObjNPW_sourceWaferInfo_GetDR_in_struct> csObjNPW_sourceWaferInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjNPW_sourceWaferInfo_GetDR_in_struct


typedef csObjNPW_sourceWaferInfo_GetDR_in_struct* csObjNPW_sourceWaferInfo_GetDR_in_struct_vPtr;
typedef const csObjNPW_sourceWaferInfo_GetDR_in_struct* csObjNPW_sourceWaferInfo_GetDR_in_struct_cvPtr;

class  csObjNPW_sourceWaferInfo_GetDR_in_struct_var
{
    public:

    csObjNPW_sourceWaferInfo_GetDR_in_struct_var ();

    csObjNPW_sourceWaferInfo_GetDR_in_struct_var (csObjNPW_sourceWaferInfo_GetDR_in_struct *_p);

    csObjNPW_sourceWaferInfo_GetDR_in_struct_var (const csObjNPW_sourceWaferInfo_GetDR_in_struct_var &_s);

    csObjNPW_sourceWaferInfo_GetDR_in_struct_var &operator= (csObjNPW_sourceWaferInfo_GetDR_in_struct *_p);

    csObjNPW_sourceWaferInfo_GetDR_in_struct_var &operator= (const csObjNPW_sourceWaferInfo_GetDR_in_struct_var &_s);

    ~csObjNPW_sourceWaferInfo_GetDR_in_struct_var ();

    csObjNPW_sourceWaferInfo_GetDR_in_struct* operator-> ();

    const csObjNPW_sourceWaferInfo_GetDR_in_struct& in() const;
    csObjNPW_sourceWaferInfo_GetDR_in_struct& inout();
    csObjNPW_sourceWaferInfo_GetDR_in_struct*& out();
    csObjNPW_sourceWaferInfo_GetDR_in_struct* _retn();

    operator csObjNPW_sourceWaferInfo_GetDR_in_struct_cvPtr () const;

    operator csObjNPW_sourceWaferInfo_GetDR_in_struct_vPtr& ();

    operator const csObjNPW_sourceWaferInfo_GetDR_in_struct& () const;

    operator csObjNPW_sourceWaferInfo_GetDR_in_struct& ();

    protected:
    csObjNPW_sourceWaferInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sourceWaferInfo_GetDR_in_struct;
    typedef csObjNPW_sourceWaferInfo_GetDR_in_struct csObjNPW_sourceWaferInfo_GetDR_in;
    typedef csObjNPW_sourceWaferInfo_GetDR_in_struct_var csObjNPW_sourceWaferInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sourceWaferInfo_GetDR_in;
    class  csObjNPW_sourceWaferInfo_GetDR_out_struct_var;
    struct  csObjNPW_sourceWaferInfo_GetDR_out_struct {
        typedef csObjNPW_sourceWaferInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSWaferDataSequence strBWSWaferDataSeq;
       ::CORBA::Boolean enoughQty;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjNPW_sourceWaferInfo_GetDR_out_struct();
       csObjNPW_sourceWaferInfo_GetDR_out_struct(const csObjNPW_sourceWaferInfo_GetDR_out_struct&);
       csObjNPW_sourceWaferInfo_GetDR_out_struct& operator=(const csObjNPW_sourceWaferInfo_GetDR_out_struct&);
       static CORBA::Info<csObjNPW_sourceWaferInfo_GetDR_out_struct> csObjNPW_sourceWaferInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjNPW_sourceWaferInfo_GetDR_out_struct


typedef csObjNPW_sourceWaferInfo_GetDR_out_struct* csObjNPW_sourceWaferInfo_GetDR_out_struct_vPtr;
typedef const csObjNPW_sourceWaferInfo_GetDR_out_struct* csObjNPW_sourceWaferInfo_GetDR_out_struct_cvPtr;

class  csObjNPW_sourceWaferInfo_GetDR_out_struct_var
{
    public:

    csObjNPW_sourceWaferInfo_GetDR_out_struct_var ();

    csObjNPW_sourceWaferInfo_GetDR_out_struct_var (csObjNPW_sourceWaferInfo_GetDR_out_struct *_p);

    csObjNPW_sourceWaferInfo_GetDR_out_struct_var (const csObjNPW_sourceWaferInfo_GetDR_out_struct_var &_s);

    csObjNPW_sourceWaferInfo_GetDR_out_struct_var &operator= (csObjNPW_sourceWaferInfo_GetDR_out_struct *_p);

    csObjNPW_sourceWaferInfo_GetDR_out_struct_var &operator= (const csObjNPW_sourceWaferInfo_GetDR_out_struct_var &_s);

    ~csObjNPW_sourceWaferInfo_GetDR_out_struct_var ();

    csObjNPW_sourceWaferInfo_GetDR_out_struct* operator-> ();

    const csObjNPW_sourceWaferInfo_GetDR_out_struct& in() const;
    csObjNPW_sourceWaferInfo_GetDR_out_struct& inout();
    csObjNPW_sourceWaferInfo_GetDR_out_struct*& out();
    csObjNPW_sourceWaferInfo_GetDR_out_struct* _retn();

    operator csObjNPW_sourceWaferInfo_GetDR_out_struct_cvPtr () const;

    operator csObjNPW_sourceWaferInfo_GetDR_out_struct_vPtr& ();

    operator const csObjNPW_sourceWaferInfo_GetDR_out_struct& () const;

    operator csObjNPW_sourceWaferInfo_GetDR_out_struct& ();

    protected:
    csObjNPW_sourceWaferInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sourceWaferInfo_GetDR_out_struct;
    typedef csObjNPW_sourceWaferInfo_GetDR_out_struct csObjNPW_sourceWaferInfo_GetDR_out;
    typedef csObjNPW_sourceWaferInfo_GetDR_out_struct_var csObjNPW_sourceWaferInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_sourceWaferInfo_GetDR_out;
    class  csObjRoute_requiredCarrierCategory_GetDR_in_struct_var;
    struct  csObjRoute_requiredCarrierCategory_GetDR_in_struct {
        typedef csObjRoute_requiredCarrierCategory_GetDR_in_struct_var _var_type;
       ::objectIdentifier routeID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjRoute_requiredCarrierCategory_GetDR_in_struct();
       csObjRoute_requiredCarrierCategory_GetDR_in_struct(const csObjRoute_requiredCarrierCategory_GetDR_in_struct&);
       csObjRoute_requiredCarrierCategory_GetDR_in_struct& operator=(const csObjRoute_requiredCarrierCategory_GetDR_in_struct&);
       static CORBA::Info<csObjRoute_requiredCarrierCategory_GetDR_in_struct> csObjRoute_requiredCarrierCategory_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjRoute_requiredCarrierCategory_GetDR_in_struct


typedef csObjRoute_requiredCarrierCategory_GetDR_in_struct* csObjRoute_requiredCarrierCategory_GetDR_in_struct_vPtr;
typedef const csObjRoute_requiredCarrierCategory_GetDR_in_struct* csObjRoute_requiredCarrierCategory_GetDR_in_struct_cvPtr;

class  csObjRoute_requiredCarrierCategory_GetDR_in_struct_var
{
    public:

    csObjRoute_requiredCarrierCategory_GetDR_in_struct_var ();

    csObjRoute_requiredCarrierCategory_GetDR_in_struct_var (csObjRoute_requiredCarrierCategory_GetDR_in_struct *_p);

    csObjRoute_requiredCarrierCategory_GetDR_in_struct_var (const csObjRoute_requiredCarrierCategory_GetDR_in_struct_var &_s);

    csObjRoute_requiredCarrierCategory_GetDR_in_struct_var &operator= (csObjRoute_requiredCarrierCategory_GetDR_in_struct *_p);

    csObjRoute_requiredCarrierCategory_GetDR_in_struct_var &operator= (const csObjRoute_requiredCarrierCategory_GetDR_in_struct_var &_s);

    ~csObjRoute_requiredCarrierCategory_GetDR_in_struct_var ();

    csObjRoute_requiredCarrierCategory_GetDR_in_struct* operator-> ();

    const csObjRoute_requiredCarrierCategory_GetDR_in_struct& in() const;
    csObjRoute_requiredCarrierCategory_GetDR_in_struct& inout();
    csObjRoute_requiredCarrierCategory_GetDR_in_struct*& out();
    csObjRoute_requiredCarrierCategory_GetDR_in_struct* _retn();

    operator csObjRoute_requiredCarrierCategory_GetDR_in_struct_cvPtr () const;

    operator csObjRoute_requiredCarrierCategory_GetDR_in_struct_vPtr& ();

    operator const csObjRoute_requiredCarrierCategory_GetDR_in_struct& () const;

    operator csObjRoute_requiredCarrierCategory_GetDR_in_struct& ();

    protected:
    csObjRoute_requiredCarrierCategory_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjRoute_requiredCarrierCategory_GetDR_in_struct;
    typedef csObjRoute_requiredCarrierCategory_GetDR_in_struct csObjRoute_requiredCarrierCategory_GetDR_in;
    typedef csObjRoute_requiredCarrierCategory_GetDR_in_struct_var csObjRoute_requiredCarrierCategory_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjRoute_requiredCarrierCategory_GetDR_in;
    class  csObjRoute_requiredCarrierCategory_GetDR_out_struct_var;
    struct  csObjRoute_requiredCarrierCategory_GetDR_out_struct {
        typedef csObjRoute_requiredCarrierCategory_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem requiredCarrierCategory;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjRoute_requiredCarrierCategory_GetDR_out_struct();
       csObjRoute_requiredCarrierCategory_GetDR_out_struct(const csObjRoute_requiredCarrierCategory_GetDR_out_struct&);
       csObjRoute_requiredCarrierCategory_GetDR_out_struct& operator=(const csObjRoute_requiredCarrierCategory_GetDR_out_struct&);
       static CORBA::Info<csObjRoute_requiredCarrierCategory_GetDR_out_struct> csObjRoute_requiredCarrierCategory_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjRoute_requiredCarrierCategory_GetDR_out_struct


typedef csObjRoute_requiredCarrierCategory_GetDR_out_struct* csObjRoute_requiredCarrierCategory_GetDR_out_struct_vPtr;
typedef const csObjRoute_requiredCarrierCategory_GetDR_out_struct* csObjRoute_requiredCarrierCategory_GetDR_out_struct_cvPtr;

class  csObjRoute_requiredCarrierCategory_GetDR_out_struct_var
{
    public:

    csObjRoute_requiredCarrierCategory_GetDR_out_struct_var ();

    csObjRoute_requiredCarrierCategory_GetDR_out_struct_var (csObjRoute_requiredCarrierCategory_GetDR_out_struct *_p);

    csObjRoute_requiredCarrierCategory_GetDR_out_struct_var (const csObjRoute_requiredCarrierCategory_GetDR_out_struct_var &_s);

    csObjRoute_requiredCarrierCategory_GetDR_out_struct_var &operator= (csObjRoute_requiredCarrierCategory_GetDR_out_struct *_p);

    csObjRoute_requiredCarrierCategory_GetDR_out_struct_var &operator= (const csObjRoute_requiredCarrierCategory_GetDR_out_struct_var &_s);

    ~csObjRoute_requiredCarrierCategory_GetDR_out_struct_var ();

    csObjRoute_requiredCarrierCategory_GetDR_out_struct* operator-> ();

    const csObjRoute_requiredCarrierCategory_GetDR_out_struct& in() const;
    csObjRoute_requiredCarrierCategory_GetDR_out_struct& inout();
    csObjRoute_requiredCarrierCategory_GetDR_out_struct*& out();
    csObjRoute_requiredCarrierCategory_GetDR_out_struct* _retn();

    operator csObjRoute_requiredCarrierCategory_GetDR_out_struct_cvPtr () const;

    operator csObjRoute_requiredCarrierCategory_GetDR_out_struct_vPtr& ();

    operator const csObjRoute_requiredCarrierCategory_GetDR_out_struct& () const;

    operator csObjRoute_requiredCarrierCategory_GetDR_out_struct& ();

    protected:
    csObjRoute_requiredCarrierCategory_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjRoute_requiredCarrierCategory_GetDR_out_struct;
    typedef csObjRoute_requiredCarrierCategory_GetDR_out_struct csObjRoute_requiredCarrierCategory_GetDR_out;
    typedef csObjRoute_requiredCarrierCategory_GetDR_out_struct_var csObjRoute_requiredCarrierCategory_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjRoute_requiredCarrierCategory_GetDR_out;
    class  csObjNPW_emptyCarrier_Pickup_in_struct_var;
    struct  csObjNPW_emptyCarrier_Pickup_in_struct {
        typedef csObjNPW_emptyCarrier_Pickup_in_struct_var _var_type;
       ::CORBA::String_StructElem cassetteCategory;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjNPW_emptyCarrier_Pickup_in_struct();
       csObjNPW_emptyCarrier_Pickup_in_struct(const csObjNPW_emptyCarrier_Pickup_in_struct&);
       csObjNPW_emptyCarrier_Pickup_in_struct& operator=(const csObjNPW_emptyCarrier_Pickup_in_struct&);
       static CORBA::Info<csObjNPW_emptyCarrier_Pickup_in_struct> csObjNPW_emptyCarrier_Pickup_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjNPW_emptyCarrier_Pickup_in_struct


typedef csObjNPW_emptyCarrier_Pickup_in_struct* csObjNPW_emptyCarrier_Pickup_in_struct_vPtr;
typedef const csObjNPW_emptyCarrier_Pickup_in_struct* csObjNPW_emptyCarrier_Pickup_in_struct_cvPtr;

class  csObjNPW_emptyCarrier_Pickup_in_struct_var
{
    public:

    csObjNPW_emptyCarrier_Pickup_in_struct_var ();

    csObjNPW_emptyCarrier_Pickup_in_struct_var (csObjNPW_emptyCarrier_Pickup_in_struct *_p);

    csObjNPW_emptyCarrier_Pickup_in_struct_var (const csObjNPW_emptyCarrier_Pickup_in_struct_var &_s);

    csObjNPW_emptyCarrier_Pickup_in_struct_var &operator= (csObjNPW_emptyCarrier_Pickup_in_struct *_p);

    csObjNPW_emptyCarrier_Pickup_in_struct_var &operator= (const csObjNPW_emptyCarrier_Pickup_in_struct_var &_s);

    ~csObjNPW_emptyCarrier_Pickup_in_struct_var ();

    csObjNPW_emptyCarrier_Pickup_in_struct* operator-> ();

    const csObjNPW_emptyCarrier_Pickup_in_struct& in() const;
    csObjNPW_emptyCarrier_Pickup_in_struct& inout();
    csObjNPW_emptyCarrier_Pickup_in_struct*& out();
    csObjNPW_emptyCarrier_Pickup_in_struct* _retn();

    operator csObjNPW_emptyCarrier_Pickup_in_struct_cvPtr () const;

    operator csObjNPW_emptyCarrier_Pickup_in_struct_vPtr& ();

    operator const csObjNPW_emptyCarrier_Pickup_in_struct& () const;

    operator csObjNPW_emptyCarrier_Pickup_in_struct& ();

    protected:
    csObjNPW_emptyCarrier_Pickup_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_emptyCarrier_Pickup_in_struct;
    typedef csObjNPW_emptyCarrier_Pickup_in_struct csObjNPW_emptyCarrier_Pickup_in;
    typedef csObjNPW_emptyCarrier_Pickup_in_struct_var csObjNPW_emptyCarrier_Pickup_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_emptyCarrier_Pickup_in;
    class  csObjNPW_emptyCarrier_Pickup_out_struct_var;
    struct  csObjNPW_emptyCarrier_Pickup_out_struct {
        typedef csObjNPW_emptyCarrier_Pickup_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier carrierID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjNPW_emptyCarrier_Pickup_out_struct();
       csObjNPW_emptyCarrier_Pickup_out_struct(const csObjNPW_emptyCarrier_Pickup_out_struct&);
       csObjNPW_emptyCarrier_Pickup_out_struct& operator=(const csObjNPW_emptyCarrier_Pickup_out_struct&);
       static CORBA::Info<csObjNPW_emptyCarrier_Pickup_out_struct> csObjNPW_emptyCarrier_Pickup_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjNPW_emptyCarrier_Pickup_out_struct


typedef csObjNPW_emptyCarrier_Pickup_out_struct* csObjNPW_emptyCarrier_Pickup_out_struct_vPtr;
typedef const csObjNPW_emptyCarrier_Pickup_out_struct* csObjNPW_emptyCarrier_Pickup_out_struct_cvPtr;

class  csObjNPW_emptyCarrier_Pickup_out_struct_var
{
    public:

    csObjNPW_emptyCarrier_Pickup_out_struct_var ();

    csObjNPW_emptyCarrier_Pickup_out_struct_var (csObjNPW_emptyCarrier_Pickup_out_struct *_p);

    csObjNPW_emptyCarrier_Pickup_out_struct_var (const csObjNPW_emptyCarrier_Pickup_out_struct_var &_s);

    csObjNPW_emptyCarrier_Pickup_out_struct_var &operator= (csObjNPW_emptyCarrier_Pickup_out_struct *_p);

    csObjNPW_emptyCarrier_Pickup_out_struct_var &operator= (const csObjNPW_emptyCarrier_Pickup_out_struct_var &_s);

    ~csObjNPW_emptyCarrier_Pickup_out_struct_var ();

    csObjNPW_emptyCarrier_Pickup_out_struct* operator-> ();

    const csObjNPW_emptyCarrier_Pickup_out_struct& in() const;
    csObjNPW_emptyCarrier_Pickup_out_struct& inout();
    csObjNPW_emptyCarrier_Pickup_out_struct*& out();
    csObjNPW_emptyCarrier_Pickup_out_struct* _retn();

    operator csObjNPW_emptyCarrier_Pickup_out_struct_cvPtr () const;

    operator csObjNPW_emptyCarrier_Pickup_out_struct_vPtr& ();

    operator const csObjNPW_emptyCarrier_Pickup_out_struct& () const;

    operator csObjNPW_emptyCarrier_Pickup_out_struct& ();

    protected:
    csObjNPW_emptyCarrier_Pickup_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_emptyCarrier_Pickup_out_struct;
    typedef csObjNPW_emptyCarrier_Pickup_out_struct csObjNPW_emptyCarrier_Pickup_out;
    typedef csObjNPW_emptyCarrier_Pickup_out_struct_var csObjNPW_emptyCarrier_Pickup_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_emptyCarrier_Pickup_out;
    class  csbjNPW_CheckCoditionForBWSOut_in_struct_var;
    struct  csbjNPW_CheckCoditionForBWSOut_in_struct {
        typedef csbjNPW_CheckCoditionForBWSOut_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::objectIdentifier emptyCarrierID;
       ::pptEqpPortStatus strEqpPortStatus;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csbjNPW_CheckCoditionForBWSOut_in_struct();
       csbjNPW_CheckCoditionForBWSOut_in_struct(const csbjNPW_CheckCoditionForBWSOut_in_struct&);
       csbjNPW_CheckCoditionForBWSOut_in_struct& operator=(const csbjNPW_CheckCoditionForBWSOut_in_struct&);
       static CORBA::Info<csbjNPW_CheckCoditionForBWSOut_in_struct> csbjNPW_CheckCoditionForBWSOut_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csbjNPW_CheckCoditionForBWSOut_in_struct


typedef csbjNPW_CheckCoditionForBWSOut_in_struct* csbjNPW_CheckCoditionForBWSOut_in_struct_vPtr;
typedef const csbjNPW_CheckCoditionForBWSOut_in_struct* csbjNPW_CheckCoditionForBWSOut_in_struct_cvPtr;

class  csbjNPW_CheckCoditionForBWSOut_in_struct_var
{
    public:

    csbjNPW_CheckCoditionForBWSOut_in_struct_var ();

    csbjNPW_CheckCoditionForBWSOut_in_struct_var (csbjNPW_CheckCoditionForBWSOut_in_struct *_p);

    csbjNPW_CheckCoditionForBWSOut_in_struct_var (const csbjNPW_CheckCoditionForBWSOut_in_struct_var &_s);

    csbjNPW_CheckCoditionForBWSOut_in_struct_var &operator= (csbjNPW_CheckCoditionForBWSOut_in_struct *_p);

    csbjNPW_CheckCoditionForBWSOut_in_struct_var &operator= (const csbjNPW_CheckCoditionForBWSOut_in_struct_var &_s);

    ~csbjNPW_CheckCoditionForBWSOut_in_struct_var ();

    csbjNPW_CheckCoditionForBWSOut_in_struct* operator-> ();

    const csbjNPW_CheckCoditionForBWSOut_in_struct& in() const;
    csbjNPW_CheckCoditionForBWSOut_in_struct& inout();
    csbjNPW_CheckCoditionForBWSOut_in_struct*& out();
    csbjNPW_CheckCoditionForBWSOut_in_struct* _retn();

    operator csbjNPW_CheckCoditionForBWSOut_in_struct_cvPtr () const;

    operator csbjNPW_CheckCoditionForBWSOut_in_struct_vPtr& ();

    operator const csbjNPW_CheckCoditionForBWSOut_in_struct& () const;

    operator csbjNPW_CheckCoditionForBWSOut_in_struct& ();

    protected:
    csbjNPW_CheckCoditionForBWSOut_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csbjNPW_CheckCoditionForBWSOut_in_struct;
    typedef csbjNPW_CheckCoditionForBWSOut_in_struct csObjNPW_CheckCoditionForBWSOut_in;
    typedef csbjNPW_CheckCoditionForBWSOut_in_struct_var csObjNPW_CheckCoditionForBWSOut_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_CheckCoditionForBWSOut_in;
    typedef objBase_out csObjNPW_CheckCoditionForBWSOut_out;
    typedef objBase_out_var csObjNPW_CheckCoditionForBWSOut_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjNPW_CheckCoditionForBWSOut_out;
    typedef objBase_out csObjLot_NPWProduct_Change_out;
    typedef objBase_out_var csObjLot_NPWProduct_Change_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_NPWProduct_Change_out;
    class  csObjLot_NPWProduct_Change_in_struct_var;
    struct  csObjLot_NPWProduct_Change_in_struct {
        typedef csObjLot_NPWProduct_Change_in_struct_var _var_type;
       ::objectIdentifier orgProductID;
       ::objectIdentifier productID;
       ::objectIdentifier lotID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_NPWProduct_Change_in_struct();
       csObjLot_NPWProduct_Change_in_struct(const csObjLot_NPWProduct_Change_in_struct&);
       csObjLot_NPWProduct_Change_in_struct& operator=(const csObjLot_NPWProduct_Change_in_struct&);
       static CORBA::Info<csObjLot_NPWProduct_Change_in_struct> csObjLot_NPWProduct_Change_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_NPWProduct_Change_in_struct


typedef csObjLot_NPWProduct_Change_in_struct* csObjLot_NPWProduct_Change_in_struct_vPtr;
typedef const csObjLot_NPWProduct_Change_in_struct* csObjLot_NPWProduct_Change_in_struct_cvPtr;

class  csObjLot_NPWProduct_Change_in_struct_var
{
    public:

    csObjLot_NPWProduct_Change_in_struct_var ();

    csObjLot_NPWProduct_Change_in_struct_var (csObjLot_NPWProduct_Change_in_struct *_p);

    csObjLot_NPWProduct_Change_in_struct_var (const csObjLot_NPWProduct_Change_in_struct_var &_s);

    csObjLot_NPWProduct_Change_in_struct_var &operator= (csObjLot_NPWProduct_Change_in_struct *_p);

    csObjLot_NPWProduct_Change_in_struct_var &operator= (const csObjLot_NPWProduct_Change_in_struct_var &_s);

    ~csObjLot_NPWProduct_Change_in_struct_var ();

    csObjLot_NPWProduct_Change_in_struct* operator-> ();

    const csObjLot_NPWProduct_Change_in_struct& in() const;
    csObjLot_NPWProduct_Change_in_struct& inout();
    csObjLot_NPWProduct_Change_in_struct*& out();
    csObjLot_NPWProduct_Change_in_struct* _retn();

    operator csObjLot_NPWProduct_Change_in_struct_cvPtr () const;

    operator csObjLot_NPWProduct_Change_in_struct_vPtr& ();

    operator const csObjLot_NPWProduct_Change_in_struct& () const;

    operator csObjLot_NPWProduct_Change_in_struct& ();

    protected:
    csObjLot_NPWProduct_Change_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_NPWProduct_Change_in_struct;
    typedef csObjLot_NPWProduct_Change_in_struct csObjLot_NPWProduct_Change_in;
    typedef csObjLot_NPWProduct_Change_in_struct_var csObjLot_NPWProduct_Change_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_NPWProduct_Change_in;
    class  csObjLot_PhotoLayer_Get_in_struct_var;
    struct  csObjLot_PhotoLayer_Get_in_struct {
        typedef csObjLot_PhotoLayer_Get_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::CORBA::Boolean previousPOFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_PhotoLayer_Get_in_struct();
       csObjLot_PhotoLayer_Get_in_struct(const csObjLot_PhotoLayer_Get_in_struct&);
       csObjLot_PhotoLayer_Get_in_struct& operator=(const csObjLot_PhotoLayer_Get_in_struct&);
       static CORBA::Info<csObjLot_PhotoLayer_Get_in_struct> csObjLot_PhotoLayer_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_PhotoLayer_Get_in_struct


typedef csObjLot_PhotoLayer_Get_in_struct* csObjLot_PhotoLayer_Get_in_struct_vPtr;
typedef const csObjLot_PhotoLayer_Get_in_struct* csObjLot_PhotoLayer_Get_in_struct_cvPtr;

class  csObjLot_PhotoLayer_Get_in_struct_var
{
    public:

    csObjLot_PhotoLayer_Get_in_struct_var ();

    csObjLot_PhotoLayer_Get_in_struct_var (csObjLot_PhotoLayer_Get_in_struct *_p);

    csObjLot_PhotoLayer_Get_in_struct_var (const csObjLot_PhotoLayer_Get_in_struct_var &_s);

    csObjLot_PhotoLayer_Get_in_struct_var &operator= (csObjLot_PhotoLayer_Get_in_struct *_p);

    csObjLot_PhotoLayer_Get_in_struct_var &operator= (const csObjLot_PhotoLayer_Get_in_struct_var &_s);

    ~csObjLot_PhotoLayer_Get_in_struct_var ();

    csObjLot_PhotoLayer_Get_in_struct* operator-> ();

    const csObjLot_PhotoLayer_Get_in_struct& in() const;
    csObjLot_PhotoLayer_Get_in_struct& inout();
    csObjLot_PhotoLayer_Get_in_struct*& out();
    csObjLot_PhotoLayer_Get_in_struct* _retn();

    operator csObjLot_PhotoLayer_Get_in_struct_cvPtr () const;

    operator csObjLot_PhotoLayer_Get_in_struct_vPtr& ();

    operator const csObjLot_PhotoLayer_Get_in_struct& () const;

    operator csObjLot_PhotoLayer_Get_in_struct& ();

    protected:
    csObjLot_PhotoLayer_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_PhotoLayer_Get_in_struct;
    typedef csObjLot_PhotoLayer_Get_in_struct csObjLot_PhotoLayer_Get_in;
    typedef csObjLot_PhotoLayer_Get_in_struct_var csObjLot_PhotoLayer_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_PhotoLayer_Get_in;
    class  csObjLot_PhotoLayer_Get_out_struct_var;
    struct  csObjLot_PhotoLayer_Get_out_struct {
        typedef csObjLot_PhotoLayer_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem photoLayer;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_PhotoLayer_Get_out_struct();
       csObjLot_PhotoLayer_Get_out_struct(const csObjLot_PhotoLayer_Get_out_struct&);
       csObjLot_PhotoLayer_Get_out_struct& operator=(const csObjLot_PhotoLayer_Get_out_struct&);
       static CORBA::Info<csObjLot_PhotoLayer_Get_out_struct> csObjLot_PhotoLayer_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_PhotoLayer_Get_out_struct


typedef csObjLot_PhotoLayer_Get_out_struct* csObjLot_PhotoLayer_Get_out_struct_vPtr;
typedef const csObjLot_PhotoLayer_Get_out_struct* csObjLot_PhotoLayer_Get_out_struct_cvPtr;

class  csObjLot_PhotoLayer_Get_out_struct_var
{
    public:

    csObjLot_PhotoLayer_Get_out_struct_var ();

    csObjLot_PhotoLayer_Get_out_struct_var (csObjLot_PhotoLayer_Get_out_struct *_p);

    csObjLot_PhotoLayer_Get_out_struct_var (const csObjLot_PhotoLayer_Get_out_struct_var &_s);

    csObjLot_PhotoLayer_Get_out_struct_var &operator= (csObjLot_PhotoLayer_Get_out_struct *_p);

    csObjLot_PhotoLayer_Get_out_struct_var &operator= (const csObjLot_PhotoLayer_Get_out_struct_var &_s);

    ~csObjLot_PhotoLayer_Get_out_struct_var ();

    csObjLot_PhotoLayer_Get_out_struct* operator-> ();

    const csObjLot_PhotoLayer_Get_out_struct& in() const;
    csObjLot_PhotoLayer_Get_out_struct& inout();
    csObjLot_PhotoLayer_Get_out_struct*& out();
    csObjLot_PhotoLayer_Get_out_struct* _retn();

    operator csObjLot_PhotoLayer_Get_out_struct_cvPtr () const;

    operator csObjLot_PhotoLayer_Get_out_struct_vPtr& ();

    operator const csObjLot_PhotoLayer_Get_out_struct& () const;

    operator csObjLot_PhotoLayer_Get_out_struct& ();

    protected:
    csObjLot_PhotoLayer_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_PhotoLayer_Get_out_struct;
    typedef csObjLot_PhotoLayer_Get_out_struct csObjLot_PhotoLayer_Get_out;
    typedef csObjLot_PhotoLayer_Get_out_struct_var csObjLot_PhotoLayer_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_PhotoLayer_Get_out;
    class  csObjAPC_LithoRecipeParameter_Replace_in_struct_var;
    struct  csObjAPC_LithoRecipeParameter_Replace_in_struct {
        typedef csObjAPC_LithoRecipeParameter_Replace_in_struct_var _var_type;
       ::pptStartRecipeParameterSequence strStartRecipeParameterSeq;
       ::csAPCLithoRecommendReticleSequence strAPCLithoRecommendReticleSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoRecipeParameter_Replace_in_struct();
       csObjAPC_LithoRecipeParameter_Replace_in_struct(const csObjAPC_LithoRecipeParameter_Replace_in_struct&);
       csObjAPC_LithoRecipeParameter_Replace_in_struct& operator=(const csObjAPC_LithoRecipeParameter_Replace_in_struct&);
       static CORBA::Info<csObjAPC_LithoRecipeParameter_Replace_in_struct> csObjAPC_LithoRecipeParameter_Replace_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoRecipeParameter_Replace_in_struct


typedef csObjAPC_LithoRecipeParameter_Replace_in_struct* csObjAPC_LithoRecipeParameter_Replace_in_struct_vPtr;
typedef const csObjAPC_LithoRecipeParameter_Replace_in_struct* csObjAPC_LithoRecipeParameter_Replace_in_struct_cvPtr;

class  csObjAPC_LithoRecipeParameter_Replace_in_struct_var
{
    public:

    csObjAPC_LithoRecipeParameter_Replace_in_struct_var ();

    csObjAPC_LithoRecipeParameter_Replace_in_struct_var (csObjAPC_LithoRecipeParameter_Replace_in_struct *_p);

    csObjAPC_LithoRecipeParameter_Replace_in_struct_var (const csObjAPC_LithoRecipeParameter_Replace_in_struct_var &_s);

    csObjAPC_LithoRecipeParameter_Replace_in_struct_var &operator= (csObjAPC_LithoRecipeParameter_Replace_in_struct *_p);

    csObjAPC_LithoRecipeParameter_Replace_in_struct_var &operator= (const csObjAPC_LithoRecipeParameter_Replace_in_struct_var &_s);

    ~csObjAPC_LithoRecipeParameter_Replace_in_struct_var ();

    csObjAPC_LithoRecipeParameter_Replace_in_struct* operator-> ();

    const csObjAPC_LithoRecipeParameter_Replace_in_struct& in() const;
    csObjAPC_LithoRecipeParameter_Replace_in_struct& inout();
    csObjAPC_LithoRecipeParameter_Replace_in_struct*& out();
    csObjAPC_LithoRecipeParameter_Replace_in_struct* _retn();

    operator csObjAPC_LithoRecipeParameter_Replace_in_struct_cvPtr () const;

    operator csObjAPC_LithoRecipeParameter_Replace_in_struct_vPtr& ();

    operator const csObjAPC_LithoRecipeParameter_Replace_in_struct& () const;

    operator csObjAPC_LithoRecipeParameter_Replace_in_struct& ();

    protected:
    csObjAPC_LithoRecipeParameter_Replace_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoRecipeParameter_Replace_in_struct;
    typedef csObjAPC_LithoRecipeParameter_Replace_in_struct csObjAPC_LithoRecipeParameter_Replace_in;
    typedef csObjAPC_LithoRecipeParameter_Replace_in_struct_var csObjAPC_LithoRecipeParameter_Replace_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoRecipeParameter_Replace_in;
    class  csObjAPC_LithoRecipeParameter_Replace_out_struct_var;
    struct  csObjAPC_LithoRecipeParameter_Replace_out_struct {
        typedef csObjAPC_LithoRecipeParameter_Replace_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptStartRecipeParameterSequence strStartRecipeParameterSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoRecipeParameter_Replace_out_struct();
       csObjAPC_LithoRecipeParameter_Replace_out_struct(const csObjAPC_LithoRecipeParameter_Replace_out_struct&);
       csObjAPC_LithoRecipeParameter_Replace_out_struct& operator=(const csObjAPC_LithoRecipeParameter_Replace_out_struct&);
       static CORBA::Info<csObjAPC_LithoRecipeParameter_Replace_out_struct> csObjAPC_LithoRecipeParameter_Replace_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoRecipeParameter_Replace_out_struct


typedef csObjAPC_LithoRecipeParameter_Replace_out_struct* csObjAPC_LithoRecipeParameter_Replace_out_struct_vPtr;
typedef const csObjAPC_LithoRecipeParameter_Replace_out_struct* csObjAPC_LithoRecipeParameter_Replace_out_struct_cvPtr;

class  csObjAPC_LithoRecipeParameter_Replace_out_struct_var
{
    public:

    csObjAPC_LithoRecipeParameter_Replace_out_struct_var ();

    csObjAPC_LithoRecipeParameter_Replace_out_struct_var (csObjAPC_LithoRecipeParameter_Replace_out_struct *_p);

    csObjAPC_LithoRecipeParameter_Replace_out_struct_var (const csObjAPC_LithoRecipeParameter_Replace_out_struct_var &_s);

    csObjAPC_LithoRecipeParameter_Replace_out_struct_var &operator= (csObjAPC_LithoRecipeParameter_Replace_out_struct *_p);

    csObjAPC_LithoRecipeParameter_Replace_out_struct_var &operator= (const csObjAPC_LithoRecipeParameter_Replace_out_struct_var &_s);

    ~csObjAPC_LithoRecipeParameter_Replace_out_struct_var ();

    csObjAPC_LithoRecipeParameter_Replace_out_struct* operator-> ();

    const csObjAPC_LithoRecipeParameter_Replace_out_struct& in() const;
    csObjAPC_LithoRecipeParameter_Replace_out_struct& inout();
    csObjAPC_LithoRecipeParameter_Replace_out_struct*& out();
    csObjAPC_LithoRecipeParameter_Replace_out_struct* _retn();

    operator csObjAPC_LithoRecipeParameter_Replace_out_struct_cvPtr () const;

    operator csObjAPC_LithoRecipeParameter_Replace_out_struct_vPtr& ();

    operator const csObjAPC_LithoRecipeParameter_Replace_out_struct& () const;

    operator csObjAPC_LithoRecipeParameter_Replace_out_struct& ();

    protected:
    csObjAPC_LithoRecipeParameter_Replace_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoRecipeParameter_Replace_out_struct;
    typedef csObjAPC_LithoRecipeParameter_Replace_out_struct csObjAPC_LithoRecipeParameter_Replace_out;
    typedef csObjAPC_LithoRecipeParameter_Replace_out_struct_var csObjAPC_LithoRecipeParameter_Replace_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoRecipeParameter_Replace_out;
    class  csObjBWS_WaferCount_GetDR_in_struct_var;
    struct  csObjBWS_WaferCount_GetDR_in_struct {
        typedef csObjBWS_WaferCount_GetDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_WaferCount_GetDR_in_struct();
       csObjBWS_WaferCount_GetDR_in_struct(const csObjBWS_WaferCount_GetDR_in_struct&);
       csObjBWS_WaferCount_GetDR_in_struct& operator=(const csObjBWS_WaferCount_GetDR_in_struct&);
       static CORBA::Info<csObjBWS_WaferCount_GetDR_in_struct> csObjBWS_WaferCount_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_WaferCount_GetDR_in_struct


typedef csObjBWS_WaferCount_GetDR_in_struct* csObjBWS_WaferCount_GetDR_in_struct_vPtr;
typedef const csObjBWS_WaferCount_GetDR_in_struct* csObjBWS_WaferCount_GetDR_in_struct_cvPtr;

class  csObjBWS_WaferCount_GetDR_in_struct_var
{
    public:

    csObjBWS_WaferCount_GetDR_in_struct_var ();

    csObjBWS_WaferCount_GetDR_in_struct_var (csObjBWS_WaferCount_GetDR_in_struct *_p);

    csObjBWS_WaferCount_GetDR_in_struct_var (const csObjBWS_WaferCount_GetDR_in_struct_var &_s);

    csObjBWS_WaferCount_GetDR_in_struct_var &operator= (csObjBWS_WaferCount_GetDR_in_struct *_p);

    csObjBWS_WaferCount_GetDR_in_struct_var &operator= (const csObjBWS_WaferCount_GetDR_in_struct_var &_s);

    ~csObjBWS_WaferCount_GetDR_in_struct_var ();

    csObjBWS_WaferCount_GetDR_in_struct* operator-> ();

    const csObjBWS_WaferCount_GetDR_in_struct& in() const;
    csObjBWS_WaferCount_GetDR_in_struct& inout();
    csObjBWS_WaferCount_GetDR_in_struct*& out();
    csObjBWS_WaferCount_GetDR_in_struct* _retn();

    operator csObjBWS_WaferCount_GetDR_in_struct_cvPtr () const;

    operator csObjBWS_WaferCount_GetDR_in_struct_vPtr& ();

    operator const csObjBWS_WaferCount_GetDR_in_struct& () const;

    operator csObjBWS_WaferCount_GetDR_in_struct& ();

    protected:
    csObjBWS_WaferCount_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferCount_GetDR_in_struct;
    typedef csObjBWS_WaferCount_GetDR_in_struct csObjBWS_WaferCount_GetDR_in;
    typedef csObjBWS_WaferCount_GetDR_in_struct_var csObjBWS_WaferCount_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferCount_GetDR_in;
    class  csObjBWS_WaferCount_GetDR_out_struct_var;
    struct  csObjBWS_WaferCount_GetDR_out_struct {
        typedef csObjBWS_WaferCount_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSWaferCount strBWSWaferCount;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_WaferCount_GetDR_out_struct();
       csObjBWS_WaferCount_GetDR_out_struct(const csObjBWS_WaferCount_GetDR_out_struct&);
       csObjBWS_WaferCount_GetDR_out_struct& operator=(const csObjBWS_WaferCount_GetDR_out_struct&);
       static CORBA::Info<csObjBWS_WaferCount_GetDR_out_struct> csObjBWS_WaferCount_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_WaferCount_GetDR_out_struct


typedef csObjBWS_WaferCount_GetDR_out_struct* csObjBWS_WaferCount_GetDR_out_struct_vPtr;
typedef const csObjBWS_WaferCount_GetDR_out_struct* csObjBWS_WaferCount_GetDR_out_struct_cvPtr;

class  csObjBWS_WaferCount_GetDR_out_struct_var
{
    public:

    csObjBWS_WaferCount_GetDR_out_struct_var ();

    csObjBWS_WaferCount_GetDR_out_struct_var (csObjBWS_WaferCount_GetDR_out_struct *_p);

    csObjBWS_WaferCount_GetDR_out_struct_var (const csObjBWS_WaferCount_GetDR_out_struct_var &_s);

    csObjBWS_WaferCount_GetDR_out_struct_var &operator= (csObjBWS_WaferCount_GetDR_out_struct *_p);

    csObjBWS_WaferCount_GetDR_out_struct_var &operator= (const csObjBWS_WaferCount_GetDR_out_struct_var &_s);

    ~csObjBWS_WaferCount_GetDR_out_struct_var ();

    csObjBWS_WaferCount_GetDR_out_struct* operator-> ();

    const csObjBWS_WaferCount_GetDR_out_struct& in() const;
    csObjBWS_WaferCount_GetDR_out_struct& inout();
    csObjBWS_WaferCount_GetDR_out_struct*& out();
    csObjBWS_WaferCount_GetDR_out_struct* _retn();

    operator csObjBWS_WaferCount_GetDR_out_struct_cvPtr () const;

    operator csObjBWS_WaferCount_GetDR_out_struct_vPtr& ();

    operator const csObjBWS_WaferCount_GetDR_out_struct& () const;

    operator csObjBWS_WaferCount_GetDR_out_struct& ();

    protected:
    csObjBWS_WaferCount_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferCount_GetDR_out_struct;
    typedef csObjBWS_WaferCount_GetDR_out_struct csObjBWS_WaferCount_GetDR_out;
    typedef csObjBWS_WaferCount_GetDR_out_struct_var csObjBWS_WaferCount_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferCount_GetDR_out;
    class  csObjTCSMgr_SendBWSInventoryInq_in_struct_var;
    struct  csObjTCSMgr_SendBWSInventoryInq_in_struct {
        typedef csObjTCSMgr_SendBWSInventoryInq_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::csBWSZoneSequence strBWSZoneSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjTCSMgr_SendBWSInventoryInq_in_struct();
       csObjTCSMgr_SendBWSInventoryInq_in_struct(const csObjTCSMgr_SendBWSInventoryInq_in_struct&);
       csObjTCSMgr_SendBWSInventoryInq_in_struct& operator=(const csObjTCSMgr_SendBWSInventoryInq_in_struct&);
       static CORBA::Info<csObjTCSMgr_SendBWSInventoryInq_in_struct> csObjTCSMgr_SendBWSInventoryInq_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjTCSMgr_SendBWSInventoryInq_in_struct


typedef csObjTCSMgr_SendBWSInventoryInq_in_struct* csObjTCSMgr_SendBWSInventoryInq_in_struct_vPtr;
typedef const csObjTCSMgr_SendBWSInventoryInq_in_struct* csObjTCSMgr_SendBWSInventoryInq_in_struct_cvPtr;

class  csObjTCSMgr_SendBWSInventoryInq_in_struct_var
{
    public:

    csObjTCSMgr_SendBWSInventoryInq_in_struct_var ();

    csObjTCSMgr_SendBWSInventoryInq_in_struct_var (csObjTCSMgr_SendBWSInventoryInq_in_struct *_p);

    csObjTCSMgr_SendBWSInventoryInq_in_struct_var (const csObjTCSMgr_SendBWSInventoryInq_in_struct_var &_s);

    csObjTCSMgr_SendBWSInventoryInq_in_struct_var &operator= (csObjTCSMgr_SendBWSInventoryInq_in_struct *_p);

    csObjTCSMgr_SendBWSInventoryInq_in_struct_var &operator= (const csObjTCSMgr_SendBWSInventoryInq_in_struct_var &_s);

    ~csObjTCSMgr_SendBWSInventoryInq_in_struct_var ();

    csObjTCSMgr_SendBWSInventoryInq_in_struct* operator-> ();

    const csObjTCSMgr_SendBWSInventoryInq_in_struct& in() const;
    csObjTCSMgr_SendBWSInventoryInq_in_struct& inout();
    csObjTCSMgr_SendBWSInventoryInq_in_struct*& out();
    csObjTCSMgr_SendBWSInventoryInq_in_struct* _retn();

    operator csObjTCSMgr_SendBWSInventoryInq_in_struct_cvPtr () const;

    operator csObjTCSMgr_SendBWSInventoryInq_in_struct_vPtr& ();

    operator const csObjTCSMgr_SendBWSInventoryInq_in_struct& () const;

    operator csObjTCSMgr_SendBWSInventoryInq_in_struct& ();

    protected:
    csObjTCSMgr_SendBWSInventoryInq_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjTCSMgr_SendBWSInventoryInq_in_struct;
    typedef csObjTCSMgr_SendBWSInventoryInq_in_struct csObjTCSMgr_SendBWSInventoryInq_in;
    typedef csObjTCSMgr_SendBWSInventoryInq_in_struct_var csObjTCSMgr_SendBWSInventoryInq_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjTCSMgr_SendBWSInventoryInq_in;
    class  csObjTCSMgr_SendBWSInventoryInq_out_struct_var;
    struct  csObjTCSMgr_SendBWSInventoryInq_out_struct {
        typedef csObjTCSMgr_SendBWSInventoryInq_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSInventoryInfo strBWSInventoryInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjTCSMgr_SendBWSInventoryInq_out_struct();
       csObjTCSMgr_SendBWSInventoryInq_out_struct(const csObjTCSMgr_SendBWSInventoryInq_out_struct&);
       csObjTCSMgr_SendBWSInventoryInq_out_struct& operator=(const csObjTCSMgr_SendBWSInventoryInq_out_struct&);
       static CORBA::Info<csObjTCSMgr_SendBWSInventoryInq_out_struct> csObjTCSMgr_SendBWSInventoryInq_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjTCSMgr_SendBWSInventoryInq_out_struct


typedef csObjTCSMgr_SendBWSInventoryInq_out_struct* csObjTCSMgr_SendBWSInventoryInq_out_struct_vPtr;
typedef const csObjTCSMgr_SendBWSInventoryInq_out_struct* csObjTCSMgr_SendBWSInventoryInq_out_struct_cvPtr;

class  csObjTCSMgr_SendBWSInventoryInq_out_struct_var
{
    public:

    csObjTCSMgr_SendBWSInventoryInq_out_struct_var ();

    csObjTCSMgr_SendBWSInventoryInq_out_struct_var (csObjTCSMgr_SendBWSInventoryInq_out_struct *_p);

    csObjTCSMgr_SendBWSInventoryInq_out_struct_var (const csObjTCSMgr_SendBWSInventoryInq_out_struct_var &_s);

    csObjTCSMgr_SendBWSInventoryInq_out_struct_var &operator= (csObjTCSMgr_SendBWSInventoryInq_out_struct *_p);

    csObjTCSMgr_SendBWSInventoryInq_out_struct_var &operator= (const csObjTCSMgr_SendBWSInventoryInq_out_struct_var &_s);

    ~csObjTCSMgr_SendBWSInventoryInq_out_struct_var ();

    csObjTCSMgr_SendBWSInventoryInq_out_struct* operator-> ();

    const csObjTCSMgr_SendBWSInventoryInq_out_struct& in() const;
    csObjTCSMgr_SendBWSInventoryInq_out_struct& inout();
    csObjTCSMgr_SendBWSInventoryInq_out_struct*& out();
    csObjTCSMgr_SendBWSInventoryInq_out_struct* _retn();

    operator csObjTCSMgr_SendBWSInventoryInq_out_struct_cvPtr () const;

    operator csObjTCSMgr_SendBWSInventoryInq_out_struct_vPtr& ();

    operator const csObjTCSMgr_SendBWSInventoryInq_out_struct& () const;

    operator csObjTCSMgr_SendBWSInventoryInq_out_struct& ();

    protected:
    csObjTCSMgr_SendBWSInventoryInq_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjTCSMgr_SendBWSInventoryInq_out_struct;
    typedef csObjTCSMgr_SendBWSInventoryInq_out_struct csObjTCSMgr_SendBWSInventoryInq_out;
    typedef csObjTCSMgr_SendBWSInventoryInq_out_struct_var csObjTCSMgr_SendBWSInventoryInq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjTCSMgr_SendBWSInventoryInq_out;
    typedef objSorter_CheckConditionForJobCreate_in csObjBWSSorter_CheckConditionForJobCreate_in;
    typedef objSorter_CheckConditionForJobCreate_in_var csObjBWSSorter_CheckConditionForJobCreate_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSSorter_CheckConditionForJobCreate_in;
    typedef objSorter_CheckConditionForJobCreate_out csObjBWSSorter_CheckConditionForJobCreate_out;
    typedef objSorter_CheckConditionForJobCreate_out_var csObjBWSSorter_CheckConditionForJobCreate_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWSSorter_CheckConditionForJobCreate_out;
    class  csObjProcess_SPCWaferChamberInformation_Get_in_struct_var;
    struct  csObjProcess_SPCWaferChamberInformation_Get_in_struct {
        typedef csObjProcess_SPCWaferChamberInformation_Get_in_struct_var _var_type;
       ::pptObjCommonIn strObjCommonIn;
       ::objectIdentifier waferID;
       ::pptWaferIDByChamberSequence waferIDByChambers;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjProcess_SPCWaferChamberInformation_Get_in_struct();
       csObjProcess_SPCWaferChamberInformation_Get_in_struct(const csObjProcess_SPCWaferChamberInformation_Get_in_struct&);
       csObjProcess_SPCWaferChamberInformation_Get_in_struct& operator=(const csObjProcess_SPCWaferChamberInformation_Get_in_struct&);
       static CORBA::Info<csObjProcess_SPCWaferChamberInformation_Get_in_struct> csObjProcess_SPCWaferChamberInformation_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjProcess_SPCWaferChamberInformation_Get_in_struct


typedef csObjProcess_SPCWaferChamberInformation_Get_in_struct* csObjProcess_SPCWaferChamberInformation_Get_in_struct_vPtr;
typedef const csObjProcess_SPCWaferChamberInformation_Get_in_struct* csObjProcess_SPCWaferChamberInformation_Get_in_struct_cvPtr;

class  csObjProcess_SPCWaferChamberInformation_Get_in_struct_var
{
    public:

    csObjProcess_SPCWaferChamberInformation_Get_in_struct_var ();

    csObjProcess_SPCWaferChamberInformation_Get_in_struct_var (csObjProcess_SPCWaferChamberInformation_Get_in_struct *_p);

    csObjProcess_SPCWaferChamberInformation_Get_in_struct_var (const csObjProcess_SPCWaferChamberInformation_Get_in_struct_var &_s);

    csObjProcess_SPCWaferChamberInformation_Get_in_struct_var &operator= (csObjProcess_SPCWaferChamberInformation_Get_in_struct *_p);

    csObjProcess_SPCWaferChamberInformation_Get_in_struct_var &operator= (const csObjProcess_SPCWaferChamberInformation_Get_in_struct_var &_s);

    ~csObjProcess_SPCWaferChamberInformation_Get_in_struct_var ();

    csObjProcess_SPCWaferChamberInformation_Get_in_struct* operator-> ();

    const csObjProcess_SPCWaferChamberInformation_Get_in_struct& in() const;
    csObjProcess_SPCWaferChamberInformation_Get_in_struct& inout();
    csObjProcess_SPCWaferChamberInformation_Get_in_struct*& out();
    csObjProcess_SPCWaferChamberInformation_Get_in_struct* _retn();

    operator csObjProcess_SPCWaferChamberInformation_Get_in_struct_cvPtr () const;

    operator csObjProcess_SPCWaferChamberInformation_Get_in_struct_vPtr& ();

    operator const csObjProcess_SPCWaferChamberInformation_Get_in_struct& () const;

    operator csObjProcess_SPCWaferChamberInformation_Get_in_struct& ();

    protected:
    csObjProcess_SPCWaferChamberInformation_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjProcess_SPCWaferChamberInformation_Get_in_struct;
    typedef csObjProcess_SPCWaferChamberInformation_Get_in_struct csObjProcess_SPCWaferChamberInformation_Get_in;
    typedef csObjProcess_SPCWaferChamberInformation_Get_in_struct_var csObjProcess_SPCWaferChamberInformation_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjProcess_SPCWaferChamberInformation_Get_in;
    class  csObjProcess_SPCWaferChamberInformation_Get_out_struct_var;
    struct  csObjProcess_SPCWaferChamberInformation_Get_out_struct {
        typedef csObjProcess_SPCWaferChamberInformation_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem chamber_list;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjProcess_SPCWaferChamberInformation_Get_out_struct();
       csObjProcess_SPCWaferChamberInformation_Get_out_struct(const csObjProcess_SPCWaferChamberInformation_Get_out_struct&);
       csObjProcess_SPCWaferChamberInformation_Get_out_struct& operator=(const csObjProcess_SPCWaferChamberInformation_Get_out_struct&);
       static CORBA::Info<csObjProcess_SPCWaferChamberInformation_Get_out_struct> csObjProcess_SPCWaferChamberInformation_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjProcess_SPCWaferChamberInformation_Get_out_struct


typedef csObjProcess_SPCWaferChamberInformation_Get_out_struct* csObjProcess_SPCWaferChamberInformation_Get_out_struct_vPtr;
typedef const csObjProcess_SPCWaferChamberInformation_Get_out_struct* csObjProcess_SPCWaferChamberInformation_Get_out_struct_cvPtr;

class  csObjProcess_SPCWaferChamberInformation_Get_out_struct_var
{
    public:

    csObjProcess_SPCWaferChamberInformation_Get_out_struct_var ();

    csObjProcess_SPCWaferChamberInformation_Get_out_struct_var (csObjProcess_SPCWaferChamberInformation_Get_out_struct *_p);

    csObjProcess_SPCWaferChamberInformation_Get_out_struct_var (const csObjProcess_SPCWaferChamberInformation_Get_out_struct_var &_s);

    csObjProcess_SPCWaferChamberInformation_Get_out_struct_var &operator= (csObjProcess_SPCWaferChamberInformation_Get_out_struct *_p);

    csObjProcess_SPCWaferChamberInformation_Get_out_struct_var &operator= (const csObjProcess_SPCWaferChamberInformation_Get_out_struct_var &_s);

    ~csObjProcess_SPCWaferChamberInformation_Get_out_struct_var ();

    csObjProcess_SPCWaferChamberInformation_Get_out_struct* operator-> ();

    const csObjProcess_SPCWaferChamberInformation_Get_out_struct& in() const;
    csObjProcess_SPCWaferChamberInformation_Get_out_struct& inout();
    csObjProcess_SPCWaferChamberInformation_Get_out_struct*& out();
    csObjProcess_SPCWaferChamberInformation_Get_out_struct* _retn();

    operator csObjProcess_SPCWaferChamberInformation_Get_out_struct_cvPtr () const;

    operator csObjProcess_SPCWaferChamberInformation_Get_out_struct_vPtr& ();

    operator const csObjProcess_SPCWaferChamberInformation_Get_out_struct& () const;

    operator csObjProcess_SPCWaferChamberInformation_Get_out_struct& ();

    protected:
    csObjProcess_SPCWaferChamberInformation_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjProcess_SPCWaferChamberInformation_Get_out_struct;
    typedef csObjProcess_SPCWaferChamberInformation_Get_out_struct csObjProcess_SPCWaferChamberInformation_Get_out;
    typedef csObjProcess_SPCWaferChamberInformation_Get_out_struct_var csObjProcess_SPCWaferChamberInformation_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjProcess_SPCWaferChamberInformation_Get_out;
    class  csObjLot_POObj_GetByOperationDR_in_struct_var;
    struct  csObjLot_POObj_GetByOperationDR_in_struct {
        typedef csObjLot_POObj_GetByOperationDR_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::Long passCount;
       ::CORBA::Boolean lastestPassCountFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_POObj_GetByOperationDR_in_struct();
       csObjLot_POObj_GetByOperationDR_in_struct(const csObjLot_POObj_GetByOperationDR_in_struct&);
       csObjLot_POObj_GetByOperationDR_in_struct& operator=(const csObjLot_POObj_GetByOperationDR_in_struct&);
       static CORBA::Info<csObjLot_POObj_GetByOperationDR_in_struct> csObjLot_POObj_GetByOperationDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_POObj_GetByOperationDR_in_struct


typedef csObjLot_POObj_GetByOperationDR_in_struct* csObjLot_POObj_GetByOperationDR_in_struct_vPtr;
typedef const csObjLot_POObj_GetByOperationDR_in_struct* csObjLot_POObj_GetByOperationDR_in_struct_cvPtr;

class  csObjLot_POObj_GetByOperationDR_in_struct_var
{
    public:

    csObjLot_POObj_GetByOperationDR_in_struct_var ();

    csObjLot_POObj_GetByOperationDR_in_struct_var (csObjLot_POObj_GetByOperationDR_in_struct *_p);

    csObjLot_POObj_GetByOperationDR_in_struct_var (const csObjLot_POObj_GetByOperationDR_in_struct_var &_s);

    csObjLot_POObj_GetByOperationDR_in_struct_var &operator= (csObjLot_POObj_GetByOperationDR_in_struct *_p);

    csObjLot_POObj_GetByOperationDR_in_struct_var &operator= (const csObjLot_POObj_GetByOperationDR_in_struct_var &_s);

    ~csObjLot_POObj_GetByOperationDR_in_struct_var ();

    csObjLot_POObj_GetByOperationDR_in_struct* operator-> ();

    const csObjLot_POObj_GetByOperationDR_in_struct& in() const;
    csObjLot_POObj_GetByOperationDR_in_struct& inout();
    csObjLot_POObj_GetByOperationDR_in_struct*& out();
    csObjLot_POObj_GetByOperationDR_in_struct* _retn();

    operator csObjLot_POObj_GetByOperationDR_in_struct_cvPtr () const;

    operator csObjLot_POObj_GetByOperationDR_in_struct_vPtr& ();

    operator const csObjLot_POObj_GetByOperationDR_in_struct& () const;

    operator csObjLot_POObj_GetByOperationDR_in_struct& ();

    protected:
    csObjLot_POObj_GetByOperationDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_POObj_GetByOperationDR_in_struct;
    typedef csObjLot_POObj_GetByOperationDR_in_struct csObjLot_POObj_GetByOperationDR_in;
    typedef csObjLot_POObj_GetByOperationDR_in_struct_var csObjLot_POObj_GetByOperationDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_POObj_GetByOperationDR_in;
    class  csObjLot_POObj_GetByOperationDR_out_struct_var;
    struct  csObjLot_POObj_GetByOperationDR_out_struct {
        typedef csObjLot_POObj_GetByOperationDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem poObj;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_POObj_GetByOperationDR_out_struct();
       csObjLot_POObj_GetByOperationDR_out_struct(const csObjLot_POObj_GetByOperationDR_out_struct&);
       csObjLot_POObj_GetByOperationDR_out_struct& operator=(const csObjLot_POObj_GetByOperationDR_out_struct&);
       static CORBA::Info<csObjLot_POObj_GetByOperationDR_out_struct> csObjLot_POObj_GetByOperationDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_POObj_GetByOperationDR_out_struct


typedef csObjLot_POObj_GetByOperationDR_out_struct* csObjLot_POObj_GetByOperationDR_out_struct_vPtr;
typedef const csObjLot_POObj_GetByOperationDR_out_struct* csObjLot_POObj_GetByOperationDR_out_struct_cvPtr;

class  csObjLot_POObj_GetByOperationDR_out_struct_var
{
    public:

    csObjLot_POObj_GetByOperationDR_out_struct_var ();

    csObjLot_POObj_GetByOperationDR_out_struct_var (csObjLot_POObj_GetByOperationDR_out_struct *_p);

    csObjLot_POObj_GetByOperationDR_out_struct_var (const csObjLot_POObj_GetByOperationDR_out_struct_var &_s);

    csObjLot_POObj_GetByOperationDR_out_struct_var &operator= (csObjLot_POObj_GetByOperationDR_out_struct *_p);

    csObjLot_POObj_GetByOperationDR_out_struct_var &operator= (const csObjLot_POObj_GetByOperationDR_out_struct_var &_s);

    ~csObjLot_POObj_GetByOperationDR_out_struct_var ();

    csObjLot_POObj_GetByOperationDR_out_struct* operator-> ();

    const csObjLot_POObj_GetByOperationDR_out_struct& in() const;
    csObjLot_POObj_GetByOperationDR_out_struct& inout();
    csObjLot_POObj_GetByOperationDR_out_struct*& out();
    csObjLot_POObj_GetByOperationDR_out_struct* _retn();

    operator csObjLot_POObj_GetByOperationDR_out_struct_cvPtr () const;

    operator csObjLot_POObj_GetByOperationDR_out_struct_vPtr& ();

    operator const csObjLot_POObj_GetByOperationDR_out_struct& () const;

    operator csObjLot_POObj_GetByOperationDR_out_struct& ();

    protected:
    csObjLot_POObj_GetByOperationDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_POObj_GetByOperationDR_out_struct;
    typedef csObjLot_POObj_GetByOperationDR_out_struct csObjLot_POObj_GetByOperationDR_out;
    typedef csObjLot_POObj_GetByOperationDR_out_struct_var csObjLot_POObj_GetByOperationDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_POObj_GetByOperationDR_out;
    typedef objBase_out csObjDurable_CheckConditionForOperationForInternalBuffer_out;
    typedef objBase_out_var csObjDurable_CheckConditionForOperationForInternalBuffer_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_CheckConditionForOperationForInternalBuffer_out;
    class  csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var;
    struct  csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct {
        typedef csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var _var_type;
       ::CORBA::String_StructElem operation;
       ::objectIdentifier equipmentID;
       ::CORBA::String_StructElem durableCategory;
       ::pptStartDurableSequence strStartDurables;
       ::pptDurableStartRecipe strDurableStartRecipe;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct();
       csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct(const csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct&);
       csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct& operator=(const csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct&);
       static CORBA::Info<csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct> csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct


typedef csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct* csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_vPtr;
typedef const csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct* csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_cvPtr;

class  csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var
{
    public:

    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var ();

    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var (csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct *_p);

    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var (const csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var &_s);

    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var &operator= (csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct *_p);

    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var &operator= (const csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var &_s);

    ~csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var ();

    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct* operator-> ();

    const csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct& in() const;
    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct& inout();
    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct*& out();
    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct* _retn();

    operator csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_cvPtr () const;

    operator csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_vPtr& ();

    operator const csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct& () const;

    operator csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct& ();

    protected:
    csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct;
    typedef csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct csObjDurable_CheckConditionForOperationForInternalBuffer_in;
    typedef csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct_var csObjDurable_CheckConditionForOperationForInternalBuffer_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_CheckConditionForOperationForInternalBuffer_in;
    typedef objBase_out csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out;
    typedef objBase_out_var csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out;
    class  csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var;
    struct  csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct {
        typedef csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var _var_type;
       ::CORBA::String_StructElem operation;
       ::objectIdentifier equipmentID;
       ::CORBA::String_StructElem durableCategory;
       ::pptStartDurableSequence strStartDurables;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct();
       csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct(const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct&);
       csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct& operator=(const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct&);
       static CORBA::Info<csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct> csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct


typedef csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct* csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_vPtr;
typedef const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct* csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_cvPtr;

class  csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var
{
    public:

    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var ();

    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var (csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct *_p);

    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var (const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var &_s);

    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var &operator= (csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct *_p);

    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var &operator= (const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var &_s);

    ~csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var ();

    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct* operator-> ();

    const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct& in() const;
    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct& inout();
    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct*& out();
    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct* _retn();

    operator csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_cvPtr () const;

    operator csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_vPtr& ();

    operator const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct& () const;

    operator csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct& ();

    protected:
    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct;
    typedef csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in;
    typedef csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct_var csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in;
    class  csObjBank_userDataInfo_GetDR_out_struct_var;
    struct  csObjBank_userDataInfo_GetDR_out_struct {
        typedef csObjBank_userDataInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBank_userDataInfo_GetDR_out_struct();
       csObjBank_userDataInfo_GetDR_out_struct(const csObjBank_userDataInfo_GetDR_out_struct&);
       csObjBank_userDataInfo_GetDR_out_struct& operator=(const csObjBank_userDataInfo_GetDR_out_struct&);
       static CORBA::Info<csObjBank_userDataInfo_GetDR_out_struct> csObjBank_userDataInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBank_userDataInfo_GetDR_out_struct


typedef csObjBank_userDataInfo_GetDR_out_struct* csObjBank_userDataInfo_GetDR_out_struct_vPtr;
typedef const csObjBank_userDataInfo_GetDR_out_struct* csObjBank_userDataInfo_GetDR_out_struct_cvPtr;

class  csObjBank_userDataInfo_GetDR_out_struct_var
{
    public:

    csObjBank_userDataInfo_GetDR_out_struct_var ();

    csObjBank_userDataInfo_GetDR_out_struct_var (csObjBank_userDataInfo_GetDR_out_struct *_p);

    csObjBank_userDataInfo_GetDR_out_struct_var (const csObjBank_userDataInfo_GetDR_out_struct_var &_s);

    csObjBank_userDataInfo_GetDR_out_struct_var &operator= (csObjBank_userDataInfo_GetDR_out_struct *_p);

    csObjBank_userDataInfo_GetDR_out_struct_var &operator= (const csObjBank_userDataInfo_GetDR_out_struct_var &_s);

    ~csObjBank_userDataInfo_GetDR_out_struct_var ();

    csObjBank_userDataInfo_GetDR_out_struct* operator-> ();

    const csObjBank_userDataInfo_GetDR_out_struct& in() const;
    csObjBank_userDataInfo_GetDR_out_struct& inout();
    csObjBank_userDataInfo_GetDR_out_struct*& out();
    csObjBank_userDataInfo_GetDR_out_struct* _retn();

    operator csObjBank_userDataInfo_GetDR_out_struct_cvPtr () const;

    operator csObjBank_userDataInfo_GetDR_out_struct_vPtr& ();

    operator const csObjBank_userDataInfo_GetDR_out_struct& () const;

    operator csObjBank_userDataInfo_GetDR_out_struct& ();

    protected:
    csObjBank_userDataInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBank_userDataInfo_GetDR_out_struct;
    typedef csObjBank_userDataInfo_GetDR_out_struct csObjBank_userDataInfo_GetDR_out;
    typedef csObjBank_userDataInfo_GetDR_out_struct_var csObjBank_userDataInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBank_userDataInfo_GetDR_out;
    class  csObjBank_userDataInfo_GetDR_in_struct_var;
    struct  csObjBank_userDataInfo_GetDR_in_struct {
        typedef csObjBank_userDataInfo_GetDR_in_struct_var _var_type;
       ::objectIdentifier bankID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBank_userDataInfo_GetDR_in_struct();
       csObjBank_userDataInfo_GetDR_in_struct(const csObjBank_userDataInfo_GetDR_in_struct&);
       csObjBank_userDataInfo_GetDR_in_struct& operator=(const csObjBank_userDataInfo_GetDR_in_struct&);
       static CORBA::Info<csObjBank_userDataInfo_GetDR_in_struct> csObjBank_userDataInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBank_userDataInfo_GetDR_in_struct


typedef csObjBank_userDataInfo_GetDR_in_struct* csObjBank_userDataInfo_GetDR_in_struct_vPtr;
typedef const csObjBank_userDataInfo_GetDR_in_struct* csObjBank_userDataInfo_GetDR_in_struct_cvPtr;

class  csObjBank_userDataInfo_GetDR_in_struct_var
{
    public:

    csObjBank_userDataInfo_GetDR_in_struct_var ();

    csObjBank_userDataInfo_GetDR_in_struct_var (csObjBank_userDataInfo_GetDR_in_struct *_p);

    csObjBank_userDataInfo_GetDR_in_struct_var (const csObjBank_userDataInfo_GetDR_in_struct_var &_s);

    csObjBank_userDataInfo_GetDR_in_struct_var &operator= (csObjBank_userDataInfo_GetDR_in_struct *_p);

    csObjBank_userDataInfo_GetDR_in_struct_var &operator= (const csObjBank_userDataInfo_GetDR_in_struct_var &_s);

    ~csObjBank_userDataInfo_GetDR_in_struct_var ();

    csObjBank_userDataInfo_GetDR_in_struct* operator-> ();

    const csObjBank_userDataInfo_GetDR_in_struct& in() const;
    csObjBank_userDataInfo_GetDR_in_struct& inout();
    csObjBank_userDataInfo_GetDR_in_struct*& out();
    csObjBank_userDataInfo_GetDR_in_struct* _retn();

    operator csObjBank_userDataInfo_GetDR_in_struct_cvPtr () const;

    operator csObjBank_userDataInfo_GetDR_in_struct_vPtr& ();

    operator const csObjBank_userDataInfo_GetDR_in_struct& () const;

    operator csObjBank_userDataInfo_GetDR_in_struct& ();

    protected:
    csObjBank_userDataInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBank_userDataInfo_GetDR_in_struct;
    typedef csObjBank_userDataInfo_GetDR_in_struct csObjBank_userDataInfo_GetDR_in;
    typedef csObjBank_userDataInfo_GetDR_in_struct_var csObjBank_userDataInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBank_userDataInfo_GetDR_in;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_pptobstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_pptobstr_ANYOPERATOR__
#undef __NOTUSE_cs_pptobstr_ANYOPERATOR__
#endif //__USE_cs_pptobstr_ANYOPERATOR__
#ifndef __NOTUSE_cs_pptobstr_ANYOPERATOR__
#define _DCL_ANYOPS_objSample_Obj_struct
#define _DCL_ANYOPS_objTestFunction_Obj_struct
#define _DCL_ANYOPS_csObjEquipment_InAuditList_GetDR_out_struct
#define _DCL_ANYOPS_csObjEquipment_ListByOwnerDR_out_struct
#define _DCL_ANYOPS_csObjRMSMgr_GetServiceManager_out_struct
#define _DCL_ANYOPS_csObjEquipment_constantsManageFlag_Get_out_struct
#define _DCL_ANYOPS_csObjRecipe_compareFlag_Get_out_struct
#define _DCL_ANYOPS_csObjEquipmentInfo_ListByOwnerDR_out_struct
#define _DCL_ANYOPS_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct
#define _DCL_ANYOPS_csObjCassette_InspectionTime_Reset_out_struct
#define _DCL_ANYOPS_csObjCassette_PMTime_Reset_out_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Reset_out_struct
#define _DCL_ANYOPS_csObjReticle_UsedDuration_Reset_out_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Increment_out_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Increment_in_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_out_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_in_struct
#define _DCL_ANYOPS_csObjUserData_GetByLotOperation_out_struct
#define _DCL_ANYOPS_csObjUserData_GetByLotOperation_in_struct
#define _DCL_ANYOPS_csObjReticlePod_Empty_Check_out_struct
#define _DCL_ANYOPS_csObjReticlePod_Empty_Check_in_struct
#define _DCL_ANYOPS_csObjVendorLotReserve_SelDR_out_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_out_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_Set_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_out_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_out_struct
#define _DCL_ANYOPS_csObjLot_udata_CopyToChild_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct
#define _DCL_ANYOPS_csObjEquipment_udata_GetDR_in_struct
#define _DCL_ANYOPS_csObjEquipment_udata_GetDR_out_struct
#define _DCL_ANYOPS_csObjCarrier_UsageTypeChange_in_struct
#define _DCL_ANYOPS_csObjLot_requiredCarrierCategory_CheckDR_in_struct
#define _DCL_ANYOPS_csObjPerson_SkillList_GetDR_out_struct
#define _DCL_ANYOPS_csObjPerson_SkillList_GetDR_in_strcut
#define _DCL_ANYOPS_csObjPerson_SkillList_AddDR_in_strcut
#define _DCL_ANYOPS_csObjPerson_SkillList_DelDR_in_strcut
#define _DCL_ANYOPS_csObjPerson_SkillList_SetDR_in_strcut
#define _DCL_ANYOPS_csObjPerson_PrivilegeCheckForTACertify_in_strcut
#define _DCL_ANYOPS_csObjFixture_touchCountSet_in_struct
#define _DCL_ANYOPS_csObjFixture_touchCountSet_out_struct
#define _DCL_ANYOPS_csObjFixture_touchCount_Get_in_struct
#define _DCL_ANYOPS_csObjFixture_touchCount_Get_out_struct
#define _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_in_struct
#define _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_in_struct
#define _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjUserData_GetByOperation_in_struct
#define _DCL_ANYOPS_csObjUserData_GetByOperation_out_struct
#define _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_in_struct
#define _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_out_struct
#define _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_in_struct
#define _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_out_struct
#define _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_in_struct
#define _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_out_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_in_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_out_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_in_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_out_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct
#define _DCL_ANYOPS_csObjControlJob_BatchSize_Check_out_struct
#define _DCL_ANYOPS_csObjControlJob_BatchSize_Check_in_struct
#define _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_in_struct
#define _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjLotID_ControlInfo_SetDR_in_struct
#define _DCL_ANYOPS_csObjLotID_ControlInfo_AddDR_in_struct
#define _DCL_ANYOPS_csObjBWS_Config_GetDR_in_struct
#define _DCL_ANYOPS_csObjBWS_Config_GetDR_out_struct
#define _DCL_ANYOPS_csObjBWS_Config_AddDR_in_struct
#define _DCL_ANYOPS_csObjBWS_Config_DeleteDR_in_struct
#define _DCL_ANYOPS_csObjBWS_Config_UpdateDR_in_struct
#define _DCL_ANYOPS_csObjBWS_WaferList_GetDR_out_struct
#define _DCL_ANYOPS_csObjBWS_WaferList_AddDR_in_struct
#define _DCL_ANYOPS_csObjBWS_WaferList_DeleteDR_in_struct
#define _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_in_struct
#define _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_out_struct
#define _DCL_ANYOPS_csObjEqpMonitorInventory_info_Update_in_struct
#define _DCL_ANYOPS_csObjNPW_sameBWSID_Get_in_struct
#define _DCL_ANYOPS_csObjNPW_sameBWSID_Get_out_struct
#define _DCL_ANYOPS_csObjDowngradeItemList_GetDR_in_struct
#define _DCL_ANYOPS_csObjDowngradeItemList_GetDR_out_struct
#define _DCL_ANYOPS_csObjDowngradeItemList_UpdateDR_in_struct
#define _DCL_ANYOPS_csObjEqpMonitor_list_GetDR_out_struct
#define _DCL_ANYOPS_csObjEqpMonitor_info_Update_in_struct
#define _DCL_ANYOPS_csObjDowngradeSettingList_GetDR_in_struct
#define _DCL_ANYOPS_csObjDowngradeSettingList_GetDR_out_struct
#define _DCL_ANYOPS_csObjDowngradeSetting_UpdateDR_in_struct
#define _DCL_ANYOPS_csObjBWSOutSTB_slotMap_InsertDR_in_struct
#define _DCL_ANYOPS_csObjBWSOutSTB_slotMap_GetDR_in_struct
#define _DCL_ANYOPS_csObjBWSOutSTB_slotMap_GetDR_out_struct
#define _DCL_ANYOPS_csObjBWSOutSTB_slotMap_DeleteDR_in_struct
#define _DCL_ANYOPS_csObjEqpMonitor_info_Get_out_struct
#define _DCL_ANYOPS_csObjEqpMonitorLot_prepareIDSet_in_struct
#define _DCL_ANYOPS_csObjNPW_sourceProductInfo_GetDR_in_struct
#define _DCL_ANYOPS_csObjNPW_sourceProductInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjNPW_sourceWaferInfo_GetDR_in_struct
#define _DCL_ANYOPS_csObjNPW_sourceWaferInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjRoute_requiredCarrierCategory_GetDR_in_struct
#define _DCL_ANYOPS_csObjRoute_requiredCarrierCategory_GetDR_out_struct
#define _DCL_ANYOPS_csObjNPW_emptyCarrier_Pickup_in_struct
#define _DCL_ANYOPS_csObjNPW_emptyCarrier_Pickup_out_struct
#define _DCL_ANYOPS_csbjNPW_CheckCoditionForBWSOut_in_struct
#define _DCL_ANYOPS_csObjLot_NPWProduct_Change_in_struct
#define _DCL_ANYOPS_csObjLot_PhotoLayer_Get_in_struct
#define _DCL_ANYOPS_csObjLot_PhotoLayer_Get_out_struct
#define _DCL_ANYOPS_csObjAPC_LithoRecipeParameter_Replace_in_struct
#define _DCL_ANYOPS_csObjAPC_LithoRecipeParameter_Replace_out_struct
#define _DCL_ANYOPS_csObjBWS_WaferCount_GetDR_in_struct
#define _DCL_ANYOPS_csObjBWS_WaferCount_GetDR_out_struct
#define _DCL_ANYOPS_csObjTCSMgr_SendBWSInventoryInq_in_struct
#define _DCL_ANYOPS_csObjTCSMgr_SendBWSInventoryInq_out_struct
#define _DCL_ANYOPS_csObjProcess_SPCWaferChamberInformation_Get_in_struct
#define _DCL_ANYOPS_csObjProcess_SPCWaferChamberInformation_Get_out_struct
#define _DCL_ANYOPS_csObjLot_POObj_GetByOperationDR_in_struct
#define _DCL_ANYOPS_csObjLot_POObj_GetByOperationDR_out_struct
#define _DCL_ANYOPS_csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct
#define _DCL_ANYOPS_csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct
#define _DCL_ANYOPS_csObjBank_userDataInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjBank_userDataInfo_GetDR_in_struct
#endif //__NOTUSE_cs_pptobstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_objSample_Obj_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::objSample_Obj_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::objSample_Obj_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::objSample_Obj_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::objSample_Obj_struct*& _data);
#endif
#endif // _DCL_ANYOPS_objSample_Obj_struct
#ifdef _DCL_ANYOPS_objTestFunction_Obj_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::objTestFunction_Obj_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::objTestFunction_Obj_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::objTestFunction_Obj_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::objTestFunction_Obj_struct*& _data);
#endif
#endif // _DCL_ANYOPS_objTestFunction_Obj_struct
#ifdef _DCL_ANYOPS_csObjEquipment_InAuditList_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_InAuditList_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_InAuditList_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_InAuditList_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_InAuditList_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_InAuditList_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjEquipment_ListByOwnerDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_ListByOwnerDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_ListByOwnerDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_ListByOwnerDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_ListByOwnerDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_ListByOwnerDR_out_struct
#ifdef _DCL_ANYOPS_csObjRMSMgr_GetServiceManager_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjRMSMgr_GetServiceManager_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjRMSMgr_GetServiceManager_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjRMSMgr_GetServiceManager_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjRMSMgr_GetServiceManager_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjRMSMgr_GetServiceManager_out_struct
#ifdef _DCL_ANYOPS_csObjEquipment_constantsManageFlag_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_constantsManageFlag_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_constantsManageFlag_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_constantsManageFlag_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_constantsManageFlag_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_constantsManageFlag_Get_out_struct
#ifdef _DCL_ANYOPS_csObjRecipe_compareFlag_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjRecipe_compareFlag_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjRecipe_compareFlag_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjRecipe_compareFlag_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjRecipe_compareFlag_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjRecipe_compareFlag_Get_out_struct
#ifdef _DCL_ANYOPS_csObjEquipmentInfo_ListByOwnerDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipmentInfo_ListByOwnerDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipmentInfo_ListByOwnerDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipmentInfo_ListByOwnerDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipmentInfo_ListByOwnerDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipmentInfo_ListByOwnerDR_out_struct
#ifdef _DCL_ANYOPS_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjCassette_InspectionTime_Reset_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjCassette_InspectionTime_Reset_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjCassette_InspectionTime_Reset_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjCassette_InspectionTime_Reset_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjCassette_InspectionTime_Reset_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjCassette_InspectionTime_Reset_out_struct
#ifdef _DCL_ANYOPS_csObjCassette_PMTime_Reset_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjCassette_PMTime_Reset_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjCassette_PMTime_Reset_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjCassette_PMTime_Reset_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjCassette_PMTime_Reset_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjCassette_PMTime_Reset_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Reset_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Reset_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Reset_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Reset_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Reset_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Reset_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_UsedDuration_Reset_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_UsedDuration_Reset_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_UsedDuration_Reset_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_UsedDuration_Reset_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_UsedDuration_Reset_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_UsedDuration_Reset_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Increment_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Increment_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Increment_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Increment_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Increment_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Increment_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Increment_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Increment_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Increment_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Increment_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Increment_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Increment_in_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Decrement_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Decrement_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Decrement_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Decrement_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Decrement_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Decrement_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Decrement_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Decrement_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_in_struct
#ifdef _DCL_ANYOPS_csObjUserData_GetByLotOperation_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjUserData_GetByLotOperation_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjUserData_GetByLotOperation_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjUserData_GetByLotOperation_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjUserData_GetByLotOperation_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjUserData_GetByLotOperation_out_struct
#ifdef _DCL_ANYOPS_csObjUserData_GetByLotOperation_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjUserData_GetByLotOperation_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjUserData_GetByLotOperation_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjUserData_GetByLotOperation_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjUserData_GetByLotOperation_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjUserData_GetByLotOperation_in_struct
#ifdef _DCL_ANYOPS_csObjReticlePod_Empty_Check_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticlePod_Empty_Check_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticlePod_Empty_Check_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticlePod_Empty_Check_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticlePod_Empty_Check_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticlePod_Empty_Check_out_struct
#ifdef _DCL_ANYOPS_csObjReticlePod_Empty_Check_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticlePod_Empty_Check_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticlePod_Empty_Check_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticlePod_Empty_Check_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticlePod_Empty_Check_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticlePod_Empty_Check_in_struct
#ifdef _DCL_ANYOPS_csObjVendorLotReserve_SelDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjVendorLotReserve_SelDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjVendorLotReserve_SelDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjVendorLotReserve_SelDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjVendorLotReserve_SelDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjVendorLotReserve_SelDR_out_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_out_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_Set_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Set_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Set_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Set_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Set_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_Set_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForMove_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForMove_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForMove_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForMove_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForMove_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForMove_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForMove_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForMove_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_out_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForProcess_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForProcess_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForProcess_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForProcess_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForProcess_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForProcess_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForProcess_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForProcess_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_out_struct
#ifdef _DCL_ANYOPS_csObjLot_udata_CopyToChild_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_udata_CopyToChild_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_udata_CopyToChild_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_udata_CopyToChild_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_udata_CopyToChild_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_udata_CopyToChild_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct
#ifdef _DCL_ANYOPS_csObjEquipment_udata_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_udata_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_udata_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_udata_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_udata_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_udata_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjEquipment_udata_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_udata_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_udata_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_udata_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_udata_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_udata_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjCarrier_UsageTypeChange_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjCarrier_UsageTypeChange_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjCarrier_UsageTypeChange_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjCarrier_UsageTypeChange_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjCarrier_UsageTypeChange_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjCarrier_UsageTypeChange_in_struct
#ifdef _DCL_ANYOPS_csObjLot_requiredCarrierCategory_CheckDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_requiredCarrierCategory_CheckDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_requiredCarrierCategory_CheckDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_requiredCarrierCategory_CheckDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_requiredCarrierCategory_CheckDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_requiredCarrierCategory_CheckDR_in_struct
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_GetDR_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_GetDR_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_GetDR_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_GetDR_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_GetDR_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_GetDR_in_strcut
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_AddDR_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_AddDR_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_AddDR_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_AddDR_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_AddDR_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_AddDR_in_strcut
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_DelDR_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_DelDR_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_DelDR_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_DelDR_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_DelDR_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_DelDR_in_strcut
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_SetDR_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_SetDR_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_SetDR_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_SetDR_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_SetDR_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_SetDR_in_strcut
#ifdef _DCL_ANYOPS_csObjPerson_PrivilegeCheckForTACertify_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_PrivilegeCheckForTACertify_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_PrivilegeCheckForTACertify_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_PrivilegeCheckForTACertify_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_PrivilegeCheckForTACertify_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_PrivilegeCheckForTACertify_in_strcut
#ifdef _DCL_ANYOPS_csObjFixture_touchCountSet_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjFixture_touchCountSet_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjFixture_touchCountSet_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjFixture_touchCountSet_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjFixture_touchCountSet_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjFixture_touchCountSet_in_struct
#ifdef _DCL_ANYOPS_csObjFixture_touchCountSet_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjFixture_touchCountSet_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjFixture_touchCountSet_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjFixture_touchCountSet_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjFixture_touchCountSet_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjFixture_touchCountSet_out_struct
#ifdef _DCL_ANYOPS_csObjFixture_touchCount_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjFixture_touchCount_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjFixture_touchCount_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjFixture_touchCount_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjFixture_touchCount_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjFixture_touchCount_Get_in_struct
#ifdef _DCL_ANYOPS_csObjFixture_touchCount_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjFixture_touchCount_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjFixture_touchCount_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjFixture_touchCount_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjFixture_touchCount_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjFixture_touchCount_Get_out_struct
#ifdef _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjWafer_userDataInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjWafer_userDataInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjWafer_userDataInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjWafer_userDataInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjWafer_userDataInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjWafer_userDataInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjWafer_userDataInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjWafer_userDataInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDurable_userDataInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDurable_userDataInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDurable_userDataInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDurable_userDataInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDurable_userDataInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDurable_userDataInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDurable_userDataInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDurable_userDataInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjUserData_GetByOperation_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjUserData_GetByOperation_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjUserData_GetByOperation_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjUserData_GetByOperation_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjUserData_GetByOperation_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjUserData_GetByOperation_in_struct
#ifdef _DCL_ANYOPS_csObjUserData_GetByOperation_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjUserData_GetByOperation_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjUserData_GetByOperation_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjUserData_GetByOperation_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjUserData_GetByOperation_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjUserData_GetByOperation_out_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoAvailable_CheckCondition_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoAvailable_CheckCondition_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoAvailable_CheckCondition_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoAvailable_CheckCondition_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoAvailable_CheckCondition_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoAvailable_CheckCondition_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoAvailable_CheckCondition_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoAvailable_CheckCondition_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_out_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoLotDataInfo_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoLotDataInfo_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoLotDataInfo_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoLotDataInfo_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoLotDataInfo_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoLotDataInfo_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoLotDataInfo_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoLotDataInfo_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_out_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoContextInfo_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoContextInfo_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoContextInfo_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoContextInfo_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoContextInfo_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoContextInfo_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoContextInfo_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoContextInfo_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_out_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoUsedInfoReq_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoUsedInfoReq_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoUsedInfoReq_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoUsedInfoReq_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_in_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoUsedInfoReq_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoUsedInfoReq_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoUsedInfoReq_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoUsedInfoReq_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_out_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoRecommendInfoInq_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoRecommendInfoInq_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoRecommendInfoInq_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoRecommendInfoInq_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_in_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoRecommendInfoInq_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoRecommendInfoInq_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoRecommendInfoInq_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoRecommendInfoInq_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_out_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct
#ifdef _DCL_ANYOPS_csObjControlJob_BatchSize_Check_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjControlJob_BatchSize_Check_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjControlJob_BatchSize_Check_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjControlJob_BatchSize_Check_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjControlJob_BatchSize_Check_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjControlJob_BatchSize_Check_out_struct
#ifdef _DCL_ANYOPS_csObjControlJob_BatchSize_Check_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjControlJob_BatchSize_Check_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjControlJob_BatchSize_Check_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjControlJob_BatchSize_Check_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjControlJob_BatchSize_Check_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjControlJob_BatchSize_Check_in_struct
#ifdef _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLotID_ControlInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLotID_ControlInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLotID_ControlInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLotID_ControlInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLotID_ControlInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLotID_ControlInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLotID_ControlInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLotID_ControlInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjLotID_ControlInfo_SetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLotID_ControlInfo_SetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLotID_ControlInfo_SetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLotID_ControlInfo_SetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLotID_ControlInfo_SetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLotID_ControlInfo_SetDR_in_struct
#ifdef _DCL_ANYOPS_csObjLotID_ControlInfo_AddDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLotID_ControlInfo_AddDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLotID_ControlInfo_AddDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLotID_ControlInfo_AddDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLotID_ControlInfo_AddDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLotID_ControlInfo_AddDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_AddDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_AddDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_AddDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_AddDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_AddDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_AddDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_DeleteDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_DeleteDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_DeleteDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_DeleteDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_DeleteDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_DeleteDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_UpdateDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_UpdateDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_UpdateDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_UpdateDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_UpdateDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_UpdateDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_WaferList_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_WaferList_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_WaferList_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_WaferList_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_WaferList_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_WaferList_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjBWS_WaferList_AddDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_WaferList_AddDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_WaferList_AddDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_WaferList_AddDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_WaferList_AddDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_WaferList_AddDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_WaferList_DeleteDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_WaferList_DeleteDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_WaferList_DeleteDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_WaferList_DeleteDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_WaferList_DeleteDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_WaferList_DeleteDR_in_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitorInventory_ListGetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitorInventory_ListGetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitorInventory_ListGetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitorInventory_ListGetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_in_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitorInventory_ListGetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitorInventory_ListGetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitorInventory_ListGetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitorInventory_ListGetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_out_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitorInventory_info_Update_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitorInventory_info_Update_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitorInventory_info_Update_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitorInventory_info_Update_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitorInventory_info_Update_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitorInventory_info_Update_in_struct
#ifdef _DCL_ANYOPS_csObjNPW_sameBWSID_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjNPW_sameBWSID_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjNPW_sameBWSID_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjNPW_sameBWSID_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjNPW_sameBWSID_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjNPW_sameBWSID_Get_in_struct
#ifdef _DCL_ANYOPS_csObjNPW_sameBWSID_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjNPW_sameBWSID_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjNPW_sameBWSID_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjNPW_sameBWSID_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjNPW_sameBWSID_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjNPW_sameBWSID_Get_out_struct
#ifdef _DCL_ANYOPS_csObjDowngradeItemList_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDowngradeItemList_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDowngradeItemList_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDowngradeItemList_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDowngradeItemList_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDowngradeItemList_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjDowngradeItemList_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDowngradeItemList_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDowngradeItemList_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDowngradeItemList_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDowngradeItemList_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDowngradeItemList_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjDowngradeItemList_UpdateDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDowngradeItemList_UpdateDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDowngradeItemList_UpdateDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDowngradeItemList_UpdateDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDowngradeItemList_UpdateDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDowngradeItemList_UpdateDR_in_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitor_list_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitor_list_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitor_list_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitor_list_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitor_list_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitor_list_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitor_info_Update_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitor_info_Update_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitor_info_Update_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitor_info_Update_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitor_info_Update_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitor_info_Update_in_struct
#ifdef _DCL_ANYOPS_csObjDowngradeSettingList_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDowngradeSettingList_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDowngradeSettingList_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDowngradeSettingList_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDowngradeSettingList_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDowngradeSettingList_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjDowngradeSettingList_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDowngradeSettingList_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDowngradeSettingList_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDowngradeSettingList_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDowngradeSettingList_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDowngradeSettingList_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjDowngradeSetting_UpdateDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDowngradeSetting_UpdateDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDowngradeSetting_UpdateDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDowngradeSetting_UpdateDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDowngradeSetting_UpdateDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDowngradeSetting_UpdateDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWSOutSTB_slotMap_InsertDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWSOutSTB_slotMap_InsertDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWSOutSTB_slotMap_InsertDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWSOutSTB_slotMap_InsertDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWSOutSTB_slotMap_InsertDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWSOutSTB_slotMap_InsertDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWSOutSTB_slotMap_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWSOutSTB_slotMap_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWSOutSTB_slotMap_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWSOutSTB_slotMap_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWSOutSTB_slotMap_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWSOutSTB_slotMap_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWSOutSTB_slotMap_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWSOutSTB_slotMap_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWSOutSTB_slotMap_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWSOutSTB_slotMap_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWSOutSTB_slotMap_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWSOutSTB_slotMap_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjBWSOutSTB_slotMap_DeleteDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWSOutSTB_slotMap_DeleteDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWSOutSTB_slotMap_DeleteDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWSOutSTB_slotMap_DeleteDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWSOutSTB_slotMap_DeleteDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWSOutSTB_slotMap_DeleteDR_in_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitor_info_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitor_info_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitor_info_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitor_info_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitor_info_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitor_info_Get_out_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitorLot_prepareIDSet_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitorLot_prepareIDSet_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitorLot_prepareIDSet_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitorLot_prepareIDSet_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitorLot_prepareIDSet_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitorLot_prepareIDSet_in_struct
#ifdef _DCL_ANYOPS_csObjNPW_sourceProductInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjNPW_sourceProductInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjNPW_sourceProductInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjNPW_sourceProductInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjNPW_sourceProductInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjNPW_sourceProductInfo_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjNPW_sourceProductInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjNPW_sourceProductInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjNPW_sourceProductInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjNPW_sourceProductInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjNPW_sourceProductInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjNPW_sourceProductInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjNPW_sourceWaferInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjNPW_sourceWaferInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjNPW_sourceWaferInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjNPW_sourceWaferInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjNPW_sourceWaferInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjNPW_sourceWaferInfo_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjNPW_sourceWaferInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjNPW_sourceWaferInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjNPW_sourceWaferInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjNPW_sourceWaferInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjNPW_sourceWaferInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjNPW_sourceWaferInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjRoute_requiredCarrierCategory_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjRoute_requiredCarrierCategory_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjRoute_requiredCarrierCategory_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjRoute_requiredCarrierCategory_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjRoute_requiredCarrierCategory_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjRoute_requiredCarrierCategory_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjRoute_requiredCarrierCategory_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjRoute_requiredCarrierCategory_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjRoute_requiredCarrierCategory_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjRoute_requiredCarrierCategory_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjRoute_requiredCarrierCategory_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjRoute_requiredCarrierCategory_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjNPW_emptyCarrier_Pickup_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjNPW_emptyCarrier_Pickup_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjNPW_emptyCarrier_Pickup_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjNPW_emptyCarrier_Pickup_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjNPW_emptyCarrier_Pickup_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjNPW_emptyCarrier_Pickup_in_struct
#ifdef _DCL_ANYOPS_csObjNPW_emptyCarrier_Pickup_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjNPW_emptyCarrier_Pickup_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjNPW_emptyCarrier_Pickup_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjNPW_emptyCarrier_Pickup_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjNPW_emptyCarrier_Pickup_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjNPW_emptyCarrier_Pickup_out_struct
#ifdef _DCL_ANYOPS_csbjNPW_CheckCoditionForBWSOut_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csbjNPW_CheckCoditionForBWSOut_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csbjNPW_CheckCoditionForBWSOut_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csbjNPW_CheckCoditionForBWSOut_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csbjNPW_CheckCoditionForBWSOut_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csbjNPW_CheckCoditionForBWSOut_in_struct
#ifdef _DCL_ANYOPS_csObjLot_NPWProduct_Change_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_NPWProduct_Change_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_NPWProduct_Change_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_NPWProduct_Change_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_NPWProduct_Change_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_NPWProduct_Change_in_struct
#ifdef _DCL_ANYOPS_csObjLot_PhotoLayer_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_PhotoLayer_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_PhotoLayer_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_PhotoLayer_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_PhotoLayer_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_PhotoLayer_Get_in_struct
#ifdef _DCL_ANYOPS_csObjLot_PhotoLayer_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_PhotoLayer_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_PhotoLayer_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_PhotoLayer_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_PhotoLayer_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_PhotoLayer_Get_out_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoRecipeParameter_Replace_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoRecipeParameter_Replace_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoRecipeParameter_Replace_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoRecipeParameter_Replace_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoRecipeParameter_Replace_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoRecipeParameter_Replace_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoRecipeParameter_Replace_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoRecipeParameter_Replace_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoRecipeParameter_Replace_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoRecipeParameter_Replace_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoRecipeParameter_Replace_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoRecipeParameter_Replace_out_struct
#ifdef _DCL_ANYOPS_csObjBWS_WaferCount_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_WaferCount_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_WaferCount_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_WaferCount_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_WaferCount_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_WaferCount_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_WaferCount_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_WaferCount_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_WaferCount_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_WaferCount_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_WaferCount_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_WaferCount_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjTCSMgr_SendBWSInventoryInq_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjTCSMgr_SendBWSInventoryInq_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjTCSMgr_SendBWSInventoryInq_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjTCSMgr_SendBWSInventoryInq_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjTCSMgr_SendBWSInventoryInq_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjTCSMgr_SendBWSInventoryInq_in_struct
#ifdef _DCL_ANYOPS_csObjTCSMgr_SendBWSInventoryInq_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjTCSMgr_SendBWSInventoryInq_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjTCSMgr_SendBWSInventoryInq_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjTCSMgr_SendBWSInventoryInq_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjTCSMgr_SendBWSInventoryInq_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjTCSMgr_SendBWSInventoryInq_out_struct
#ifdef _DCL_ANYOPS_csObjProcess_SPCWaferChamberInformation_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjProcess_SPCWaferChamberInformation_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjProcess_SPCWaferChamberInformation_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjProcess_SPCWaferChamberInformation_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjProcess_SPCWaferChamberInformation_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjProcess_SPCWaferChamberInformation_Get_in_struct
#ifdef _DCL_ANYOPS_csObjProcess_SPCWaferChamberInformation_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjProcess_SPCWaferChamberInformation_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjProcess_SPCWaferChamberInformation_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjProcess_SPCWaferChamberInformation_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjProcess_SPCWaferChamberInformation_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjProcess_SPCWaferChamberInformation_Get_out_struct
#ifdef _DCL_ANYOPS_csObjLot_POObj_GetByOperationDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_POObj_GetByOperationDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_POObj_GetByOperationDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_POObj_GetByOperationDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_POObj_GetByOperationDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_POObj_GetByOperationDR_in_struct
#ifdef _DCL_ANYOPS_csObjLot_POObj_GetByOperationDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_POObj_GetByOperationDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_POObj_GetByOperationDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_POObj_GetByOperationDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_POObj_GetByOperationDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_POObj_GetByOperationDR_out_struct
#ifdef _DCL_ANYOPS_csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDurable_CheckConditionForOperationForInternalBuffer_in_struct
#ifdef _DCL_ANYOPS_csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in_struct
#ifdef _DCL_ANYOPS_csObjBank_userDataInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBank_userDataInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBank_userDataInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBank_userDataInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBank_userDataInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBank_userDataInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjBank_userDataInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBank_userDataInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBank_userDataInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBank_userDataInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBank_userDataInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBank_userDataInfo_GetDR_in_struct

#endif /* _cs_pptobstr_hh_included */

#endif /* _cs_pptobstr_server_defined */
