//----------------------------------------------------------------------------
//
//  Generated from rmsstr.idl
//  On Tuesday, November 14, 2017 11:55:06 AM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _rmsstr_server_defined
#ifndef _rmsstr_hh_included
#define _rmsstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_tcsstr_hh_included
#include <cs_tcsstr.hh>
#endif
#else
#ifndef _cs_tcsstr_hh_included
#include "cs_tcsstr.hh"
#endif
#endif
    class  rmsRangeValue_struct_var;
    struct  rmsRangeValue_struct {
        typedef rmsRangeValue_struct_var _var_type;
       ::CORBA::String_StructElem depend;
       ::CORBA::String_StructElem value;
       ::CORBA::String_StructElem rangeComment;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRangeValue_struct();
       rmsRangeValue_struct(const rmsRangeValue_struct&);
       rmsRangeValue_struct& operator=(const rmsRangeValue_struct&);
       static CORBA::Info<rmsRangeValue_struct> rmsRangeValue_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRangeValue_struct


typedef rmsRangeValue_struct* rmsRangeValue_struct_vPtr;
typedef const rmsRangeValue_struct* rmsRangeValue_struct_cvPtr;

class  rmsRangeValue_struct_var
{
    public:

    rmsRangeValue_struct_var ();

    rmsRangeValue_struct_var (rmsRangeValue_struct *_p);

    rmsRangeValue_struct_var (const rmsRangeValue_struct_var &_s);

    rmsRangeValue_struct_var &operator= (rmsRangeValue_struct *_p);

    rmsRangeValue_struct_var &operator= (const rmsRangeValue_struct_var &_s);

    ~rmsRangeValue_struct_var ();

    rmsRangeValue_struct* operator-> ();

    const rmsRangeValue_struct& in() const;
    rmsRangeValue_struct& inout();
    rmsRangeValue_struct*& out();
    rmsRangeValue_struct* _retn();

    operator rmsRangeValue_struct_cvPtr () const;

    operator rmsRangeValue_struct_vPtr& ();

    operator const rmsRangeValue_struct& () const;

    operator rmsRangeValue_struct& ();

    protected:
    rmsRangeValue_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRangeValue_struct;
    typedef rmsRangeValue_struct rmsRangeValue;
    typedef rmsRangeValue_struct_var rmsRangeValue_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRangeValue;
class  _IDL_SEQ_rmsRangeValueSeq_0_var;
class  _IDL_SEQ_rmsRangeValueSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRangeValueSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRangeValue *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRangeValueSeq_0 ();
    _IDL_SEQ_rmsRangeValueSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRangeValueSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRangeValue* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRangeValueSeq_0 (const _IDL_SEQ_rmsRangeValueSeq_0&);

    ~_IDL_SEQ_rmsRangeValueSeq_0 ();

    _IDL_SEQ_rmsRangeValueSeq_0& operator= (const _IDL_SEQ_rmsRangeValueSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRangeValue& operator [] (::CORBA::ULong indx);
    const rmsRangeValue& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRangeValue* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRangeValue* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRangeValue* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRangeValue* src, rmsRangeValue* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRangeValue* data); 
  public:

    static rmsRangeValue* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRangeValue* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRangeValue* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRangeValueSeq_0> rmsRangeValueSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRangeValueSeq_0* _IDL_SEQ_rmsRangeValueSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRangeValueSeq_0* _IDL_SEQ_rmsRangeValueSeq_0_cvPtr;

class  _IDL_SEQ_rmsRangeValueSeq_0_var
{
    public:

    _IDL_SEQ_rmsRangeValueSeq_0_var ();

    _IDL_SEQ_rmsRangeValueSeq_0_var (_IDL_SEQ_rmsRangeValueSeq_0 *_p);

    _IDL_SEQ_rmsRangeValueSeq_0_var (const _IDL_SEQ_rmsRangeValueSeq_0_var &_s);

    _IDL_SEQ_rmsRangeValueSeq_0_var &operator= (_IDL_SEQ_rmsRangeValueSeq_0 *_p);

    _IDL_SEQ_rmsRangeValueSeq_0_var &operator= (const _IDL_SEQ_rmsRangeValueSeq_0_var &_s);

    ~_IDL_SEQ_rmsRangeValueSeq_0_var ();

    _IDL_SEQ_rmsRangeValueSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRangeValueSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRangeValueSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRangeValueSeq_0() const;

    const rmsRangeValue& operator[] (::CORBA::ULong index) const;
    rmsRangeValue& operator[] (::CORBA::ULong index);
    const rmsRangeValue& operator[] (int index) const;
    rmsRangeValue& operator[] (int index);
    const _IDL_SEQ_rmsRangeValueSeq_0& in() const;
    _IDL_SEQ_rmsRangeValueSeq_0& inout();
    _IDL_SEQ_rmsRangeValueSeq_0*& out();
    _IDL_SEQ_rmsRangeValueSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRangeValueSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRangeValueSeq_0 _rmsRangeValueSeq_seq;
    typedef _IDL_SEQ_rmsRangeValueSeq_0 _rmsRangeValueSeq_seq_1;
    typedef _IDL_SEQ_rmsRangeValueSeq_0 rmsRangeValueSeq;
    typedef _IDL_SEQ_rmsRangeValueSeq_0_var rmsRangeValueSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRangeValueSeq;
    class  rmsRecipeItemValue_struct_var;
    struct  rmsRecipeItemValue_struct {
        typedef rmsRecipeItemValue_struct_var _var_type;
       ::CORBA::Long lineNo;
       ::CORBA::Long startByte;
       ::CORBA::String_StructElem blockName;
       ::CORBA::String_StructElem CCODE;
       ::CORBA::String_StructElem itemName;
       ::CORBA::String_StructElem itemType;
       ::CORBA::String_StructElem itemValue;
       ::CORBA::Boolean recipeFlag;
       ::CORBA::Boolean audit;
       ::CORBA::Boolean diffFlag;
       ::CORBA::String_StructElem maxValue;
       ::CORBA::String_StructElem minValue;
       ::rmsRangeValueSeq toleranceValues;
       ::CORBA::String_StructElem option;
       ::CORBA::Long setGoldenFlag;
       ::CORBA::String_StructElem DCCmaxValue;
       ::CORBA::String_StructElem DCCminValue;
       ::CORBA::Boolean isKey;
       ::CORBA::Boolean rowChanged;
       ::CORBA::String_StructElem sn;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeItemValue_struct();
       rmsRecipeItemValue_struct(const rmsRecipeItemValue_struct&);
       rmsRecipeItemValue_struct& operator=(const rmsRecipeItemValue_struct&);
       static CORBA::Info<rmsRecipeItemValue_struct> rmsRecipeItemValue_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeItemValue_struct


typedef rmsRecipeItemValue_struct* rmsRecipeItemValue_struct_vPtr;
typedef const rmsRecipeItemValue_struct* rmsRecipeItemValue_struct_cvPtr;

class  rmsRecipeItemValue_struct_var
{
    public:

    rmsRecipeItemValue_struct_var ();

    rmsRecipeItemValue_struct_var (rmsRecipeItemValue_struct *_p);

    rmsRecipeItemValue_struct_var (const rmsRecipeItemValue_struct_var &_s);

    rmsRecipeItemValue_struct_var &operator= (rmsRecipeItemValue_struct *_p);

    rmsRecipeItemValue_struct_var &operator= (const rmsRecipeItemValue_struct_var &_s);

    ~rmsRecipeItemValue_struct_var ();

    rmsRecipeItemValue_struct* operator-> ();

    const rmsRecipeItemValue_struct& in() const;
    rmsRecipeItemValue_struct& inout();
    rmsRecipeItemValue_struct*& out();
    rmsRecipeItemValue_struct* _retn();

    operator rmsRecipeItemValue_struct_cvPtr () const;

    operator rmsRecipeItemValue_struct_vPtr& ();

    operator const rmsRecipeItemValue_struct& () const;

    operator rmsRecipeItemValue_struct& ();

    protected:
    rmsRecipeItemValue_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeItemValue_struct;
    typedef rmsRecipeItemValue_struct rmsRecipeItemValue;
    typedef rmsRecipeItemValue_struct_var rmsRecipeItemValue_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeItemValue;
class  _IDL_SEQ_rmsRecipeItemValueSeq_0_var;
class  _IDL_SEQ_rmsRecipeItemValueSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeItemValueSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeItemValue *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeItemValueSeq_0 ();
    _IDL_SEQ_rmsRecipeItemValueSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeItemValueSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeItemValue* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeItemValueSeq_0 (const _IDL_SEQ_rmsRecipeItemValueSeq_0&);

    ~_IDL_SEQ_rmsRecipeItemValueSeq_0 ();

    _IDL_SEQ_rmsRecipeItemValueSeq_0& operator= (const _IDL_SEQ_rmsRecipeItemValueSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeItemValue& operator [] (::CORBA::ULong indx);
    const rmsRecipeItemValue& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeItemValue* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeItemValue* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeItemValue* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeItemValue* src, rmsRecipeItemValue* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeItemValue* data); 
  public:

    static rmsRecipeItemValue* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeItemValue* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeItemValue* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeItemValueSeq_0> rmsRecipeItemValueSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeItemValueSeq_0* _IDL_SEQ_rmsRecipeItemValueSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeItemValueSeq_0* _IDL_SEQ_rmsRecipeItemValueSeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeItemValueSeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeItemValueSeq_0_var ();

    _IDL_SEQ_rmsRecipeItemValueSeq_0_var (_IDL_SEQ_rmsRecipeItemValueSeq_0 *_p);

    _IDL_SEQ_rmsRecipeItemValueSeq_0_var (const _IDL_SEQ_rmsRecipeItemValueSeq_0_var &_s);

    _IDL_SEQ_rmsRecipeItemValueSeq_0_var &operator= (_IDL_SEQ_rmsRecipeItemValueSeq_0 *_p);

    _IDL_SEQ_rmsRecipeItemValueSeq_0_var &operator= (const _IDL_SEQ_rmsRecipeItemValueSeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeItemValueSeq_0_var ();

    _IDL_SEQ_rmsRecipeItemValueSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeItemValueSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeItemValueSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeItemValueSeq_0() const;

    const rmsRecipeItemValue& operator[] (::CORBA::ULong index) const;
    rmsRecipeItemValue& operator[] (::CORBA::ULong index);
    const rmsRecipeItemValue& operator[] (int index) const;
    rmsRecipeItemValue& operator[] (int index);
    const _IDL_SEQ_rmsRecipeItemValueSeq_0& in() const;
    _IDL_SEQ_rmsRecipeItemValueSeq_0& inout();
    _IDL_SEQ_rmsRecipeItemValueSeq_0*& out();
    _IDL_SEQ_rmsRecipeItemValueSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeItemValueSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeItemValueSeq_0 _rmsRecipeItemValueSeq_seq;
    typedef _IDL_SEQ_rmsRecipeItemValueSeq_0 _rmsRecipeItemValueSeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeItemValueSeq_0 rmsRecipeItemValueSeq;
    typedef _IDL_SEQ_rmsRecipeItemValueSeq_0_var rmsRecipeItemValueSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeItemValueSeq;
    class  rmsRecipeBody_struct_var;
    struct  rmsRecipeBody_struct {
        typedef rmsRecipeBody_struct_var _var_type;
       ::objectIdentifier machineRecipeID;
       ::CORBA::String_StructElem physicalRecipeID;
       ::CORBA::Boolean mainRecipeFlag;
       ::CORBA::String_StructElem recipeFileName;
       ::CORBA::String_StructElem ruleId;
       ::CORBA::String_StructElem lastUpdateTime;
       ::rmsRecipeItemValueSeq recipeItems;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeBody_struct();
       rmsRecipeBody_struct(const rmsRecipeBody_struct&);
       rmsRecipeBody_struct& operator=(const rmsRecipeBody_struct&);
       static CORBA::Info<rmsRecipeBody_struct> rmsRecipeBody_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeBody_struct


typedef rmsRecipeBody_struct* rmsRecipeBody_struct_vPtr;
typedef const rmsRecipeBody_struct* rmsRecipeBody_struct_cvPtr;

class  rmsRecipeBody_struct_var
{
    public:

    rmsRecipeBody_struct_var ();

    rmsRecipeBody_struct_var (rmsRecipeBody_struct *_p);

    rmsRecipeBody_struct_var (const rmsRecipeBody_struct_var &_s);

    rmsRecipeBody_struct_var &operator= (rmsRecipeBody_struct *_p);

    rmsRecipeBody_struct_var &operator= (const rmsRecipeBody_struct_var &_s);

    ~rmsRecipeBody_struct_var ();

    rmsRecipeBody_struct* operator-> ();

    const rmsRecipeBody_struct& in() const;
    rmsRecipeBody_struct& inout();
    rmsRecipeBody_struct*& out();
    rmsRecipeBody_struct* _retn();

    operator rmsRecipeBody_struct_cvPtr () const;

    operator rmsRecipeBody_struct_vPtr& ();

    operator const rmsRecipeBody_struct& () const;

    operator rmsRecipeBody_struct& ();

    protected:
    rmsRecipeBody_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeBody_struct;
    typedef rmsRecipeBody_struct rmsRecipeBody;
    typedef rmsRecipeBody_struct_var rmsRecipeBody_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeBody;
class  _IDL_SEQ_rmsRecipeBodySeq_0_var;
class  _IDL_SEQ_rmsRecipeBodySeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeBodySeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeBody *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeBodySeq_0 ();
    _IDL_SEQ_rmsRecipeBodySeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeBodySeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeBody* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeBodySeq_0 (const _IDL_SEQ_rmsRecipeBodySeq_0&);

    ~_IDL_SEQ_rmsRecipeBodySeq_0 ();

    _IDL_SEQ_rmsRecipeBodySeq_0& operator= (const _IDL_SEQ_rmsRecipeBodySeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeBody& operator [] (::CORBA::ULong indx);
    const rmsRecipeBody& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeBody* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeBody* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeBody* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeBody* src, rmsRecipeBody* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeBody* data); 
  public:

    static rmsRecipeBody* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeBody* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeBody* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeBodySeq_0> rmsRecipeBodySeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeBodySeq_0* _IDL_SEQ_rmsRecipeBodySeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeBodySeq_0* _IDL_SEQ_rmsRecipeBodySeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeBodySeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeBodySeq_0_var ();

    _IDL_SEQ_rmsRecipeBodySeq_0_var (_IDL_SEQ_rmsRecipeBodySeq_0 *_p);

    _IDL_SEQ_rmsRecipeBodySeq_0_var (const _IDL_SEQ_rmsRecipeBodySeq_0_var &_s);

    _IDL_SEQ_rmsRecipeBodySeq_0_var &operator= (_IDL_SEQ_rmsRecipeBodySeq_0 *_p);

    _IDL_SEQ_rmsRecipeBodySeq_0_var &operator= (const _IDL_SEQ_rmsRecipeBodySeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeBodySeq_0_var ();

    _IDL_SEQ_rmsRecipeBodySeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeBodySeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeBodySeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeBodySeq_0() const;

    const rmsRecipeBody& operator[] (::CORBA::ULong index) const;
    rmsRecipeBody& operator[] (::CORBA::ULong index);
    const rmsRecipeBody& operator[] (int index) const;
    rmsRecipeBody& operator[] (int index);
    const _IDL_SEQ_rmsRecipeBodySeq_0& in() const;
    _IDL_SEQ_rmsRecipeBodySeq_0& inout();
    _IDL_SEQ_rmsRecipeBodySeq_0*& out();
    _IDL_SEQ_rmsRecipeBodySeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeBodySeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeBodySeq_0 _rmsRecipeBodySeq_seq;
    typedef _IDL_SEQ_rmsRecipeBodySeq_0 _rmsRecipeBodySeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeBodySeq_0 rmsRecipeBodySeq;
    typedef _IDL_SEQ_rmsRecipeBodySeq_0_var rmsRecipeBodySeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeBodySeq;
    class  rmsAuditReqResult_struct_var;
    struct  rmsAuditReqResult_struct {
        typedef rmsAuditReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsAuditReqResult_struct();
       rmsAuditReqResult_struct(const rmsAuditReqResult_struct&);
       rmsAuditReqResult_struct& operator=(const rmsAuditReqResult_struct&);
       static CORBA::Info<rmsAuditReqResult_struct> rmsAuditReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsAuditReqResult_struct


typedef rmsAuditReqResult_struct* rmsAuditReqResult_struct_vPtr;
typedef const rmsAuditReqResult_struct* rmsAuditReqResult_struct_cvPtr;

class  rmsAuditReqResult_struct_var
{
    public:

    rmsAuditReqResult_struct_var ();

    rmsAuditReqResult_struct_var (rmsAuditReqResult_struct *_p);

    rmsAuditReqResult_struct_var (const rmsAuditReqResult_struct_var &_s);

    rmsAuditReqResult_struct_var &operator= (rmsAuditReqResult_struct *_p);

    rmsAuditReqResult_struct_var &operator= (const rmsAuditReqResult_struct_var &_s);

    ~rmsAuditReqResult_struct_var ();

    rmsAuditReqResult_struct* operator-> ();

    const rmsAuditReqResult_struct& in() const;
    rmsAuditReqResult_struct& inout();
    rmsAuditReqResult_struct*& out();
    rmsAuditReqResult_struct* _retn();

    operator rmsAuditReqResult_struct_cvPtr () const;

    operator rmsAuditReqResult_struct_vPtr& ();

    operator const rmsAuditReqResult_struct& () const;

    operator rmsAuditReqResult_struct& ();

    protected:
    rmsAuditReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsAuditReqResult_struct;
    typedef rmsAuditReqResult_struct rmsAuditReqResult;
    typedef rmsAuditReqResult_struct_var rmsAuditReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsAuditReqResult;
    class  rmsRecipeInqResult_struct_var;
    struct  rmsRecipeInqResult_struct {
        typedef rmsRecipeInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeBodySeq parsedRecipeBodys;
       ::CORBA::String_StructElem checkOutUser;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeInqResult_struct();
       rmsRecipeInqResult_struct(const rmsRecipeInqResult_struct&);
       rmsRecipeInqResult_struct& operator=(const rmsRecipeInqResult_struct&);
       static CORBA::Info<rmsRecipeInqResult_struct> rmsRecipeInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeInqResult_struct


typedef rmsRecipeInqResult_struct* rmsRecipeInqResult_struct_vPtr;
typedef const rmsRecipeInqResult_struct* rmsRecipeInqResult_struct_cvPtr;

class  rmsRecipeInqResult_struct_var
{
    public:

    rmsRecipeInqResult_struct_var ();

    rmsRecipeInqResult_struct_var (rmsRecipeInqResult_struct *_p);

    rmsRecipeInqResult_struct_var (const rmsRecipeInqResult_struct_var &_s);

    rmsRecipeInqResult_struct_var &operator= (rmsRecipeInqResult_struct *_p);

    rmsRecipeInqResult_struct_var &operator= (const rmsRecipeInqResult_struct_var &_s);

    ~rmsRecipeInqResult_struct_var ();

    rmsRecipeInqResult_struct* operator-> ();

    const rmsRecipeInqResult_struct& in() const;
    rmsRecipeInqResult_struct& inout();
    rmsRecipeInqResult_struct*& out();
    rmsRecipeInqResult_struct* _retn();

    operator rmsRecipeInqResult_struct_cvPtr () const;

    operator rmsRecipeInqResult_struct_vPtr& ();

    operator const rmsRecipeInqResult_struct& () const;

    operator rmsRecipeInqResult_struct& ();

    protected:
    rmsRecipeInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeInqResult_struct;
    typedef rmsRecipeInqResult_struct rmsRecipeInqResult;
    typedef rmsRecipeInqResult_struct_var rmsRecipeInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeInqResult;
    class  rmsRecipeUploadReqResult_struct_var;
    struct  rmsRecipeUploadReqResult_struct {
        typedef rmsRecipeUploadReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeBodySeq parsedRecipeBodys;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeUploadReqResult_struct();
       rmsRecipeUploadReqResult_struct(const rmsRecipeUploadReqResult_struct&);
       rmsRecipeUploadReqResult_struct& operator=(const rmsRecipeUploadReqResult_struct&);
       static CORBA::Info<rmsRecipeUploadReqResult_struct> rmsRecipeUploadReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeUploadReqResult_struct


typedef rmsRecipeUploadReqResult_struct* rmsRecipeUploadReqResult_struct_vPtr;
typedef const rmsRecipeUploadReqResult_struct* rmsRecipeUploadReqResult_struct_cvPtr;

class  rmsRecipeUploadReqResult_struct_var
{
    public:

    rmsRecipeUploadReqResult_struct_var ();

    rmsRecipeUploadReqResult_struct_var (rmsRecipeUploadReqResult_struct *_p);

    rmsRecipeUploadReqResult_struct_var (const rmsRecipeUploadReqResult_struct_var &_s);

    rmsRecipeUploadReqResult_struct_var &operator= (rmsRecipeUploadReqResult_struct *_p);

    rmsRecipeUploadReqResult_struct_var &operator= (const rmsRecipeUploadReqResult_struct_var &_s);

    ~rmsRecipeUploadReqResult_struct_var ();

    rmsRecipeUploadReqResult_struct* operator-> ();

    const rmsRecipeUploadReqResult_struct& in() const;
    rmsRecipeUploadReqResult_struct& inout();
    rmsRecipeUploadReqResult_struct*& out();
    rmsRecipeUploadReqResult_struct* _retn();

    operator rmsRecipeUploadReqResult_struct_cvPtr () const;

    operator rmsRecipeUploadReqResult_struct_vPtr& ();

    operator const rmsRecipeUploadReqResult_struct& () const;

    operator rmsRecipeUploadReqResult_struct& ();

    protected:
    rmsRecipeUploadReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeUploadReqResult_struct;
    typedef rmsRecipeUploadReqResult_struct rmsRecipeUploadReqResult;
    typedef rmsRecipeUploadReqResult_struct_var rmsRecipeUploadReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeUploadReqResult;
    class  rmsRecipeCheckOutReqResult_struct_var;
    struct  rmsRecipeCheckOutReqResult_struct {
        typedef rmsRecipeCheckOutReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeCheckOutReqResult_struct();
       rmsRecipeCheckOutReqResult_struct(const rmsRecipeCheckOutReqResult_struct&);
       rmsRecipeCheckOutReqResult_struct& operator=(const rmsRecipeCheckOutReqResult_struct&);
       static CORBA::Info<rmsRecipeCheckOutReqResult_struct> rmsRecipeCheckOutReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeCheckOutReqResult_struct


typedef rmsRecipeCheckOutReqResult_struct* rmsRecipeCheckOutReqResult_struct_vPtr;
typedef const rmsRecipeCheckOutReqResult_struct* rmsRecipeCheckOutReqResult_struct_cvPtr;

class  rmsRecipeCheckOutReqResult_struct_var
{
    public:

    rmsRecipeCheckOutReqResult_struct_var ();

    rmsRecipeCheckOutReqResult_struct_var (rmsRecipeCheckOutReqResult_struct *_p);

    rmsRecipeCheckOutReqResult_struct_var (const rmsRecipeCheckOutReqResult_struct_var &_s);

    rmsRecipeCheckOutReqResult_struct_var &operator= (rmsRecipeCheckOutReqResult_struct *_p);

    rmsRecipeCheckOutReqResult_struct_var &operator= (const rmsRecipeCheckOutReqResult_struct_var &_s);

    ~rmsRecipeCheckOutReqResult_struct_var ();

    rmsRecipeCheckOutReqResult_struct* operator-> ();

    const rmsRecipeCheckOutReqResult_struct& in() const;
    rmsRecipeCheckOutReqResult_struct& inout();
    rmsRecipeCheckOutReqResult_struct*& out();
    rmsRecipeCheckOutReqResult_struct* _retn();

    operator rmsRecipeCheckOutReqResult_struct_cvPtr () const;

    operator rmsRecipeCheckOutReqResult_struct_vPtr& ();

    operator const rmsRecipeCheckOutReqResult_struct& () const;

    operator rmsRecipeCheckOutReqResult_struct& ();

    protected:
    rmsRecipeCheckOutReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeCheckOutReqResult_struct;
    typedef rmsRecipeCheckOutReqResult_struct rmsRecipeCheckOutReqResult;
    typedef rmsRecipeCheckOutReqResult_struct_var rmsRecipeCheckOutReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeCheckOutReqResult;
    class  rmsRecipeCheckInReqResult_struct_var;
    struct  rmsRecipeCheckInReqResult_struct {
        typedef rmsRecipeCheckInReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeCheckInReqResult_struct();
       rmsRecipeCheckInReqResult_struct(const rmsRecipeCheckInReqResult_struct&);
       rmsRecipeCheckInReqResult_struct& operator=(const rmsRecipeCheckInReqResult_struct&);
       static CORBA::Info<rmsRecipeCheckInReqResult_struct> rmsRecipeCheckInReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeCheckInReqResult_struct


typedef rmsRecipeCheckInReqResult_struct* rmsRecipeCheckInReqResult_struct_vPtr;
typedef const rmsRecipeCheckInReqResult_struct* rmsRecipeCheckInReqResult_struct_cvPtr;

class  rmsRecipeCheckInReqResult_struct_var
{
    public:

    rmsRecipeCheckInReqResult_struct_var ();

    rmsRecipeCheckInReqResult_struct_var (rmsRecipeCheckInReqResult_struct *_p);

    rmsRecipeCheckInReqResult_struct_var (const rmsRecipeCheckInReqResult_struct_var &_s);

    rmsRecipeCheckInReqResult_struct_var &operator= (rmsRecipeCheckInReqResult_struct *_p);

    rmsRecipeCheckInReqResult_struct_var &operator= (const rmsRecipeCheckInReqResult_struct_var &_s);

    ~rmsRecipeCheckInReqResult_struct_var ();

    rmsRecipeCheckInReqResult_struct* operator-> ();

    const rmsRecipeCheckInReqResult_struct& in() const;
    rmsRecipeCheckInReqResult_struct& inout();
    rmsRecipeCheckInReqResult_struct*& out();
    rmsRecipeCheckInReqResult_struct* _retn();

    operator rmsRecipeCheckInReqResult_struct_cvPtr () const;

    operator rmsRecipeCheckInReqResult_struct_vPtr& ();

    operator const rmsRecipeCheckInReqResult_struct& () const;

    operator rmsRecipeCheckInReqResult_struct& ();

    protected:
    rmsRecipeCheckInReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeCheckInReqResult_struct;
    typedef rmsRecipeCheckInReqResult_struct rmsRecipeCheckInReqResult;
    typedef rmsRecipeCheckInReqResult_struct_var rmsRecipeCheckInReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeCheckInReqResult;
    class  rmsRecipeSaveReqResult_struct_var;
    struct  rmsRecipeSaveReqResult_struct {
        typedef rmsRecipeSaveReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeSaveReqResult_struct();
       rmsRecipeSaveReqResult_struct(const rmsRecipeSaveReqResult_struct&);
       rmsRecipeSaveReqResult_struct& operator=(const rmsRecipeSaveReqResult_struct&);
       static CORBA::Info<rmsRecipeSaveReqResult_struct> rmsRecipeSaveReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeSaveReqResult_struct


typedef rmsRecipeSaveReqResult_struct* rmsRecipeSaveReqResult_struct_vPtr;
typedef const rmsRecipeSaveReqResult_struct* rmsRecipeSaveReqResult_struct_cvPtr;

class  rmsRecipeSaveReqResult_struct_var
{
    public:

    rmsRecipeSaveReqResult_struct_var ();

    rmsRecipeSaveReqResult_struct_var (rmsRecipeSaveReqResult_struct *_p);

    rmsRecipeSaveReqResult_struct_var (const rmsRecipeSaveReqResult_struct_var &_s);

    rmsRecipeSaveReqResult_struct_var &operator= (rmsRecipeSaveReqResult_struct *_p);

    rmsRecipeSaveReqResult_struct_var &operator= (const rmsRecipeSaveReqResult_struct_var &_s);

    ~rmsRecipeSaveReqResult_struct_var ();

    rmsRecipeSaveReqResult_struct* operator-> ();

    const rmsRecipeSaveReqResult_struct& in() const;
    rmsRecipeSaveReqResult_struct& inout();
    rmsRecipeSaveReqResult_struct*& out();
    rmsRecipeSaveReqResult_struct* _retn();

    operator rmsRecipeSaveReqResult_struct_cvPtr () const;

    operator rmsRecipeSaveReqResult_struct_vPtr& ();

    operator const rmsRecipeSaveReqResult_struct& () const;

    operator rmsRecipeSaveReqResult_struct& ();

    protected:
    rmsRecipeSaveReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeSaveReqResult_struct;
    typedef rmsRecipeSaveReqResult_struct rmsRecipeSaveReqResult;
    typedef rmsRecipeSaveReqResult_struct_var rmsRecipeSaveReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeSaveReqResult;
    class  rmsRecipeSetGoldenReqResult_struct_var;
    struct  rmsRecipeSetGoldenReqResult_struct {
        typedef rmsRecipeSetGoldenReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeSetGoldenReqResult_struct();
       rmsRecipeSetGoldenReqResult_struct(const rmsRecipeSetGoldenReqResult_struct&);
       rmsRecipeSetGoldenReqResult_struct& operator=(const rmsRecipeSetGoldenReqResult_struct&);
       static CORBA::Info<rmsRecipeSetGoldenReqResult_struct> rmsRecipeSetGoldenReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeSetGoldenReqResult_struct


typedef rmsRecipeSetGoldenReqResult_struct* rmsRecipeSetGoldenReqResult_struct_vPtr;
typedef const rmsRecipeSetGoldenReqResult_struct* rmsRecipeSetGoldenReqResult_struct_cvPtr;

class  rmsRecipeSetGoldenReqResult_struct_var
{
    public:

    rmsRecipeSetGoldenReqResult_struct_var ();

    rmsRecipeSetGoldenReqResult_struct_var (rmsRecipeSetGoldenReqResult_struct *_p);

    rmsRecipeSetGoldenReqResult_struct_var (const rmsRecipeSetGoldenReqResult_struct_var &_s);

    rmsRecipeSetGoldenReqResult_struct_var &operator= (rmsRecipeSetGoldenReqResult_struct *_p);

    rmsRecipeSetGoldenReqResult_struct_var &operator= (const rmsRecipeSetGoldenReqResult_struct_var &_s);

    ~rmsRecipeSetGoldenReqResult_struct_var ();

    rmsRecipeSetGoldenReqResult_struct* operator-> ();

    const rmsRecipeSetGoldenReqResult_struct& in() const;
    rmsRecipeSetGoldenReqResult_struct& inout();
    rmsRecipeSetGoldenReqResult_struct*& out();
    rmsRecipeSetGoldenReqResult_struct* _retn();

    operator rmsRecipeSetGoldenReqResult_struct_cvPtr () const;

    operator rmsRecipeSetGoldenReqResult_struct_vPtr& ();

    operator const rmsRecipeSetGoldenReqResult_struct& () const;

    operator rmsRecipeSetGoldenReqResult_struct& ();

    protected:
    rmsRecipeSetGoldenReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeSetGoldenReqResult_struct;
    typedef rmsRecipeSetGoldenReqResult_struct rmsRecipeSetGoldenReqResult;
    typedef rmsRecipeSetGoldenReqResult_struct_var rmsRecipeSetGoldenReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeSetGoldenReqResult;
    class  rmsPreAuditInqResult_struct_var;
    struct  rmsPreAuditInqResult_struct {
        typedef rmsPreAuditInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem recipeFileLocation;
       ::tcsEqpConstantSequence ECIDList;
       ::tcsEqpConstantSequence SVIDList;
       ::tcsRecipeSequence recipeList;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsPreAuditInqResult_struct();
       rmsPreAuditInqResult_struct(const rmsPreAuditInqResult_struct&);
       rmsPreAuditInqResult_struct& operator=(const rmsPreAuditInqResult_struct&);
       static CORBA::Info<rmsPreAuditInqResult_struct> rmsPreAuditInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsPreAuditInqResult_struct


typedef rmsPreAuditInqResult_struct* rmsPreAuditInqResult_struct_vPtr;
typedef const rmsPreAuditInqResult_struct* rmsPreAuditInqResult_struct_cvPtr;

class  rmsPreAuditInqResult_struct_var
{
    public:

    rmsPreAuditInqResult_struct_var ();

    rmsPreAuditInqResult_struct_var (rmsPreAuditInqResult_struct *_p);

    rmsPreAuditInqResult_struct_var (const rmsPreAuditInqResult_struct_var &_s);

    rmsPreAuditInqResult_struct_var &operator= (rmsPreAuditInqResult_struct *_p);

    rmsPreAuditInqResult_struct_var &operator= (const rmsPreAuditInqResult_struct_var &_s);

    ~rmsPreAuditInqResult_struct_var ();

    rmsPreAuditInqResult_struct* operator-> ();

    const rmsPreAuditInqResult_struct& in() const;
    rmsPreAuditInqResult_struct& inout();
    rmsPreAuditInqResult_struct*& out();
    rmsPreAuditInqResult_struct* _retn();

    operator rmsPreAuditInqResult_struct_cvPtr () const;

    operator rmsPreAuditInqResult_struct_vPtr& ();

    operator const rmsPreAuditInqResult_struct& () const;

    operator rmsPreAuditInqResult_struct& ();

    protected:
    rmsPreAuditInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsPreAuditInqResult_struct;
    typedef rmsPreAuditInqResult_struct rmsPreAuditInqResult;
    typedef rmsPreAuditInqResult_struct_var rmsPreAuditInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsPreAuditInqResult;
    class  rmsSetDBUserPswdReqResult_struct_var;
    struct  rmsSetDBUserPswdReqResult_struct {
        typedef rmsSetDBUserPswdReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsSetDBUserPswdReqResult_struct();
       rmsSetDBUserPswdReqResult_struct(const rmsSetDBUserPswdReqResult_struct&);
       rmsSetDBUserPswdReqResult_struct& operator=(const rmsSetDBUserPswdReqResult_struct&);
       static CORBA::Info<rmsSetDBUserPswdReqResult_struct> rmsSetDBUserPswdReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsSetDBUserPswdReqResult_struct


typedef rmsSetDBUserPswdReqResult_struct* rmsSetDBUserPswdReqResult_struct_vPtr;
typedef const rmsSetDBUserPswdReqResult_struct* rmsSetDBUserPswdReqResult_struct_cvPtr;

class  rmsSetDBUserPswdReqResult_struct_var
{
    public:

    rmsSetDBUserPswdReqResult_struct_var ();

    rmsSetDBUserPswdReqResult_struct_var (rmsSetDBUserPswdReqResult_struct *_p);

    rmsSetDBUserPswdReqResult_struct_var (const rmsSetDBUserPswdReqResult_struct_var &_s);

    rmsSetDBUserPswdReqResult_struct_var &operator= (rmsSetDBUserPswdReqResult_struct *_p);

    rmsSetDBUserPswdReqResult_struct_var &operator= (const rmsSetDBUserPswdReqResult_struct_var &_s);

    ~rmsSetDBUserPswdReqResult_struct_var ();

    rmsSetDBUserPswdReqResult_struct* operator-> ();

    const rmsSetDBUserPswdReqResult_struct& in() const;
    rmsSetDBUserPswdReqResult_struct& inout();
    rmsSetDBUserPswdReqResult_struct*& out();
    rmsSetDBUserPswdReqResult_struct* _retn();

    operator rmsSetDBUserPswdReqResult_struct_cvPtr () const;

    operator rmsSetDBUserPswdReqResult_struct_vPtr& ();

    operator const rmsSetDBUserPswdReqResult_struct& () const;

    operator rmsSetDBUserPswdReqResult_struct& ();

    protected:
    rmsSetDBUserPswdReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsSetDBUserPswdReqResult_struct;
    typedef rmsSetDBUserPswdReqResult_struct rmsSetDBUserPswdReqResult;
    typedef rmsSetDBUserPswdReqResult_struct_var rmsSetDBUserPswdReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsSetDBUserPswdReqResult;
    class  rmsConstantValue_struct_var;
    struct  rmsConstantValue_struct {
        typedef rmsConstantValue_struct_var _var_type;
       ::CORBA::String_StructElem name;
       ::CORBA::String_StructElem value;
       ::CORBA::String_StructElem listPath;
       ::CORBA::String_StructElem maxValue;
       ::CORBA::String_StructElem minValue;
       ::CORBA::String_StructElem currentValue;
       ::CORBA::Short audit;
       ::CORBA::Boolean diffFlag;
       ::rmsRangeValueSeq toleranceValues;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsConstantValue_struct();
       rmsConstantValue_struct(const rmsConstantValue_struct&);
       rmsConstantValue_struct& operator=(const rmsConstantValue_struct&);
       static CORBA::Info<rmsConstantValue_struct> rmsConstantValue_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsConstantValue_struct


typedef rmsConstantValue_struct* rmsConstantValue_struct_vPtr;
typedef const rmsConstantValue_struct* rmsConstantValue_struct_cvPtr;

class  rmsConstantValue_struct_var
{
    public:

    rmsConstantValue_struct_var ();

    rmsConstantValue_struct_var (rmsConstantValue_struct *_p);

    rmsConstantValue_struct_var (const rmsConstantValue_struct_var &_s);

    rmsConstantValue_struct_var &operator= (rmsConstantValue_struct *_p);

    rmsConstantValue_struct_var &operator= (const rmsConstantValue_struct_var &_s);

    ~rmsConstantValue_struct_var ();

    rmsConstantValue_struct* operator-> ();

    const rmsConstantValue_struct& in() const;
    rmsConstantValue_struct& inout();
    rmsConstantValue_struct*& out();
    rmsConstantValue_struct* _retn();

    operator rmsConstantValue_struct_cvPtr () const;

    operator rmsConstantValue_struct_vPtr& ();

    operator const rmsConstantValue_struct& () const;

    operator rmsConstantValue_struct& ();

    protected:
    rmsConstantValue_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsConstantValue_struct;
    typedef rmsConstantValue_struct rmsConstantValue;
    typedef rmsConstantValue_struct_var rmsConstantValue_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsConstantValue;
class  _IDL_SEQ_rmsConstantValueSequence_0_var;
class  _IDL_SEQ_rmsConstantValueSequence_0 {
    public:
        typedef _IDL_SEQ_rmsConstantValueSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsConstantValue *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsConstantValueSequence_0 ();
    _IDL_SEQ_rmsConstantValueSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsConstantValueSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsConstantValue* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsConstantValueSequence_0 (const _IDL_SEQ_rmsConstantValueSequence_0&);

    ~_IDL_SEQ_rmsConstantValueSequence_0 ();

    _IDL_SEQ_rmsConstantValueSequence_0& operator= (const _IDL_SEQ_rmsConstantValueSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsConstantValue& operator [] (::CORBA::ULong indx);
    const rmsConstantValue& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsConstantValue* get_buffer (::CORBA::Boolean orphan=0);
    const rmsConstantValue* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsConstantValue* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsConstantValue* src, rmsConstantValue* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsConstantValue* data); 
  public:

    static rmsConstantValue* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsConstantValue* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsConstantValue* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsConstantValueSequence_0> rmsConstantValueSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsConstantValueSequence_0* _IDL_SEQ_rmsConstantValueSequence_0_vPtr;
typedef const _IDL_SEQ_rmsConstantValueSequence_0* _IDL_SEQ_rmsConstantValueSequence_0_cvPtr;

class  _IDL_SEQ_rmsConstantValueSequence_0_var
{
    public:

    _IDL_SEQ_rmsConstantValueSequence_0_var ();

    _IDL_SEQ_rmsConstantValueSequence_0_var (_IDL_SEQ_rmsConstantValueSequence_0 *_p);

    _IDL_SEQ_rmsConstantValueSequence_0_var (const _IDL_SEQ_rmsConstantValueSequence_0_var &_s);

    _IDL_SEQ_rmsConstantValueSequence_0_var &operator= (_IDL_SEQ_rmsConstantValueSequence_0 *_p);

    _IDL_SEQ_rmsConstantValueSequence_0_var &operator= (const _IDL_SEQ_rmsConstantValueSequence_0_var &_s);

    ~_IDL_SEQ_rmsConstantValueSequence_0_var ();

    _IDL_SEQ_rmsConstantValueSequence_0* operator-> ();

    operator _IDL_SEQ_rmsConstantValueSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsConstantValueSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsConstantValueSequence_0() const;

    const rmsConstantValue& operator[] (::CORBA::ULong index) const;
    rmsConstantValue& operator[] (::CORBA::ULong index);
    const rmsConstantValue& operator[] (int index) const;
    rmsConstantValue& operator[] (int index);
    const _IDL_SEQ_rmsConstantValueSequence_0& in() const;
    _IDL_SEQ_rmsConstantValueSequence_0& inout();
    _IDL_SEQ_rmsConstantValueSequence_0*& out();
    _IDL_SEQ_rmsConstantValueSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsConstantValueSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsConstantValueSequence_0 _rmsConstantValueSequence_seq;
    typedef _IDL_SEQ_rmsConstantValueSequence_0 _rmsConstantValueSequence_seq_1;
    typedef _IDL_SEQ_rmsConstantValueSequence_0 rmsConstantValueSequence;
    typedef _IDL_SEQ_rmsConstantValueSequence_0_var rmsConstantValueSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsConstantValueSequence;
    class  rmsEqpConstant_struct_var;
    struct  rmsEqpConstant_struct {
        typedef rmsEqpConstant_struct_var _var_type;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::LongLong constantID;
       ::CORBA::Boolean isSVID;
       ::rmsConstantValueSequence constValues;
       ::CORBA::Boolean diffFlag;
       ::CORBA::String_StructElem blockName;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpConstant_struct();
       rmsEqpConstant_struct(const rmsEqpConstant_struct&);
       rmsEqpConstant_struct& operator=(const rmsEqpConstant_struct&);
       static CORBA::Info<rmsEqpConstant_struct> rmsEqpConstant_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpConstant_struct


typedef rmsEqpConstant_struct* rmsEqpConstant_struct_vPtr;
typedef const rmsEqpConstant_struct* rmsEqpConstant_struct_cvPtr;

class  rmsEqpConstant_struct_var
{
    public:

    rmsEqpConstant_struct_var ();

    rmsEqpConstant_struct_var (rmsEqpConstant_struct *_p);

    rmsEqpConstant_struct_var (const rmsEqpConstant_struct_var &_s);

    rmsEqpConstant_struct_var &operator= (rmsEqpConstant_struct *_p);

    rmsEqpConstant_struct_var &operator= (const rmsEqpConstant_struct_var &_s);

    ~rmsEqpConstant_struct_var ();

    rmsEqpConstant_struct* operator-> ();

    const rmsEqpConstant_struct& in() const;
    rmsEqpConstant_struct& inout();
    rmsEqpConstant_struct*& out();
    rmsEqpConstant_struct* _retn();

    operator rmsEqpConstant_struct_cvPtr () const;

    operator rmsEqpConstant_struct_vPtr& ();

    operator const rmsEqpConstant_struct& () const;

    operator rmsEqpConstant_struct& ();

    protected:
    rmsEqpConstant_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstant_struct;
    typedef rmsEqpConstant_struct rmsEqpConstant;
    typedef rmsEqpConstant_struct_var rmsEqpConstant_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstant;
class  _IDL_SEQ_rmsEqpConstantSequence_0_var;
class  _IDL_SEQ_rmsEqpConstantSequence_0 {
    public:
        typedef _IDL_SEQ_rmsEqpConstantSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsEqpConstant *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsEqpConstantSequence_0 ();
    _IDL_SEQ_rmsEqpConstantSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsEqpConstantSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpConstant* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsEqpConstantSequence_0 (const _IDL_SEQ_rmsEqpConstantSequence_0&);

    ~_IDL_SEQ_rmsEqpConstantSequence_0 ();

    _IDL_SEQ_rmsEqpConstantSequence_0& operator= (const _IDL_SEQ_rmsEqpConstantSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsEqpConstant& operator [] (::CORBA::ULong indx);
    const rmsEqpConstant& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsEqpConstant* get_buffer (::CORBA::Boolean orphan=0);
    const rmsEqpConstant* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpConstant* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpConstant* src, rmsEqpConstant* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpConstant* data); 
  public:

    static rmsEqpConstant* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsEqpConstant* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsEqpConstant* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsEqpConstantSequence_0> rmsEqpConstantSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsEqpConstantSequence_0* _IDL_SEQ_rmsEqpConstantSequence_0_vPtr;
typedef const _IDL_SEQ_rmsEqpConstantSequence_0* _IDL_SEQ_rmsEqpConstantSequence_0_cvPtr;

class  _IDL_SEQ_rmsEqpConstantSequence_0_var
{
    public:

    _IDL_SEQ_rmsEqpConstantSequence_0_var ();

    _IDL_SEQ_rmsEqpConstantSequence_0_var (_IDL_SEQ_rmsEqpConstantSequence_0 *_p);

    _IDL_SEQ_rmsEqpConstantSequence_0_var (const _IDL_SEQ_rmsEqpConstantSequence_0_var &_s);

    _IDL_SEQ_rmsEqpConstantSequence_0_var &operator= (_IDL_SEQ_rmsEqpConstantSequence_0 *_p);

    _IDL_SEQ_rmsEqpConstantSequence_0_var &operator= (const _IDL_SEQ_rmsEqpConstantSequence_0_var &_s);

    ~_IDL_SEQ_rmsEqpConstantSequence_0_var ();

    _IDL_SEQ_rmsEqpConstantSequence_0* operator-> ();

    operator _IDL_SEQ_rmsEqpConstantSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsEqpConstantSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsEqpConstantSequence_0() const;

    const rmsEqpConstant& operator[] (::CORBA::ULong index) const;
    rmsEqpConstant& operator[] (::CORBA::ULong index);
    const rmsEqpConstant& operator[] (int index) const;
    rmsEqpConstant& operator[] (int index);
    const _IDL_SEQ_rmsEqpConstantSequence_0& in() const;
    _IDL_SEQ_rmsEqpConstantSequence_0& inout();
    _IDL_SEQ_rmsEqpConstantSequence_0*& out();
    _IDL_SEQ_rmsEqpConstantSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsEqpConstantSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsEqpConstantSequence_0 _rmsEqpConstantSequence_seq;
    typedef _IDL_SEQ_rmsEqpConstantSequence_0 _rmsEqpConstantSequence_seq_1;
    typedef _IDL_SEQ_rmsEqpConstantSequence_0 rmsEqpConstantSequence;
    typedef _IDL_SEQ_rmsEqpConstantSequence_0_var rmsEqpConstantSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantSequence;
    class  rmsEqpConstantInqResult_struct_var;
    struct  rmsEqpConstantInqResult_struct {
        typedef rmsEqpConstantInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEqpConstantSequence constLists;
       ::CORBA::String_StructElem checkOutUser;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpConstantInqResult_struct();
       rmsEqpConstantInqResult_struct(const rmsEqpConstantInqResult_struct&);
       rmsEqpConstantInqResult_struct& operator=(const rmsEqpConstantInqResult_struct&);
       static CORBA::Info<rmsEqpConstantInqResult_struct> rmsEqpConstantInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpConstantInqResult_struct


typedef rmsEqpConstantInqResult_struct* rmsEqpConstantInqResult_struct_vPtr;
typedef const rmsEqpConstantInqResult_struct* rmsEqpConstantInqResult_struct_cvPtr;

class  rmsEqpConstantInqResult_struct_var
{
    public:

    rmsEqpConstantInqResult_struct_var ();

    rmsEqpConstantInqResult_struct_var (rmsEqpConstantInqResult_struct *_p);

    rmsEqpConstantInqResult_struct_var (const rmsEqpConstantInqResult_struct_var &_s);

    rmsEqpConstantInqResult_struct_var &operator= (rmsEqpConstantInqResult_struct *_p);

    rmsEqpConstantInqResult_struct_var &operator= (const rmsEqpConstantInqResult_struct_var &_s);

    ~rmsEqpConstantInqResult_struct_var ();

    rmsEqpConstantInqResult_struct* operator-> ();

    const rmsEqpConstantInqResult_struct& in() const;
    rmsEqpConstantInqResult_struct& inout();
    rmsEqpConstantInqResult_struct*& out();
    rmsEqpConstantInqResult_struct* _retn();

    operator rmsEqpConstantInqResult_struct_cvPtr () const;

    operator rmsEqpConstantInqResult_struct_vPtr& ();

    operator const rmsEqpConstantInqResult_struct& () const;

    operator rmsEqpConstantInqResult_struct& ();

    protected:
    rmsEqpConstantInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantInqResult_struct;
    typedef rmsEqpConstantInqResult_struct rmsEqpConstantInqResult;
    typedef rmsEqpConstantInqResult_struct_var rmsEqpConstantInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantInqResult;
    class  rmsEqpConstantUploadReqResult_struct_var;
    struct  rmsEqpConstantUploadReqResult_struct {
        typedef rmsEqpConstantUploadReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEqpConstantSequence constLists;
       ::CORBA::String_StructElem checkOutUser;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpConstantUploadReqResult_struct();
       rmsEqpConstantUploadReqResult_struct(const rmsEqpConstantUploadReqResult_struct&);
       rmsEqpConstantUploadReqResult_struct& operator=(const rmsEqpConstantUploadReqResult_struct&);
       static CORBA::Info<rmsEqpConstantUploadReqResult_struct> rmsEqpConstantUploadReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpConstantUploadReqResult_struct


typedef rmsEqpConstantUploadReqResult_struct* rmsEqpConstantUploadReqResult_struct_vPtr;
typedef const rmsEqpConstantUploadReqResult_struct* rmsEqpConstantUploadReqResult_struct_cvPtr;

class  rmsEqpConstantUploadReqResult_struct_var
{
    public:

    rmsEqpConstantUploadReqResult_struct_var ();

    rmsEqpConstantUploadReqResult_struct_var (rmsEqpConstantUploadReqResult_struct *_p);

    rmsEqpConstantUploadReqResult_struct_var (const rmsEqpConstantUploadReqResult_struct_var &_s);

    rmsEqpConstantUploadReqResult_struct_var &operator= (rmsEqpConstantUploadReqResult_struct *_p);

    rmsEqpConstantUploadReqResult_struct_var &operator= (const rmsEqpConstantUploadReqResult_struct_var &_s);

    ~rmsEqpConstantUploadReqResult_struct_var ();

    rmsEqpConstantUploadReqResult_struct* operator-> ();

    const rmsEqpConstantUploadReqResult_struct& in() const;
    rmsEqpConstantUploadReqResult_struct& inout();
    rmsEqpConstantUploadReqResult_struct*& out();
    rmsEqpConstantUploadReqResult_struct* _retn();

    operator rmsEqpConstantUploadReqResult_struct_cvPtr () const;

    operator rmsEqpConstantUploadReqResult_struct_vPtr& ();

    operator const rmsEqpConstantUploadReqResult_struct& () const;

    operator rmsEqpConstantUploadReqResult_struct& ();

    protected:
    rmsEqpConstantUploadReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantUploadReqResult_struct;
    typedef rmsEqpConstantUploadReqResult_struct rmsEqpConstantUploadReqResult;
    typedef rmsEqpConstantUploadReqResult_struct_var rmsEqpConstantUploadReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantUploadReqResult;
    class  rmsEqpConstantCheckOutReqResult_struct_var;
    struct  rmsEqpConstantCheckOutReqResult_struct {
        typedef rmsEqpConstantCheckOutReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpConstantCheckOutReqResult_struct();
       rmsEqpConstantCheckOutReqResult_struct(const rmsEqpConstantCheckOutReqResult_struct&);
       rmsEqpConstantCheckOutReqResult_struct& operator=(const rmsEqpConstantCheckOutReqResult_struct&);
       static CORBA::Info<rmsEqpConstantCheckOutReqResult_struct> rmsEqpConstantCheckOutReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpConstantCheckOutReqResult_struct


typedef rmsEqpConstantCheckOutReqResult_struct* rmsEqpConstantCheckOutReqResult_struct_vPtr;
typedef const rmsEqpConstantCheckOutReqResult_struct* rmsEqpConstantCheckOutReqResult_struct_cvPtr;

class  rmsEqpConstantCheckOutReqResult_struct_var
{
    public:

    rmsEqpConstantCheckOutReqResult_struct_var ();

    rmsEqpConstantCheckOutReqResult_struct_var (rmsEqpConstantCheckOutReqResult_struct *_p);

    rmsEqpConstantCheckOutReqResult_struct_var (const rmsEqpConstantCheckOutReqResult_struct_var &_s);

    rmsEqpConstantCheckOutReqResult_struct_var &operator= (rmsEqpConstantCheckOutReqResult_struct *_p);

    rmsEqpConstantCheckOutReqResult_struct_var &operator= (const rmsEqpConstantCheckOutReqResult_struct_var &_s);

    ~rmsEqpConstantCheckOutReqResult_struct_var ();

    rmsEqpConstantCheckOutReqResult_struct* operator-> ();

    const rmsEqpConstantCheckOutReqResult_struct& in() const;
    rmsEqpConstantCheckOutReqResult_struct& inout();
    rmsEqpConstantCheckOutReqResult_struct*& out();
    rmsEqpConstantCheckOutReqResult_struct* _retn();

    operator rmsEqpConstantCheckOutReqResult_struct_cvPtr () const;

    operator rmsEqpConstantCheckOutReqResult_struct_vPtr& ();

    operator const rmsEqpConstantCheckOutReqResult_struct& () const;

    operator rmsEqpConstantCheckOutReqResult_struct& ();

    protected:
    rmsEqpConstantCheckOutReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantCheckOutReqResult_struct;
    typedef rmsEqpConstantCheckOutReqResult_struct rmsEqpConstantCheckOutReqResult;
    typedef rmsEqpConstantCheckOutReqResult_struct_var rmsEqpConstantCheckOutReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantCheckOutReqResult;
    class  rmsEqpConstantCheckInReqResult_struct_var;
    struct  rmsEqpConstantCheckInReqResult_struct {
        typedef rmsEqpConstantCheckInReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpConstantCheckInReqResult_struct();
       rmsEqpConstantCheckInReqResult_struct(const rmsEqpConstantCheckInReqResult_struct&);
       rmsEqpConstantCheckInReqResult_struct& operator=(const rmsEqpConstantCheckInReqResult_struct&);
       static CORBA::Info<rmsEqpConstantCheckInReqResult_struct> rmsEqpConstantCheckInReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpConstantCheckInReqResult_struct


typedef rmsEqpConstantCheckInReqResult_struct* rmsEqpConstantCheckInReqResult_struct_vPtr;
typedef const rmsEqpConstantCheckInReqResult_struct* rmsEqpConstantCheckInReqResult_struct_cvPtr;

class  rmsEqpConstantCheckInReqResult_struct_var
{
    public:

    rmsEqpConstantCheckInReqResult_struct_var ();

    rmsEqpConstantCheckInReqResult_struct_var (rmsEqpConstantCheckInReqResult_struct *_p);

    rmsEqpConstantCheckInReqResult_struct_var (const rmsEqpConstantCheckInReqResult_struct_var &_s);

    rmsEqpConstantCheckInReqResult_struct_var &operator= (rmsEqpConstantCheckInReqResult_struct *_p);

    rmsEqpConstantCheckInReqResult_struct_var &operator= (const rmsEqpConstantCheckInReqResult_struct_var &_s);

    ~rmsEqpConstantCheckInReqResult_struct_var ();

    rmsEqpConstantCheckInReqResult_struct* operator-> ();

    const rmsEqpConstantCheckInReqResult_struct& in() const;
    rmsEqpConstantCheckInReqResult_struct& inout();
    rmsEqpConstantCheckInReqResult_struct*& out();
    rmsEqpConstantCheckInReqResult_struct* _retn();

    operator rmsEqpConstantCheckInReqResult_struct_cvPtr () const;

    operator rmsEqpConstantCheckInReqResult_struct_vPtr& ();

    operator const rmsEqpConstantCheckInReqResult_struct& () const;

    operator rmsEqpConstantCheckInReqResult_struct& ();

    protected:
    rmsEqpConstantCheckInReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantCheckInReqResult_struct;
    typedef rmsEqpConstantCheckInReqResult_struct rmsEqpConstantCheckInReqResult;
    typedef rmsEqpConstantCheckInReqResult_struct_var rmsEqpConstantCheckInReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantCheckInReqResult;
    class  rmsEqpConstantSaveReqResult_struct_var;
    struct  rmsEqpConstantSaveReqResult_struct {
        typedef rmsEqpConstantSaveReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpConstantSaveReqResult_struct();
       rmsEqpConstantSaveReqResult_struct(const rmsEqpConstantSaveReqResult_struct&);
       rmsEqpConstantSaveReqResult_struct& operator=(const rmsEqpConstantSaveReqResult_struct&);
       static CORBA::Info<rmsEqpConstantSaveReqResult_struct> rmsEqpConstantSaveReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpConstantSaveReqResult_struct


typedef rmsEqpConstantSaveReqResult_struct* rmsEqpConstantSaveReqResult_struct_vPtr;
typedef const rmsEqpConstantSaveReqResult_struct* rmsEqpConstantSaveReqResult_struct_cvPtr;

class  rmsEqpConstantSaveReqResult_struct_var
{
    public:

    rmsEqpConstantSaveReqResult_struct_var ();

    rmsEqpConstantSaveReqResult_struct_var (rmsEqpConstantSaveReqResult_struct *_p);

    rmsEqpConstantSaveReqResult_struct_var (const rmsEqpConstantSaveReqResult_struct_var &_s);

    rmsEqpConstantSaveReqResult_struct_var &operator= (rmsEqpConstantSaveReqResult_struct *_p);

    rmsEqpConstantSaveReqResult_struct_var &operator= (const rmsEqpConstantSaveReqResult_struct_var &_s);

    ~rmsEqpConstantSaveReqResult_struct_var ();

    rmsEqpConstantSaveReqResult_struct* operator-> ();

    const rmsEqpConstantSaveReqResult_struct& in() const;
    rmsEqpConstantSaveReqResult_struct& inout();
    rmsEqpConstantSaveReqResult_struct*& out();
    rmsEqpConstantSaveReqResult_struct* _retn();

    operator rmsEqpConstantSaveReqResult_struct_cvPtr () const;

    operator rmsEqpConstantSaveReqResult_struct_vPtr& ();

    operator const rmsEqpConstantSaveReqResult_struct& () const;

    operator rmsEqpConstantSaveReqResult_struct& ();

    protected:
    rmsEqpConstantSaveReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantSaveReqResult_struct;
    typedef rmsEqpConstantSaveReqResult_struct rmsEqpConstantSaveReqResult;
    typedef rmsEqpConstantSaveReqResult_struct_var rmsEqpConstantSaveReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantSaveReqResult;
    class  rmsHistoryRecord_struct_var;
    struct  rmsHistoryRecord_struct {
        typedef rmsHistoryRecord_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqpID;
       ::CORBA::String_StructElem actionCode;
       ::CORBA::String_StructElem recipeID;
       ::CORBA::String_StructElem subRecipe;
       ::CORBA::String_StructElem compareResult;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::String_StructElem claimTime;
       ::CORBA::String_StructElem claimUserID;
       ::CORBA::String_StructElem confirmUserID;
       ::CORBA::String_StructElem message;
       ::CORBA::Long recipeLevel;
       ::CORBA::String_StructElem chamberID;
       ::CORBA::String_StructElem reasonCode;
       ::CORBA::String_StructElem reasonDesc;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsHistoryRecord_struct();
       rmsHistoryRecord_struct(const rmsHistoryRecord_struct&);
       rmsHistoryRecord_struct& operator=(const rmsHistoryRecord_struct&);
       static CORBA::Info<rmsHistoryRecord_struct> rmsHistoryRecord_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsHistoryRecord_struct


typedef rmsHistoryRecord_struct* rmsHistoryRecord_struct_vPtr;
typedef const rmsHistoryRecord_struct* rmsHistoryRecord_struct_cvPtr;

class  rmsHistoryRecord_struct_var
{
    public:

    rmsHistoryRecord_struct_var ();

    rmsHistoryRecord_struct_var (rmsHistoryRecord_struct *_p);

    rmsHistoryRecord_struct_var (const rmsHistoryRecord_struct_var &_s);

    rmsHistoryRecord_struct_var &operator= (rmsHistoryRecord_struct *_p);

    rmsHistoryRecord_struct_var &operator= (const rmsHistoryRecord_struct_var &_s);

    ~rmsHistoryRecord_struct_var ();

    rmsHistoryRecord_struct* operator-> ();

    const rmsHistoryRecord_struct& in() const;
    rmsHistoryRecord_struct& inout();
    rmsHistoryRecord_struct*& out();
    rmsHistoryRecord_struct* _retn();

    operator rmsHistoryRecord_struct_cvPtr () const;

    operator rmsHistoryRecord_struct_vPtr& ();

    operator const rmsHistoryRecord_struct& () const;

    operator rmsHistoryRecord_struct& ();

    protected:
    rmsHistoryRecord_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsHistoryRecord_struct;
    typedef rmsHistoryRecord_struct rmsHistoryRecord;
    typedef rmsHistoryRecord_struct_var rmsHistoryRecord_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsHistoryRecord;
class  _IDL_SEQ_rmsHistoryRecordSequence_0_var;
class  _IDL_SEQ_rmsHistoryRecordSequence_0 {
    public:
        typedef _IDL_SEQ_rmsHistoryRecordSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsHistoryRecord *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsHistoryRecordSequence_0 ();
    _IDL_SEQ_rmsHistoryRecordSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsHistoryRecordSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsHistoryRecord* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsHistoryRecordSequence_0 (const _IDL_SEQ_rmsHistoryRecordSequence_0&);

    ~_IDL_SEQ_rmsHistoryRecordSequence_0 ();

    _IDL_SEQ_rmsHistoryRecordSequence_0& operator= (const _IDL_SEQ_rmsHistoryRecordSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsHistoryRecord& operator [] (::CORBA::ULong indx);
    const rmsHistoryRecord& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsHistoryRecord* get_buffer (::CORBA::Boolean orphan=0);
    const rmsHistoryRecord* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsHistoryRecord* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsHistoryRecord* src, rmsHistoryRecord* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsHistoryRecord* data); 
  public:

    static rmsHistoryRecord* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsHistoryRecord* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsHistoryRecord* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsHistoryRecordSequence_0> rmsHistoryRecordSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsHistoryRecordSequence_0* _IDL_SEQ_rmsHistoryRecordSequence_0_vPtr;
typedef const _IDL_SEQ_rmsHistoryRecordSequence_0* _IDL_SEQ_rmsHistoryRecordSequence_0_cvPtr;

class  _IDL_SEQ_rmsHistoryRecordSequence_0_var
{
    public:

    _IDL_SEQ_rmsHistoryRecordSequence_0_var ();

    _IDL_SEQ_rmsHistoryRecordSequence_0_var (_IDL_SEQ_rmsHistoryRecordSequence_0 *_p);

    _IDL_SEQ_rmsHistoryRecordSequence_0_var (const _IDL_SEQ_rmsHistoryRecordSequence_0_var &_s);

    _IDL_SEQ_rmsHistoryRecordSequence_0_var &operator= (_IDL_SEQ_rmsHistoryRecordSequence_0 *_p);

    _IDL_SEQ_rmsHistoryRecordSequence_0_var &operator= (const _IDL_SEQ_rmsHistoryRecordSequence_0_var &_s);

    ~_IDL_SEQ_rmsHistoryRecordSequence_0_var ();

    _IDL_SEQ_rmsHistoryRecordSequence_0* operator-> ();

    operator _IDL_SEQ_rmsHistoryRecordSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsHistoryRecordSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsHistoryRecordSequence_0() const;

    const rmsHistoryRecord& operator[] (::CORBA::ULong index) const;
    rmsHistoryRecord& operator[] (::CORBA::ULong index);
    const rmsHistoryRecord& operator[] (int index) const;
    rmsHistoryRecord& operator[] (int index);
    const _IDL_SEQ_rmsHistoryRecordSequence_0& in() const;
    _IDL_SEQ_rmsHistoryRecordSequence_0& inout();
    _IDL_SEQ_rmsHistoryRecordSequence_0*& out();
    _IDL_SEQ_rmsHistoryRecordSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsHistoryRecordSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsHistoryRecordSequence_0 _rmsHistoryRecordSequence_seq;
    typedef _IDL_SEQ_rmsHistoryRecordSequence_0 _rmsHistoryRecordSequence_seq_1;
    typedef _IDL_SEQ_rmsHistoryRecordSequence_0 rmsHistoryRecordSequence;
    typedef _IDL_SEQ_rmsHistoryRecordSequence_0_var rmsHistoryRecordSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsHistoryRecordSequence;
    class  rmsGeneralHistoryInqResult_struct_var;
    struct  rmsGeneralHistoryInqResult_struct {
        typedef rmsGeneralHistoryInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsHistoryRecordSequence historyRecords;
       ::CORBA::Boolean overSearchCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsGeneralHistoryInqResult_struct();
       rmsGeneralHistoryInqResult_struct(const rmsGeneralHistoryInqResult_struct&);
       rmsGeneralHistoryInqResult_struct& operator=(const rmsGeneralHistoryInqResult_struct&);
       static CORBA::Info<rmsGeneralHistoryInqResult_struct> rmsGeneralHistoryInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsGeneralHistoryInqResult_struct


typedef rmsGeneralHistoryInqResult_struct* rmsGeneralHistoryInqResult_struct_vPtr;
typedef const rmsGeneralHistoryInqResult_struct* rmsGeneralHistoryInqResult_struct_cvPtr;

class  rmsGeneralHistoryInqResult_struct_var
{
    public:

    rmsGeneralHistoryInqResult_struct_var ();

    rmsGeneralHistoryInqResult_struct_var (rmsGeneralHistoryInqResult_struct *_p);

    rmsGeneralHistoryInqResult_struct_var (const rmsGeneralHistoryInqResult_struct_var &_s);

    rmsGeneralHistoryInqResult_struct_var &operator= (rmsGeneralHistoryInqResult_struct *_p);

    rmsGeneralHistoryInqResult_struct_var &operator= (const rmsGeneralHistoryInqResult_struct_var &_s);

    ~rmsGeneralHistoryInqResult_struct_var ();

    rmsGeneralHistoryInqResult_struct* operator-> ();

    const rmsGeneralHistoryInqResult_struct& in() const;
    rmsGeneralHistoryInqResult_struct& inout();
    rmsGeneralHistoryInqResult_struct*& out();
    rmsGeneralHistoryInqResult_struct* _retn();

    operator rmsGeneralHistoryInqResult_struct_cvPtr () const;

    operator rmsGeneralHistoryInqResult_struct_vPtr& ();

    operator const rmsGeneralHistoryInqResult_struct& () const;

    operator rmsGeneralHistoryInqResult_struct& ();

    protected:
    rmsGeneralHistoryInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsGeneralHistoryInqResult_struct;
    typedef rmsGeneralHistoryInqResult_struct rmsGeneralHistoryInqResult;
    typedef rmsGeneralHistoryInqResult_struct_var rmsGeneralHistoryInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsGeneralHistoryInqResult;
    class  rmsRecipeHistoryInqResult_struct_var;
    struct  rmsRecipeHistoryInqResult_struct {
        typedef rmsRecipeHistoryInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsHistoryRecordSequence historyRecords;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeHistoryInqResult_struct();
       rmsRecipeHistoryInqResult_struct(const rmsRecipeHistoryInqResult_struct&);
       rmsRecipeHistoryInqResult_struct& operator=(const rmsRecipeHistoryInqResult_struct&);
       static CORBA::Info<rmsRecipeHistoryInqResult_struct> rmsRecipeHistoryInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeHistoryInqResult_struct


typedef rmsRecipeHistoryInqResult_struct* rmsRecipeHistoryInqResult_struct_vPtr;
typedef const rmsRecipeHistoryInqResult_struct* rmsRecipeHistoryInqResult_struct_cvPtr;

class  rmsRecipeHistoryInqResult_struct_var
{
    public:

    rmsRecipeHistoryInqResult_struct_var ();

    rmsRecipeHistoryInqResult_struct_var (rmsRecipeHistoryInqResult_struct *_p);

    rmsRecipeHistoryInqResult_struct_var (const rmsRecipeHistoryInqResult_struct_var &_s);

    rmsRecipeHistoryInqResult_struct_var &operator= (rmsRecipeHistoryInqResult_struct *_p);

    rmsRecipeHistoryInqResult_struct_var &operator= (const rmsRecipeHistoryInqResult_struct_var &_s);

    ~rmsRecipeHistoryInqResult_struct_var ();

    rmsRecipeHistoryInqResult_struct* operator-> ();

    const rmsRecipeHistoryInqResult_struct& in() const;
    rmsRecipeHistoryInqResult_struct& inout();
    rmsRecipeHistoryInqResult_struct*& out();
    rmsRecipeHistoryInqResult_struct* _retn();

    operator rmsRecipeHistoryInqResult_struct_cvPtr () const;

    operator rmsRecipeHistoryInqResult_struct_vPtr& ();

    operator const rmsRecipeHistoryInqResult_struct& () const;

    operator rmsRecipeHistoryInqResult_struct& ();

    protected:
    rmsRecipeHistoryInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeHistoryInqResult_struct;
    typedef rmsRecipeHistoryInqResult_struct rmsRecipeHistoryInqResult;
    typedef rmsRecipeHistoryInqResult_struct_var rmsRecipeHistoryInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeHistoryInqResult;
    class  rmsRuleBlockItemInfo_struct_var;
    struct  rmsRuleBlockItemInfo_struct {
        typedef rmsRuleBlockItemInfo_struct_var _var_type;
       ::CORBA::String_StructElem ruleID;
       ::CORBA::Long blockSeqNo;
       ::CORBA::Long itemSeqNo;
       ::CORBA::String_StructElem listPath;
       ::CORBA::Long itemEndLength;
       ::CORBA::String_StructElem itemEndChar;
       ::CORBA::String_StructElem itemType;
       ::CORBA::String_StructElem itemName;
       ::CORBA::Long definedIn;
       ::CORBA::Long repeatByBlockNo;
       ::CORBA::Long repeatByItemNo;
       ::CORBA::Short rangeFlag;
       ::CORBA::Short recipeFlag;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleBlockItemInfo_struct();
       rmsRuleBlockItemInfo_struct(const rmsRuleBlockItemInfo_struct&);
       rmsRuleBlockItemInfo_struct& operator=(const rmsRuleBlockItemInfo_struct&);
       static CORBA::Info<rmsRuleBlockItemInfo_struct> rmsRuleBlockItemInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRuleBlockItemInfo_struct


typedef rmsRuleBlockItemInfo_struct* rmsRuleBlockItemInfo_struct_vPtr;
typedef const rmsRuleBlockItemInfo_struct* rmsRuleBlockItemInfo_struct_cvPtr;

class  rmsRuleBlockItemInfo_struct_var
{
    public:

    rmsRuleBlockItemInfo_struct_var ();

    rmsRuleBlockItemInfo_struct_var (rmsRuleBlockItemInfo_struct *_p);

    rmsRuleBlockItemInfo_struct_var (const rmsRuleBlockItemInfo_struct_var &_s);

    rmsRuleBlockItemInfo_struct_var &operator= (rmsRuleBlockItemInfo_struct *_p);

    rmsRuleBlockItemInfo_struct_var &operator= (const rmsRuleBlockItemInfo_struct_var &_s);

    ~rmsRuleBlockItemInfo_struct_var ();

    rmsRuleBlockItemInfo_struct* operator-> ();

    const rmsRuleBlockItemInfo_struct& in() const;
    rmsRuleBlockItemInfo_struct& inout();
    rmsRuleBlockItemInfo_struct*& out();
    rmsRuleBlockItemInfo_struct* _retn();

    operator rmsRuleBlockItemInfo_struct_cvPtr () const;

    operator rmsRuleBlockItemInfo_struct_vPtr& ();

    operator const rmsRuleBlockItemInfo_struct& () const;

    operator rmsRuleBlockItemInfo_struct& ();

    protected:
    rmsRuleBlockItemInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleBlockItemInfo_struct;
    typedef rmsRuleBlockItemInfo_struct rmsRuleBlockItemInfo;
    typedef rmsRuleBlockItemInfo_struct_var rmsRuleBlockItemInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleBlockItemInfo;
class  _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var;
class  _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRuleBlockItemInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 ();
    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRuleBlockItemInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 (const _IDL_SEQ_rmsRuleBlockItemInfoSeq_0&);

    ~_IDL_SEQ_rmsRuleBlockItemInfoSeq_0 ();

    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0& operator= (const _IDL_SEQ_rmsRuleBlockItemInfoSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRuleBlockItemInfo& operator [] (::CORBA::ULong indx);
    const rmsRuleBlockItemInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRuleBlockItemInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRuleBlockItemInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRuleBlockItemInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRuleBlockItemInfo* src, rmsRuleBlockItemInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRuleBlockItemInfo* data); 
  public:

    static rmsRuleBlockItemInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRuleBlockItemInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRuleBlockItemInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRuleBlockItemInfoSeq_0> rmsRuleBlockItemInfoSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRuleBlockItemInfoSeq_0* _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRuleBlockItemInfoSeq_0* _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_cvPtr;

class  _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var
{
    public:

    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var ();

    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var (_IDL_SEQ_rmsRuleBlockItemInfoSeq_0 *_p);

    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var (const _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var &_s);

    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var &operator= (_IDL_SEQ_rmsRuleBlockItemInfoSeq_0 *_p);

    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var &operator= (const _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var &_s);

    ~_IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var ();

    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRuleBlockItemInfoSeq_0() const;

    const rmsRuleBlockItemInfo& operator[] (::CORBA::ULong index) const;
    rmsRuleBlockItemInfo& operator[] (::CORBA::ULong index);
    const rmsRuleBlockItemInfo& operator[] (int index) const;
    rmsRuleBlockItemInfo& operator[] (int index);
    const _IDL_SEQ_rmsRuleBlockItemInfoSeq_0& in() const;
    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0& inout();
    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0*& out();
    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 _rmsRuleBlockItemInfoSeq_seq;
    typedef _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 _rmsRuleBlockItemInfoSeq_seq_1;
    typedef _IDL_SEQ_rmsRuleBlockItemInfoSeq_0 rmsRuleBlockItemInfoSeq;
    typedef _IDL_SEQ_rmsRuleBlockItemInfoSeq_0_var rmsRuleBlockItemInfoSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleBlockItemInfoSeq;
    class  rmsRuleBlockInfo_struct_var;
    struct  rmsRuleBlockInfo_struct {
        typedef rmsRuleBlockInfo_struct_var _var_type;
       ::CORBA::String_StructElem ruleID;
       ::CORBA::Long blockSeqNo;
       ::CORBA::Long fromCCODE;
       ::CORBA::Long toCCODE;
       ::CORBA::String_StructElem blockName;
       ::rmsRuleBlockItemInfoSeq ruleBlockItemInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleBlockInfo_struct();
       rmsRuleBlockInfo_struct(const rmsRuleBlockInfo_struct&);
       rmsRuleBlockInfo_struct& operator=(const rmsRuleBlockInfo_struct&);
       static CORBA::Info<rmsRuleBlockInfo_struct> rmsRuleBlockInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleBlockInfo_struct


typedef rmsRuleBlockInfo_struct* rmsRuleBlockInfo_struct_vPtr;
typedef const rmsRuleBlockInfo_struct* rmsRuleBlockInfo_struct_cvPtr;

class  rmsRuleBlockInfo_struct_var
{
    public:

    rmsRuleBlockInfo_struct_var ();

    rmsRuleBlockInfo_struct_var (rmsRuleBlockInfo_struct *_p);

    rmsRuleBlockInfo_struct_var (const rmsRuleBlockInfo_struct_var &_s);

    rmsRuleBlockInfo_struct_var &operator= (rmsRuleBlockInfo_struct *_p);

    rmsRuleBlockInfo_struct_var &operator= (const rmsRuleBlockInfo_struct_var &_s);

    ~rmsRuleBlockInfo_struct_var ();

    rmsRuleBlockInfo_struct* operator-> ();

    const rmsRuleBlockInfo_struct& in() const;
    rmsRuleBlockInfo_struct& inout();
    rmsRuleBlockInfo_struct*& out();
    rmsRuleBlockInfo_struct* _retn();

    operator rmsRuleBlockInfo_struct_cvPtr () const;

    operator rmsRuleBlockInfo_struct_vPtr& ();

    operator const rmsRuleBlockInfo_struct& () const;

    operator rmsRuleBlockInfo_struct& ();

    protected:
    rmsRuleBlockInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleBlockInfo_struct;
    typedef rmsRuleBlockInfo_struct rmsRuleBlockInfo;
    typedef rmsRuleBlockInfo_struct_var rmsRuleBlockInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleBlockInfo;
class  _IDL_SEQ_rmsRuleBlockInfoSeq_0_var;
class  _IDL_SEQ_rmsRuleBlockInfoSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRuleBlockInfoSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRuleBlockInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRuleBlockInfoSeq_0 ();
    _IDL_SEQ_rmsRuleBlockInfoSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRuleBlockInfoSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRuleBlockInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRuleBlockInfoSeq_0 (const _IDL_SEQ_rmsRuleBlockInfoSeq_0&);

    ~_IDL_SEQ_rmsRuleBlockInfoSeq_0 ();

    _IDL_SEQ_rmsRuleBlockInfoSeq_0& operator= (const _IDL_SEQ_rmsRuleBlockInfoSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRuleBlockInfo& operator [] (::CORBA::ULong indx);
    const rmsRuleBlockInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRuleBlockInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRuleBlockInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRuleBlockInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRuleBlockInfo* src, rmsRuleBlockInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRuleBlockInfo* data); 
  public:

    static rmsRuleBlockInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRuleBlockInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRuleBlockInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRuleBlockInfoSeq_0> rmsRuleBlockInfoSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRuleBlockInfoSeq_0* _IDL_SEQ_rmsRuleBlockInfoSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRuleBlockInfoSeq_0* _IDL_SEQ_rmsRuleBlockInfoSeq_0_cvPtr;

class  _IDL_SEQ_rmsRuleBlockInfoSeq_0_var
{
    public:

    _IDL_SEQ_rmsRuleBlockInfoSeq_0_var ();

    _IDL_SEQ_rmsRuleBlockInfoSeq_0_var (_IDL_SEQ_rmsRuleBlockInfoSeq_0 *_p);

    _IDL_SEQ_rmsRuleBlockInfoSeq_0_var (const _IDL_SEQ_rmsRuleBlockInfoSeq_0_var &_s);

    _IDL_SEQ_rmsRuleBlockInfoSeq_0_var &operator= (_IDL_SEQ_rmsRuleBlockInfoSeq_0 *_p);

    _IDL_SEQ_rmsRuleBlockInfoSeq_0_var &operator= (const _IDL_SEQ_rmsRuleBlockInfoSeq_0_var &_s);

    ~_IDL_SEQ_rmsRuleBlockInfoSeq_0_var ();

    _IDL_SEQ_rmsRuleBlockInfoSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRuleBlockInfoSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRuleBlockInfoSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRuleBlockInfoSeq_0() const;

    const rmsRuleBlockInfo& operator[] (::CORBA::ULong index) const;
    rmsRuleBlockInfo& operator[] (::CORBA::ULong index);
    const rmsRuleBlockInfo& operator[] (int index) const;
    rmsRuleBlockInfo& operator[] (int index);
    const _IDL_SEQ_rmsRuleBlockInfoSeq_0& in() const;
    _IDL_SEQ_rmsRuleBlockInfoSeq_0& inout();
    _IDL_SEQ_rmsRuleBlockInfoSeq_0*& out();
    _IDL_SEQ_rmsRuleBlockInfoSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRuleBlockInfoSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRuleBlockInfoSeq_0 _rmsRuleBlockInfoSeq_seq;
    typedef _IDL_SEQ_rmsRuleBlockInfoSeq_0 _rmsRuleBlockInfoSeq_seq_1;
    typedef _IDL_SEQ_rmsRuleBlockInfoSeq_0 rmsRuleBlockInfoSeq;
    typedef _IDL_SEQ_rmsRuleBlockInfoSeq_0_var rmsRuleBlockInfoSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleBlockInfoSeq;
    class  rmsRuleInfo_struct_var;
    struct  rmsRuleInfo_struct {
        typedef rmsRuleInfo_struct_var _var_type;
       ::CORBA::String_StructElem ruleID;
       ::CORBA::String_StructElem externalProgram;
       ::CORBA::String_StructElem externalParameter;
       ::CORBA::String_StructElem createTime;
       ::CORBA::String_StructElem lastUpdateTime;
       ::rmsRuleBlockInfoSeq ruleBlockInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleInfo_struct();
       rmsRuleInfo_struct(const rmsRuleInfo_struct&);
       rmsRuleInfo_struct& operator=(const rmsRuleInfo_struct&);
       static CORBA::Info<rmsRuleInfo_struct> rmsRuleInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleInfo_struct


typedef rmsRuleInfo_struct* rmsRuleInfo_struct_vPtr;
typedef const rmsRuleInfo_struct* rmsRuleInfo_struct_cvPtr;

class  rmsRuleInfo_struct_var
{
    public:

    rmsRuleInfo_struct_var ();

    rmsRuleInfo_struct_var (rmsRuleInfo_struct *_p);

    rmsRuleInfo_struct_var (const rmsRuleInfo_struct_var &_s);

    rmsRuleInfo_struct_var &operator= (rmsRuleInfo_struct *_p);

    rmsRuleInfo_struct_var &operator= (const rmsRuleInfo_struct_var &_s);

    ~rmsRuleInfo_struct_var ();

    rmsRuleInfo_struct* operator-> ();

    const rmsRuleInfo_struct& in() const;
    rmsRuleInfo_struct& inout();
    rmsRuleInfo_struct*& out();
    rmsRuleInfo_struct* _retn();

    operator rmsRuleInfo_struct_cvPtr () const;

    operator rmsRuleInfo_struct_vPtr& ();

    operator const rmsRuleInfo_struct& () const;

    operator rmsRuleInfo_struct& ();

    protected:
    rmsRuleInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleInfo_struct;
    typedef rmsRuleInfo_struct rmsRuleInfo;
    typedef rmsRuleInfo_struct_var rmsRuleInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleInfo;
    class  rmsRuleRelationInfo_struct_var;
    struct  rmsRuleRelationInfo_struct {
        typedef rmsRuleRelationInfo_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::CORBA::String_StructElem eqpSpecial;
       ::CORBA::String_StructElem ruleID;
       ::CORBA::Long recipeLevel;
       ::CORBA::Long recipeDependence;
       ::CORBA::String_StructElem recipeIDPattern;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleRelationInfo_struct();
       rmsRuleRelationInfo_struct(const rmsRuleRelationInfo_struct&);
       rmsRuleRelationInfo_struct& operator=(const rmsRuleRelationInfo_struct&);
       static CORBA::Info<rmsRuleRelationInfo_struct> rmsRuleRelationInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleRelationInfo_struct


typedef rmsRuleRelationInfo_struct* rmsRuleRelationInfo_struct_vPtr;
typedef const rmsRuleRelationInfo_struct* rmsRuleRelationInfo_struct_cvPtr;

class  rmsRuleRelationInfo_struct_var
{
    public:

    rmsRuleRelationInfo_struct_var ();

    rmsRuleRelationInfo_struct_var (rmsRuleRelationInfo_struct *_p);

    rmsRuleRelationInfo_struct_var (const rmsRuleRelationInfo_struct_var &_s);

    rmsRuleRelationInfo_struct_var &operator= (rmsRuleRelationInfo_struct *_p);

    rmsRuleRelationInfo_struct_var &operator= (const rmsRuleRelationInfo_struct_var &_s);

    ~rmsRuleRelationInfo_struct_var ();

    rmsRuleRelationInfo_struct* operator-> ();

    const rmsRuleRelationInfo_struct& in() const;
    rmsRuleRelationInfo_struct& inout();
    rmsRuleRelationInfo_struct*& out();
    rmsRuleRelationInfo_struct* _retn();

    operator rmsRuleRelationInfo_struct_cvPtr () const;

    operator rmsRuleRelationInfo_struct_vPtr& ();

    operator const rmsRuleRelationInfo_struct& () const;

    operator rmsRuleRelationInfo_struct& ();

    protected:
    rmsRuleRelationInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationInfo_struct;
    typedef rmsRuleRelationInfo_struct rmsRuleRelationInfo;
    typedef rmsRuleRelationInfo_struct_var rmsRuleRelationInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationInfo;
class  _IDL_SEQ_rmsRuleRelationInfoSeq_0_var;
class  _IDL_SEQ_rmsRuleRelationInfoSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRuleRelationInfoSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRuleRelationInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRuleRelationInfoSeq_0 ();
    _IDL_SEQ_rmsRuleRelationInfoSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRuleRelationInfoSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRuleRelationInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRuleRelationInfoSeq_0 (const _IDL_SEQ_rmsRuleRelationInfoSeq_0&);

    ~_IDL_SEQ_rmsRuleRelationInfoSeq_0 ();

    _IDL_SEQ_rmsRuleRelationInfoSeq_0& operator= (const _IDL_SEQ_rmsRuleRelationInfoSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRuleRelationInfo& operator [] (::CORBA::ULong indx);
    const rmsRuleRelationInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRuleRelationInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRuleRelationInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRuleRelationInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRuleRelationInfo* src, rmsRuleRelationInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRuleRelationInfo* data); 
  public:

    static rmsRuleRelationInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRuleRelationInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRuleRelationInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRuleRelationInfoSeq_0> rmsRuleRelationInfoSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRuleRelationInfoSeq_0* _IDL_SEQ_rmsRuleRelationInfoSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRuleRelationInfoSeq_0* _IDL_SEQ_rmsRuleRelationInfoSeq_0_cvPtr;

class  _IDL_SEQ_rmsRuleRelationInfoSeq_0_var
{
    public:

    _IDL_SEQ_rmsRuleRelationInfoSeq_0_var ();

    _IDL_SEQ_rmsRuleRelationInfoSeq_0_var (_IDL_SEQ_rmsRuleRelationInfoSeq_0 *_p);

    _IDL_SEQ_rmsRuleRelationInfoSeq_0_var (const _IDL_SEQ_rmsRuleRelationInfoSeq_0_var &_s);

    _IDL_SEQ_rmsRuleRelationInfoSeq_0_var &operator= (_IDL_SEQ_rmsRuleRelationInfoSeq_0 *_p);

    _IDL_SEQ_rmsRuleRelationInfoSeq_0_var &operator= (const _IDL_SEQ_rmsRuleRelationInfoSeq_0_var &_s);

    ~_IDL_SEQ_rmsRuleRelationInfoSeq_0_var ();

    _IDL_SEQ_rmsRuleRelationInfoSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRuleRelationInfoSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRuleRelationInfoSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRuleRelationInfoSeq_0() const;

    const rmsRuleRelationInfo& operator[] (::CORBA::ULong index) const;
    rmsRuleRelationInfo& operator[] (::CORBA::ULong index);
    const rmsRuleRelationInfo& operator[] (int index) const;
    rmsRuleRelationInfo& operator[] (int index);
    const _IDL_SEQ_rmsRuleRelationInfoSeq_0& in() const;
    _IDL_SEQ_rmsRuleRelationInfoSeq_0& inout();
    _IDL_SEQ_rmsRuleRelationInfoSeq_0*& out();
    _IDL_SEQ_rmsRuleRelationInfoSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRuleRelationInfoSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRuleRelationInfoSeq_0 _rmsRuleRelationInfoSeq_seq;
    typedef _IDL_SEQ_rmsRuleRelationInfoSeq_0 _rmsRuleRelationInfoSeq_seq_1;
    typedef _IDL_SEQ_rmsRuleRelationInfoSeq_0 rmsRuleRelationInfoSeq;
    typedef _IDL_SEQ_rmsRuleRelationInfoSeq_0_var rmsRuleRelationInfoSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationInfoSeq;
    class  rmsRuleRelationSetReqResult_struct_var;
    struct  rmsRuleRelationSetReqResult_struct {
        typedef rmsRuleRelationSetReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleRelationSetReqResult_struct();
       rmsRuleRelationSetReqResult_struct(const rmsRuleRelationSetReqResult_struct&);
       rmsRuleRelationSetReqResult_struct& operator=(const rmsRuleRelationSetReqResult_struct&);
       static CORBA::Info<rmsRuleRelationSetReqResult_struct> rmsRuleRelationSetReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleRelationSetReqResult_struct


typedef rmsRuleRelationSetReqResult_struct* rmsRuleRelationSetReqResult_struct_vPtr;
typedef const rmsRuleRelationSetReqResult_struct* rmsRuleRelationSetReqResult_struct_cvPtr;

class  rmsRuleRelationSetReqResult_struct_var
{
    public:

    rmsRuleRelationSetReqResult_struct_var ();

    rmsRuleRelationSetReqResult_struct_var (rmsRuleRelationSetReqResult_struct *_p);

    rmsRuleRelationSetReqResult_struct_var (const rmsRuleRelationSetReqResult_struct_var &_s);

    rmsRuleRelationSetReqResult_struct_var &operator= (rmsRuleRelationSetReqResult_struct *_p);

    rmsRuleRelationSetReqResult_struct_var &operator= (const rmsRuleRelationSetReqResult_struct_var &_s);

    ~rmsRuleRelationSetReqResult_struct_var ();

    rmsRuleRelationSetReqResult_struct* operator-> ();

    const rmsRuleRelationSetReqResult_struct& in() const;
    rmsRuleRelationSetReqResult_struct& inout();
    rmsRuleRelationSetReqResult_struct*& out();
    rmsRuleRelationSetReqResult_struct* _retn();

    operator rmsRuleRelationSetReqResult_struct_cvPtr () const;

    operator rmsRuleRelationSetReqResult_struct_vPtr& ();

    operator const rmsRuleRelationSetReqResult_struct& () const;

    operator rmsRuleRelationSetReqResult_struct& ();

    protected:
    rmsRuleRelationSetReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationSetReqResult_struct;
    typedef rmsRuleRelationSetReqResult_struct rmsRuleRelationSetReqResult;
    typedef rmsRuleRelationSetReqResult_struct_var rmsRuleRelationSetReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationSetReqResult;
    class  rmsRuleRelationListResult_struct_var;
    struct  rmsRuleRelationListResult_struct {
        typedef rmsRuleRelationListResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRuleRelationInfoSeq strRuleRelationInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleRelationListResult_struct();
       rmsRuleRelationListResult_struct(const rmsRuleRelationListResult_struct&);
       rmsRuleRelationListResult_struct& operator=(const rmsRuleRelationListResult_struct&);
       static CORBA::Info<rmsRuleRelationListResult_struct> rmsRuleRelationListResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleRelationListResult_struct


typedef rmsRuleRelationListResult_struct* rmsRuleRelationListResult_struct_vPtr;
typedef const rmsRuleRelationListResult_struct* rmsRuleRelationListResult_struct_cvPtr;

class  rmsRuleRelationListResult_struct_var
{
    public:

    rmsRuleRelationListResult_struct_var ();

    rmsRuleRelationListResult_struct_var (rmsRuleRelationListResult_struct *_p);

    rmsRuleRelationListResult_struct_var (const rmsRuleRelationListResult_struct_var &_s);

    rmsRuleRelationListResult_struct_var &operator= (rmsRuleRelationListResult_struct *_p);

    rmsRuleRelationListResult_struct_var &operator= (const rmsRuleRelationListResult_struct_var &_s);

    ~rmsRuleRelationListResult_struct_var ();

    rmsRuleRelationListResult_struct* operator-> ();

    const rmsRuleRelationListResult_struct& in() const;
    rmsRuleRelationListResult_struct& inout();
    rmsRuleRelationListResult_struct*& out();
    rmsRuleRelationListResult_struct* _retn();

    operator rmsRuleRelationListResult_struct_cvPtr () const;

    operator rmsRuleRelationListResult_struct_vPtr& ();

    operator const rmsRuleRelationListResult_struct& () const;

    operator rmsRuleRelationListResult_struct& ();

    protected:
    rmsRuleRelationListResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationListResult_struct;
    typedef rmsRuleRelationListResult_struct rmsRuleRelationListResult;
    typedef rmsRuleRelationListResult_struct_var rmsRuleRelationListResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationListResult;
    class  rmsRuleDefinitionSetReqResult_struct_var;
    struct  rmsRuleDefinitionSetReqResult_struct {
        typedef rmsRuleDefinitionSetReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleDefinitionSetReqResult_struct();
       rmsRuleDefinitionSetReqResult_struct(const rmsRuleDefinitionSetReqResult_struct&);
       rmsRuleDefinitionSetReqResult_struct& operator=(const rmsRuleDefinitionSetReqResult_struct&);
       static CORBA::Info<rmsRuleDefinitionSetReqResult_struct> rmsRuleDefinitionSetReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleDefinitionSetReqResult_struct


typedef rmsRuleDefinitionSetReqResult_struct* rmsRuleDefinitionSetReqResult_struct_vPtr;
typedef const rmsRuleDefinitionSetReqResult_struct* rmsRuleDefinitionSetReqResult_struct_cvPtr;

class  rmsRuleDefinitionSetReqResult_struct_var
{
    public:

    rmsRuleDefinitionSetReqResult_struct_var ();

    rmsRuleDefinitionSetReqResult_struct_var (rmsRuleDefinitionSetReqResult_struct *_p);

    rmsRuleDefinitionSetReqResult_struct_var (const rmsRuleDefinitionSetReqResult_struct_var &_s);

    rmsRuleDefinitionSetReqResult_struct_var &operator= (rmsRuleDefinitionSetReqResult_struct *_p);

    rmsRuleDefinitionSetReqResult_struct_var &operator= (const rmsRuleDefinitionSetReqResult_struct_var &_s);

    ~rmsRuleDefinitionSetReqResult_struct_var ();

    rmsRuleDefinitionSetReqResult_struct* operator-> ();

    const rmsRuleDefinitionSetReqResult_struct& in() const;
    rmsRuleDefinitionSetReqResult_struct& inout();
    rmsRuleDefinitionSetReqResult_struct*& out();
    rmsRuleDefinitionSetReqResult_struct* _retn();

    operator rmsRuleDefinitionSetReqResult_struct_cvPtr () const;

    operator rmsRuleDefinitionSetReqResult_struct_vPtr& ();

    operator const rmsRuleDefinitionSetReqResult_struct& () const;

    operator rmsRuleDefinitionSetReqResult_struct& ();

    protected:
    rmsRuleDefinitionSetReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionSetReqResult_struct;
    typedef rmsRuleDefinitionSetReqResult_struct rmsRuleDefinitionSetReqResult;
    typedef rmsRuleDefinitionSetReqResult_struct_var rmsRuleDefinitionSetReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionSetReqResult;
    class  rmsRuleDefinitionCheckOutReqResult_struct_var;
    struct  rmsRuleDefinitionCheckOutReqResult_struct {
        typedef rmsRuleDefinitionCheckOutReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleDefinitionCheckOutReqResult_struct();
       rmsRuleDefinitionCheckOutReqResult_struct(const rmsRuleDefinitionCheckOutReqResult_struct&);
       rmsRuleDefinitionCheckOutReqResult_struct& operator=(const rmsRuleDefinitionCheckOutReqResult_struct&);
       static CORBA::Info<rmsRuleDefinitionCheckOutReqResult_struct> rmsRuleDefinitionCheckOutReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleDefinitionCheckOutReqResult_struct


typedef rmsRuleDefinitionCheckOutReqResult_struct* rmsRuleDefinitionCheckOutReqResult_struct_vPtr;
typedef const rmsRuleDefinitionCheckOutReqResult_struct* rmsRuleDefinitionCheckOutReqResult_struct_cvPtr;

class  rmsRuleDefinitionCheckOutReqResult_struct_var
{
    public:

    rmsRuleDefinitionCheckOutReqResult_struct_var ();

    rmsRuleDefinitionCheckOutReqResult_struct_var (rmsRuleDefinitionCheckOutReqResult_struct *_p);

    rmsRuleDefinitionCheckOutReqResult_struct_var (const rmsRuleDefinitionCheckOutReqResult_struct_var &_s);

    rmsRuleDefinitionCheckOutReqResult_struct_var &operator= (rmsRuleDefinitionCheckOutReqResult_struct *_p);

    rmsRuleDefinitionCheckOutReqResult_struct_var &operator= (const rmsRuleDefinitionCheckOutReqResult_struct_var &_s);

    ~rmsRuleDefinitionCheckOutReqResult_struct_var ();

    rmsRuleDefinitionCheckOutReqResult_struct* operator-> ();

    const rmsRuleDefinitionCheckOutReqResult_struct& in() const;
    rmsRuleDefinitionCheckOutReqResult_struct& inout();
    rmsRuleDefinitionCheckOutReqResult_struct*& out();
    rmsRuleDefinitionCheckOutReqResult_struct* _retn();

    operator rmsRuleDefinitionCheckOutReqResult_struct_cvPtr () const;

    operator rmsRuleDefinitionCheckOutReqResult_struct_vPtr& ();

    operator const rmsRuleDefinitionCheckOutReqResult_struct& () const;

    operator rmsRuleDefinitionCheckOutReqResult_struct& ();

    protected:
    rmsRuleDefinitionCheckOutReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionCheckOutReqResult_struct;
    typedef rmsRuleDefinitionCheckOutReqResult_struct rmsRuleDefinitionCheckOutReqResult;
    typedef rmsRuleDefinitionCheckOutReqResult_struct_var rmsRuleDefinitionCheckOutReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionCheckOutReqResult;
    class  rmsRuleDefinitionCheckInReqResult_struct_var;
    struct  rmsRuleDefinitionCheckInReqResult_struct {
        typedef rmsRuleDefinitionCheckInReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleDefinitionCheckInReqResult_struct();
       rmsRuleDefinitionCheckInReqResult_struct(const rmsRuleDefinitionCheckInReqResult_struct&);
       rmsRuleDefinitionCheckInReqResult_struct& operator=(const rmsRuleDefinitionCheckInReqResult_struct&);
       static CORBA::Info<rmsRuleDefinitionCheckInReqResult_struct> rmsRuleDefinitionCheckInReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleDefinitionCheckInReqResult_struct


typedef rmsRuleDefinitionCheckInReqResult_struct* rmsRuleDefinitionCheckInReqResult_struct_vPtr;
typedef const rmsRuleDefinitionCheckInReqResult_struct* rmsRuleDefinitionCheckInReqResult_struct_cvPtr;

class  rmsRuleDefinitionCheckInReqResult_struct_var
{
    public:

    rmsRuleDefinitionCheckInReqResult_struct_var ();

    rmsRuleDefinitionCheckInReqResult_struct_var (rmsRuleDefinitionCheckInReqResult_struct *_p);

    rmsRuleDefinitionCheckInReqResult_struct_var (const rmsRuleDefinitionCheckInReqResult_struct_var &_s);

    rmsRuleDefinitionCheckInReqResult_struct_var &operator= (rmsRuleDefinitionCheckInReqResult_struct *_p);

    rmsRuleDefinitionCheckInReqResult_struct_var &operator= (const rmsRuleDefinitionCheckInReqResult_struct_var &_s);

    ~rmsRuleDefinitionCheckInReqResult_struct_var ();

    rmsRuleDefinitionCheckInReqResult_struct* operator-> ();

    const rmsRuleDefinitionCheckInReqResult_struct& in() const;
    rmsRuleDefinitionCheckInReqResult_struct& inout();
    rmsRuleDefinitionCheckInReqResult_struct*& out();
    rmsRuleDefinitionCheckInReqResult_struct* _retn();

    operator rmsRuleDefinitionCheckInReqResult_struct_cvPtr () const;

    operator rmsRuleDefinitionCheckInReqResult_struct_vPtr& ();

    operator const rmsRuleDefinitionCheckInReqResult_struct& () const;

    operator rmsRuleDefinitionCheckInReqResult_struct& ();

    protected:
    rmsRuleDefinitionCheckInReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionCheckInReqResult_struct;
    typedef rmsRuleDefinitionCheckInReqResult_struct rmsRuleDefinitionCheckInReqResult;
    typedef rmsRuleDefinitionCheckInReqResult_struct_var rmsRuleDefinitionCheckInReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionCheckInReqResult;
    class  rmsRuleDefinitionListInqResult_struct_var;
    struct  rmsRuleDefinitionListInqResult_struct {
        typedef rmsRuleDefinitionListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifierSequence ruleIDs;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleDefinitionListInqResult_struct();
       rmsRuleDefinitionListInqResult_struct(const rmsRuleDefinitionListInqResult_struct&);
       rmsRuleDefinitionListInqResult_struct& operator=(const rmsRuleDefinitionListInqResult_struct&);
       static CORBA::Info<rmsRuleDefinitionListInqResult_struct> rmsRuleDefinitionListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleDefinitionListInqResult_struct


typedef rmsRuleDefinitionListInqResult_struct* rmsRuleDefinitionListInqResult_struct_vPtr;
typedef const rmsRuleDefinitionListInqResult_struct* rmsRuleDefinitionListInqResult_struct_cvPtr;

class  rmsRuleDefinitionListInqResult_struct_var
{
    public:

    rmsRuleDefinitionListInqResult_struct_var ();

    rmsRuleDefinitionListInqResult_struct_var (rmsRuleDefinitionListInqResult_struct *_p);

    rmsRuleDefinitionListInqResult_struct_var (const rmsRuleDefinitionListInqResult_struct_var &_s);

    rmsRuleDefinitionListInqResult_struct_var &operator= (rmsRuleDefinitionListInqResult_struct *_p);

    rmsRuleDefinitionListInqResult_struct_var &operator= (const rmsRuleDefinitionListInqResult_struct_var &_s);

    ~rmsRuleDefinitionListInqResult_struct_var ();

    rmsRuleDefinitionListInqResult_struct* operator-> ();

    const rmsRuleDefinitionListInqResult_struct& in() const;
    rmsRuleDefinitionListInqResult_struct& inout();
    rmsRuleDefinitionListInqResult_struct*& out();
    rmsRuleDefinitionListInqResult_struct* _retn();

    operator rmsRuleDefinitionListInqResult_struct_cvPtr () const;

    operator rmsRuleDefinitionListInqResult_struct_vPtr& ();

    operator const rmsRuleDefinitionListInqResult_struct& () const;

    operator rmsRuleDefinitionListInqResult_struct& ();

    protected:
    rmsRuleDefinitionListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionListInqResult_struct;
    typedef rmsRuleDefinitionListInqResult_struct rmsRuleDefinitionListInqResult;
    typedef rmsRuleDefinitionListInqResult_struct_var rmsRuleDefinitionListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionListInqResult;
    class  rmsRuleDefinitionInfoInqResult_struct_var;
    struct  rmsRuleDefinitionInfoInqResult_struct {
        typedef rmsRuleDefinitionInfoInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRuleInfo strRuleInfo;
       ::CORBA::String_StructElem checkOutUser;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleDefinitionInfoInqResult_struct();
       rmsRuleDefinitionInfoInqResult_struct(const rmsRuleDefinitionInfoInqResult_struct&);
       rmsRuleDefinitionInfoInqResult_struct& operator=(const rmsRuleDefinitionInfoInqResult_struct&);
       static CORBA::Info<rmsRuleDefinitionInfoInqResult_struct> rmsRuleDefinitionInfoInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleDefinitionInfoInqResult_struct


typedef rmsRuleDefinitionInfoInqResult_struct* rmsRuleDefinitionInfoInqResult_struct_vPtr;
typedef const rmsRuleDefinitionInfoInqResult_struct* rmsRuleDefinitionInfoInqResult_struct_cvPtr;

class  rmsRuleDefinitionInfoInqResult_struct_var
{
    public:

    rmsRuleDefinitionInfoInqResult_struct_var ();

    rmsRuleDefinitionInfoInqResult_struct_var (rmsRuleDefinitionInfoInqResult_struct *_p);

    rmsRuleDefinitionInfoInqResult_struct_var (const rmsRuleDefinitionInfoInqResult_struct_var &_s);

    rmsRuleDefinitionInfoInqResult_struct_var &operator= (rmsRuleDefinitionInfoInqResult_struct *_p);

    rmsRuleDefinitionInfoInqResult_struct_var &operator= (const rmsRuleDefinitionInfoInqResult_struct_var &_s);

    ~rmsRuleDefinitionInfoInqResult_struct_var ();

    rmsRuleDefinitionInfoInqResult_struct* operator-> ();

    const rmsRuleDefinitionInfoInqResult_struct& in() const;
    rmsRuleDefinitionInfoInqResult_struct& inout();
    rmsRuleDefinitionInfoInqResult_struct*& out();
    rmsRuleDefinitionInfoInqResult_struct* _retn();

    operator rmsRuleDefinitionInfoInqResult_struct_cvPtr () const;

    operator rmsRuleDefinitionInfoInqResult_struct_vPtr& ();

    operator const rmsRuleDefinitionInfoInqResult_struct& () const;

    operator rmsRuleDefinitionInfoInqResult_struct& ();

    protected:
    rmsRuleDefinitionInfoInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionInfoInqResult_struct;
    typedef rmsRuleDefinitionInfoInqResult_struct rmsRuleDefinitionInfoInqResult;
    typedef rmsRuleDefinitionInfoInqResult_struct_var rmsRuleDefinitionInfoInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionInfoInqResult;
    class  rmsRecipeDeleteReqResult_struct_var;
    struct  rmsRecipeDeleteReqResult_struct {
        typedef rmsRecipeDeleteReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeDeleteReqResult_struct();
       rmsRecipeDeleteReqResult_struct(const rmsRecipeDeleteReqResult_struct&);
       rmsRecipeDeleteReqResult_struct& operator=(const rmsRecipeDeleteReqResult_struct&);
       static CORBA::Info<rmsRecipeDeleteReqResult_struct> rmsRecipeDeleteReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeDeleteReqResult_struct


typedef rmsRecipeDeleteReqResult_struct* rmsRecipeDeleteReqResult_struct_vPtr;
typedef const rmsRecipeDeleteReqResult_struct* rmsRecipeDeleteReqResult_struct_cvPtr;

class  rmsRecipeDeleteReqResult_struct_var
{
    public:

    rmsRecipeDeleteReqResult_struct_var ();

    rmsRecipeDeleteReqResult_struct_var (rmsRecipeDeleteReqResult_struct *_p);

    rmsRecipeDeleteReqResult_struct_var (const rmsRecipeDeleteReqResult_struct_var &_s);

    rmsRecipeDeleteReqResult_struct_var &operator= (rmsRecipeDeleteReqResult_struct *_p);

    rmsRecipeDeleteReqResult_struct_var &operator= (const rmsRecipeDeleteReqResult_struct_var &_s);

    ~rmsRecipeDeleteReqResult_struct_var ();

    rmsRecipeDeleteReqResult_struct* operator-> ();

    const rmsRecipeDeleteReqResult_struct& in() const;
    rmsRecipeDeleteReqResult_struct& inout();
    rmsRecipeDeleteReqResult_struct*& out();
    rmsRecipeDeleteReqResult_struct* _retn();

    operator rmsRecipeDeleteReqResult_struct_cvPtr () const;

    operator rmsRecipeDeleteReqResult_struct_vPtr& ();

    operator const rmsRecipeDeleteReqResult_struct& () const;

    operator rmsRecipeDeleteReqResult_struct& ();

    protected:
    rmsRecipeDeleteReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeDeleteReqResult_struct;
    typedef rmsRecipeDeleteReqResult_struct rmsRecipeDeleteReqResult;
    typedef rmsRecipeDeleteReqResult_struct_var rmsRecipeDeleteReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeDeleteReqResult;
    class  rmsRuleRelationDeleteReqResult_struct_var;
    struct  rmsRuleRelationDeleteReqResult_struct {
        typedef rmsRuleRelationDeleteReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleRelationDeleteReqResult_struct();
       rmsRuleRelationDeleteReqResult_struct(const rmsRuleRelationDeleteReqResult_struct&);
       rmsRuleRelationDeleteReqResult_struct& operator=(const rmsRuleRelationDeleteReqResult_struct&);
       static CORBA::Info<rmsRuleRelationDeleteReqResult_struct> rmsRuleRelationDeleteReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleRelationDeleteReqResult_struct


typedef rmsRuleRelationDeleteReqResult_struct* rmsRuleRelationDeleteReqResult_struct_vPtr;
typedef const rmsRuleRelationDeleteReqResult_struct* rmsRuleRelationDeleteReqResult_struct_cvPtr;

class  rmsRuleRelationDeleteReqResult_struct_var
{
    public:

    rmsRuleRelationDeleteReqResult_struct_var ();

    rmsRuleRelationDeleteReqResult_struct_var (rmsRuleRelationDeleteReqResult_struct *_p);

    rmsRuleRelationDeleteReqResult_struct_var (const rmsRuleRelationDeleteReqResult_struct_var &_s);

    rmsRuleRelationDeleteReqResult_struct_var &operator= (rmsRuleRelationDeleteReqResult_struct *_p);

    rmsRuleRelationDeleteReqResult_struct_var &operator= (const rmsRuleRelationDeleteReqResult_struct_var &_s);

    ~rmsRuleRelationDeleteReqResult_struct_var ();

    rmsRuleRelationDeleteReqResult_struct* operator-> ();

    const rmsRuleRelationDeleteReqResult_struct& in() const;
    rmsRuleRelationDeleteReqResult_struct& inout();
    rmsRuleRelationDeleteReqResult_struct*& out();
    rmsRuleRelationDeleteReqResult_struct* _retn();

    operator rmsRuleRelationDeleteReqResult_struct_cvPtr () const;

    operator rmsRuleRelationDeleteReqResult_struct_vPtr& ();

    operator const rmsRuleRelationDeleteReqResult_struct& () const;

    operator rmsRuleRelationDeleteReqResult_struct& ();

    protected:
    rmsRuleRelationDeleteReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationDeleteReqResult_struct;
    typedef rmsRuleRelationDeleteReqResult_struct rmsRuleRelationDeleteReqResult;
    typedef rmsRuleRelationDeleteReqResult_struct_var rmsRuleRelationDeleteReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleRelationDeleteReqResult;
    class  rmsRuleDefinitionDeleteReqResult_struct_var;
    struct  rmsRuleDefinitionDeleteReqResult_struct {
        typedef rmsRuleDefinitionDeleteReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRuleDefinitionDeleteReqResult_struct();
       rmsRuleDefinitionDeleteReqResult_struct(const rmsRuleDefinitionDeleteReqResult_struct&);
       rmsRuleDefinitionDeleteReqResult_struct& operator=(const rmsRuleDefinitionDeleteReqResult_struct&);
       static CORBA::Info<rmsRuleDefinitionDeleteReqResult_struct> rmsRuleDefinitionDeleteReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRuleDefinitionDeleteReqResult_struct


typedef rmsRuleDefinitionDeleteReqResult_struct* rmsRuleDefinitionDeleteReqResult_struct_vPtr;
typedef const rmsRuleDefinitionDeleteReqResult_struct* rmsRuleDefinitionDeleteReqResult_struct_cvPtr;

class  rmsRuleDefinitionDeleteReqResult_struct_var
{
    public:

    rmsRuleDefinitionDeleteReqResult_struct_var ();

    rmsRuleDefinitionDeleteReqResult_struct_var (rmsRuleDefinitionDeleteReqResult_struct *_p);

    rmsRuleDefinitionDeleteReqResult_struct_var (const rmsRuleDefinitionDeleteReqResult_struct_var &_s);

    rmsRuleDefinitionDeleteReqResult_struct_var &operator= (rmsRuleDefinitionDeleteReqResult_struct *_p);

    rmsRuleDefinitionDeleteReqResult_struct_var &operator= (const rmsRuleDefinitionDeleteReqResult_struct_var &_s);

    ~rmsRuleDefinitionDeleteReqResult_struct_var ();

    rmsRuleDefinitionDeleteReqResult_struct* operator-> ();

    const rmsRuleDefinitionDeleteReqResult_struct& in() const;
    rmsRuleDefinitionDeleteReqResult_struct& inout();
    rmsRuleDefinitionDeleteReqResult_struct*& out();
    rmsRuleDefinitionDeleteReqResult_struct* _retn();

    operator rmsRuleDefinitionDeleteReqResult_struct_cvPtr () const;

    operator rmsRuleDefinitionDeleteReqResult_struct_vPtr& ();

    operator const rmsRuleDefinitionDeleteReqResult_struct& () const;

    operator rmsRuleDefinitionDeleteReqResult_struct& ();

    protected:
    rmsRuleDefinitionDeleteReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionDeleteReqResult_struct;
    typedef rmsRuleDefinitionDeleteReqResult_struct rmsRuleDefinitionDeleteReqResult;
    typedef rmsRuleDefinitionDeleteReqResult_struct_var rmsRuleDefinitionDeleteReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRuleDefinitionDeleteReqResult;
    class  rmsRecipeInfo_struct_var;
    struct  rmsRecipeInfo_struct {
        typedef rmsRecipeInfo_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem physicalRecipeID;
       ::CORBA::String_StructElem subEquipmentID;
       ::CORBA::Long recipeLevel;
       ::CORBA::String_StructElem chamberID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeInfo_struct();
       rmsRecipeInfo_struct(const rmsRecipeInfo_struct&);
       rmsRecipeInfo_struct& operator=(const rmsRecipeInfo_struct&);
       static CORBA::Info<rmsRecipeInfo_struct> rmsRecipeInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRecipeInfo_struct


typedef rmsRecipeInfo_struct* rmsRecipeInfo_struct_vPtr;
typedef const rmsRecipeInfo_struct* rmsRecipeInfo_struct_cvPtr;

class  rmsRecipeInfo_struct_var
{
    public:

    rmsRecipeInfo_struct_var ();

    rmsRecipeInfo_struct_var (rmsRecipeInfo_struct *_p);

    rmsRecipeInfo_struct_var (const rmsRecipeInfo_struct_var &_s);

    rmsRecipeInfo_struct_var &operator= (rmsRecipeInfo_struct *_p);

    rmsRecipeInfo_struct_var &operator= (const rmsRecipeInfo_struct_var &_s);

    ~rmsRecipeInfo_struct_var ();

    rmsRecipeInfo_struct* operator-> ();

    const rmsRecipeInfo_struct& in() const;
    rmsRecipeInfo_struct& inout();
    rmsRecipeInfo_struct*& out();
    rmsRecipeInfo_struct* _retn();

    operator rmsRecipeInfo_struct_cvPtr () const;

    operator rmsRecipeInfo_struct_vPtr& ();

    operator const rmsRecipeInfo_struct& () const;

    operator rmsRecipeInfo_struct& ();

    protected:
    rmsRecipeInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeInfo_struct;
    typedef rmsRecipeInfo_struct rmsRecipeInfo;
    typedef rmsRecipeInfo_struct_var rmsRecipeInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeInfo;
class  _IDL_SEQ_rmsRecipeInfoSequence_0_var;
class  _IDL_SEQ_rmsRecipeInfoSequence_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeInfoSequence_0 ();
    _IDL_SEQ_rmsRecipeInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeInfoSequence_0 (const _IDL_SEQ_rmsRecipeInfoSequence_0&);

    ~_IDL_SEQ_rmsRecipeInfoSequence_0 ();

    _IDL_SEQ_rmsRecipeInfoSequence_0& operator= (const _IDL_SEQ_rmsRecipeInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeInfo& operator [] (::CORBA::ULong indx);
    const rmsRecipeInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeInfo* src, rmsRecipeInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeInfo* data); 
  public:

    static rmsRecipeInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeInfoSequence_0> rmsRecipeInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeInfoSequence_0* _IDL_SEQ_rmsRecipeInfoSequence_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeInfoSequence_0* _IDL_SEQ_rmsRecipeInfoSequence_0_cvPtr;

class  _IDL_SEQ_rmsRecipeInfoSequence_0_var
{
    public:

    _IDL_SEQ_rmsRecipeInfoSequence_0_var ();

    _IDL_SEQ_rmsRecipeInfoSequence_0_var (_IDL_SEQ_rmsRecipeInfoSequence_0 *_p);

    _IDL_SEQ_rmsRecipeInfoSequence_0_var (const _IDL_SEQ_rmsRecipeInfoSequence_0_var &_s);

    _IDL_SEQ_rmsRecipeInfoSequence_0_var &operator= (_IDL_SEQ_rmsRecipeInfoSequence_0 *_p);

    _IDL_SEQ_rmsRecipeInfoSequence_0_var &operator= (const _IDL_SEQ_rmsRecipeInfoSequence_0_var &_s);

    ~_IDL_SEQ_rmsRecipeInfoSequence_0_var ();

    _IDL_SEQ_rmsRecipeInfoSequence_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeInfoSequence_0() const;

    const rmsRecipeInfo& operator[] (::CORBA::ULong index) const;
    rmsRecipeInfo& operator[] (::CORBA::ULong index);
    const rmsRecipeInfo& operator[] (int index) const;
    rmsRecipeInfo& operator[] (int index);
    const _IDL_SEQ_rmsRecipeInfoSequence_0& in() const;
    _IDL_SEQ_rmsRecipeInfoSequence_0& inout();
    _IDL_SEQ_rmsRecipeInfoSequence_0*& out();
    _IDL_SEQ_rmsRecipeInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeInfoSequence_0 _rmsRecipeInfoSequence_seq;
    typedef _IDL_SEQ_rmsRecipeInfoSequence_0 _rmsRecipeInfoSequence_seq_1;
    typedef _IDL_SEQ_rmsRecipeInfoSequence_0 rmsRecipeInfoSequence;
    typedef _IDL_SEQ_rmsRecipeInfoSequence_0_var rmsRecipeInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeInfoSequence;
    class  rmsRecipeDeleteCheckInqResult_struct_var;
    struct  rmsRecipeDeleteCheckInqResult_struct {
        typedef rmsRecipeDeleteCheckInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeInfoSequence strRecipeInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeDeleteCheckInqResult_struct();
       rmsRecipeDeleteCheckInqResult_struct(const rmsRecipeDeleteCheckInqResult_struct&);
       rmsRecipeDeleteCheckInqResult_struct& operator=(const rmsRecipeDeleteCheckInqResult_struct&);
       static CORBA::Info<rmsRecipeDeleteCheckInqResult_struct> rmsRecipeDeleteCheckInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeDeleteCheckInqResult_struct


typedef rmsRecipeDeleteCheckInqResult_struct* rmsRecipeDeleteCheckInqResult_struct_vPtr;
typedef const rmsRecipeDeleteCheckInqResult_struct* rmsRecipeDeleteCheckInqResult_struct_cvPtr;

class  rmsRecipeDeleteCheckInqResult_struct_var
{
    public:

    rmsRecipeDeleteCheckInqResult_struct_var ();

    rmsRecipeDeleteCheckInqResult_struct_var (rmsRecipeDeleteCheckInqResult_struct *_p);

    rmsRecipeDeleteCheckInqResult_struct_var (const rmsRecipeDeleteCheckInqResult_struct_var &_s);

    rmsRecipeDeleteCheckInqResult_struct_var &operator= (rmsRecipeDeleteCheckInqResult_struct *_p);

    rmsRecipeDeleteCheckInqResult_struct_var &operator= (const rmsRecipeDeleteCheckInqResult_struct_var &_s);

    ~rmsRecipeDeleteCheckInqResult_struct_var ();

    rmsRecipeDeleteCheckInqResult_struct* operator-> ();

    const rmsRecipeDeleteCheckInqResult_struct& in() const;
    rmsRecipeDeleteCheckInqResult_struct& inout();
    rmsRecipeDeleteCheckInqResult_struct*& out();
    rmsRecipeDeleteCheckInqResult_struct* _retn();

    operator rmsRecipeDeleteCheckInqResult_struct_cvPtr () const;

    operator rmsRecipeDeleteCheckInqResult_struct_vPtr& ();

    operator const rmsRecipeDeleteCheckInqResult_struct& () const;

    operator rmsRecipeDeleteCheckInqResult_struct& ();

    protected:
    rmsRecipeDeleteCheckInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeDeleteCheckInqResult_struct;
    typedef rmsRecipeDeleteCheckInqResult_struct rmsRecipeDeleteCheckInqResult;
    typedef rmsRecipeDeleteCheckInqResult_struct_var rmsRecipeDeleteCheckInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeDeleteCheckInqResult;
    class  rmsRecipeUsedByCheckInqResult_struct_var;
    struct  rmsRecipeUsedByCheckInqResult_struct {
        typedef rmsRecipeUsedByCheckInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeInfoSequence strRecipeInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeUsedByCheckInqResult_struct();
       rmsRecipeUsedByCheckInqResult_struct(const rmsRecipeUsedByCheckInqResult_struct&);
       rmsRecipeUsedByCheckInqResult_struct& operator=(const rmsRecipeUsedByCheckInqResult_struct&);
       static CORBA::Info<rmsRecipeUsedByCheckInqResult_struct> rmsRecipeUsedByCheckInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeUsedByCheckInqResult_struct


typedef rmsRecipeUsedByCheckInqResult_struct* rmsRecipeUsedByCheckInqResult_struct_vPtr;
typedef const rmsRecipeUsedByCheckInqResult_struct* rmsRecipeUsedByCheckInqResult_struct_cvPtr;

class  rmsRecipeUsedByCheckInqResult_struct_var
{
    public:

    rmsRecipeUsedByCheckInqResult_struct_var ();

    rmsRecipeUsedByCheckInqResult_struct_var (rmsRecipeUsedByCheckInqResult_struct *_p);

    rmsRecipeUsedByCheckInqResult_struct_var (const rmsRecipeUsedByCheckInqResult_struct_var &_s);

    rmsRecipeUsedByCheckInqResult_struct_var &operator= (rmsRecipeUsedByCheckInqResult_struct *_p);

    rmsRecipeUsedByCheckInqResult_struct_var &operator= (const rmsRecipeUsedByCheckInqResult_struct_var &_s);

    ~rmsRecipeUsedByCheckInqResult_struct_var ();

    rmsRecipeUsedByCheckInqResult_struct* operator-> ();

    const rmsRecipeUsedByCheckInqResult_struct& in() const;
    rmsRecipeUsedByCheckInqResult_struct& inout();
    rmsRecipeUsedByCheckInqResult_struct*& out();
    rmsRecipeUsedByCheckInqResult_struct* _retn();

    operator rmsRecipeUsedByCheckInqResult_struct_cvPtr () const;

    operator rmsRecipeUsedByCheckInqResult_struct_vPtr& ();

    operator const rmsRecipeUsedByCheckInqResult_struct& () const;

    operator rmsRecipeUsedByCheckInqResult_struct& ();

    protected:
    rmsRecipeUsedByCheckInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeUsedByCheckInqResult_struct;
    typedef rmsRecipeUsedByCheckInqResult_struct rmsRecipeUsedByCheckInqResult;
    typedef rmsRecipeUsedByCheckInqResult_struct_var rmsRecipeUsedByCheckInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeUsedByCheckInqResult;
    class  rmsRecipeCopydFromGoldenReqResult_struct_var;
    struct  rmsRecipeCopydFromGoldenReqResult_struct {
        typedef rmsRecipeCopydFromGoldenReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeCopydFromGoldenReqResult_struct();
       rmsRecipeCopydFromGoldenReqResult_struct(const rmsRecipeCopydFromGoldenReqResult_struct&);
       rmsRecipeCopydFromGoldenReqResult_struct& operator=(const rmsRecipeCopydFromGoldenReqResult_struct&);
       static CORBA::Info<rmsRecipeCopydFromGoldenReqResult_struct> rmsRecipeCopydFromGoldenReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeCopydFromGoldenReqResult_struct


typedef rmsRecipeCopydFromGoldenReqResult_struct* rmsRecipeCopydFromGoldenReqResult_struct_vPtr;
typedef const rmsRecipeCopydFromGoldenReqResult_struct* rmsRecipeCopydFromGoldenReqResult_struct_cvPtr;

class  rmsRecipeCopydFromGoldenReqResult_struct_var
{
    public:

    rmsRecipeCopydFromGoldenReqResult_struct_var ();

    rmsRecipeCopydFromGoldenReqResult_struct_var (rmsRecipeCopydFromGoldenReqResult_struct *_p);

    rmsRecipeCopydFromGoldenReqResult_struct_var (const rmsRecipeCopydFromGoldenReqResult_struct_var &_s);

    rmsRecipeCopydFromGoldenReqResult_struct_var &operator= (rmsRecipeCopydFromGoldenReqResult_struct *_p);

    rmsRecipeCopydFromGoldenReqResult_struct_var &operator= (const rmsRecipeCopydFromGoldenReqResult_struct_var &_s);

    ~rmsRecipeCopydFromGoldenReqResult_struct_var ();

    rmsRecipeCopydFromGoldenReqResult_struct* operator-> ();

    const rmsRecipeCopydFromGoldenReqResult_struct& in() const;
    rmsRecipeCopydFromGoldenReqResult_struct& inout();
    rmsRecipeCopydFromGoldenReqResult_struct*& out();
    rmsRecipeCopydFromGoldenReqResult_struct* _retn();

    operator rmsRecipeCopydFromGoldenReqResult_struct_cvPtr () const;

    operator rmsRecipeCopydFromGoldenReqResult_struct_vPtr& ();

    operator const rmsRecipeCopydFromGoldenReqResult_struct& () const;

    operator rmsRecipeCopydFromGoldenReqResult_struct& ();

    protected:
    rmsRecipeCopydFromGoldenReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeCopydFromGoldenReqResult_struct;
    typedef rmsRecipeCopydFromGoldenReqResult_struct rmsRecipeCopydFromGoldenReqResult;
    typedef rmsRecipeCopydFromGoldenReqResult_struct_var rmsRecipeCopydFromGoldenReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeCopydFromGoldenReqResult;
    class  rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var;
    struct  rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct {
        typedef rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct();
       rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct(const rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct&);
       rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct& operator=(const rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct&);
       static CORBA::Info<rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct> rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct


typedef rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct* rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_vPtr;
typedef const rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct* rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_cvPtr;

class  rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var
{
    public:

    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var ();

    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var (rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct *_p);

    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var (const rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var &_s);

    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var &operator= (rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct *_p);

    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var &operator= (const rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var &_s);

    ~rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var ();

    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct* operator-> ();

    const rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct& in() const;
    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct& inout();
    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct*& out();
    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct* _retn();

    operator rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_cvPtr () const;

    operator rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_vPtr& ();

    operator const rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct& () const;

    operator rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct& ();

    protected:
    rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct;
    typedef rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct rmsRecipeUploadAllFromGoldenWithLimitReqResult;
    typedef rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct_var rmsRecipeUploadAllFromGoldenWithLimitReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeUploadAllFromGoldenWithLimitReqResult;
    class  rmsGoldenViewEqpListInqResult_struct_var;
    struct  rmsGoldenViewEqpListInqResult_struct {
        typedef rmsGoldenViewEqpListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifierSequence eqpIDs;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsGoldenViewEqpListInqResult_struct();
       rmsGoldenViewEqpListInqResult_struct(const rmsGoldenViewEqpListInqResult_struct&);
       rmsGoldenViewEqpListInqResult_struct& operator=(const rmsGoldenViewEqpListInqResult_struct&);
       static CORBA::Info<rmsGoldenViewEqpListInqResult_struct> rmsGoldenViewEqpListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsGoldenViewEqpListInqResult_struct


typedef rmsGoldenViewEqpListInqResult_struct* rmsGoldenViewEqpListInqResult_struct_vPtr;
typedef const rmsGoldenViewEqpListInqResult_struct* rmsGoldenViewEqpListInqResult_struct_cvPtr;

class  rmsGoldenViewEqpListInqResult_struct_var
{
    public:

    rmsGoldenViewEqpListInqResult_struct_var ();

    rmsGoldenViewEqpListInqResult_struct_var (rmsGoldenViewEqpListInqResult_struct *_p);

    rmsGoldenViewEqpListInqResult_struct_var (const rmsGoldenViewEqpListInqResult_struct_var &_s);

    rmsGoldenViewEqpListInqResult_struct_var &operator= (rmsGoldenViewEqpListInqResult_struct *_p);

    rmsGoldenViewEqpListInqResult_struct_var &operator= (const rmsGoldenViewEqpListInqResult_struct_var &_s);

    ~rmsGoldenViewEqpListInqResult_struct_var ();

    rmsGoldenViewEqpListInqResult_struct* operator-> ();

    const rmsGoldenViewEqpListInqResult_struct& in() const;
    rmsGoldenViewEqpListInqResult_struct& inout();
    rmsGoldenViewEqpListInqResult_struct*& out();
    rmsGoldenViewEqpListInqResult_struct* _retn();

    operator rmsGoldenViewEqpListInqResult_struct_cvPtr () const;

    operator rmsGoldenViewEqpListInqResult_struct_vPtr& ();

    operator const rmsGoldenViewEqpListInqResult_struct& () const;

    operator rmsGoldenViewEqpListInqResult_struct& ();

    protected:
    rmsGoldenViewEqpListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsGoldenViewEqpListInqResult_struct;
    typedef rmsGoldenViewEqpListInqResult_struct rmsGoldenViewEqpListInqResult;
    typedef rmsGoldenViewEqpListInqResult_struct_var rmsGoldenViewEqpListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsGoldenViewEqpListInqResult;
    class  rmsAlarmEventParameter_struct_var;
    struct  rmsAlarmEventParameter_struct {
        typedef rmsAlarmEventParameter_struct_var _var_type;
       ::CORBA::String_StructElem parameterName;
       ::CORBA::String_StructElem parameterValue;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsAlarmEventParameter_struct();
       rmsAlarmEventParameter_struct(const rmsAlarmEventParameter_struct&);
       rmsAlarmEventParameter_struct& operator=(const rmsAlarmEventParameter_struct&);
       static CORBA::Info<rmsAlarmEventParameter_struct> rmsAlarmEventParameter_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsAlarmEventParameter_struct


typedef rmsAlarmEventParameter_struct* rmsAlarmEventParameter_struct_vPtr;
typedef const rmsAlarmEventParameter_struct* rmsAlarmEventParameter_struct_cvPtr;

class  rmsAlarmEventParameter_struct_var
{
    public:

    rmsAlarmEventParameter_struct_var ();

    rmsAlarmEventParameter_struct_var (rmsAlarmEventParameter_struct *_p);

    rmsAlarmEventParameter_struct_var (const rmsAlarmEventParameter_struct_var &_s);

    rmsAlarmEventParameter_struct_var &operator= (rmsAlarmEventParameter_struct *_p);

    rmsAlarmEventParameter_struct_var &operator= (const rmsAlarmEventParameter_struct_var &_s);

    ~rmsAlarmEventParameter_struct_var ();

    rmsAlarmEventParameter_struct* operator-> ();

    const rmsAlarmEventParameter_struct& in() const;
    rmsAlarmEventParameter_struct& inout();
    rmsAlarmEventParameter_struct*& out();
    rmsAlarmEventParameter_struct* _retn();

    operator rmsAlarmEventParameter_struct_cvPtr () const;

    operator rmsAlarmEventParameter_struct_vPtr& ();

    operator const rmsAlarmEventParameter_struct& () const;

    operator rmsAlarmEventParameter_struct& ();

    protected:
    rmsAlarmEventParameter_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsAlarmEventParameter_struct;
    typedef rmsAlarmEventParameter_struct rmsAlarmEventParameter;
    typedef rmsAlarmEventParameter_struct_var rmsAlarmEventParameter_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsAlarmEventParameter;
class  _IDL_SEQ_rmsAlarmEventParameterSequence_0_var;
class  _IDL_SEQ_rmsAlarmEventParameterSequence_0 {
    public:
        typedef _IDL_SEQ_rmsAlarmEventParameterSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsAlarmEventParameter *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsAlarmEventParameterSequence_0 ();
    _IDL_SEQ_rmsAlarmEventParameterSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsAlarmEventParameterSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsAlarmEventParameter* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsAlarmEventParameterSequence_0 (const _IDL_SEQ_rmsAlarmEventParameterSequence_0&);

    ~_IDL_SEQ_rmsAlarmEventParameterSequence_0 ();

    _IDL_SEQ_rmsAlarmEventParameterSequence_0& operator= (const _IDL_SEQ_rmsAlarmEventParameterSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsAlarmEventParameter& operator [] (::CORBA::ULong indx);
    const rmsAlarmEventParameter& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsAlarmEventParameter* get_buffer (::CORBA::Boolean orphan=0);
    const rmsAlarmEventParameter* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsAlarmEventParameter* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsAlarmEventParameter* src, rmsAlarmEventParameter* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsAlarmEventParameter* data); 
  public:

    static rmsAlarmEventParameter* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsAlarmEventParameter* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsAlarmEventParameter* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsAlarmEventParameterSequence_0> rmsAlarmEventParameterSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsAlarmEventParameterSequence_0* _IDL_SEQ_rmsAlarmEventParameterSequence_0_vPtr;
typedef const _IDL_SEQ_rmsAlarmEventParameterSequence_0* _IDL_SEQ_rmsAlarmEventParameterSequence_0_cvPtr;

class  _IDL_SEQ_rmsAlarmEventParameterSequence_0_var
{
    public:

    _IDL_SEQ_rmsAlarmEventParameterSequence_0_var ();

    _IDL_SEQ_rmsAlarmEventParameterSequence_0_var (_IDL_SEQ_rmsAlarmEventParameterSequence_0 *_p);

    _IDL_SEQ_rmsAlarmEventParameterSequence_0_var (const _IDL_SEQ_rmsAlarmEventParameterSequence_0_var &_s);

    _IDL_SEQ_rmsAlarmEventParameterSequence_0_var &operator= (_IDL_SEQ_rmsAlarmEventParameterSequence_0 *_p);

    _IDL_SEQ_rmsAlarmEventParameterSequence_0_var &operator= (const _IDL_SEQ_rmsAlarmEventParameterSequence_0_var &_s);

    ~_IDL_SEQ_rmsAlarmEventParameterSequence_0_var ();

    _IDL_SEQ_rmsAlarmEventParameterSequence_0* operator-> ();

    operator _IDL_SEQ_rmsAlarmEventParameterSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsAlarmEventParameterSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsAlarmEventParameterSequence_0() const;

    const rmsAlarmEventParameter& operator[] (::CORBA::ULong index) const;
    rmsAlarmEventParameter& operator[] (::CORBA::ULong index);
    const rmsAlarmEventParameter& operator[] (int index) const;
    rmsAlarmEventParameter& operator[] (int index);
    const _IDL_SEQ_rmsAlarmEventParameterSequence_0& in() const;
    _IDL_SEQ_rmsAlarmEventParameterSequence_0& inout();
    _IDL_SEQ_rmsAlarmEventParameterSequence_0*& out();
    _IDL_SEQ_rmsAlarmEventParameterSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsAlarmEventParameterSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsAlarmEventParameterSequence_0 _rmsAlarmEventParameterSequence_seq;
    typedef _IDL_SEQ_rmsAlarmEventParameterSequence_0 _rmsAlarmEventParameterSequence_seq_1;
    typedef _IDL_SEQ_rmsAlarmEventParameterSequence_0 rmsAlarmEventParameterSequence;
    typedef _IDL_SEQ_rmsAlarmEventParameterSequence_0_var rmsAlarmEventParameterSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsAlarmEventParameterSequence;
    class  rmsChildRecipeInqResult_struct_var;
    struct  rmsChildRecipeInqResult_struct {
        typedef rmsChildRecipeInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::stringSequence childRecipes;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsChildRecipeInqResult_struct();
       rmsChildRecipeInqResult_struct(const rmsChildRecipeInqResult_struct&);
       rmsChildRecipeInqResult_struct& operator=(const rmsChildRecipeInqResult_struct&);
       static CORBA::Info<rmsChildRecipeInqResult_struct> rmsChildRecipeInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsChildRecipeInqResult_struct


typedef rmsChildRecipeInqResult_struct* rmsChildRecipeInqResult_struct_vPtr;
typedef const rmsChildRecipeInqResult_struct* rmsChildRecipeInqResult_struct_cvPtr;

class  rmsChildRecipeInqResult_struct_var
{
    public:

    rmsChildRecipeInqResult_struct_var ();

    rmsChildRecipeInqResult_struct_var (rmsChildRecipeInqResult_struct *_p);

    rmsChildRecipeInqResult_struct_var (const rmsChildRecipeInqResult_struct_var &_s);

    rmsChildRecipeInqResult_struct_var &operator= (rmsChildRecipeInqResult_struct *_p);

    rmsChildRecipeInqResult_struct_var &operator= (const rmsChildRecipeInqResult_struct_var &_s);

    ~rmsChildRecipeInqResult_struct_var ();

    rmsChildRecipeInqResult_struct* operator-> ();

    const rmsChildRecipeInqResult_struct& in() const;
    rmsChildRecipeInqResult_struct& inout();
    rmsChildRecipeInqResult_struct*& out();
    rmsChildRecipeInqResult_struct* _retn();

    operator rmsChildRecipeInqResult_struct_cvPtr () const;

    operator rmsChildRecipeInqResult_struct_vPtr& ();

    operator const rmsChildRecipeInqResult_struct& () const;

    operator rmsChildRecipeInqResult_struct& ();

    protected:
    rmsChildRecipeInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsChildRecipeInqResult_struct;
    typedef rmsChildRecipeInqResult_struct rmsChildRecipeInqResult;
    typedef rmsChildRecipeInqResult_struct_var rmsChildRecipeInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsChildRecipeInqResult;
    class  rmsRecipeLeaf_struct_var;
    struct  rmsRecipeLeaf_struct {
        typedef rmsRecipeLeaf_struct_var _var_type;
       ::CORBA::String_StructElem recipeID;
       ::CORBA::String_StructElem parentRecipeID;
       ::CORBA::Long recipeLevel;
       ::CORBA::String_StructElem option;
       ::CORBA::Boolean exist;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeLeaf_struct();
       rmsRecipeLeaf_struct(const rmsRecipeLeaf_struct&);
       rmsRecipeLeaf_struct& operator=(const rmsRecipeLeaf_struct&);
       static CORBA::Info<rmsRecipeLeaf_struct> rmsRecipeLeaf_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRecipeLeaf_struct


typedef rmsRecipeLeaf_struct* rmsRecipeLeaf_struct_vPtr;
typedef const rmsRecipeLeaf_struct* rmsRecipeLeaf_struct_cvPtr;

class  rmsRecipeLeaf_struct_var
{
    public:

    rmsRecipeLeaf_struct_var ();

    rmsRecipeLeaf_struct_var (rmsRecipeLeaf_struct *_p);

    rmsRecipeLeaf_struct_var (const rmsRecipeLeaf_struct_var &_s);

    rmsRecipeLeaf_struct_var &operator= (rmsRecipeLeaf_struct *_p);

    rmsRecipeLeaf_struct_var &operator= (const rmsRecipeLeaf_struct_var &_s);

    ~rmsRecipeLeaf_struct_var ();

    rmsRecipeLeaf_struct* operator-> ();

    const rmsRecipeLeaf_struct& in() const;
    rmsRecipeLeaf_struct& inout();
    rmsRecipeLeaf_struct*& out();
    rmsRecipeLeaf_struct* _retn();

    operator rmsRecipeLeaf_struct_cvPtr () const;

    operator rmsRecipeLeaf_struct_vPtr& ();

    operator const rmsRecipeLeaf_struct& () const;

    operator rmsRecipeLeaf_struct& ();

    protected:
    rmsRecipeLeaf_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLeaf_struct;
    typedef rmsRecipeLeaf_struct rmsRecipeLeaf;
    typedef rmsRecipeLeaf_struct_var rmsRecipeLeaf_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLeaf;
class  _IDL_SEQ_rmsRecipeLeafSequence_0_var;
class  _IDL_SEQ_rmsRecipeLeafSequence_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeLeafSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeLeaf *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeLeafSequence_0 ();
    _IDL_SEQ_rmsRecipeLeafSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeLeafSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeLeaf* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeLeafSequence_0 (const _IDL_SEQ_rmsRecipeLeafSequence_0&);

    ~_IDL_SEQ_rmsRecipeLeafSequence_0 ();

    _IDL_SEQ_rmsRecipeLeafSequence_0& operator= (const _IDL_SEQ_rmsRecipeLeafSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeLeaf& operator [] (::CORBA::ULong indx);
    const rmsRecipeLeaf& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeLeaf* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeLeaf* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeLeaf* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeLeaf* src, rmsRecipeLeaf* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeLeaf* data); 
  public:

    static rmsRecipeLeaf* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeLeaf* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeLeaf* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeLeafSequence_0> rmsRecipeLeafSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeLeafSequence_0* _IDL_SEQ_rmsRecipeLeafSequence_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeLeafSequence_0* _IDL_SEQ_rmsRecipeLeafSequence_0_cvPtr;

class  _IDL_SEQ_rmsRecipeLeafSequence_0_var
{
    public:

    _IDL_SEQ_rmsRecipeLeafSequence_0_var ();

    _IDL_SEQ_rmsRecipeLeafSequence_0_var (_IDL_SEQ_rmsRecipeLeafSequence_0 *_p);

    _IDL_SEQ_rmsRecipeLeafSequence_0_var (const _IDL_SEQ_rmsRecipeLeafSequence_0_var &_s);

    _IDL_SEQ_rmsRecipeLeafSequence_0_var &operator= (_IDL_SEQ_rmsRecipeLeafSequence_0 *_p);

    _IDL_SEQ_rmsRecipeLeafSequence_0_var &operator= (const _IDL_SEQ_rmsRecipeLeafSequence_0_var &_s);

    ~_IDL_SEQ_rmsRecipeLeafSequence_0_var ();

    _IDL_SEQ_rmsRecipeLeafSequence_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeLeafSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeLeafSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeLeafSequence_0() const;

    const rmsRecipeLeaf& operator[] (::CORBA::ULong index) const;
    rmsRecipeLeaf& operator[] (::CORBA::ULong index);
    const rmsRecipeLeaf& operator[] (int index) const;
    rmsRecipeLeaf& operator[] (int index);
    const _IDL_SEQ_rmsRecipeLeafSequence_0& in() const;
    _IDL_SEQ_rmsRecipeLeafSequence_0& inout();
    _IDL_SEQ_rmsRecipeLeafSequence_0*& out();
    _IDL_SEQ_rmsRecipeLeafSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeLeafSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeLeafSequence_0 _rmsRecipeLeafSequence_seq;
    typedef _IDL_SEQ_rmsRecipeLeafSequence_0 _rmsRecipeLeafSequence_seq_1;
    typedef _IDL_SEQ_rmsRecipeLeafSequence_0 rmsRecipeLeafSequence;
    typedef _IDL_SEQ_rmsRecipeLeafSequence_0_var rmsRecipeLeafSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLeafSequence;
    class  rmsRecipeTreeInqResult_struct_var;
    struct  rmsRecipeTreeInqResult_struct {
        typedef rmsRecipeTreeInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeLeafSequence recipeLeaves;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeTreeInqResult_struct();
       rmsRecipeTreeInqResult_struct(const rmsRecipeTreeInqResult_struct&);
       rmsRecipeTreeInqResult_struct& operator=(const rmsRecipeTreeInqResult_struct&);
       static CORBA::Info<rmsRecipeTreeInqResult_struct> rmsRecipeTreeInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeTreeInqResult_struct


typedef rmsRecipeTreeInqResult_struct* rmsRecipeTreeInqResult_struct_vPtr;
typedef const rmsRecipeTreeInqResult_struct* rmsRecipeTreeInqResult_struct_cvPtr;

class  rmsRecipeTreeInqResult_struct_var
{
    public:

    rmsRecipeTreeInqResult_struct_var ();

    rmsRecipeTreeInqResult_struct_var (rmsRecipeTreeInqResult_struct *_p);

    rmsRecipeTreeInqResult_struct_var (const rmsRecipeTreeInqResult_struct_var &_s);

    rmsRecipeTreeInqResult_struct_var &operator= (rmsRecipeTreeInqResult_struct *_p);

    rmsRecipeTreeInqResult_struct_var &operator= (const rmsRecipeTreeInqResult_struct_var &_s);

    ~rmsRecipeTreeInqResult_struct_var ();

    rmsRecipeTreeInqResult_struct* operator-> ();

    const rmsRecipeTreeInqResult_struct& in() const;
    rmsRecipeTreeInqResult_struct& inout();
    rmsRecipeTreeInqResult_struct*& out();
    rmsRecipeTreeInqResult_struct* _retn();

    operator rmsRecipeTreeInqResult_struct_cvPtr () const;

    operator rmsRecipeTreeInqResult_struct_vPtr& ();

    operator const rmsRecipeTreeInqResult_struct& () const;

    operator rmsRecipeTreeInqResult_struct& ();

    protected:
    rmsRecipeTreeInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeTreeInqResult_struct;
    typedef rmsRecipeTreeInqResult_struct rmsRecipeTreeInqResult;
    typedef rmsRecipeTreeInqResult_struct_var rmsRecipeTreeInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeTreeInqResult;
    class  rmsRecipeLimitCopyReqResult_struct_var;
    struct  rmsRecipeLimitCopyReqResult_struct {
        typedef rmsRecipeLimitCopyReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeLimitCopyReqResult_struct();
       rmsRecipeLimitCopyReqResult_struct(const rmsRecipeLimitCopyReqResult_struct&);
       rmsRecipeLimitCopyReqResult_struct& operator=(const rmsRecipeLimitCopyReqResult_struct&);
       static CORBA::Info<rmsRecipeLimitCopyReqResult_struct> rmsRecipeLimitCopyReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeLimitCopyReqResult_struct


typedef rmsRecipeLimitCopyReqResult_struct* rmsRecipeLimitCopyReqResult_struct_vPtr;
typedef const rmsRecipeLimitCopyReqResult_struct* rmsRecipeLimitCopyReqResult_struct_cvPtr;

class  rmsRecipeLimitCopyReqResult_struct_var
{
    public:

    rmsRecipeLimitCopyReqResult_struct_var ();

    rmsRecipeLimitCopyReqResult_struct_var (rmsRecipeLimitCopyReqResult_struct *_p);

    rmsRecipeLimitCopyReqResult_struct_var (const rmsRecipeLimitCopyReqResult_struct_var &_s);

    rmsRecipeLimitCopyReqResult_struct_var &operator= (rmsRecipeLimitCopyReqResult_struct *_p);

    rmsRecipeLimitCopyReqResult_struct_var &operator= (const rmsRecipeLimitCopyReqResult_struct_var &_s);

    ~rmsRecipeLimitCopyReqResult_struct_var ();

    rmsRecipeLimitCopyReqResult_struct* operator-> ();

    const rmsRecipeLimitCopyReqResult_struct& in() const;
    rmsRecipeLimitCopyReqResult_struct& inout();
    rmsRecipeLimitCopyReqResult_struct*& out();
    rmsRecipeLimitCopyReqResult_struct* _retn();

    operator rmsRecipeLimitCopyReqResult_struct_cvPtr () const;

    operator rmsRecipeLimitCopyReqResult_struct_vPtr& ();

    operator const rmsRecipeLimitCopyReqResult_struct& () const;

    operator rmsRecipeLimitCopyReqResult_struct& ();

    protected:
    rmsRecipeLimitCopyReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLimitCopyReqResult_struct;
    typedef rmsRecipeLimitCopyReqResult_struct rmsRecipeLimitCopyReqResult;
    typedef rmsRecipeLimitCopyReqResult_struct_var rmsRecipeLimitCopyReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLimitCopyReqResult;
    class  rmsChildRecipeUploadReqResult_struct_var;
    struct  rmsChildRecipeUploadReqResult_struct {
        typedef rmsChildRecipeUploadReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsChildRecipeUploadReqResult_struct();
       rmsChildRecipeUploadReqResult_struct(const rmsChildRecipeUploadReqResult_struct&);
       rmsChildRecipeUploadReqResult_struct& operator=(const rmsChildRecipeUploadReqResult_struct&);
       static CORBA::Info<rmsChildRecipeUploadReqResult_struct> rmsChildRecipeUploadReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsChildRecipeUploadReqResult_struct


typedef rmsChildRecipeUploadReqResult_struct* rmsChildRecipeUploadReqResult_struct_vPtr;
typedef const rmsChildRecipeUploadReqResult_struct* rmsChildRecipeUploadReqResult_struct_cvPtr;

class  rmsChildRecipeUploadReqResult_struct_var
{
    public:

    rmsChildRecipeUploadReqResult_struct_var ();

    rmsChildRecipeUploadReqResult_struct_var (rmsChildRecipeUploadReqResult_struct *_p);

    rmsChildRecipeUploadReqResult_struct_var (const rmsChildRecipeUploadReqResult_struct_var &_s);

    rmsChildRecipeUploadReqResult_struct_var &operator= (rmsChildRecipeUploadReqResult_struct *_p);

    rmsChildRecipeUploadReqResult_struct_var &operator= (const rmsChildRecipeUploadReqResult_struct_var &_s);

    ~rmsChildRecipeUploadReqResult_struct_var ();

    rmsChildRecipeUploadReqResult_struct* operator-> ();

    const rmsChildRecipeUploadReqResult_struct& in() const;
    rmsChildRecipeUploadReqResult_struct& inout();
    rmsChildRecipeUploadReqResult_struct*& out();
    rmsChildRecipeUploadReqResult_struct* _retn();

    operator rmsChildRecipeUploadReqResult_struct_cvPtr () const;

    operator rmsChildRecipeUploadReqResult_struct_vPtr& ();

    operator const rmsChildRecipeUploadReqResult_struct& () const;

    operator rmsChildRecipeUploadReqResult_struct& ();

    protected:
    rmsChildRecipeUploadReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsChildRecipeUploadReqResult_struct;
    typedef rmsChildRecipeUploadReqResult_struct rmsChildRecipeUploadReqResult;
    typedef rmsChildRecipeUploadReqResult_struct_var rmsChildRecipeUploadReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsChildRecipeUploadReqResult;
    class  rmsMiscInqResult_struct_var;
    struct  rmsMiscInqResult_struct {
        typedef rmsMiscInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem value;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsMiscInqResult_struct();
       rmsMiscInqResult_struct(const rmsMiscInqResult_struct&);
       rmsMiscInqResult_struct& operator=(const rmsMiscInqResult_struct&);
       static CORBA::Info<rmsMiscInqResult_struct> rmsMiscInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsMiscInqResult_struct


typedef rmsMiscInqResult_struct* rmsMiscInqResult_struct_vPtr;
typedef const rmsMiscInqResult_struct* rmsMiscInqResult_struct_cvPtr;

class  rmsMiscInqResult_struct_var
{
    public:

    rmsMiscInqResult_struct_var ();

    rmsMiscInqResult_struct_var (rmsMiscInqResult_struct *_p);

    rmsMiscInqResult_struct_var (const rmsMiscInqResult_struct_var &_s);

    rmsMiscInqResult_struct_var &operator= (rmsMiscInqResult_struct *_p);

    rmsMiscInqResult_struct_var &operator= (const rmsMiscInqResult_struct_var &_s);

    ~rmsMiscInqResult_struct_var ();

    rmsMiscInqResult_struct* operator-> ();

    const rmsMiscInqResult_struct& in() const;
    rmsMiscInqResult_struct& inout();
    rmsMiscInqResult_struct*& out();
    rmsMiscInqResult_struct* _retn();

    operator rmsMiscInqResult_struct_cvPtr () const;

    operator rmsMiscInqResult_struct_vPtr& ();

    operator const rmsMiscInqResult_struct& () const;

    operator rmsMiscInqResult_struct& ();

    protected:
    rmsMiscInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsMiscInqResult_struct;
    typedef rmsMiscInqResult_struct rmsMiscInqResult;
    typedef rmsMiscInqResult_struct_var rmsMiscInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsMiscInqResult;
    class  rmsResult_struct_var;
    struct  rmsResult_struct {
        typedef rmsResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsResult_struct();
       rmsResult_struct(const rmsResult_struct&);
       rmsResult_struct& operator=(const rmsResult_struct&);
       static CORBA::Info<rmsResult_struct> rmsResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsResult_struct


typedef rmsResult_struct* rmsResult_struct_vPtr;
typedef const rmsResult_struct* rmsResult_struct_cvPtr;

class  rmsResult_struct_var
{
    public:

    rmsResult_struct_var ();

    rmsResult_struct_var (rmsResult_struct *_p);

    rmsResult_struct_var (const rmsResult_struct_var &_s);

    rmsResult_struct_var &operator= (rmsResult_struct *_p);

    rmsResult_struct_var &operator= (const rmsResult_struct_var &_s);

    ~rmsResult_struct_var ();

    rmsResult_struct* operator-> ();

    const rmsResult_struct& in() const;
    rmsResult_struct& inout();
    rmsResult_struct*& out();
    rmsResult_struct* _retn();

    operator rmsResult_struct_cvPtr () const;

    operator rmsResult_struct_vPtr& ();

    operator const rmsResult_struct& () const;

    operator rmsResult_struct& ();

    protected:
    rmsResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsResult_struct;
    typedef rmsResult_struct rmsResult;
    typedef rmsResult_struct_var rmsResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsResult;
    class  rmsMiscPair_struct_var;
    struct  rmsMiscPair_struct {
        typedef rmsMiscPair_struct_var _var_type;
       ::CORBA::String_StructElem key;
       ::CORBA::String_StructElem value;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsMiscPair_struct();
       rmsMiscPair_struct(const rmsMiscPair_struct&);
       rmsMiscPair_struct& operator=(const rmsMiscPair_struct&);
       static CORBA::Info<rmsMiscPair_struct> rmsMiscPair_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsMiscPair_struct


typedef rmsMiscPair_struct* rmsMiscPair_struct_vPtr;
typedef const rmsMiscPair_struct* rmsMiscPair_struct_cvPtr;

class  rmsMiscPair_struct_var
{
    public:

    rmsMiscPair_struct_var ();

    rmsMiscPair_struct_var (rmsMiscPair_struct *_p);

    rmsMiscPair_struct_var (const rmsMiscPair_struct_var &_s);

    rmsMiscPair_struct_var &operator= (rmsMiscPair_struct *_p);

    rmsMiscPair_struct_var &operator= (const rmsMiscPair_struct_var &_s);

    ~rmsMiscPair_struct_var ();

    rmsMiscPair_struct* operator-> ();

    const rmsMiscPair_struct& in() const;
    rmsMiscPair_struct& inout();
    rmsMiscPair_struct*& out();
    rmsMiscPair_struct* _retn();

    operator rmsMiscPair_struct_cvPtr () const;

    operator rmsMiscPair_struct_vPtr& ();

    operator const rmsMiscPair_struct& () const;

    operator rmsMiscPair_struct& ();

    protected:
    rmsMiscPair_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsMiscPair_struct;
    typedef rmsMiscPair_struct rmsMiscPair;
    typedef rmsMiscPair_struct_var rmsMiscPair_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsMiscPair;
class  _IDL_SEQ_rmsMiscPairSeq_0_var;
class  _IDL_SEQ_rmsMiscPairSeq_0 {
    public:
        typedef _IDL_SEQ_rmsMiscPairSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsMiscPair *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsMiscPairSeq_0 ();
    _IDL_SEQ_rmsMiscPairSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsMiscPairSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsMiscPair* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsMiscPairSeq_0 (const _IDL_SEQ_rmsMiscPairSeq_0&);

    ~_IDL_SEQ_rmsMiscPairSeq_0 ();

    _IDL_SEQ_rmsMiscPairSeq_0& operator= (const _IDL_SEQ_rmsMiscPairSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsMiscPair& operator [] (::CORBA::ULong indx);
    const rmsMiscPair& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsMiscPair* get_buffer (::CORBA::Boolean orphan=0);
    const rmsMiscPair* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsMiscPair* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsMiscPair* src, rmsMiscPair* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsMiscPair* data); 
  public:

    static rmsMiscPair* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsMiscPair* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsMiscPair* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsMiscPairSeq_0> rmsMiscPairSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsMiscPairSeq_0* _IDL_SEQ_rmsMiscPairSeq_0_vPtr;
typedef const _IDL_SEQ_rmsMiscPairSeq_0* _IDL_SEQ_rmsMiscPairSeq_0_cvPtr;

class  _IDL_SEQ_rmsMiscPairSeq_0_var
{
    public:

    _IDL_SEQ_rmsMiscPairSeq_0_var ();

    _IDL_SEQ_rmsMiscPairSeq_0_var (_IDL_SEQ_rmsMiscPairSeq_0 *_p);

    _IDL_SEQ_rmsMiscPairSeq_0_var (const _IDL_SEQ_rmsMiscPairSeq_0_var &_s);

    _IDL_SEQ_rmsMiscPairSeq_0_var &operator= (_IDL_SEQ_rmsMiscPairSeq_0 *_p);

    _IDL_SEQ_rmsMiscPairSeq_0_var &operator= (const _IDL_SEQ_rmsMiscPairSeq_0_var &_s);

    ~_IDL_SEQ_rmsMiscPairSeq_0_var ();

    _IDL_SEQ_rmsMiscPairSeq_0* operator-> ();

    operator _IDL_SEQ_rmsMiscPairSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsMiscPairSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsMiscPairSeq_0() const;

    const rmsMiscPair& operator[] (::CORBA::ULong index) const;
    rmsMiscPair& operator[] (::CORBA::ULong index);
    const rmsMiscPair& operator[] (int index) const;
    rmsMiscPair& operator[] (int index);
    const _IDL_SEQ_rmsMiscPairSeq_0& in() const;
    _IDL_SEQ_rmsMiscPairSeq_0& inout();
    _IDL_SEQ_rmsMiscPairSeq_0*& out();
    _IDL_SEQ_rmsMiscPairSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsMiscPairSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsMiscPairSeq_0 _rmsMiscPairSeq_seq;
    typedef _IDL_SEQ_rmsMiscPairSeq_0 _rmsMiscPairSeq_seq_1;
    typedef _IDL_SEQ_rmsMiscPairSeq_0 rmsMiscPairSeq;
    typedef _IDL_SEQ_rmsMiscPairSeq_0_var rmsMiscPairSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsMiscPairSeq;
    class  rmsMiscPairInqResult_struct_var;
    struct  rmsMiscPairInqResult_struct {
        typedef rmsMiscPairInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsMiscPairSeq pairs;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsMiscPairInqResult_struct();
       rmsMiscPairInqResult_struct(const rmsMiscPairInqResult_struct&);
       rmsMiscPairInqResult_struct& operator=(const rmsMiscPairInqResult_struct&);
       static CORBA::Info<rmsMiscPairInqResult_struct> rmsMiscPairInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsMiscPairInqResult_struct


typedef rmsMiscPairInqResult_struct* rmsMiscPairInqResult_struct_vPtr;
typedef const rmsMiscPairInqResult_struct* rmsMiscPairInqResult_struct_cvPtr;

class  rmsMiscPairInqResult_struct_var
{
    public:

    rmsMiscPairInqResult_struct_var ();

    rmsMiscPairInqResult_struct_var (rmsMiscPairInqResult_struct *_p);

    rmsMiscPairInqResult_struct_var (const rmsMiscPairInqResult_struct_var &_s);

    rmsMiscPairInqResult_struct_var &operator= (rmsMiscPairInqResult_struct *_p);

    rmsMiscPairInqResult_struct_var &operator= (const rmsMiscPairInqResult_struct_var &_s);

    ~rmsMiscPairInqResult_struct_var ();

    rmsMiscPairInqResult_struct* operator-> ();

    const rmsMiscPairInqResult_struct& in() const;
    rmsMiscPairInqResult_struct& inout();
    rmsMiscPairInqResult_struct*& out();
    rmsMiscPairInqResult_struct* _retn();

    operator rmsMiscPairInqResult_struct_cvPtr () const;

    operator rmsMiscPairInqResult_struct_vPtr& ();

    operator const rmsMiscPairInqResult_struct& () const;

    operator rmsMiscPairInqResult_struct& ();

    protected:
    rmsMiscPairInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsMiscPairInqResult_struct;
    typedef rmsMiscPairInqResult_struct rmsMiscPairInqResult;
    typedef rmsMiscPairInqResult_struct_var rmsMiscPairInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsMiscPairInqResult;
    class  rmsMandPRecipeInfo_struct_var;
    struct  rmsMandPRecipeInfo_struct {
        typedef rmsMandPRecipeInfo_struct_var _var_type;
       ::objectIdentifier machineRecipeID;
       ::CORBA::String_StructElem physicalRecipeID;
       ::CORBA::Boolean uploaded;
       ::CORBA::Boolean goldenExist;
       ::CORBA::Boolean auditFlag;
       ::CORBA::Boolean locked;
       ::CORBA::String_StructElem goldenUpdateTime;
       ::CORBA::Boolean display;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsMandPRecipeInfo_struct();
       rmsMandPRecipeInfo_struct(const rmsMandPRecipeInfo_struct&);
       rmsMandPRecipeInfo_struct& operator=(const rmsMandPRecipeInfo_struct&);
       static CORBA::Info<rmsMandPRecipeInfo_struct> rmsMandPRecipeInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsMandPRecipeInfo_struct


typedef rmsMandPRecipeInfo_struct* rmsMandPRecipeInfo_struct_vPtr;
typedef const rmsMandPRecipeInfo_struct* rmsMandPRecipeInfo_struct_cvPtr;

class  rmsMandPRecipeInfo_struct_var
{
    public:

    rmsMandPRecipeInfo_struct_var ();

    rmsMandPRecipeInfo_struct_var (rmsMandPRecipeInfo_struct *_p);

    rmsMandPRecipeInfo_struct_var (const rmsMandPRecipeInfo_struct_var &_s);

    rmsMandPRecipeInfo_struct_var &operator= (rmsMandPRecipeInfo_struct *_p);

    rmsMandPRecipeInfo_struct_var &operator= (const rmsMandPRecipeInfo_struct_var &_s);

    ~rmsMandPRecipeInfo_struct_var ();

    rmsMandPRecipeInfo_struct* operator-> ();

    const rmsMandPRecipeInfo_struct& in() const;
    rmsMandPRecipeInfo_struct& inout();
    rmsMandPRecipeInfo_struct*& out();
    rmsMandPRecipeInfo_struct* _retn();

    operator rmsMandPRecipeInfo_struct_cvPtr () const;

    operator rmsMandPRecipeInfo_struct_vPtr& ();

    operator const rmsMandPRecipeInfo_struct& () const;

    operator rmsMandPRecipeInfo_struct& ();

    protected:
    rmsMandPRecipeInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsMandPRecipeInfo_struct;
    typedef rmsMandPRecipeInfo_struct rmsMandPRecipeInfo;
    typedef rmsMandPRecipeInfo_struct_var rmsMandPRecipeInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsMandPRecipeInfo;
class  _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var;
class  _IDL_SEQ_rmsMandPRecipeInfoSequence_0 {
    public:
        typedef _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsMandPRecipeInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsMandPRecipeInfoSequence_0 ();
    _IDL_SEQ_rmsMandPRecipeInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsMandPRecipeInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsMandPRecipeInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsMandPRecipeInfoSequence_0 (const _IDL_SEQ_rmsMandPRecipeInfoSequence_0&);

    ~_IDL_SEQ_rmsMandPRecipeInfoSequence_0 ();

    _IDL_SEQ_rmsMandPRecipeInfoSequence_0& operator= (const _IDL_SEQ_rmsMandPRecipeInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsMandPRecipeInfo& operator [] (::CORBA::ULong indx);
    const rmsMandPRecipeInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsMandPRecipeInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsMandPRecipeInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsMandPRecipeInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsMandPRecipeInfo* src, rmsMandPRecipeInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsMandPRecipeInfo* data); 
  public:

    static rmsMandPRecipeInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsMandPRecipeInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsMandPRecipeInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsMandPRecipeInfoSequence_0> rmsMandPRecipeInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsMandPRecipeInfoSequence_0* _IDL_SEQ_rmsMandPRecipeInfoSequence_0_vPtr;
typedef const _IDL_SEQ_rmsMandPRecipeInfoSequence_0* _IDL_SEQ_rmsMandPRecipeInfoSequence_0_cvPtr;

class  _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var
{
    public:

    _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var ();

    _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var (_IDL_SEQ_rmsMandPRecipeInfoSequence_0 *_p);

    _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var (const _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var &_s);

    _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var &operator= (_IDL_SEQ_rmsMandPRecipeInfoSequence_0 *_p);

    _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var &operator= (const _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var &_s);

    ~_IDL_SEQ_rmsMandPRecipeInfoSequence_0_var ();

    _IDL_SEQ_rmsMandPRecipeInfoSequence_0* operator-> ();

    operator _IDL_SEQ_rmsMandPRecipeInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsMandPRecipeInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsMandPRecipeInfoSequence_0() const;

    const rmsMandPRecipeInfo& operator[] (::CORBA::ULong index) const;
    rmsMandPRecipeInfo& operator[] (::CORBA::ULong index);
    const rmsMandPRecipeInfo& operator[] (int index) const;
    rmsMandPRecipeInfo& operator[] (int index);
    const _IDL_SEQ_rmsMandPRecipeInfoSequence_0& in() const;
    _IDL_SEQ_rmsMandPRecipeInfoSequence_0& inout();
    _IDL_SEQ_rmsMandPRecipeInfoSequence_0*& out();
    _IDL_SEQ_rmsMandPRecipeInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsMandPRecipeInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsMandPRecipeInfoSequence_0 _rmsMandPRecipeInfoSequence_seq;
    typedef _IDL_SEQ_rmsMandPRecipeInfoSequence_0 _rmsMandPRecipeInfoSequence_seq_1;
    typedef _IDL_SEQ_rmsMandPRecipeInfoSequence_0 rmsMandPRecipeInfoSequence;
    typedef _IDL_SEQ_rmsMandPRecipeInfoSequence_0_var rmsMandPRecipeInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsMandPRecipeInfoSequence;
    class  rmsEqpRelatedRecipeAllInqResult_struct_var;
    struct  rmsEqpRelatedRecipeAllInqResult_struct {
        typedef rmsEqpRelatedRecipeAllInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsMandPRecipeInfoSequence strMandPRecipeInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpRelatedRecipeAllInqResult_struct();
       rmsEqpRelatedRecipeAllInqResult_struct(const rmsEqpRelatedRecipeAllInqResult_struct&);
       rmsEqpRelatedRecipeAllInqResult_struct& operator=(const rmsEqpRelatedRecipeAllInqResult_struct&);
       static CORBA::Info<rmsEqpRelatedRecipeAllInqResult_struct> rmsEqpRelatedRecipeAllInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpRelatedRecipeAllInqResult_struct


typedef rmsEqpRelatedRecipeAllInqResult_struct* rmsEqpRelatedRecipeAllInqResult_struct_vPtr;
typedef const rmsEqpRelatedRecipeAllInqResult_struct* rmsEqpRelatedRecipeAllInqResult_struct_cvPtr;

class  rmsEqpRelatedRecipeAllInqResult_struct_var
{
    public:

    rmsEqpRelatedRecipeAllInqResult_struct_var ();

    rmsEqpRelatedRecipeAllInqResult_struct_var (rmsEqpRelatedRecipeAllInqResult_struct *_p);

    rmsEqpRelatedRecipeAllInqResult_struct_var (const rmsEqpRelatedRecipeAllInqResult_struct_var &_s);

    rmsEqpRelatedRecipeAllInqResult_struct_var &operator= (rmsEqpRelatedRecipeAllInqResult_struct *_p);

    rmsEqpRelatedRecipeAllInqResult_struct_var &operator= (const rmsEqpRelatedRecipeAllInqResult_struct_var &_s);

    ~rmsEqpRelatedRecipeAllInqResult_struct_var ();

    rmsEqpRelatedRecipeAllInqResult_struct* operator-> ();

    const rmsEqpRelatedRecipeAllInqResult_struct& in() const;
    rmsEqpRelatedRecipeAllInqResult_struct& inout();
    rmsEqpRelatedRecipeAllInqResult_struct*& out();
    rmsEqpRelatedRecipeAllInqResult_struct* _retn();

    operator rmsEqpRelatedRecipeAllInqResult_struct_cvPtr () const;

    operator rmsEqpRelatedRecipeAllInqResult_struct_vPtr& ();

    operator const rmsEqpRelatedRecipeAllInqResult_struct& () const;

    operator rmsEqpRelatedRecipeAllInqResult_struct& ();

    protected:
    rmsEqpRelatedRecipeAllInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpRelatedRecipeAllInqResult_struct;
    typedef rmsEqpRelatedRecipeAllInqResult_struct rmsEqpRelatedRecipeAllInqResult;
    typedef rmsEqpRelatedRecipeAllInqResult_struct_var rmsEqpRelatedRecipeAllInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpRelatedRecipeAllInqResult;
    class  rmsBatchJob_struct_var;
    struct  rmsBatchJob_struct {
        typedef rmsBatchJob_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem eqpSpecial;
       ::CORBA::String_StructElem registerTime;
       ::CORBA::String_StructElem registerUser;
       ::CORBA::String_StructElem registerUserPwd;
       ::CORBA::Long jobCode;
       ::CORBA::Long timeInterval;
       ::CORBA::String_StructElem eqpAvailStart;
       ::CORBA::String_StructElem eqpAvailEnd;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::String_StructElem reasonCode;
       ::CORBA::String_StructElem email;
       ::CORBA::String_StructElem physicalRecipeID;
       ::CORBA::String_StructElem execTime;
       ::CORBA::Long execResult;
       ::CORBA::String_StructElem message;
       ::CORBA::String_StructElem closing;
       ::CORBA::String_StructElem summary;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsBatchJob_struct();
       rmsBatchJob_struct(const rmsBatchJob_struct&);
       rmsBatchJob_struct& operator=(const rmsBatchJob_struct&);
       static CORBA::Info<rmsBatchJob_struct> rmsBatchJob_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsBatchJob_struct


typedef rmsBatchJob_struct* rmsBatchJob_struct_vPtr;
typedef const rmsBatchJob_struct* rmsBatchJob_struct_cvPtr;

class  rmsBatchJob_struct_var
{
    public:

    rmsBatchJob_struct_var ();

    rmsBatchJob_struct_var (rmsBatchJob_struct *_p);

    rmsBatchJob_struct_var (const rmsBatchJob_struct_var &_s);

    rmsBatchJob_struct_var &operator= (rmsBatchJob_struct *_p);

    rmsBatchJob_struct_var &operator= (const rmsBatchJob_struct_var &_s);

    ~rmsBatchJob_struct_var ();

    rmsBatchJob_struct* operator-> ();

    const rmsBatchJob_struct& in() const;
    rmsBatchJob_struct& inout();
    rmsBatchJob_struct*& out();
    rmsBatchJob_struct* _retn();

    operator rmsBatchJob_struct_cvPtr () const;

    operator rmsBatchJob_struct_vPtr& ();

    operator const rmsBatchJob_struct& () const;

    operator rmsBatchJob_struct& ();

    protected:
    rmsBatchJob_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsBatchJob_struct;
    typedef rmsBatchJob_struct rmsBatchJob;
    typedef rmsBatchJob_struct_var rmsBatchJob_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsBatchJob;
class  _IDL_SEQ_rmsBatchJobSeq_0_var;
class  _IDL_SEQ_rmsBatchJobSeq_0 {
    public:
        typedef _IDL_SEQ_rmsBatchJobSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsBatchJob *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsBatchJobSeq_0 ();
    _IDL_SEQ_rmsBatchJobSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsBatchJobSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsBatchJob* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsBatchJobSeq_0 (const _IDL_SEQ_rmsBatchJobSeq_0&);

    ~_IDL_SEQ_rmsBatchJobSeq_0 ();

    _IDL_SEQ_rmsBatchJobSeq_0& operator= (const _IDL_SEQ_rmsBatchJobSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsBatchJob& operator [] (::CORBA::ULong indx);
    const rmsBatchJob& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsBatchJob* get_buffer (::CORBA::Boolean orphan=0);
    const rmsBatchJob* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsBatchJob* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsBatchJob* src, rmsBatchJob* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsBatchJob* data); 
  public:

    static rmsBatchJob* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsBatchJob* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsBatchJob* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsBatchJobSeq_0> rmsBatchJobSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsBatchJobSeq_0* _IDL_SEQ_rmsBatchJobSeq_0_vPtr;
typedef const _IDL_SEQ_rmsBatchJobSeq_0* _IDL_SEQ_rmsBatchJobSeq_0_cvPtr;

class  _IDL_SEQ_rmsBatchJobSeq_0_var
{
    public:

    _IDL_SEQ_rmsBatchJobSeq_0_var ();

    _IDL_SEQ_rmsBatchJobSeq_0_var (_IDL_SEQ_rmsBatchJobSeq_0 *_p);

    _IDL_SEQ_rmsBatchJobSeq_0_var (const _IDL_SEQ_rmsBatchJobSeq_0_var &_s);

    _IDL_SEQ_rmsBatchJobSeq_0_var &operator= (_IDL_SEQ_rmsBatchJobSeq_0 *_p);

    _IDL_SEQ_rmsBatchJobSeq_0_var &operator= (const _IDL_SEQ_rmsBatchJobSeq_0_var &_s);

    ~_IDL_SEQ_rmsBatchJobSeq_0_var ();

    _IDL_SEQ_rmsBatchJobSeq_0* operator-> ();

    operator _IDL_SEQ_rmsBatchJobSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsBatchJobSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsBatchJobSeq_0() const;

    const rmsBatchJob& operator[] (::CORBA::ULong index) const;
    rmsBatchJob& operator[] (::CORBA::ULong index);
    const rmsBatchJob& operator[] (int index) const;
    rmsBatchJob& operator[] (int index);
    const _IDL_SEQ_rmsBatchJobSeq_0& in() const;
    _IDL_SEQ_rmsBatchJobSeq_0& inout();
    _IDL_SEQ_rmsBatchJobSeq_0*& out();
    _IDL_SEQ_rmsBatchJobSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsBatchJobSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsBatchJobSeq_0 _rmsBatchJobSeq_seq;
    typedef _IDL_SEQ_rmsBatchJobSeq_0 _rmsBatchJobSeq_seq_1;
    typedef _IDL_SEQ_rmsBatchJobSeq_0 rmsBatchJobSeq;
    typedef _IDL_SEQ_rmsBatchJobSeq_0_var rmsBatchJobSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsBatchJobSeq;
    class  rmsBatchJobInqResult_struct_var;
    struct  rmsBatchJobInqResult_struct {
        typedef rmsBatchJobInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsBatchJobSeq jobs;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsBatchJobInqResult_struct();
       rmsBatchJobInqResult_struct(const rmsBatchJobInqResult_struct&);
       rmsBatchJobInqResult_struct& operator=(const rmsBatchJobInqResult_struct&);
       static CORBA::Info<rmsBatchJobInqResult_struct> rmsBatchJobInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsBatchJobInqResult_struct


typedef rmsBatchJobInqResult_struct* rmsBatchJobInqResult_struct_vPtr;
typedef const rmsBatchJobInqResult_struct* rmsBatchJobInqResult_struct_cvPtr;

class  rmsBatchJobInqResult_struct_var
{
    public:

    rmsBatchJobInqResult_struct_var ();

    rmsBatchJobInqResult_struct_var (rmsBatchJobInqResult_struct *_p);

    rmsBatchJobInqResult_struct_var (const rmsBatchJobInqResult_struct_var &_s);

    rmsBatchJobInqResult_struct_var &operator= (rmsBatchJobInqResult_struct *_p);

    rmsBatchJobInqResult_struct_var &operator= (const rmsBatchJobInqResult_struct_var &_s);

    ~rmsBatchJobInqResult_struct_var ();

    rmsBatchJobInqResult_struct* operator-> ();

    const rmsBatchJobInqResult_struct& in() const;
    rmsBatchJobInqResult_struct& inout();
    rmsBatchJobInqResult_struct*& out();
    rmsBatchJobInqResult_struct* _retn();

    operator rmsBatchJobInqResult_struct_cvPtr () const;

    operator rmsBatchJobInqResult_struct_vPtr& ();

    operator const rmsBatchJobInqResult_struct& () const;

    operator rmsBatchJobInqResult_struct& ();

    protected:
    rmsBatchJobInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsBatchJobInqResult_struct;
    typedef rmsBatchJobInqResult_struct rmsBatchJobInqResult;
    typedef rmsBatchJobInqResult_struct_var rmsBatchJobInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsBatchJobInqResult;
    class  rmsEqpBatchJobRunTimeInfo_struct_var;
    struct  rmsEqpBatchJobRunTimeInfo_struct {
        typedef rmsEqpBatchJobRunTimeInfo_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem eqpSpecial;
       ::CORBA::String_StructElem status;
       ::CORBA::Long jobCnt;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpBatchJobRunTimeInfo_struct();
       rmsEqpBatchJobRunTimeInfo_struct(const rmsEqpBatchJobRunTimeInfo_struct&);
       rmsEqpBatchJobRunTimeInfo_struct& operator=(const rmsEqpBatchJobRunTimeInfo_struct&);
       static CORBA::Info<rmsEqpBatchJobRunTimeInfo_struct> rmsEqpBatchJobRunTimeInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsEqpBatchJobRunTimeInfo_struct


typedef rmsEqpBatchJobRunTimeInfo_struct* rmsEqpBatchJobRunTimeInfo_struct_vPtr;
typedef const rmsEqpBatchJobRunTimeInfo_struct* rmsEqpBatchJobRunTimeInfo_struct_cvPtr;

class  rmsEqpBatchJobRunTimeInfo_struct_var
{
    public:

    rmsEqpBatchJobRunTimeInfo_struct_var ();

    rmsEqpBatchJobRunTimeInfo_struct_var (rmsEqpBatchJobRunTimeInfo_struct *_p);

    rmsEqpBatchJobRunTimeInfo_struct_var (const rmsEqpBatchJobRunTimeInfo_struct_var &_s);

    rmsEqpBatchJobRunTimeInfo_struct_var &operator= (rmsEqpBatchJobRunTimeInfo_struct *_p);

    rmsEqpBatchJobRunTimeInfo_struct_var &operator= (const rmsEqpBatchJobRunTimeInfo_struct_var &_s);

    ~rmsEqpBatchJobRunTimeInfo_struct_var ();

    rmsEqpBatchJobRunTimeInfo_struct* operator-> ();

    const rmsEqpBatchJobRunTimeInfo_struct& in() const;
    rmsEqpBatchJobRunTimeInfo_struct& inout();
    rmsEqpBatchJobRunTimeInfo_struct*& out();
    rmsEqpBatchJobRunTimeInfo_struct* _retn();

    operator rmsEqpBatchJobRunTimeInfo_struct_cvPtr () const;

    operator rmsEqpBatchJobRunTimeInfo_struct_vPtr& ();

    operator const rmsEqpBatchJobRunTimeInfo_struct& () const;

    operator rmsEqpBatchJobRunTimeInfo_struct& ();

    protected:
    rmsEqpBatchJobRunTimeInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpBatchJobRunTimeInfo_struct;
    typedef rmsEqpBatchJobRunTimeInfo_struct rmsEqpBatchJobRunTimeInfo;
    typedef rmsEqpBatchJobRunTimeInfo_struct_var rmsEqpBatchJobRunTimeInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpBatchJobRunTimeInfo;
class  _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var;
class  _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 {
    public:
        typedef _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsEqpBatchJobRunTimeInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 ();
    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpBatchJobRunTimeInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 (const _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0&);

    ~_IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 ();

    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0& operator= (const _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsEqpBatchJobRunTimeInfo& operator [] (::CORBA::ULong indx);
    const rmsEqpBatchJobRunTimeInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsEqpBatchJobRunTimeInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsEqpBatchJobRunTimeInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpBatchJobRunTimeInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpBatchJobRunTimeInfo* src, rmsEqpBatchJobRunTimeInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpBatchJobRunTimeInfo* data); 
  public:

    static rmsEqpBatchJobRunTimeInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsEqpBatchJobRunTimeInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsEqpBatchJobRunTimeInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0> rmsEqpBatchJobRunTimeInfoSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0* _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_vPtr;
typedef const _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0* _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_cvPtr;

class  _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var
{
    public:

    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var ();

    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var (_IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 *_p);

    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var (const _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var &_s);

    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var &operator= (_IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 *_p);

    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var &operator= (const _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var &_s);

    ~_IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var ();

    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0* operator-> ();

    operator _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0() const;

    const rmsEqpBatchJobRunTimeInfo& operator[] (::CORBA::ULong index) const;
    rmsEqpBatchJobRunTimeInfo& operator[] (::CORBA::ULong index);
    const rmsEqpBatchJobRunTimeInfo& operator[] (int index) const;
    rmsEqpBatchJobRunTimeInfo& operator[] (int index);
    const _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0& in() const;
    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0& inout();
    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0*& out();
    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 _rmsEqpBatchJobRunTimeInfoSeq_seq;
    typedef _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 _rmsEqpBatchJobRunTimeInfoSeq_seq_1;
    typedef _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0 rmsEqpBatchJobRunTimeInfoSeq;
    typedef _IDL_SEQ_rmsEqpBatchJobRunTimeInfoSeq_0_var rmsEqpBatchJobRunTimeInfoSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpBatchJobRunTimeInfoSeq;
    class  rmsBatchJobRunTimeInfo_struct_var;
    struct  rmsBatchJobRunTimeInfo_struct {
        typedef rmsBatchJobRunTimeInfo_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEqpBatchJobRunTimeInfoSeq jobs;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsBatchJobRunTimeInfo_struct();
       rmsBatchJobRunTimeInfo_struct(const rmsBatchJobRunTimeInfo_struct&);
       rmsBatchJobRunTimeInfo_struct& operator=(const rmsBatchJobRunTimeInfo_struct&);
       static CORBA::Info<rmsBatchJobRunTimeInfo_struct> rmsBatchJobRunTimeInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsBatchJobRunTimeInfo_struct


typedef rmsBatchJobRunTimeInfo_struct* rmsBatchJobRunTimeInfo_struct_vPtr;
typedef const rmsBatchJobRunTimeInfo_struct* rmsBatchJobRunTimeInfo_struct_cvPtr;

class  rmsBatchJobRunTimeInfo_struct_var
{
    public:

    rmsBatchJobRunTimeInfo_struct_var ();

    rmsBatchJobRunTimeInfo_struct_var (rmsBatchJobRunTimeInfo_struct *_p);

    rmsBatchJobRunTimeInfo_struct_var (const rmsBatchJobRunTimeInfo_struct_var &_s);

    rmsBatchJobRunTimeInfo_struct_var &operator= (rmsBatchJobRunTimeInfo_struct *_p);

    rmsBatchJobRunTimeInfo_struct_var &operator= (const rmsBatchJobRunTimeInfo_struct_var &_s);

    ~rmsBatchJobRunTimeInfo_struct_var ();

    rmsBatchJobRunTimeInfo_struct* operator-> ();

    const rmsBatchJobRunTimeInfo_struct& in() const;
    rmsBatchJobRunTimeInfo_struct& inout();
    rmsBatchJobRunTimeInfo_struct*& out();
    rmsBatchJobRunTimeInfo_struct* _retn();

    operator rmsBatchJobRunTimeInfo_struct_cvPtr () const;

    operator rmsBatchJobRunTimeInfo_struct_vPtr& ();

    operator const rmsBatchJobRunTimeInfo_struct& () const;

    operator rmsBatchJobRunTimeInfo_struct& ();

    protected:
    rmsBatchJobRunTimeInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsBatchJobRunTimeInfo_struct;
    typedef rmsBatchJobRunTimeInfo_struct rmsBatchJobRunTimeInfo;
    typedef rmsBatchJobRunTimeInfo_struct_var rmsBatchJobRunTimeInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsBatchJobRunTimeInfo;
    class  rmsEqpProfile_struct_var;
    struct  rmsEqpProfile_struct {
        typedef rmsEqpProfile_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem eqpSpecial;
       ::CORBA::String_StructElem email;
       ::CORBA::Boolean isInhibit;
       ::CORBA::Boolean showScientific;
       ::CORBA::Long atp;
       ::CORBA::Long batchCnt;
       ::CORBA::Boolean keyECMail;
       ::CORBA::Boolean nonKeyECMail;
       ::CORBA::Boolean nonKeyECInhibit;
       ::CORBA::Boolean ExtraItemMail;
       ::CORBA::Boolean ChangeToolStatus;
       ::CORBA::Boolean enablerms;
       ::CORBA::Boolean enableecms;
       ::CORBA::Boolean toolphaseout;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpProfile_struct();
       rmsEqpProfile_struct(const rmsEqpProfile_struct&);
       rmsEqpProfile_struct& operator=(const rmsEqpProfile_struct&);
       static CORBA::Info<rmsEqpProfile_struct> rmsEqpProfile_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsEqpProfile_struct


typedef rmsEqpProfile_struct* rmsEqpProfile_struct_vPtr;
typedef const rmsEqpProfile_struct* rmsEqpProfile_struct_cvPtr;

class  rmsEqpProfile_struct_var
{
    public:

    rmsEqpProfile_struct_var ();

    rmsEqpProfile_struct_var (rmsEqpProfile_struct *_p);

    rmsEqpProfile_struct_var (const rmsEqpProfile_struct_var &_s);

    rmsEqpProfile_struct_var &operator= (rmsEqpProfile_struct *_p);

    rmsEqpProfile_struct_var &operator= (const rmsEqpProfile_struct_var &_s);

    ~rmsEqpProfile_struct_var ();

    rmsEqpProfile_struct* operator-> ();

    const rmsEqpProfile_struct& in() const;
    rmsEqpProfile_struct& inout();
    rmsEqpProfile_struct*& out();
    rmsEqpProfile_struct* _retn();

    operator rmsEqpProfile_struct_cvPtr () const;

    operator rmsEqpProfile_struct_vPtr& ();

    operator const rmsEqpProfile_struct& () const;

    operator rmsEqpProfile_struct& ();

    protected:
    rmsEqpProfile_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpProfile_struct;
    typedef rmsEqpProfile_struct rmsEqpProfile;
    typedef rmsEqpProfile_struct_var rmsEqpProfile_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpProfile;
class  _IDL_SEQ_rmsEqpProfileSeq_0_var;
class  _IDL_SEQ_rmsEqpProfileSeq_0 {
    public:
        typedef _IDL_SEQ_rmsEqpProfileSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsEqpProfile *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsEqpProfileSeq_0 ();
    _IDL_SEQ_rmsEqpProfileSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsEqpProfileSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpProfile* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsEqpProfileSeq_0 (const _IDL_SEQ_rmsEqpProfileSeq_0&);

    ~_IDL_SEQ_rmsEqpProfileSeq_0 ();

    _IDL_SEQ_rmsEqpProfileSeq_0& operator= (const _IDL_SEQ_rmsEqpProfileSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsEqpProfile& operator [] (::CORBA::ULong indx);
    const rmsEqpProfile& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsEqpProfile* get_buffer (::CORBA::Boolean orphan=0);
    const rmsEqpProfile* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpProfile* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpProfile* src, rmsEqpProfile* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpProfile* data); 
  public:

    static rmsEqpProfile* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsEqpProfile* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsEqpProfile* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsEqpProfileSeq_0> rmsEqpProfileSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsEqpProfileSeq_0* _IDL_SEQ_rmsEqpProfileSeq_0_vPtr;
typedef const _IDL_SEQ_rmsEqpProfileSeq_0* _IDL_SEQ_rmsEqpProfileSeq_0_cvPtr;

class  _IDL_SEQ_rmsEqpProfileSeq_0_var
{
    public:

    _IDL_SEQ_rmsEqpProfileSeq_0_var ();

    _IDL_SEQ_rmsEqpProfileSeq_0_var (_IDL_SEQ_rmsEqpProfileSeq_0 *_p);

    _IDL_SEQ_rmsEqpProfileSeq_0_var (const _IDL_SEQ_rmsEqpProfileSeq_0_var &_s);

    _IDL_SEQ_rmsEqpProfileSeq_0_var &operator= (_IDL_SEQ_rmsEqpProfileSeq_0 *_p);

    _IDL_SEQ_rmsEqpProfileSeq_0_var &operator= (const _IDL_SEQ_rmsEqpProfileSeq_0_var &_s);

    ~_IDL_SEQ_rmsEqpProfileSeq_0_var ();

    _IDL_SEQ_rmsEqpProfileSeq_0* operator-> ();

    operator _IDL_SEQ_rmsEqpProfileSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsEqpProfileSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsEqpProfileSeq_0() const;

    const rmsEqpProfile& operator[] (::CORBA::ULong index) const;
    rmsEqpProfile& operator[] (::CORBA::ULong index);
    const rmsEqpProfile& operator[] (int index) const;
    rmsEqpProfile& operator[] (int index);
    const _IDL_SEQ_rmsEqpProfileSeq_0& in() const;
    _IDL_SEQ_rmsEqpProfileSeq_0& inout();
    _IDL_SEQ_rmsEqpProfileSeq_0*& out();
    _IDL_SEQ_rmsEqpProfileSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsEqpProfileSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsEqpProfileSeq_0 _rmsEqpProfileSeq_seq;
    typedef _IDL_SEQ_rmsEqpProfileSeq_0 _rmsEqpProfileSeq_seq_1;
    typedef _IDL_SEQ_rmsEqpProfileSeq_0 rmsEqpProfileSeq;
    typedef _IDL_SEQ_rmsEqpProfileSeq_0_var rmsEqpProfileSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpProfileSeq;
    class  rmsEqpProfileInqResult_struct_var;
    struct  rmsEqpProfileInqResult_struct {
        typedef rmsEqpProfileInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEqpProfileSeq profiles;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpProfileInqResult_struct();
       rmsEqpProfileInqResult_struct(const rmsEqpProfileInqResult_struct&);
       rmsEqpProfileInqResult_struct& operator=(const rmsEqpProfileInqResult_struct&);
       static CORBA::Info<rmsEqpProfileInqResult_struct> rmsEqpProfileInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpProfileInqResult_struct


typedef rmsEqpProfileInqResult_struct* rmsEqpProfileInqResult_struct_vPtr;
typedef const rmsEqpProfileInqResult_struct* rmsEqpProfileInqResult_struct_cvPtr;

class  rmsEqpProfileInqResult_struct_var
{
    public:

    rmsEqpProfileInqResult_struct_var ();

    rmsEqpProfileInqResult_struct_var (rmsEqpProfileInqResult_struct *_p);

    rmsEqpProfileInqResult_struct_var (const rmsEqpProfileInqResult_struct_var &_s);

    rmsEqpProfileInqResult_struct_var &operator= (rmsEqpProfileInqResult_struct *_p);

    rmsEqpProfileInqResult_struct_var &operator= (const rmsEqpProfileInqResult_struct_var &_s);

    ~rmsEqpProfileInqResult_struct_var ();

    rmsEqpProfileInqResult_struct* operator-> ();

    const rmsEqpProfileInqResult_struct& in() const;
    rmsEqpProfileInqResult_struct& inout();
    rmsEqpProfileInqResult_struct*& out();
    rmsEqpProfileInqResult_struct* _retn();

    operator rmsEqpProfileInqResult_struct_cvPtr () const;

    operator rmsEqpProfileInqResult_struct_vPtr& ();

    operator const rmsEqpProfileInqResult_struct& () const;

    operator rmsEqpProfileInqResult_struct& ();

    protected:
    rmsEqpProfileInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpProfileInqResult_struct;
    typedef rmsEqpProfileInqResult_struct rmsEqpProfileInqResult;
    typedef rmsEqpProfileInqResult_struct_var rmsEqpProfileInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpProfileInqResult;
    class  rmsRecipeProfile_struct_var;
    struct  rmsRecipeProfile_struct {
        typedef rmsRecipeProfile_struct_var _var_type;
       ::CORBA::String_StructElem physicalRecipeID;
       ::CORBA::Boolean displayFlag;
       ::CORBA::Boolean rmsOnly;
       ::CORBA::Boolean locked;
       ::CORBA::String_StructElem deptId;
       ::CORBA::String_StructElem email;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeProfile_struct();
       rmsRecipeProfile_struct(const rmsRecipeProfile_struct&);
       rmsRecipeProfile_struct& operator=(const rmsRecipeProfile_struct&);
       static CORBA::Info<rmsRecipeProfile_struct> rmsRecipeProfile_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRecipeProfile_struct


typedef rmsRecipeProfile_struct* rmsRecipeProfile_struct_vPtr;
typedef const rmsRecipeProfile_struct* rmsRecipeProfile_struct_cvPtr;

class  rmsRecipeProfile_struct_var
{
    public:

    rmsRecipeProfile_struct_var ();

    rmsRecipeProfile_struct_var (rmsRecipeProfile_struct *_p);

    rmsRecipeProfile_struct_var (const rmsRecipeProfile_struct_var &_s);

    rmsRecipeProfile_struct_var &operator= (rmsRecipeProfile_struct *_p);

    rmsRecipeProfile_struct_var &operator= (const rmsRecipeProfile_struct_var &_s);

    ~rmsRecipeProfile_struct_var ();

    rmsRecipeProfile_struct* operator-> ();

    const rmsRecipeProfile_struct& in() const;
    rmsRecipeProfile_struct& inout();
    rmsRecipeProfile_struct*& out();
    rmsRecipeProfile_struct* _retn();

    operator rmsRecipeProfile_struct_cvPtr () const;

    operator rmsRecipeProfile_struct_vPtr& ();

    operator const rmsRecipeProfile_struct& () const;

    operator rmsRecipeProfile_struct& ();

    protected:
    rmsRecipeProfile_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeProfile_struct;
    typedef rmsRecipeProfile_struct rmsRecipeProfile;
    typedef rmsRecipeProfile_struct_var rmsRecipeProfile_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeProfile;
class  _IDL_SEQ_rmsRecipeProfileSeq_0_var;
class  _IDL_SEQ_rmsRecipeProfileSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeProfileSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeProfile *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeProfileSeq_0 ();
    _IDL_SEQ_rmsRecipeProfileSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeProfileSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeProfile* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeProfileSeq_0 (const _IDL_SEQ_rmsRecipeProfileSeq_0&);

    ~_IDL_SEQ_rmsRecipeProfileSeq_0 ();

    _IDL_SEQ_rmsRecipeProfileSeq_0& operator= (const _IDL_SEQ_rmsRecipeProfileSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeProfile& operator [] (::CORBA::ULong indx);
    const rmsRecipeProfile& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeProfile* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeProfile* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeProfile* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeProfile* src, rmsRecipeProfile* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeProfile* data); 
  public:

    static rmsRecipeProfile* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeProfile* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeProfile* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeProfileSeq_0> rmsRecipeProfileSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeProfileSeq_0* _IDL_SEQ_rmsRecipeProfileSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeProfileSeq_0* _IDL_SEQ_rmsRecipeProfileSeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeProfileSeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeProfileSeq_0_var ();

    _IDL_SEQ_rmsRecipeProfileSeq_0_var (_IDL_SEQ_rmsRecipeProfileSeq_0 *_p);

    _IDL_SEQ_rmsRecipeProfileSeq_0_var (const _IDL_SEQ_rmsRecipeProfileSeq_0_var &_s);

    _IDL_SEQ_rmsRecipeProfileSeq_0_var &operator= (_IDL_SEQ_rmsRecipeProfileSeq_0 *_p);

    _IDL_SEQ_rmsRecipeProfileSeq_0_var &operator= (const _IDL_SEQ_rmsRecipeProfileSeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeProfileSeq_0_var ();

    _IDL_SEQ_rmsRecipeProfileSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeProfileSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeProfileSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeProfileSeq_0() const;

    const rmsRecipeProfile& operator[] (::CORBA::ULong index) const;
    rmsRecipeProfile& operator[] (::CORBA::ULong index);
    const rmsRecipeProfile& operator[] (int index) const;
    rmsRecipeProfile& operator[] (int index);
    const _IDL_SEQ_rmsRecipeProfileSeq_0& in() const;
    _IDL_SEQ_rmsRecipeProfileSeq_0& inout();
    _IDL_SEQ_rmsRecipeProfileSeq_0*& out();
    _IDL_SEQ_rmsRecipeProfileSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeProfileSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeProfileSeq_0 _rmsRecipeProfileSeq_seq;
    typedef _IDL_SEQ_rmsRecipeProfileSeq_0 _rmsRecipeProfileSeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeProfileSeq_0 rmsRecipeProfileSeq;
    typedef _IDL_SEQ_rmsRecipeProfileSeq_0_var rmsRecipeProfileSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeProfileSeq;
    class  rmsRecipeProfileInqResult_struct_var;
    struct  rmsRecipeProfileInqResult_struct {
        typedef rmsRecipeProfileInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeProfileSeq profiles;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeProfileInqResult_struct();
       rmsRecipeProfileInqResult_struct(const rmsRecipeProfileInqResult_struct&);
       rmsRecipeProfileInqResult_struct& operator=(const rmsRecipeProfileInqResult_struct&);
       static CORBA::Info<rmsRecipeProfileInqResult_struct> rmsRecipeProfileInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeProfileInqResult_struct


typedef rmsRecipeProfileInqResult_struct* rmsRecipeProfileInqResult_struct_vPtr;
typedef const rmsRecipeProfileInqResult_struct* rmsRecipeProfileInqResult_struct_cvPtr;

class  rmsRecipeProfileInqResult_struct_var
{
    public:

    rmsRecipeProfileInqResult_struct_var ();

    rmsRecipeProfileInqResult_struct_var (rmsRecipeProfileInqResult_struct *_p);

    rmsRecipeProfileInqResult_struct_var (const rmsRecipeProfileInqResult_struct_var &_s);

    rmsRecipeProfileInqResult_struct_var &operator= (rmsRecipeProfileInqResult_struct *_p);

    rmsRecipeProfileInqResult_struct_var &operator= (const rmsRecipeProfileInqResult_struct_var &_s);

    ~rmsRecipeProfileInqResult_struct_var ();

    rmsRecipeProfileInqResult_struct* operator-> ();

    const rmsRecipeProfileInqResult_struct& in() const;
    rmsRecipeProfileInqResult_struct& inout();
    rmsRecipeProfileInqResult_struct*& out();
    rmsRecipeProfileInqResult_struct* _retn();

    operator rmsRecipeProfileInqResult_struct_cvPtr () const;

    operator rmsRecipeProfileInqResult_struct_vPtr& ();

    operator const rmsRecipeProfileInqResult_struct& () const;

    operator rmsRecipeProfileInqResult_struct& ();

    protected:
    rmsRecipeProfileInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeProfileInqResult_struct;
    typedef rmsRecipeProfileInqResult_struct rmsRecipeProfileInqResult;
    typedef rmsRecipeProfileInqResult_struct_var rmsRecipeProfileInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeProfileInqResult;
    class  rmsAuditFailInfo_struct_var;
    struct  rmsAuditFailInfo_struct {
        typedef rmsAuditFailInfo_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem claim_date;
       ::CORBA::Long count;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsAuditFailInfo_struct();
       rmsAuditFailInfo_struct(const rmsAuditFailInfo_struct&);
       rmsAuditFailInfo_struct& operator=(const rmsAuditFailInfo_struct&);
       static CORBA::Info<rmsAuditFailInfo_struct> rmsAuditFailInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsAuditFailInfo_struct


typedef rmsAuditFailInfo_struct* rmsAuditFailInfo_struct_vPtr;
typedef const rmsAuditFailInfo_struct* rmsAuditFailInfo_struct_cvPtr;

class  rmsAuditFailInfo_struct_var
{
    public:

    rmsAuditFailInfo_struct_var ();

    rmsAuditFailInfo_struct_var (rmsAuditFailInfo_struct *_p);

    rmsAuditFailInfo_struct_var (const rmsAuditFailInfo_struct_var &_s);

    rmsAuditFailInfo_struct_var &operator= (rmsAuditFailInfo_struct *_p);

    rmsAuditFailInfo_struct_var &operator= (const rmsAuditFailInfo_struct_var &_s);

    ~rmsAuditFailInfo_struct_var ();

    rmsAuditFailInfo_struct* operator-> ();

    const rmsAuditFailInfo_struct& in() const;
    rmsAuditFailInfo_struct& inout();
    rmsAuditFailInfo_struct*& out();
    rmsAuditFailInfo_struct* _retn();

    operator rmsAuditFailInfo_struct_cvPtr () const;

    operator rmsAuditFailInfo_struct_vPtr& ();

    operator const rmsAuditFailInfo_struct& () const;

    operator rmsAuditFailInfo_struct& ();

    protected:
    rmsAuditFailInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsAuditFailInfo_struct;
    typedef rmsAuditFailInfo_struct rmsAuditFailInfo;
    typedef rmsAuditFailInfo_struct_var rmsAuditFailInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsAuditFailInfo;
class  _IDL_SEQ_rmsAuditFailInfoSeq_0_var;
class  _IDL_SEQ_rmsAuditFailInfoSeq_0 {
    public:
        typedef _IDL_SEQ_rmsAuditFailInfoSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsAuditFailInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsAuditFailInfoSeq_0 ();
    _IDL_SEQ_rmsAuditFailInfoSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsAuditFailInfoSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsAuditFailInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsAuditFailInfoSeq_0 (const _IDL_SEQ_rmsAuditFailInfoSeq_0&);

    ~_IDL_SEQ_rmsAuditFailInfoSeq_0 ();

    _IDL_SEQ_rmsAuditFailInfoSeq_0& operator= (const _IDL_SEQ_rmsAuditFailInfoSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsAuditFailInfo& operator [] (::CORBA::ULong indx);
    const rmsAuditFailInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsAuditFailInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsAuditFailInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsAuditFailInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsAuditFailInfo* src, rmsAuditFailInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsAuditFailInfo* data); 
  public:

    static rmsAuditFailInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsAuditFailInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsAuditFailInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsAuditFailInfoSeq_0> rmsAuditFailInfoSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsAuditFailInfoSeq_0* _IDL_SEQ_rmsAuditFailInfoSeq_0_vPtr;
typedef const _IDL_SEQ_rmsAuditFailInfoSeq_0* _IDL_SEQ_rmsAuditFailInfoSeq_0_cvPtr;

class  _IDL_SEQ_rmsAuditFailInfoSeq_0_var
{
    public:

    _IDL_SEQ_rmsAuditFailInfoSeq_0_var ();

    _IDL_SEQ_rmsAuditFailInfoSeq_0_var (_IDL_SEQ_rmsAuditFailInfoSeq_0 *_p);

    _IDL_SEQ_rmsAuditFailInfoSeq_0_var (const _IDL_SEQ_rmsAuditFailInfoSeq_0_var &_s);

    _IDL_SEQ_rmsAuditFailInfoSeq_0_var &operator= (_IDL_SEQ_rmsAuditFailInfoSeq_0 *_p);

    _IDL_SEQ_rmsAuditFailInfoSeq_0_var &operator= (const _IDL_SEQ_rmsAuditFailInfoSeq_0_var &_s);

    ~_IDL_SEQ_rmsAuditFailInfoSeq_0_var ();

    _IDL_SEQ_rmsAuditFailInfoSeq_0* operator-> ();

    operator _IDL_SEQ_rmsAuditFailInfoSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsAuditFailInfoSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsAuditFailInfoSeq_0() const;

    const rmsAuditFailInfo& operator[] (::CORBA::ULong index) const;
    rmsAuditFailInfo& operator[] (::CORBA::ULong index);
    const rmsAuditFailInfo& operator[] (int index) const;
    rmsAuditFailInfo& operator[] (int index);
    const _IDL_SEQ_rmsAuditFailInfoSeq_0& in() const;
    _IDL_SEQ_rmsAuditFailInfoSeq_0& inout();
    _IDL_SEQ_rmsAuditFailInfoSeq_0*& out();
    _IDL_SEQ_rmsAuditFailInfoSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsAuditFailInfoSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsAuditFailInfoSeq_0 _rmsAuditFailInfoSeq_seq;
    typedef _IDL_SEQ_rmsAuditFailInfoSeq_0 _rmsAuditFailInfoSeq_seq_1;
    typedef _IDL_SEQ_rmsAuditFailInfoSeq_0 rmsAuditFailInfoSeq;
    typedef _IDL_SEQ_rmsAuditFailInfoSeq_0_var rmsAuditFailInfoSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsAuditFailInfoSeq;
    class  rmsAuditFailInfoInqResult_struct_var;
    struct  rmsAuditFailInfoInqResult_struct {
        typedef rmsAuditFailInfoInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsAuditFailInfoSeq auditFailInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsAuditFailInfoInqResult_struct();
       rmsAuditFailInfoInqResult_struct(const rmsAuditFailInfoInqResult_struct&);
       rmsAuditFailInfoInqResult_struct& operator=(const rmsAuditFailInfoInqResult_struct&);
       static CORBA::Info<rmsAuditFailInfoInqResult_struct> rmsAuditFailInfoInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsAuditFailInfoInqResult_struct


typedef rmsAuditFailInfoInqResult_struct* rmsAuditFailInfoInqResult_struct_vPtr;
typedef const rmsAuditFailInfoInqResult_struct* rmsAuditFailInfoInqResult_struct_cvPtr;

class  rmsAuditFailInfoInqResult_struct_var
{
    public:

    rmsAuditFailInfoInqResult_struct_var ();

    rmsAuditFailInfoInqResult_struct_var (rmsAuditFailInfoInqResult_struct *_p);

    rmsAuditFailInfoInqResult_struct_var (const rmsAuditFailInfoInqResult_struct_var &_s);

    rmsAuditFailInfoInqResult_struct_var &operator= (rmsAuditFailInfoInqResult_struct *_p);

    rmsAuditFailInfoInqResult_struct_var &operator= (const rmsAuditFailInfoInqResult_struct_var &_s);

    ~rmsAuditFailInfoInqResult_struct_var ();

    rmsAuditFailInfoInqResult_struct* operator-> ();

    const rmsAuditFailInfoInqResult_struct& in() const;
    rmsAuditFailInfoInqResult_struct& inout();
    rmsAuditFailInfoInqResult_struct*& out();
    rmsAuditFailInfoInqResult_struct* _retn();

    operator rmsAuditFailInfoInqResult_struct_cvPtr () const;

    operator rmsAuditFailInfoInqResult_struct_vPtr& ();

    operator const rmsAuditFailInfoInqResult_struct& () const;

    operator rmsAuditFailInfoInqResult_struct& ();

    protected:
    rmsAuditFailInfoInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsAuditFailInfoInqResult_struct;
    typedef rmsAuditFailInfoInqResult_struct rmsAuditFailInfoInqResult;
    typedef rmsAuditFailInfoInqResult_struct_var rmsAuditFailInfoInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsAuditFailInfoInqResult;
    class  rmsReGoldenInfo_struct_var;
    struct  rmsReGoldenInfo_struct {
        typedef rmsReGoldenInfo_struct_var _var_type;
       ::CORBA::String_StructElem reason_code;
       ::CORBA::Long count;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsReGoldenInfo_struct();
       rmsReGoldenInfo_struct(const rmsReGoldenInfo_struct&);
       rmsReGoldenInfo_struct& operator=(const rmsReGoldenInfo_struct&);
       static CORBA::Info<rmsReGoldenInfo_struct> rmsReGoldenInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsReGoldenInfo_struct


typedef rmsReGoldenInfo_struct* rmsReGoldenInfo_struct_vPtr;
typedef const rmsReGoldenInfo_struct* rmsReGoldenInfo_struct_cvPtr;

class  rmsReGoldenInfo_struct_var
{
    public:

    rmsReGoldenInfo_struct_var ();

    rmsReGoldenInfo_struct_var (rmsReGoldenInfo_struct *_p);

    rmsReGoldenInfo_struct_var (const rmsReGoldenInfo_struct_var &_s);

    rmsReGoldenInfo_struct_var &operator= (rmsReGoldenInfo_struct *_p);

    rmsReGoldenInfo_struct_var &operator= (const rmsReGoldenInfo_struct_var &_s);

    ~rmsReGoldenInfo_struct_var ();

    rmsReGoldenInfo_struct* operator-> ();

    const rmsReGoldenInfo_struct& in() const;
    rmsReGoldenInfo_struct& inout();
    rmsReGoldenInfo_struct*& out();
    rmsReGoldenInfo_struct* _retn();

    operator rmsReGoldenInfo_struct_cvPtr () const;

    operator rmsReGoldenInfo_struct_vPtr& ();

    operator const rmsReGoldenInfo_struct& () const;

    operator rmsReGoldenInfo_struct& ();

    protected:
    rmsReGoldenInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsReGoldenInfo_struct;
    typedef rmsReGoldenInfo_struct rmsReGoldenInfo;
    typedef rmsReGoldenInfo_struct_var rmsReGoldenInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsReGoldenInfo;
class  _IDL_SEQ_rmsReGoldenInfoSeq_0_var;
class  _IDL_SEQ_rmsReGoldenInfoSeq_0 {
    public:
        typedef _IDL_SEQ_rmsReGoldenInfoSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsReGoldenInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsReGoldenInfoSeq_0 ();
    _IDL_SEQ_rmsReGoldenInfoSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsReGoldenInfoSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsReGoldenInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsReGoldenInfoSeq_0 (const _IDL_SEQ_rmsReGoldenInfoSeq_0&);

    ~_IDL_SEQ_rmsReGoldenInfoSeq_0 ();

    _IDL_SEQ_rmsReGoldenInfoSeq_0& operator= (const _IDL_SEQ_rmsReGoldenInfoSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsReGoldenInfo& operator [] (::CORBA::ULong indx);
    const rmsReGoldenInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsReGoldenInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsReGoldenInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsReGoldenInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsReGoldenInfo* src, rmsReGoldenInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsReGoldenInfo* data); 
  public:

    static rmsReGoldenInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsReGoldenInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsReGoldenInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsReGoldenInfoSeq_0> rmsReGoldenInfoSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsReGoldenInfoSeq_0* _IDL_SEQ_rmsReGoldenInfoSeq_0_vPtr;
typedef const _IDL_SEQ_rmsReGoldenInfoSeq_0* _IDL_SEQ_rmsReGoldenInfoSeq_0_cvPtr;

class  _IDL_SEQ_rmsReGoldenInfoSeq_0_var
{
    public:

    _IDL_SEQ_rmsReGoldenInfoSeq_0_var ();

    _IDL_SEQ_rmsReGoldenInfoSeq_0_var (_IDL_SEQ_rmsReGoldenInfoSeq_0 *_p);

    _IDL_SEQ_rmsReGoldenInfoSeq_0_var (const _IDL_SEQ_rmsReGoldenInfoSeq_0_var &_s);

    _IDL_SEQ_rmsReGoldenInfoSeq_0_var &operator= (_IDL_SEQ_rmsReGoldenInfoSeq_0 *_p);

    _IDL_SEQ_rmsReGoldenInfoSeq_0_var &operator= (const _IDL_SEQ_rmsReGoldenInfoSeq_0_var &_s);

    ~_IDL_SEQ_rmsReGoldenInfoSeq_0_var ();

    _IDL_SEQ_rmsReGoldenInfoSeq_0* operator-> ();

    operator _IDL_SEQ_rmsReGoldenInfoSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsReGoldenInfoSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsReGoldenInfoSeq_0() const;

    const rmsReGoldenInfo& operator[] (::CORBA::ULong index) const;
    rmsReGoldenInfo& operator[] (::CORBA::ULong index);
    const rmsReGoldenInfo& operator[] (int index) const;
    rmsReGoldenInfo& operator[] (int index);
    const _IDL_SEQ_rmsReGoldenInfoSeq_0& in() const;
    _IDL_SEQ_rmsReGoldenInfoSeq_0& inout();
    _IDL_SEQ_rmsReGoldenInfoSeq_0*& out();
    _IDL_SEQ_rmsReGoldenInfoSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsReGoldenInfoSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsReGoldenInfoSeq_0 _rmsReGoldenInfoSeq_seq;
    typedef _IDL_SEQ_rmsReGoldenInfoSeq_0 _rmsReGoldenInfoSeq_seq_1;
    typedef _IDL_SEQ_rmsReGoldenInfoSeq_0 rmsReGoldenInfoSeq;
    typedef _IDL_SEQ_rmsReGoldenInfoSeq_0_var rmsReGoldenInfoSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsReGoldenInfoSeq;
    class  rmsReGoldenInfoInqResult_struct_var;
    struct  rmsReGoldenInfoInqResult_struct {
        typedef rmsReGoldenInfoInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsReGoldenInfoSeq reGoldenInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsReGoldenInfoInqResult_struct();
       rmsReGoldenInfoInqResult_struct(const rmsReGoldenInfoInqResult_struct&);
       rmsReGoldenInfoInqResult_struct& operator=(const rmsReGoldenInfoInqResult_struct&);
       static CORBA::Info<rmsReGoldenInfoInqResult_struct> rmsReGoldenInfoInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsReGoldenInfoInqResult_struct


typedef rmsReGoldenInfoInqResult_struct* rmsReGoldenInfoInqResult_struct_vPtr;
typedef const rmsReGoldenInfoInqResult_struct* rmsReGoldenInfoInqResult_struct_cvPtr;

class  rmsReGoldenInfoInqResult_struct_var
{
    public:

    rmsReGoldenInfoInqResult_struct_var ();

    rmsReGoldenInfoInqResult_struct_var (rmsReGoldenInfoInqResult_struct *_p);

    rmsReGoldenInfoInqResult_struct_var (const rmsReGoldenInfoInqResult_struct_var &_s);

    rmsReGoldenInfoInqResult_struct_var &operator= (rmsReGoldenInfoInqResult_struct *_p);

    rmsReGoldenInfoInqResult_struct_var &operator= (const rmsReGoldenInfoInqResult_struct_var &_s);

    ~rmsReGoldenInfoInqResult_struct_var ();

    rmsReGoldenInfoInqResult_struct* operator-> ();

    const rmsReGoldenInfoInqResult_struct& in() const;
    rmsReGoldenInfoInqResult_struct& inout();
    rmsReGoldenInfoInqResult_struct*& out();
    rmsReGoldenInfoInqResult_struct* _retn();

    operator rmsReGoldenInfoInqResult_struct_cvPtr () const;

    operator rmsReGoldenInfoInqResult_struct_vPtr& ();

    operator const rmsReGoldenInfoInqResult_struct& () const;

    operator rmsReGoldenInfoInqResult_struct& ();

    protected:
    rmsReGoldenInfoInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsReGoldenInfoInqResult_struct;
    typedef rmsReGoldenInfoInqResult_struct rmsReGoldenInfoInqResult;
    typedef rmsReGoldenInfoInqResult_struct_var rmsReGoldenInfoInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsReGoldenInfoInqResult;
    class  rmsEnvVariable_struct_var;
    struct  rmsEnvVariable_struct {
        typedef rmsEnvVariable_struct_var _var_type;
       ::CORBA::String_StructElem name;
       ::CORBA::String_StructElem value;
       ::CORBA::Long length;
       ::CORBA::Boolean canNotChange;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEnvVariable_struct();
       rmsEnvVariable_struct(const rmsEnvVariable_struct&);
       rmsEnvVariable_struct& operator=(const rmsEnvVariable_struct&);
       static CORBA::Info<rmsEnvVariable_struct> rmsEnvVariable_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsEnvVariable_struct


typedef rmsEnvVariable_struct* rmsEnvVariable_struct_vPtr;
typedef const rmsEnvVariable_struct* rmsEnvVariable_struct_cvPtr;

class  rmsEnvVariable_struct_var
{
    public:

    rmsEnvVariable_struct_var ();

    rmsEnvVariable_struct_var (rmsEnvVariable_struct *_p);

    rmsEnvVariable_struct_var (const rmsEnvVariable_struct_var &_s);

    rmsEnvVariable_struct_var &operator= (rmsEnvVariable_struct *_p);

    rmsEnvVariable_struct_var &operator= (const rmsEnvVariable_struct_var &_s);

    ~rmsEnvVariable_struct_var ();

    rmsEnvVariable_struct* operator-> ();

    const rmsEnvVariable_struct& in() const;
    rmsEnvVariable_struct& inout();
    rmsEnvVariable_struct*& out();
    rmsEnvVariable_struct* _retn();

    operator rmsEnvVariable_struct_cvPtr () const;

    operator rmsEnvVariable_struct_vPtr& ();

    operator const rmsEnvVariable_struct& () const;

    operator rmsEnvVariable_struct& ();

    protected:
    rmsEnvVariable_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEnvVariable_struct;
    typedef rmsEnvVariable_struct rmsEnvVariable;
    typedef rmsEnvVariable_struct_var rmsEnvVariable_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEnvVariable;
class  _IDL_SEQ_rmsEnvVariableSeq_0_var;
class  _IDL_SEQ_rmsEnvVariableSeq_0 {
    public:
        typedef _IDL_SEQ_rmsEnvVariableSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsEnvVariable *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsEnvVariableSeq_0 ();
    _IDL_SEQ_rmsEnvVariableSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsEnvVariableSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsEnvVariable* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsEnvVariableSeq_0 (const _IDL_SEQ_rmsEnvVariableSeq_0&);

    ~_IDL_SEQ_rmsEnvVariableSeq_0 ();

    _IDL_SEQ_rmsEnvVariableSeq_0& operator= (const _IDL_SEQ_rmsEnvVariableSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsEnvVariable& operator [] (::CORBA::ULong indx);
    const rmsEnvVariable& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsEnvVariable* get_buffer (::CORBA::Boolean orphan=0);
    const rmsEnvVariable* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsEnvVariable* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEnvVariable* src, rmsEnvVariable* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEnvVariable* data); 
  public:

    static rmsEnvVariable* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsEnvVariable* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsEnvVariable* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsEnvVariableSeq_0> rmsEnvVariableSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsEnvVariableSeq_0* _IDL_SEQ_rmsEnvVariableSeq_0_vPtr;
typedef const _IDL_SEQ_rmsEnvVariableSeq_0* _IDL_SEQ_rmsEnvVariableSeq_0_cvPtr;

class  _IDL_SEQ_rmsEnvVariableSeq_0_var
{
    public:

    _IDL_SEQ_rmsEnvVariableSeq_0_var ();

    _IDL_SEQ_rmsEnvVariableSeq_0_var (_IDL_SEQ_rmsEnvVariableSeq_0 *_p);

    _IDL_SEQ_rmsEnvVariableSeq_0_var (const _IDL_SEQ_rmsEnvVariableSeq_0_var &_s);

    _IDL_SEQ_rmsEnvVariableSeq_0_var &operator= (_IDL_SEQ_rmsEnvVariableSeq_0 *_p);

    _IDL_SEQ_rmsEnvVariableSeq_0_var &operator= (const _IDL_SEQ_rmsEnvVariableSeq_0_var &_s);

    ~_IDL_SEQ_rmsEnvVariableSeq_0_var ();

    _IDL_SEQ_rmsEnvVariableSeq_0* operator-> ();

    operator _IDL_SEQ_rmsEnvVariableSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsEnvVariableSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsEnvVariableSeq_0() const;

    const rmsEnvVariable& operator[] (::CORBA::ULong index) const;
    rmsEnvVariable& operator[] (::CORBA::ULong index);
    const rmsEnvVariable& operator[] (int index) const;
    rmsEnvVariable& operator[] (int index);
    const _IDL_SEQ_rmsEnvVariableSeq_0& in() const;
    _IDL_SEQ_rmsEnvVariableSeq_0& inout();
    _IDL_SEQ_rmsEnvVariableSeq_0*& out();
    _IDL_SEQ_rmsEnvVariableSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsEnvVariableSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsEnvVariableSeq_0 _rmsEnvVariableSeq_seq;
    typedef _IDL_SEQ_rmsEnvVariableSeq_0 _rmsEnvVariableSeq_seq_1;
    typedef _IDL_SEQ_rmsEnvVariableSeq_0 rmsEnvVariableSeq;
    typedef _IDL_SEQ_rmsEnvVariableSeq_0_var rmsEnvVariableSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEnvVariableSeq;
    class  rmsEnvVariableInqResult_struct_var;
    struct  rmsEnvVariableInqResult_struct {
        typedef rmsEnvVariableInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEnvVariableSeq vars;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEnvVariableInqResult_struct();
       rmsEnvVariableInqResult_struct(const rmsEnvVariableInqResult_struct&);
       rmsEnvVariableInqResult_struct& operator=(const rmsEnvVariableInqResult_struct&);
       static CORBA::Info<rmsEnvVariableInqResult_struct> rmsEnvVariableInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEnvVariableInqResult_struct


typedef rmsEnvVariableInqResult_struct* rmsEnvVariableInqResult_struct_vPtr;
typedef const rmsEnvVariableInqResult_struct* rmsEnvVariableInqResult_struct_cvPtr;

class  rmsEnvVariableInqResult_struct_var
{
    public:

    rmsEnvVariableInqResult_struct_var ();

    rmsEnvVariableInqResult_struct_var (rmsEnvVariableInqResult_struct *_p);

    rmsEnvVariableInqResult_struct_var (const rmsEnvVariableInqResult_struct_var &_s);

    rmsEnvVariableInqResult_struct_var &operator= (rmsEnvVariableInqResult_struct *_p);

    rmsEnvVariableInqResult_struct_var &operator= (const rmsEnvVariableInqResult_struct_var &_s);

    ~rmsEnvVariableInqResult_struct_var ();

    rmsEnvVariableInqResult_struct* operator-> ();

    const rmsEnvVariableInqResult_struct& in() const;
    rmsEnvVariableInqResult_struct& inout();
    rmsEnvVariableInqResult_struct*& out();
    rmsEnvVariableInqResult_struct* _retn();

    operator rmsEnvVariableInqResult_struct_cvPtr () const;

    operator rmsEnvVariableInqResult_struct_vPtr& ();

    operator const rmsEnvVariableInqResult_struct& () const;

    operator rmsEnvVariableInqResult_struct& ();

    protected:
    rmsEnvVariableInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEnvVariableInqResult_struct;
    typedef rmsEnvVariableInqResult_struct rmsEnvVariableInqResult;
    typedef rmsEnvVariableInqResult_struct_var rmsEnvVariableInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEnvVariableInqResult;
    class  rmsParentRecipe_struct_var;
    struct  rmsParentRecipe_struct {
        typedef rmsParentRecipe_struct_var _var_type;
       ::CORBA::String_StructElem PhysicalRecipeId;
       ::CORBA::String_StructElem MachineRecipeId;
       ::CORBA::Boolean uploaded;
       ::CORBA::Boolean goldenExist;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsParentRecipe_struct();
       rmsParentRecipe_struct(const rmsParentRecipe_struct&);
       rmsParentRecipe_struct& operator=(const rmsParentRecipe_struct&);
       static CORBA::Info<rmsParentRecipe_struct> rmsParentRecipe_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsParentRecipe_struct


typedef rmsParentRecipe_struct* rmsParentRecipe_struct_vPtr;
typedef const rmsParentRecipe_struct* rmsParentRecipe_struct_cvPtr;

class  rmsParentRecipe_struct_var
{
    public:

    rmsParentRecipe_struct_var ();

    rmsParentRecipe_struct_var (rmsParentRecipe_struct *_p);

    rmsParentRecipe_struct_var (const rmsParentRecipe_struct_var &_s);

    rmsParentRecipe_struct_var &operator= (rmsParentRecipe_struct *_p);

    rmsParentRecipe_struct_var &operator= (const rmsParentRecipe_struct_var &_s);

    ~rmsParentRecipe_struct_var ();

    rmsParentRecipe_struct* operator-> ();

    const rmsParentRecipe_struct& in() const;
    rmsParentRecipe_struct& inout();
    rmsParentRecipe_struct*& out();
    rmsParentRecipe_struct* _retn();

    operator rmsParentRecipe_struct_cvPtr () const;

    operator rmsParentRecipe_struct_vPtr& ();

    operator const rmsParentRecipe_struct& () const;

    operator rmsParentRecipe_struct& ();

    protected:
    rmsParentRecipe_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsParentRecipe_struct;
    typedef rmsParentRecipe_struct rmsParentRecipe;
    typedef rmsParentRecipe_struct_var rmsParentRecipe_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsParentRecipe;
class  _IDL_SEQ_rmsParentRecipeSeq_0_var;
class  _IDL_SEQ_rmsParentRecipeSeq_0 {
    public:
        typedef _IDL_SEQ_rmsParentRecipeSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsParentRecipe *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsParentRecipeSeq_0 ();
    _IDL_SEQ_rmsParentRecipeSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsParentRecipeSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsParentRecipe* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsParentRecipeSeq_0 (const _IDL_SEQ_rmsParentRecipeSeq_0&);

    ~_IDL_SEQ_rmsParentRecipeSeq_0 ();

    _IDL_SEQ_rmsParentRecipeSeq_0& operator= (const _IDL_SEQ_rmsParentRecipeSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsParentRecipe& operator [] (::CORBA::ULong indx);
    const rmsParentRecipe& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsParentRecipe* get_buffer (::CORBA::Boolean orphan=0);
    const rmsParentRecipe* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsParentRecipe* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsParentRecipe* src, rmsParentRecipe* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsParentRecipe* data); 
  public:

    static rmsParentRecipe* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsParentRecipe* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsParentRecipe* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsParentRecipeSeq_0> rmsParentRecipeSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsParentRecipeSeq_0* _IDL_SEQ_rmsParentRecipeSeq_0_vPtr;
typedef const _IDL_SEQ_rmsParentRecipeSeq_0* _IDL_SEQ_rmsParentRecipeSeq_0_cvPtr;

class  _IDL_SEQ_rmsParentRecipeSeq_0_var
{
    public:

    _IDL_SEQ_rmsParentRecipeSeq_0_var ();

    _IDL_SEQ_rmsParentRecipeSeq_0_var (_IDL_SEQ_rmsParentRecipeSeq_0 *_p);

    _IDL_SEQ_rmsParentRecipeSeq_0_var (const _IDL_SEQ_rmsParentRecipeSeq_0_var &_s);

    _IDL_SEQ_rmsParentRecipeSeq_0_var &operator= (_IDL_SEQ_rmsParentRecipeSeq_0 *_p);

    _IDL_SEQ_rmsParentRecipeSeq_0_var &operator= (const _IDL_SEQ_rmsParentRecipeSeq_0_var &_s);

    ~_IDL_SEQ_rmsParentRecipeSeq_0_var ();

    _IDL_SEQ_rmsParentRecipeSeq_0* operator-> ();

    operator _IDL_SEQ_rmsParentRecipeSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsParentRecipeSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsParentRecipeSeq_0() const;

    const rmsParentRecipe& operator[] (::CORBA::ULong index) const;
    rmsParentRecipe& operator[] (::CORBA::ULong index);
    const rmsParentRecipe& operator[] (int index) const;
    rmsParentRecipe& operator[] (int index);
    const _IDL_SEQ_rmsParentRecipeSeq_0& in() const;
    _IDL_SEQ_rmsParentRecipeSeq_0& inout();
    _IDL_SEQ_rmsParentRecipeSeq_0*& out();
    _IDL_SEQ_rmsParentRecipeSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsParentRecipeSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsParentRecipeSeq_0 _rmsParentRecipeSeq_seq;
    typedef _IDL_SEQ_rmsParentRecipeSeq_0 _rmsParentRecipeSeq_seq_1;
    typedef _IDL_SEQ_rmsParentRecipeSeq_0 rmsParentRecipeSeq;
    typedef _IDL_SEQ_rmsParentRecipeSeq_0_var rmsParentRecipeSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsParentRecipeSeq;
    class  rmsParentRecipeSeqResult_struct_var;
    struct  rmsParentRecipeSeqResult_struct {
        typedef rmsParentRecipeSeqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem recipeId;
       ::rmsParentRecipeSeq rmsParentRecipeList;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsParentRecipeSeqResult_struct();
       rmsParentRecipeSeqResult_struct(const rmsParentRecipeSeqResult_struct&);
       rmsParentRecipeSeqResult_struct& operator=(const rmsParentRecipeSeqResult_struct&);
       static CORBA::Info<rmsParentRecipeSeqResult_struct> rmsParentRecipeSeqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsParentRecipeSeqResult_struct


typedef rmsParentRecipeSeqResult_struct* rmsParentRecipeSeqResult_struct_vPtr;
typedef const rmsParentRecipeSeqResult_struct* rmsParentRecipeSeqResult_struct_cvPtr;

class  rmsParentRecipeSeqResult_struct_var
{
    public:

    rmsParentRecipeSeqResult_struct_var ();

    rmsParentRecipeSeqResult_struct_var (rmsParentRecipeSeqResult_struct *_p);

    rmsParentRecipeSeqResult_struct_var (const rmsParentRecipeSeqResult_struct_var &_s);

    rmsParentRecipeSeqResult_struct_var &operator= (rmsParentRecipeSeqResult_struct *_p);

    rmsParentRecipeSeqResult_struct_var &operator= (const rmsParentRecipeSeqResult_struct_var &_s);

    ~rmsParentRecipeSeqResult_struct_var ();

    rmsParentRecipeSeqResult_struct* operator-> ();

    const rmsParentRecipeSeqResult_struct& in() const;
    rmsParentRecipeSeqResult_struct& inout();
    rmsParentRecipeSeqResult_struct*& out();
    rmsParentRecipeSeqResult_struct* _retn();

    operator rmsParentRecipeSeqResult_struct_cvPtr () const;

    operator rmsParentRecipeSeqResult_struct_vPtr& ();

    operator const rmsParentRecipeSeqResult_struct& () const;

    operator rmsParentRecipeSeqResult_struct& ();

    protected:
    rmsParentRecipeSeqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsParentRecipeSeqResult_struct;
    typedef rmsParentRecipeSeqResult_struct rmsParentRecipeSeqResult;
    typedef rmsParentRecipeSeqResult_struct_var rmsParentRecipeSeqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsParentRecipeSeqResult;
    class  rmsRecipeNode_struct_var;
    struct  rmsRecipeNode_struct {
        typedef rmsRecipeNode_struct_var _var_type;
       ::CORBA::String_StructElem recipeId;
       ::CORBA::Boolean uploaded;
       ::CORBA::Boolean goldenExist;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeNode_struct();
       rmsRecipeNode_struct(const rmsRecipeNode_struct&);
       rmsRecipeNode_struct& operator=(const rmsRecipeNode_struct&);
       static CORBA::Info<rmsRecipeNode_struct> rmsRecipeNode_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRecipeNode_struct


typedef rmsRecipeNode_struct* rmsRecipeNode_struct_vPtr;
typedef const rmsRecipeNode_struct* rmsRecipeNode_struct_cvPtr;

class  rmsRecipeNode_struct_var
{
    public:

    rmsRecipeNode_struct_var ();

    rmsRecipeNode_struct_var (rmsRecipeNode_struct *_p);

    rmsRecipeNode_struct_var (const rmsRecipeNode_struct_var &_s);

    rmsRecipeNode_struct_var &operator= (rmsRecipeNode_struct *_p);

    rmsRecipeNode_struct_var &operator= (const rmsRecipeNode_struct_var &_s);

    ~rmsRecipeNode_struct_var ();

    rmsRecipeNode_struct* operator-> ();

    const rmsRecipeNode_struct& in() const;
    rmsRecipeNode_struct& inout();
    rmsRecipeNode_struct*& out();
    rmsRecipeNode_struct* _retn();

    operator rmsRecipeNode_struct_cvPtr () const;

    operator rmsRecipeNode_struct_vPtr& ();

    operator const rmsRecipeNode_struct& () const;

    operator rmsRecipeNode_struct& ();

    protected:
    rmsRecipeNode_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeNode_struct;
    typedef rmsRecipeNode_struct rmsRecipeNode;
    typedef rmsRecipeNode_struct_var rmsRecipeNode_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeNode;
class  _IDL_SEQ_rmsRecipeNodeSeq_0_var;
class  _IDL_SEQ_rmsRecipeNodeSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeNodeSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeNode *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeNodeSeq_0 ();
    _IDL_SEQ_rmsRecipeNodeSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeNodeSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeNode* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeNodeSeq_0 (const _IDL_SEQ_rmsRecipeNodeSeq_0&);

    ~_IDL_SEQ_rmsRecipeNodeSeq_0 ();

    _IDL_SEQ_rmsRecipeNodeSeq_0& operator= (const _IDL_SEQ_rmsRecipeNodeSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeNode& operator [] (::CORBA::ULong indx);
    const rmsRecipeNode& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeNode* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeNode* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeNode* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeNode* src, rmsRecipeNode* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeNode* data); 
  public:

    static rmsRecipeNode* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeNode* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeNode* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeNodeSeq_0> rmsRecipeNodeSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeNodeSeq_0* _IDL_SEQ_rmsRecipeNodeSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeNodeSeq_0* _IDL_SEQ_rmsRecipeNodeSeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeNodeSeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeNodeSeq_0_var ();

    _IDL_SEQ_rmsRecipeNodeSeq_0_var (_IDL_SEQ_rmsRecipeNodeSeq_0 *_p);

    _IDL_SEQ_rmsRecipeNodeSeq_0_var (const _IDL_SEQ_rmsRecipeNodeSeq_0_var &_s);

    _IDL_SEQ_rmsRecipeNodeSeq_0_var &operator= (_IDL_SEQ_rmsRecipeNodeSeq_0 *_p);

    _IDL_SEQ_rmsRecipeNodeSeq_0_var &operator= (const _IDL_SEQ_rmsRecipeNodeSeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeNodeSeq_0_var ();

    _IDL_SEQ_rmsRecipeNodeSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeNodeSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeNodeSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeNodeSeq_0() const;

    const rmsRecipeNode& operator[] (::CORBA::ULong index) const;
    rmsRecipeNode& operator[] (::CORBA::ULong index);
    const rmsRecipeNode& operator[] (int index) const;
    rmsRecipeNode& operator[] (int index);
    const _IDL_SEQ_rmsRecipeNodeSeq_0& in() const;
    _IDL_SEQ_rmsRecipeNodeSeq_0& inout();
    _IDL_SEQ_rmsRecipeNodeSeq_0*& out();
    _IDL_SEQ_rmsRecipeNodeSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeNodeSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeNodeSeq_0 _rmsRecipeNodeSeq_seq;
    typedef _IDL_SEQ_rmsRecipeNodeSeq_0 _rmsRecipeNodeSeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeNodeSeq_0 rmsRecipeNodeSeq;
    typedef _IDL_SEQ_rmsRecipeNodeSeq_0_var rmsRecipeNodeSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeNodeSeq;
    class  rmsRecipeByLevel_struct_var;
    struct  rmsRecipeByLevel_struct {
        typedef rmsRecipeByLevel_struct_var _var_type;
       ::CORBA::Long recipeLevel;
       ::rmsRecipeNodeSeq nodes;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeByLevel_struct();
       rmsRecipeByLevel_struct(const rmsRecipeByLevel_struct&);
       rmsRecipeByLevel_struct& operator=(const rmsRecipeByLevel_struct&);
       static CORBA::Info<rmsRecipeByLevel_struct> rmsRecipeByLevel_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeByLevel_struct


typedef rmsRecipeByLevel_struct* rmsRecipeByLevel_struct_vPtr;
typedef const rmsRecipeByLevel_struct* rmsRecipeByLevel_struct_cvPtr;

class  rmsRecipeByLevel_struct_var
{
    public:

    rmsRecipeByLevel_struct_var ();

    rmsRecipeByLevel_struct_var (rmsRecipeByLevel_struct *_p);

    rmsRecipeByLevel_struct_var (const rmsRecipeByLevel_struct_var &_s);

    rmsRecipeByLevel_struct_var &operator= (rmsRecipeByLevel_struct *_p);

    rmsRecipeByLevel_struct_var &operator= (const rmsRecipeByLevel_struct_var &_s);

    ~rmsRecipeByLevel_struct_var ();

    rmsRecipeByLevel_struct* operator-> ();

    const rmsRecipeByLevel_struct& in() const;
    rmsRecipeByLevel_struct& inout();
    rmsRecipeByLevel_struct*& out();
    rmsRecipeByLevel_struct* _retn();

    operator rmsRecipeByLevel_struct_cvPtr () const;

    operator rmsRecipeByLevel_struct_vPtr& ();

    operator const rmsRecipeByLevel_struct& () const;

    operator rmsRecipeByLevel_struct& ();

    protected:
    rmsRecipeByLevel_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeByLevel_struct;
    typedef rmsRecipeByLevel_struct rmsRecipeByLevel;
    typedef rmsRecipeByLevel_struct_var rmsRecipeByLevel_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeByLevel;
class  _IDL_SEQ_rmsRecipeByLevelSeq_0_var;
class  _IDL_SEQ_rmsRecipeByLevelSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeByLevelSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeByLevel *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeByLevelSeq_0 ();
    _IDL_SEQ_rmsRecipeByLevelSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeByLevelSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeByLevel* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeByLevelSeq_0 (const _IDL_SEQ_rmsRecipeByLevelSeq_0&);

    ~_IDL_SEQ_rmsRecipeByLevelSeq_0 ();

    _IDL_SEQ_rmsRecipeByLevelSeq_0& operator= (const _IDL_SEQ_rmsRecipeByLevelSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeByLevel& operator [] (::CORBA::ULong indx);
    const rmsRecipeByLevel& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeByLevel* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeByLevel* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeByLevel* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeByLevel* src, rmsRecipeByLevel* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeByLevel* data); 
  public:

    static rmsRecipeByLevel* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeByLevel* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeByLevel* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeByLevelSeq_0> rmsRecipeByLevelSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeByLevelSeq_0* _IDL_SEQ_rmsRecipeByLevelSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeByLevelSeq_0* _IDL_SEQ_rmsRecipeByLevelSeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeByLevelSeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeByLevelSeq_0_var ();

    _IDL_SEQ_rmsRecipeByLevelSeq_0_var (_IDL_SEQ_rmsRecipeByLevelSeq_0 *_p);

    _IDL_SEQ_rmsRecipeByLevelSeq_0_var (const _IDL_SEQ_rmsRecipeByLevelSeq_0_var &_s);

    _IDL_SEQ_rmsRecipeByLevelSeq_0_var &operator= (_IDL_SEQ_rmsRecipeByLevelSeq_0 *_p);

    _IDL_SEQ_rmsRecipeByLevelSeq_0_var &operator= (const _IDL_SEQ_rmsRecipeByLevelSeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeByLevelSeq_0_var ();

    _IDL_SEQ_rmsRecipeByLevelSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeByLevelSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeByLevelSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeByLevelSeq_0() const;

    const rmsRecipeByLevel& operator[] (::CORBA::ULong index) const;
    rmsRecipeByLevel& operator[] (::CORBA::ULong index);
    const rmsRecipeByLevel& operator[] (int index) const;
    rmsRecipeByLevel& operator[] (int index);
    const _IDL_SEQ_rmsRecipeByLevelSeq_0& in() const;
    _IDL_SEQ_rmsRecipeByLevelSeq_0& inout();
    _IDL_SEQ_rmsRecipeByLevelSeq_0*& out();
    _IDL_SEQ_rmsRecipeByLevelSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeByLevelSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeByLevelSeq_0 _rmsRecipeByLevelSeq_seq;
    typedef _IDL_SEQ_rmsRecipeByLevelSeq_0 _rmsRecipeByLevelSeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeByLevelSeq_0 rmsRecipeByLevelSeq;
    typedef _IDL_SEQ_rmsRecipeByLevelSeq_0_var rmsRecipeByLevelSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeByLevelSeq;
    class  rmsEqpRecipeByLevelInqResult_struct_var;
    struct  rmsEqpRecipeByLevelInqResult_struct {
        typedef rmsEqpRecipeByLevelInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeByLevelSeq recipeList;
       ::rmsRecipeByLevelSeq orphanList;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpRecipeByLevelInqResult_struct();
       rmsEqpRecipeByLevelInqResult_struct(const rmsEqpRecipeByLevelInqResult_struct&);
       rmsEqpRecipeByLevelInqResult_struct& operator=(const rmsEqpRecipeByLevelInqResult_struct&);
       static CORBA::Info<rmsEqpRecipeByLevelInqResult_struct> rmsEqpRecipeByLevelInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpRecipeByLevelInqResult_struct


typedef rmsEqpRecipeByLevelInqResult_struct* rmsEqpRecipeByLevelInqResult_struct_vPtr;
typedef const rmsEqpRecipeByLevelInqResult_struct* rmsEqpRecipeByLevelInqResult_struct_cvPtr;

class  rmsEqpRecipeByLevelInqResult_struct_var
{
    public:

    rmsEqpRecipeByLevelInqResult_struct_var ();

    rmsEqpRecipeByLevelInqResult_struct_var (rmsEqpRecipeByLevelInqResult_struct *_p);

    rmsEqpRecipeByLevelInqResult_struct_var (const rmsEqpRecipeByLevelInqResult_struct_var &_s);

    rmsEqpRecipeByLevelInqResult_struct_var &operator= (rmsEqpRecipeByLevelInqResult_struct *_p);

    rmsEqpRecipeByLevelInqResult_struct_var &operator= (const rmsEqpRecipeByLevelInqResult_struct_var &_s);

    ~rmsEqpRecipeByLevelInqResult_struct_var ();

    rmsEqpRecipeByLevelInqResult_struct* operator-> ();

    const rmsEqpRecipeByLevelInqResult_struct& in() const;
    rmsEqpRecipeByLevelInqResult_struct& inout();
    rmsEqpRecipeByLevelInqResult_struct*& out();
    rmsEqpRecipeByLevelInqResult_struct* _retn();

    operator rmsEqpRecipeByLevelInqResult_struct_cvPtr () const;

    operator rmsEqpRecipeByLevelInqResult_struct_vPtr& ();

    operator const rmsEqpRecipeByLevelInqResult_struct& () const;

    operator rmsEqpRecipeByLevelInqResult_struct& ();

    protected:
    rmsEqpRecipeByLevelInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpRecipeByLevelInqResult_struct;
    typedef rmsEqpRecipeByLevelInqResult_struct rmsEqpRecipeByLevelInqResult;
    typedef rmsEqpRecipeByLevelInqResult_struct_var rmsEqpRecipeByLevelInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpRecipeByLevelInqResult;
    class  rmsRecipeRelationInqResult_struct_var;
    struct  rmsRecipeRelationInqResult_struct {
        typedef rmsRecipeRelationInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeNodeSeq parentRecipes;
       ::rmsRecipeNodeSeq childRecipes;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeRelationInqResult_struct();
       rmsRecipeRelationInqResult_struct(const rmsRecipeRelationInqResult_struct&);
       rmsRecipeRelationInqResult_struct& operator=(const rmsRecipeRelationInqResult_struct&);
       static CORBA::Info<rmsRecipeRelationInqResult_struct> rmsRecipeRelationInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeRelationInqResult_struct


typedef rmsRecipeRelationInqResult_struct* rmsRecipeRelationInqResult_struct_vPtr;
typedef const rmsRecipeRelationInqResult_struct* rmsRecipeRelationInqResult_struct_cvPtr;

class  rmsRecipeRelationInqResult_struct_var
{
    public:

    rmsRecipeRelationInqResult_struct_var ();

    rmsRecipeRelationInqResult_struct_var (rmsRecipeRelationInqResult_struct *_p);

    rmsRecipeRelationInqResult_struct_var (const rmsRecipeRelationInqResult_struct_var &_s);

    rmsRecipeRelationInqResult_struct_var &operator= (rmsRecipeRelationInqResult_struct *_p);

    rmsRecipeRelationInqResult_struct_var &operator= (const rmsRecipeRelationInqResult_struct_var &_s);

    ~rmsRecipeRelationInqResult_struct_var ();

    rmsRecipeRelationInqResult_struct* operator-> ();

    const rmsRecipeRelationInqResult_struct& in() const;
    rmsRecipeRelationInqResult_struct& inout();
    rmsRecipeRelationInqResult_struct*& out();
    rmsRecipeRelationInqResult_struct* _retn();

    operator rmsRecipeRelationInqResult_struct_cvPtr () const;

    operator rmsRecipeRelationInqResult_struct_vPtr& ();

    operator const rmsRecipeRelationInqResult_struct& () const;

    operator rmsRecipeRelationInqResult_struct& ();

    protected:
    rmsRecipeRelationInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeRelationInqResult_struct;
    typedef rmsRecipeRelationInqResult_struct rmsRecipeRelationInqResult;
    typedef rmsRecipeRelationInqResult_struct_var rmsRecipeRelationInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeRelationInqResult;
    class  rmsBulletinRecord_struct_var;
    struct  rmsBulletinRecord_struct {
        typedef rmsBulletinRecord_struct_var _var_type;
       ::CORBA::Long bulletinID;
       ::CORBA::String_StructElem bulletinTime;
       ::CORBA::String_StructElem departmentID;
       ::CORBA::String_StructElem content;
       ::CORBA::String_StructElem isEnable;
       ::CORBA::String_StructElem beginTime;
       ::CORBA::String_StructElem endTime;
       ::CORBA::String_StructElem claimTime;
       ::CORBA::String_StructElem claimUserID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsBulletinRecord_struct();
       rmsBulletinRecord_struct(const rmsBulletinRecord_struct&);
       rmsBulletinRecord_struct& operator=(const rmsBulletinRecord_struct&);
       static CORBA::Info<rmsBulletinRecord_struct> rmsBulletinRecord_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsBulletinRecord_struct


typedef rmsBulletinRecord_struct* rmsBulletinRecord_struct_vPtr;
typedef const rmsBulletinRecord_struct* rmsBulletinRecord_struct_cvPtr;

class  rmsBulletinRecord_struct_var
{
    public:

    rmsBulletinRecord_struct_var ();

    rmsBulletinRecord_struct_var (rmsBulletinRecord_struct *_p);

    rmsBulletinRecord_struct_var (const rmsBulletinRecord_struct_var &_s);

    rmsBulletinRecord_struct_var &operator= (rmsBulletinRecord_struct *_p);

    rmsBulletinRecord_struct_var &operator= (const rmsBulletinRecord_struct_var &_s);

    ~rmsBulletinRecord_struct_var ();

    rmsBulletinRecord_struct* operator-> ();

    const rmsBulletinRecord_struct& in() const;
    rmsBulletinRecord_struct& inout();
    rmsBulletinRecord_struct*& out();
    rmsBulletinRecord_struct* _retn();

    operator rmsBulletinRecord_struct_cvPtr () const;

    operator rmsBulletinRecord_struct_vPtr& ();

    operator const rmsBulletinRecord_struct& () const;

    operator rmsBulletinRecord_struct& ();

    protected:
    rmsBulletinRecord_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsBulletinRecord_struct;
    typedef rmsBulletinRecord_struct rmsBulletinRecord;
    typedef rmsBulletinRecord_struct_var rmsBulletinRecord_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsBulletinRecord;
class  _IDL_SEQ_rmsBulletinRecordSequence_0_var;
class  _IDL_SEQ_rmsBulletinRecordSequence_0 {
    public:
        typedef _IDL_SEQ_rmsBulletinRecordSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsBulletinRecord *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsBulletinRecordSequence_0 ();
    _IDL_SEQ_rmsBulletinRecordSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsBulletinRecordSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsBulletinRecord* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsBulletinRecordSequence_0 (const _IDL_SEQ_rmsBulletinRecordSequence_0&);

    ~_IDL_SEQ_rmsBulletinRecordSequence_0 ();

    _IDL_SEQ_rmsBulletinRecordSequence_0& operator= (const _IDL_SEQ_rmsBulletinRecordSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsBulletinRecord& operator [] (::CORBA::ULong indx);
    const rmsBulletinRecord& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsBulletinRecord* get_buffer (::CORBA::Boolean orphan=0);
    const rmsBulletinRecord* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsBulletinRecord* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsBulletinRecord* src, rmsBulletinRecord* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsBulletinRecord* data); 
  public:

    static rmsBulletinRecord* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsBulletinRecord* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsBulletinRecord* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsBulletinRecordSequence_0> rmsBulletinRecordSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsBulletinRecordSequence_0* _IDL_SEQ_rmsBulletinRecordSequence_0_vPtr;
typedef const _IDL_SEQ_rmsBulletinRecordSequence_0* _IDL_SEQ_rmsBulletinRecordSequence_0_cvPtr;

class  _IDL_SEQ_rmsBulletinRecordSequence_0_var
{
    public:

    _IDL_SEQ_rmsBulletinRecordSequence_0_var ();

    _IDL_SEQ_rmsBulletinRecordSequence_0_var (_IDL_SEQ_rmsBulletinRecordSequence_0 *_p);

    _IDL_SEQ_rmsBulletinRecordSequence_0_var (const _IDL_SEQ_rmsBulletinRecordSequence_0_var &_s);

    _IDL_SEQ_rmsBulletinRecordSequence_0_var &operator= (_IDL_SEQ_rmsBulletinRecordSequence_0 *_p);

    _IDL_SEQ_rmsBulletinRecordSequence_0_var &operator= (const _IDL_SEQ_rmsBulletinRecordSequence_0_var &_s);

    ~_IDL_SEQ_rmsBulletinRecordSequence_0_var ();

    _IDL_SEQ_rmsBulletinRecordSequence_0* operator-> ();

    operator _IDL_SEQ_rmsBulletinRecordSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsBulletinRecordSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsBulletinRecordSequence_0() const;

    const rmsBulletinRecord& operator[] (::CORBA::ULong index) const;
    rmsBulletinRecord& operator[] (::CORBA::ULong index);
    const rmsBulletinRecord& operator[] (int index) const;
    rmsBulletinRecord& operator[] (int index);
    const _IDL_SEQ_rmsBulletinRecordSequence_0& in() const;
    _IDL_SEQ_rmsBulletinRecordSequence_0& inout();
    _IDL_SEQ_rmsBulletinRecordSequence_0*& out();
    _IDL_SEQ_rmsBulletinRecordSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsBulletinRecordSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsBulletinRecordSequence_0 _rmsBulletinRecordSequence_seq;
    typedef _IDL_SEQ_rmsBulletinRecordSequence_0 _rmsBulletinRecordSequence_seq_1;
    typedef _IDL_SEQ_rmsBulletinRecordSequence_0 rmsBulletinRecordSequence;
    typedef _IDL_SEQ_rmsBulletinRecordSequence_0_var rmsBulletinRecordSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsBulletinRecordSequence;
    class  rmsBulletinListInqResult_struct_var;
    struct  rmsBulletinListInqResult_struct {
        typedef rmsBulletinListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsBulletinRecordSequence bulletinRecords;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsBulletinListInqResult_struct();
       rmsBulletinListInqResult_struct(const rmsBulletinListInqResult_struct&);
       rmsBulletinListInqResult_struct& operator=(const rmsBulletinListInqResult_struct&);
       static CORBA::Info<rmsBulletinListInqResult_struct> rmsBulletinListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsBulletinListInqResult_struct


typedef rmsBulletinListInqResult_struct* rmsBulletinListInqResult_struct_vPtr;
typedef const rmsBulletinListInqResult_struct* rmsBulletinListInqResult_struct_cvPtr;

class  rmsBulletinListInqResult_struct_var
{
    public:

    rmsBulletinListInqResult_struct_var ();

    rmsBulletinListInqResult_struct_var (rmsBulletinListInqResult_struct *_p);

    rmsBulletinListInqResult_struct_var (const rmsBulletinListInqResult_struct_var &_s);

    rmsBulletinListInqResult_struct_var &operator= (rmsBulletinListInqResult_struct *_p);

    rmsBulletinListInqResult_struct_var &operator= (const rmsBulletinListInqResult_struct_var &_s);

    ~rmsBulletinListInqResult_struct_var ();

    rmsBulletinListInqResult_struct* operator-> ();

    const rmsBulletinListInqResult_struct& in() const;
    rmsBulletinListInqResult_struct& inout();
    rmsBulletinListInqResult_struct*& out();
    rmsBulletinListInqResult_struct* _retn();

    operator rmsBulletinListInqResult_struct_cvPtr () const;

    operator rmsBulletinListInqResult_struct_vPtr& ();

    operator const rmsBulletinListInqResult_struct& () const;

    operator rmsBulletinListInqResult_struct& ();

    protected:
    rmsBulletinListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsBulletinListInqResult_struct;
    typedef rmsBulletinListInqResult_struct rmsBulletinListInqResult;
    typedef rmsBulletinListInqResult_struct_var rmsBulletinListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsBulletinListInqResult;
    class  rmsRIMJob_struct_var;
    struct  rmsRIMJob_struct {
        typedef rmsRIMJob_struct_var _var_type;
       ::CORBA::Long jobIndex;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeID;
       ::CORBA::Long recipeLevel;
       ::CORBA::String_StructElem actionCode;
       ::CORBA::String_StructElem jobStatus;
       ::CORBA::Long retryCount;
       ::CORBA::String_StructElem jobExecDT;
       ::CORBA::String_StructElem rmsStartDT;
       ::CORBA::String_StructElem rmsEndDT;
       ::CORBA::String_StructElem result;
       ::CORBA::String_StructElem resultDesc;
       ::CORBA::String_StructElem rimStartDT;
       ::CORBA::String_StructElem rimEndDT;
       ::CORBA::String_StructElem rimExecResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRIMJob_struct();
       rmsRIMJob_struct(const rmsRIMJob_struct&);
       rmsRIMJob_struct& operator=(const rmsRIMJob_struct&);
       static CORBA::Info<rmsRIMJob_struct> rmsRIMJob_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRIMJob_struct


typedef rmsRIMJob_struct* rmsRIMJob_struct_vPtr;
typedef const rmsRIMJob_struct* rmsRIMJob_struct_cvPtr;

class  rmsRIMJob_struct_var
{
    public:

    rmsRIMJob_struct_var ();

    rmsRIMJob_struct_var (rmsRIMJob_struct *_p);

    rmsRIMJob_struct_var (const rmsRIMJob_struct_var &_s);

    rmsRIMJob_struct_var &operator= (rmsRIMJob_struct *_p);

    rmsRIMJob_struct_var &operator= (const rmsRIMJob_struct_var &_s);

    ~rmsRIMJob_struct_var ();

    rmsRIMJob_struct* operator-> ();

    const rmsRIMJob_struct& in() const;
    rmsRIMJob_struct& inout();
    rmsRIMJob_struct*& out();
    rmsRIMJob_struct* _retn();

    operator rmsRIMJob_struct_cvPtr () const;

    operator rmsRIMJob_struct_vPtr& ();

    operator const rmsRIMJob_struct& () const;

    operator rmsRIMJob_struct& ();

    protected:
    rmsRIMJob_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRIMJob_struct;
    typedef rmsRIMJob_struct rmsRIMJob;
    typedef rmsRIMJob_struct_var rmsRIMJob_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRIMJob;
class  _IDL_SEQ_rmsRIMJobSeq_0_var;
class  _IDL_SEQ_rmsRIMJobSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRIMJobSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRIMJob *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRIMJobSeq_0 ();
    _IDL_SEQ_rmsRIMJobSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRIMJobSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRIMJob* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRIMJobSeq_0 (const _IDL_SEQ_rmsRIMJobSeq_0&);

    ~_IDL_SEQ_rmsRIMJobSeq_0 ();

    _IDL_SEQ_rmsRIMJobSeq_0& operator= (const _IDL_SEQ_rmsRIMJobSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRIMJob& operator [] (::CORBA::ULong indx);
    const rmsRIMJob& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRIMJob* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRIMJob* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRIMJob* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRIMJob* src, rmsRIMJob* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRIMJob* data); 
  public:

    static rmsRIMJob* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRIMJob* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRIMJob* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRIMJobSeq_0> rmsRIMJobSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRIMJobSeq_0* _IDL_SEQ_rmsRIMJobSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRIMJobSeq_0* _IDL_SEQ_rmsRIMJobSeq_0_cvPtr;

class  _IDL_SEQ_rmsRIMJobSeq_0_var
{
    public:

    _IDL_SEQ_rmsRIMJobSeq_0_var ();

    _IDL_SEQ_rmsRIMJobSeq_0_var (_IDL_SEQ_rmsRIMJobSeq_0 *_p);

    _IDL_SEQ_rmsRIMJobSeq_0_var (const _IDL_SEQ_rmsRIMJobSeq_0_var &_s);

    _IDL_SEQ_rmsRIMJobSeq_0_var &operator= (_IDL_SEQ_rmsRIMJobSeq_0 *_p);

    _IDL_SEQ_rmsRIMJobSeq_0_var &operator= (const _IDL_SEQ_rmsRIMJobSeq_0_var &_s);

    ~_IDL_SEQ_rmsRIMJobSeq_0_var ();

    _IDL_SEQ_rmsRIMJobSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRIMJobSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRIMJobSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRIMJobSeq_0() const;

    const rmsRIMJob& operator[] (::CORBA::ULong index) const;
    rmsRIMJob& operator[] (::CORBA::ULong index);
    const rmsRIMJob& operator[] (int index) const;
    rmsRIMJob& operator[] (int index);
    const _IDL_SEQ_rmsRIMJobSeq_0& in() const;
    _IDL_SEQ_rmsRIMJobSeq_0& inout();
    _IDL_SEQ_rmsRIMJobSeq_0*& out();
    _IDL_SEQ_rmsRIMJobSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRIMJobSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRIMJobSeq_0 _rmsRIMJobSeq_seq;
    typedef _IDL_SEQ_rmsRIMJobSeq_0 _rmsRIMJobSeq_seq_1;
    typedef _IDL_SEQ_rmsRIMJobSeq_0 rmsRIMJobSeq;
    typedef _IDL_SEQ_rmsRIMJobSeq_0_var rmsRIMJobSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRIMJobSeq;
    class  rmsRIMJobInqResult_struct_var;
    struct  rmsRIMJobInqResult_struct {
        typedef rmsRIMJobInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRIMJobSeq jobs;
       ::CORBA::Boolean overSearchCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRIMJobInqResult_struct();
       rmsRIMJobInqResult_struct(const rmsRIMJobInqResult_struct&);
       rmsRIMJobInqResult_struct& operator=(const rmsRIMJobInqResult_struct&);
       static CORBA::Info<rmsRIMJobInqResult_struct> rmsRIMJobInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRIMJobInqResult_struct


typedef rmsRIMJobInqResult_struct* rmsRIMJobInqResult_struct_vPtr;
typedef const rmsRIMJobInqResult_struct* rmsRIMJobInqResult_struct_cvPtr;

class  rmsRIMJobInqResult_struct_var
{
    public:

    rmsRIMJobInqResult_struct_var ();

    rmsRIMJobInqResult_struct_var (rmsRIMJobInqResult_struct *_p);

    rmsRIMJobInqResult_struct_var (const rmsRIMJobInqResult_struct_var &_s);

    rmsRIMJobInqResult_struct_var &operator= (rmsRIMJobInqResult_struct *_p);

    rmsRIMJobInqResult_struct_var &operator= (const rmsRIMJobInqResult_struct_var &_s);

    ~rmsRIMJobInqResult_struct_var ();

    rmsRIMJobInqResult_struct* operator-> ();

    const rmsRIMJobInqResult_struct& in() const;
    rmsRIMJobInqResult_struct& inout();
    rmsRIMJobInqResult_struct*& out();
    rmsRIMJobInqResult_struct* _retn();

    operator rmsRIMJobInqResult_struct_cvPtr () const;

    operator rmsRIMJobInqResult_struct_vPtr& ();

    operator const rmsRIMJobInqResult_struct& () const;

    operator rmsRIMJobInqResult_struct& ();

    protected:
    rmsRIMJobInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRIMJobInqResult_struct;
    typedef rmsRIMJobInqResult_struct rmsRIMJobInqResult;
    typedef rmsRIMJobInqResult_struct_var rmsRIMJobInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRIMJobInqResult;
    class  rmsUATData_struct_var;
    struct  rmsUATData_struct {
        typedef rmsUATData_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeID;
       ::CORBA::Long recipeLevel;
       ::CORBA::Long jobIndex;
       ::CORBA::String_StructElem inhibitRecipe;
       ::CORBA::String_StructElem claimTime;
       ::CORBA::String_StructElem inhibitIdentifier;
       ::CORBA::String_StructElem inhibitObjectRef;
       ::CORBA::String_StructElem jobExecDT;
       ::CORBA::String_StructElem rimRef;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsUATData_struct();
       rmsUATData_struct(const rmsUATData_struct&);
       rmsUATData_struct& operator=(const rmsUATData_struct&);
       static CORBA::Info<rmsUATData_struct> rmsUATData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsUATData_struct


typedef rmsUATData_struct* rmsUATData_struct_vPtr;
typedef const rmsUATData_struct* rmsUATData_struct_cvPtr;

class  rmsUATData_struct_var
{
    public:

    rmsUATData_struct_var ();

    rmsUATData_struct_var (rmsUATData_struct *_p);

    rmsUATData_struct_var (const rmsUATData_struct_var &_s);

    rmsUATData_struct_var &operator= (rmsUATData_struct *_p);

    rmsUATData_struct_var &operator= (const rmsUATData_struct_var &_s);

    ~rmsUATData_struct_var ();

    rmsUATData_struct* operator-> ();

    const rmsUATData_struct& in() const;
    rmsUATData_struct& inout();
    rmsUATData_struct*& out();
    rmsUATData_struct* _retn();

    operator rmsUATData_struct_cvPtr () const;

    operator rmsUATData_struct_vPtr& ();

    operator const rmsUATData_struct& () const;

    operator rmsUATData_struct& ();

    protected:
    rmsUATData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsUATData_struct;
    typedef rmsUATData_struct rmsUATData;
    typedef rmsUATData_struct_var rmsUATData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsUATData;
class  _IDL_SEQ_rmsUATDataSeq_0_var;
class  _IDL_SEQ_rmsUATDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsUATDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsUATData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsUATDataSeq_0 ();
    _IDL_SEQ_rmsUATDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsUATDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsUATData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsUATDataSeq_0 (const _IDL_SEQ_rmsUATDataSeq_0&);

    ~_IDL_SEQ_rmsUATDataSeq_0 ();

    _IDL_SEQ_rmsUATDataSeq_0& operator= (const _IDL_SEQ_rmsUATDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsUATData& operator [] (::CORBA::ULong indx);
    const rmsUATData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsUATData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsUATData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsUATData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsUATData* src, rmsUATData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsUATData* data); 
  public:

    static rmsUATData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsUATData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsUATData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsUATDataSeq_0> rmsUATDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsUATDataSeq_0* _IDL_SEQ_rmsUATDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsUATDataSeq_0* _IDL_SEQ_rmsUATDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsUATDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsUATDataSeq_0_var ();

    _IDL_SEQ_rmsUATDataSeq_0_var (_IDL_SEQ_rmsUATDataSeq_0 *_p);

    _IDL_SEQ_rmsUATDataSeq_0_var (const _IDL_SEQ_rmsUATDataSeq_0_var &_s);

    _IDL_SEQ_rmsUATDataSeq_0_var &operator= (_IDL_SEQ_rmsUATDataSeq_0 *_p);

    _IDL_SEQ_rmsUATDataSeq_0_var &operator= (const _IDL_SEQ_rmsUATDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsUATDataSeq_0_var ();

    _IDL_SEQ_rmsUATDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsUATDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsUATDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsUATDataSeq_0() const;

    const rmsUATData& operator[] (::CORBA::ULong index) const;
    rmsUATData& operator[] (::CORBA::ULong index);
    const rmsUATData& operator[] (int index) const;
    rmsUATData& operator[] (int index);
    const _IDL_SEQ_rmsUATDataSeq_0& in() const;
    _IDL_SEQ_rmsUATDataSeq_0& inout();
    _IDL_SEQ_rmsUATDataSeq_0*& out();
    _IDL_SEQ_rmsUATDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsUATDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsUATDataSeq_0 _rmsUATDataSeq_seq;
    typedef _IDL_SEQ_rmsUATDataSeq_0 _rmsUATDataSeq_seq_1;
    typedef _IDL_SEQ_rmsUATDataSeq_0 rmsUATDataSeq;
    typedef _IDL_SEQ_rmsUATDataSeq_0_var rmsUATDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsUATDataSeq;
    class  rmsUATDataInqResult_struct_var;
    struct  rmsUATDataInqResult_struct {
        typedef rmsUATDataInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsUATDataSeq uatInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsUATDataInqResult_struct();
       rmsUATDataInqResult_struct(const rmsUATDataInqResult_struct&);
       rmsUATDataInqResult_struct& operator=(const rmsUATDataInqResult_struct&);
       static CORBA::Info<rmsUATDataInqResult_struct> rmsUATDataInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsUATDataInqResult_struct


typedef rmsUATDataInqResult_struct* rmsUATDataInqResult_struct_vPtr;
typedef const rmsUATDataInqResult_struct* rmsUATDataInqResult_struct_cvPtr;

class  rmsUATDataInqResult_struct_var
{
    public:

    rmsUATDataInqResult_struct_var ();

    rmsUATDataInqResult_struct_var (rmsUATDataInqResult_struct *_p);

    rmsUATDataInqResult_struct_var (const rmsUATDataInqResult_struct_var &_s);

    rmsUATDataInqResult_struct_var &operator= (rmsUATDataInqResult_struct *_p);

    rmsUATDataInqResult_struct_var &operator= (const rmsUATDataInqResult_struct_var &_s);

    ~rmsUATDataInqResult_struct_var ();

    rmsUATDataInqResult_struct* operator-> ();

    const rmsUATDataInqResult_struct& in() const;
    rmsUATDataInqResult_struct& inout();
    rmsUATDataInqResult_struct*& out();
    rmsUATDataInqResult_struct* _retn();

    operator rmsUATDataInqResult_struct_cvPtr () const;

    operator rmsUATDataInqResult_struct_vPtr& ();

    operator const rmsUATDataInqResult_struct& () const;

    operator rmsUATDataInqResult_struct& ();

    protected:
    rmsUATDataInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsUATDataInqResult_struct;
    typedef rmsUATDataInqResult_struct rmsUATDataInqResult;
    typedef rmsUATDataInqResult_struct_var rmsUATDataInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsUATDataInqResult;
    typedef rmsUATData rmsHoldData;
    typedef rmsUATData_var rmsHoldData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsHoldData;
class  _IDL_SEQ_rmsHoldDataSeq_0_var;
class  _IDL_SEQ_rmsHoldDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsHoldDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsHoldData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsHoldDataSeq_0 ();
    _IDL_SEQ_rmsHoldDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsHoldDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsHoldData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsHoldDataSeq_0 (const _IDL_SEQ_rmsHoldDataSeq_0&);

    ~_IDL_SEQ_rmsHoldDataSeq_0 ();

    _IDL_SEQ_rmsHoldDataSeq_0& operator= (const _IDL_SEQ_rmsHoldDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsHoldData& operator [] (::CORBA::ULong indx);
    const rmsHoldData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsHoldData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsHoldData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsHoldData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsHoldData* src, rmsHoldData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsHoldData* data); 
  public:

    static rmsHoldData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsHoldData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsHoldData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsHoldDataSeq_0> rmsHoldDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsHoldDataSeq_0* _IDL_SEQ_rmsHoldDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsHoldDataSeq_0* _IDL_SEQ_rmsHoldDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsHoldDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsHoldDataSeq_0_var ();

    _IDL_SEQ_rmsHoldDataSeq_0_var (_IDL_SEQ_rmsHoldDataSeq_0 *_p);

    _IDL_SEQ_rmsHoldDataSeq_0_var (const _IDL_SEQ_rmsHoldDataSeq_0_var &_s);

    _IDL_SEQ_rmsHoldDataSeq_0_var &operator= (_IDL_SEQ_rmsHoldDataSeq_0 *_p);

    _IDL_SEQ_rmsHoldDataSeq_0_var &operator= (const _IDL_SEQ_rmsHoldDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsHoldDataSeq_0_var ();

    _IDL_SEQ_rmsHoldDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsHoldDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsHoldDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsHoldDataSeq_0() const;

    const rmsHoldData& operator[] (::CORBA::ULong index) const;
    rmsHoldData& operator[] (::CORBA::ULong index);
    const rmsHoldData& operator[] (int index) const;
    rmsHoldData& operator[] (int index);
    const _IDL_SEQ_rmsHoldDataSeq_0& in() const;
    _IDL_SEQ_rmsHoldDataSeq_0& inout();
    _IDL_SEQ_rmsHoldDataSeq_0*& out();
    _IDL_SEQ_rmsHoldDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsHoldDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsHoldDataSeq_0 _rmsHoldDataSeq_seq;
    typedef _IDL_SEQ_rmsHoldDataSeq_0 _rmsHoldDataSeq_seq_1;
    typedef _IDL_SEQ_rmsHoldDataSeq_0 rmsHoldDataSeq;
    typedef _IDL_SEQ_rmsHoldDataSeq_0_var rmsHoldDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsHoldDataSeq;
    class  rmsHoldDataInqResult_struct_var;
    struct  rmsHoldDataInqResult_struct {
        typedef rmsHoldDataInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsHoldDataSeq holdInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsHoldDataInqResult_struct();
       rmsHoldDataInqResult_struct(const rmsHoldDataInqResult_struct&);
       rmsHoldDataInqResult_struct& operator=(const rmsHoldDataInqResult_struct&);
       static CORBA::Info<rmsHoldDataInqResult_struct> rmsHoldDataInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsHoldDataInqResult_struct


typedef rmsHoldDataInqResult_struct* rmsHoldDataInqResult_struct_vPtr;
typedef const rmsHoldDataInqResult_struct* rmsHoldDataInqResult_struct_cvPtr;

class  rmsHoldDataInqResult_struct_var
{
    public:

    rmsHoldDataInqResult_struct_var ();

    rmsHoldDataInqResult_struct_var (rmsHoldDataInqResult_struct *_p);

    rmsHoldDataInqResult_struct_var (const rmsHoldDataInqResult_struct_var &_s);

    rmsHoldDataInqResult_struct_var &operator= (rmsHoldDataInqResult_struct *_p);

    rmsHoldDataInqResult_struct_var &operator= (const rmsHoldDataInqResult_struct_var &_s);

    ~rmsHoldDataInqResult_struct_var ();

    rmsHoldDataInqResult_struct* operator-> ();

    const rmsHoldDataInqResult_struct& in() const;
    rmsHoldDataInqResult_struct& inout();
    rmsHoldDataInqResult_struct*& out();
    rmsHoldDataInqResult_struct* _retn();

    operator rmsHoldDataInqResult_struct_cvPtr () const;

    operator rmsHoldDataInqResult_struct_vPtr& ();

    operator const rmsHoldDataInqResult_struct& () const;

    operator rmsHoldDataInqResult_struct& ();

    protected:
    rmsHoldDataInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsHoldDataInqResult_struct;
    typedef rmsHoldDataInqResult_struct rmsHoldDataInqResult;
    typedef rmsHoldDataInqResult_struct_var rmsHoldDataInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsHoldDataInqResult;
    class  rmsLabelData_struct_var;
    struct  rmsLabelData_struct {
        typedef rmsLabelData_struct_var _var_type;
       ::CORBA::String_StructElem depId;
       ::CORBA::String_StructElem label;
       ::CORBA::Long applyCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsLabelData_struct();
       rmsLabelData_struct(const rmsLabelData_struct&);
       rmsLabelData_struct& operator=(const rmsLabelData_struct&);
       static CORBA::Info<rmsLabelData_struct> rmsLabelData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsLabelData_struct


typedef rmsLabelData_struct* rmsLabelData_struct_vPtr;
typedef const rmsLabelData_struct* rmsLabelData_struct_cvPtr;

class  rmsLabelData_struct_var
{
    public:

    rmsLabelData_struct_var ();

    rmsLabelData_struct_var (rmsLabelData_struct *_p);

    rmsLabelData_struct_var (const rmsLabelData_struct_var &_s);

    rmsLabelData_struct_var &operator= (rmsLabelData_struct *_p);

    rmsLabelData_struct_var &operator= (const rmsLabelData_struct_var &_s);

    ~rmsLabelData_struct_var ();

    rmsLabelData_struct* operator-> ();

    const rmsLabelData_struct& in() const;
    rmsLabelData_struct& inout();
    rmsLabelData_struct*& out();
    rmsLabelData_struct* _retn();

    operator rmsLabelData_struct_cvPtr () const;

    operator rmsLabelData_struct_vPtr& ();

    operator const rmsLabelData_struct& () const;

    operator rmsLabelData_struct& ();

    protected:
    rmsLabelData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsLabelData_struct;
    typedef rmsLabelData_struct rmsLabelData;
    typedef rmsLabelData_struct_var rmsLabelData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLabelData;
class  _IDL_SEQ_rmsLabelDataSeq_0_var;
class  _IDL_SEQ_rmsLabelDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsLabelDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsLabelData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsLabelDataSeq_0 ();
    _IDL_SEQ_rmsLabelDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsLabelDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsLabelData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsLabelDataSeq_0 (const _IDL_SEQ_rmsLabelDataSeq_0&);

    ~_IDL_SEQ_rmsLabelDataSeq_0 ();

    _IDL_SEQ_rmsLabelDataSeq_0& operator= (const _IDL_SEQ_rmsLabelDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsLabelData& operator [] (::CORBA::ULong indx);
    const rmsLabelData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsLabelData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsLabelData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsLabelData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsLabelData* src, rmsLabelData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsLabelData* data); 
  public:

    static rmsLabelData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsLabelData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsLabelData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsLabelDataSeq_0> rmsLabelDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsLabelDataSeq_0* _IDL_SEQ_rmsLabelDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsLabelDataSeq_0* _IDL_SEQ_rmsLabelDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsLabelDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsLabelDataSeq_0_var ();

    _IDL_SEQ_rmsLabelDataSeq_0_var (_IDL_SEQ_rmsLabelDataSeq_0 *_p);

    _IDL_SEQ_rmsLabelDataSeq_0_var (const _IDL_SEQ_rmsLabelDataSeq_0_var &_s);

    _IDL_SEQ_rmsLabelDataSeq_0_var &operator= (_IDL_SEQ_rmsLabelDataSeq_0 *_p);

    _IDL_SEQ_rmsLabelDataSeq_0_var &operator= (const _IDL_SEQ_rmsLabelDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsLabelDataSeq_0_var ();

    _IDL_SEQ_rmsLabelDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsLabelDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsLabelDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsLabelDataSeq_0() const;

    const rmsLabelData& operator[] (::CORBA::ULong index) const;
    rmsLabelData& operator[] (::CORBA::ULong index);
    const rmsLabelData& operator[] (int index) const;
    rmsLabelData& operator[] (int index);
    const _IDL_SEQ_rmsLabelDataSeq_0& in() const;
    _IDL_SEQ_rmsLabelDataSeq_0& inout();
    _IDL_SEQ_rmsLabelDataSeq_0*& out();
    _IDL_SEQ_rmsLabelDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsLabelDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsLabelDataSeq_0 _rmsLabelDataSeq_seq;
    typedef _IDL_SEQ_rmsLabelDataSeq_0 _rmsLabelDataSeq_seq_1;
    typedef _IDL_SEQ_rmsLabelDataSeq_0 rmsLabelDataSeq;
    typedef _IDL_SEQ_rmsLabelDataSeq_0_var rmsLabelDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLabelDataSeq;
    class  rmsLabelDataInqResult_struct_var;
    struct  rmsLabelDataInqResult_struct {
        typedef rmsLabelDataInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsLabelDataSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsLabelDataInqResult_struct();
       rmsLabelDataInqResult_struct(const rmsLabelDataInqResult_struct&);
       rmsLabelDataInqResult_struct& operator=(const rmsLabelDataInqResult_struct&);
       static CORBA::Info<rmsLabelDataInqResult_struct> rmsLabelDataInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsLabelDataInqResult_struct


typedef rmsLabelDataInqResult_struct* rmsLabelDataInqResult_struct_vPtr;
typedef const rmsLabelDataInqResult_struct* rmsLabelDataInqResult_struct_cvPtr;

class  rmsLabelDataInqResult_struct_var
{
    public:

    rmsLabelDataInqResult_struct_var ();

    rmsLabelDataInqResult_struct_var (rmsLabelDataInqResult_struct *_p);

    rmsLabelDataInqResult_struct_var (const rmsLabelDataInqResult_struct_var &_s);

    rmsLabelDataInqResult_struct_var &operator= (rmsLabelDataInqResult_struct *_p);

    rmsLabelDataInqResult_struct_var &operator= (const rmsLabelDataInqResult_struct_var &_s);

    ~rmsLabelDataInqResult_struct_var ();

    rmsLabelDataInqResult_struct* operator-> ();

    const rmsLabelDataInqResult_struct& in() const;
    rmsLabelDataInqResult_struct& inout();
    rmsLabelDataInqResult_struct*& out();
    rmsLabelDataInqResult_struct* _retn();

    operator rmsLabelDataInqResult_struct_cvPtr () const;

    operator rmsLabelDataInqResult_struct_vPtr& ();

    operator const rmsLabelDataInqResult_struct& () const;

    operator rmsLabelDataInqResult_struct& ();

    protected:
    rmsLabelDataInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsLabelDataInqResult_struct;
    typedef rmsLabelDataInqResult_struct rmsLabelDataInqResult;
    typedef rmsLabelDataInqResult_struct_var rmsLabelDataInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLabelDataInqResult;
    class  rmsRecipeLabelData_struct_var;
    struct  rmsRecipeLabelData_struct {
        typedef rmsRecipeLabelData_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeId;
       ::CORBA::String_StructElem label;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeLabelData_struct();
       rmsRecipeLabelData_struct(const rmsRecipeLabelData_struct&);
       rmsRecipeLabelData_struct& operator=(const rmsRecipeLabelData_struct&);
       static CORBA::Info<rmsRecipeLabelData_struct> rmsRecipeLabelData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRecipeLabelData_struct


typedef rmsRecipeLabelData_struct* rmsRecipeLabelData_struct_vPtr;
typedef const rmsRecipeLabelData_struct* rmsRecipeLabelData_struct_cvPtr;

class  rmsRecipeLabelData_struct_var
{
    public:

    rmsRecipeLabelData_struct_var ();

    rmsRecipeLabelData_struct_var (rmsRecipeLabelData_struct *_p);

    rmsRecipeLabelData_struct_var (const rmsRecipeLabelData_struct_var &_s);

    rmsRecipeLabelData_struct_var &operator= (rmsRecipeLabelData_struct *_p);

    rmsRecipeLabelData_struct_var &operator= (const rmsRecipeLabelData_struct_var &_s);

    ~rmsRecipeLabelData_struct_var ();

    rmsRecipeLabelData_struct* operator-> ();

    const rmsRecipeLabelData_struct& in() const;
    rmsRecipeLabelData_struct& inout();
    rmsRecipeLabelData_struct*& out();
    rmsRecipeLabelData_struct* _retn();

    operator rmsRecipeLabelData_struct_cvPtr () const;

    operator rmsRecipeLabelData_struct_vPtr& ();

    operator const rmsRecipeLabelData_struct& () const;

    operator rmsRecipeLabelData_struct& ();

    protected:
    rmsRecipeLabelData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelData_struct;
    typedef rmsRecipeLabelData_struct rmsRecipeLabelData;
    typedef rmsRecipeLabelData_struct_var rmsRecipeLabelData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelData;
class  _IDL_SEQ_rmsRecipeLabelDataSeq_0_var;
class  _IDL_SEQ_rmsRecipeLabelDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeLabelDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeLabelData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeLabelDataSeq_0 ();
    _IDL_SEQ_rmsRecipeLabelDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeLabelDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeLabelData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeLabelDataSeq_0 (const _IDL_SEQ_rmsRecipeLabelDataSeq_0&);

    ~_IDL_SEQ_rmsRecipeLabelDataSeq_0 ();

    _IDL_SEQ_rmsRecipeLabelDataSeq_0& operator= (const _IDL_SEQ_rmsRecipeLabelDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeLabelData& operator [] (::CORBA::ULong indx);
    const rmsRecipeLabelData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeLabelData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeLabelData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeLabelData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeLabelData* src, rmsRecipeLabelData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeLabelData* data); 
  public:

    static rmsRecipeLabelData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeLabelData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeLabelData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeLabelDataSeq_0> rmsRecipeLabelDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeLabelDataSeq_0* _IDL_SEQ_rmsRecipeLabelDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeLabelDataSeq_0* _IDL_SEQ_rmsRecipeLabelDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeLabelDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeLabelDataSeq_0_var ();

    _IDL_SEQ_rmsRecipeLabelDataSeq_0_var (_IDL_SEQ_rmsRecipeLabelDataSeq_0 *_p);

    _IDL_SEQ_rmsRecipeLabelDataSeq_0_var (const _IDL_SEQ_rmsRecipeLabelDataSeq_0_var &_s);

    _IDL_SEQ_rmsRecipeLabelDataSeq_0_var &operator= (_IDL_SEQ_rmsRecipeLabelDataSeq_0 *_p);

    _IDL_SEQ_rmsRecipeLabelDataSeq_0_var &operator= (const _IDL_SEQ_rmsRecipeLabelDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeLabelDataSeq_0_var ();

    _IDL_SEQ_rmsRecipeLabelDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeLabelDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeLabelDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeLabelDataSeq_0() const;

    const rmsRecipeLabelData& operator[] (::CORBA::ULong index) const;
    rmsRecipeLabelData& operator[] (::CORBA::ULong index);
    const rmsRecipeLabelData& operator[] (int index) const;
    rmsRecipeLabelData& operator[] (int index);
    const _IDL_SEQ_rmsRecipeLabelDataSeq_0& in() const;
    _IDL_SEQ_rmsRecipeLabelDataSeq_0& inout();
    _IDL_SEQ_rmsRecipeLabelDataSeq_0*& out();
    _IDL_SEQ_rmsRecipeLabelDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeLabelDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeLabelDataSeq_0 _rmsRecipeLabelDataSeq_seq;
    typedef _IDL_SEQ_rmsRecipeLabelDataSeq_0 _rmsRecipeLabelDataSeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeLabelDataSeq_0 rmsRecipeLabelDataSeq;
    typedef _IDL_SEQ_rmsRecipeLabelDataSeq_0_var rmsRecipeLabelDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelDataSeq;
    class  rmsRecipeLabelDataInqResult_struct_var;
    struct  rmsRecipeLabelDataInqResult_struct {
        typedef rmsRecipeLabelDataInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeLabelDataSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeLabelDataInqResult_struct();
       rmsRecipeLabelDataInqResult_struct(const rmsRecipeLabelDataInqResult_struct&);
       rmsRecipeLabelDataInqResult_struct& operator=(const rmsRecipeLabelDataInqResult_struct&);
       static CORBA::Info<rmsRecipeLabelDataInqResult_struct> rmsRecipeLabelDataInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeLabelDataInqResult_struct


typedef rmsRecipeLabelDataInqResult_struct* rmsRecipeLabelDataInqResult_struct_vPtr;
typedef const rmsRecipeLabelDataInqResult_struct* rmsRecipeLabelDataInqResult_struct_cvPtr;

class  rmsRecipeLabelDataInqResult_struct_var
{
    public:

    rmsRecipeLabelDataInqResult_struct_var ();

    rmsRecipeLabelDataInqResult_struct_var (rmsRecipeLabelDataInqResult_struct *_p);

    rmsRecipeLabelDataInqResult_struct_var (const rmsRecipeLabelDataInqResult_struct_var &_s);

    rmsRecipeLabelDataInqResult_struct_var &operator= (rmsRecipeLabelDataInqResult_struct *_p);

    rmsRecipeLabelDataInqResult_struct_var &operator= (const rmsRecipeLabelDataInqResult_struct_var &_s);

    ~rmsRecipeLabelDataInqResult_struct_var ();

    rmsRecipeLabelDataInqResult_struct* operator-> ();

    const rmsRecipeLabelDataInqResult_struct& in() const;
    rmsRecipeLabelDataInqResult_struct& inout();
    rmsRecipeLabelDataInqResult_struct*& out();
    rmsRecipeLabelDataInqResult_struct* _retn();

    operator rmsRecipeLabelDataInqResult_struct_cvPtr () const;

    operator rmsRecipeLabelDataInqResult_struct_vPtr& ();

    operator const rmsRecipeLabelDataInqResult_struct& () const;

    operator rmsRecipeLabelDataInqResult_struct& ();

    protected:
    rmsRecipeLabelDataInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelDataInqResult_struct;
    typedef rmsRecipeLabelDataInqResult_struct rmsRecipeLabelDataInqResult;
    typedef rmsRecipeLabelDataInqResult_struct_var rmsRecipeLabelDataInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelDataInqResult;
    typedef rmsRecipeLabelData rmsRecipeLabelTree;
    typedef rmsRecipeLabelData_var rmsRecipeLabelTree_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelTree;
class  _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var;
class  _IDL_SEQ_rmsRecipeLabelTreeSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeLabelTree *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeLabelTreeSeq_0 ();
    _IDL_SEQ_rmsRecipeLabelTreeSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeLabelTreeSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeLabelTree* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeLabelTreeSeq_0 (const _IDL_SEQ_rmsRecipeLabelTreeSeq_0&);

    ~_IDL_SEQ_rmsRecipeLabelTreeSeq_0 ();

    _IDL_SEQ_rmsRecipeLabelTreeSeq_0& operator= (const _IDL_SEQ_rmsRecipeLabelTreeSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeLabelTree& operator [] (::CORBA::ULong indx);
    const rmsRecipeLabelTree& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeLabelTree* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeLabelTree* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeLabelTree* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeLabelTree* src, rmsRecipeLabelTree* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeLabelTree* data); 
  public:

    static rmsRecipeLabelTree* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeLabelTree* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeLabelTree* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeLabelTreeSeq_0> rmsRecipeLabelTreeSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeLabelTreeSeq_0* _IDL_SEQ_rmsRecipeLabelTreeSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeLabelTreeSeq_0* _IDL_SEQ_rmsRecipeLabelTreeSeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var ();

    _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var (_IDL_SEQ_rmsRecipeLabelTreeSeq_0 *_p);

    _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var (const _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var &_s);

    _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var &operator= (_IDL_SEQ_rmsRecipeLabelTreeSeq_0 *_p);

    _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var &operator= (const _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeLabelTreeSeq_0_var ();

    _IDL_SEQ_rmsRecipeLabelTreeSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeLabelTreeSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeLabelTreeSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeLabelTreeSeq_0() const;

    const rmsRecipeLabelTree& operator[] (::CORBA::ULong index) const;
    rmsRecipeLabelTree& operator[] (::CORBA::ULong index);
    const rmsRecipeLabelTree& operator[] (int index) const;
    rmsRecipeLabelTree& operator[] (int index);
    const _IDL_SEQ_rmsRecipeLabelTreeSeq_0& in() const;
    _IDL_SEQ_rmsRecipeLabelTreeSeq_0& inout();
    _IDL_SEQ_rmsRecipeLabelTreeSeq_0*& out();
    _IDL_SEQ_rmsRecipeLabelTreeSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeLabelTreeSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeLabelTreeSeq_0 _rmsRecipeLabelTreeSeq_seq;
    typedef _IDL_SEQ_rmsRecipeLabelTreeSeq_0 _rmsRecipeLabelTreeSeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeLabelTreeSeq_0 rmsRecipeLabelTreeSeq;
    typedef _IDL_SEQ_rmsRecipeLabelTreeSeq_0_var rmsRecipeLabelTreeSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelTreeSeq;
    class  rmsRecipeLabelTreeInqResult_struct_var;
    struct  rmsRecipeLabelTreeInqResult_struct {
        typedef rmsRecipeLabelTreeInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeLabelTreeSeq treeInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeLabelTreeInqResult_struct();
       rmsRecipeLabelTreeInqResult_struct(const rmsRecipeLabelTreeInqResult_struct&);
       rmsRecipeLabelTreeInqResult_struct& operator=(const rmsRecipeLabelTreeInqResult_struct&);
       static CORBA::Info<rmsRecipeLabelTreeInqResult_struct> rmsRecipeLabelTreeInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeLabelTreeInqResult_struct


typedef rmsRecipeLabelTreeInqResult_struct* rmsRecipeLabelTreeInqResult_struct_vPtr;
typedef const rmsRecipeLabelTreeInqResult_struct* rmsRecipeLabelTreeInqResult_struct_cvPtr;

class  rmsRecipeLabelTreeInqResult_struct_var
{
    public:

    rmsRecipeLabelTreeInqResult_struct_var ();

    rmsRecipeLabelTreeInqResult_struct_var (rmsRecipeLabelTreeInqResult_struct *_p);

    rmsRecipeLabelTreeInqResult_struct_var (const rmsRecipeLabelTreeInqResult_struct_var &_s);

    rmsRecipeLabelTreeInqResult_struct_var &operator= (rmsRecipeLabelTreeInqResult_struct *_p);

    rmsRecipeLabelTreeInqResult_struct_var &operator= (const rmsRecipeLabelTreeInqResult_struct_var &_s);

    ~rmsRecipeLabelTreeInqResult_struct_var ();

    rmsRecipeLabelTreeInqResult_struct* operator-> ();

    const rmsRecipeLabelTreeInqResult_struct& in() const;
    rmsRecipeLabelTreeInqResult_struct& inout();
    rmsRecipeLabelTreeInqResult_struct*& out();
    rmsRecipeLabelTreeInqResult_struct* _retn();

    operator rmsRecipeLabelTreeInqResult_struct_cvPtr () const;

    operator rmsRecipeLabelTreeInqResult_struct_vPtr& ();

    operator const rmsRecipeLabelTreeInqResult_struct& () const;

    operator rmsRecipeLabelTreeInqResult_struct& ();

    protected:
    rmsRecipeLabelTreeInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelTreeInqResult_struct;
    typedef rmsRecipeLabelTreeInqResult_struct rmsRecipeLabelTreeInqResult;
    typedef rmsRecipeLabelTreeInqResult_struct_var rmsRecipeLabelTreeInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeLabelTreeInqResult;
    class  rmsRecipeChange_struct_var;
    struct  rmsRecipeChange_struct {
        typedef rmsRecipeChange_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeId;
       ::CORBA::String_StructElem eventCreateTime;
       ::CORBA::String_StructElem modifier;
       ::CORBA::String_StructElem status;
       ::CORBA::String_StructElem eventProcessTime;
       ::CORBA::String_StructElem result;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeChange_struct();
       rmsRecipeChange_struct(const rmsRecipeChange_struct&);
       rmsRecipeChange_struct& operator=(const rmsRecipeChange_struct&);
       static CORBA::Info<rmsRecipeChange_struct> rmsRecipeChange_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRecipeChange_struct


typedef rmsRecipeChange_struct* rmsRecipeChange_struct_vPtr;
typedef const rmsRecipeChange_struct* rmsRecipeChange_struct_cvPtr;

class  rmsRecipeChange_struct_var
{
    public:

    rmsRecipeChange_struct_var ();

    rmsRecipeChange_struct_var (rmsRecipeChange_struct *_p);

    rmsRecipeChange_struct_var (const rmsRecipeChange_struct_var &_s);

    rmsRecipeChange_struct_var &operator= (rmsRecipeChange_struct *_p);

    rmsRecipeChange_struct_var &operator= (const rmsRecipeChange_struct_var &_s);

    ~rmsRecipeChange_struct_var ();

    rmsRecipeChange_struct* operator-> ();

    const rmsRecipeChange_struct& in() const;
    rmsRecipeChange_struct& inout();
    rmsRecipeChange_struct*& out();
    rmsRecipeChange_struct* _retn();

    operator rmsRecipeChange_struct_cvPtr () const;

    operator rmsRecipeChange_struct_vPtr& ();

    operator const rmsRecipeChange_struct& () const;

    operator rmsRecipeChange_struct& ();

    protected:
    rmsRecipeChange_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeChange_struct;
    typedef rmsRecipeChange_struct rmsRecipeChange;
    typedef rmsRecipeChange_struct_var rmsRecipeChange_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeChange;
class  _IDL_SEQ_rmsRecipeChangeSeq_0_var;
class  _IDL_SEQ_rmsRecipeChangeSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeChangeSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeChange *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeChangeSeq_0 ();
    _IDL_SEQ_rmsRecipeChangeSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeChangeSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeChange* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeChangeSeq_0 (const _IDL_SEQ_rmsRecipeChangeSeq_0&);

    ~_IDL_SEQ_rmsRecipeChangeSeq_0 ();

    _IDL_SEQ_rmsRecipeChangeSeq_0& operator= (const _IDL_SEQ_rmsRecipeChangeSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeChange& operator [] (::CORBA::ULong indx);
    const rmsRecipeChange& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeChange* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeChange* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeChange* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeChange* src, rmsRecipeChange* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeChange* data); 
  public:

    static rmsRecipeChange* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeChange* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeChange* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeChangeSeq_0> rmsRecipeChangeSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeChangeSeq_0* _IDL_SEQ_rmsRecipeChangeSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeChangeSeq_0* _IDL_SEQ_rmsRecipeChangeSeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeChangeSeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeChangeSeq_0_var ();

    _IDL_SEQ_rmsRecipeChangeSeq_0_var (_IDL_SEQ_rmsRecipeChangeSeq_0 *_p);

    _IDL_SEQ_rmsRecipeChangeSeq_0_var (const _IDL_SEQ_rmsRecipeChangeSeq_0_var &_s);

    _IDL_SEQ_rmsRecipeChangeSeq_0_var &operator= (_IDL_SEQ_rmsRecipeChangeSeq_0 *_p);

    _IDL_SEQ_rmsRecipeChangeSeq_0_var &operator= (const _IDL_SEQ_rmsRecipeChangeSeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeChangeSeq_0_var ();

    _IDL_SEQ_rmsRecipeChangeSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeChangeSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeChangeSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeChangeSeq_0() const;

    const rmsRecipeChange& operator[] (::CORBA::ULong index) const;
    rmsRecipeChange& operator[] (::CORBA::ULong index);
    const rmsRecipeChange& operator[] (int index) const;
    rmsRecipeChange& operator[] (int index);
    const _IDL_SEQ_rmsRecipeChangeSeq_0& in() const;
    _IDL_SEQ_rmsRecipeChangeSeq_0& inout();
    _IDL_SEQ_rmsRecipeChangeSeq_0*& out();
    _IDL_SEQ_rmsRecipeChangeSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeChangeSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeChangeSeq_0 _rmsRecipeChangeSeq_seq;
    typedef _IDL_SEQ_rmsRecipeChangeSeq_0 _rmsRecipeChangeSeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeChangeSeq_0 rmsRecipeChangeSeq;
    typedef _IDL_SEQ_rmsRecipeChangeSeq_0_var rmsRecipeChangeSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeChangeSeq;
    class  rmsRecipeChangeInqResult_struct_var;
    struct  rmsRecipeChangeInqResult_struct {
        typedef rmsRecipeChangeInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeChangeSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeChangeInqResult_struct();
       rmsRecipeChangeInqResult_struct(const rmsRecipeChangeInqResult_struct&);
       rmsRecipeChangeInqResult_struct& operator=(const rmsRecipeChangeInqResult_struct&);
       static CORBA::Info<rmsRecipeChangeInqResult_struct> rmsRecipeChangeInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeChangeInqResult_struct


typedef rmsRecipeChangeInqResult_struct* rmsRecipeChangeInqResult_struct_vPtr;
typedef const rmsRecipeChangeInqResult_struct* rmsRecipeChangeInqResult_struct_cvPtr;

class  rmsRecipeChangeInqResult_struct_var
{
    public:

    rmsRecipeChangeInqResult_struct_var ();

    rmsRecipeChangeInqResult_struct_var (rmsRecipeChangeInqResult_struct *_p);

    rmsRecipeChangeInqResult_struct_var (const rmsRecipeChangeInqResult_struct_var &_s);

    rmsRecipeChangeInqResult_struct_var &operator= (rmsRecipeChangeInqResult_struct *_p);

    rmsRecipeChangeInqResult_struct_var &operator= (const rmsRecipeChangeInqResult_struct_var &_s);

    ~rmsRecipeChangeInqResult_struct_var ();

    rmsRecipeChangeInqResult_struct* operator-> ();

    const rmsRecipeChangeInqResult_struct& in() const;
    rmsRecipeChangeInqResult_struct& inout();
    rmsRecipeChangeInqResult_struct*& out();
    rmsRecipeChangeInqResult_struct* _retn();

    operator rmsRecipeChangeInqResult_struct_cvPtr () const;

    operator rmsRecipeChangeInqResult_struct_vPtr& ();

    operator const rmsRecipeChangeInqResult_struct& () const;

    operator rmsRecipeChangeInqResult_struct& ();

    protected:
    rmsRecipeChangeInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeChangeInqResult_struct;
    typedef rmsRecipeChangeInqResult_struct rmsRecipeChangeInqResult;
    typedef rmsRecipeChangeInqResult_struct_var rmsRecipeChangeInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeChangeInqResult;
    class  rmsRcipeMatchedInqResult_struct_var;
    struct  rmsRcipeMatchedInqResult_struct {
        typedef rmsRcipeMatchedInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeInfoSequence strRecipeInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcipeMatchedInqResult_struct();
       rmsRcipeMatchedInqResult_struct(const rmsRcipeMatchedInqResult_struct&);
       rmsRcipeMatchedInqResult_struct& operator=(const rmsRcipeMatchedInqResult_struct&);
       static CORBA::Info<rmsRcipeMatchedInqResult_struct> rmsRcipeMatchedInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcipeMatchedInqResult_struct


typedef rmsRcipeMatchedInqResult_struct* rmsRcipeMatchedInqResult_struct_vPtr;
typedef const rmsRcipeMatchedInqResult_struct* rmsRcipeMatchedInqResult_struct_cvPtr;

class  rmsRcipeMatchedInqResult_struct_var
{
    public:

    rmsRcipeMatchedInqResult_struct_var ();

    rmsRcipeMatchedInqResult_struct_var (rmsRcipeMatchedInqResult_struct *_p);

    rmsRcipeMatchedInqResult_struct_var (const rmsRcipeMatchedInqResult_struct_var &_s);

    rmsRcipeMatchedInqResult_struct_var &operator= (rmsRcipeMatchedInqResult_struct *_p);

    rmsRcipeMatchedInqResult_struct_var &operator= (const rmsRcipeMatchedInqResult_struct_var &_s);

    ~rmsRcipeMatchedInqResult_struct_var ();

    rmsRcipeMatchedInqResult_struct* operator-> ();

    const rmsRcipeMatchedInqResult_struct& in() const;
    rmsRcipeMatchedInqResult_struct& inout();
    rmsRcipeMatchedInqResult_struct*& out();
    rmsRcipeMatchedInqResult_struct* _retn();

    operator rmsRcipeMatchedInqResult_struct_cvPtr () const;

    operator rmsRcipeMatchedInqResult_struct_vPtr& ();

    operator const rmsRcipeMatchedInqResult_struct& () const;

    operator rmsRcipeMatchedInqResult_struct& ();

    protected:
    rmsRcipeMatchedInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcipeMatchedInqResult_struct;
    typedef rmsRcipeMatchedInqResult_struct rmsRcipeMatchedInqResult;
    typedef rmsRcipeMatchedInqResult_struct_var rmsRcipeMatchedInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcipeMatchedInqResult;
    class  rmsECBatch_struct_var;
    struct  rmsECBatch_struct {
        typedef rmsECBatch_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::Long batchNo;
       ::CORBA::String_StructElem createTime;
       ::CORBA::LongLong minConstId;
       ::CORBA::LongLong maxConstId;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsECBatch_struct();
       rmsECBatch_struct(const rmsECBatch_struct&);
       rmsECBatch_struct& operator=(const rmsECBatch_struct&);
       static CORBA::Info<rmsECBatch_struct> rmsECBatch_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsECBatch_struct


typedef rmsECBatch_struct* rmsECBatch_struct_vPtr;
typedef const rmsECBatch_struct* rmsECBatch_struct_cvPtr;

class  rmsECBatch_struct_var
{
    public:

    rmsECBatch_struct_var ();

    rmsECBatch_struct_var (rmsECBatch_struct *_p);

    rmsECBatch_struct_var (const rmsECBatch_struct_var &_s);

    rmsECBatch_struct_var &operator= (rmsECBatch_struct *_p);

    rmsECBatch_struct_var &operator= (const rmsECBatch_struct_var &_s);

    ~rmsECBatch_struct_var ();

    rmsECBatch_struct* operator-> ();

    const rmsECBatch_struct& in() const;
    rmsECBatch_struct& inout();
    rmsECBatch_struct*& out();
    rmsECBatch_struct* _retn();

    operator rmsECBatch_struct_cvPtr () const;

    operator rmsECBatch_struct_vPtr& ();

    operator const rmsECBatch_struct& () const;

    operator rmsECBatch_struct& ();

    protected:
    rmsECBatch_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatch_struct;
    typedef rmsECBatch_struct rmsECBatch;
    typedef rmsECBatch_struct_var rmsECBatch_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatch;
class  _IDL_SEQ_rmsECBatchSeq_0_var;
class  _IDL_SEQ_rmsECBatchSeq_0 {
    public:
        typedef _IDL_SEQ_rmsECBatchSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsECBatch *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsECBatchSeq_0 ();
    _IDL_SEQ_rmsECBatchSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsECBatchSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsECBatch* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsECBatchSeq_0 (const _IDL_SEQ_rmsECBatchSeq_0&);

    ~_IDL_SEQ_rmsECBatchSeq_0 ();

    _IDL_SEQ_rmsECBatchSeq_0& operator= (const _IDL_SEQ_rmsECBatchSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsECBatch& operator [] (::CORBA::ULong indx);
    const rmsECBatch& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsECBatch* get_buffer (::CORBA::Boolean orphan=0);
    const rmsECBatch* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsECBatch* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsECBatch* src, rmsECBatch* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsECBatch* data); 
  public:

    static rmsECBatch* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsECBatch* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsECBatch* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsECBatchSeq_0> rmsECBatchSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsECBatchSeq_0* _IDL_SEQ_rmsECBatchSeq_0_vPtr;
typedef const _IDL_SEQ_rmsECBatchSeq_0* _IDL_SEQ_rmsECBatchSeq_0_cvPtr;

class  _IDL_SEQ_rmsECBatchSeq_0_var
{
    public:

    _IDL_SEQ_rmsECBatchSeq_0_var ();

    _IDL_SEQ_rmsECBatchSeq_0_var (_IDL_SEQ_rmsECBatchSeq_0 *_p);

    _IDL_SEQ_rmsECBatchSeq_0_var (const _IDL_SEQ_rmsECBatchSeq_0_var &_s);

    _IDL_SEQ_rmsECBatchSeq_0_var &operator= (_IDL_SEQ_rmsECBatchSeq_0 *_p);

    _IDL_SEQ_rmsECBatchSeq_0_var &operator= (const _IDL_SEQ_rmsECBatchSeq_0_var &_s);

    ~_IDL_SEQ_rmsECBatchSeq_0_var ();

    _IDL_SEQ_rmsECBatchSeq_0* operator-> ();

    operator _IDL_SEQ_rmsECBatchSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsECBatchSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsECBatchSeq_0() const;

    const rmsECBatch& operator[] (::CORBA::ULong index) const;
    rmsECBatch& operator[] (::CORBA::ULong index);
    const rmsECBatch& operator[] (int index) const;
    rmsECBatch& operator[] (int index);
    const _IDL_SEQ_rmsECBatchSeq_0& in() const;
    _IDL_SEQ_rmsECBatchSeq_0& inout();
    _IDL_SEQ_rmsECBatchSeq_0*& out();
    _IDL_SEQ_rmsECBatchSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsECBatchSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsECBatchSeq_0 _rmsECBatchSeq_seq;
    typedef _IDL_SEQ_rmsECBatchSeq_0 _rmsECBatchSeq_seq_1;
    typedef _IDL_SEQ_rmsECBatchSeq_0 rmsECBatchSeq;
    typedef _IDL_SEQ_rmsECBatchSeq_0_var rmsECBatchSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatchSeq;
    class  rmsECBatchInqResult_struct_var;
    struct  rmsECBatchInqResult_struct {
        typedef rmsECBatchInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsECBatchSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsECBatchInqResult_struct();
       rmsECBatchInqResult_struct(const rmsECBatchInqResult_struct&);
       rmsECBatchInqResult_struct& operator=(const rmsECBatchInqResult_struct&);
       static CORBA::Info<rmsECBatchInqResult_struct> rmsECBatchInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsECBatchInqResult_struct


typedef rmsECBatchInqResult_struct* rmsECBatchInqResult_struct_vPtr;
typedef const rmsECBatchInqResult_struct* rmsECBatchInqResult_struct_cvPtr;

class  rmsECBatchInqResult_struct_var
{
    public:

    rmsECBatchInqResult_struct_var ();

    rmsECBatchInqResult_struct_var (rmsECBatchInqResult_struct *_p);

    rmsECBatchInqResult_struct_var (const rmsECBatchInqResult_struct_var &_s);

    rmsECBatchInqResult_struct_var &operator= (rmsECBatchInqResult_struct *_p);

    rmsECBatchInqResult_struct_var &operator= (const rmsECBatchInqResult_struct_var &_s);

    ~rmsECBatchInqResult_struct_var ();

    rmsECBatchInqResult_struct* operator-> ();

    const rmsECBatchInqResult_struct& in() const;
    rmsECBatchInqResult_struct& inout();
    rmsECBatchInqResult_struct*& out();
    rmsECBatchInqResult_struct* _retn();

    operator rmsECBatchInqResult_struct_cvPtr () const;

    operator rmsECBatchInqResult_struct_vPtr& ();

    operator const rmsECBatchInqResult_struct& () const;

    operator rmsECBatchInqResult_struct& ();

    protected:
    rmsECBatchInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatchInqResult_struct;
    typedef rmsECBatchInqResult_struct rmsECBatchInqResult;
    typedef rmsECBatchInqResult_struct_var rmsECBatchInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatchInqResult;
    class  rmsECBatchAuditFailInfo_struct_var;
    struct  rmsECBatchAuditFailInfo_struct {
        typedef rmsECBatchAuditFailInfo_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqpID;
       ::CORBA::LongLong constID;
       ::CORBA::Boolean svidflag;
       ::CORBA::String_StructElem listpath;
       ::CORBA::String_StructElem constname;
       ::CORBA::String_StructElem constvalue;
       ::CORBA::Boolean audit;
       ::CORBA::Long tolerance;
       ::CORBA::String_StructElem maxvalue;
       ::CORBA::String_StructElem minvalue;
       ::CORBA::String_StructElem toolconstvalue;
       ::CORBA::String_StructElem createtime;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsECBatchAuditFailInfo_struct();
       rmsECBatchAuditFailInfo_struct(const rmsECBatchAuditFailInfo_struct&);
       rmsECBatchAuditFailInfo_struct& operator=(const rmsECBatchAuditFailInfo_struct&);
       static CORBA::Info<rmsECBatchAuditFailInfo_struct> rmsECBatchAuditFailInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsECBatchAuditFailInfo_struct


typedef rmsECBatchAuditFailInfo_struct* rmsECBatchAuditFailInfo_struct_vPtr;
typedef const rmsECBatchAuditFailInfo_struct* rmsECBatchAuditFailInfo_struct_cvPtr;

class  rmsECBatchAuditFailInfo_struct_var
{
    public:

    rmsECBatchAuditFailInfo_struct_var ();

    rmsECBatchAuditFailInfo_struct_var (rmsECBatchAuditFailInfo_struct *_p);

    rmsECBatchAuditFailInfo_struct_var (const rmsECBatchAuditFailInfo_struct_var &_s);

    rmsECBatchAuditFailInfo_struct_var &operator= (rmsECBatchAuditFailInfo_struct *_p);

    rmsECBatchAuditFailInfo_struct_var &operator= (const rmsECBatchAuditFailInfo_struct_var &_s);

    ~rmsECBatchAuditFailInfo_struct_var ();

    rmsECBatchAuditFailInfo_struct* operator-> ();

    const rmsECBatchAuditFailInfo_struct& in() const;
    rmsECBatchAuditFailInfo_struct& inout();
    rmsECBatchAuditFailInfo_struct*& out();
    rmsECBatchAuditFailInfo_struct* _retn();

    operator rmsECBatchAuditFailInfo_struct_cvPtr () const;

    operator rmsECBatchAuditFailInfo_struct_vPtr& ();

    operator const rmsECBatchAuditFailInfo_struct& () const;

    operator rmsECBatchAuditFailInfo_struct& ();

    protected:
    rmsECBatchAuditFailInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatchAuditFailInfo_struct;
    typedef rmsECBatchAuditFailInfo_struct rmsECBatchAuditFailInfo;
    typedef rmsECBatchAuditFailInfo_struct_var rmsECBatchAuditFailInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatchAuditFailInfo;
class  _IDL_SEQ_rmsECBatchAuditFailSeq_0_var;
class  _IDL_SEQ_rmsECBatchAuditFailSeq_0 {
    public:
        typedef _IDL_SEQ_rmsECBatchAuditFailSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsECBatchAuditFailInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsECBatchAuditFailSeq_0 ();
    _IDL_SEQ_rmsECBatchAuditFailSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsECBatchAuditFailSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsECBatchAuditFailInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsECBatchAuditFailSeq_0 (const _IDL_SEQ_rmsECBatchAuditFailSeq_0&);

    ~_IDL_SEQ_rmsECBatchAuditFailSeq_0 ();

    _IDL_SEQ_rmsECBatchAuditFailSeq_0& operator= (const _IDL_SEQ_rmsECBatchAuditFailSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsECBatchAuditFailInfo& operator [] (::CORBA::ULong indx);
    const rmsECBatchAuditFailInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsECBatchAuditFailInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsECBatchAuditFailInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsECBatchAuditFailInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsECBatchAuditFailInfo* src, rmsECBatchAuditFailInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsECBatchAuditFailInfo* data); 
  public:

    static rmsECBatchAuditFailInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsECBatchAuditFailInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsECBatchAuditFailInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsECBatchAuditFailSeq_0> rmsECBatchAuditFailSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsECBatchAuditFailSeq_0* _IDL_SEQ_rmsECBatchAuditFailSeq_0_vPtr;
typedef const _IDL_SEQ_rmsECBatchAuditFailSeq_0* _IDL_SEQ_rmsECBatchAuditFailSeq_0_cvPtr;

class  _IDL_SEQ_rmsECBatchAuditFailSeq_0_var
{
    public:

    _IDL_SEQ_rmsECBatchAuditFailSeq_0_var ();

    _IDL_SEQ_rmsECBatchAuditFailSeq_0_var (_IDL_SEQ_rmsECBatchAuditFailSeq_0 *_p);

    _IDL_SEQ_rmsECBatchAuditFailSeq_0_var (const _IDL_SEQ_rmsECBatchAuditFailSeq_0_var &_s);

    _IDL_SEQ_rmsECBatchAuditFailSeq_0_var &operator= (_IDL_SEQ_rmsECBatchAuditFailSeq_0 *_p);

    _IDL_SEQ_rmsECBatchAuditFailSeq_0_var &operator= (const _IDL_SEQ_rmsECBatchAuditFailSeq_0_var &_s);

    ~_IDL_SEQ_rmsECBatchAuditFailSeq_0_var ();

    _IDL_SEQ_rmsECBatchAuditFailSeq_0* operator-> ();

    operator _IDL_SEQ_rmsECBatchAuditFailSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsECBatchAuditFailSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsECBatchAuditFailSeq_0() const;

    const rmsECBatchAuditFailInfo& operator[] (::CORBA::ULong index) const;
    rmsECBatchAuditFailInfo& operator[] (::CORBA::ULong index);
    const rmsECBatchAuditFailInfo& operator[] (int index) const;
    rmsECBatchAuditFailInfo& operator[] (int index);
    const _IDL_SEQ_rmsECBatchAuditFailSeq_0& in() const;
    _IDL_SEQ_rmsECBatchAuditFailSeq_0& inout();
    _IDL_SEQ_rmsECBatchAuditFailSeq_0*& out();
    _IDL_SEQ_rmsECBatchAuditFailSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsECBatchAuditFailSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsECBatchAuditFailSeq_0 _rmsECBatchAuditFailSeq_seq;
    typedef _IDL_SEQ_rmsECBatchAuditFailSeq_0 _rmsECBatchAuditFailSeq_seq_1;
    typedef _IDL_SEQ_rmsECBatchAuditFailSeq_0 rmsECBatchAuditFailSeq;
    typedef _IDL_SEQ_rmsECBatchAuditFailSeq_0_var rmsECBatchAuditFailSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatchAuditFailSeq;
    class  rmsECBatchAuditFailInqResult_struct_var;
    struct  rmsECBatchAuditFailInqResult_struct {
        typedef rmsECBatchAuditFailInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsECBatchAuditFailSeq profiles;
       ::CORBA::Boolean overSearchCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsECBatchAuditFailInqResult_struct();
       rmsECBatchAuditFailInqResult_struct(const rmsECBatchAuditFailInqResult_struct&);
       rmsECBatchAuditFailInqResult_struct& operator=(const rmsECBatchAuditFailInqResult_struct&);
       static CORBA::Info<rmsECBatchAuditFailInqResult_struct> rmsECBatchAuditFailInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsECBatchAuditFailInqResult_struct


typedef rmsECBatchAuditFailInqResult_struct* rmsECBatchAuditFailInqResult_struct_vPtr;
typedef const rmsECBatchAuditFailInqResult_struct* rmsECBatchAuditFailInqResult_struct_cvPtr;

class  rmsECBatchAuditFailInqResult_struct_var
{
    public:

    rmsECBatchAuditFailInqResult_struct_var ();

    rmsECBatchAuditFailInqResult_struct_var (rmsECBatchAuditFailInqResult_struct *_p);

    rmsECBatchAuditFailInqResult_struct_var (const rmsECBatchAuditFailInqResult_struct_var &_s);

    rmsECBatchAuditFailInqResult_struct_var &operator= (rmsECBatchAuditFailInqResult_struct *_p);

    rmsECBatchAuditFailInqResult_struct_var &operator= (const rmsECBatchAuditFailInqResult_struct_var &_s);

    ~rmsECBatchAuditFailInqResult_struct_var ();

    rmsECBatchAuditFailInqResult_struct* operator-> ();

    const rmsECBatchAuditFailInqResult_struct& in() const;
    rmsECBatchAuditFailInqResult_struct& inout();
    rmsECBatchAuditFailInqResult_struct*& out();
    rmsECBatchAuditFailInqResult_struct* _retn();

    operator rmsECBatchAuditFailInqResult_struct_cvPtr () const;

    operator rmsECBatchAuditFailInqResult_struct_vPtr& ();

    operator const rmsECBatchAuditFailInqResult_struct& () const;

    operator rmsECBatchAuditFailInqResult_struct& ();

    protected:
    rmsECBatchAuditFailInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatchAuditFailInqResult_struct;
    typedef rmsECBatchAuditFailInqResult_struct rmsECBatchAuditFailInqResult;
    typedef rmsECBatchAuditFailInqResult_struct_var rmsECBatchAuditFailInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECBatchAuditFailInqResult;
    class  csLotAttrForAudit_struct_var;
    struct  csLotAttrForAudit_struct {
        typedef csLotAttrForAudit_struct_var _var_type;
       ::CORBA::String_StructElem lotId;
       ::CORBA::String_StructElem lotType;
       ::CORBA::String_StructElem lotOwnerDept;
       ::CORBA::Boolean SERFlag;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLotAttrForAudit_struct();
       csLotAttrForAudit_struct(const csLotAttrForAudit_struct&);
       csLotAttrForAudit_struct& operator=(const csLotAttrForAudit_struct&);
       static CORBA::Info<csLotAttrForAudit_struct> csLotAttrForAudit_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csLotAttrForAudit_struct


typedef csLotAttrForAudit_struct* csLotAttrForAudit_struct_vPtr;
typedef const csLotAttrForAudit_struct* csLotAttrForAudit_struct_cvPtr;

class  csLotAttrForAudit_struct_var
{
    public:

    csLotAttrForAudit_struct_var ();

    csLotAttrForAudit_struct_var (csLotAttrForAudit_struct *_p);

    csLotAttrForAudit_struct_var (const csLotAttrForAudit_struct_var &_s);

    csLotAttrForAudit_struct_var &operator= (csLotAttrForAudit_struct *_p);

    csLotAttrForAudit_struct_var &operator= (const csLotAttrForAudit_struct_var &_s);

    ~csLotAttrForAudit_struct_var ();

    csLotAttrForAudit_struct* operator-> ();

    const csLotAttrForAudit_struct& in() const;
    csLotAttrForAudit_struct& inout();
    csLotAttrForAudit_struct*& out();
    csLotAttrForAudit_struct* _retn();

    operator csLotAttrForAudit_struct_cvPtr () const;

    operator csLotAttrForAudit_struct_vPtr& ();

    operator const csLotAttrForAudit_struct& () const;

    operator csLotAttrForAudit_struct& ();

    protected:
    csLotAttrForAudit_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLotAttrForAudit_struct;
    typedef csLotAttrForAudit_struct csLotAttrForAudit;
    typedef csLotAttrForAudit_struct_var csLotAttrForAudit_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotAttrForAudit;
class  _IDL_SEQ_csLotAttrForAuditSequence_0_var;
class  _IDL_SEQ_csLotAttrForAuditSequence_0 {
    public:
        typedef _IDL_SEQ_csLotAttrForAuditSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csLotAttrForAudit *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csLotAttrForAuditSequence_0 ();
    _IDL_SEQ_csLotAttrForAuditSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csLotAttrForAuditSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csLotAttrForAudit* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csLotAttrForAuditSequence_0 (const _IDL_SEQ_csLotAttrForAuditSequence_0&);

    ~_IDL_SEQ_csLotAttrForAuditSequence_0 ();

    _IDL_SEQ_csLotAttrForAuditSequence_0& operator= (const _IDL_SEQ_csLotAttrForAuditSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csLotAttrForAudit& operator [] (::CORBA::ULong indx);
    const csLotAttrForAudit& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csLotAttrForAudit* get_buffer (::CORBA::Boolean orphan=0);
    const csLotAttrForAudit* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csLotAttrForAudit* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csLotAttrForAudit* src, csLotAttrForAudit* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csLotAttrForAudit* data); 
  public:

    static csLotAttrForAudit* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csLotAttrForAudit* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csLotAttrForAudit* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csLotAttrForAuditSequence_0> csLotAttrForAuditSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csLotAttrForAuditSequence_0* _IDL_SEQ_csLotAttrForAuditSequence_0_vPtr;
typedef const _IDL_SEQ_csLotAttrForAuditSequence_0* _IDL_SEQ_csLotAttrForAuditSequence_0_cvPtr;

class  _IDL_SEQ_csLotAttrForAuditSequence_0_var
{
    public:

    _IDL_SEQ_csLotAttrForAuditSequence_0_var ();

    _IDL_SEQ_csLotAttrForAuditSequence_0_var (_IDL_SEQ_csLotAttrForAuditSequence_0 *_p);

    _IDL_SEQ_csLotAttrForAuditSequence_0_var (const _IDL_SEQ_csLotAttrForAuditSequence_0_var &_s);

    _IDL_SEQ_csLotAttrForAuditSequence_0_var &operator= (_IDL_SEQ_csLotAttrForAuditSequence_0 *_p);

    _IDL_SEQ_csLotAttrForAuditSequence_0_var &operator= (const _IDL_SEQ_csLotAttrForAuditSequence_0_var &_s);

    ~_IDL_SEQ_csLotAttrForAuditSequence_0_var ();

    _IDL_SEQ_csLotAttrForAuditSequence_0* operator-> ();

    operator _IDL_SEQ_csLotAttrForAuditSequence_0_cvPtr () const;

    operator _IDL_SEQ_csLotAttrForAuditSequence_0_vPtr& ();

    operator _IDL_SEQ_csLotAttrForAuditSequence_0() const;

    const csLotAttrForAudit& operator[] (::CORBA::ULong index) const;
    csLotAttrForAudit& operator[] (::CORBA::ULong index);
    const csLotAttrForAudit& operator[] (int index) const;
    csLotAttrForAudit& operator[] (int index);
    const _IDL_SEQ_csLotAttrForAuditSequence_0& in() const;
    _IDL_SEQ_csLotAttrForAuditSequence_0& inout();
    _IDL_SEQ_csLotAttrForAuditSequence_0*& out();
    _IDL_SEQ_csLotAttrForAuditSequence_0* _retn();

    protected:
    _IDL_SEQ_csLotAttrForAuditSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csLotAttrForAuditSequence_0 _csLotAttrForAuditSequence_seq;
    typedef _IDL_SEQ_csLotAttrForAuditSequence_0 _csLotAttrForAuditSequence_seq_1;
    typedef _IDL_SEQ_csLotAttrForAuditSequence_0 csLotAttrForAuditSequence;
    typedef _IDL_SEQ_csLotAttrForAuditSequence_0_var csLotAttrForAuditSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotAttrForAuditSequence;
    class  rmsLotAuditSkip_struct_var;
    struct  rmsLotAuditSkip_struct {
        typedef rmsLotAuditSkip_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem lotId;
       ::CORBA::String_StructElem createUser;
       ::CORBA::String_StructElem createTime;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsLotAuditSkip_struct();
       rmsLotAuditSkip_struct(const rmsLotAuditSkip_struct&);
       rmsLotAuditSkip_struct& operator=(const rmsLotAuditSkip_struct&);
       static CORBA::Info<rmsLotAuditSkip_struct> rmsLotAuditSkip_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsLotAuditSkip_struct


typedef rmsLotAuditSkip_struct* rmsLotAuditSkip_struct_vPtr;
typedef const rmsLotAuditSkip_struct* rmsLotAuditSkip_struct_cvPtr;

class  rmsLotAuditSkip_struct_var
{
    public:

    rmsLotAuditSkip_struct_var ();

    rmsLotAuditSkip_struct_var (rmsLotAuditSkip_struct *_p);

    rmsLotAuditSkip_struct_var (const rmsLotAuditSkip_struct_var &_s);

    rmsLotAuditSkip_struct_var &operator= (rmsLotAuditSkip_struct *_p);

    rmsLotAuditSkip_struct_var &operator= (const rmsLotAuditSkip_struct_var &_s);

    ~rmsLotAuditSkip_struct_var ();

    rmsLotAuditSkip_struct* operator-> ();

    const rmsLotAuditSkip_struct& in() const;
    rmsLotAuditSkip_struct& inout();
    rmsLotAuditSkip_struct*& out();
    rmsLotAuditSkip_struct* _retn();

    operator rmsLotAuditSkip_struct_cvPtr () const;

    operator rmsLotAuditSkip_struct_vPtr& ();

    operator const rmsLotAuditSkip_struct& () const;

    operator rmsLotAuditSkip_struct& ();

    protected:
    rmsLotAuditSkip_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsLotAuditSkip_struct;
    typedef rmsLotAuditSkip_struct rmsLotAuditSkip;
    typedef rmsLotAuditSkip_struct_var rmsLotAuditSkip_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLotAuditSkip;
class  _IDL_SEQ_rmsLotAuditSkipSeq_0_var;
class  _IDL_SEQ_rmsLotAuditSkipSeq_0 {
    public:
        typedef _IDL_SEQ_rmsLotAuditSkipSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsLotAuditSkip *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsLotAuditSkipSeq_0 ();
    _IDL_SEQ_rmsLotAuditSkipSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsLotAuditSkipSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsLotAuditSkip* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsLotAuditSkipSeq_0 (const _IDL_SEQ_rmsLotAuditSkipSeq_0&);

    ~_IDL_SEQ_rmsLotAuditSkipSeq_0 ();

    _IDL_SEQ_rmsLotAuditSkipSeq_0& operator= (const _IDL_SEQ_rmsLotAuditSkipSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsLotAuditSkip& operator [] (::CORBA::ULong indx);
    const rmsLotAuditSkip& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsLotAuditSkip* get_buffer (::CORBA::Boolean orphan=0);
    const rmsLotAuditSkip* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsLotAuditSkip* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsLotAuditSkip* src, rmsLotAuditSkip* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsLotAuditSkip* data); 
  public:

    static rmsLotAuditSkip* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsLotAuditSkip* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsLotAuditSkip* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsLotAuditSkipSeq_0> rmsLotAuditSkipSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsLotAuditSkipSeq_0* _IDL_SEQ_rmsLotAuditSkipSeq_0_vPtr;
typedef const _IDL_SEQ_rmsLotAuditSkipSeq_0* _IDL_SEQ_rmsLotAuditSkipSeq_0_cvPtr;

class  _IDL_SEQ_rmsLotAuditSkipSeq_0_var
{
    public:

    _IDL_SEQ_rmsLotAuditSkipSeq_0_var ();

    _IDL_SEQ_rmsLotAuditSkipSeq_0_var (_IDL_SEQ_rmsLotAuditSkipSeq_0 *_p);

    _IDL_SEQ_rmsLotAuditSkipSeq_0_var (const _IDL_SEQ_rmsLotAuditSkipSeq_0_var &_s);

    _IDL_SEQ_rmsLotAuditSkipSeq_0_var &operator= (_IDL_SEQ_rmsLotAuditSkipSeq_0 *_p);

    _IDL_SEQ_rmsLotAuditSkipSeq_0_var &operator= (const _IDL_SEQ_rmsLotAuditSkipSeq_0_var &_s);

    ~_IDL_SEQ_rmsLotAuditSkipSeq_0_var ();

    _IDL_SEQ_rmsLotAuditSkipSeq_0* operator-> ();

    operator _IDL_SEQ_rmsLotAuditSkipSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsLotAuditSkipSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsLotAuditSkipSeq_0() const;

    const rmsLotAuditSkip& operator[] (::CORBA::ULong index) const;
    rmsLotAuditSkip& operator[] (::CORBA::ULong index);
    const rmsLotAuditSkip& operator[] (int index) const;
    rmsLotAuditSkip& operator[] (int index);
    const _IDL_SEQ_rmsLotAuditSkipSeq_0& in() const;
    _IDL_SEQ_rmsLotAuditSkipSeq_0& inout();
    _IDL_SEQ_rmsLotAuditSkipSeq_0*& out();
    _IDL_SEQ_rmsLotAuditSkipSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsLotAuditSkipSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsLotAuditSkipSeq_0 _rmsLotAuditSkipSeq_seq;
    typedef _IDL_SEQ_rmsLotAuditSkipSeq_0 _rmsLotAuditSkipSeq_seq_1;
    typedef _IDL_SEQ_rmsLotAuditSkipSeq_0 rmsLotAuditSkipSeq;
    typedef _IDL_SEQ_rmsLotAuditSkipSeq_0_var rmsLotAuditSkipSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLotAuditSkipSeq;
    class  rmsLotAuditSkipInqResult_struct_var;
    struct  rmsLotAuditSkipInqResult_struct {
        typedef rmsLotAuditSkipInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsLotAuditSkipSeq lotInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsLotAuditSkipInqResult_struct();
       rmsLotAuditSkipInqResult_struct(const rmsLotAuditSkipInqResult_struct&);
       rmsLotAuditSkipInqResult_struct& operator=(const rmsLotAuditSkipInqResult_struct&);
       static CORBA::Info<rmsLotAuditSkipInqResult_struct> rmsLotAuditSkipInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsLotAuditSkipInqResult_struct


typedef rmsLotAuditSkipInqResult_struct* rmsLotAuditSkipInqResult_struct_vPtr;
typedef const rmsLotAuditSkipInqResult_struct* rmsLotAuditSkipInqResult_struct_cvPtr;

class  rmsLotAuditSkipInqResult_struct_var
{
    public:

    rmsLotAuditSkipInqResult_struct_var ();

    rmsLotAuditSkipInqResult_struct_var (rmsLotAuditSkipInqResult_struct *_p);

    rmsLotAuditSkipInqResult_struct_var (const rmsLotAuditSkipInqResult_struct_var &_s);

    rmsLotAuditSkipInqResult_struct_var &operator= (rmsLotAuditSkipInqResult_struct *_p);

    rmsLotAuditSkipInqResult_struct_var &operator= (const rmsLotAuditSkipInqResult_struct_var &_s);

    ~rmsLotAuditSkipInqResult_struct_var ();

    rmsLotAuditSkipInqResult_struct* operator-> ();

    const rmsLotAuditSkipInqResult_struct& in() const;
    rmsLotAuditSkipInqResult_struct& inout();
    rmsLotAuditSkipInqResult_struct*& out();
    rmsLotAuditSkipInqResult_struct* _retn();

    operator rmsLotAuditSkipInqResult_struct_cvPtr () const;

    operator rmsLotAuditSkipInqResult_struct_vPtr& ();

    operator const rmsLotAuditSkipInqResult_struct& () const;

    operator rmsLotAuditSkipInqResult_struct& ();

    protected:
    rmsLotAuditSkipInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsLotAuditSkipInqResult_struct;
    typedef rmsLotAuditSkipInqResult_struct rmsLotAuditSkipInqResult;
    typedef rmsLotAuditSkipInqResult_struct_var rmsLotAuditSkipInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLotAuditSkipInqResult;
    class  rmsEqpConstantBlock_struct_var;
    struct  rmsEqpConstantBlock_struct {
        typedef rmsEqpConstantBlock_struct_var _var_type;
       ::CORBA::String_StructElem blockName;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpConstantBlock_struct();
       rmsEqpConstantBlock_struct(const rmsEqpConstantBlock_struct&);
       rmsEqpConstantBlock_struct& operator=(const rmsEqpConstantBlock_struct&);
       static CORBA::Info<rmsEqpConstantBlock_struct> rmsEqpConstantBlock_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsEqpConstantBlock_struct


typedef rmsEqpConstantBlock_struct* rmsEqpConstantBlock_struct_vPtr;
typedef const rmsEqpConstantBlock_struct* rmsEqpConstantBlock_struct_cvPtr;

class  rmsEqpConstantBlock_struct_var
{
    public:

    rmsEqpConstantBlock_struct_var ();

    rmsEqpConstantBlock_struct_var (rmsEqpConstantBlock_struct *_p);

    rmsEqpConstantBlock_struct_var (const rmsEqpConstantBlock_struct_var &_s);

    rmsEqpConstantBlock_struct_var &operator= (rmsEqpConstantBlock_struct *_p);

    rmsEqpConstantBlock_struct_var &operator= (const rmsEqpConstantBlock_struct_var &_s);

    ~rmsEqpConstantBlock_struct_var ();

    rmsEqpConstantBlock_struct* operator-> ();

    const rmsEqpConstantBlock_struct& in() const;
    rmsEqpConstantBlock_struct& inout();
    rmsEqpConstantBlock_struct*& out();
    rmsEqpConstantBlock_struct* _retn();

    operator rmsEqpConstantBlock_struct_cvPtr () const;

    operator rmsEqpConstantBlock_struct_vPtr& ();

    operator const rmsEqpConstantBlock_struct& () const;

    operator rmsEqpConstantBlock_struct& ();

    protected:
    rmsEqpConstantBlock_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantBlock_struct;
    typedef rmsEqpConstantBlock_struct rmsEqpConstantBlock;
    typedef rmsEqpConstantBlock_struct_var rmsEqpConstantBlock_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantBlock;
class  _IDL_SEQ_rmsEqpConstantBlockSequence_0_var;
class  _IDL_SEQ_rmsEqpConstantBlockSequence_0 {
    public:
        typedef _IDL_SEQ_rmsEqpConstantBlockSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsEqpConstantBlock *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsEqpConstantBlockSequence_0 ();
    _IDL_SEQ_rmsEqpConstantBlockSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsEqpConstantBlockSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpConstantBlock* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsEqpConstantBlockSequence_0 (const _IDL_SEQ_rmsEqpConstantBlockSequence_0&);

    ~_IDL_SEQ_rmsEqpConstantBlockSequence_0 ();

    _IDL_SEQ_rmsEqpConstantBlockSequence_0& operator= (const _IDL_SEQ_rmsEqpConstantBlockSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsEqpConstantBlock& operator [] (::CORBA::ULong indx);
    const rmsEqpConstantBlock& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsEqpConstantBlock* get_buffer (::CORBA::Boolean orphan=0);
    const rmsEqpConstantBlock* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpConstantBlock* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpConstantBlock* src, rmsEqpConstantBlock* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpConstantBlock* data); 
  public:

    static rmsEqpConstantBlock* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsEqpConstantBlock* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsEqpConstantBlock* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsEqpConstantBlockSequence_0> rmsEqpConstantBlockSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsEqpConstantBlockSequence_0* _IDL_SEQ_rmsEqpConstantBlockSequence_0_vPtr;
typedef const _IDL_SEQ_rmsEqpConstantBlockSequence_0* _IDL_SEQ_rmsEqpConstantBlockSequence_0_cvPtr;

class  _IDL_SEQ_rmsEqpConstantBlockSequence_0_var
{
    public:

    _IDL_SEQ_rmsEqpConstantBlockSequence_0_var ();

    _IDL_SEQ_rmsEqpConstantBlockSequence_0_var (_IDL_SEQ_rmsEqpConstantBlockSequence_0 *_p);

    _IDL_SEQ_rmsEqpConstantBlockSequence_0_var (const _IDL_SEQ_rmsEqpConstantBlockSequence_0_var &_s);

    _IDL_SEQ_rmsEqpConstantBlockSequence_0_var &operator= (_IDL_SEQ_rmsEqpConstantBlockSequence_0 *_p);

    _IDL_SEQ_rmsEqpConstantBlockSequence_0_var &operator= (const _IDL_SEQ_rmsEqpConstantBlockSequence_0_var &_s);

    ~_IDL_SEQ_rmsEqpConstantBlockSequence_0_var ();

    _IDL_SEQ_rmsEqpConstantBlockSequence_0* operator-> ();

    operator _IDL_SEQ_rmsEqpConstantBlockSequence_0_cvPtr () const;

    operator _IDL_SEQ_rmsEqpConstantBlockSequence_0_vPtr& ();

    operator _IDL_SEQ_rmsEqpConstantBlockSequence_0() const;

    const rmsEqpConstantBlock& operator[] (::CORBA::ULong index) const;
    rmsEqpConstantBlock& operator[] (::CORBA::ULong index);
    const rmsEqpConstantBlock& operator[] (int index) const;
    rmsEqpConstantBlock& operator[] (int index);
    const _IDL_SEQ_rmsEqpConstantBlockSequence_0& in() const;
    _IDL_SEQ_rmsEqpConstantBlockSequence_0& inout();
    _IDL_SEQ_rmsEqpConstantBlockSequence_0*& out();
    _IDL_SEQ_rmsEqpConstantBlockSequence_0* _retn();

    protected:
    _IDL_SEQ_rmsEqpConstantBlockSequence_0 *_ptr;
};

    typedef _IDL_SEQ_rmsEqpConstantBlockSequence_0 _rmsEqpConstantBlockSequence_seq;
    typedef _IDL_SEQ_rmsEqpConstantBlockSequence_0 _rmsEqpConstantBlockSequence_seq_1;
    typedef _IDL_SEQ_rmsEqpConstantBlockSequence_0 rmsEqpConstantBlockSequence;
    typedef _IDL_SEQ_rmsEqpConstantBlockSequence_0_var rmsEqpConstantBlockSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantBlockSequence;
    class  rmsEqpConstantBlockInqResult_struct_var;
    struct  rmsEqpConstantBlockInqResult_struct {
        typedef rmsEqpConstantBlockInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEqpConstantBlockSequence blocks;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpConstantBlockInqResult_struct();
       rmsEqpConstantBlockInqResult_struct(const rmsEqpConstantBlockInqResult_struct&);
       rmsEqpConstantBlockInqResult_struct& operator=(const rmsEqpConstantBlockInqResult_struct&);
       static CORBA::Info<rmsEqpConstantBlockInqResult_struct> rmsEqpConstantBlockInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpConstantBlockInqResult_struct


typedef rmsEqpConstantBlockInqResult_struct* rmsEqpConstantBlockInqResult_struct_vPtr;
typedef const rmsEqpConstantBlockInqResult_struct* rmsEqpConstantBlockInqResult_struct_cvPtr;

class  rmsEqpConstantBlockInqResult_struct_var
{
    public:

    rmsEqpConstantBlockInqResult_struct_var ();

    rmsEqpConstantBlockInqResult_struct_var (rmsEqpConstantBlockInqResult_struct *_p);

    rmsEqpConstantBlockInqResult_struct_var (const rmsEqpConstantBlockInqResult_struct_var &_s);

    rmsEqpConstantBlockInqResult_struct_var &operator= (rmsEqpConstantBlockInqResult_struct *_p);

    rmsEqpConstantBlockInqResult_struct_var &operator= (const rmsEqpConstantBlockInqResult_struct_var &_s);

    ~rmsEqpConstantBlockInqResult_struct_var ();

    rmsEqpConstantBlockInqResult_struct* operator-> ();

    const rmsEqpConstantBlockInqResult_struct& in() const;
    rmsEqpConstantBlockInqResult_struct& inout();
    rmsEqpConstantBlockInqResult_struct*& out();
    rmsEqpConstantBlockInqResult_struct* _retn();

    operator rmsEqpConstantBlockInqResult_struct_cvPtr () const;

    operator rmsEqpConstantBlockInqResult_struct_vPtr& ();

    operator const rmsEqpConstantBlockInqResult_struct& () const;

    operator rmsEqpConstantBlockInqResult_struct& ();

    protected:
    rmsEqpConstantBlockInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantBlockInqResult_struct;
    typedef rmsEqpConstantBlockInqResult_struct rmsEqpConstantBlockInqResult;
    typedef rmsEqpConstantBlockInqResult_struct_var rmsEqpConstantBlockInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpConstantBlockInqResult;
    class  rmsRcpBatch_struct_var;
    struct  rmsRcpBatch_struct {
        typedef rmsRcpBatch_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeId;
       ::CORBA::Long recipeLevel;
       ::CORBA::String_StructElem batchCreateTime;
       ::CORBA::String_StructElem compresult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpBatch_struct();
       rmsRcpBatch_struct(const rmsRcpBatch_struct&);
       rmsRcpBatch_struct& operator=(const rmsRcpBatch_struct&);
       static CORBA::Info<rmsRcpBatch_struct> rmsRcpBatch_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpBatch_struct


typedef rmsRcpBatch_struct* rmsRcpBatch_struct_vPtr;
typedef const rmsRcpBatch_struct* rmsRcpBatch_struct_cvPtr;

class  rmsRcpBatch_struct_var
{
    public:

    rmsRcpBatch_struct_var ();

    rmsRcpBatch_struct_var (rmsRcpBatch_struct *_p);

    rmsRcpBatch_struct_var (const rmsRcpBatch_struct_var &_s);

    rmsRcpBatch_struct_var &operator= (rmsRcpBatch_struct *_p);

    rmsRcpBatch_struct_var &operator= (const rmsRcpBatch_struct_var &_s);

    ~rmsRcpBatch_struct_var ();

    rmsRcpBatch_struct* operator-> ();

    const rmsRcpBatch_struct& in() const;
    rmsRcpBatch_struct& inout();
    rmsRcpBatch_struct*& out();
    rmsRcpBatch_struct* _retn();

    operator rmsRcpBatch_struct_cvPtr () const;

    operator rmsRcpBatch_struct_vPtr& ();

    operator const rmsRcpBatch_struct& () const;

    operator rmsRcpBatch_struct& ();

    protected:
    rmsRcpBatch_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatch_struct;
    typedef rmsRcpBatch_struct rmsRcpBatch;
    typedef rmsRcpBatch_struct_var rmsRcpBatch_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatch;
class  _IDL_SEQ_rmsRcpBatchSeq_0_var;
class  _IDL_SEQ_rmsRcpBatchSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpBatchSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpBatch *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpBatchSeq_0 ();
    _IDL_SEQ_rmsRcpBatchSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpBatchSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpBatch* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpBatchSeq_0 (const _IDL_SEQ_rmsRcpBatchSeq_0&);

    ~_IDL_SEQ_rmsRcpBatchSeq_0 ();

    _IDL_SEQ_rmsRcpBatchSeq_0& operator= (const _IDL_SEQ_rmsRcpBatchSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpBatch& operator [] (::CORBA::ULong indx);
    const rmsRcpBatch& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpBatch* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpBatch* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpBatch* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpBatch* src, rmsRcpBatch* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpBatch* data); 
  public:

    static rmsRcpBatch* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpBatch* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpBatch* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpBatchSeq_0> rmsRcpBatchSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpBatchSeq_0* _IDL_SEQ_rmsRcpBatchSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpBatchSeq_0* _IDL_SEQ_rmsRcpBatchSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpBatchSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpBatchSeq_0_var ();

    _IDL_SEQ_rmsRcpBatchSeq_0_var (_IDL_SEQ_rmsRcpBatchSeq_0 *_p);

    _IDL_SEQ_rmsRcpBatchSeq_0_var (const _IDL_SEQ_rmsRcpBatchSeq_0_var &_s);

    _IDL_SEQ_rmsRcpBatchSeq_0_var &operator= (_IDL_SEQ_rmsRcpBatchSeq_0 *_p);

    _IDL_SEQ_rmsRcpBatchSeq_0_var &operator= (const _IDL_SEQ_rmsRcpBatchSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpBatchSeq_0_var ();

    _IDL_SEQ_rmsRcpBatchSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpBatchSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpBatchSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpBatchSeq_0() const;

    const rmsRcpBatch& operator[] (::CORBA::ULong index) const;
    rmsRcpBatch& operator[] (::CORBA::ULong index);
    const rmsRcpBatch& operator[] (int index) const;
    rmsRcpBatch& operator[] (int index);
    const _IDL_SEQ_rmsRcpBatchSeq_0& in() const;
    _IDL_SEQ_rmsRcpBatchSeq_0& inout();
    _IDL_SEQ_rmsRcpBatchSeq_0*& out();
    _IDL_SEQ_rmsRcpBatchSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpBatchSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpBatchSeq_0 _rmsRcpBatchSeq_seq;
    typedef _IDL_SEQ_rmsRcpBatchSeq_0 _rmsRcpBatchSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpBatchSeq_0 rmsRcpBatchSeq;
    typedef _IDL_SEQ_rmsRcpBatchSeq_0_var rmsRcpBatchSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatchSeq;
    class  rmsRcpBatchInqResult_struct_var;
    struct  rmsRcpBatchInqResult_struct {
        typedef rmsRcpBatchInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpBatchSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpBatchInqResult_struct();
       rmsRcpBatchInqResult_struct(const rmsRcpBatchInqResult_struct&);
       rmsRcpBatchInqResult_struct& operator=(const rmsRcpBatchInqResult_struct&);
       static CORBA::Info<rmsRcpBatchInqResult_struct> rmsRcpBatchInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpBatchInqResult_struct


typedef rmsRcpBatchInqResult_struct* rmsRcpBatchInqResult_struct_vPtr;
typedef const rmsRcpBatchInqResult_struct* rmsRcpBatchInqResult_struct_cvPtr;

class  rmsRcpBatchInqResult_struct_var
{
    public:

    rmsRcpBatchInqResult_struct_var ();

    rmsRcpBatchInqResult_struct_var (rmsRcpBatchInqResult_struct *_p);

    rmsRcpBatchInqResult_struct_var (const rmsRcpBatchInqResult_struct_var &_s);

    rmsRcpBatchInqResult_struct_var &operator= (rmsRcpBatchInqResult_struct *_p);

    rmsRcpBatchInqResult_struct_var &operator= (const rmsRcpBatchInqResult_struct_var &_s);

    ~rmsRcpBatchInqResult_struct_var ();

    rmsRcpBatchInqResult_struct* operator-> ();

    const rmsRcpBatchInqResult_struct& in() const;
    rmsRcpBatchInqResult_struct& inout();
    rmsRcpBatchInqResult_struct*& out();
    rmsRcpBatchInqResult_struct* _retn();

    operator rmsRcpBatchInqResult_struct_cvPtr () const;

    operator rmsRcpBatchInqResult_struct_vPtr& ();

    operator const rmsRcpBatchInqResult_struct& () const;

    operator rmsRcpBatchInqResult_struct& ();

    protected:
    rmsRcpBatchInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatchInqResult_struct;
    typedef rmsRcpBatchInqResult_struct rmsRcpBatchInqResult;
    typedef rmsRcpBatchInqResult_struct_var rmsRcpBatchInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatchInqResult;
    class  rmsUserPrivilege_struct_var;
    struct  rmsUserPrivilege_struct {
        typedef rmsUserPrivilege_struct_var _var_type;
       ::CORBA::String_StructElem userId;
       ::CORBA::String_StructElem deptId;
       ::CORBA::String_StructElem privilege;
       ::CORBA::String_StructElem level;
       ::CORBA::String_StructElem targetEqp;
       ::CORBA::String_StructElem targetRcp;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsUserPrivilege_struct();
       rmsUserPrivilege_struct(const rmsUserPrivilege_struct&);
       rmsUserPrivilege_struct& operator=(const rmsUserPrivilege_struct&);
       static CORBA::Info<rmsUserPrivilege_struct> rmsUserPrivilege_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsUserPrivilege_struct


typedef rmsUserPrivilege_struct* rmsUserPrivilege_struct_vPtr;
typedef const rmsUserPrivilege_struct* rmsUserPrivilege_struct_cvPtr;

class  rmsUserPrivilege_struct_var
{
    public:

    rmsUserPrivilege_struct_var ();

    rmsUserPrivilege_struct_var (rmsUserPrivilege_struct *_p);

    rmsUserPrivilege_struct_var (const rmsUserPrivilege_struct_var &_s);

    rmsUserPrivilege_struct_var &operator= (rmsUserPrivilege_struct *_p);

    rmsUserPrivilege_struct_var &operator= (const rmsUserPrivilege_struct_var &_s);

    ~rmsUserPrivilege_struct_var ();

    rmsUserPrivilege_struct* operator-> ();

    const rmsUserPrivilege_struct& in() const;
    rmsUserPrivilege_struct& inout();
    rmsUserPrivilege_struct*& out();
    rmsUserPrivilege_struct* _retn();

    operator rmsUserPrivilege_struct_cvPtr () const;

    operator rmsUserPrivilege_struct_vPtr& ();

    operator const rmsUserPrivilege_struct& () const;

    operator rmsUserPrivilege_struct& ();

    protected:
    rmsUserPrivilege_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsUserPrivilege_struct;
    typedef rmsUserPrivilege_struct rmsUserPrivilege;
    typedef rmsUserPrivilege_struct_var rmsUserPrivilege_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsUserPrivilege;
class  _IDL_SEQ_rmsUserPrivilegeSeq_0_var;
class  _IDL_SEQ_rmsUserPrivilegeSeq_0 {
    public:
        typedef _IDL_SEQ_rmsUserPrivilegeSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsUserPrivilege *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsUserPrivilegeSeq_0 ();
    _IDL_SEQ_rmsUserPrivilegeSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsUserPrivilegeSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsUserPrivilege* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsUserPrivilegeSeq_0 (const _IDL_SEQ_rmsUserPrivilegeSeq_0&);

    ~_IDL_SEQ_rmsUserPrivilegeSeq_0 ();

    _IDL_SEQ_rmsUserPrivilegeSeq_0& operator= (const _IDL_SEQ_rmsUserPrivilegeSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsUserPrivilege& operator [] (::CORBA::ULong indx);
    const rmsUserPrivilege& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsUserPrivilege* get_buffer (::CORBA::Boolean orphan=0);
    const rmsUserPrivilege* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsUserPrivilege* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsUserPrivilege* src, rmsUserPrivilege* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsUserPrivilege* data); 
  public:

    static rmsUserPrivilege* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsUserPrivilege* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsUserPrivilege* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsUserPrivilegeSeq_0> rmsUserPrivilegeSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsUserPrivilegeSeq_0* _IDL_SEQ_rmsUserPrivilegeSeq_0_vPtr;
typedef const _IDL_SEQ_rmsUserPrivilegeSeq_0* _IDL_SEQ_rmsUserPrivilegeSeq_0_cvPtr;

class  _IDL_SEQ_rmsUserPrivilegeSeq_0_var
{
    public:

    _IDL_SEQ_rmsUserPrivilegeSeq_0_var ();

    _IDL_SEQ_rmsUserPrivilegeSeq_0_var (_IDL_SEQ_rmsUserPrivilegeSeq_0 *_p);

    _IDL_SEQ_rmsUserPrivilegeSeq_0_var (const _IDL_SEQ_rmsUserPrivilegeSeq_0_var &_s);

    _IDL_SEQ_rmsUserPrivilegeSeq_0_var &operator= (_IDL_SEQ_rmsUserPrivilegeSeq_0 *_p);

    _IDL_SEQ_rmsUserPrivilegeSeq_0_var &operator= (const _IDL_SEQ_rmsUserPrivilegeSeq_0_var &_s);

    ~_IDL_SEQ_rmsUserPrivilegeSeq_0_var ();

    _IDL_SEQ_rmsUserPrivilegeSeq_0* operator-> ();

    operator _IDL_SEQ_rmsUserPrivilegeSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsUserPrivilegeSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsUserPrivilegeSeq_0() const;

    const rmsUserPrivilege& operator[] (::CORBA::ULong index) const;
    rmsUserPrivilege& operator[] (::CORBA::ULong index);
    const rmsUserPrivilege& operator[] (int index) const;
    rmsUserPrivilege& operator[] (int index);
    const _IDL_SEQ_rmsUserPrivilegeSeq_0& in() const;
    _IDL_SEQ_rmsUserPrivilegeSeq_0& inout();
    _IDL_SEQ_rmsUserPrivilegeSeq_0*& out();
    _IDL_SEQ_rmsUserPrivilegeSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsUserPrivilegeSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsUserPrivilegeSeq_0 _rmsUserPrivilegeSeq_seq;
    typedef _IDL_SEQ_rmsUserPrivilegeSeq_0 _rmsUserPrivilegeSeq_seq_1;
    typedef _IDL_SEQ_rmsUserPrivilegeSeq_0 rmsUserPrivilegeSeq;
    typedef _IDL_SEQ_rmsUserPrivilegeSeq_0_var rmsUserPrivilegeSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsUserPrivilegeSeq;
    class  rmsUserPrivilegeInqResult_struct_var;
    struct  rmsUserPrivilegeInqResult_struct {
        typedef rmsUserPrivilegeInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsUserPrivilegeSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsUserPrivilegeInqResult_struct();
       rmsUserPrivilegeInqResult_struct(const rmsUserPrivilegeInqResult_struct&);
       rmsUserPrivilegeInqResult_struct& operator=(const rmsUserPrivilegeInqResult_struct&);
       static CORBA::Info<rmsUserPrivilegeInqResult_struct> rmsUserPrivilegeInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsUserPrivilegeInqResult_struct


typedef rmsUserPrivilegeInqResult_struct* rmsUserPrivilegeInqResult_struct_vPtr;
typedef const rmsUserPrivilegeInqResult_struct* rmsUserPrivilegeInqResult_struct_cvPtr;

class  rmsUserPrivilegeInqResult_struct_var
{
    public:

    rmsUserPrivilegeInqResult_struct_var ();

    rmsUserPrivilegeInqResult_struct_var (rmsUserPrivilegeInqResult_struct *_p);

    rmsUserPrivilegeInqResult_struct_var (const rmsUserPrivilegeInqResult_struct_var &_s);

    rmsUserPrivilegeInqResult_struct_var &operator= (rmsUserPrivilegeInqResult_struct *_p);

    rmsUserPrivilegeInqResult_struct_var &operator= (const rmsUserPrivilegeInqResult_struct_var &_s);

    ~rmsUserPrivilegeInqResult_struct_var ();

    rmsUserPrivilegeInqResult_struct* operator-> ();

    const rmsUserPrivilegeInqResult_struct& in() const;
    rmsUserPrivilegeInqResult_struct& inout();
    rmsUserPrivilegeInqResult_struct*& out();
    rmsUserPrivilegeInqResult_struct* _retn();

    operator rmsUserPrivilegeInqResult_struct_cvPtr () const;

    operator rmsUserPrivilegeInqResult_struct_vPtr& ();

    operator const rmsUserPrivilegeInqResult_struct& () const;

    operator rmsUserPrivilegeInqResult_struct& ();

    protected:
    rmsUserPrivilegeInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsUserPrivilegeInqResult_struct;
    typedef rmsUserPrivilegeInqResult_struct rmsUserPrivilegeInqResult;
    typedef rmsUserPrivilegeInqResult_struct_var rmsUserPrivilegeInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsUserPrivilegeInqResult;
    class  rmsPrivilege_struct_var;
    struct  rmsPrivilege_struct {
        typedef rmsPrivilege_struct_var _var_type;
       ::CORBA::String_StructElem privilege;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsPrivilege_struct();
       rmsPrivilege_struct(const rmsPrivilege_struct&);
       rmsPrivilege_struct& operator=(const rmsPrivilege_struct&);
       static CORBA::Info<rmsPrivilege_struct> rmsPrivilege_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsPrivilege_struct


typedef rmsPrivilege_struct* rmsPrivilege_struct_vPtr;
typedef const rmsPrivilege_struct* rmsPrivilege_struct_cvPtr;

class  rmsPrivilege_struct_var
{
    public:

    rmsPrivilege_struct_var ();

    rmsPrivilege_struct_var (rmsPrivilege_struct *_p);

    rmsPrivilege_struct_var (const rmsPrivilege_struct_var &_s);

    rmsPrivilege_struct_var &operator= (rmsPrivilege_struct *_p);

    rmsPrivilege_struct_var &operator= (const rmsPrivilege_struct_var &_s);

    ~rmsPrivilege_struct_var ();

    rmsPrivilege_struct* operator-> ();

    const rmsPrivilege_struct& in() const;
    rmsPrivilege_struct& inout();
    rmsPrivilege_struct*& out();
    rmsPrivilege_struct* _retn();

    operator rmsPrivilege_struct_cvPtr () const;

    operator rmsPrivilege_struct_vPtr& ();

    operator const rmsPrivilege_struct& () const;

    operator rmsPrivilege_struct& ();

    protected:
    rmsPrivilege_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilege_struct;
    typedef rmsPrivilege_struct rmsPrivilege;
    typedef rmsPrivilege_struct_var rmsPrivilege_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilege;
class  _IDL_SEQ_rmsPrivilegeSeq_0_var;
class  _IDL_SEQ_rmsPrivilegeSeq_0 {
    public:
        typedef _IDL_SEQ_rmsPrivilegeSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsPrivilege *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsPrivilegeSeq_0 ();
    _IDL_SEQ_rmsPrivilegeSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsPrivilegeSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsPrivilege* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsPrivilegeSeq_0 (const _IDL_SEQ_rmsPrivilegeSeq_0&);

    ~_IDL_SEQ_rmsPrivilegeSeq_0 ();

    _IDL_SEQ_rmsPrivilegeSeq_0& operator= (const _IDL_SEQ_rmsPrivilegeSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsPrivilege& operator [] (::CORBA::ULong indx);
    const rmsPrivilege& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsPrivilege* get_buffer (::CORBA::Boolean orphan=0);
    const rmsPrivilege* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsPrivilege* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsPrivilege* src, rmsPrivilege* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsPrivilege* data); 
  public:

    static rmsPrivilege* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsPrivilege* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsPrivilege* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsPrivilegeSeq_0> rmsPrivilegeSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsPrivilegeSeq_0* _IDL_SEQ_rmsPrivilegeSeq_0_vPtr;
typedef const _IDL_SEQ_rmsPrivilegeSeq_0* _IDL_SEQ_rmsPrivilegeSeq_0_cvPtr;

class  _IDL_SEQ_rmsPrivilegeSeq_0_var
{
    public:

    _IDL_SEQ_rmsPrivilegeSeq_0_var ();

    _IDL_SEQ_rmsPrivilegeSeq_0_var (_IDL_SEQ_rmsPrivilegeSeq_0 *_p);

    _IDL_SEQ_rmsPrivilegeSeq_0_var (const _IDL_SEQ_rmsPrivilegeSeq_0_var &_s);

    _IDL_SEQ_rmsPrivilegeSeq_0_var &operator= (_IDL_SEQ_rmsPrivilegeSeq_0 *_p);

    _IDL_SEQ_rmsPrivilegeSeq_0_var &operator= (const _IDL_SEQ_rmsPrivilegeSeq_0_var &_s);

    ~_IDL_SEQ_rmsPrivilegeSeq_0_var ();

    _IDL_SEQ_rmsPrivilegeSeq_0* operator-> ();

    operator _IDL_SEQ_rmsPrivilegeSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsPrivilegeSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsPrivilegeSeq_0() const;

    const rmsPrivilege& operator[] (::CORBA::ULong index) const;
    rmsPrivilege& operator[] (::CORBA::ULong index);
    const rmsPrivilege& operator[] (int index) const;
    rmsPrivilege& operator[] (int index);
    const _IDL_SEQ_rmsPrivilegeSeq_0& in() const;
    _IDL_SEQ_rmsPrivilegeSeq_0& inout();
    _IDL_SEQ_rmsPrivilegeSeq_0*& out();
    _IDL_SEQ_rmsPrivilegeSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsPrivilegeSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsPrivilegeSeq_0 _rmsPrivilegeSeq_seq;
    typedef _IDL_SEQ_rmsPrivilegeSeq_0 _rmsPrivilegeSeq_seq_1;
    typedef _IDL_SEQ_rmsPrivilegeSeq_0 rmsPrivilegeSeq;
    typedef _IDL_SEQ_rmsPrivilegeSeq_0_var rmsPrivilegeSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilegeSeq;
    class  rmsPrivilegeInqResult_struct_var;
    struct  rmsPrivilegeInqResult_struct {
        typedef rmsPrivilegeInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsPrivilegeSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsPrivilegeInqResult_struct();
       rmsPrivilegeInqResult_struct(const rmsPrivilegeInqResult_struct&);
       rmsPrivilegeInqResult_struct& operator=(const rmsPrivilegeInqResult_struct&);
       static CORBA::Info<rmsPrivilegeInqResult_struct> rmsPrivilegeInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsPrivilegeInqResult_struct


typedef rmsPrivilegeInqResult_struct* rmsPrivilegeInqResult_struct_vPtr;
typedef const rmsPrivilegeInqResult_struct* rmsPrivilegeInqResult_struct_cvPtr;

class  rmsPrivilegeInqResult_struct_var
{
    public:

    rmsPrivilegeInqResult_struct_var ();

    rmsPrivilegeInqResult_struct_var (rmsPrivilegeInqResult_struct *_p);

    rmsPrivilegeInqResult_struct_var (const rmsPrivilegeInqResult_struct_var &_s);

    rmsPrivilegeInqResult_struct_var &operator= (rmsPrivilegeInqResult_struct *_p);

    rmsPrivilegeInqResult_struct_var &operator= (const rmsPrivilegeInqResult_struct_var &_s);

    ~rmsPrivilegeInqResult_struct_var ();

    rmsPrivilegeInqResult_struct* operator-> ();

    const rmsPrivilegeInqResult_struct& in() const;
    rmsPrivilegeInqResult_struct& inout();
    rmsPrivilegeInqResult_struct*& out();
    rmsPrivilegeInqResult_struct* _retn();

    operator rmsPrivilegeInqResult_struct_cvPtr () const;

    operator rmsPrivilegeInqResult_struct_vPtr& ();

    operator const rmsPrivilegeInqResult_struct& () const;

    operator rmsPrivilegeInqResult_struct& ();

    protected:
    rmsPrivilegeInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilegeInqResult_struct;
    typedef rmsPrivilegeInqResult_struct rmsPrivilegeInqResult;
    typedef rmsPrivilegeInqResult_struct_var rmsPrivilegeInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilegeInqResult;
    class  rmsPrivilegeLevel_struct_var;
    struct  rmsPrivilegeLevel_struct {
        typedef rmsPrivilegeLevel_struct_var _var_type;
       ::CORBA::Long level;
       ::CORBA::String_StructElem description;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsPrivilegeLevel_struct();
       rmsPrivilegeLevel_struct(const rmsPrivilegeLevel_struct&);
       rmsPrivilegeLevel_struct& operator=(const rmsPrivilegeLevel_struct&);
       static CORBA::Info<rmsPrivilegeLevel_struct> rmsPrivilegeLevel_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsPrivilegeLevel_struct


typedef rmsPrivilegeLevel_struct* rmsPrivilegeLevel_struct_vPtr;
typedef const rmsPrivilegeLevel_struct* rmsPrivilegeLevel_struct_cvPtr;

class  rmsPrivilegeLevel_struct_var
{
    public:

    rmsPrivilegeLevel_struct_var ();

    rmsPrivilegeLevel_struct_var (rmsPrivilegeLevel_struct *_p);

    rmsPrivilegeLevel_struct_var (const rmsPrivilegeLevel_struct_var &_s);

    rmsPrivilegeLevel_struct_var &operator= (rmsPrivilegeLevel_struct *_p);

    rmsPrivilegeLevel_struct_var &operator= (const rmsPrivilegeLevel_struct_var &_s);

    ~rmsPrivilegeLevel_struct_var ();

    rmsPrivilegeLevel_struct* operator-> ();

    const rmsPrivilegeLevel_struct& in() const;
    rmsPrivilegeLevel_struct& inout();
    rmsPrivilegeLevel_struct*& out();
    rmsPrivilegeLevel_struct* _retn();

    operator rmsPrivilegeLevel_struct_cvPtr () const;

    operator rmsPrivilegeLevel_struct_vPtr& ();

    operator const rmsPrivilegeLevel_struct& () const;

    operator rmsPrivilegeLevel_struct& ();

    protected:
    rmsPrivilegeLevel_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilegeLevel_struct;
    typedef rmsPrivilegeLevel_struct rmsPrivilegeLevel;
    typedef rmsPrivilegeLevel_struct_var rmsPrivilegeLevel_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilegeLevel;
class  _IDL_SEQ_rmsPrivilegeLevelSeq_0_var;
class  _IDL_SEQ_rmsPrivilegeLevelSeq_0 {
    public:
        typedef _IDL_SEQ_rmsPrivilegeLevelSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsPrivilegeLevel *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsPrivilegeLevelSeq_0 ();
    _IDL_SEQ_rmsPrivilegeLevelSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsPrivilegeLevelSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsPrivilegeLevel* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsPrivilegeLevelSeq_0 (const _IDL_SEQ_rmsPrivilegeLevelSeq_0&);

    ~_IDL_SEQ_rmsPrivilegeLevelSeq_0 ();

    _IDL_SEQ_rmsPrivilegeLevelSeq_0& operator= (const _IDL_SEQ_rmsPrivilegeLevelSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsPrivilegeLevel& operator [] (::CORBA::ULong indx);
    const rmsPrivilegeLevel& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsPrivilegeLevel* get_buffer (::CORBA::Boolean orphan=0);
    const rmsPrivilegeLevel* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsPrivilegeLevel* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsPrivilegeLevel* src, rmsPrivilegeLevel* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsPrivilegeLevel* data); 
  public:

    static rmsPrivilegeLevel* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsPrivilegeLevel* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsPrivilegeLevel* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsPrivilegeLevelSeq_0> rmsPrivilegeLevelSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsPrivilegeLevelSeq_0* _IDL_SEQ_rmsPrivilegeLevelSeq_0_vPtr;
typedef const _IDL_SEQ_rmsPrivilegeLevelSeq_0* _IDL_SEQ_rmsPrivilegeLevelSeq_0_cvPtr;

class  _IDL_SEQ_rmsPrivilegeLevelSeq_0_var
{
    public:

    _IDL_SEQ_rmsPrivilegeLevelSeq_0_var ();

    _IDL_SEQ_rmsPrivilegeLevelSeq_0_var (_IDL_SEQ_rmsPrivilegeLevelSeq_0 *_p);

    _IDL_SEQ_rmsPrivilegeLevelSeq_0_var (const _IDL_SEQ_rmsPrivilegeLevelSeq_0_var &_s);

    _IDL_SEQ_rmsPrivilegeLevelSeq_0_var &operator= (_IDL_SEQ_rmsPrivilegeLevelSeq_0 *_p);

    _IDL_SEQ_rmsPrivilegeLevelSeq_0_var &operator= (const _IDL_SEQ_rmsPrivilegeLevelSeq_0_var &_s);

    ~_IDL_SEQ_rmsPrivilegeLevelSeq_0_var ();

    _IDL_SEQ_rmsPrivilegeLevelSeq_0* operator-> ();

    operator _IDL_SEQ_rmsPrivilegeLevelSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsPrivilegeLevelSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsPrivilegeLevelSeq_0() const;

    const rmsPrivilegeLevel& operator[] (::CORBA::ULong index) const;
    rmsPrivilegeLevel& operator[] (::CORBA::ULong index);
    const rmsPrivilegeLevel& operator[] (int index) const;
    rmsPrivilegeLevel& operator[] (int index);
    const _IDL_SEQ_rmsPrivilegeLevelSeq_0& in() const;
    _IDL_SEQ_rmsPrivilegeLevelSeq_0& inout();
    _IDL_SEQ_rmsPrivilegeLevelSeq_0*& out();
    _IDL_SEQ_rmsPrivilegeLevelSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsPrivilegeLevelSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsPrivilegeLevelSeq_0 _rmsPrivilegeLevelSeq_seq;
    typedef _IDL_SEQ_rmsPrivilegeLevelSeq_0 _rmsPrivilegeLevelSeq_seq_1;
    typedef _IDL_SEQ_rmsPrivilegeLevelSeq_0 rmsPrivilegeLevelSeq;
    typedef _IDL_SEQ_rmsPrivilegeLevelSeq_0_var rmsPrivilegeLevelSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilegeLevelSeq;
    class  rmsPrivilegeLevelInqResult_struct_var;
    struct  rmsPrivilegeLevelInqResult_struct {
        typedef rmsPrivilegeLevelInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsPrivilegeLevelSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsPrivilegeLevelInqResult_struct();
       rmsPrivilegeLevelInqResult_struct(const rmsPrivilegeLevelInqResult_struct&);
       rmsPrivilegeLevelInqResult_struct& operator=(const rmsPrivilegeLevelInqResult_struct&);
       static CORBA::Info<rmsPrivilegeLevelInqResult_struct> rmsPrivilegeLevelInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsPrivilegeLevelInqResult_struct


typedef rmsPrivilegeLevelInqResult_struct* rmsPrivilegeLevelInqResult_struct_vPtr;
typedef const rmsPrivilegeLevelInqResult_struct* rmsPrivilegeLevelInqResult_struct_cvPtr;

class  rmsPrivilegeLevelInqResult_struct_var
{
    public:

    rmsPrivilegeLevelInqResult_struct_var ();

    rmsPrivilegeLevelInqResult_struct_var (rmsPrivilegeLevelInqResult_struct *_p);

    rmsPrivilegeLevelInqResult_struct_var (const rmsPrivilegeLevelInqResult_struct_var &_s);

    rmsPrivilegeLevelInqResult_struct_var &operator= (rmsPrivilegeLevelInqResult_struct *_p);

    rmsPrivilegeLevelInqResult_struct_var &operator= (const rmsPrivilegeLevelInqResult_struct_var &_s);

    ~rmsPrivilegeLevelInqResult_struct_var ();

    rmsPrivilegeLevelInqResult_struct* operator-> ();

    const rmsPrivilegeLevelInqResult_struct& in() const;
    rmsPrivilegeLevelInqResult_struct& inout();
    rmsPrivilegeLevelInqResult_struct*& out();
    rmsPrivilegeLevelInqResult_struct* _retn();

    operator rmsPrivilegeLevelInqResult_struct_cvPtr () const;

    operator rmsPrivilegeLevelInqResult_struct_vPtr& ();

    operator const rmsPrivilegeLevelInqResult_struct& () const;

    operator rmsPrivilegeLevelInqResult_struct& ();

    protected:
    rmsPrivilegeLevelInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilegeLevelInqResult_struct;
    typedef rmsPrivilegeLevelInqResult_struct rmsPrivilegeLevelInqResult;
    typedef rmsPrivilegeLevelInqResult_struct_var rmsPrivilegeLevelInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsPrivilegeLevelInqResult;
    class  rmsEqpStatusChangeFlag_struct_var;
    struct  rmsEqpStatusChangeFlag_struct {
        typedef rmsEqpStatusChangeFlag_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem statuschange;
       ::CORBA::String_StructElem claimuser;
       ::CORBA::String_StructElem createtime;
       ::CORBA::String_StructElem updatetime;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpStatusChangeFlag_struct();
       rmsEqpStatusChangeFlag_struct(const rmsEqpStatusChangeFlag_struct&);
       rmsEqpStatusChangeFlag_struct& operator=(const rmsEqpStatusChangeFlag_struct&);
       static CORBA::Info<rmsEqpStatusChangeFlag_struct> rmsEqpStatusChangeFlag_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsEqpStatusChangeFlag_struct


typedef rmsEqpStatusChangeFlag_struct* rmsEqpStatusChangeFlag_struct_vPtr;
typedef const rmsEqpStatusChangeFlag_struct* rmsEqpStatusChangeFlag_struct_cvPtr;

class  rmsEqpStatusChangeFlag_struct_var
{
    public:

    rmsEqpStatusChangeFlag_struct_var ();

    rmsEqpStatusChangeFlag_struct_var (rmsEqpStatusChangeFlag_struct *_p);

    rmsEqpStatusChangeFlag_struct_var (const rmsEqpStatusChangeFlag_struct_var &_s);

    rmsEqpStatusChangeFlag_struct_var &operator= (rmsEqpStatusChangeFlag_struct *_p);

    rmsEqpStatusChangeFlag_struct_var &operator= (const rmsEqpStatusChangeFlag_struct_var &_s);

    ~rmsEqpStatusChangeFlag_struct_var ();

    rmsEqpStatusChangeFlag_struct* operator-> ();

    const rmsEqpStatusChangeFlag_struct& in() const;
    rmsEqpStatusChangeFlag_struct& inout();
    rmsEqpStatusChangeFlag_struct*& out();
    rmsEqpStatusChangeFlag_struct* _retn();

    operator rmsEqpStatusChangeFlag_struct_cvPtr () const;

    operator rmsEqpStatusChangeFlag_struct_vPtr& ();

    operator const rmsEqpStatusChangeFlag_struct& () const;

    operator rmsEqpStatusChangeFlag_struct& ();

    protected:
    rmsEqpStatusChangeFlag_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpStatusChangeFlag_struct;
    typedef rmsEqpStatusChangeFlag_struct rmsEqpStatusChg;
    typedef rmsEqpStatusChangeFlag_struct_var rmsEqpStatusChg_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpStatusChg;
class  _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var;
class  _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 {
    public:
        typedef _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsEqpStatusChg *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 ();
    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpStatusChg* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 (const _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0&);

    ~_IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 ();

    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0& operator= (const _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsEqpStatusChg& operator [] (::CORBA::ULong indx);
    const rmsEqpStatusChg& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsEqpStatusChg* get_buffer (::CORBA::Boolean orphan=0);
    const rmsEqpStatusChg* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpStatusChg* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpStatusChg* src, rmsEqpStatusChg* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpStatusChg* data); 
  public:

    static rmsEqpStatusChg* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsEqpStatusChg* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsEqpStatusChg* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsEqpStatusChangeFlagSeq_0> rmsEqpStatusChangeFlagSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0* _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_vPtr;
typedef const _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0* _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_cvPtr;

class  _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var
{
    public:

    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var ();

    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var (_IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 *_p);

    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var (const _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var &_s);

    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var &operator= (_IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 *_p);

    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var &operator= (const _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var &_s);

    ~_IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var ();

    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0* operator-> ();

    operator _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0() const;

    const rmsEqpStatusChg& operator[] (::CORBA::ULong index) const;
    rmsEqpStatusChg& operator[] (::CORBA::ULong index);
    const rmsEqpStatusChg& operator[] (int index) const;
    rmsEqpStatusChg& operator[] (int index);
    const _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0& in() const;
    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0& inout();
    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0*& out();
    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 _rmsEqpStatusChangeFlagSeq_seq;
    typedef _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 _rmsEqpStatusChangeFlagSeq_seq_1;
    typedef _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0 rmsEqpStatusChangeFlagSeq;
    typedef _IDL_SEQ_rmsEqpStatusChangeFlagSeq_0_var rmsEqpStatusChangeFlagSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpStatusChangeFlagSeq;
    class  rmsEqpStatusChangeFlagResult_struct_var;
    struct  rmsEqpStatusChangeFlagResult_struct {
        typedef rmsEqpStatusChangeFlagResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEqpStatusChangeFlagSeq profiles;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpStatusChangeFlagResult_struct();
       rmsEqpStatusChangeFlagResult_struct(const rmsEqpStatusChangeFlagResult_struct&);
       rmsEqpStatusChangeFlagResult_struct& operator=(const rmsEqpStatusChangeFlagResult_struct&);
       static CORBA::Info<rmsEqpStatusChangeFlagResult_struct> rmsEqpStatusChangeFlagResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpStatusChangeFlagResult_struct


typedef rmsEqpStatusChangeFlagResult_struct* rmsEqpStatusChangeFlagResult_struct_vPtr;
typedef const rmsEqpStatusChangeFlagResult_struct* rmsEqpStatusChangeFlagResult_struct_cvPtr;

class  rmsEqpStatusChangeFlagResult_struct_var
{
    public:

    rmsEqpStatusChangeFlagResult_struct_var ();

    rmsEqpStatusChangeFlagResult_struct_var (rmsEqpStatusChangeFlagResult_struct *_p);

    rmsEqpStatusChangeFlagResult_struct_var (const rmsEqpStatusChangeFlagResult_struct_var &_s);

    rmsEqpStatusChangeFlagResult_struct_var &operator= (rmsEqpStatusChangeFlagResult_struct *_p);

    rmsEqpStatusChangeFlagResult_struct_var &operator= (const rmsEqpStatusChangeFlagResult_struct_var &_s);

    ~rmsEqpStatusChangeFlagResult_struct_var ();

    rmsEqpStatusChangeFlagResult_struct* operator-> ();

    const rmsEqpStatusChangeFlagResult_struct& in() const;
    rmsEqpStatusChangeFlagResult_struct& inout();
    rmsEqpStatusChangeFlagResult_struct*& out();
    rmsEqpStatusChangeFlagResult_struct* _retn();

    operator rmsEqpStatusChangeFlagResult_struct_cvPtr () const;

    operator rmsEqpStatusChangeFlagResult_struct_vPtr& ();

    operator const rmsEqpStatusChangeFlagResult_struct& () const;

    operator rmsEqpStatusChangeFlagResult_struct& ();

    protected:
    rmsEqpStatusChangeFlagResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpStatusChangeFlagResult_struct;
    typedef rmsEqpStatusChangeFlagResult_struct rmsEqpStatusChangeFlagResult;
    typedef rmsEqpStatusChangeFlagResult_struct_var rmsEqpStatusChangeFlagResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpStatusChangeFlagResult;
    class  rmsEDMJob_struct_var;
    struct  rmsEDMJob_struct {
        typedef rmsEDMJob_struct_var _var_type;
       ::CORBA::Long jobIndex;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeID;
       ::CORBA::String_StructElem actionCode;
       ::CORBA::String_StructElem jobStatus;
       ::CORBA::Long retryCount;
       ::CORBA::String_StructElem jobExecDT;
       ::CORBA::String_StructElem rmsStartDT;
       ::CORBA::String_StructElem rmsEndDT;
       ::CORBA::String_StructElem result;
       ::CORBA::String_StructElem resultDesc;
       ::CORBA::String_StructElem edmExecDT;
       ::CORBA::String_StructElem edmExecResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEDMJob_struct();
       rmsEDMJob_struct(const rmsEDMJob_struct&);
       rmsEDMJob_struct& operator=(const rmsEDMJob_struct&);
       static CORBA::Info<rmsEDMJob_struct> rmsEDMJob_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsEDMJob_struct


typedef rmsEDMJob_struct* rmsEDMJob_struct_vPtr;
typedef const rmsEDMJob_struct* rmsEDMJob_struct_cvPtr;

class  rmsEDMJob_struct_var
{
    public:

    rmsEDMJob_struct_var ();

    rmsEDMJob_struct_var (rmsEDMJob_struct *_p);

    rmsEDMJob_struct_var (const rmsEDMJob_struct_var &_s);

    rmsEDMJob_struct_var &operator= (rmsEDMJob_struct *_p);

    rmsEDMJob_struct_var &operator= (const rmsEDMJob_struct_var &_s);

    ~rmsEDMJob_struct_var ();

    rmsEDMJob_struct* operator-> ();

    const rmsEDMJob_struct& in() const;
    rmsEDMJob_struct& inout();
    rmsEDMJob_struct*& out();
    rmsEDMJob_struct* _retn();

    operator rmsEDMJob_struct_cvPtr () const;

    operator rmsEDMJob_struct_vPtr& ();

    operator const rmsEDMJob_struct& () const;

    operator rmsEDMJob_struct& ();

    protected:
    rmsEDMJob_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEDMJob_struct;
    typedef rmsEDMJob_struct rmsEDMJob;
    typedef rmsEDMJob_struct_var rmsEDMJob_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEDMJob;
class  _IDL_SEQ_rmsEDMJobSeq_0_var;
class  _IDL_SEQ_rmsEDMJobSeq_0 {
    public:
        typedef _IDL_SEQ_rmsEDMJobSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsEDMJob *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsEDMJobSeq_0 ();
    _IDL_SEQ_rmsEDMJobSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsEDMJobSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsEDMJob* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsEDMJobSeq_0 (const _IDL_SEQ_rmsEDMJobSeq_0&);

    ~_IDL_SEQ_rmsEDMJobSeq_0 ();

    _IDL_SEQ_rmsEDMJobSeq_0& operator= (const _IDL_SEQ_rmsEDMJobSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsEDMJob& operator [] (::CORBA::ULong indx);
    const rmsEDMJob& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsEDMJob* get_buffer (::CORBA::Boolean orphan=0);
    const rmsEDMJob* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsEDMJob* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEDMJob* src, rmsEDMJob* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEDMJob* data); 
  public:

    static rmsEDMJob* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsEDMJob* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsEDMJob* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsEDMJobSeq_0> rmsEDMJobSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsEDMJobSeq_0* _IDL_SEQ_rmsEDMJobSeq_0_vPtr;
typedef const _IDL_SEQ_rmsEDMJobSeq_0* _IDL_SEQ_rmsEDMJobSeq_0_cvPtr;

class  _IDL_SEQ_rmsEDMJobSeq_0_var
{
    public:

    _IDL_SEQ_rmsEDMJobSeq_0_var ();

    _IDL_SEQ_rmsEDMJobSeq_0_var (_IDL_SEQ_rmsEDMJobSeq_0 *_p);

    _IDL_SEQ_rmsEDMJobSeq_0_var (const _IDL_SEQ_rmsEDMJobSeq_0_var &_s);

    _IDL_SEQ_rmsEDMJobSeq_0_var &operator= (_IDL_SEQ_rmsEDMJobSeq_0 *_p);

    _IDL_SEQ_rmsEDMJobSeq_0_var &operator= (const _IDL_SEQ_rmsEDMJobSeq_0_var &_s);

    ~_IDL_SEQ_rmsEDMJobSeq_0_var ();

    _IDL_SEQ_rmsEDMJobSeq_0* operator-> ();

    operator _IDL_SEQ_rmsEDMJobSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsEDMJobSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsEDMJobSeq_0() const;

    const rmsEDMJob& operator[] (::CORBA::ULong index) const;
    rmsEDMJob& operator[] (::CORBA::ULong index);
    const rmsEDMJob& operator[] (int index) const;
    rmsEDMJob& operator[] (int index);
    const _IDL_SEQ_rmsEDMJobSeq_0& in() const;
    _IDL_SEQ_rmsEDMJobSeq_0& inout();
    _IDL_SEQ_rmsEDMJobSeq_0*& out();
    _IDL_SEQ_rmsEDMJobSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsEDMJobSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsEDMJobSeq_0 _rmsEDMJobSeq_seq;
    typedef _IDL_SEQ_rmsEDMJobSeq_0 _rmsEDMJobSeq_seq_1;
    typedef _IDL_SEQ_rmsEDMJobSeq_0 rmsEDMJobSeq;
    typedef _IDL_SEQ_rmsEDMJobSeq_0_var rmsEDMJobSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEDMJobSeq;
    class  rmsEDMJobInqResult_struct_var;
    struct  rmsEDMJobInqResult_struct {
        typedef rmsEDMJobInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEDMJobSeq jobs;
       ::CORBA::Boolean overSearchCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEDMJobInqResult_struct();
       rmsEDMJobInqResult_struct(const rmsEDMJobInqResult_struct&);
       rmsEDMJobInqResult_struct& operator=(const rmsEDMJobInqResult_struct&);
       static CORBA::Info<rmsEDMJobInqResult_struct> rmsEDMJobInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEDMJobInqResult_struct


typedef rmsEDMJobInqResult_struct* rmsEDMJobInqResult_struct_vPtr;
typedef const rmsEDMJobInqResult_struct* rmsEDMJobInqResult_struct_cvPtr;

class  rmsEDMJobInqResult_struct_var
{
    public:

    rmsEDMJobInqResult_struct_var ();

    rmsEDMJobInqResult_struct_var (rmsEDMJobInqResult_struct *_p);

    rmsEDMJobInqResult_struct_var (const rmsEDMJobInqResult_struct_var &_s);

    rmsEDMJobInqResult_struct_var &operator= (rmsEDMJobInqResult_struct *_p);

    rmsEDMJobInqResult_struct_var &operator= (const rmsEDMJobInqResult_struct_var &_s);

    ~rmsEDMJobInqResult_struct_var ();

    rmsEDMJobInqResult_struct* operator-> ();

    const rmsEDMJobInqResult_struct& in() const;
    rmsEDMJobInqResult_struct& inout();
    rmsEDMJobInqResult_struct*& out();
    rmsEDMJobInqResult_struct* _retn();

    operator rmsEDMJobInqResult_struct_cvPtr () const;

    operator rmsEDMJobInqResult_struct_vPtr& ();

    operator const rmsEDMJobInqResult_struct& () const;

    operator rmsEDMJobInqResult_struct& ();

    protected:
    rmsEDMJobInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEDMJobInqResult_struct;
    typedef rmsEDMJobInqResult_struct rmsEDMJobInqResult;
    typedef rmsEDMJobInqResult_struct_var rmsEDMJobInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEDMJobInqResult;
    class  rmsForceAuditHistory_struct_var;
    struct  rmsForceAuditHistory_struct {
        typedef rmsForceAuditHistory_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqpID;
       ::CORBA::String_StructElem actioncode;
       ::CORBA::String_StructElem recipeid;
       ::CORBA::String_StructElem compresult;
       ::CORBA::String_StructElem claimmemo;
       ::CORBA::String_StructElem claimtime;
       ::CORBA::String_StructElem claimuserid;
       ::CORBA::String_StructElem confirmuserid;
       ::CORBA::String_StructElem message;
       ::CORBA::Long recipelevel;
       ::CORBA::String_StructElem chamberid;
       ::CORBA::String_StructElem subrecipeid;
       ::CORBA::String_StructElem reasoncode;
       ::CORBA::String_StructElem reasondesc;
       ::CORBA::String_StructElem lotid;
       ::CORBA::String_StructElem lottype;
       ::CORBA::String_StructElem lotownerdept;
       ::CORBA::Boolean serflag;
       ::CORBA::String_StructElem auditrule;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsForceAuditHistory_struct();
       rmsForceAuditHistory_struct(const rmsForceAuditHistory_struct&);
       rmsForceAuditHistory_struct& operator=(const rmsForceAuditHistory_struct&);
       static CORBA::Info<rmsForceAuditHistory_struct> rmsForceAuditHistory_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsForceAuditHistory_struct


typedef rmsForceAuditHistory_struct* rmsForceAuditHistory_struct_vPtr;
typedef const rmsForceAuditHistory_struct* rmsForceAuditHistory_struct_cvPtr;

class  rmsForceAuditHistory_struct_var
{
    public:

    rmsForceAuditHistory_struct_var ();

    rmsForceAuditHistory_struct_var (rmsForceAuditHistory_struct *_p);

    rmsForceAuditHistory_struct_var (const rmsForceAuditHistory_struct_var &_s);

    rmsForceAuditHistory_struct_var &operator= (rmsForceAuditHistory_struct *_p);

    rmsForceAuditHistory_struct_var &operator= (const rmsForceAuditHistory_struct_var &_s);

    ~rmsForceAuditHistory_struct_var ();

    rmsForceAuditHistory_struct* operator-> ();

    const rmsForceAuditHistory_struct& in() const;
    rmsForceAuditHistory_struct& inout();
    rmsForceAuditHistory_struct*& out();
    rmsForceAuditHistory_struct* _retn();

    operator rmsForceAuditHistory_struct_cvPtr () const;

    operator rmsForceAuditHistory_struct_vPtr& ();

    operator const rmsForceAuditHistory_struct& () const;

    operator rmsForceAuditHistory_struct& ();

    protected:
    rmsForceAuditHistory_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsForceAuditHistory_struct;
    typedef rmsForceAuditHistory_struct rmsForceAuditHistory;
    typedef rmsForceAuditHistory_struct_var rmsForceAuditHistory_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsForceAuditHistory;
class  _IDL_SEQ_rmsForceAuditHistorySeq_0_var;
class  _IDL_SEQ_rmsForceAuditHistorySeq_0 {
    public:
        typedef _IDL_SEQ_rmsForceAuditHistorySeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsForceAuditHistory *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsForceAuditHistorySeq_0 ();
    _IDL_SEQ_rmsForceAuditHistorySeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsForceAuditHistorySeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsForceAuditHistory* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsForceAuditHistorySeq_0 (const _IDL_SEQ_rmsForceAuditHistorySeq_0&);

    ~_IDL_SEQ_rmsForceAuditHistorySeq_0 ();

    _IDL_SEQ_rmsForceAuditHistorySeq_0& operator= (const _IDL_SEQ_rmsForceAuditHistorySeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsForceAuditHistory& operator [] (::CORBA::ULong indx);
    const rmsForceAuditHistory& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsForceAuditHistory* get_buffer (::CORBA::Boolean orphan=0);
    const rmsForceAuditHistory* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsForceAuditHistory* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsForceAuditHistory* src, rmsForceAuditHistory* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsForceAuditHistory* data); 
  public:

    static rmsForceAuditHistory* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsForceAuditHistory* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsForceAuditHistory* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsForceAuditHistorySeq_0> rmsForceAuditHistorySeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsForceAuditHistorySeq_0* _IDL_SEQ_rmsForceAuditHistorySeq_0_vPtr;
typedef const _IDL_SEQ_rmsForceAuditHistorySeq_0* _IDL_SEQ_rmsForceAuditHistorySeq_0_cvPtr;

class  _IDL_SEQ_rmsForceAuditHistorySeq_0_var
{
    public:

    _IDL_SEQ_rmsForceAuditHistorySeq_0_var ();

    _IDL_SEQ_rmsForceAuditHistorySeq_0_var (_IDL_SEQ_rmsForceAuditHistorySeq_0 *_p);

    _IDL_SEQ_rmsForceAuditHistorySeq_0_var (const _IDL_SEQ_rmsForceAuditHistorySeq_0_var &_s);

    _IDL_SEQ_rmsForceAuditHistorySeq_0_var &operator= (_IDL_SEQ_rmsForceAuditHistorySeq_0 *_p);

    _IDL_SEQ_rmsForceAuditHistorySeq_0_var &operator= (const _IDL_SEQ_rmsForceAuditHistorySeq_0_var &_s);

    ~_IDL_SEQ_rmsForceAuditHistorySeq_0_var ();

    _IDL_SEQ_rmsForceAuditHistorySeq_0* operator-> ();

    operator _IDL_SEQ_rmsForceAuditHistorySeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsForceAuditHistorySeq_0_vPtr& ();

    operator _IDL_SEQ_rmsForceAuditHistorySeq_0() const;

    const rmsForceAuditHistory& operator[] (::CORBA::ULong index) const;
    rmsForceAuditHistory& operator[] (::CORBA::ULong index);
    const rmsForceAuditHistory& operator[] (int index) const;
    rmsForceAuditHistory& operator[] (int index);
    const _IDL_SEQ_rmsForceAuditHistorySeq_0& in() const;
    _IDL_SEQ_rmsForceAuditHistorySeq_0& inout();
    _IDL_SEQ_rmsForceAuditHistorySeq_0*& out();
    _IDL_SEQ_rmsForceAuditHistorySeq_0* _retn();

    protected:
    _IDL_SEQ_rmsForceAuditHistorySeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsForceAuditHistorySeq_0 _rmsForceAuditHistorySeq_seq;
    typedef _IDL_SEQ_rmsForceAuditHistorySeq_0 _rmsForceAuditHistorySeq_seq_1;
    typedef _IDL_SEQ_rmsForceAuditHistorySeq_0 rmsForceAuditHistorySeq;
    typedef _IDL_SEQ_rmsForceAuditHistorySeq_0_var rmsForceAuditHistorySeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsForceAuditHistorySeq;
    class  rmsForceAuditHistoryInqResult_struct_var;
    struct  rmsForceAuditHistoryInqResult_struct {
        typedef rmsForceAuditHistoryInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsForceAuditHistorySeq profiles;
       ::CORBA::Boolean overSearchCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsForceAuditHistoryInqResult_struct();
       rmsForceAuditHistoryInqResult_struct(const rmsForceAuditHistoryInqResult_struct&);
       rmsForceAuditHistoryInqResult_struct& operator=(const rmsForceAuditHistoryInqResult_struct&);
       static CORBA::Info<rmsForceAuditHistoryInqResult_struct> rmsForceAuditHistoryInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsForceAuditHistoryInqResult_struct


typedef rmsForceAuditHistoryInqResult_struct* rmsForceAuditHistoryInqResult_struct_vPtr;
typedef const rmsForceAuditHistoryInqResult_struct* rmsForceAuditHistoryInqResult_struct_cvPtr;

class  rmsForceAuditHistoryInqResult_struct_var
{
    public:

    rmsForceAuditHistoryInqResult_struct_var ();

    rmsForceAuditHistoryInqResult_struct_var (rmsForceAuditHistoryInqResult_struct *_p);

    rmsForceAuditHistoryInqResult_struct_var (const rmsForceAuditHistoryInqResult_struct_var &_s);

    rmsForceAuditHistoryInqResult_struct_var &operator= (rmsForceAuditHistoryInqResult_struct *_p);

    rmsForceAuditHistoryInqResult_struct_var &operator= (const rmsForceAuditHistoryInqResult_struct_var &_s);

    ~rmsForceAuditHistoryInqResult_struct_var ();

    rmsForceAuditHistoryInqResult_struct* operator-> ();

    const rmsForceAuditHistoryInqResult_struct& in() const;
    rmsForceAuditHistoryInqResult_struct& inout();
    rmsForceAuditHistoryInqResult_struct*& out();
    rmsForceAuditHistoryInqResult_struct* _retn();

    operator rmsForceAuditHistoryInqResult_struct_cvPtr () const;

    operator rmsForceAuditHistoryInqResult_struct_vPtr& ();

    operator const rmsForceAuditHistoryInqResult_struct& () const;

    operator rmsForceAuditHistoryInqResult_struct& ();

    protected:
    rmsForceAuditHistoryInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsForceAuditHistoryInqResult_struct;
    typedef rmsForceAuditHistoryInqResult_struct rmsForceAuditHistoryInqResult;
    typedef rmsForceAuditHistoryInqResult_struct_var rmsForceAuditHistoryInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsForceAuditHistoryInqResult;
    class  rmsECIMJob_struct_var;
    struct  rmsECIMJob_struct {
        typedef rmsECIMJob_struct_var _var_type;
       ::CORBA::Long jobIndex;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem actionCode;
       ::CORBA::String_StructElem constid;
       ::CORBA::String_StructElem jobExecDT;
       ::CORBA::String_StructElem rmsStartDT;
       ::CORBA::String_StructElem rmsEndDT;
       ::CORBA::String_StructElem rmsresult;
       ::CORBA::String_StructElem rmsjobStatus;
       ::CORBA::Long chgtoolstatus;
       ::CORBA::String_StructElem resultDesc;
       ::CORBA::Long retryCount;
       ::CORBA::String_StructElem rimStartDT;
       ::CORBA::String_StructElem rimEndDT;
       ::CORBA::String_StructElem rimExecResult;
       ::CORBA::Long svidflag;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsECIMJob_struct();
       rmsECIMJob_struct(const rmsECIMJob_struct&);
       rmsECIMJob_struct& operator=(const rmsECIMJob_struct&);
       static CORBA::Info<rmsECIMJob_struct> rmsECIMJob_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsECIMJob_struct


typedef rmsECIMJob_struct* rmsECIMJob_struct_vPtr;
typedef const rmsECIMJob_struct* rmsECIMJob_struct_cvPtr;

class  rmsECIMJob_struct_var
{
    public:

    rmsECIMJob_struct_var ();

    rmsECIMJob_struct_var (rmsECIMJob_struct *_p);

    rmsECIMJob_struct_var (const rmsECIMJob_struct_var &_s);

    rmsECIMJob_struct_var &operator= (rmsECIMJob_struct *_p);

    rmsECIMJob_struct_var &operator= (const rmsECIMJob_struct_var &_s);

    ~rmsECIMJob_struct_var ();

    rmsECIMJob_struct* operator-> ();

    const rmsECIMJob_struct& in() const;
    rmsECIMJob_struct& inout();
    rmsECIMJob_struct*& out();
    rmsECIMJob_struct* _retn();

    operator rmsECIMJob_struct_cvPtr () const;

    operator rmsECIMJob_struct_vPtr& ();

    operator const rmsECIMJob_struct& () const;

    operator rmsECIMJob_struct& ();

    protected:
    rmsECIMJob_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsECIMJob_struct;
    typedef rmsECIMJob_struct rmsECIMJob;
    typedef rmsECIMJob_struct_var rmsECIMJob_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECIMJob;
class  _IDL_SEQ_rmsECIMJobSeq_0_var;
class  _IDL_SEQ_rmsECIMJobSeq_0 {
    public:
        typedef _IDL_SEQ_rmsECIMJobSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsECIMJob *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsECIMJobSeq_0 ();
    _IDL_SEQ_rmsECIMJobSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsECIMJobSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsECIMJob* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsECIMJobSeq_0 (const _IDL_SEQ_rmsECIMJobSeq_0&);

    ~_IDL_SEQ_rmsECIMJobSeq_0 ();

    _IDL_SEQ_rmsECIMJobSeq_0& operator= (const _IDL_SEQ_rmsECIMJobSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsECIMJob& operator [] (::CORBA::ULong indx);
    const rmsECIMJob& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsECIMJob* get_buffer (::CORBA::Boolean orphan=0);
    const rmsECIMJob* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsECIMJob* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsECIMJob* src, rmsECIMJob* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsECIMJob* data); 
  public:

    static rmsECIMJob* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsECIMJob* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsECIMJob* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsECIMJobSeq_0> rmsECIMJobSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsECIMJobSeq_0* _IDL_SEQ_rmsECIMJobSeq_0_vPtr;
typedef const _IDL_SEQ_rmsECIMJobSeq_0* _IDL_SEQ_rmsECIMJobSeq_0_cvPtr;

class  _IDL_SEQ_rmsECIMJobSeq_0_var
{
    public:

    _IDL_SEQ_rmsECIMJobSeq_0_var ();

    _IDL_SEQ_rmsECIMJobSeq_0_var (_IDL_SEQ_rmsECIMJobSeq_0 *_p);

    _IDL_SEQ_rmsECIMJobSeq_0_var (const _IDL_SEQ_rmsECIMJobSeq_0_var &_s);

    _IDL_SEQ_rmsECIMJobSeq_0_var &operator= (_IDL_SEQ_rmsECIMJobSeq_0 *_p);

    _IDL_SEQ_rmsECIMJobSeq_0_var &operator= (const _IDL_SEQ_rmsECIMJobSeq_0_var &_s);

    ~_IDL_SEQ_rmsECIMJobSeq_0_var ();

    _IDL_SEQ_rmsECIMJobSeq_0* operator-> ();

    operator _IDL_SEQ_rmsECIMJobSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsECIMJobSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsECIMJobSeq_0() const;

    const rmsECIMJob& operator[] (::CORBA::ULong index) const;
    rmsECIMJob& operator[] (::CORBA::ULong index);
    const rmsECIMJob& operator[] (int index) const;
    rmsECIMJob& operator[] (int index);
    const _IDL_SEQ_rmsECIMJobSeq_0& in() const;
    _IDL_SEQ_rmsECIMJobSeq_0& inout();
    _IDL_SEQ_rmsECIMJobSeq_0*& out();
    _IDL_SEQ_rmsECIMJobSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsECIMJobSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsECIMJobSeq_0 _rmsECIMJobSeq_seq;
    typedef _IDL_SEQ_rmsECIMJobSeq_0 _rmsECIMJobSeq_seq_1;
    typedef _IDL_SEQ_rmsECIMJobSeq_0 rmsECIMJobSeq;
    typedef _IDL_SEQ_rmsECIMJobSeq_0_var rmsECIMJobSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECIMJobSeq;
    class  rmsECIMJobInqResult_struct_var;
    struct  rmsECIMJobInqResult_struct {
        typedef rmsECIMJobInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsECIMJobSeq jobs;
       ::CORBA::Boolean overSearchCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsECIMJobInqResult_struct();
       rmsECIMJobInqResult_struct(const rmsECIMJobInqResult_struct&);
       rmsECIMJobInqResult_struct& operator=(const rmsECIMJobInqResult_struct&);
       static CORBA::Info<rmsECIMJobInqResult_struct> rmsECIMJobInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsECIMJobInqResult_struct


typedef rmsECIMJobInqResult_struct* rmsECIMJobInqResult_struct_vPtr;
typedef const rmsECIMJobInqResult_struct* rmsECIMJobInqResult_struct_cvPtr;

class  rmsECIMJobInqResult_struct_var
{
    public:

    rmsECIMJobInqResult_struct_var ();

    rmsECIMJobInqResult_struct_var (rmsECIMJobInqResult_struct *_p);

    rmsECIMJobInqResult_struct_var (const rmsECIMJobInqResult_struct_var &_s);

    rmsECIMJobInqResult_struct_var &operator= (rmsECIMJobInqResult_struct *_p);

    rmsECIMJobInqResult_struct_var &operator= (const rmsECIMJobInqResult_struct_var &_s);

    ~rmsECIMJobInqResult_struct_var ();

    rmsECIMJobInqResult_struct* operator-> ();

    const rmsECIMJobInqResult_struct& in() const;
    rmsECIMJobInqResult_struct& inout();
    rmsECIMJobInqResult_struct*& out();
    rmsECIMJobInqResult_struct* _retn();

    operator rmsECIMJobInqResult_struct_cvPtr () const;

    operator rmsECIMJobInqResult_struct_vPtr& ();

    operator const rmsECIMJobInqResult_struct& () const;

    operator rmsECIMJobInqResult_struct& ();

    protected:
    rmsECIMJobInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsECIMJobInqResult_struct;
    typedef rmsECIMJobInqResult_struct rmsECIMJobInqResult;
    typedef rmsECIMJobInqResult_struct_var rmsECIMJobInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECIMJobInqResult;
    class  rmsECUATData_struct_var;
    struct  rmsECUATData_struct {
        typedef rmsECUATData_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem constid;
       ::CORBA::Long chgtoolstatus;
       ::CORBA::Long jobIndex;
       ::CORBA::String_StructElem claimTime;
       ::CORBA::Long svidflag;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsECUATData_struct();
       rmsECUATData_struct(const rmsECUATData_struct&);
       rmsECUATData_struct& operator=(const rmsECUATData_struct&);
       static CORBA::Info<rmsECUATData_struct> rmsECUATData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsECUATData_struct


typedef rmsECUATData_struct* rmsECUATData_struct_vPtr;
typedef const rmsECUATData_struct* rmsECUATData_struct_cvPtr;

class  rmsECUATData_struct_var
{
    public:

    rmsECUATData_struct_var ();

    rmsECUATData_struct_var (rmsECUATData_struct *_p);

    rmsECUATData_struct_var (const rmsECUATData_struct_var &_s);

    rmsECUATData_struct_var &operator= (rmsECUATData_struct *_p);

    rmsECUATData_struct_var &operator= (const rmsECUATData_struct_var &_s);

    ~rmsECUATData_struct_var ();

    rmsECUATData_struct* operator-> ();

    const rmsECUATData_struct& in() const;
    rmsECUATData_struct& inout();
    rmsECUATData_struct*& out();
    rmsECUATData_struct* _retn();

    operator rmsECUATData_struct_cvPtr () const;

    operator rmsECUATData_struct_vPtr& ();

    operator const rmsECUATData_struct& () const;

    operator rmsECUATData_struct& ();

    protected:
    rmsECUATData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsECUATData_struct;
    typedef rmsECUATData_struct rmsECUATData;
    typedef rmsECUATData_struct_var rmsECUATData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECUATData;
class  _IDL_SEQ_rmsECUATDataSeq_0_var;
class  _IDL_SEQ_rmsECUATDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsECUATDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsECUATData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsECUATDataSeq_0 ();
    _IDL_SEQ_rmsECUATDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsECUATDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsECUATData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsECUATDataSeq_0 (const _IDL_SEQ_rmsECUATDataSeq_0&);

    ~_IDL_SEQ_rmsECUATDataSeq_0 ();

    _IDL_SEQ_rmsECUATDataSeq_0& operator= (const _IDL_SEQ_rmsECUATDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsECUATData& operator [] (::CORBA::ULong indx);
    const rmsECUATData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsECUATData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsECUATData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsECUATData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsECUATData* src, rmsECUATData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsECUATData* data); 
  public:

    static rmsECUATData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsECUATData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsECUATData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsECUATDataSeq_0> rmsECUATDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsECUATDataSeq_0* _IDL_SEQ_rmsECUATDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsECUATDataSeq_0* _IDL_SEQ_rmsECUATDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsECUATDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsECUATDataSeq_0_var ();

    _IDL_SEQ_rmsECUATDataSeq_0_var (_IDL_SEQ_rmsECUATDataSeq_0 *_p);

    _IDL_SEQ_rmsECUATDataSeq_0_var (const _IDL_SEQ_rmsECUATDataSeq_0_var &_s);

    _IDL_SEQ_rmsECUATDataSeq_0_var &operator= (_IDL_SEQ_rmsECUATDataSeq_0 *_p);

    _IDL_SEQ_rmsECUATDataSeq_0_var &operator= (const _IDL_SEQ_rmsECUATDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsECUATDataSeq_0_var ();

    _IDL_SEQ_rmsECUATDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsECUATDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsECUATDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsECUATDataSeq_0() const;

    const rmsECUATData& operator[] (::CORBA::ULong index) const;
    rmsECUATData& operator[] (::CORBA::ULong index);
    const rmsECUATData& operator[] (int index) const;
    rmsECUATData& operator[] (int index);
    const _IDL_SEQ_rmsECUATDataSeq_0& in() const;
    _IDL_SEQ_rmsECUATDataSeq_0& inout();
    _IDL_SEQ_rmsECUATDataSeq_0*& out();
    _IDL_SEQ_rmsECUATDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsECUATDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsECUATDataSeq_0 _rmsECUATDataSeq_seq;
    typedef _IDL_SEQ_rmsECUATDataSeq_0 _rmsECUATDataSeq_seq_1;
    typedef _IDL_SEQ_rmsECUATDataSeq_0 rmsECUATDataSeq;
    typedef _IDL_SEQ_rmsECUATDataSeq_0_var rmsECUATDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECUATDataSeq;
    class  rmsECUATDataInqResult_struct_var;
    struct  rmsECUATDataInqResult_struct {
        typedef rmsECUATDataInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsECUATDataSeq ecuatInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsECUATDataInqResult_struct();
       rmsECUATDataInqResult_struct(const rmsECUATDataInqResult_struct&);
       rmsECUATDataInqResult_struct& operator=(const rmsECUATDataInqResult_struct&);
       static CORBA::Info<rmsECUATDataInqResult_struct> rmsECUATDataInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsECUATDataInqResult_struct


typedef rmsECUATDataInqResult_struct* rmsECUATDataInqResult_struct_vPtr;
typedef const rmsECUATDataInqResult_struct* rmsECUATDataInqResult_struct_cvPtr;

class  rmsECUATDataInqResult_struct_var
{
    public:

    rmsECUATDataInqResult_struct_var ();

    rmsECUATDataInqResult_struct_var (rmsECUATDataInqResult_struct *_p);

    rmsECUATDataInqResult_struct_var (const rmsECUATDataInqResult_struct_var &_s);

    rmsECUATDataInqResult_struct_var &operator= (rmsECUATDataInqResult_struct *_p);

    rmsECUATDataInqResult_struct_var &operator= (const rmsECUATDataInqResult_struct_var &_s);

    ~rmsECUATDataInqResult_struct_var ();

    rmsECUATDataInqResult_struct* operator-> ();

    const rmsECUATDataInqResult_struct& in() const;
    rmsECUATDataInqResult_struct& inout();
    rmsECUATDataInqResult_struct*& out();
    rmsECUATDataInqResult_struct* _retn();

    operator rmsECUATDataInqResult_struct_cvPtr () const;

    operator rmsECUATDataInqResult_struct_vPtr& ();

    operator const rmsECUATDataInqResult_struct& () const;

    operator rmsECUATDataInqResult_struct& ();

    protected:
    rmsECUATDataInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsECUATDataInqResult_struct;
    typedef rmsECUATDataInqResult_struct rmsECUATDataInqResult;
    typedef rmsECUATDataInqResult_struct_var rmsECUATDataInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsECUATDataInqResult;
    class  rmsRcpCmpEvdSaveReqResult_struct_var;
    struct  rmsRcpCmpEvdSaveReqResult_struct {
        typedef rmsRcpCmpEvdSaveReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpEvdSaveReqResult_struct();
       rmsRcpCmpEvdSaveReqResult_struct(const rmsRcpCmpEvdSaveReqResult_struct&);
       rmsRcpCmpEvdSaveReqResult_struct& operator=(const rmsRcpCmpEvdSaveReqResult_struct&);
       static CORBA::Info<rmsRcpCmpEvdSaveReqResult_struct> rmsRcpCmpEvdSaveReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpEvdSaveReqResult_struct


typedef rmsRcpCmpEvdSaveReqResult_struct* rmsRcpCmpEvdSaveReqResult_struct_vPtr;
typedef const rmsRcpCmpEvdSaveReqResult_struct* rmsRcpCmpEvdSaveReqResult_struct_cvPtr;

class  rmsRcpCmpEvdSaveReqResult_struct_var
{
    public:

    rmsRcpCmpEvdSaveReqResult_struct_var ();

    rmsRcpCmpEvdSaveReqResult_struct_var (rmsRcpCmpEvdSaveReqResult_struct *_p);

    rmsRcpCmpEvdSaveReqResult_struct_var (const rmsRcpCmpEvdSaveReqResult_struct_var &_s);

    rmsRcpCmpEvdSaveReqResult_struct_var &operator= (rmsRcpCmpEvdSaveReqResult_struct *_p);

    rmsRcpCmpEvdSaveReqResult_struct_var &operator= (const rmsRcpCmpEvdSaveReqResult_struct_var &_s);

    ~rmsRcpCmpEvdSaveReqResult_struct_var ();

    rmsRcpCmpEvdSaveReqResult_struct* operator-> ();

    const rmsRcpCmpEvdSaveReqResult_struct& in() const;
    rmsRcpCmpEvdSaveReqResult_struct& inout();
    rmsRcpCmpEvdSaveReqResult_struct*& out();
    rmsRcpCmpEvdSaveReqResult_struct* _retn();

    operator rmsRcpCmpEvdSaveReqResult_struct_cvPtr () const;

    operator rmsRcpCmpEvdSaveReqResult_struct_vPtr& ();

    operator const rmsRcpCmpEvdSaveReqResult_struct& () const;

    operator rmsRcpCmpEvdSaveReqResult_struct& ();

    protected:
    rmsRcpCmpEvdSaveReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpEvdSaveReqResult_struct;
    typedef rmsRcpCmpEvdSaveReqResult_struct rmsRcpCmpEvdSaveReqResult;
    typedef rmsRcpCmpEvdSaveReqResult_struct_var rmsRcpCmpEvdSaveReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpEvdSaveReqResult;
    class  rmsRcpCmpEvdDetailInqResult_struct_var;
    struct  rmsRcpCmpEvdDetailInqResult_struct {
        typedef rmsRcpCmpEvdDetailInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem s_eqpID;
       ::CORBA::String_StructElem s_subEqpID;
       ::CORBA::String_StructElem s_recipeID;
       ::CORBA::Long s_recipeLevel;
       ::rmsRecipeBodySeq s_evdDetailInfos;
       ::CORBA::String_StructElem t_eqpID;
       ::CORBA::String_StructElem t_subEqpID;
       ::CORBA::String_StructElem t_recipeID;
       ::CORBA::Long t_recipeLevel;
       ::rmsRecipeBodySeq t_evdDetailInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpEvdDetailInqResult_struct();
       rmsRcpCmpEvdDetailInqResult_struct(const rmsRcpCmpEvdDetailInqResult_struct&);
       rmsRcpCmpEvdDetailInqResult_struct& operator=(const rmsRcpCmpEvdDetailInqResult_struct&);
       static CORBA::Info<rmsRcpCmpEvdDetailInqResult_struct> rmsRcpCmpEvdDetailInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpEvdDetailInqResult_struct


typedef rmsRcpCmpEvdDetailInqResult_struct* rmsRcpCmpEvdDetailInqResult_struct_vPtr;
typedef const rmsRcpCmpEvdDetailInqResult_struct* rmsRcpCmpEvdDetailInqResult_struct_cvPtr;

class  rmsRcpCmpEvdDetailInqResult_struct_var
{
    public:

    rmsRcpCmpEvdDetailInqResult_struct_var ();

    rmsRcpCmpEvdDetailInqResult_struct_var (rmsRcpCmpEvdDetailInqResult_struct *_p);

    rmsRcpCmpEvdDetailInqResult_struct_var (const rmsRcpCmpEvdDetailInqResult_struct_var &_s);

    rmsRcpCmpEvdDetailInqResult_struct_var &operator= (rmsRcpCmpEvdDetailInqResult_struct *_p);

    rmsRcpCmpEvdDetailInqResult_struct_var &operator= (const rmsRcpCmpEvdDetailInqResult_struct_var &_s);

    ~rmsRcpCmpEvdDetailInqResult_struct_var ();

    rmsRcpCmpEvdDetailInqResult_struct* operator-> ();

    const rmsRcpCmpEvdDetailInqResult_struct& in() const;
    rmsRcpCmpEvdDetailInqResult_struct& inout();
    rmsRcpCmpEvdDetailInqResult_struct*& out();
    rmsRcpCmpEvdDetailInqResult_struct* _retn();

    operator rmsRcpCmpEvdDetailInqResult_struct_cvPtr () const;

    operator rmsRcpCmpEvdDetailInqResult_struct_vPtr& ();

    operator const rmsRcpCmpEvdDetailInqResult_struct& () const;

    operator rmsRcpCmpEvdDetailInqResult_struct& ();

    protected:
    rmsRcpCmpEvdDetailInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpEvdDetailInqResult_struct;
    typedef rmsRcpCmpEvdDetailInqResult_struct rmsRcpCmpEvdDetailInqResult;
    typedef rmsRcpCmpEvdDetailInqResult_struct_var rmsRcpCmpEvdDetailInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpEvdDetailInqResult;
    class  rmsRcpCmpExamSaveReqResult_struct_var;
    struct  rmsRcpCmpExamSaveReqResult_struct {
        typedef rmsRcpCmpExamSaveReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpExamSaveReqResult_struct();
       rmsRcpCmpExamSaveReqResult_struct(const rmsRcpCmpExamSaveReqResult_struct&);
       rmsRcpCmpExamSaveReqResult_struct& operator=(const rmsRcpCmpExamSaveReqResult_struct&);
       static CORBA::Info<rmsRcpCmpExamSaveReqResult_struct> rmsRcpCmpExamSaveReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpExamSaveReqResult_struct


typedef rmsRcpCmpExamSaveReqResult_struct* rmsRcpCmpExamSaveReqResult_struct_vPtr;
typedef const rmsRcpCmpExamSaveReqResult_struct* rmsRcpCmpExamSaveReqResult_struct_cvPtr;

class  rmsRcpCmpExamSaveReqResult_struct_var
{
    public:

    rmsRcpCmpExamSaveReqResult_struct_var ();

    rmsRcpCmpExamSaveReqResult_struct_var (rmsRcpCmpExamSaveReqResult_struct *_p);

    rmsRcpCmpExamSaveReqResult_struct_var (const rmsRcpCmpExamSaveReqResult_struct_var &_s);

    rmsRcpCmpExamSaveReqResult_struct_var &operator= (rmsRcpCmpExamSaveReqResult_struct *_p);

    rmsRcpCmpExamSaveReqResult_struct_var &operator= (const rmsRcpCmpExamSaveReqResult_struct_var &_s);

    ~rmsRcpCmpExamSaveReqResult_struct_var ();

    rmsRcpCmpExamSaveReqResult_struct* operator-> ();

    const rmsRcpCmpExamSaveReqResult_struct& in() const;
    rmsRcpCmpExamSaveReqResult_struct& inout();
    rmsRcpCmpExamSaveReqResult_struct*& out();
    rmsRcpCmpExamSaveReqResult_struct* _retn();

    operator rmsRcpCmpExamSaveReqResult_struct_cvPtr () const;

    operator rmsRcpCmpExamSaveReqResult_struct_vPtr& ();

    operator const rmsRcpCmpExamSaveReqResult_struct& () const;

    operator rmsRcpCmpExamSaveReqResult_struct& ();

    protected:
    rmsRcpCmpExamSaveReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamSaveReqResult_struct;
    typedef rmsRcpCmpExamSaveReqResult_struct rmsRcpCmpExamSaveReqResult;
    typedef rmsRcpCmpExamSaveReqResult_struct_var rmsRcpCmpExamSaveReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamSaveReqResult;
    class  rmsRcpCmpExamData_struct_var;
    struct  rmsRcpCmpExamData_struct {
        typedef rmsRcpCmpExamData_struct_var _var_type;
       ::CORBA::String_StructElem examID;
       ::CORBA::String_StructElem examDesc;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpExamData_struct();
       rmsRcpCmpExamData_struct(const rmsRcpCmpExamData_struct&);
       rmsRcpCmpExamData_struct& operator=(const rmsRcpCmpExamData_struct&);
       static CORBA::Info<rmsRcpCmpExamData_struct> rmsRcpCmpExamData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpCmpExamData_struct


typedef rmsRcpCmpExamData_struct* rmsRcpCmpExamData_struct_vPtr;
typedef const rmsRcpCmpExamData_struct* rmsRcpCmpExamData_struct_cvPtr;

class  rmsRcpCmpExamData_struct_var
{
    public:

    rmsRcpCmpExamData_struct_var ();

    rmsRcpCmpExamData_struct_var (rmsRcpCmpExamData_struct *_p);

    rmsRcpCmpExamData_struct_var (const rmsRcpCmpExamData_struct_var &_s);

    rmsRcpCmpExamData_struct_var &operator= (rmsRcpCmpExamData_struct *_p);

    rmsRcpCmpExamData_struct_var &operator= (const rmsRcpCmpExamData_struct_var &_s);

    ~rmsRcpCmpExamData_struct_var ();

    rmsRcpCmpExamData_struct* operator-> ();

    const rmsRcpCmpExamData_struct& in() const;
    rmsRcpCmpExamData_struct& inout();
    rmsRcpCmpExamData_struct*& out();
    rmsRcpCmpExamData_struct* _retn();

    operator rmsRcpCmpExamData_struct_cvPtr () const;

    operator rmsRcpCmpExamData_struct_vPtr& ();

    operator const rmsRcpCmpExamData_struct& () const;

    operator rmsRcpCmpExamData_struct& ();

    protected:
    rmsRcpCmpExamData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamData_struct;
    typedef rmsRcpCmpExamData_struct rmsRcpCmpExamData;
    typedef rmsRcpCmpExamData_struct_var rmsRcpCmpExamData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamData;
class  _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var;
class  _IDL_SEQ_rmsRcpCmpExamDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpCmpExamData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpCmpExamDataSeq_0 ();
    _IDL_SEQ_rmsRcpCmpExamDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpCmpExamDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpExamData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpCmpExamDataSeq_0 (const _IDL_SEQ_rmsRcpCmpExamDataSeq_0&);

    ~_IDL_SEQ_rmsRcpCmpExamDataSeq_0 ();

    _IDL_SEQ_rmsRcpCmpExamDataSeq_0& operator= (const _IDL_SEQ_rmsRcpCmpExamDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpCmpExamData& operator [] (::CORBA::ULong indx);
    const rmsRcpCmpExamData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpCmpExamData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpCmpExamData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpExamData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpExamData* src, rmsRcpCmpExamData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpExamData* data); 
  public:

    static rmsRcpCmpExamData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpCmpExamData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpCmpExamData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpCmpExamDataSeq_0> rmsRcpCmpExamDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpCmpExamDataSeq_0* _IDL_SEQ_rmsRcpCmpExamDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpCmpExamDataSeq_0* _IDL_SEQ_rmsRcpCmpExamDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var (_IDL_SEQ_rmsRcpCmpExamDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var (const _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var &_s);

    _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var &operator= (_IDL_SEQ_rmsRcpCmpExamDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var &operator= (const _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpCmpExamDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpExamDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpCmpExamDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpCmpExamDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpCmpExamDataSeq_0() const;

    const rmsRcpCmpExamData& operator[] (::CORBA::ULong index) const;
    rmsRcpCmpExamData& operator[] (::CORBA::ULong index);
    const rmsRcpCmpExamData& operator[] (int index) const;
    rmsRcpCmpExamData& operator[] (int index);
    const _IDL_SEQ_rmsRcpCmpExamDataSeq_0& in() const;
    _IDL_SEQ_rmsRcpCmpExamDataSeq_0& inout();
    _IDL_SEQ_rmsRcpCmpExamDataSeq_0*& out();
    _IDL_SEQ_rmsRcpCmpExamDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpCmpExamDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpCmpExamDataSeq_0 _rmsRcpCmpExamDataSeq_seq;
    typedef _IDL_SEQ_rmsRcpCmpExamDataSeq_0 _rmsRcpCmpExamDataSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpCmpExamDataSeq_0 rmsRcpCmpExamDataSeq;
    typedef _IDL_SEQ_rmsRcpCmpExamDataSeq_0_var rmsRcpCmpExamDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamDataSeq;
    class  rmsRcpCmpExamInqResult_struct_var;
    struct  rmsRcpCmpExamInqResult_struct {
        typedef rmsRcpCmpExamInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpCmpExamDataSeq examInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpExamInqResult_struct();
       rmsRcpCmpExamInqResult_struct(const rmsRcpCmpExamInqResult_struct&);
       rmsRcpCmpExamInqResult_struct& operator=(const rmsRcpCmpExamInqResult_struct&);
       static CORBA::Info<rmsRcpCmpExamInqResult_struct> rmsRcpCmpExamInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpExamInqResult_struct


typedef rmsRcpCmpExamInqResult_struct* rmsRcpCmpExamInqResult_struct_vPtr;
typedef const rmsRcpCmpExamInqResult_struct* rmsRcpCmpExamInqResult_struct_cvPtr;

class  rmsRcpCmpExamInqResult_struct_var
{
    public:

    rmsRcpCmpExamInqResult_struct_var ();

    rmsRcpCmpExamInqResult_struct_var (rmsRcpCmpExamInqResult_struct *_p);

    rmsRcpCmpExamInqResult_struct_var (const rmsRcpCmpExamInqResult_struct_var &_s);

    rmsRcpCmpExamInqResult_struct_var &operator= (rmsRcpCmpExamInqResult_struct *_p);

    rmsRcpCmpExamInqResult_struct_var &operator= (const rmsRcpCmpExamInqResult_struct_var &_s);

    ~rmsRcpCmpExamInqResult_struct_var ();

    rmsRcpCmpExamInqResult_struct* operator-> ();

    const rmsRcpCmpExamInqResult_struct& in() const;
    rmsRcpCmpExamInqResult_struct& inout();
    rmsRcpCmpExamInqResult_struct*& out();
    rmsRcpCmpExamInqResult_struct* _retn();

    operator rmsRcpCmpExamInqResult_struct_cvPtr () const;

    operator rmsRcpCmpExamInqResult_struct_vPtr& ();

    operator const rmsRcpCmpExamInqResult_struct& () const;

    operator rmsRcpCmpExamInqResult_struct& ();

    protected:
    rmsRcpCmpExamInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamInqResult_struct;
    typedef rmsRcpCmpExamInqResult_struct rmsRcpCmpExamInqResult;
    typedef rmsRcpCmpExamInqResult_struct_var rmsRcpCmpExamInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamInqResult;
    class  rmsRcpCmpExamDetailData_struct_var;
    struct  rmsRcpCmpExamDetailData_struct {
        typedef rmsRcpCmpExamDetailData_struct_var _var_type;
       ::CORBA::Long no;
       ::CORBA::String_StructElem oper_no;
       ::CORBA::String_StructElem pd_name;
       ::CORBA::String_StructElem e_eqpID;
       ::CORBA::String_StructElem e_subEqpID;
       ::CORBA::String_StructElem e_recipeID;
       ::CORBA::Long e_recipeLevel;
       ::CORBA::String_StructElem p_eqpID;
       ::CORBA::String_StructElem p_subEqpID;
       ::CORBA::String_StructElem p_recipeID;
       ::CORBA::Long p_recipeLevel;
       ::CORBA::String_StructElem evdFlg;
       ::CORBA::String_StructElem evdID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpExamDetailData_struct();
       rmsRcpCmpExamDetailData_struct(const rmsRcpCmpExamDetailData_struct&);
       rmsRcpCmpExamDetailData_struct& operator=(const rmsRcpCmpExamDetailData_struct&);
       static CORBA::Info<rmsRcpCmpExamDetailData_struct> rmsRcpCmpExamDetailData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpCmpExamDetailData_struct


typedef rmsRcpCmpExamDetailData_struct* rmsRcpCmpExamDetailData_struct_vPtr;
typedef const rmsRcpCmpExamDetailData_struct* rmsRcpCmpExamDetailData_struct_cvPtr;

class  rmsRcpCmpExamDetailData_struct_var
{
    public:

    rmsRcpCmpExamDetailData_struct_var ();

    rmsRcpCmpExamDetailData_struct_var (rmsRcpCmpExamDetailData_struct *_p);

    rmsRcpCmpExamDetailData_struct_var (const rmsRcpCmpExamDetailData_struct_var &_s);

    rmsRcpCmpExamDetailData_struct_var &operator= (rmsRcpCmpExamDetailData_struct *_p);

    rmsRcpCmpExamDetailData_struct_var &operator= (const rmsRcpCmpExamDetailData_struct_var &_s);

    ~rmsRcpCmpExamDetailData_struct_var ();

    rmsRcpCmpExamDetailData_struct* operator-> ();

    const rmsRcpCmpExamDetailData_struct& in() const;
    rmsRcpCmpExamDetailData_struct& inout();
    rmsRcpCmpExamDetailData_struct*& out();
    rmsRcpCmpExamDetailData_struct* _retn();

    operator rmsRcpCmpExamDetailData_struct_cvPtr () const;

    operator rmsRcpCmpExamDetailData_struct_vPtr& ();

    operator const rmsRcpCmpExamDetailData_struct& () const;

    operator rmsRcpCmpExamDetailData_struct& ();

    protected:
    rmsRcpCmpExamDetailData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamDetailData_struct;
    typedef rmsRcpCmpExamDetailData_struct rmsRcpCmpExamDetailData;
    typedef rmsRcpCmpExamDetailData_struct_var rmsRcpCmpExamDetailData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamDetailData;
class  _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var;
class  _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpCmpExamDetailData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 ();
    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpExamDetailData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 (const _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0&);

    ~_IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 ();

    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0& operator= (const _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpCmpExamDetailData& operator [] (::CORBA::ULong indx);
    const rmsRcpCmpExamDetailData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpCmpExamDetailData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpCmpExamDetailData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpExamDetailData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpExamDetailData* src, rmsRcpCmpExamDetailData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpExamDetailData* data); 
  public:

    static rmsRcpCmpExamDetailData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpCmpExamDetailData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpCmpExamDetailData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0> rmsRcpCmpExamDetailDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0* _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0* _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var (_IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var (const _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var &_s);

    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var &operator= (_IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var &operator= (const _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0() const;

    const rmsRcpCmpExamDetailData& operator[] (::CORBA::ULong index) const;
    rmsRcpCmpExamDetailData& operator[] (::CORBA::ULong index);
    const rmsRcpCmpExamDetailData& operator[] (int index) const;
    rmsRcpCmpExamDetailData& operator[] (int index);
    const _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0& in() const;
    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0& inout();
    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0*& out();
    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 _rmsRcpCmpExamDetailDataSeq_seq;
    typedef _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 _rmsRcpCmpExamDetailDataSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0 rmsRcpCmpExamDetailDataSeq;
    typedef _IDL_SEQ_rmsRcpCmpExamDetailDataSeq_0_var rmsRcpCmpExamDetailDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamDetailDataSeq;
    class  rmsRcpCmpExamDetailInqResult_struct_var;
    struct  rmsRcpCmpExamDetailInqResult_struct {
        typedef rmsRcpCmpExamDetailInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpCmpExamDetailDataSeq examDetailInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpExamDetailInqResult_struct();
       rmsRcpCmpExamDetailInqResult_struct(const rmsRcpCmpExamDetailInqResult_struct&);
       rmsRcpCmpExamDetailInqResult_struct& operator=(const rmsRcpCmpExamDetailInqResult_struct&);
       static CORBA::Info<rmsRcpCmpExamDetailInqResult_struct> rmsRcpCmpExamDetailInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpExamDetailInqResult_struct


typedef rmsRcpCmpExamDetailInqResult_struct* rmsRcpCmpExamDetailInqResult_struct_vPtr;
typedef const rmsRcpCmpExamDetailInqResult_struct* rmsRcpCmpExamDetailInqResult_struct_cvPtr;

class  rmsRcpCmpExamDetailInqResult_struct_var
{
    public:

    rmsRcpCmpExamDetailInqResult_struct_var ();

    rmsRcpCmpExamDetailInqResult_struct_var (rmsRcpCmpExamDetailInqResult_struct *_p);

    rmsRcpCmpExamDetailInqResult_struct_var (const rmsRcpCmpExamDetailInqResult_struct_var &_s);

    rmsRcpCmpExamDetailInqResult_struct_var &operator= (rmsRcpCmpExamDetailInqResult_struct *_p);

    rmsRcpCmpExamDetailInqResult_struct_var &operator= (const rmsRcpCmpExamDetailInqResult_struct_var &_s);

    ~rmsRcpCmpExamDetailInqResult_struct_var ();

    rmsRcpCmpExamDetailInqResult_struct* operator-> ();

    const rmsRcpCmpExamDetailInqResult_struct& in() const;
    rmsRcpCmpExamDetailInqResult_struct& inout();
    rmsRcpCmpExamDetailInqResult_struct*& out();
    rmsRcpCmpExamDetailInqResult_struct* _retn();

    operator rmsRcpCmpExamDetailInqResult_struct_cvPtr () const;

    operator rmsRcpCmpExamDetailInqResult_struct_vPtr& ();

    operator const rmsRcpCmpExamDetailInqResult_struct& () const;

    operator rmsRcpCmpExamDetailInqResult_struct& ();

    protected:
    rmsRcpCmpExamDetailInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamDetailInqResult_struct;
    typedef rmsRcpCmpExamDetailInqResult_struct rmsRcpCmpExamDetailInqResult;
    typedef rmsRcpCmpExamDetailInqResult_struct_var rmsRcpCmpExamDetailInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpExamDetailInqResult;
    class  rmsRecipeGolden_struct_var;
    struct  rmsRecipeGolden_struct {
        typedef rmsRecipeGolden_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeId;
       ::CORBA::String_StructElem eventCreateTime;
       ::CORBA::String_StructElem modifier;
       ::CORBA::String_StructElem status;
       ::CORBA::String_StructElem eventProcessTime;
       ::CORBA::String_StructElem result;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeGolden_struct();
       rmsRecipeGolden_struct(const rmsRecipeGolden_struct&);
       rmsRecipeGolden_struct& operator=(const rmsRecipeGolden_struct&);
       static CORBA::Info<rmsRecipeGolden_struct> rmsRecipeGolden_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRecipeGolden_struct


typedef rmsRecipeGolden_struct* rmsRecipeGolden_struct_vPtr;
typedef const rmsRecipeGolden_struct* rmsRecipeGolden_struct_cvPtr;

class  rmsRecipeGolden_struct_var
{
    public:

    rmsRecipeGolden_struct_var ();

    rmsRecipeGolden_struct_var (rmsRecipeGolden_struct *_p);

    rmsRecipeGolden_struct_var (const rmsRecipeGolden_struct_var &_s);

    rmsRecipeGolden_struct_var &operator= (rmsRecipeGolden_struct *_p);

    rmsRecipeGolden_struct_var &operator= (const rmsRecipeGolden_struct_var &_s);

    ~rmsRecipeGolden_struct_var ();

    rmsRecipeGolden_struct* operator-> ();

    const rmsRecipeGolden_struct& in() const;
    rmsRecipeGolden_struct& inout();
    rmsRecipeGolden_struct*& out();
    rmsRecipeGolden_struct* _retn();

    operator rmsRecipeGolden_struct_cvPtr () const;

    operator rmsRecipeGolden_struct_vPtr& ();

    operator const rmsRecipeGolden_struct& () const;

    operator rmsRecipeGolden_struct& ();

    protected:
    rmsRecipeGolden_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeGolden_struct;
    typedef rmsRecipeGolden_struct rmsRecipeGolden;
    typedef rmsRecipeGolden_struct_var rmsRecipeGolden_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeGolden;
class  _IDL_SEQ_rmsRecipeGoldenSeq_0_var;
class  _IDL_SEQ_rmsRecipeGoldenSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRecipeGoldenSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRecipeGolden *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRecipeGoldenSeq_0 ();
    _IDL_SEQ_rmsRecipeGoldenSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRecipeGoldenSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeGolden* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRecipeGoldenSeq_0 (const _IDL_SEQ_rmsRecipeGoldenSeq_0&);

    ~_IDL_SEQ_rmsRecipeGoldenSeq_0 ();

    _IDL_SEQ_rmsRecipeGoldenSeq_0& operator= (const _IDL_SEQ_rmsRecipeGoldenSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRecipeGolden& operator [] (::CORBA::ULong indx);
    const rmsRecipeGolden& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRecipeGolden* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRecipeGolden* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRecipeGolden* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeGolden* src, rmsRecipeGolden* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRecipeGolden* data); 
  public:

    static rmsRecipeGolden* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRecipeGolden* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRecipeGolden* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRecipeGoldenSeq_0> rmsRecipeGoldenSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRecipeGoldenSeq_0* _IDL_SEQ_rmsRecipeGoldenSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRecipeGoldenSeq_0* _IDL_SEQ_rmsRecipeGoldenSeq_0_cvPtr;

class  _IDL_SEQ_rmsRecipeGoldenSeq_0_var
{
    public:

    _IDL_SEQ_rmsRecipeGoldenSeq_0_var ();

    _IDL_SEQ_rmsRecipeGoldenSeq_0_var (_IDL_SEQ_rmsRecipeGoldenSeq_0 *_p);

    _IDL_SEQ_rmsRecipeGoldenSeq_0_var (const _IDL_SEQ_rmsRecipeGoldenSeq_0_var &_s);

    _IDL_SEQ_rmsRecipeGoldenSeq_0_var &operator= (_IDL_SEQ_rmsRecipeGoldenSeq_0 *_p);

    _IDL_SEQ_rmsRecipeGoldenSeq_0_var &operator= (const _IDL_SEQ_rmsRecipeGoldenSeq_0_var &_s);

    ~_IDL_SEQ_rmsRecipeGoldenSeq_0_var ();

    _IDL_SEQ_rmsRecipeGoldenSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRecipeGoldenSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRecipeGoldenSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRecipeGoldenSeq_0() const;

    const rmsRecipeGolden& operator[] (::CORBA::ULong index) const;
    rmsRecipeGolden& operator[] (::CORBA::ULong index);
    const rmsRecipeGolden& operator[] (int index) const;
    rmsRecipeGolden& operator[] (int index);
    const _IDL_SEQ_rmsRecipeGoldenSeq_0& in() const;
    _IDL_SEQ_rmsRecipeGoldenSeq_0& inout();
    _IDL_SEQ_rmsRecipeGoldenSeq_0*& out();
    _IDL_SEQ_rmsRecipeGoldenSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRecipeGoldenSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRecipeGoldenSeq_0 _rmsRecipeGoldenSeq_seq;
    typedef _IDL_SEQ_rmsRecipeGoldenSeq_0 _rmsRecipeGoldenSeq_seq_1;
    typedef _IDL_SEQ_rmsRecipeGoldenSeq_0 rmsRecipeGoldenSeq;
    typedef _IDL_SEQ_rmsRecipeGoldenSeq_0_var rmsRecipeGoldenSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeGoldenSeq;
    class  rmsRecipeGoldenInqResult_struct_var;
    struct  rmsRecipeGoldenInqResult_struct {
        typedef rmsRecipeGoldenInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRecipeGoldenSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRecipeGoldenInqResult_struct();
       rmsRecipeGoldenInqResult_struct(const rmsRecipeGoldenInqResult_struct&);
       rmsRecipeGoldenInqResult_struct& operator=(const rmsRecipeGoldenInqResult_struct&);
       static CORBA::Info<rmsRecipeGoldenInqResult_struct> rmsRecipeGoldenInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRecipeGoldenInqResult_struct


typedef rmsRecipeGoldenInqResult_struct* rmsRecipeGoldenInqResult_struct_vPtr;
typedef const rmsRecipeGoldenInqResult_struct* rmsRecipeGoldenInqResult_struct_cvPtr;

class  rmsRecipeGoldenInqResult_struct_var
{
    public:

    rmsRecipeGoldenInqResult_struct_var ();

    rmsRecipeGoldenInqResult_struct_var (rmsRecipeGoldenInqResult_struct *_p);

    rmsRecipeGoldenInqResult_struct_var (const rmsRecipeGoldenInqResult_struct_var &_s);

    rmsRecipeGoldenInqResult_struct_var &operator= (rmsRecipeGoldenInqResult_struct *_p);

    rmsRecipeGoldenInqResult_struct_var &operator= (const rmsRecipeGoldenInqResult_struct_var &_s);

    ~rmsRecipeGoldenInqResult_struct_var ();

    rmsRecipeGoldenInqResult_struct* operator-> ();

    const rmsRecipeGoldenInqResult_struct& in() const;
    rmsRecipeGoldenInqResult_struct& inout();
    rmsRecipeGoldenInqResult_struct*& out();
    rmsRecipeGoldenInqResult_struct* _retn();

    operator rmsRecipeGoldenInqResult_struct_cvPtr () const;

    operator rmsRecipeGoldenInqResult_struct_vPtr& ();

    operator const rmsRecipeGoldenInqResult_struct& () const;

    operator rmsRecipeGoldenInqResult_struct& ();

    protected:
    rmsRecipeGoldenInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeGoldenInqResult_struct;
    typedef rmsRecipeGoldenInqResult_struct rmsRecipeGoldenInqResult;
    typedef rmsRecipeGoldenInqResult_struct_var rmsRecipeGoldenInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRecipeGoldenInqResult;
    class  rmsGeneralConfig_struct_var;
    struct  rmsGeneralConfig_struct {
        typedef rmsGeneralConfig_struct_var _var_type;
       ::CORBA::String_StructElem keyname;
       ::CORBA::String_StructElem key;
       ::CORBA::String_StructElem valuename;
       ::CORBA::String_StructElem value;
       ::CORBA::String_StructElem createuser;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsGeneralConfig_struct();
       rmsGeneralConfig_struct(const rmsGeneralConfig_struct&);
       rmsGeneralConfig_struct& operator=(const rmsGeneralConfig_struct&);
       static CORBA::Info<rmsGeneralConfig_struct> rmsGeneralConfig_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsGeneralConfig_struct


typedef rmsGeneralConfig_struct* rmsGeneralConfig_struct_vPtr;
typedef const rmsGeneralConfig_struct* rmsGeneralConfig_struct_cvPtr;

class  rmsGeneralConfig_struct_var
{
    public:

    rmsGeneralConfig_struct_var ();

    rmsGeneralConfig_struct_var (rmsGeneralConfig_struct *_p);

    rmsGeneralConfig_struct_var (const rmsGeneralConfig_struct_var &_s);

    rmsGeneralConfig_struct_var &operator= (rmsGeneralConfig_struct *_p);

    rmsGeneralConfig_struct_var &operator= (const rmsGeneralConfig_struct_var &_s);

    ~rmsGeneralConfig_struct_var ();

    rmsGeneralConfig_struct* operator-> ();

    const rmsGeneralConfig_struct& in() const;
    rmsGeneralConfig_struct& inout();
    rmsGeneralConfig_struct*& out();
    rmsGeneralConfig_struct* _retn();

    operator rmsGeneralConfig_struct_cvPtr () const;

    operator rmsGeneralConfig_struct_vPtr& ();

    operator const rmsGeneralConfig_struct& () const;

    operator rmsGeneralConfig_struct& ();

    protected:
    rmsGeneralConfig_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsGeneralConfig_struct;
    typedef rmsGeneralConfig_struct rmsGeneralConfig;
    typedef rmsGeneralConfig_struct_var rmsGeneralConfig_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsGeneralConfig;
class  _IDL_SEQ_rmsGeneralConfigSeq_0_var;
class  _IDL_SEQ_rmsGeneralConfigSeq_0 {
    public:
        typedef _IDL_SEQ_rmsGeneralConfigSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsGeneralConfig *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsGeneralConfigSeq_0 ();
    _IDL_SEQ_rmsGeneralConfigSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsGeneralConfigSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsGeneralConfig* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsGeneralConfigSeq_0 (const _IDL_SEQ_rmsGeneralConfigSeq_0&);

    ~_IDL_SEQ_rmsGeneralConfigSeq_0 ();

    _IDL_SEQ_rmsGeneralConfigSeq_0& operator= (const _IDL_SEQ_rmsGeneralConfigSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsGeneralConfig& operator [] (::CORBA::ULong indx);
    const rmsGeneralConfig& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsGeneralConfig* get_buffer (::CORBA::Boolean orphan=0);
    const rmsGeneralConfig* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsGeneralConfig* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsGeneralConfig* src, rmsGeneralConfig* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsGeneralConfig* data); 
  public:

    static rmsGeneralConfig* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsGeneralConfig* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsGeneralConfig* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsGeneralConfigSeq_0> rmsGeneralConfigSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsGeneralConfigSeq_0* _IDL_SEQ_rmsGeneralConfigSeq_0_vPtr;
typedef const _IDL_SEQ_rmsGeneralConfigSeq_0* _IDL_SEQ_rmsGeneralConfigSeq_0_cvPtr;

class  _IDL_SEQ_rmsGeneralConfigSeq_0_var
{
    public:

    _IDL_SEQ_rmsGeneralConfigSeq_0_var ();

    _IDL_SEQ_rmsGeneralConfigSeq_0_var (_IDL_SEQ_rmsGeneralConfigSeq_0 *_p);

    _IDL_SEQ_rmsGeneralConfigSeq_0_var (const _IDL_SEQ_rmsGeneralConfigSeq_0_var &_s);

    _IDL_SEQ_rmsGeneralConfigSeq_0_var &operator= (_IDL_SEQ_rmsGeneralConfigSeq_0 *_p);

    _IDL_SEQ_rmsGeneralConfigSeq_0_var &operator= (const _IDL_SEQ_rmsGeneralConfigSeq_0_var &_s);

    ~_IDL_SEQ_rmsGeneralConfigSeq_0_var ();

    _IDL_SEQ_rmsGeneralConfigSeq_0* operator-> ();

    operator _IDL_SEQ_rmsGeneralConfigSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsGeneralConfigSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsGeneralConfigSeq_0() const;

    const rmsGeneralConfig& operator[] (::CORBA::ULong index) const;
    rmsGeneralConfig& operator[] (::CORBA::ULong index);
    const rmsGeneralConfig& operator[] (int index) const;
    rmsGeneralConfig& operator[] (int index);
    const _IDL_SEQ_rmsGeneralConfigSeq_0& in() const;
    _IDL_SEQ_rmsGeneralConfigSeq_0& inout();
    _IDL_SEQ_rmsGeneralConfigSeq_0*& out();
    _IDL_SEQ_rmsGeneralConfigSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsGeneralConfigSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsGeneralConfigSeq_0 _rmsGeneralConfigSeq_seq;
    typedef _IDL_SEQ_rmsGeneralConfigSeq_0 _rmsGeneralConfigSeq_seq_1;
    typedef _IDL_SEQ_rmsGeneralConfigSeq_0 rmsGeneralConfigSeq;
    typedef _IDL_SEQ_rmsGeneralConfigSeq_0_var rmsGeneralConfigSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsGeneralConfigSeq;
    class  rmsGeneralConfigInqResult_struct_var;
    struct  rmsGeneralConfigInqResult_struct {
        typedef rmsGeneralConfigInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsGeneralConfigSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsGeneralConfigInqResult_struct();
       rmsGeneralConfigInqResult_struct(const rmsGeneralConfigInqResult_struct&);
       rmsGeneralConfigInqResult_struct& operator=(const rmsGeneralConfigInqResult_struct&);
       static CORBA::Info<rmsGeneralConfigInqResult_struct> rmsGeneralConfigInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsGeneralConfigInqResult_struct


typedef rmsGeneralConfigInqResult_struct* rmsGeneralConfigInqResult_struct_vPtr;
typedef const rmsGeneralConfigInqResult_struct* rmsGeneralConfigInqResult_struct_cvPtr;

class  rmsGeneralConfigInqResult_struct_var
{
    public:

    rmsGeneralConfigInqResult_struct_var ();

    rmsGeneralConfigInqResult_struct_var (rmsGeneralConfigInqResult_struct *_p);

    rmsGeneralConfigInqResult_struct_var (const rmsGeneralConfigInqResult_struct_var &_s);

    rmsGeneralConfigInqResult_struct_var &operator= (rmsGeneralConfigInqResult_struct *_p);

    rmsGeneralConfigInqResult_struct_var &operator= (const rmsGeneralConfigInqResult_struct_var &_s);

    ~rmsGeneralConfigInqResult_struct_var ();

    rmsGeneralConfigInqResult_struct* operator-> ();

    const rmsGeneralConfigInqResult_struct& in() const;
    rmsGeneralConfigInqResult_struct& inout();
    rmsGeneralConfigInqResult_struct*& out();
    rmsGeneralConfigInqResult_struct* _retn();

    operator rmsGeneralConfigInqResult_struct_cvPtr () const;

    operator rmsGeneralConfigInqResult_struct_vPtr& ();

    operator const rmsGeneralConfigInqResult_struct& () const;

    operator rmsGeneralConfigInqResult_struct& ();

    protected:
    rmsGeneralConfigInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsGeneralConfigInqResult_struct;
    typedef rmsGeneralConfigInqResult_struct rmsGeneralConfigInqResult;
    typedef rmsGeneralConfigInqResult_struct_var rmsGeneralConfigInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsGeneralConfigInqResult;
    class  rmsEqpAuditFlagAutoTurnOnData_struct_var;
    struct  rmsEqpAuditFlagAutoTurnOnData_struct {
        typedef rmsEqpAuditFlagAutoTurnOnData_struct_var _var_type;
       ::CORBA::String_StructElem eqpID;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem flagType;
       ::CORBA::Long autoTurnOnTime;
       ::CORBA::String_StructElem clmTime;
       ::CORBA::String_StructElem clmUser;
       ::CORBA::String_StructElem clmMemo;
       ::CORBA::String_StructElem mailedEqpOwner;
       ::CORBA::String_StructElem mailedSysAdmin;
       ::CORBA::String_StructElem expectTurnOnTime;
       ::CORBA::Long hoursToTurnOn;
       ::CORBA::Long minutesToTurnOn;
       ::CORBA::Long secondsToTurnOn;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpAuditFlagAutoTurnOnData_struct();
       rmsEqpAuditFlagAutoTurnOnData_struct(const rmsEqpAuditFlagAutoTurnOnData_struct&);
       rmsEqpAuditFlagAutoTurnOnData_struct& operator=(const rmsEqpAuditFlagAutoTurnOnData_struct&);
       static CORBA::Info<rmsEqpAuditFlagAutoTurnOnData_struct> rmsEqpAuditFlagAutoTurnOnData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsEqpAuditFlagAutoTurnOnData_struct


typedef rmsEqpAuditFlagAutoTurnOnData_struct* rmsEqpAuditFlagAutoTurnOnData_struct_vPtr;
typedef const rmsEqpAuditFlagAutoTurnOnData_struct* rmsEqpAuditFlagAutoTurnOnData_struct_cvPtr;

class  rmsEqpAuditFlagAutoTurnOnData_struct_var
{
    public:

    rmsEqpAuditFlagAutoTurnOnData_struct_var ();

    rmsEqpAuditFlagAutoTurnOnData_struct_var (rmsEqpAuditFlagAutoTurnOnData_struct *_p);

    rmsEqpAuditFlagAutoTurnOnData_struct_var (const rmsEqpAuditFlagAutoTurnOnData_struct_var &_s);

    rmsEqpAuditFlagAutoTurnOnData_struct_var &operator= (rmsEqpAuditFlagAutoTurnOnData_struct *_p);

    rmsEqpAuditFlagAutoTurnOnData_struct_var &operator= (const rmsEqpAuditFlagAutoTurnOnData_struct_var &_s);

    ~rmsEqpAuditFlagAutoTurnOnData_struct_var ();

    rmsEqpAuditFlagAutoTurnOnData_struct* operator-> ();

    const rmsEqpAuditFlagAutoTurnOnData_struct& in() const;
    rmsEqpAuditFlagAutoTurnOnData_struct& inout();
    rmsEqpAuditFlagAutoTurnOnData_struct*& out();
    rmsEqpAuditFlagAutoTurnOnData_struct* _retn();

    operator rmsEqpAuditFlagAutoTurnOnData_struct_cvPtr () const;

    operator rmsEqpAuditFlagAutoTurnOnData_struct_vPtr& ();

    operator const rmsEqpAuditFlagAutoTurnOnData_struct& () const;

    operator rmsEqpAuditFlagAutoTurnOnData_struct& ();

    protected:
    rmsEqpAuditFlagAutoTurnOnData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpAuditFlagAutoTurnOnData_struct;
    typedef rmsEqpAuditFlagAutoTurnOnData_struct rmsEqpAuditFlagAutoTurnOnData;
    typedef rmsEqpAuditFlagAutoTurnOnData_struct_var rmsEqpAuditFlagAutoTurnOnData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpAuditFlagAutoTurnOnData;
class  _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var;
class  _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsEqpAuditFlagAutoTurnOnData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 ();
    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpAuditFlagAutoTurnOnData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 (const _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0&);

    ~_IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 ();

    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0& operator= (const _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsEqpAuditFlagAutoTurnOnData& operator [] (::CORBA::ULong indx);
    const rmsEqpAuditFlagAutoTurnOnData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsEqpAuditFlagAutoTurnOnData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsEqpAuditFlagAutoTurnOnData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsEqpAuditFlagAutoTurnOnData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpAuditFlagAutoTurnOnData* src, rmsEqpAuditFlagAutoTurnOnData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsEqpAuditFlagAutoTurnOnData* data); 
  public:

    static rmsEqpAuditFlagAutoTurnOnData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsEqpAuditFlagAutoTurnOnData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsEqpAuditFlagAutoTurnOnData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0> rmsEqpAuditFlagAutoTurnOnDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0* _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0* _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var ();

    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var (_IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 *_p);

    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var (const _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var &_s);

    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var &operator= (_IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 *_p);

    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var &operator= (const _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var ();

    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0() const;

    const rmsEqpAuditFlagAutoTurnOnData& operator[] (::CORBA::ULong index) const;
    rmsEqpAuditFlagAutoTurnOnData& operator[] (::CORBA::ULong index);
    const rmsEqpAuditFlagAutoTurnOnData& operator[] (int index) const;
    rmsEqpAuditFlagAutoTurnOnData& operator[] (int index);
    const _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0& in() const;
    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0& inout();
    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0*& out();
    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 _rmsEqpAuditFlagAutoTurnOnDataSeq_seq;
    typedef _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 _rmsEqpAuditFlagAutoTurnOnDataSeq_seq_1;
    typedef _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0 rmsEqpAuditFlagAutoTurnOnDataSeq;
    typedef _IDL_SEQ_rmsEqpAuditFlagAutoTurnOnDataSeq_0_var rmsEqpAuditFlagAutoTurnOnDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpAuditFlagAutoTurnOnDataSeq;
    class  rmsEqpAuditFlagAutoTurnOnInqResult_struct_var;
    struct  rmsEqpAuditFlagAutoTurnOnInqResult_struct {
        typedef rmsEqpAuditFlagAutoTurnOnInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsEqpAuditFlagAutoTurnOnDataSeq EqpAuditFlagAutoTurnOnData;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpAuditFlagAutoTurnOnInqResult_struct();
       rmsEqpAuditFlagAutoTurnOnInqResult_struct(const rmsEqpAuditFlagAutoTurnOnInqResult_struct&);
       rmsEqpAuditFlagAutoTurnOnInqResult_struct& operator=(const rmsEqpAuditFlagAutoTurnOnInqResult_struct&);
       static CORBA::Info<rmsEqpAuditFlagAutoTurnOnInqResult_struct> rmsEqpAuditFlagAutoTurnOnInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpAuditFlagAutoTurnOnInqResult_struct


typedef rmsEqpAuditFlagAutoTurnOnInqResult_struct* rmsEqpAuditFlagAutoTurnOnInqResult_struct_vPtr;
typedef const rmsEqpAuditFlagAutoTurnOnInqResult_struct* rmsEqpAuditFlagAutoTurnOnInqResult_struct_cvPtr;

class  rmsEqpAuditFlagAutoTurnOnInqResult_struct_var
{
    public:

    rmsEqpAuditFlagAutoTurnOnInqResult_struct_var ();

    rmsEqpAuditFlagAutoTurnOnInqResult_struct_var (rmsEqpAuditFlagAutoTurnOnInqResult_struct *_p);

    rmsEqpAuditFlagAutoTurnOnInqResult_struct_var (const rmsEqpAuditFlagAutoTurnOnInqResult_struct_var &_s);

    rmsEqpAuditFlagAutoTurnOnInqResult_struct_var &operator= (rmsEqpAuditFlagAutoTurnOnInqResult_struct *_p);

    rmsEqpAuditFlagAutoTurnOnInqResult_struct_var &operator= (const rmsEqpAuditFlagAutoTurnOnInqResult_struct_var &_s);

    ~rmsEqpAuditFlagAutoTurnOnInqResult_struct_var ();

    rmsEqpAuditFlagAutoTurnOnInqResult_struct* operator-> ();

    const rmsEqpAuditFlagAutoTurnOnInqResult_struct& in() const;
    rmsEqpAuditFlagAutoTurnOnInqResult_struct& inout();
    rmsEqpAuditFlagAutoTurnOnInqResult_struct*& out();
    rmsEqpAuditFlagAutoTurnOnInqResult_struct* _retn();

    operator rmsEqpAuditFlagAutoTurnOnInqResult_struct_cvPtr () const;

    operator rmsEqpAuditFlagAutoTurnOnInqResult_struct_vPtr& ();

    operator const rmsEqpAuditFlagAutoTurnOnInqResult_struct& () const;

    operator rmsEqpAuditFlagAutoTurnOnInqResult_struct& ();

    protected:
    rmsEqpAuditFlagAutoTurnOnInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpAuditFlagAutoTurnOnInqResult_struct;
    typedef rmsEqpAuditFlagAutoTurnOnInqResult_struct rmsEqpAuditFlagAutoTurnOnInqResult;
    typedef rmsEqpAuditFlagAutoTurnOnInqResult_struct_var rmsEqpAuditFlagAutoTurnOnInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpAuditFlagAutoTurnOnInqResult;
    class  rmsRcpCmpData_struct_var;
    struct  rmsRcpCmpData_struct {
        typedef rmsRcpCmpData_struct_var _var_type;
       ::CORBA::String_StructElem seqDiff;
       ::CORBA::Long valueDiff;
       ::CORBA::Long auditDiff;
       ::CORBA::Long minDiff;
       ::CORBA::Long maxDiff;
       ::CORBA::Long r1Seq;
       ::CORBA::String_StructElem r1BlockName;
       ::CORBA::String_StructElem r1ItemName;
       ::CORBA::String_StructElem r1ItemValue;
       ::CORBA::String_StructElem r1Audit;
       ::CORBA::String_StructElem r1Tolerance;
       ::CORBA::String_StructElem r1MinValue;
       ::CORBA::String_StructElem r1MaxValue;
       ::CORBA::Long r2Seq;
       ::CORBA::String_StructElem r2BlockName;
       ::CORBA::String_StructElem r2ItemName;
       ::CORBA::String_StructElem r2ItemValue;
       ::CORBA::String_StructElem r2Audit;
       ::CORBA::String_StructElem r2Tolerance;
       ::CORBA::String_StructElem r2MinValue;
       ::CORBA::String_StructElem r2MaxValue;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpData_struct();
       rmsRcpCmpData_struct(const rmsRcpCmpData_struct&);
       rmsRcpCmpData_struct& operator=(const rmsRcpCmpData_struct&);
       static CORBA::Info<rmsRcpCmpData_struct> rmsRcpCmpData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpCmpData_struct


typedef rmsRcpCmpData_struct* rmsRcpCmpData_struct_vPtr;
typedef const rmsRcpCmpData_struct* rmsRcpCmpData_struct_cvPtr;

class  rmsRcpCmpData_struct_var
{
    public:

    rmsRcpCmpData_struct_var ();

    rmsRcpCmpData_struct_var (rmsRcpCmpData_struct *_p);

    rmsRcpCmpData_struct_var (const rmsRcpCmpData_struct_var &_s);

    rmsRcpCmpData_struct_var &operator= (rmsRcpCmpData_struct *_p);

    rmsRcpCmpData_struct_var &operator= (const rmsRcpCmpData_struct_var &_s);

    ~rmsRcpCmpData_struct_var ();

    rmsRcpCmpData_struct* operator-> ();

    const rmsRcpCmpData_struct& in() const;
    rmsRcpCmpData_struct& inout();
    rmsRcpCmpData_struct*& out();
    rmsRcpCmpData_struct* _retn();

    operator rmsRcpCmpData_struct_cvPtr () const;

    operator rmsRcpCmpData_struct_vPtr& ();

    operator const rmsRcpCmpData_struct& () const;

    operator rmsRcpCmpData_struct& ();

    protected:
    rmsRcpCmpData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpData_struct;
    typedef rmsRcpCmpData_struct rmsRcpCmpData;
    typedef rmsRcpCmpData_struct_var rmsRcpCmpData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpData;
class  _IDL_SEQ_rmsRcpCmpDataSeq_0_var;
class  _IDL_SEQ_rmsRcpCmpDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpCmpDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpCmpData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpCmpDataSeq_0 ();
    _IDL_SEQ_rmsRcpCmpDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpCmpDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpCmpDataSeq_0 (const _IDL_SEQ_rmsRcpCmpDataSeq_0&);

    ~_IDL_SEQ_rmsRcpCmpDataSeq_0 ();

    _IDL_SEQ_rmsRcpCmpDataSeq_0& operator= (const _IDL_SEQ_rmsRcpCmpDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpCmpData& operator [] (::CORBA::ULong indx);
    const rmsRcpCmpData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpCmpData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpCmpData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpData* src, rmsRcpCmpData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpData* data); 
  public:

    static rmsRcpCmpData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpCmpData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpCmpData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpCmpDataSeq_0> rmsRcpCmpDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpCmpDataSeq_0* _IDL_SEQ_rmsRcpCmpDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpCmpDataSeq_0* _IDL_SEQ_rmsRcpCmpDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpCmpDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpCmpDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpDataSeq_0_var (_IDL_SEQ_rmsRcpCmpDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpDataSeq_0_var (const _IDL_SEQ_rmsRcpCmpDataSeq_0_var &_s);

    _IDL_SEQ_rmsRcpCmpDataSeq_0_var &operator= (_IDL_SEQ_rmsRcpCmpDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpDataSeq_0_var &operator= (const _IDL_SEQ_rmsRcpCmpDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpCmpDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpCmpDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpCmpDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpCmpDataSeq_0() const;

    const rmsRcpCmpData& operator[] (::CORBA::ULong index) const;
    rmsRcpCmpData& operator[] (::CORBA::ULong index);
    const rmsRcpCmpData& operator[] (int index) const;
    rmsRcpCmpData& operator[] (int index);
    const _IDL_SEQ_rmsRcpCmpDataSeq_0& in() const;
    _IDL_SEQ_rmsRcpCmpDataSeq_0& inout();
    _IDL_SEQ_rmsRcpCmpDataSeq_0*& out();
    _IDL_SEQ_rmsRcpCmpDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpCmpDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpCmpDataSeq_0 _rmsRcpCmpDataSeq_seq;
    typedef _IDL_SEQ_rmsRcpCmpDataSeq_0 _rmsRcpCmpDataSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpCmpDataSeq_0 rmsRcpCmpDataSeq;
    typedef _IDL_SEQ_rmsRcpCmpDataSeq_0_var rmsRcpCmpDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpDataSeq;
    class  rmsRcpCmpInqList_struct_var;
    struct  rmsRcpCmpInqList_struct {
        typedef rmsRcpCmpInqList_struct_var _var_type;
       ::CORBA::String_StructElem r1_eqpID;
       ::CORBA::String_StructElem r1_subEqpID;
       ::CORBA::String_StructElem r1_recipeID;
       ::CORBA::Long r1_recipeLevel;
       ::CORBA::Long r1_goldenFlag;
       ::CORBA::String_StructElem r2_eqpID;
       ::CORBA::String_StructElem r2_subEqpID;
       ::CORBA::String_StructElem r2_recipeID;
       ::CORBA::Long r2_recipeLevel;
       ::CORBA::Long r2_goldenFlag;
       ::rmsRcpCmpDataSeq rcpCmpInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpInqList_struct();
       rmsRcpCmpInqList_struct(const rmsRcpCmpInqList_struct&);
       rmsRcpCmpInqList_struct& operator=(const rmsRcpCmpInqList_struct&);
       static CORBA::Info<rmsRcpCmpInqList_struct> rmsRcpCmpInqList_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpInqList_struct


typedef rmsRcpCmpInqList_struct* rmsRcpCmpInqList_struct_vPtr;
typedef const rmsRcpCmpInqList_struct* rmsRcpCmpInqList_struct_cvPtr;

class  rmsRcpCmpInqList_struct_var
{
    public:

    rmsRcpCmpInqList_struct_var ();

    rmsRcpCmpInqList_struct_var (rmsRcpCmpInqList_struct *_p);

    rmsRcpCmpInqList_struct_var (const rmsRcpCmpInqList_struct_var &_s);

    rmsRcpCmpInqList_struct_var &operator= (rmsRcpCmpInqList_struct *_p);

    rmsRcpCmpInqList_struct_var &operator= (const rmsRcpCmpInqList_struct_var &_s);

    ~rmsRcpCmpInqList_struct_var ();

    rmsRcpCmpInqList_struct* operator-> ();

    const rmsRcpCmpInqList_struct& in() const;
    rmsRcpCmpInqList_struct& inout();
    rmsRcpCmpInqList_struct*& out();
    rmsRcpCmpInqList_struct* _retn();

    operator rmsRcpCmpInqList_struct_cvPtr () const;

    operator rmsRcpCmpInqList_struct_vPtr& ();

    operator const rmsRcpCmpInqList_struct& () const;

    operator rmsRcpCmpInqList_struct& ();

    protected:
    rmsRcpCmpInqList_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpInqList_struct;
    typedef rmsRcpCmpInqList_struct rmsRcpCmpInqList;
    typedef rmsRcpCmpInqList_struct_var rmsRcpCmpInqList_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpInqList;
class  _IDL_SEQ_rmsRcpCmpInqListSeq_0_var;
class  _IDL_SEQ_rmsRcpCmpInqListSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpCmpInqListSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpCmpInqList *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpCmpInqListSeq_0 ();
    _IDL_SEQ_rmsRcpCmpInqListSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpCmpInqListSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpInqList* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpCmpInqListSeq_0 (const _IDL_SEQ_rmsRcpCmpInqListSeq_0&);

    ~_IDL_SEQ_rmsRcpCmpInqListSeq_0 ();

    _IDL_SEQ_rmsRcpCmpInqListSeq_0& operator= (const _IDL_SEQ_rmsRcpCmpInqListSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpCmpInqList& operator [] (::CORBA::ULong indx);
    const rmsRcpCmpInqList& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpCmpInqList* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpCmpInqList* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpInqList* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpInqList* src, rmsRcpCmpInqList* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpInqList* data); 
  public:

    static rmsRcpCmpInqList* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpCmpInqList* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpCmpInqList* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpCmpInqListSeq_0> rmsRcpCmpInqListSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpCmpInqListSeq_0* _IDL_SEQ_rmsRcpCmpInqListSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpCmpInqListSeq_0* _IDL_SEQ_rmsRcpCmpInqListSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpCmpInqListSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpCmpInqListSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpInqListSeq_0_var (_IDL_SEQ_rmsRcpCmpInqListSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpInqListSeq_0_var (const _IDL_SEQ_rmsRcpCmpInqListSeq_0_var &_s);

    _IDL_SEQ_rmsRcpCmpInqListSeq_0_var &operator= (_IDL_SEQ_rmsRcpCmpInqListSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpInqListSeq_0_var &operator= (const _IDL_SEQ_rmsRcpCmpInqListSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpCmpInqListSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpInqListSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpCmpInqListSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpCmpInqListSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpCmpInqListSeq_0() const;

    const rmsRcpCmpInqList& operator[] (::CORBA::ULong index) const;
    rmsRcpCmpInqList& operator[] (::CORBA::ULong index);
    const rmsRcpCmpInqList& operator[] (int index) const;
    rmsRcpCmpInqList& operator[] (int index);
    const _IDL_SEQ_rmsRcpCmpInqListSeq_0& in() const;
    _IDL_SEQ_rmsRcpCmpInqListSeq_0& inout();
    _IDL_SEQ_rmsRcpCmpInqListSeq_0*& out();
    _IDL_SEQ_rmsRcpCmpInqListSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpCmpInqListSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpCmpInqListSeq_0 _rmsRcpCmpInqListSeq_seq;
    typedef _IDL_SEQ_rmsRcpCmpInqListSeq_0 _rmsRcpCmpInqListSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpCmpInqListSeq_0 rmsRcpCmpInqListSeq;
    typedef _IDL_SEQ_rmsRcpCmpInqListSeq_0_var rmsRcpCmpInqListSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpInqListSeq;
    class  rmsRcpCmpInqResult_struct_var;
    struct  rmsRcpCmpInqResult_struct {
        typedef rmsRcpCmpInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpCmpInqListSeq rcpCmpListInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpInqResult_struct();
       rmsRcpCmpInqResult_struct(const rmsRcpCmpInqResult_struct&);
       rmsRcpCmpInqResult_struct& operator=(const rmsRcpCmpInqResult_struct&);
       static CORBA::Info<rmsRcpCmpInqResult_struct> rmsRcpCmpInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpInqResult_struct


typedef rmsRcpCmpInqResult_struct* rmsRcpCmpInqResult_struct_vPtr;
typedef const rmsRcpCmpInqResult_struct* rmsRcpCmpInqResult_struct_cvPtr;

class  rmsRcpCmpInqResult_struct_var
{
    public:

    rmsRcpCmpInqResult_struct_var ();

    rmsRcpCmpInqResult_struct_var (rmsRcpCmpInqResult_struct *_p);

    rmsRcpCmpInqResult_struct_var (const rmsRcpCmpInqResult_struct_var &_s);

    rmsRcpCmpInqResult_struct_var &operator= (rmsRcpCmpInqResult_struct *_p);

    rmsRcpCmpInqResult_struct_var &operator= (const rmsRcpCmpInqResult_struct_var &_s);

    ~rmsRcpCmpInqResult_struct_var ();

    rmsRcpCmpInqResult_struct* operator-> ();

    const rmsRcpCmpInqResult_struct& in() const;
    rmsRcpCmpInqResult_struct& inout();
    rmsRcpCmpInqResult_struct*& out();
    rmsRcpCmpInqResult_struct* _retn();

    operator rmsRcpCmpInqResult_struct_cvPtr () const;

    operator rmsRcpCmpInqResult_struct_vPtr& ();

    operator const rmsRcpCmpInqResult_struct& () const;

    operator rmsRcpCmpInqResult_struct& ();

    protected:
    rmsRcpCmpInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpInqResult_struct;
    typedef rmsRcpCmpInqResult_struct rmsRcpCmpInqResult;
    typedef rmsRcpCmpInqResult_struct_var rmsRcpCmpInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpInqResult;
    class  rmsRcpCmpBatchSaveReqResult_struct_var;
    struct  rmsRcpCmpBatchSaveReqResult_struct {
        typedef rmsRcpCmpBatchSaveReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpBatchSaveReqResult_struct();
       rmsRcpCmpBatchSaveReqResult_struct(const rmsRcpCmpBatchSaveReqResult_struct&);
       rmsRcpCmpBatchSaveReqResult_struct& operator=(const rmsRcpCmpBatchSaveReqResult_struct&);
       static CORBA::Info<rmsRcpCmpBatchSaveReqResult_struct> rmsRcpCmpBatchSaveReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpBatchSaveReqResult_struct


typedef rmsRcpCmpBatchSaveReqResult_struct* rmsRcpCmpBatchSaveReqResult_struct_vPtr;
typedef const rmsRcpCmpBatchSaveReqResult_struct* rmsRcpCmpBatchSaveReqResult_struct_cvPtr;

class  rmsRcpCmpBatchSaveReqResult_struct_var
{
    public:

    rmsRcpCmpBatchSaveReqResult_struct_var ();

    rmsRcpCmpBatchSaveReqResult_struct_var (rmsRcpCmpBatchSaveReqResult_struct *_p);

    rmsRcpCmpBatchSaveReqResult_struct_var (const rmsRcpCmpBatchSaveReqResult_struct_var &_s);

    rmsRcpCmpBatchSaveReqResult_struct_var &operator= (rmsRcpCmpBatchSaveReqResult_struct *_p);

    rmsRcpCmpBatchSaveReqResult_struct_var &operator= (const rmsRcpCmpBatchSaveReqResult_struct_var &_s);

    ~rmsRcpCmpBatchSaveReqResult_struct_var ();

    rmsRcpCmpBatchSaveReqResult_struct* operator-> ();

    const rmsRcpCmpBatchSaveReqResult_struct& in() const;
    rmsRcpCmpBatchSaveReqResult_struct& inout();
    rmsRcpCmpBatchSaveReqResult_struct*& out();
    rmsRcpCmpBatchSaveReqResult_struct* _retn();

    operator rmsRcpCmpBatchSaveReqResult_struct_cvPtr () const;

    operator rmsRcpCmpBatchSaveReqResult_struct_vPtr& ();

    operator const rmsRcpCmpBatchSaveReqResult_struct& () const;

    operator rmsRcpCmpBatchSaveReqResult_struct& ();

    protected:
    rmsRcpCmpBatchSaveReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchSaveReqResult_struct;
    typedef rmsRcpCmpBatchSaveReqResult_struct rmsRcpCmpBatchSaveReqResult;
    typedef rmsRcpCmpBatchSaveReqResult_struct_var rmsRcpCmpBatchSaveReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchSaveReqResult;
    class  rmsRcpCmpBatchUpdateReqResult_struct_var;
    struct  rmsRcpCmpBatchUpdateReqResult_struct {
        typedef rmsRcpCmpBatchUpdateReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpBatchUpdateReqResult_struct();
       rmsRcpCmpBatchUpdateReqResult_struct(const rmsRcpCmpBatchUpdateReqResult_struct&);
       rmsRcpCmpBatchUpdateReqResult_struct& operator=(const rmsRcpCmpBatchUpdateReqResult_struct&);
       static CORBA::Info<rmsRcpCmpBatchUpdateReqResult_struct> rmsRcpCmpBatchUpdateReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpBatchUpdateReqResult_struct


typedef rmsRcpCmpBatchUpdateReqResult_struct* rmsRcpCmpBatchUpdateReqResult_struct_vPtr;
typedef const rmsRcpCmpBatchUpdateReqResult_struct* rmsRcpCmpBatchUpdateReqResult_struct_cvPtr;

class  rmsRcpCmpBatchUpdateReqResult_struct_var
{
    public:

    rmsRcpCmpBatchUpdateReqResult_struct_var ();

    rmsRcpCmpBatchUpdateReqResult_struct_var (rmsRcpCmpBatchUpdateReqResult_struct *_p);

    rmsRcpCmpBatchUpdateReqResult_struct_var (const rmsRcpCmpBatchUpdateReqResult_struct_var &_s);

    rmsRcpCmpBatchUpdateReqResult_struct_var &operator= (rmsRcpCmpBatchUpdateReqResult_struct *_p);

    rmsRcpCmpBatchUpdateReqResult_struct_var &operator= (const rmsRcpCmpBatchUpdateReqResult_struct_var &_s);

    ~rmsRcpCmpBatchUpdateReqResult_struct_var ();

    rmsRcpCmpBatchUpdateReqResult_struct* operator-> ();

    const rmsRcpCmpBatchUpdateReqResult_struct& in() const;
    rmsRcpCmpBatchUpdateReqResult_struct& inout();
    rmsRcpCmpBatchUpdateReqResult_struct*& out();
    rmsRcpCmpBatchUpdateReqResult_struct* _retn();

    operator rmsRcpCmpBatchUpdateReqResult_struct_cvPtr () const;

    operator rmsRcpCmpBatchUpdateReqResult_struct_vPtr& ();

    operator const rmsRcpCmpBatchUpdateReqResult_struct& () const;

    operator rmsRcpCmpBatchUpdateReqResult_struct& ();

    protected:
    rmsRcpCmpBatchUpdateReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchUpdateReqResult_struct;
    typedef rmsRcpCmpBatchUpdateReqResult_struct rmsRcpCmpBatchUpdateReqResult;
    typedef rmsRcpCmpBatchUpdateReqResult_struct_var rmsRcpCmpBatchUpdateReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchUpdateReqResult;
    class  rmsRcpCmpBatchDeleteReqResult_struct_var;
    struct  rmsRcpCmpBatchDeleteReqResult_struct {
        typedef rmsRcpCmpBatchDeleteReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpBatchDeleteReqResult_struct();
       rmsRcpCmpBatchDeleteReqResult_struct(const rmsRcpCmpBatchDeleteReqResult_struct&);
       rmsRcpCmpBatchDeleteReqResult_struct& operator=(const rmsRcpCmpBatchDeleteReqResult_struct&);
       static CORBA::Info<rmsRcpCmpBatchDeleteReqResult_struct> rmsRcpCmpBatchDeleteReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpBatchDeleteReqResult_struct


typedef rmsRcpCmpBatchDeleteReqResult_struct* rmsRcpCmpBatchDeleteReqResult_struct_vPtr;
typedef const rmsRcpCmpBatchDeleteReqResult_struct* rmsRcpCmpBatchDeleteReqResult_struct_cvPtr;

class  rmsRcpCmpBatchDeleteReqResult_struct_var
{
    public:

    rmsRcpCmpBatchDeleteReqResult_struct_var ();

    rmsRcpCmpBatchDeleteReqResult_struct_var (rmsRcpCmpBatchDeleteReqResult_struct *_p);

    rmsRcpCmpBatchDeleteReqResult_struct_var (const rmsRcpCmpBatchDeleteReqResult_struct_var &_s);

    rmsRcpCmpBatchDeleteReqResult_struct_var &operator= (rmsRcpCmpBatchDeleteReqResult_struct *_p);

    rmsRcpCmpBatchDeleteReqResult_struct_var &operator= (const rmsRcpCmpBatchDeleteReqResult_struct_var &_s);

    ~rmsRcpCmpBatchDeleteReqResult_struct_var ();

    rmsRcpCmpBatchDeleteReqResult_struct* operator-> ();

    const rmsRcpCmpBatchDeleteReqResult_struct& in() const;
    rmsRcpCmpBatchDeleteReqResult_struct& inout();
    rmsRcpCmpBatchDeleteReqResult_struct*& out();
    rmsRcpCmpBatchDeleteReqResult_struct* _retn();

    operator rmsRcpCmpBatchDeleteReqResult_struct_cvPtr () const;

    operator rmsRcpCmpBatchDeleteReqResult_struct_vPtr& ();

    operator const rmsRcpCmpBatchDeleteReqResult_struct& () const;

    operator rmsRcpCmpBatchDeleteReqResult_struct& ();

    protected:
    rmsRcpCmpBatchDeleteReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchDeleteReqResult_struct;
    typedef rmsRcpCmpBatchDeleteReqResult_struct rmsRcpCmpBatchDeleteReqResult;
    typedef rmsRcpCmpBatchDeleteReqResult_struct_var rmsRcpCmpBatchDeleteReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchDeleteReqResult;
    class  rmsRcpCmpBatchData_struct_var;
    struct  rmsRcpCmpBatchData_struct {
        typedef rmsRcpCmpBatchData_struct_var _var_type;
       ::CORBA::String_StructElem userID;
       ::CORBA::String_StructElem batchName;
       ::CORBA::String_StructElem batchDesc;
       ::CORBA::String_StructElem email;
       ::CORBA::String_StructElem status;
       ::CORBA::String_StructElem registerTime;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpBatchData_struct();
       rmsRcpCmpBatchData_struct(const rmsRcpCmpBatchData_struct&);
       rmsRcpCmpBatchData_struct& operator=(const rmsRcpCmpBatchData_struct&);
       static CORBA::Info<rmsRcpCmpBatchData_struct> rmsRcpCmpBatchData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpCmpBatchData_struct


typedef rmsRcpCmpBatchData_struct* rmsRcpCmpBatchData_struct_vPtr;
typedef const rmsRcpCmpBatchData_struct* rmsRcpCmpBatchData_struct_cvPtr;

class  rmsRcpCmpBatchData_struct_var
{
    public:

    rmsRcpCmpBatchData_struct_var ();

    rmsRcpCmpBatchData_struct_var (rmsRcpCmpBatchData_struct *_p);

    rmsRcpCmpBatchData_struct_var (const rmsRcpCmpBatchData_struct_var &_s);

    rmsRcpCmpBatchData_struct_var &operator= (rmsRcpCmpBatchData_struct *_p);

    rmsRcpCmpBatchData_struct_var &operator= (const rmsRcpCmpBatchData_struct_var &_s);

    ~rmsRcpCmpBatchData_struct_var ();

    rmsRcpCmpBatchData_struct* operator-> ();

    const rmsRcpCmpBatchData_struct& in() const;
    rmsRcpCmpBatchData_struct& inout();
    rmsRcpCmpBatchData_struct*& out();
    rmsRcpCmpBatchData_struct* _retn();

    operator rmsRcpCmpBatchData_struct_cvPtr () const;

    operator rmsRcpCmpBatchData_struct_vPtr& ();

    operator const rmsRcpCmpBatchData_struct& () const;

    operator rmsRcpCmpBatchData_struct& ();

    protected:
    rmsRcpCmpBatchData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchData_struct;
    typedef rmsRcpCmpBatchData_struct rmsRcpCmpBatchData;
    typedef rmsRcpCmpBatchData_struct_var rmsRcpCmpBatchData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchData;
class  _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var;
class  _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpCmpBatchData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 ();
    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpBatchData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 (const _IDL_SEQ_rmsRcpCmpBatchDataSeq_0&);

    ~_IDL_SEQ_rmsRcpCmpBatchDataSeq_0 ();

    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0& operator= (const _IDL_SEQ_rmsRcpCmpBatchDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpCmpBatchData& operator [] (::CORBA::ULong indx);
    const rmsRcpCmpBatchData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpCmpBatchData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpCmpBatchData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpBatchData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpBatchData* src, rmsRcpCmpBatchData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpBatchData* data); 
  public:

    static rmsRcpCmpBatchData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpCmpBatchData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpCmpBatchData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpCmpBatchDataSeq_0> rmsRcpCmpBatchDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpCmpBatchDataSeq_0* _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpCmpBatchDataSeq_0* _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var (_IDL_SEQ_rmsRcpCmpBatchDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var (const _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var &_s);

    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var &operator= (_IDL_SEQ_rmsRcpCmpBatchDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var &operator= (const _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpCmpBatchDataSeq_0() const;

    const rmsRcpCmpBatchData& operator[] (::CORBA::ULong index) const;
    rmsRcpCmpBatchData& operator[] (::CORBA::ULong index);
    const rmsRcpCmpBatchData& operator[] (int index) const;
    rmsRcpCmpBatchData& operator[] (int index);
    const _IDL_SEQ_rmsRcpCmpBatchDataSeq_0& in() const;
    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0& inout();
    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0*& out();
    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 _rmsRcpCmpBatchDataSeq_seq;
    typedef _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 _rmsRcpCmpBatchDataSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpCmpBatchDataSeq_0 rmsRcpCmpBatchDataSeq;
    typedef _IDL_SEQ_rmsRcpCmpBatchDataSeq_0_var rmsRcpCmpBatchDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchDataSeq;
    class  rmsRcpCmpBatchInqResult_struct_var;
    struct  rmsRcpCmpBatchInqResult_struct {
        typedef rmsRcpCmpBatchInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpCmpBatchDataSeq rcpCmpBatchInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpBatchInqResult_struct();
       rmsRcpCmpBatchInqResult_struct(const rmsRcpCmpBatchInqResult_struct&);
       rmsRcpCmpBatchInqResult_struct& operator=(const rmsRcpCmpBatchInqResult_struct&);
       static CORBA::Info<rmsRcpCmpBatchInqResult_struct> rmsRcpCmpBatchInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpBatchInqResult_struct


typedef rmsRcpCmpBatchInqResult_struct* rmsRcpCmpBatchInqResult_struct_vPtr;
typedef const rmsRcpCmpBatchInqResult_struct* rmsRcpCmpBatchInqResult_struct_cvPtr;

class  rmsRcpCmpBatchInqResult_struct_var
{
    public:

    rmsRcpCmpBatchInqResult_struct_var ();

    rmsRcpCmpBatchInqResult_struct_var (rmsRcpCmpBatchInqResult_struct *_p);

    rmsRcpCmpBatchInqResult_struct_var (const rmsRcpCmpBatchInqResult_struct_var &_s);

    rmsRcpCmpBatchInqResult_struct_var &operator= (rmsRcpCmpBatchInqResult_struct *_p);

    rmsRcpCmpBatchInqResult_struct_var &operator= (const rmsRcpCmpBatchInqResult_struct_var &_s);

    ~rmsRcpCmpBatchInqResult_struct_var ();

    rmsRcpCmpBatchInqResult_struct* operator-> ();

    const rmsRcpCmpBatchInqResult_struct& in() const;
    rmsRcpCmpBatchInqResult_struct& inout();
    rmsRcpCmpBatchInqResult_struct*& out();
    rmsRcpCmpBatchInqResult_struct* _retn();

    operator rmsRcpCmpBatchInqResult_struct_cvPtr () const;

    operator rmsRcpCmpBatchInqResult_struct_vPtr& ();

    operator const rmsRcpCmpBatchInqResult_struct& () const;

    operator rmsRcpCmpBatchInqResult_struct& ();

    protected:
    rmsRcpCmpBatchInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchInqResult_struct;
    typedef rmsRcpCmpBatchInqResult_struct rmsRcpCmpBatchInqResult;
    typedef rmsRcpCmpBatchInqResult_struct_var rmsRcpCmpBatchInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpBatchInqResult;
    class  rmsRcpCmpPairData_struct_var;
    struct  rmsRcpCmpPairData_struct {
        typedef rmsRcpCmpPairData_struct_var _var_type;
       ::CORBA::Long no;
       ::CORBA::String_StructElem r1_eqpID;
       ::CORBA::String_StructElem r1_subEqpID;
       ::CORBA::String_StructElem r1_recipeID;
       ::CORBA::Long r1_recipeLevel;
       ::CORBA::Long r1_goldenFlag;
       ::CORBA::String_StructElem r2_eqpID;
       ::CORBA::String_StructElem r2_subEqpID;
       ::CORBA::String_StructElem r2_recipeID;
       ::CORBA::Long r2_recipeLevel;
       ::CORBA::Long r2_goldenFlag;
       ::CORBA::String_StructElem status;
       ::CORBA::String_StructElem autoExpanded;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpPairData_struct();
       rmsRcpCmpPairData_struct(const rmsRcpCmpPairData_struct&);
       rmsRcpCmpPairData_struct& operator=(const rmsRcpCmpPairData_struct&);
       static CORBA::Info<rmsRcpCmpPairData_struct> rmsRcpCmpPairData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpCmpPairData_struct


typedef rmsRcpCmpPairData_struct* rmsRcpCmpPairData_struct_vPtr;
typedef const rmsRcpCmpPairData_struct* rmsRcpCmpPairData_struct_cvPtr;

class  rmsRcpCmpPairData_struct_var
{
    public:

    rmsRcpCmpPairData_struct_var ();

    rmsRcpCmpPairData_struct_var (rmsRcpCmpPairData_struct *_p);

    rmsRcpCmpPairData_struct_var (const rmsRcpCmpPairData_struct_var &_s);

    rmsRcpCmpPairData_struct_var &operator= (rmsRcpCmpPairData_struct *_p);

    rmsRcpCmpPairData_struct_var &operator= (const rmsRcpCmpPairData_struct_var &_s);

    ~rmsRcpCmpPairData_struct_var ();

    rmsRcpCmpPairData_struct* operator-> ();

    const rmsRcpCmpPairData_struct& in() const;
    rmsRcpCmpPairData_struct& inout();
    rmsRcpCmpPairData_struct*& out();
    rmsRcpCmpPairData_struct* _retn();

    operator rmsRcpCmpPairData_struct_cvPtr () const;

    operator rmsRcpCmpPairData_struct_vPtr& ();

    operator const rmsRcpCmpPairData_struct& () const;

    operator rmsRcpCmpPairData_struct& ();

    protected:
    rmsRcpCmpPairData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairData_struct;
    typedef rmsRcpCmpPairData_struct rmsRcpCmpPairData;
    typedef rmsRcpCmpPairData_struct_var rmsRcpCmpPairData_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairData;
class  _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var;
class  _IDL_SEQ_rmsRcpCmpPairDataSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpCmpPairData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpCmpPairDataSeq_0 ();
    _IDL_SEQ_rmsRcpCmpPairDataSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpCmpPairDataSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpPairData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpCmpPairDataSeq_0 (const _IDL_SEQ_rmsRcpCmpPairDataSeq_0&);

    ~_IDL_SEQ_rmsRcpCmpPairDataSeq_0 ();

    _IDL_SEQ_rmsRcpCmpPairDataSeq_0& operator= (const _IDL_SEQ_rmsRcpCmpPairDataSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpCmpPairData& operator [] (::CORBA::ULong indx);
    const rmsRcpCmpPairData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpCmpPairData* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpCmpPairData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpPairData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpPairData* src, rmsRcpCmpPairData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpPairData* data); 
  public:

    static rmsRcpCmpPairData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpCmpPairData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpCmpPairData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpCmpPairDataSeq_0> rmsRcpCmpPairDataSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpCmpPairDataSeq_0* _IDL_SEQ_rmsRcpCmpPairDataSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpCmpPairDataSeq_0* _IDL_SEQ_rmsRcpCmpPairDataSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var (_IDL_SEQ_rmsRcpCmpPairDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var (const _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var &_s);

    _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var &operator= (_IDL_SEQ_rmsRcpCmpPairDataSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var &operator= (const _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpCmpPairDataSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpPairDataSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpCmpPairDataSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpCmpPairDataSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpCmpPairDataSeq_0() const;

    const rmsRcpCmpPairData& operator[] (::CORBA::ULong index) const;
    rmsRcpCmpPairData& operator[] (::CORBA::ULong index);
    const rmsRcpCmpPairData& operator[] (int index) const;
    rmsRcpCmpPairData& operator[] (int index);
    const _IDL_SEQ_rmsRcpCmpPairDataSeq_0& in() const;
    _IDL_SEQ_rmsRcpCmpPairDataSeq_0& inout();
    _IDL_SEQ_rmsRcpCmpPairDataSeq_0*& out();
    _IDL_SEQ_rmsRcpCmpPairDataSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpCmpPairDataSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpCmpPairDataSeq_0 _rmsRcpCmpPairDataSeq_seq;
    typedef _IDL_SEQ_rmsRcpCmpPairDataSeq_0 _rmsRcpCmpPairDataSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpCmpPairDataSeq_0 rmsRcpCmpPairDataSeq;
    typedef _IDL_SEQ_rmsRcpCmpPairDataSeq_0_var rmsRcpCmpPairDataSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairDataSeq;
    class  rmsRcpCmpPairInqResult_struct_var;
    struct  rmsRcpCmpPairInqResult_struct {
        typedef rmsRcpCmpPairInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem userID;
       ::CORBA::String_StructElem batchName;
       ::rmsRcpCmpPairDataSeq rcpCmpPairInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpPairInqResult_struct();
       rmsRcpCmpPairInqResult_struct(const rmsRcpCmpPairInqResult_struct&);
       rmsRcpCmpPairInqResult_struct& operator=(const rmsRcpCmpPairInqResult_struct&);
       static CORBA::Info<rmsRcpCmpPairInqResult_struct> rmsRcpCmpPairInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpPairInqResult_struct


typedef rmsRcpCmpPairInqResult_struct* rmsRcpCmpPairInqResult_struct_vPtr;
typedef const rmsRcpCmpPairInqResult_struct* rmsRcpCmpPairInqResult_struct_cvPtr;

class  rmsRcpCmpPairInqResult_struct_var
{
    public:

    rmsRcpCmpPairInqResult_struct_var ();

    rmsRcpCmpPairInqResult_struct_var (rmsRcpCmpPairInqResult_struct *_p);

    rmsRcpCmpPairInqResult_struct_var (const rmsRcpCmpPairInqResult_struct_var &_s);

    rmsRcpCmpPairInqResult_struct_var &operator= (rmsRcpCmpPairInqResult_struct *_p);

    rmsRcpCmpPairInqResult_struct_var &operator= (const rmsRcpCmpPairInqResult_struct_var &_s);

    ~rmsRcpCmpPairInqResult_struct_var ();

    rmsRcpCmpPairInqResult_struct* operator-> ();

    const rmsRcpCmpPairInqResult_struct& in() const;
    rmsRcpCmpPairInqResult_struct& inout();
    rmsRcpCmpPairInqResult_struct*& out();
    rmsRcpCmpPairInqResult_struct* _retn();

    operator rmsRcpCmpPairInqResult_struct_cvPtr () const;

    operator rmsRcpCmpPairInqResult_struct_vPtr& ();

    operator const rmsRcpCmpPairInqResult_struct& () const;

    operator rmsRcpCmpPairInqResult_struct& ();

    protected:
    rmsRcpCmpPairInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairInqResult_struct;
    typedef rmsRcpCmpPairInqResult_struct rmsRcpCmpPairInqResult;
    typedef rmsRcpCmpPairInqResult_struct_var rmsRcpCmpPairInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairInqResult;
    class  rmsRcpCmpPairNoInqResult_struct_var;
    struct  rmsRcpCmpPairNoInqResult_struct {
        typedef rmsRcpCmpPairNoInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Long no;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpPairNoInqResult_struct();
       rmsRcpCmpPairNoInqResult_struct(const rmsRcpCmpPairNoInqResult_struct&);
       rmsRcpCmpPairNoInqResult_struct& operator=(const rmsRcpCmpPairNoInqResult_struct&);
       static CORBA::Info<rmsRcpCmpPairNoInqResult_struct> rmsRcpCmpPairNoInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpPairNoInqResult_struct


typedef rmsRcpCmpPairNoInqResult_struct* rmsRcpCmpPairNoInqResult_struct_vPtr;
typedef const rmsRcpCmpPairNoInqResult_struct* rmsRcpCmpPairNoInqResult_struct_cvPtr;

class  rmsRcpCmpPairNoInqResult_struct_var
{
    public:

    rmsRcpCmpPairNoInqResult_struct_var ();

    rmsRcpCmpPairNoInqResult_struct_var (rmsRcpCmpPairNoInqResult_struct *_p);

    rmsRcpCmpPairNoInqResult_struct_var (const rmsRcpCmpPairNoInqResult_struct_var &_s);

    rmsRcpCmpPairNoInqResult_struct_var &operator= (rmsRcpCmpPairNoInqResult_struct *_p);

    rmsRcpCmpPairNoInqResult_struct_var &operator= (const rmsRcpCmpPairNoInqResult_struct_var &_s);

    ~rmsRcpCmpPairNoInqResult_struct_var ();

    rmsRcpCmpPairNoInqResult_struct* operator-> ();

    const rmsRcpCmpPairNoInqResult_struct& in() const;
    rmsRcpCmpPairNoInqResult_struct& inout();
    rmsRcpCmpPairNoInqResult_struct*& out();
    rmsRcpCmpPairNoInqResult_struct* _retn();

    operator rmsRcpCmpPairNoInqResult_struct_cvPtr () const;

    operator rmsRcpCmpPairNoInqResult_struct_vPtr& ();

    operator const rmsRcpCmpPairNoInqResult_struct& () const;

    operator rmsRcpCmpPairNoInqResult_struct& ();

    protected:
    rmsRcpCmpPairNoInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairNoInqResult_struct;
    typedef rmsRcpCmpPairNoInqResult_struct rmsRcpCmpPairNoInqResult;
    typedef rmsRcpCmpPairNoInqResult_struct_var rmsRcpCmpPairNoInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairNoInqResult;
    class  rmsRcpCmpPairAddReqResult_struct_var;
    struct  rmsRcpCmpPairAddReqResult_struct {
        typedef rmsRcpCmpPairAddReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpPairAddReqResult_struct();
       rmsRcpCmpPairAddReqResult_struct(const rmsRcpCmpPairAddReqResult_struct&);
       rmsRcpCmpPairAddReqResult_struct& operator=(const rmsRcpCmpPairAddReqResult_struct&);
       static CORBA::Info<rmsRcpCmpPairAddReqResult_struct> rmsRcpCmpPairAddReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpPairAddReqResult_struct


typedef rmsRcpCmpPairAddReqResult_struct* rmsRcpCmpPairAddReqResult_struct_vPtr;
typedef const rmsRcpCmpPairAddReqResult_struct* rmsRcpCmpPairAddReqResult_struct_cvPtr;

class  rmsRcpCmpPairAddReqResult_struct_var
{
    public:

    rmsRcpCmpPairAddReqResult_struct_var ();

    rmsRcpCmpPairAddReqResult_struct_var (rmsRcpCmpPairAddReqResult_struct *_p);

    rmsRcpCmpPairAddReqResult_struct_var (const rmsRcpCmpPairAddReqResult_struct_var &_s);

    rmsRcpCmpPairAddReqResult_struct_var &operator= (rmsRcpCmpPairAddReqResult_struct *_p);

    rmsRcpCmpPairAddReqResult_struct_var &operator= (const rmsRcpCmpPairAddReqResult_struct_var &_s);

    ~rmsRcpCmpPairAddReqResult_struct_var ();

    rmsRcpCmpPairAddReqResult_struct* operator-> ();

    const rmsRcpCmpPairAddReqResult_struct& in() const;
    rmsRcpCmpPairAddReqResult_struct& inout();
    rmsRcpCmpPairAddReqResult_struct*& out();
    rmsRcpCmpPairAddReqResult_struct* _retn();

    operator rmsRcpCmpPairAddReqResult_struct_cvPtr () const;

    operator rmsRcpCmpPairAddReqResult_struct_vPtr& ();

    operator const rmsRcpCmpPairAddReqResult_struct& () const;

    operator rmsRcpCmpPairAddReqResult_struct& ();

    protected:
    rmsRcpCmpPairAddReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairAddReqResult_struct;
    typedef rmsRcpCmpPairAddReqResult_struct rmsRcpCmpPairAddReqResult;
    typedef rmsRcpCmpPairAddReqResult_struct_var rmsRcpCmpPairAddReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairAddReqResult;
    class  rmsRcpCmpPairUpdateReqResult_struct_var;
    struct  rmsRcpCmpPairUpdateReqResult_struct {
        typedef rmsRcpCmpPairUpdateReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpPairUpdateReqResult_struct();
       rmsRcpCmpPairUpdateReqResult_struct(const rmsRcpCmpPairUpdateReqResult_struct&);
       rmsRcpCmpPairUpdateReqResult_struct& operator=(const rmsRcpCmpPairUpdateReqResult_struct&);
       static CORBA::Info<rmsRcpCmpPairUpdateReqResult_struct> rmsRcpCmpPairUpdateReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpPairUpdateReqResult_struct


typedef rmsRcpCmpPairUpdateReqResult_struct* rmsRcpCmpPairUpdateReqResult_struct_vPtr;
typedef const rmsRcpCmpPairUpdateReqResult_struct* rmsRcpCmpPairUpdateReqResult_struct_cvPtr;

class  rmsRcpCmpPairUpdateReqResult_struct_var
{
    public:

    rmsRcpCmpPairUpdateReqResult_struct_var ();

    rmsRcpCmpPairUpdateReqResult_struct_var (rmsRcpCmpPairUpdateReqResult_struct *_p);

    rmsRcpCmpPairUpdateReqResult_struct_var (const rmsRcpCmpPairUpdateReqResult_struct_var &_s);

    rmsRcpCmpPairUpdateReqResult_struct_var &operator= (rmsRcpCmpPairUpdateReqResult_struct *_p);

    rmsRcpCmpPairUpdateReqResult_struct_var &operator= (const rmsRcpCmpPairUpdateReqResult_struct_var &_s);

    ~rmsRcpCmpPairUpdateReqResult_struct_var ();

    rmsRcpCmpPairUpdateReqResult_struct* operator-> ();

    const rmsRcpCmpPairUpdateReqResult_struct& in() const;
    rmsRcpCmpPairUpdateReqResult_struct& inout();
    rmsRcpCmpPairUpdateReqResult_struct*& out();
    rmsRcpCmpPairUpdateReqResult_struct* _retn();

    operator rmsRcpCmpPairUpdateReqResult_struct_cvPtr () const;

    operator rmsRcpCmpPairUpdateReqResult_struct_vPtr& ();

    operator const rmsRcpCmpPairUpdateReqResult_struct& () const;

    operator rmsRcpCmpPairUpdateReqResult_struct& ();

    protected:
    rmsRcpCmpPairUpdateReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairUpdateReqResult_struct;
    typedef rmsRcpCmpPairUpdateReqResult_struct rmsRcpCmpPairUpdateReqResult;
    typedef rmsRcpCmpPairUpdateReqResult_struct_var rmsRcpCmpPairUpdateReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairUpdateReqResult;
    class  rmsRcpCmpPairList_struct_var;
    struct  rmsRcpCmpPairList_struct {
        typedef rmsRcpCmpPairList_struct_var _var_type;
       ::CORBA::String_StructElem userID;
       ::CORBA::String_StructElem batchName;
       ::CORBA::Long no;
       ::rmsRcpCmpDataSeq rcpCmpInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpPairList_struct();
       rmsRcpCmpPairList_struct(const rmsRcpCmpPairList_struct&);
       rmsRcpCmpPairList_struct& operator=(const rmsRcpCmpPairList_struct&);
       static CORBA::Info<rmsRcpCmpPairList_struct> rmsRcpCmpPairList_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpPairList_struct


typedef rmsRcpCmpPairList_struct* rmsRcpCmpPairList_struct_vPtr;
typedef const rmsRcpCmpPairList_struct* rmsRcpCmpPairList_struct_cvPtr;

class  rmsRcpCmpPairList_struct_var
{
    public:

    rmsRcpCmpPairList_struct_var ();

    rmsRcpCmpPairList_struct_var (rmsRcpCmpPairList_struct *_p);

    rmsRcpCmpPairList_struct_var (const rmsRcpCmpPairList_struct_var &_s);

    rmsRcpCmpPairList_struct_var &operator= (rmsRcpCmpPairList_struct *_p);

    rmsRcpCmpPairList_struct_var &operator= (const rmsRcpCmpPairList_struct_var &_s);

    ~rmsRcpCmpPairList_struct_var ();

    rmsRcpCmpPairList_struct* operator-> ();

    const rmsRcpCmpPairList_struct& in() const;
    rmsRcpCmpPairList_struct& inout();
    rmsRcpCmpPairList_struct*& out();
    rmsRcpCmpPairList_struct* _retn();

    operator rmsRcpCmpPairList_struct_cvPtr () const;

    operator rmsRcpCmpPairList_struct_vPtr& ();

    operator const rmsRcpCmpPairList_struct& () const;

    operator rmsRcpCmpPairList_struct& ();

    protected:
    rmsRcpCmpPairList_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairList_struct;
    typedef rmsRcpCmpPairList_struct rmsRcpCmpPairList;
    typedef rmsRcpCmpPairList_struct_var rmsRcpCmpPairList_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairList;
class  _IDL_SEQ_rmsRcpCmpPairListSeq_0_var;
class  _IDL_SEQ_rmsRcpCmpPairListSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpCmpPairListSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpCmpPairList *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpCmpPairListSeq_0 ();
    _IDL_SEQ_rmsRcpCmpPairListSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpCmpPairListSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpPairList* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpCmpPairListSeq_0 (const _IDL_SEQ_rmsRcpCmpPairListSeq_0&);

    ~_IDL_SEQ_rmsRcpCmpPairListSeq_0 ();

    _IDL_SEQ_rmsRcpCmpPairListSeq_0& operator= (const _IDL_SEQ_rmsRcpCmpPairListSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpCmpPairList& operator [] (::CORBA::ULong indx);
    const rmsRcpCmpPairList& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpCmpPairList* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpCmpPairList* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpCmpPairList* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpPairList* src, rmsRcpCmpPairList* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpCmpPairList* data); 
  public:

    static rmsRcpCmpPairList* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpCmpPairList* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpCmpPairList* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpCmpPairListSeq_0> rmsRcpCmpPairListSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpCmpPairListSeq_0* _IDL_SEQ_rmsRcpCmpPairListSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpCmpPairListSeq_0* _IDL_SEQ_rmsRcpCmpPairListSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpCmpPairListSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpCmpPairListSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpPairListSeq_0_var (_IDL_SEQ_rmsRcpCmpPairListSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpPairListSeq_0_var (const _IDL_SEQ_rmsRcpCmpPairListSeq_0_var &_s);

    _IDL_SEQ_rmsRcpCmpPairListSeq_0_var &operator= (_IDL_SEQ_rmsRcpCmpPairListSeq_0 *_p);

    _IDL_SEQ_rmsRcpCmpPairListSeq_0_var &operator= (const _IDL_SEQ_rmsRcpCmpPairListSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpCmpPairListSeq_0_var ();

    _IDL_SEQ_rmsRcpCmpPairListSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpCmpPairListSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpCmpPairListSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpCmpPairListSeq_0() const;

    const rmsRcpCmpPairList& operator[] (::CORBA::ULong index) const;
    rmsRcpCmpPairList& operator[] (::CORBA::ULong index);
    const rmsRcpCmpPairList& operator[] (int index) const;
    rmsRcpCmpPairList& operator[] (int index);
    const _IDL_SEQ_rmsRcpCmpPairListSeq_0& in() const;
    _IDL_SEQ_rmsRcpCmpPairListSeq_0& inout();
    _IDL_SEQ_rmsRcpCmpPairListSeq_0*& out();
    _IDL_SEQ_rmsRcpCmpPairListSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpCmpPairListSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpCmpPairListSeq_0 _rmsRcpCmpPairListSeq_seq;
    typedef _IDL_SEQ_rmsRcpCmpPairListSeq_0 _rmsRcpCmpPairListSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpCmpPairListSeq_0 rmsRcpCmpPairListSeq;
    typedef _IDL_SEQ_rmsRcpCmpPairListSeq_0_var rmsRcpCmpPairListSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpPairListSeq;
    class  rmsRcpCmpResultInqResult_struct_var;
    struct  rmsRcpCmpResultInqResult_struct {
        typedef rmsRcpCmpResultInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpCmpPairListSeq rcpCmpPairListInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpResultInqResult_struct();
       rmsRcpCmpResultInqResult_struct(const rmsRcpCmpResultInqResult_struct&);
       rmsRcpCmpResultInqResult_struct& operator=(const rmsRcpCmpResultInqResult_struct&);
       static CORBA::Info<rmsRcpCmpResultInqResult_struct> rmsRcpCmpResultInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpResultInqResult_struct


typedef rmsRcpCmpResultInqResult_struct* rmsRcpCmpResultInqResult_struct_vPtr;
typedef const rmsRcpCmpResultInqResult_struct* rmsRcpCmpResultInqResult_struct_cvPtr;

class  rmsRcpCmpResultInqResult_struct_var
{
    public:

    rmsRcpCmpResultInqResult_struct_var ();

    rmsRcpCmpResultInqResult_struct_var (rmsRcpCmpResultInqResult_struct *_p);

    rmsRcpCmpResultInqResult_struct_var (const rmsRcpCmpResultInqResult_struct_var &_s);

    rmsRcpCmpResultInqResult_struct_var &operator= (rmsRcpCmpResultInqResult_struct *_p);

    rmsRcpCmpResultInqResult_struct_var &operator= (const rmsRcpCmpResultInqResult_struct_var &_s);

    ~rmsRcpCmpResultInqResult_struct_var ();

    rmsRcpCmpResultInqResult_struct* operator-> ();

    const rmsRcpCmpResultInqResult_struct& in() const;
    rmsRcpCmpResultInqResult_struct& inout();
    rmsRcpCmpResultInqResult_struct*& out();
    rmsRcpCmpResultInqResult_struct* _retn();

    operator rmsRcpCmpResultInqResult_struct_cvPtr () const;

    operator rmsRcpCmpResultInqResult_struct_vPtr& ();

    operator const rmsRcpCmpResultInqResult_struct& () const;

    operator rmsRcpCmpResultInqResult_struct& ();

    protected:
    rmsRcpCmpResultInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpResultInqResult_struct;
    typedef rmsRcpCmpResultInqResult_struct rmsRcpCmpResultInqResult;
    typedef rmsRcpCmpResultInqResult_struct_var rmsRcpCmpResultInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpResultInqResult;
    class  rmsRcpCmpSaveReqResult_struct_var;
    struct  rmsRcpCmpSaveReqResult_struct {
        typedef rmsRcpCmpSaveReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpCmpPairListSeq rcpCmpPairListInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpCmpSaveReqResult_struct();
       rmsRcpCmpSaveReqResult_struct(const rmsRcpCmpSaveReqResult_struct&);
       rmsRcpCmpSaveReqResult_struct& operator=(const rmsRcpCmpSaveReqResult_struct&);
       static CORBA::Info<rmsRcpCmpSaveReqResult_struct> rmsRcpCmpSaveReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpCmpSaveReqResult_struct


typedef rmsRcpCmpSaveReqResult_struct* rmsRcpCmpSaveReqResult_struct_vPtr;
typedef const rmsRcpCmpSaveReqResult_struct* rmsRcpCmpSaveReqResult_struct_cvPtr;

class  rmsRcpCmpSaveReqResult_struct_var
{
    public:

    rmsRcpCmpSaveReqResult_struct_var ();

    rmsRcpCmpSaveReqResult_struct_var (rmsRcpCmpSaveReqResult_struct *_p);

    rmsRcpCmpSaveReqResult_struct_var (const rmsRcpCmpSaveReqResult_struct_var &_s);

    rmsRcpCmpSaveReqResult_struct_var &operator= (rmsRcpCmpSaveReqResult_struct *_p);

    rmsRcpCmpSaveReqResult_struct_var &operator= (const rmsRcpCmpSaveReqResult_struct_var &_s);

    ~rmsRcpCmpSaveReqResult_struct_var ();

    rmsRcpCmpSaveReqResult_struct* operator-> ();

    const rmsRcpCmpSaveReqResult_struct& in() const;
    rmsRcpCmpSaveReqResult_struct& inout();
    rmsRcpCmpSaveReqResult_struct*& out();
    rmsRcpCmpSaveReqResult_struct* _retn();

    operator rmsRcpCmpSaveReqResult_struct_cvPtr () const;

    operator rmsRcpCmpSaveReqResult_struct_vPtr& ();

    operator const rmsRcpCmpSaveReqResult_struct& () const;

    operator rmsRcpCmpSaveReqResult_struct& ();

    protected:
    rmsRcpCmpSaveReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpSaveReqResult_struct;
    typedef rmsRcpCmpSaveReqResult_struct rmsRcpCmpSaveReqResult;
    typedef rmsRcpCmpSaveReqResult_struct_var rmsRcpCmpSaveReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpCmpSaveReqResult;
    class  rmsRcpBatchCnt_struct_var;
    struct  rmsRcpBatchCnt_struct {
        typedef rmsRcpBatchCnt_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeId;
       ::CORBA::Long recipeLevel;
       ::CORBA::Long batchauditcnt;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpBatchCnt_struct();
       rmsRcpBatchCnt_struct(const rmsRcpBatchCnt_struct&);
       rmsRcpBatchCnt_struct& operator=(const rmsRcpBatchCnt_struct&);
       static CORBA::Info<rmsRcpBatchCnt_struct> rmsRcpBatchCnt_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpBatchCnt_struct


typedef rmsRcpBatchCnt_struct* rmsRcpBatchCnt_struct_vPtr;
typedef const rmsRcpBatchCnt_struct* rmsRcpBatchCnt_struct_cvPtr;

class  rmsRcpBatchCnt_struct_var
{
    public:

    rmsRcpBatchCnt_struct_var ();

    rmsRcpBatchCnt_struct_var (rmsRcpBatchCnt_struct *_p);

    rmsRcpBatchCnt_struct_var (const rmsRcpBatchCnt_struct_var &_s);

    rmsRcpBatchCnt_struct_var &operator= (rmsRcpBatchCnt_struct *_p);

    rmsRcpBatchCnt_struct_var &operator= (const rmsRcpBatchCnt_struct_var &_s);

    ~rmsRcpBatchCnt_struct_var ();

    rmsRcpBatchCnt_struct* operator-> ();

    const rmsRcpBatchCnt_struct& in() const;
    rmsRcpBatchCnt_struct& inout();
    rmsRcpBatchCnt_struct*& out();
    rmsRcpBatchCnt_struct* _retn();

    operator rmsRcpBatchCnt_struct_cvPtr () const;

    operator rmsRcpBatchCnt_struct_vPtr& ();

    operator const rmsRcpBatchCnt_struct& () const;

    operator rmsRcpBatchCnt_struct& ();

    protected:
    rmsRcpBatchCnt_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatchCnt_struct;
    typedef rmsRcpBatchCnt_struct rmsRcpBatchCnt;
    typedef rmsRcpBatchCnt_struct_var rmsRcpBatchCnt_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatchCnt;
class  _IDL_SEQ_rmsRcpBatchCntSeq_0_var;
class  _IDL_SEQ_rmsRcpBatchCntSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpBatchCntSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpBatchCnt *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpBatchCntSeq_0 ();
    _IDL_SEQ_rmsRcpBatchCntSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpBatchCntSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpBatchCnt* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpBatchCntSeq_0 (const _IDL_SEQ_rmsRcpBatchCntSeq_0&);

    ~_IDL_SEQ_rmsRcpBatchCntSeq_0 ();

    _IDL_SEQ_rmsRcpBatchCntSeq_0& operator= (const _IDL_SEQ_rmsRcpBatchCntSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpBatchCnt& operator [] (::CORBA::ULong indx);
    const rmsRcpBatchCnt& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpBatchCnt* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpBatchCnt* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpBatchCnt* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpBatchCnt* src, rmsRcpBatchCnt* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpBatchCnt* data); 
  public:

    static rmsRcpBatchCnt* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpBatchCnt* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpBatchCnt* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpBatchCntSeq_0> rmsRcpBatchCntSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpBatchCntSeq_0* _IDL_SEQ_rmsRcpBatchCntSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpBatchCntSeq_0* _IDL_SEQ_rmsRcpBatchCntSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpBatchCntSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpBatchCntSeq_0_var ();

    _IDL_SEQ_rmsRcpBatchCntSeq_0_var (_IDL_SEQ_rmsRcpBatchCntSeq_0 *_p);

    _IDL_SEQ_rmsRcpBatchCntSeq_0_var (const _IDL_SEQ_rmsRcpBatchCntSeq_0_var &_s);

    _IDL_SEQ_rmsRcpBatchCntSeq_0_var &operator= (_IDL_SEQ_rmsRcpBatchCntSeq_0 *_p);

    _IDL_SEQ_rmsRcpBatchCntSeq_0_var &operator= (const _IDL_SEQ_rmsRcpBatchCntSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpBatchCntSeq_0_var ();

    _IDL_SEQ_rmsRcpBatchCntSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpBatchCntSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpBatchCntSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpBatchCntSeq_0() const;

    const rmsRcpBatchCnt& operator[] (::CORBA::ULong index) const;
    rmsRcpBatchCnt& operator[] (::CORBA::ULong index);
    const rmsRcpBatchCnt& operator[] (int index) const;
    rmsRcpBatchCnt& operator[] (int index);
    const _IDL_SEQ_rmsRcpBatchCntSeq_0& in() const;
    _IDL_SEQ_rmsRcpBatchCntSeq_0& inout();
    _IDL_SEQ_rmsRcpBatchCntSeq_0*& out();
    _IDL_SEQ_rmsRcpBatchCntSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpBatchCntSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpBatchCntSeq_0 _rmsRcpBatchCntSeq_seq;
    typedef _IDL_SEQ_rmsRcpBatchCntSeq_0 _rmsRcpBatchCntSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpBatchCntSeq_0 rmsRcpBatchCntSeq;
    typedef _IDL_SEQ_rmsRcpBatchCntSeq_0_var rmsRcpBatchCntSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatchCntSeq;
    class  rmsRcpBatchCntInqResult_struct_var;
    struct  rmsRcpBatchCntInqResult_struct {
        typedef rmsRcpBatchCntInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpBatchCntSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpBatchCntInqResult_struct();
       rmsRcpBatchCntInqResult_struct(const rmsRcpBatchCntInqResult_struct&);
       rmsRcpBatchCntInqResult_struct& operator=(const rmsRcpBatchCntInqResult_struct&);
       static CORBA::Info<rmsRcpBatchCntInqResult_struct> rmsRcpBatchCntInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpBatchCntInqResult_struct


typedef rmsRcpBatchCntInqResult_struct* rmsRcpBatchCntInqResult_struct_vPtr;
typedef const rmsRcpBatchCntInqResult_struct* rmsRcpBatchCntInqResult_struct_cvPtr;

class  rmsRcpBatchCntInqResult_struct_var
{
    public:

    rmsRcpBatchCntInqResult_struct_var ();

    rmsRcpBatchCntInqResult_struct_var (rmsRcpBatchCntInqResult_struct *_p);

    rmsRcpBatchCntInqResult_struct_var (const rmsRcpBatchCntInqResult_struct_var &_s);

    rmsRcpBatchCntInqResult_struct_var &operator= (rmsRcpBatchCntInqResult_struct *_p);

    rmsRcpBatchCntInqResult_struct_var &operator= (const rmsRcpBatchCntInqResult_struct_var &_s);

    ~rmsRcpBatchCntInqResult_struct_var ();

    rmsRcpBatchCntInqResult_struct* operator-> ();

    const rmsRcpBatchCntInqResult_struct& in() const;
    rmsRcpBatchCntInqResult_struct& inout();
    rmsRcpBatchCntInqResult_struct*& out();
    rmsRcpBatchCntInqResult_struct* _retn();

    operator rmsRcpBatchCntInqResult_struct_cvPtr () const;

    operator rmsRcpBatchCntInqResult_struct_vPtr& ();

    operator const rmsRcpBatchCntInqResult_struct& () const;

    operator rmsRcpBatchCntInqResult_struct& ();

    protected:
    rmsRcpBatchCntInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatchCntInqResult_struct;
    typedef rmsRcpBatchCntInqResult_struct rmsRcpBatchCntInqResult;
    typedef rmsRcpBatchCntInqResult_struct_var rmsRcpBatchCntInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpBatchCntInqResult;
    class  rmsRcpAFI_struct_var;
    struct  rmsRcpAFI_struct {
        typedef rmsRcpAFI_struct_var _var_type;
       ::CORBA::String_StructElem eqpId;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem mrrecipeId;
       ::CORBA::String_StructElem recipeId;
       ::CORBA::Long recipeLevel;
       ::CORBA::String_StructElem createTime;
       ::CORBA::String_StructElem result;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpAFI_struct();
       rmsRcpAFI_struct(const rmsRcpAFI_struct&);
       rmsRcpAFI_struct& operator=(const rmsRcpAFI_struct&);
       static CORBA::Info<rmsRcpAFI_struct> rmsRcpAFI_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpAFI_struct


typedef rmsRcpAFI_struct* rmsRcpAFI_struct_vPtr;
typedef const rmsRcpAFI_struct* rmsRcpAFI_struct_cvPtr;

class  rmsRcpAFI_struct_var
{
    public:

    rmsRcpAFI_struct_var ();

    rmsRcpAFI_struct_var (rmsRcpAFI_struct *_p);

    rmsRcpAFI_struct_var (const rmsRcpAFI_struct_var &_s);

    rmsRcpAFI_struct_var &operator= (rmsRcpAFI_struct *_p);

    rmsRcpAFI_struct_var &operator= (const rmsRcpAFI_struct_var &_s);

    ~rmsRcpAFI_struct_var ();

    rmsRcpAFI_struct* operator-> ();

    const rmsRcpAFI_struct& in() const;
    rmsRcpAFI_struct& inout();
    rmsRcpAFI_struct*& out();
    rmsRcpAFI_struct* _retn();

    operator rmsRcpAFI_struct_cvPtr () const;

    operator rmsRcpAFI_struct_vPtr& ();

    operator const rmsRcpAFI_struct& () const;

    operator rmsRcpAFI_struct& ();

    protected:
    rmsRcpAFI_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpAFI_struct;
    typedef rmsRcpAFI_struct rmsRcpAFI;
    typedef rmsRcpAFI_struct_var rmsRcpAFI_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpAFI;
class  _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var;
class  _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpAFI *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 ();
    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpAFI* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 (const _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0&);

    ~_IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 ();

    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0& operator= (const _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpAFI& operator [] (::CORBA::ULong indx);
    const rmsRcpAFI& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpAFI* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpAFI* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpAFI* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpAFI* src, rmsRcpAFI* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpAFI* data); 
  public:

    static rmsRcpAFI* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpAFI* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpAFI* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0> rmsRcpAuditFailInhibitJobSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0* _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0* _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var ();

    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var (_IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 *_p);

    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var (const _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var &_s);

    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var &operator= (_IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 *_p);

    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var &operator= (const _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var ();

    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0() const;

    const rmsRcpAFI& operator[] (::CORBA::ULong index) const;
    rmsRcpAFI& operator[] (::CORBA::ULong index);
    const rmsRcpAFI& operator[] (int index) const;
    rmsRcpAFI& operator[] (int index);
    const _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0& in() const;
    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0& inout();
    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0*& out();
    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 _rmsRcpAuditFailInhibitJobSeq_seq;
    typedef _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 _rmsRcpAuditFailInhibitJobSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0 rmsRcpAuditFailInhibitJobSeq;
    typedef _IDL_SEQ_rmsRcpAuditFailInhibitJobSeq_0_var rmsRcpAuditFailInhibitJobSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpAuditFailInhibitJobSeq;
    class  rmsRcpAFIInqResult_struct_var;
    struct  rmsRcpAFIInqResult_struct {
        typedef rmsRcpAFIInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpAuditFailInhibitJobSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpAFIInqResult_struct();
       rmsRcpAFIInqResult_struct(const rmsRcpAFIInqResult_struct&);
       rmsRcpAFIInqResult_struct& operator=(const rmsRcpAFIInqResult_struct&);
       static CORBA::Info<rmsRcpAFIInqResult_struct> rmsRcpAFIInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpAFIInqResult_struct


typedef rmsRcpAFIInqResult_struct* rmsRcpAFIInqResult_struct_vPtr;
typedef const rmsRcpAFIInqResult_struct* rmsRcpAFIInqResult_struct_cvPtr;

class  rmsRcpAFIInqResult_struct_var
{
    public:

    rmsRcpAFIInqResult_struct_var ();

    rmsRcpAFIInqResult_struct_var (rmsRcpAFIInqResult_struct *_p);

    rmsRcpAFIInqResult_struct_var (const rmsRcpAFIInqResult_struct_var &_s);

    rmsRcpAFIInqResult_struct_var &operator= (rmsRcpAFIInqResult_struct *_p);

    rmsRcpAFIInqResult_struct_var &operator= (const rmsRcpAFIInqResult_struct_var &_s);

    ~rmsRcpAFIInqResult_struct_var ();

    rmsRcpAFIInqResult_struct* operator-> ();

    const rmsRcpAFIInqResult_struct& in() const;
    rmsRcpAFIInqResult_struct& inout();
    rmsRcpAFIInqResult_struct*& out();
    rmsRcpAFIInqResult_struct* _retn();

    operator rmsRcpAFIInqResult_struct_cvPtr () const;

    operator rmsRcpAFIInqResult_struct_vPtr& ();

    operator const rmsRcpAFIInqResult_struct& () const;

    operator rmsRcpAFIInqResult_struct& ();

    protected:
    rmsRcpAFIInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpAFIInqResult_struct;
    typedef rmsRcpAFIInqResult_struct rmsRcpAFIInqResult;
    typedef rmsRcpAFIInqResult_struct_var rmsRcpAFIInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpAFIInqResult;
    class  rmsRcpChgAuditInfo_struct_var;
    struct  rmsRcpChgAuditInfo_struct {
        typedef rmsRcpChgAuditInfo_struct_var _var_type;
       ::CORBA::String_StructElem eqpID;
       ::CORBA::String_StructElem subEqpID;
       ::CORBA::String_StructElem recipeID;
       ::CORBA::String_StructElem createtime;
       ::CORBA::String_StructElem modifier;
       ::CORBA::String_StructElem status;
       ::CORBA::String_StructElem eventprocesstime;
       ::CORBA::String_StructElem result;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpChgAuditInfo_struct();
       rmsRcpChgAuditInfo_struct(const rmsRcpChgAuditInfo_struct&);
       rmsRcpChgAuditInfo_struct& operator=(const rmsRcpChgAuditInfo_struct&);
       static CORBA::Info<rmsRcpChgAuditInfo_struct> rmsRcpChgAuditInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpChgAuditInfo_struct


typedef rmsRcpChgAuditInfo_struct* rmsRcpChgAuditInfo_struct_vPtr;
typedef const rmsRcpChgAuditInfo_struct* rmsRcpChgAuditInfo_struct_cvPtr;

class  rmsRcpChgAuditInfo_struct_var
{
    public:

    rmsRcpChgAuditInfo_struct_var ();

    rmsRcpChgAuditInfo_struct_var (rmsRcpChgAuditInfo_struct *_p);

    rmsRcpChgAuditInfo_struct_var (const rmsRcpChgAuditInfo_struct_var &_s);

    rmsRcpChgAuditInfo_struct_var &operator= (rmsRcpChgAuditInfo_struct *_p);

    rmsRcpChgAuditInfo_struct_var &operator= (const rmsRcpChgAuditInfo_struct_var &_s);

    ~rmsRcpChgAuditInfo_struct_var ();

    rmsRcpChgAuditInfo_struct* operator-> ();

    const rmsRcpChgAuditInfo_struct& in() const;
    rmsRcpChgAuditInfo_struct& inout();
    rmsRcpChgAuditInfo_struct*& out();
    rmsRcpChgAuditInfo_struct* _retn();

    operator rmsRcpChgAuditInfo_struct_cvPtr () const;

    operator rmsRcpChgAuditInfo_struct_vPtr& ();

    operator const rmsRcpChgAuditInfo_struct& () const;

    operator rmsRcpChgAuditInfo_struct& ();

    protected:
    rmsRcpChgAuditInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpChgAuditInfo_struct;
    typedef rmsRcpChgAuditInfo_struct rmsRcpChgAuditInfo;
    typedef rmsRcpChgAuditInfo_struct_var rmsRcpChgAuditInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpChgAuditInfo;
class  _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var;
class  _IDL_SEQ_rmsRcpChgAuditResultSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpChgAuditInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpChgAuditResultSeq_0 ();
    _IDL_SEQ_rmsRcpChgAuditResultSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpChgAuditResultSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpChgAuditInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpChgAuditResultSeq_0 (const _IDL_SEQ_rmsRcpChgAuditResultSeq_0&);

    ~_IDL_SEQ_rmsRcpChgAuditResultSeq_0 ();

    _IDL_SEQ_rmsRcpChgAuditResultSeq_0& operator= (const _IDL_SEQ_rmsRcpChgAuditResultSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpChgAuditInfo& operator [] (::CORBA::ULong indx);
    const rmsRcpChgAuditInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpChgAuditInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpChgAuditInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpChgAuditInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpChgAuditInfo* src, rmsRcpChgAuditInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpChgAuditInfo* data); 
  public:

    static rmsRcpChgAuditInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpChgAuditInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpChgAuditInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpChgAuditResultSeq_0> rmsRcpChgAuditResultSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpChgAuditResultSeq_0* _IDL_SEQ_rmsRcpChgAuditResultSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpChgAuditResultSeq_0* _IDL_SEQ_rmsRcpChgAuditResultSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var ();

    _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var (_IDL_SEQ_rmsRcpChgAuditResultSeq_0 *_p);

    _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var (const _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var &_s);

    _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var &operator= (_IDL_SEQ_rmsRcpChgAuditResultSeq_0 *_p);

    _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var &operator= (const _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpChgAuditResultSeq_0_var ();

    _IDL_SEQ_rmsRcpChgAuditResultSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpChgAuditResultSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpChgAuditResultSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpChgAuditResultSeq_0() const;

    const rmsRcpChgAuditInfo& operator[] (::CORBA::ULong index) const;
    rmsRcpChgAuditInfo& operator[] (::CORBA::ULong index);
    const rmsRcpChgAuditInfo& operator[] (int index) const;
    rmsRcpChgAuditInfo& operator[] (int index);
    const _IDL_SEQ_rmsRcpChgAuditResultSeq_0& in() const;
    _IDL_SEQ_rmsRcpChgAuditResultSeq_0& inout();
    _IDL_SEQ_rmsRcpChgAuditResultSeq_0*& out();
    _IDL_SEQ_rmsRcpChgAuditResultSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpChgAuditResultSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpChgAuditResultSeq_0 _rmsRcpChgAuditResultSeq_seq;
    typedef _IDL_SEQ_rmsRcpChgAuditResultSeq_0 _rmsRcpChgAuditResultSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpChgAuditResultSeq_0 rmsRcpChgAuditResultSeq;
    typedef _IDL_SEQ_rmsRcpChgAuditResultSeq_0_var rmsRcpChgAuditResultSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpChgAuditResultSeq;
    class  rmsRcpChgAuditResultInqResult_struct_var;
    struct  rmsRcpChgAuditResultInqResult_struct {
        typedef rmsRcpChgAuditResultInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpChgAuditResultSeq profiles;
       ::CORBA::Boolean overSearchCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpChgAuditResultInqResult_struct();
       rmsRcpChgAuditResultInqResult_struct(const rmsRcpChgAuditResultInqResult_struct&);
       rmsRcpChgAuditResultInqResult_struct& operator=(const rmsRcpChgAuditResultInqResult_struct&);
       static CORBA::Info<rmsRcpChgAuditResultInqResult_struct> rmsRcpChgAuditResultInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpChgAuditResultInqResult_struct


typedef rmsRcpChgAuditResultInqResult_struct* rmsRcpChgAuditResultInqResult_struct_vPtr;
typedef const rmsRcpChgAuditResultInqResult_struct* rmsRcpChgAuditResultInqResult_struct_cvPtr;

class  rmsRcpChgAuditResultInqResult_struct_var
{
    public:

    rmsRcpChgAuditResultInqResult_struct_var ();

    rmsRcpChgAuditResultInqResult_struct_var (rmsRcpChgAuditResultInqResult_struct *_p);

    rmsRcpChgAuditResultInqResult_struct_var (const rmsRcpChgAuditResultInqResult_struct_var &_s);

    rmsRcpChgAuditResultInqResult_struct_var &operator= (rmsRcpChgAuditResultInqResult_struct *_p);

    rmsRcpChgAuditResultInqResult_struct_var &operator= (const rmsRcpChgAuditResultInqResult_struct_var &_s);

    ~rmsRcpChgAuditResultInqResult_struct_var ();

    rmsRcpChgAuditResultInqResult_struct* operator-> ();

    const rmsRcpChgAuditResultInqResult_struct& in() const;
    rmsRcpChgAuditResultInqResult_struct& inout();
    rmsRcpChgAuditResultInqResult_struct*& out();
    rmsRcpChgAuditResultInqResult_struct* _retn();

    operator rmsRcpChgAuditResultInqResult_struct_cvPtr () const;

    operator rmsRcpChgAuditResultInqResult_struct_vPtr& ();

    operator const rmsRcpChgAuditResultInqResult_struct& () const;

    operator rmsRcpChgAuditResultInqResult_struct& ();

    protected:
    rmsRcpChgAuditResultInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpChgAuditResultInqResult_struct;
    typedef rmsRcpChgAuditResultInqResult_struct rmsRcpChgAuditResultInqResult;
    typedef rmsRcpChgAuditResultInqResult_struct_var rmsRcpChgAuditResultInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpChgAuditResultInqResult;
    class  rmsRcpAutoLabelInqInfo_struct_var;
    struct  rmsRcpAutoLabelInqInfo_struct {
        typedef rmsRcpAutoLabelInqInfo_struct_var _var_type;
       ::CORBA::String_StructElem label;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpAutoLabelInqInfo_struct();
       rmsRcpAutoLabelInqInfo_struct(const rmsRcpAutoLabelInqInfo_struct&);
       rmsRcpAutoLabelInqInfo_struct& operator=(const rmsRcpAutoLabelInqInfo_struct&);
       static CORBA::Info<rmsRcpAutoLabelInqInfo_struct> rmsRcpAutoLabelInqInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpAutoLabelInqInfo_struct


typedef rmsRcpAutoLabelInqInfo_struct* rmsRcpAutoLabelInqInfo_struct_vPtr;
typedef const rmsRcpAutoLabelInqInfo_struct* rmsRcpAutoLabelInqInfo_struct_cvPtr;

class  rmsRcpAutoLabelInqInfo_struct_var
{
    public:

    rmsRcpAutoLabelInqInfo_struct_var ();

    rmsRcpAutoLabelInqInfo_struct_var (rmsRcpAutoLabelInqInfo_struct *_p);

    rmsRcpAutoLabelInqInfo_struct_var (const rmsRcpAutoLabelInqInfo_struct_var &_s);

    rmsRcpAutoLabelInqInfo_struct_var &operator= (rmsRcpAutoLabelInqInfo_struct *_p);

    rmsRcpAutoLabelInqInfo_struct_var &operator= (const rmsRcpAutoLabelInqInfo_struct_var &_s);

    ~rmsRcpAutoLabelInqInfo_struct_var ();

    rmsRcpAutoLabelInqInfo_struct* operator-> ();

    const rmsRcpAutoLabelInqInfo_struct& in() const;
    rmsRcpAutoLabelInqInfo_struct& inout();
    rmsRcpAutoLabelInqInfo_struct*& out();
    rmsRcpAutoLabelInqInfo_struct* _retn();

    operator rmsRcpAutoLabelInqInfo_struct_cvPtr () const;

    operator rmsRcpAutoLabelInqInfo_struct_vPtr& ();

    operator const rmsRcpAutoLabelInqInfo_struct& () const;

    operator rmsRcpAutoLabelInqInfo_struct& ();

    protected:
    rmsRcpAutoLabelInqInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpAutoLabelInqInfo_struct;
    typedef rmsRcpAutoLabelInqInfo_struct rmsRcpAutoLabelInqInfo;
    typedef rmsRcpAutoLabelInqInfo_struct_var rmsRcpAutoLabelInqInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpAutoLabelInqInfo;
class  _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var;
class  _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpAutoLabelInqInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 ();
    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpAutoLabelInqInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 (const _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0&);

    ~_IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 ();

    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0& operator= (const _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpAutoLabelInqInfo& operator [] (::CORBA::ULong indx);
    const rmsRcpAutoLabelInqInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpAutoLabelInqInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpAutoLabelInqInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpAutoLabelInqInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpAutoLabelInqInfo* src, rmsRcpAutoLabelInqInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpAutoLabelInqInfo* data); 
  public:

    static rmsRcpAutoLabelInqInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpAutoLabelInqInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpAutoLabelInqInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0> rmsRcpAutoLabelAllInqResultSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0* _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0* _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var ();

    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var (_IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 *_p);

    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var (const _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var &_s);

    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var &operator= (_IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 *_p);

    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var &operator= (const _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var ();

    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0() const;

    const rmsRcpAutoLabelInqInfo& operator[] (::CORBA::ULong index) const;
    rmsRcpAutoLabelInqInfo& operator[] (::CORBA::ULong index);
    const rmsRcpAutoLabelInqInfo& operator[] (int index) const;
    rmsRcpAutoLabelInqInfo& operator[] (int index);
    const _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0& in() const;
    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0& inout();
    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0*& out();
    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 _rmsRcpAutoLabelAllInqResultSeq_seq;
    typedef _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 _rmsRcpAutoLabelAllInqResultSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0 rmsRcpAutoLabelAllInqResultSeq;
    typedef _IDL_SEQ_rmsRcpAutoLabelAllInqResultSeq_0_var rmsRcpAutoLabelAllInqResultSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpAutoLabelAllInqResultSeq;
    class  rmsEqpRecipeAutoLabelAllInqResult_struct_var;
    struct  rmsEqpRecipeAutoLabelAllInqResult_struct {
        typedef rmsEqpRecipeAutoLabelAllInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpAutoLabelAllInqResultSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpRecipeAutoLabelAllInqResult_struct();
       rmsEqpRecipeAutoLabelAllInqResult_struct(const rmsEqpRecipeAutoLabelAllInqResult_struct&);
       rmsEqpRecipeAutoLabelAllInqResult_struct& operator=(const rmsEqpRecipeAutoLabelAllInqResult_struct&);
       static CORBA::Info<rmsEqpRecipeAutoLabelAllInqResult_struct> rmsEqpRecipeAutoLabelAllInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpRecipeAutoLabelAllInqResult_struct


typedef rmsEqpRecipeAutoLabelAllInqResult_struct* rmsEqpRecipeAutoLabelAllInqResult_struct_vPtr;
typedef const rmsEqpRecipeAutoLabelAllInqResult_struct* rmsEqpRecipeAutoLabelAllInqResult_struct_cvPtr;

class  rmsEqpRecipeAutoLabelAllInqResult_struct_var
{
    public:

    rmsEqpRecipeAutoLabelAllInqResult_struct_var ();

    rmsEqpRecipeAutoLabelAllInqResult_struct_var (rmsEqpRecipeAutoLabelAllInqResult_struct *_p);

    rmsEqpRecipeAutoLabelAllInqResult_struct_var (const rmsEqpRecipeAutoLabelAllInqResult_struct_var &_s);

    rmsEqpRecipeAutoLabelAllInqResult_struct_var &operator= (rmsEqpRecipeAutoLabelAllInqResult_struct *_p);

    rmsEqpRecipeAutoLabelAllInqResult_struct_var &operator= (const rmsEqpRecipeAutoLabelAllInqResult_struct_var &_s);

    ~rmsEqpRecipeAutoLabelAllInqResult_struct_var ();

    rmsEqpRecipeAutoLabelAllInqResult_struct* operator-> ();

    const rmsEqpRecipeAutoLabelAllInqResult_struct& in() const;
    rmsEqpRecipeAutoLabelAllInqResult_struct& inout();
    rmsEqpRecipeAutoLabelAllInqResult_struct*& out();
    rmsEqpRecipeAutoLabelAllInqResult_struct* _retn();

    operator rmsEqpRecipeAutoLabelAllInqResult_struct_cvPtr () const;

    operator rmsEqpRecipeAutoLabelAllInqResult_struct_vPtr& ();

    operator const rmsEqpRecipeAutoLabelAllInqResult_struct& () const;

    operator rmsEqpRecipeAutoLabelAllInqResult_struct& ();

    protected:
    rmsEqpRecipeAutoLabelAllInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpRecipeAutoLabelAllInqResult_struct;
    typedef rmsEqpRecipeAutoLabelAllInqResult_struct rmsEqpRecipeAutoLabelAllInqResult;
    typedef rmsEqpRecipeAutoLabelAllInqResult_struct_var rmsEqpRecipeAutoLabelAllInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpRecipeAutoLabelAllInqResult;
    class  rmsRcpLabelRuleInqInfo_struct_var;
    struct  rmsRcpLabelRuleInqInfo_struct {
        typedef rmsRcpLabelRuleInqInfo_struct_var _var_type;
       ::CORBA::String_StructElem eqpID;
       ::CORBA::String_StructElem subEqpID;
       ::CORBA::String_StructElem rcppattern;
       ::CORBA::String_StructElem label;
       ::CORBA::String_StructElem updateuser;
       ::CORBA::String_StructElem updatetime;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpLabelRuleInqInfo_struct();
       rmsRcpLabelRuleInqInfo_struct(const rmsRcpLabelRuleInqInfo_struct&);
       rmsRcpLabelRuleInqInfo_struct& operator=(const rmsRcpLabelRuleInqInfo_struct&);
       static CORBA::Info<rmsRcpLabelRuleInqInfo_struct> rmsRcpLabelRuleInqInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpLabelRuleInqInfo_struct


typedef rmsRcpLabelRuleInqInfo_struct* rmsRcpLabelRuleInqInfo_struct_vPtr;
typedef const rmsRcpLabelRuleInqInfo_struct* rmsRcpLabelRuleInqInfo_struct_cvPtr;

class  rmsRcpLabelRuleInqInfo_struct_var
{
    public:

    rmsRcpLabelRuleInqInfo_struct_var ();

    rmsRcpLabelRuleInqInfo_struct_var (rmsRcpLabelRuleInqInfo_struct *_p);

    rmsRcpLabelRuleInqInfo_struct_var (const rmsRcpLabelRuleInqInfo_struct_var &_s);

    rmsRcpLabelRuleInqInfo_struct_var &operator= (rmsRcpLabelRuleInqInfo_struct *_p);

    rmsRcpLabelRuleInqInfo_struct_var &operator= (const rmsRcpLabelRuleInqInfo_struct_var &_s);

    ~rmsRcpLabelRuleInqInfo_struct_var ();

    rmsRcpLabelRuleInqInfo_struct* operator-> ();

    const rmsRcpLabelRuleInqInfo_struct& in() const;
    rmsRcpLabelRuleInqInfo_struct& inout();
    rmsRcpLabelRuleInqInfo_struct*& out();
    rmsRcpLabelRuleInqInfo_struct* _retn();

    operator rmsRcpLabelRuleInqInfo_struct_cvPtr () const;

    operator rmsRcpLabelRuleInqInfo_struct_vPtr& ();

    operator const rmsRcpLabelRuleInqInfo_struct& () const;

    operator rmsRcpLabelRuleInqInfo_struct& ();

    protected:
    rmsRcpLabelRuleInqInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpLabelRuleInqInfo_struct;
    typedef rmsRcpLabelRuleInqInfo_struct rmsRcpLabelRuleInqInfo;
    typedef rmsRcpLabelRuleInqInfo_struct_var rmsRcpLabelRuleInqInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpLabelRuleInqInfo;
class  _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var;
class  _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpLabelRuleInqInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 ();
    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpLabelRuleInqInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 (const _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0&);

    ~_IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 ();

    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0& operator= (const _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpLabelRuleInqInfo& operator [] (::CORBA::ULong indx);
    const rmsRcpLabelRuleInqInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpLabelRuleInqInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpLabelRuleInqInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpLabelRuleInqInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpLabelRuleInqInfo* src, rmsRcpLabelRuleInqInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpLabelRuleInqInfo* data); 
  public:

    static rmsRcpLabelRuleInqInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpLabelRuleInqInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpLabelRuleInqInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0> rmsRcpLabelRuleInqResultSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0* _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0* _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var ();

    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var (_IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 *_p);

    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var (const _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var &_s);

    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var &operator= (_IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 *_p);

    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var &operator= (const _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var ();

    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0() const;

    const rmsRcpLabelRuleInqInfo& operator[] (::CORBA::ULong index) const;
    rmsRcpLabelRuleInqInfo& operator[] (::CORBA::ULong index);
    const rmsRcpLabelRuleInqInfo& operator[] (int index) const;
    rmsRcpLabelRuleInqInfo& operator[] (int index);
    const _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0& in() const;
    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0& inout();
    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0*& out();
    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 _rmsRcpLabelRuleInqResultSeq_seq;
    typedef _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 _rmsRcpLabelRuleInqResultSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0 rmsRcpLabelRuleInqResultSeq;
    typedef _IDL_SEQ_rmsRcpLabelRuleInqResultSeq_0_var rmsRcpLabelRuleInqResultSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpLabelRuleInqResultSeq;
    class  rmsEqpRcpLabelRuleInqResult_struct_var;
    struct  rmsEqpRcpLabelRuleInqResult_struct {
        typedef rmsEqpRcpLabelRuleInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpLabelRuleInqResultSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsEqpRcpLabelRuleInqResult_struct();
       rmsEqpRcpLabelRuleInqResult_struct(const rmsEqpRcpLabelRuleInqResult_struct&);
       rmsEqpRcpLabelRuleInqResult_struct& operator=(const rmsEqpRcpLabelRuleInqResult_struct&);
       static CORBA::Info<rmsEqpRcpLabelRuleInqResult_struct> rmsEqpRcpLabelRuleInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsEqpRcpLabelRuleInqResult_struct


typedef rmsEqpRcpLabelRuleInqResult_struct* rmsEqpRcpLabelRuleInqResult_struct_vPtr;
typedef const rmsEqpRcpLabelRuleInqResult_struct* rmsEqpRcpLabelRuleInqResult_struct_cvPtr;

class  rmsEqpRcpLabelRuleInqResult_struct_var
{
    public:

    rmsEqpRcpLabelRuleInqResult_struct_var ();

    rmsEqpRcpLabelRuleInqResult_struct_var (rmsEqpRcpLabelRuleInqResult_struct *_p);

    rmsEqpRcpLabelRuleInqResult_struct_var (const rmsEqpRcpLabelRuleInqResult_struct_var &_s);

    rmsEqpRcpLabelRuleInqResult_struct_var &operator= (rmsEqpRcpLabelRuleInqResult_struct *_p);

    rmsEqpRcpLabelRuleInqResult_struct_var &operator= (const rmsEqpRcpLabelRuleInqResult_struct_var &_s);

    ~rmsEqpRcpLabelRuleInqResult_struct_var ();

    rmsEqpRcpLabelRuleInqResult_struct* operator-> ();

    const rmsEqpRcpLabelRuleInqResult_struct& in() const;
    rmsEqpRcpLabelRuleInqResult_struct& inout();
    rmsEqpRcpLabelRuleInqResult_struct*& out();
    rmsEqpRcpLabelRuleInqResult_struct* _retn();

    operator rmsEqpRcpLabelRuleInqResult_struct_cvPtr () const;

    operator rmsEqpRcpLabelRuleInqResult_struct_vPtr& ();

    operator const rmsEqpRcpLabelRuleInqResult_struct& () const;

    operator rmsEqpRcpLabelRuleInqResult_struct& ();

    protected:
    rmsEqpRcpLabelRuleInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpRcpLabelRuleInqResult_struct;
    typedef rmsEqpRcpLabelRuleInqResult_struct rmsEqpRcpLabelRuleInqResult;
    typedef rmsEqpRcpLabelRuleInqResult_struct_var rmsEqpRcpLabelRuleInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsEqpRcpLabelRuleInqResult;
    class  rmsProRcpAuditRuleInfo_struct_var;
    struct  rmsProRcpAuditRuleInfo_struct {
        typedef rmsProRcpAuditRuleInfo_struct_var _var_type;
       ::CORBA::String_StructElem eqpID;
       ::CORBA::String_StructElem subEqpID;
       ::CORBA::String_StructElem rcppattern;
       ::CORBA::Long positive;
       ::CORBA::String_StructElem updateuser;
       ::CORBA::String_StructElem updatetime;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsProRcpAuditRuleInfo_struct();
       rmsProRcpAuditRuleInfo_struct(const rmsProRcpAuditRuleInfo_struct&);
       rmsProRcpAuditRuleInfo_struct& operator=(const rmsProRcpAuditRuleInfo_struct&);
       static CORBA::Info<rmsProRcpAuditRuleInfo_struct> rmsProRcpAuditRuleInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsProRcpAuditRuleInfo_struct


typedef rmsProRcpAuditRuleInfo_struct* rmsProRcpAuditRuleInfo_struct_vPtr;
typedef const rmsProRcpAuditRuleInfo_struct* rmsProRcpAuditRuleInfo_struct_cvPtr;

class  rmsProRcpAuditRuleInfo_struct_var
{
    public:

    rmsProRcpAuditRuleInfo_struct_var ();

    rmsProRcpAuditRuleInfo_struct_var (rmsProRcpAuditRuleInfo_struct *_p);

    rmsProRcpAuditRuleInfo_struct_var (const rmsProRcpAuditRuleInfo_struct_var &_s);

    rmsProRcpAuditRuleInfo_struct_var &operator= (rmsProRcpAuditRuleInfo_struct *_p);

    rmsProRcpAuditRuleInfo_struct_var &operator= (const rmsProRcpAuditRuleInfo_struct_var &_s);

    ~rmsProRcpAuditRuleInfo_struct_var ();

    rmsProRcpAuditRuleInfo_struct* operator-> ();

    const rmsProRcpAuditRuleInfo_struct& in() const;
    rmsProRcpAuditRuleInfo_struct& inout();
    rmsProRcpAuditRuleInfo_struct*& out();
    rmsProRcpAuditRuleInfo_struct* _retn();

    operator rmsProRcpAuditRuleInfo_struct_cvPtr () const;

    operator rmsProRcpAuditRuleInfo_struct_vPtr& ();

    operator const rmsProRcpAuditRuleInfo_struct& () const;

    operator rmsProRcpAuditRuleInfo_struct& ();

    protected:
    rmsProRcpAuditRuleInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsProRcpAuditRuleInfo_struct;
    typedef rmsProRcpAuditRuleInfo_struct rmsProRcpAuditRuleInfo;
    typedef rmsProRcpAuditRuleInfo_struct_var rmsProRcpAuditRuleInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsProRcpAuditRuleInfo;
class  _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var;
class  _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 {
    public:
        typedef _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsProRcpAuditRuleInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 ();
    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsProRcpAuditRuleInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 (const _IDL_SEQ_rmsProdRcpAuditRuleSeq_0&);

    ~_IDL_SEQ_rmsProdRcpAuditRuleSeq_0 ();

    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0& operator= (const _IDL_SEQ_rmsProdRcpAuditRuleSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsProRcpAuditRuleInfo& operator [] (::CORBA::ULong indx);
    const rmsProRcpAuditRuleInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsProRcpAuditRuleInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsProRcpAuditRuleInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsProRcpAuditRuleInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsProRcpAuditRuleInfo* src, rmsProRcpAuditRuleInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsProRcpAuditRuleInfo* data); 
  public:

    static rmsProRcpAuditRuleInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsProRcpAuditRuleInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsProRcpAuditRuleInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsProdRcpAuditRuleSeq_0> rmsProdRcpAuditRuleSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsProdRcpAuditRuleSeq_0* _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_vPtr;
typedef const _IDL_SEQ_rmsProdRcpAuditRuleSeq_0* _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_cvPtr;

class  _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var
{
    public:

    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var ();

    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var (_IDL_SEQ_rmsProdRcpAuditRuleSeq_0 *_p);

    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var (const _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var &_s);

    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var &operator= (_IDL_SEQ_rmsProdRcpAuditRuleSeq_0 *_p);

    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var &operator= (const _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var &_s);

    ~_IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var ();

    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0* operator-> ();

    operator _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsProdRcpAuditRuleSeq_0() const;

    const rmsProRcpAuditRuleInfo& operator[] (::CORBA::ULong index) const;
    rmsProRcpAuditRuleInfo& operator[] (::CORBA::ULong index);
    const rmsProRcpAuditRuleInfo& operator[] (int index) const;
    rmsProRcpAuditRuleInfo& operator[] (int index);
    const _IDL_SEQ_rmsProdRcpAuditRuleSeq_0& in() const;
    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0& inout();
    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0*& out();
    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 _rmsProdRcpAuditRuleSeq_seq;
    typedef _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 _rmsProdRcpAuditRuleSeq_seq_1;
    typedef _IDL_SEQ_rmsProdRcpAuditRuleSeq_0 rmsProdRcpAuditRuleSeq;
    typedef _IDL_SEQ_rmsProdRcpAuditRuleSeq_0_var rmsProdRcpAuditRuleSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsProdRcpAuditRuleSeq;
    class  rmsProRcpAuditRuleInqResult_struct_var;
    struct  rmsProRcpAuditRuleInqResult_struct {
        typedef rmsProRcpAuditRuleInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsProdRcpAuditRuleSeq profiles;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsProRcpAuditRuleInqResult_struct();
       rmsProRcpAuditRuleInqResult_struct(const rmsProRcpAuditRuleInqResult_struct&);
       rmsProRcpAuditRuleInqResult_struct& operator=(const rmsProRcpAuditRuleInqResult_struct&);
       static CORBA::Info<rmsProRcpAuditRuleInqResult_struct> rmsProRcpAuditRuleInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsProRcpAuditRuleInqResult_struct


typedef rmsProRcpAuditRuleInqResult_struct* rmsProRcpAuditRuleInqResult_struct_vPtr;
typedef const rmsProRcpAuditRuleInqResult_struct* rmsProRcpAuditRuleInqResult_struct_cvPtr;

class  rmsProRcpAuditRuleInqResult_struct_var
{
    public:

    rmsProRcpAuditRuleInqResult_struct_var ();

    rmsProRcpAuditRuleInqResult_struct_var (rmsProRcpAuditRuleInqResult_struct *_p);

    rmsProRcpAuditRuleInqResult_struct_var (const rmsProRcpAuditRuleInqResult_struct_var &_s);

    rmsProRcpAuditRuleInqResult_struct_var &operator= (rmsProRcpAuditRuleInqResult_struct *_p);

    rmsProRcpAuditRuleInqResult_struct_var &operator= (const rmsProRcpAuditRuleInqResult_struct_var &_s);

    ~rmsProRcpAuditRuleInqResult_struct_var ();

    rmsProRcpAuditRuleInqResult_struct* operator-> ();

    const rmsProRcpAuditRuleInqResult_struct& in() const;
    rmsProRcpAuditRuleInqResult_struct& inout();
    rmsProRcpAuditRuleInqResult_struct*& out();
    rmsProRcpAuditRuleInqResult_struct* _retn();

    operator rmsProRcpAuditRuleInqResult_struct_cvPtr () const;

    operator rmsProRcpAuditRuleInqResult_struct_vPtr& ();

    operator const rmsProRcpAuditRuleInqResult_struct& () const;

    operator rmsProRcpAuditRuleInqResult_struct& ();

    protected:
    rmsProRcpAuditRuleInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsProRcpAuditRuleInqResult_struct;
    typedef rmsProRcpAuditRuleInqResult_struct rmsProRcpAuditRuleInqResult;
    typedef rmsProRcpAuditRuleInqResult_struct_var rmsProRcpAuditRuleInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsProRcpAuditRuleInqResult;
    class  rmsLoadMapRecipeInfo_struct_var;
    struct  rmsLoadMapRecipeInfo_struct {
        typedef rmsLoadMapRecipeInfo_struct_var _var_type;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem mainRecipeID;
       ::CORBA::String_StructElem mapRecipeID;
       ::CORBA::Long productionCount;
       ::CORBA::Long monitorCount;
       ::CORBA::Long sideDummyCount;
       ::CORBA::Long fillDummyCount;
       ::CORBA::Long extraDummyCount;
       ::CORBA::String_StructElem mapLastUpdateTime;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsLoadMapRecipeInfo_struct();
       rmsLoadMapRecipeInfo_struct(const rmsLoadMapRecipeInfo_struct&);
       rmsLoadMapRecipeInfo_struct& operator=(const rmsLoadMapRecipeInfo_struct&);
       static CORBA::Info<rmsLoadMapRecipeInfo_struct> rmsLoadMapRecipeInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsLoadMapRecipeInfo_struct


typedef rmsLoadMapRecipeInfo_struct* rmsLoadMapRecipeInfo_struct_vPtr;
typedef const rmsLoadMapRecipeInfo_struct* rmsLoadMapRecipeInfo_struct_cvPtr;

class  rmsLoadMapRecipeInfo_struct_var
{
    public:

    rmsLoadMapRecipeInfo_struct_var ();

    rmsLoadMapRecipeInfo_struct_var (rmsLoadMapRecipeInfo_struct *_p);

    rmsLoadMapRecipeInfo_struct_var (const rmsLoadMapRecipeInfo_struct_var &_s);

    rmsLoadMapRecipeInfo_struct_var &operator= (rmsLoadMapRecipeInfo_struct *_p);

    rmsLoadMapRecipeInfo_struct_var &operator= (const rmsLoadMapRecipeInfo_struct_var &_s);

    ~rmsLoadMapRecipeInfo_struct_var ();

    rmsLoadMapRecipeInfo_struct* operator-> ();

    const rmsLoadMapRecipeInfo_struct& in() const;
    rmsLoadMapRecipeInfo_struct& inout();
    rmsLoadMapRecipeInfo_struct*& out();
    rmsLoadMapRecipeInfo_struct* _retn();

    operator rmsLoadMapRecipeInfo_struct_cvPtr () const;

    operator rmsLoadMapRecipeInfo_struct_vPtr& ();

    operator const rmsLoadMapRecipeInfo_struct& () const;

    operator rmsLoadMapRecipeInfo_struct& ();

    protected:
    rmsLoadMapRecipeInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsLoadMapRecipeInfo_struct;
    typedef rmsLoadMapRecipeInfo_struct rmsLoadMapRecipeInfo;
    typedef rmsLoadMapRecipeInfo_struct_var rmsLoadMapRecipeInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLoadMapRecipeInfo;
class  _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var;
class  _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 {
    public:
        typedef _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsLoadMapRecipeInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 ();
    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsLoadMapRecipeInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 (const _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0&);

    ~_IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 ();

    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0& operator= (const _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsLoadMapRecipeInfo& operator [] (::CORBA::ULong indx);
    const rmsLoadMapRecipeInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsLoadMapRecipeInfo* get_buffer (::CORBA::Boolean orphan=0);
    const rmsLoadMapRecipeInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsLoadMapRecipeInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsLoadMapRecipeInfo* src, rmsLoadMapRecipeInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsLoadMapRecipeInfo* data); 
  public:

    static rmsLoadMapRecipeInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsLoadMapRecipeInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsLoadMapRecipeInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsLoadMapRecipeInfoSeq_0> rmsLoadMapRecipeInfoSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0* _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_vPtr;
typedef const _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0* _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_cvPtr;

class  _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var
{
    public:

    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var ();

    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var (_IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 *_p);

    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var (const _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var &_s);

    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var &operator= (_IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 *_p);

    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var &operator= (const _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var &_s);

    ~_IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var ();

    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0* operator-> ();

    operator _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0() const;

    const rmsLoadMapRecipeInfo& operator[] (::CORBA::ULong index) const;
    rmsLoadMapRecipeInfo& operator[] (::CORBA::ULong index);
    const rmsLoadMapRecipeInfo& operator[] (int index) const;
    rmsLoadMapRecipeInfo& operator[] (int index);
    const _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0& in() const;
    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0& inout();
    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0*& out();
    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 _rmsLoadMapRecipeInfoSeq_seq;
    typedef _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 _rmsLoadMapRecipeInfoSeq_seq_1;
    typedef _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0 rmsLoadMapRecipeInfoSeq;
    typedef _IDL_SEQ_rmsLoadMapRecipeInfoSeq_0_var rmsLoadMapRecipeInfoSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLoadMapRecipeInfoSeq;
    class  rmsLoadMapRecipeInfoResult_struct_var;
    struct  rmsLoadMapRecipeInfoResult_struct {
        typedef rmsLoadMapRecipeInfoResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem mapInfoFlag;
       ::rmsLoadMapRecipeInfoSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsLoadMapRecipeInfoResult_struct();
       rmsLoadMapRecipeInfoResult_struct(const rmsLoadMapRecipeInfoResult_struct&);
       rmsLoadMapRecipeInfoResult_struct& operator=(const rmsLoadMapRecipeInfoResult_struct&);
       static CORBA::Info<rmsLoadMapRecipeInfoResult_struct> rmsLoadMapRecipeInfoResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsLoadMapRecipeInfoResult_struct


typedef rmsLoadMapRecipeInfoResult_struct* rmsLoadMapRecipeInfoResult_struct_vPtr;
typedef const rmsLoadMapRecipeInfoResult_struct* rmsLoadMapRecipeInfoResult_struct_cvPtr;

class  rmsLoadMapRecipeInfoResult_struct_var
{
    public:

    rmsLoadMapRecipeInfoResult_struct_var ();

    rmsLoadMapRecipeInfoResult_struct_var (rmsLoadMapRecipeInfoResult_struct *_p);

    rmsLoadMapRecipeInfoResult_struct_var (const rmsLoadMapRecipeInfoResult_struct_var &_s);

    rmsLoadMapRecipeInfoResult_struct_var &operator= (rmsLoadMapRecipeInfoResult_struct *_p);

    rmsLoadMapRecipeInfoResult_struct_var &operator= (const rmsLoadMapRecipeInfoResult_struct_var &_s);

    ~rmsLoadMapRecipeInfoResult_struct_var ();

    rmsLoadMapRecipeInfoResult_struct* operator-> ();

    const rmsLoadMapRecipeInfoResult_struct& in() const;
    rmsLoadMapRecipeInfoResult_struct& inout();
    rmsLoadMapRecipeInfoResult_struct*& out();
    rmsLoadMapRecipeInfoResult_struct* _retn();

    operator rmsLoadMapRecipeInfoResult_struct_cvPtr () const;

    operator rmsLoadMapRecipeInfoResult_struct_vPtr& ();

    operator const rmsLoadMapRecipeInfoResult_struct& () const;

    operator rmsLoadMapRecipeInfoResult_struct& ();

    protected:
    rmsLoadMapRecipeInfoResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsLoadMapRecipeInfoResult_struct;
    typedef rmsLoadMapRecipeInfoResult_struct rmsLoadMapRecipeInfoResult;
    typedef rmsLoadMapRecipeInfoResult_struct_var rmsLoadMapRecipeInfoResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsLoadMapRecipeInfoResult;
    class  rmsRcpTmpNameID_struct_var;
    struct  rmsRcpTmpNameID_struct {
        typedef rmsRcpTmpNameID_struct_var _var_type;
       ::CORBA::String_StructElem nameid;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpTmpNameID_struct();
       rmsRcpTmpNameID_struct(const rmsRcpTmpNameID_struct&);
       rmsRcpTmpNameID_struct& operator=(const rmsRcpTmpNameID_struct&);
       static CORBA::Info<rmsRcpTmpNameID_struct> rmsRcpTmpNameID_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpTmpNameID_struct


typedef rmsRcpTmpNameID_struct* rmsRcpTmpNameID_struct_vPtr;
typedef const rmsRcpTmpNameID_struct* rmsRcpTmpNameID_struct_cvPtr;

class  rmsRcpTmpNameID_struct_var
{
    public:

    rmsRcpTmpNameID_struct_var ();

    rmsRcpTmpNameID_struct_var (rmsRcpTmpNameID_struct *_p);

    rmsRcpTmpNameID_struct_var (const rmsRcpTmpNameID_struct_var &_s);

    rmsRcpTmpNameID_struct_var &operator= (rmsRcpTmpNameID_struct *_p);

    rmsRcpTmpNameID_struct_var &operator= (const rmsRcpTmpNameID_struct_var &_s);

    ~rmsRcpTmpNameID_struct_var ();

    rmsRcpTmpNameID_struct* operator-> ();

    const rmsRcpTmpNameID_struct& in() const;
    rmsRcpTmpNameID_struct& inout();
    rmsRcpTmpNameID_struct*& out();
    rmsRcpTmpNameID_struct* _retn();

    operator rmsRcpTmpNameID_struct_cvPtr () const;

    operator rmsRcpTmpNameID_struct_vPtr& ();

    operator const rmsRcpTmpNameID_struct& () const;

    operator rmsRcpTmpNameID_struct& ();

    protected:
    rmsRcpTmpNameID_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpTmpNameID_struct;
    typedef rmsRcpTmpNameID_struct rmsRcpTmpNameID;
    typedef rmsRcpTmpNameID_struct_var rmsRcpTmpNameID_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpTmpNameID;
class  _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var;
class  _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpTmpNameID *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 ();
    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpTmpNameID* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 (const _IDL_SEQ_rmsRcpTemplateNameIDSeq_0&);

    ~_IDL_SEQ_rmsRcpTemplateNameIDSeq_0 ();

    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0& operator= (const _IDL_SEQ_rmsRcpTemplateNameIDSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpTmpNameID& operator [] (::CORBA::ULong indx);
    const rmsRcpTmpNameID& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpTmpNameID* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpTmpNameID* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpTmpNameID* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpTmpNameID* src, rmsRcpTmpNameID* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpTmpNameID* data); 
  public:

    static rmsRcpTmpNameID* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpTmpNameID* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpTmpNameID* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpTemplateNameIDSeq_0> rmsRcpTemplateNameIDSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpTemplateNameIDSeq_0* _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpTemplateNameIDSeq_0* _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var ();

    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var (_IDL_SEQ_rmsRcpTemplateNameIDSeq_0 *_p);

    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var (const _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var &_s);

    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var &operator= (_IDL_SEQ_rmsRcpTemplateNameIDSeq_0 *_p);

    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var &operator= (const _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var ();

    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpTemplateNameIDSeq_0() const;

    const rmsRcpTmpNameID& operator[] (::CORBA::ULong index) const;
    rmsRcpTmpNameID& operator[] (::CORBA::ULong index);
    const rmsRcpTmpNameID& operator[] (int index) const;
    rmsRcpTmpNameID& operator[] (int index);
    const _IDL_SEQ_rmsRcpTemplateNameIDSeq_0& in() const;
    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0& inout();
    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0*& out();
    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 _rmsRcpTemplateNameIDSeq_seq;
    typedef _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 _rmsRcpTemplateNameIDSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpTemplateNameIDSeq_0 rmsRcpTemplateNameIDSeq;
    typedef _IDL_SEQ_rmsRcpTemplateNameIDSeq_0_var rmsRcpTemplateNameIDSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpTemplateNameIDSeq;
    class  rmsRcpTemplateNameIDInqResult_struct_var;
    struct  rmsRcpTemplateNameIDInqResult_struct {
        typedef rmsRcpTemplateNameIDInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpTemplateNameIDSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpTemplateNameIDInqResult_struct();
       rmsRcpTemplateNameIDInqResult_struct(const rmsRcpTemplateNameIDInqResult_struct&);
       rmsRcpTemplateNameIDInqResult_struct& operator=(const rmsRcpTemplateNameIDInqResult_struct&);
       static CORBA::Info<rmsRcpTemplateNameIDInqResult_struct> rmsRcpTemplateNameIDInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpTemplateNameIDInqResult_struct


typedef rmsRcpTemplateNameIDInqResult_struct* rmsRcpTemplateNameIDInqResult_struct_vPtr;
typedef const rmsRcpTemplateNameIDInqResult_struct* rmsRcpTemplateNameIDInqResult_struct_cvPtr;

class  rmsRcpTemplateNameIDInqResult_struct_var
{
    public:

    rmsRcpTemplateNameIDInqResult_struct_var ();

    rmsRcpTemplateNameIDInqResult_struct_var (rmsRcpTemplateNameIDInqResult_struct *_p);

    rmsRcpTemplateNameIDInqResult_struct_var (const rmsRcpTemplateNameIDInqResult_struct_var &_s);

    rmsRcpTemplateNameIDInqResult_struct_var &operator= (rmsRcpTemplateNameIDInqResult_struct *_p);

    rmsRcpTemplateNameIDInqResult_struct_var &operator= (const rmsRcpTemplateNameIDInqResult_struct_var &_s);

    ~rmsRcpTemplateNameIDInqResult_struct_var ();

    rmsRcpTemplateNameIDInqResult_struct* operator-> ();

    const rmsRcpTemplateNameIDInqResult_struct& in() const;
    rmsRcpTemplateNameIDInqResult_struct& inout();
    rmsRcpTemplateNameIDInqResult_struct*& out();
    rmsRcpTemplateNameIDInqResult_struct* _retn();

    operator rmsRcpTemplateNameIDInqResult_struct_cvPtr () const;

    operator rmsRcpTemplateNameIDInqResult_struct_vPtr& ();

    operator const rmsRcpTemplateNameIDInqResult_struct& () const;

    operator rmsRcpTemplateNameIDInqResult_struct& ();

    protected:
    rmsRcpTemplateNameIDInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpTemplateNameIDInqResult_struct;
    typedef rmsRcpTemplateNameIDInqResult_struct rmsRcpTemplateNameIDInqResult;
    typedef rmsRcpTemplateNameIDInqResult_struct_var rmsRcpTemplateNameIDInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpTemplateNameIDInqResult;
    class  rmsRcpTmpItems_struct_var;
    struct  rmsRcpTmpItems_struct {
        typedef rmsRcpTmpItems_struct_var _var_type;
       ::CORBA::String_StructElem blockname;
       ::CORBA::String_StructElem itemname;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpTmpItems_struct();
       rmsRcpTmpItems_struct(const rmsRcpTmpItems_struct&);
       rmsRcpTmpItems_struct& operator=(const rmsRcpTmpItems_struct&);
       static CORBA::Info<rmsRcpTmpItems_struct> rmsRcpTmpItems_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpTmpItems_struct


typedef rmsRcpTmpItems_struct* rmsRcpTmpItems_struct_vPtr;
typedef const rmsRcpTmpItems_struct* rmsRcpTmpItems_struct_cvPtr;

class  rmsRcpTmpItems_struct_var
{
    public:

    rmsRcpTmpItems_struct_var ();

    rmsRcpTmpItems_struct_var (rmsRcpTmpItems_struct *_p);

    rmsRcpTmpItems_struct_var (const rmsRcpTmpItems_struct_var &_s);

    rmsRcpTmpItems_struct_var &operator= (rmsRcpTmpItems_struct *_p);

    rmsRcpTmpItems_struct_var &operator= (const rmsRcpTmpItems_struct_var &_s);

    ~rmsRcpTmpItems_struct_var ();

    rmsRcpTmpItems_struct* operator-> ();

    const rmsRcpTmpItems_struct& in() const;
    rmsRcpTmpItems_struct& inout();
    rmsRcpTmpItems_struct*& out();
    rmsRcpTmpItems_struct* _retn();

    operator rmsRcpTmpItems_struct_cvPtr () const;

    operator rmsRcpTmpItems_struct_vPtr& ();

    operator const rmsRcpTmpItems_struct& () const;

    operator rmsRcpTmpItems_struct& ();

    protected:
    rmsRcpTmpItems_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpTmpItems_struct;
    typedef rmsRcpTmpItems_struct rmsRcpTmpItems;
    typedef rmsRcpTmpItems_struct_var rmsRcpTmpItems_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpTmpItems;
class  _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var;
class  _IDL_SEQ_rmsRcpTemplateItemsSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpTmpItems *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpTemplateItemsSeq_0 ();
    _IDL_SEQ_rmsRcpTemplateItemsSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpTemplateItemsSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpTmpItems* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpTemplateItemsSeq_0 (const _IDL_SEQ_rmsRcpTemplateItemsSeq_0&);

    ~_IDL_SEQ_rmsRcpTemplateItemsSeq_0 ();

    _IDL_SEQ_rmsRcpTemplateItemsSeq_0& operator= (const _IDL_SEQ_rmsRcpTemplateItemsSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpTmpItems& operator [] (::CORBA::ULong indx);
    const rmsRcpTmpItems& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpTmpItems* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpTmpItems* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpTmpItems* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpTmpItems* src, rmsRcpTmpItems* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpTmpItems* data); 
  public:

    static rmsRcpTmpItems* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpTmpItems* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpTmpItems* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpTemplateItemsSeq_0> rmsRcpTemplateItemsSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpTemplateItemsSeq_0* _IDL_SEQ_rmsRcpTemplateItemsSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpTemplateItemsSeq_0* _IDL_SEQ_rmsRcpTemplateItemsSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var ();

    _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var (_IDL_SEQ_rmsRcpTemplateItemsSeq_0 *_p);

    _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var (const _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var &_s);

    _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var &operator= (_IDL_SEQ_rmsRcpTemplateItemsSeq_0 *_p);

    _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var &operator= (const _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpTemplateItemsSeq_0_var ();

    _IDL_SEQ_rmsRcpTemplateItemsSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpTemplateItemsSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpTemplateItemsSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpTemplateItemsSeq_0() const;

    const rmsRcpTmpItems& operator[] (::CORBA::ULong index) const;
    rmsRcpTmpItems& operator[] (::CORBA::ULong index);
    const rmsRcpTmpItems& operator[] (int index) const;
    rmsRcpTmpItems& operator[] (int index);
    const _IDL_SEQ_rmsRcpTemplateItemsSeq_0& in() const;
    _IDL_SEQ_rmsRcpTemplateItemsSeq_0& inout();
    _IDL_SEQ_rmsRcpTemplateItemsSeq_0*& out();
    _IDL_SEQ_rmsRcpTemplateItemsSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpTemplateItemsSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpTemplateItemsSeq_0 _rmsRcpTemplateItemsSeq_seq;
    typedef _IDL_SEQ_rmsRcpTemplateItemsSeq_0 _rmsRcpTemplateItemsSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpTemplateItemsSeq_0 rmsRcpTemplateItemsSeq;
    typedef _IDL_SEQ_rmsRcpTemplateItemsSeq_0_var rmsRcpTemplateItemsSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpTemplateItemsSeq;
    class  rmsRcpItemValue_struct_var;
    struct  rmsRcpItemValue_struct {
        typedef rmsRcpItemValue_struct_var _var_type;
       ::CORBA::String_StructElem blockname;
       ::CORBA::String_StructElem itemname;
       ::CORBA::String_StructElem itemvalue;
       ::CORBA::String_StructElem checkresult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpItemValue_struct();
       rmsRcpItemValue_struct(const rmsRcpItemValue_struct&);
       rmsRcpItemValue_struct& operator=(const rmsRcpItemValue_struct&);
       static CORBA::Info<rmsRcpItemValue_struct> rmsRcpItemValue_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsRcpItemValue_struct


typedef rmsRcpItemValue_struct* rmsRcpItemValue_struct_vPtr;
typedef const rmsRcpItemValue_struct* rmsRcpItemValue_struct_cvPtr;

class  rmsRcpItemValue_struct_var
{
    public:

    rmsRcpItemValue_struct_var ();

    rmsRcpItemValue_struct_var (rmsRcpItemValue_struct *_p);

    rmsRcpItemValue_struct_var (const rmsRcpItemValue_struct_var &_s);

    rmsRcpItemValue_struct_var &operator= (rmsRcpItemValue_struct *_p);

    rmsRcpItemValue_struct_var &operator= (const rmsRcpItemValue_struct_var &_s);

    ~rmsRcpItemValue_struct_var ();

    rmsRcpItemValue_struct* operator-> ();

    const rmsRcpItemValue_struct& in() const;
    rmsRcpItemValue_struct& inout();
    rmsRcpItemValue_struct*& out();
    rmsRcpItemValue_struct* _retn();

    operator rmsRcpItemValue_struct_cvPtr () const;

    operator rmsRcpItemValue_struct_vPtr& ();

    operator const rmsRcpItemValue_struct& () const;

    operator rmsRcpItemValue_struct& ();

    protected:
    rmsRcpItemValue_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpItemValue_struct;
    typedef rmsRcpItemValue_struct rmsRcpItemValue;
    typedef rmsRcpItemValue_struct_var rmsRcpItemValue_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpItemValue;
class  _IDL_SEQ_rmsRcpItemValueSeq_0_var;
class  _IDL_SEQ_rmsRcpItemValueSeq_0 {
    public:
        typedef _IDL_SEQ_rmsRcpItemValueSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsRcpItemValue *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsRcpItemValueSeq_0 ();
    _IDL_SEQ_rmsRcpItemValueSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsRcpItemValueSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpItemValue* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsRcpItemValueSeq_0 (const _IDL_SEQ_rmsRcpItemValueSeq_0&);

    ~_IDL_SEQ_rmsRcpItemValueSeq_0 ();

    _IDL_SEQ_rmsRcpItemValueSeq_0& operator= (const _IDL_SEQ_rmsRcpItemValueSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsRcpItemValue& operator [] (::CORBA::ULong indx);
    const rmsRcpItemValue& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsRcpItemValue* get_buffer (::CORBA::Boolean orphan=0);
    const rmsRcpItemValue* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsRcpItemValue* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpItemValue* src, rmsRcpItemValue* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsRcpItemValue* data); 
  public:

    static rmsRcpItemValue* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsRcpItemValue* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsRcpItemValue* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsRcpItemValueSeq_0> rmsRcpItemValueSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsRcpItemValueSeq_0* _IDL_SEQ_rmsRcpItemValueSeq_0_vPtr;
typedef const _IDL_SEQ_rmsRcpItemValueSeq_0* _IDL_SEQ_rmsRcpItemValueSeq_0_cvPtr;

class  _IDL_SEQ_rmsRcpItemValueSeq_0_var
{
    public:

    _IDL_SEQ_rmsRcpItemValueSeq_0_var ();

    _IDL_SEQ_rmsRcpItemValueSeq_0_var (_IDL_SEQ_rmsRcpItemValueSeq_0 *_p);

    _IDL_SEQ_rmsRcpItemValueSeq_0_var (const _IDL_SEQ_rmsRcpItemValueSeq_0_var &_s);

    _IDL_SEQ_rmsRcpItemValueSeq_0_var &operator= (_IDL_SEQ_rmsRcpItemValueSeq_0 *_p);

    _IDL_SEQ_rmsRcpItemValueSeq_0_var &operator= (const _IDL_SEQ_rmsRcpItemValueSeq_0_var &_s);

    ~_IDL_SEQ_rmsRcpItemValueSeq_0_var ();

    _IDL_SEQ_rmsRcpItemValueSeq_0* operator-> ();

    operator _IDL_SEQ_rmsRcpItemValueSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsRcpItemValueSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsRcpItemValueSeq_0() const;

    const rmsRcpItemValue& operator[] (::CORBA::ULong index) const;
    rmsRcpItemValue& operator[] (::CORBA::ULong index);
    const rmsRcpItemValue& operator[] (int index) const;
    rmsRcpItemValue& operator[] (int index);
    const _IDL_SEQ_rmsRcpItemValueSeq_0& in() const;
    _IDL_SEQ_rmsRcpItemValueSeq_0& inout();
    _IDL_SEQ_rmsRcpItemValueSeq_0*& out();
    _IDL_SEQ_rmsRcpItemValueSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsRcpItemValueSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsRcpItemValueSeq_0 _rmsRcpItemValueSeq_seq;
    typedef _IDL_SEQ_rmsRcpItemValueSeq_0 _rmsRcpItemValueSeq_seq_1;
    typedef _IDL_SEQ_rmsRcpItemValueSeq_0 rmsRcpItemValueSeq;
    typedef _IDL_SEQ_rmsRcpItemValueSeq_0_var rmsRcpItemValueSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpItemValueSeq;
    class  rmsRcpItemValueCheckResult_struct_var;
    struct  rmsRcpItemValueCheckResult_struct {
        typedef rmsRcpItemValueCheckResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsRcpItemValueSeq infos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsRcpItemValueCheckResult_struct();
       rmsRcpItemValueCheckResult_struct(const rmsRcpItemValueCheckResult_struct&);
       rmsRcpItemValueCheckResult_struct& operator=(const rmsRcpItemValueCheckResult_struct&);
       static CORBA::Info<rmsRcpItemValueCheckResult_struct> rmsRcpItemValueCheckResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsRcpItemValueCheckResult_struct


typedef rmsRcpItemValueCheckResult_struct* rmsRcpItemValueCheckResult_struct_vPtr;
typedef const rmsRcpItemValueCheckResult_struct* rmsRcpItemValueCheckResult_struct_cvPtr;

class  rmsRcpItemValueCheckResult_struct_var
{
    public:

    rmsRcpItemValueCheckResult_struct_var ();

    rmsRcpItemValueCheckResult_struct_var (rmsRcpItemValueCheckResult_struct *_p);

    rmsRcpItemValueCheckResult_struct_var (const rmsRcpItemValueCheckResult_struct_var &_s);

    rmsRcpItemValueCheckResult_struct_var &operator= (rmsRcpItemValueCheckResult_struct *_p);

    rmsRcpItemValueCheckResult_struct_var &operator= (const rmsRcpItemValueCheckResult_struct_var &_s);

    ~rmsRcpItemValueCheckResult_struct_var ();

    rmsRcpItemValueCheckResult_struct* operator-> ();

    const rmsRcpItemValueCheckResult_struct& in() const;
    rmsRcpItemValueCheckResult_struct& inout();
    rmsRcpItemValueCheckResult_struct*& out();
    rmsRcpItemValueCheckResult_struct* _retn();

    operator rmsRcpItemValueCheckResult_struct_cvPtr () const;

    operator rmsRcpItemValueCheckResult_struct_vPtr& ();

    operator const rmsRcpItemValueCheckResult_struct& () const;

    operator rmsRcpItemValueCheckResult_struct& ();

    protected:
    rmsRcpItemValueCheckResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpItemValueCheckResult_struct;
    typedef rmsRcpItemValueCheckResult_struct rmsRcpItemValueCheckResult;
    typedef rmsRcpItemValueCheckResult_struct_var rmsRcpItemValueCheckResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsRcpItemValueCheckResult;
    class  rmsSERJob_struct_var;
    struct  rmsSERJob_struct {
        typedef rmsSERJob_struct_var _var_type;
       ::CORBA::Long jobIndex;
       ::CORBA::String_StructElem equipmentID;
       ::CORBA::String_StructElem subEqp;
       ::CORBA::String_StructElem recipeID;
       ::CORBA::String_StructElem actionCode;
       ::CORBA::String_StructElem jobStatus;
       ::CORBA::Long retryCount;
       ::CORBA::String_StructElem jobExecDT;
       ::CORBA::String_StructElem rmsStartDT;
       ::CORBA::String_StructElem rmsEndDT;
       ::CORBA::String_StructElem result;
       ::CORBA::String_StructElem resultDesc;
       ::CORBA::String_StructElem serExecDT;
       ::CORBA::String_StructElem serExecResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsSERJob_struct();
       rmsSERJob_struct(const rmsSERJob_struct&);
       rmsSERJob_struct& operator=(const rmsSERJob_struct&);
       static CORBA::Info<rmsSERJob_struct> rmsSERJob_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct rmsSERJob_struct


typedef rmsSERJob_struct* rmsSERJob_struct_vPtr;
typedef const rmsSERJob_struct* rmsSERJob_struct_cvPtr;

class  rmsSERJob_struct_var
{
    public:

    rmsSERJob_struct_var ();

    rmsSERJob_struct_var (rmsSERJob_struct *_p);

    rmsSERJob_struct_var (const rmsSERJob_struct_var &_s);

    rmsSERJob_struct_var &operator= (rmsSERJob_struct *_p);

    rmsSERJob_struct_var &operator= (const rmsSERJob_struct_var &_s);

    ~rmsSERJob_struct_var ();

    rmsSERJob_struct* operator-> ();

    const rmsSERJob_struct& in() const;
    rmsSERJob_struct& inout();
    rmsSERJob_struct*& out();
    rmsSERJob_struct* _retn();

    operator rmsSERJob_struct_cvPtr () const;

    operator rmsSERJob_struct_vPtr& ();

    operator const rmsSERJob_struct& () const;

    operator rmsSERJob_struct& ();

    protected:
    rmsSERJob_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsSERJob_struct;
    typedef rmsSERJob_struct rmsSERJob;
    typedef rmsSERJob_struct_var rmsSERJob_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsSERJob;
class  _IDL_SEQ_rmsSERJobSeq_0_var;
class  _IDL_SEQ_rmsSERJobSeq_0 {
    public:
        typedef _IDL_SEQ_rmsSERJobSeq_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    rmsSERJob *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_rmsSERJobSeq_0 ();
    _IDL_SEQ_rmsSERJobSeq_0 (::CORBA::ULong max);
    _IDL_SEQ_rmsSERJobSeq_0 (::CORBA::ULong max, ::CORBA::ULong length, rmsSERJob* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_rmsSERJobSeq_0 (const _IDL_SEQ_rmsSERJobSeq_0&);

    ~_IDL_SEQ_rmsSERJobSeq_0 ();

    _IDL_SEQ_rmsSERJobSeq_0& operator= (const _IDL_SEQ_rmsSERJobSeq_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    rmsSERJob& operator [] (::CORBA::ULong indx);
    const rmsSERJob& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    rmsSERJob* get_buffer (::CORBA::Boolean orphan=0);
    const rmsSERJob* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, rmsSERJob* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsSERJob* src, rmsSERJob* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, rmsSERJob* data); 
  public:

    static rmsSERJob* SOMLINK allocbuf(::CORBA::ULong nelems);
    static rmsSERJob* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(rmsSERJob* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_rmsSERJobSeq_0> rmsSERJobSeq_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_rmsSERJobSeq_0* _IDL_SEQ_rmsSERJobSeq_0_vPtr;
typedef const _IDL_SEQ_rmsSERJobSeq_0* _IDL_SEQ_rmsSERJobSeq_0_cvPtr;

class  _IDL_SEQ_rmsSERJobSeq_0_var
{
    public:

    _IDL_SEQ_rmsSERJobSeq_0_var ();

    _IDL_SEQ_rmsSERJobSeq_0_var (_IDL_SEQ_rmsSERJobSeq_0 *_p);

    _IDL_SEQ_rmsSERJobSeq_0_var (const _IDL_SEQ_rmsSERJobSeq_0_var &_s);

    _IDL_SEQ_rmsSERJobSeq_0_var &operator= (_IDL_SEQ_rmsSERJobSeq_0 *_p);

    _IDL_SEQ_rmsSERJobSeq_0_var &operator= (const _IDL_SEQ_rmsSERJobSeq_0_var &_s);

    ~_IDL_SEQ_rmsSERJobSeq_0_var ();

    _IDL_SEQ_rmsSERJobSeq_0* operator-> ();

    operator _IDL_SEQ_rmsSERJobSeq_0_cvPtr () const;

    operator _IDL_SEQ_rmsSERJobSeq_0_vPtr& ();

    operator _IDL_SEQ_rmsSERJobSeq_0() const;

    const rmsSERJob& operator[] (::CORBA::ULong index) const;
    rmsSERJob& operator[] (::CORBA::ULong index);
    const rmsSERJob& operator[] (int index) const;
    rmsSERJob& operator[] (int index);
    const _IDL_SEQ_rmsSERJobSeq_0& in() const;
    _IDL_SEQ_rmsSERJobSeq_0& inout();
    _IDL_SEQ_rmsSERJobSeq_0*& out();
    _IDL_SEQ_rmsSERJobSeq_0* _retn();

    protected:
    _IDL_SEQ_rmsSERJobSeq_0 *_ptr;
};

    typedef _IDL_SEQ_rmsSERJobSeq_0 _rmsSERJobSeq_seq;
    typedef _IDL_SEQ_rmsSERJobSeq_0 _rmsSERJobSeq_seq_1;
    typedef _IDL_SEQ_rmsSERJobSeq_0 rmsSERJobSeq;
    typedef _IDL_SEQ_rmsSERJobSeq_0_var rmsSERJobSeq_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsSERJobSeq;
    class  rmsSERJobInqResult_struct_var;
    struct  rmsSERJobInqResult_struct {
        typedef rmsSERJobInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::rmsSERJobSeq jobs;
       ::CORBA::Boolean overSearchCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       rmsSERJobInqResult_struct();
       rmsSERJobInqResult_struct(const rmsSERJobInqResult_struct&);
       rmsSERJobInqResult_struct& operator=(const rmsSERJobInqResult_struct&);
       static CORBA::Info<rmsSERJobInqResult_struct> rmsSERJobInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct rmsSERJobInqResult_struct


typedef rmsSERJobInqResult_struct* rmsSERJobInqResult_struct_vPtr;
typedef const rmsSERJobInqResult_struct* rmsSERJobInqResult_struct_cvPtr;

class  rmsSERJobInqResult_struct_var
{
    public:

    rmsSERJobInqResult_struct_var ();

    rmsSERJobInqResult_struct_var (rmsSERJobInqResult_struct *_p);

    rmsSERJobInqResult_struct_var (const rmsSERJobInqResult_struct_var &_s);

    rmsSERJobInqResult_struct_var &operator= (rmsSERJobInqResult_struct *_p);

    rmsSERJobInqResult_struct_var &operator= (const rmsSERJobInqResult_struct_var &_s);

    ~rmsSERJobInqResult_struct_var ();

    rmsSERJobInqResult_struct* operator-> ();

    const rmsSERJobInqResult_struct& in() const;
    rmsSERJobInqResult_struct& inout();
    rmsSERJobInqResult_struct*& out();
    rmsSERJobInqResult_struct* _retn();

    operator rmsSERJobInqResult_struct_cvPtr () const;

    operator rmsSERJobInqResult_struct_vPtr& ();

    operator const rmsSERJobInqResult_struct& () const;

    operator rmsSERJobInqResult_struct& ();

    protected:
    rmsSERJobInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_rmsSERJobInqResult_struct;
    typedef rmsSERJobInqResult_struct rmsSERJobInqResult;
    typedef rmsSERJobInqResult_struct_var rmsSERJobInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_rmsSERJobInqResult;

   static const char* ex_RMSException = "RMSException";
   class  RMSException : public ::CORBA::UserException {
     public:
       static const  char* _exception_id;

       ::CORBA::String_StructElem functionName;
       ::CORBA::String_StructElem r1;
       ::CORBA::String_StructElem r2;
       ::CORBA::String_StructElem r3;
       ::CORBA::String_StructElem r4;
       ::CORBA::Long retn;

       RMSException () : CORBA::UserException (ex_RMSException, "IDL:RMSException:1.0") { };
        RMSException(const RMSException&);
        RMSException& operator=(const RMSException&);
       RMSException ( const char* _functionName, const char* _r1, const char* _r2, const char* _r3, const char* _r4, const ::CORBA::Long _retn) : CORBA::UserException (ex_RMSException, "IDL:RMSException:1.0") { 
         functionName = _functionName;
         r1 = _r1;
         r2 = _r2;
         r3 = _r3;
         r4 = _r4;
         retn = _retn;
       }

       // The _narrow methods are depricated; use _downcast 
       static  RMSException* SOMLINK _narrow (::CORBA::Exception *e);
       static  const RMSException* SOMLINK _narrow (const ::CORBA::Exception *e) {
         return _narrow ((::CORBA::Exception *)e); }
       static  RMSException* SOMLINK _downcast (::CORBA::Exception *e) {return _narrow(e);}
       static  const RMSException* SOMLINK _downcast (const ::CORBA::Exception *e) {return _narrow(e);}
       void  encodeOp(::CORBA::Request &_req) const;
       void  decodeOp(::CORBA::Request &_req);
   }; // exception RMSException

    extern  ::CORBA::TypeCode_ptr _tc_RMSException;
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_rmsstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_rmsstr_ANYOPERATOR__
#undef __NOTUSE_rmsstr_ANYOPERATOR__
#endif //__USE_rmsstr_ANYOPERATOR__
#ifndef __NOTUSE_rmsstr_ANYOPERATOR__
#define _DCL_ANYOPS_rmsRangeValue_struct
#define _DCL_ANYOPS_rmsRangeValueSeq
#define _DCL_ANYOPS_rmsRecipeItemValue_struct
#define _DCL_ANYOPS_rmsRecipeItemValueSeq
#define _DCL_ANYOPS_rmsRecipeBody_struct
#define _DCL_ANYOPS_rmsRecipeBodySeq
#define _DCL_ANYOPS_rmsAuditReqResult_struct
#define _DCL_ANYOPS_rmsRecipeInqResult_struct
#define _DCL_ANYOPS_rmsRecipeUploadReqResult_struct
#define _DCL_ANYOPS_rmsRecipeCheckOutReqResult_struct
#define _DCL_ANYOPS_rmsRecipeCheckInReqResult_struct
#define _DCL_ANYOPS_rmsRecipeSaveReqResult_struct
#define _DCL_ANYOPS_rmsRecipeSetGoldenReqResult_struct
#define _DCL_ANYOPS_rmsPreAuditInqResult_struct
#define _DCL_ANYOPS_rmsSetDBUserPswdReqResult_struct
#define _DCL_ANYOPS_rmsConstantValue_struct
#define _DCL_ANYOPS_rmsConstantValueSequence
#define _DCL_ANYOPS_rmsEqpConstant_struct
#define _DCL_ANYOPS_rmsEqpConstantSequence
#define _DCL_ANYOPS_rmsEqpConstantInqResult_struct
#define _DCL_ANYOPS_rmsEqpConstantUploadReqResult_struct
#define _DCL_ANYOPS_rmsEqpConstantCheckOutReqResult_struct
#define _DCL_ANYOPS_rmsEqpConstantCheckInReqResult_struct
#define _DCL_ANYOPS_rmsEqpConstantSaveReqResult_struct
#define _DCL_ANYOPS_rmsHistoryRecord_struct
#define _DCL_ANYOPS_rmsHistoryRecordSequence
#define _DCL_ANYOPS_rmsGeneralHistoryInqResult_struct
#define _DCL_ANYOPS_rmsRecipeHistoryInqResult_struct
#define _DCL_ANYOPS_rmsRuleBlockItemInfo_struct
#define _DCL_ANYOPS_rmsRuleBlockItemInfoSeq
#define _DCL_ANYOPS_rmsRuleBlockInfo_struct
#define _DCL_ANYOPS_rmsRuleBlockInfoSeq
#define _DCL_ANYOPS_rmsRuleInfo_struct
#define _DCL_ANYOPS_rmsRuleRelationInfo_struct
#define _DCL_ANYOPS_rmsRuleRelationInfoSeq
#define _DCL_ANYOPS_rmsRuleRelationSetReqResult_struct
#define _DCL_ANYOPS_rmsRuleRelationListResult_struct
#define _DCL_ANYOPS_rmsRuleDefinitionSetReqResult_struct
#define _DCL_ANYOPS_rmsRuleDefinitionCheckOutReqResult_struct
#define _DCL_ANYOPS_rmsRuleDefinitionCheckInReqResult_struct
#define _DCL_ANYOPS_rmsRuleDefinitionListInqResult_struct
#define _DCL_ANYOPS_rmsRuleDefinitionInfoInqResult_struct
#define _DCL_ANYOPS_rmsRecipeDeleteReqResult_struct
#define _DCL_ANYOPS_rmsRuleRelationDeleteReqResult_struct
#define _DCL_ANYOPS_rmsRuleDefinitionDeleteReqResult_struct
#define _DCL_ANYOPS_rmsRecipeInfo_struct
#define _DCL_ANYOPS_rmsRecipeInfoSequence
#define _DCL_ANYOPS_rmsRecipeDeleteCheckInqResult_struct
#define _DCL_ANYOPS_rmsRecipeUsedByCheckInqResult_struct
#define _DCL_ANYOPS_rmsRecipeCopydFromGoldenReqResult_struct
#define _DCL_ANYOPS_rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct
#define _DCL_ANYOPS_rmsGoldenViewEqpListInqResult_struct
#define _DCL_ANYOPS_rmsAlarmEventParameter_struct
#define _DCL_ANYOPS_rmsAlarmEventParameterSequence
#define _DCL_ANYOPS_rmsChildRecipeInqResult_struct
#define _DCL_ANYOPS_rmsRecipeLeaf_struct
#define _DCL_ANYOPS_rmsRecipeLeafSequence
#define _DCL_ANYOPS_rmsRecipeTreeInqResult_struct
#define _DCL_ANYOPS_rmsRecipeLimitCopyReqResult_struct
#define _DCL_ANYOPS_rmsChildRecipeUploadReqResult_struct
#define _DCL_ANYOPS_rmsMiscInqResult_struct
#define _DCL_ANYOPS_rmsResult_struct
#define _DCL_ANYOPS_rmsMiscPair_struct
#define _DCL_ANYOPS_rmsMiscPairSeq
#define _DCL_ANYOPS_rmsMiscPairInqResult_struct
#define _DCL_ANYOPS_rmsMandPRecipeInfo_struct
#define _DCL_ANYOPS_rmsMandPRecipeInfoSequence
#define _DCL_ANYOPS_rmsEqpRelatedRecipeAllInqResult_struct
#define _DCL_ANYOPS_rmsBatchJob_struct
#define _DCL_ANYOPS_rmsBatchJobSeq
#define _DCL_ANYOPS_rmsBatchJobInqResult_struct
#define _DCL_ANYOPS_rmsEqpBatchJobRunTimeInfo_struct
#define _DCL_ANYOPS_rmsEqpBatchJobRunTimeInfoSeq
#define _DCL_ANYOPS_rmsBatchJobRunTimeInfo_struct
#define _DCL_ANYOPS_rmsEqpProfile_struct
#define _DCL_ANYOPS_rmsEqpProfileSeq
#define _DCL_ANYOPS_rmsEqpProfileInqResult_struct
#define _DCL_ANYOPS_rmsRecipeProfile_struct
#define _DCL_ANYOPS_rmsRecipeProfileSeq
#define _DCL_ANYOPS_rmsRecipeProfileInqResult_struct
#define _DCL_ANYOPS_rmsAuditFailInfo_struct
#define _DCL_ANYOPS_rmsAuditFailInfoSeq
#define _DCL_ANYOPS_rmsAuditFailInfoInqResult_struct
#define _DCL_ANYOPS_rmsReGoldenInfo_struct
#define _DCL_ANYOPS_rmsReGoldenInfoSeq
#define _DCL_ANYOPS_rmsReGoldenInfoInqResult_struct
#define _DCL_ANYOPS_rmsEnvVariable_struct
#define _DCL_ANYOPS_rmsEnvVariableSeq
#define _DCL_ANYOPS_rmsEnvVariableInqResult_struct
#define _DCL_ANYOPS_rmsParentRecipe_struct
#define _DCL_ANYOPS_rmsParentRecipeSeq
#define _DCL_ANYOPS_rmsParentRecipeSeqResult_struct
#define _DCL_ANYOPS_rmsRecipeNode_struct
#define _DCL_ANYOPS_rmsRecipeNodeSeq
#define _DCL_ANYOPS_rmsRecipeByLevel_struct
#define _DCL_ANYOPS_rmsRecipeByLevelSeq
#define _DCL_ANYOPS_rmsEqpRecipeByLevelInqResult_struct
#define _DCL_ANYOPS_rmsRecipeRelationInqResult_struct
#define _DCL_ANYOPS_rmsBulletinRecord_struct
#define _DCL_ANYOPS_rmsBulletinRecordSequence
#define _DCL_ANYOPS_rmsBulletinListInqResult_struct
#define _DCL_ANYOPS_rmsRIMJob_struct
#define _DCL_ANYOPS_rmsRIMJobSeq
#define _DCL_ANYOPS_rmsRIMJobInqResult_struct
#define _DCL_ANYOPS_rmsUATData_struct
#define _DCL_ANYOPS_rmsUATDataSeq
#define _DCL_ANYOPS_rmsUATDataInqResult_struct
#define _DCL_ANYOPS_rmsHoldDataSeq
#define _DCL_ANYOPS_rmsHoldDataInqResult_struct
#define _DCL_ANYOPS_rmsLabelData_struct
#define _DCL_ANYOPS_rmsLabelDataSeq
#define _DCL_ANYOPS_rmsLabelDataInqResult_struct
#define _DCL_ANYOPS_rmsRecipeLabelData_struct
#define _DCL_ANYOPS_rmsRecipeLabelDataSeq
#define _DCL_ANYOPS_rmsRecipeLabelDataInqResult_struct
#define _DCL_ANYOPS_rmsRecipeLabelTreeSeq
#define _DCL_ANYOPS_rmsRecipeLabelTreeInqResult_struct
#define _DCL_ANYOPS_rmsRecipeChange_struct
#define _DCL_ANYOPS_rmsRecipeChangeSeq
#define _DCL_ANYOPS_rmsRecipeChangeInqResult_struct
#define _DCL_ANYOPS_rmsRcipeMatchedInqResult_struct
#define _DCL_ANYOPS_rmsECBatch_struct
#define _DCL_ANYOPS_rmsECBatchSeq
#define _DCL_ANYOPS_rmsECBatchInqResult_struct
#define _DCL_ANYOPS_rmsECBatchAuditFailInfo_struct
#define _DCL_ANYOPS_rmsECBatchAuditFailSeq
#define _DCL_ANYOPS_rmsECBatchAuditFailInqResult_struct
#define _DCL_ANYOPS_csLotAttrForAudit_struct
#define _DCL_ANYOPS_csLotAttrForAuditSequence
#define _DCL_ANYOPS_rmsLotAuditSkip_struct
#define _DCL_ANYOPS_rmsLotAuditSkipSeq
#define _DCL_ANYOPS_rmsLotAuditSkipInqResult_struct
#define _DCL_ANYOPS_rmsEqpConstantBlock_struct
#define _DCL_ANYOPS_rmsEqpConstantBlockSequence
#define _DCL_ANYOPS_rmsEqpConstantBlockInqResult_struct
#define _DCL_ANYOPS_rmsRcpBatch_struct
#define _DCL_ANYOPS_rmsRcpBatchSeq
#define _DCL_ANYOPS_rmsRcpBatchInqResult_struct
#define _DCL_ANYOPS_rmsUserPrivilege_struct
#define _DCL_ANYOPS_rmsUserPrivilegeSeq
#define _DCL_ANYOPS_rmsUserPrivilegeInqResult_struct
#define _DCL_ANYOPS_rmsPrivilege_struct
#define _DCL_ANYOPS_rmsPrivilegeSeq
#define _DCL_ANYOPS_rmsPrivilegeInqResult_struct
#define _DCL_ANYOPS_rmsPrivilegeLevel_struct
#define _DCL_ANYOPS_rmsPrivilegeLevelSeq
#define _DCL_ANYOPS_rmsPrivilegeLevelInqResult_struct
#define _DCL_ANYOPS_rmsEqpStatusChangeFlag_struct
#define _DCL_ANYOPS_rmsEqpStatusChangeFlagSeq
#define _DCL_ANYOPS_rmsEqpStatusChangeFlagResult_struct
#define _DCL_ANYOPS_rmsEDMJob_struct
#define _DCL_ANYOPS_rmsEDMJobSeq
#define _DCL_ANYOPS_rmsEDMJobInqResult_struct
#define _DCL_ANYOPS_rmsForceAuditHistory_struct
#define _DCL_ANYOPS_rmsForceAuditHistorySeq
#define _DCL_ANYOPS_rmsForceAuditHistoryInqResult_struct
#define _DCL_ANYOPS_rmsECIMJob_struct
#define _DCL_ANYOPS_rmsECIMJobSeq
#define _DCL_ANYOPS_rmsECIMJobInqResult_struct
#define _DCL_ANYOPS_rmsECUATData_struct
#define _DCL_ANYOPS_rmsECUATDataSeq
#define _DCL_ANYOPS_rmsECUATDataInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpEvdSaveReqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpEvdDetailInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpExamSaveReqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpExamData_struct
#define _DCL_ANYOPS_rmsRcpCmpExamDataSeq
#define _DCL_ANYOPS_rmsRcpCmpExamInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpExamDetailData_struct
#define _DCL_ANYOPS_rmsRcpCmpExamDetailDataSeq
#define _DCL_ANYOPS_rmsRcpCmpExamDetailInqResult_struct
#define _DCL_ANYOPS_rmsRecipeGolden_struct
#define _DCL_ANYOPS_rmsRecipeGoldenSeq
#define _DCL_ANYOPS_rmsRecipeGoldenInqResult_struct
#define _DCL_ANYOPS_rmsGeneralConfig_struct
#define _DCL_ANYOPS_rmsGeneralConfigSeq
#define _DCL_ANYOPS_rmsGeneralConfigInqResult_struct
#define _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnData_struct
#define _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnDataSeq
#define _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpData_struct
#define _DCL_ANYOPS_rmsRcpCmpDataSeq
#define _DCL_ANYOPS_rmsRcpCmpInqList_struct
#define _DCL_ANYOPS_rmsRcpCmpInqListSeq
#define _DCL_ANYOPS_rmsRcpCmpInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpBatchSaveReqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpBatchUpdateReqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpBatchDeleteReqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpBatchData_struct
#define _DCL_ANYOPS_rmsRcpCmpBatchDataSeq
#define _DCL_ANYOPS_rmsRcpCmpBatchInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpPairData_struct
#define _DCL_ANYOPS_rmsRcpCmpPairDataSeq
#define _DCL_ANYOPS_rmsRcpCmpPairInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpPairNoInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpPairAddReqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpPairUpdateReqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpPairList_struct
#define _DCL_ANYOPS_rmsRcpCmpPairListSeq
#define _DCL_ANYOPS_rmsRcpCmpResultInqResult_struct
#define _DCL_ANYOPS_rmsRcpCmpSaveReqResult_struct
#define _DCL_ANYOPS_rmsRcpBatchCnt_struct
#define _DCL_ANYOPS_rmsRcpBatchCntSeq
#define _DCL_ANYOPS_rmsRcpBatchCntInqResult_struct
#define _DCL_ANYOPS_rmsRcpAFI_struct
#define _DCL_ANYOPS_rmsRcpAuditFailInhibitJobSeq
#define _DCL_ANYOPS_rmsRcpAFIInqResult_struct
#define _DCL_ANYOPS_rmsRcpChgAuditInfo_struct
#define _DCL_ANYOPS_rmsRcpChgAuditResultSeq
#define _DCL_ANYOPS_rmsRcpChgAuditResultInqResult_struct
#define _DCL_ANYOPS_rmsRcpAutoLabelInqInfo_struct
#define _DCL_ANYOPS_rmsRcpAutoLabelAllInqResultSeq
#define _DCL_ANYOPS_rmsEqpRecipeAutoLabelAllInqResult_struct
#define _DCL_ANYOPS_rmsRcpLabelRuleInqInfo_struct
#define _DCL_ANYOPS_rmsRcpLabelRuleInqResultSeq
#define _DCL_ANYOPS_rmsEqpRcpLabelRuleInqResult_struct
#define _DCL_ANYOPS_rmsProRcpAuditRuleInfo_struct
#define _DCL_ANYOPS_rmsProdRcpAuditRuleSeq
#define _DCL_ANYOPS_rmsProRcpAuditRuleInqResult_struct
#define _DCL_ANYOPS_rmsLoadMapRecipeInfo_struct
#define _DCL_ANYOPS_rmsLoadMapRecipeInfoSeq
#define _DCL_ANYOPS_rmsLoadMapRecipeInfoResult_struct
#define _DCL_ANYOPS_rmsRcpTmpNameID_struct
#define _DCL_ANYOPS_rmsRcpTemplateNameIDSeq
#define _DCL_ANYOPS_rmsRcpTemplateNameIDInqResult_struct
#define _DCL_ANYOPS_rmsRcpTmpItems_struct
#define _DCL_ANYOPS_rmsRcpTemplateItemsSeq
#define _DCL_ANYOPS_rmsRcpItemValue_struct
#define _DCL_ANYOPS_rmsRcpItemValueSeq
#define _DCL_ANYOPS_rmsRcpItemValueCheckResult_struct
#define _DCL_ANYOPS_rmsSERJob_struct
#define _DCL_ANYOPS_rmsSERJobSeq
#define _DCL_ANYOPS_rmsSERJobInqResult_struct
#define _DCL_ANYOPS_RMSException
#endif //__NOTUSE_rmsstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_rmsRangeValue_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRangeValue_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRangeValue_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRangeValue_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRangeValue_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRangeValue_struct
#ifdef _DCL_ANYOPS_rmsRangeValueSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRangeValueSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRangeValueSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRangeValueSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRangeValueSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRangeValueSeq
#ifdef _DCL_ANYOPS_rmsRecipeItemValue_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeItemValue_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeItemValue_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeItemValue_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeItemValue_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeItemValue_struct
#ifdef _DCL_ANYOPS_rmsRecipeItemValueSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeItemValueSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeItemValueSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeItemValueSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeItemValueSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeItemValueSeq
#ifdef _DCL_ANYOPS_rmsRecipeBody_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeBody_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeBody_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeBody_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeBody_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeBody_struct
#ifdef _DCL_ANYOPS_rmsRecipeBodySeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeBodySeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeBodySeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeBodySeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeBodySeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeBodySeq
#ifdef _DCL_ANYOPS_rmsAuditReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsAuditReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsAuditReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsAuditReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsAuditReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsAuditReqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeUploadReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeUploadReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeUploadReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeUploadReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeUploadReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeUploadReqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeCheckOutReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeCheckOutReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeCheckOutReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeCheckOutReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeCheckOutReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeCheckOutReqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeCheckInReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeCheckInReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeCheckInReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeCheckInReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeCheckInReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeCheckInReqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeSaveReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeSaveReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeSaveReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeSaveReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeSaveReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeSaveReqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeSetGoldenReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeSetGoldenReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeSetGoldenReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeSetGoldenReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeSetGoldenReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeSetGoldenReqResult_struct
#ifdef _DCL_ANYOPS_rmsPreAuditInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsPreAuditInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsPreAuditInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsPreAuditInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsPreAuditInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsPreAuditInqResult_struct
#ifdef _DCL_ANYOPS_rmsSetDBUserPswdReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsSetDBUserPswdReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsSetDBUserPswdReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsSetDBUserPswdReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsSetDBUserPswdReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsSetDBUserPswdReqResult_struct
#ifdef _DCL_ANYOPS_rmsConstantValue_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsConstantValue_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsConstantValue_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsConstantValue_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsConstantValue_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsConstantValue_struct
#ifdef _DCL_ANYOPS_rmsConstantValueSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsConstantValueSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsConstantValueSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsConstantValueSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsConstantValueSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsConstantValueSequence
#ifdef _DCL_ANYOPS_rmsEqpConstant_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstant_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstant_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstant_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstant_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstant_struct
#ifdef _DCL_ANYOPS_rmsEqpConstantSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantSequence
#ifdef _DCL_ANYOPS_rmsEqpConstantInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantInqResult_struct
#ifdef _DCL_ANYOPS_rmsEqpConstantUploadReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantUploadReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantUploadReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantUploadReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantUploadReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantUploadReqResult_struct
#ifdef _DCL_ANYOPS_rmsEqpConstantCheckOutReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantCheckOutReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantCheckOutReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantCheckOutReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantCheckOutReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantCheckOutReqResult_struct
#ifdef _DCL_ANYOPS_rmsEqpConstantCheckInReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantCheckInReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantCheckInReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantCheckInReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantCheckInReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantCheckInReqResult_struct
#ifdef _DCL_ANYOPS_rmsEqpConstantSaveReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantSaveReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantSaveReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantSaveReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantSaveReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantSaveReqResult_struct
#ifdef _DCL_ANYOPS_rmsHistoryRecord_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsHistoryRecord_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsHistoryRecord_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsHistoryRecord_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsHistoryRecord_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsHistoryRecord_struct
#ifdef _DCL_ANYOPS_rmsHistoryRecordSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsHistoryRecordSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsHistoryRecordSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsHistoryRecordSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsHistoryRecordSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsHistoryRecordSequence
#ifdef _DCL_ANYOPS_rmsGeneralHistoryInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsGeneralHistoryInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsGeneralHistoryInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsGeneralHistoryInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsGeneralHistoryInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsGeneralHistoryInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeHistoryInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeHistoryInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeHistoryInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeHistoryInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeHistoryInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeHistoryInqResult_struct
#ifdef _DCL_ANYOPS_rmsRuleBlockItemInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleBlockItemInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleBlockItemInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleBlockItemInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleBlockItemInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleBlockItemInfo_struct
#ifdef _DCL_ANYOPS_rmsRuleBlockItemInfoSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleBlockItemInfoSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleBlockItemInfoSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleBlockItemInfoSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleBlockItemInfoSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleBlockItemInfoSeq
#ifdef _DCL_ANYOPS_rmsRuleBlockInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleBlockInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleBlockInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleBlockInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleBlockInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleBlockInfo_struct
#ifdef _DCL_ANYOPS_rmsRuleBlockInfoSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleBlockInfoSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleBlockInfoSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleBlockInfoSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleBlockInfoSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleBlockInfoSeq
#ifdef _DCL_ANYOPS_rmsRuleInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleInfo_struct
#ifdef _DCL_ANYOPS_rmsRuleRelationInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleRelationInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleRelationInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleRelationInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleRelationInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleRelationInfo_struct
#ifdef _DCL_ANYOPS_rmsRuleRelationInfoSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleRelationInfoSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleRelationInfoSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleRelationInfoSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleRelationInfoSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleRelationInfoSeq
#ifdef _DCL_ANYOPS_rmsRuleRelationSetReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleRelationSetReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleRelationSetReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleRelationSetReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleRelationSetReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleRelationSetReqResult_struct
#ifdef _DCL_ANYOPS_rmsRuleRelationListResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleRelationListResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleRelationListResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleRelationListResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleRelationListResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleRelationListResult_struct
#ifdef _DCL_ANYOPS_rmsRuleDefinitionSetReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleDefinitionSetReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleDefinitionSetReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleDefinitionSetReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleDefinitionSetReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleDefinitionSetReqResult_struct
#ifdef _DCL_ANYOPS_rmsRuleDefinitionCheckOutReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleDefinitionCheckOutReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleDefinitionCheckOutReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleDefinitionCheckOutReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleDefinitionCheckOutReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleDefinitionCheckOutReqResult_struct
#ifdef _DCL_ANYOPS_rmsRuleDefinitionCheckInReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleDefinitionCheckInReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleDefinitionCheckInReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleDefinitionCheckInReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleDefinitionCheckInReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleDefinitionCheckInReqResult_struct
#ifdef _DCL_ANYOPS_rmsRuleDefinitionListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleDefinitionListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleDefinitionListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleDefinitionListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleDefinitionListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleDefinitionListInqResult_struct
#ifdef _DCL_ANYOPS_rmsRuleDefinitionInfoInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleDefinitionInfoInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleDefinitionInfoInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleDefinitionInfoInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleDefinitionInfoInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleDefinitionInfoInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeDeleteReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeDeleteReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeDeleteReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeDeleteReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeDeleteReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeDeleteReqResult_struct
#ifdef _DCL_ANYOPS_rmsRuleRelationDeleteReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleRelationDeleteReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleRelationDeleteReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleRelationDeleteReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleRelationDeleteReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleRelationDeleteReqResult_struct
#ifdef _DCL_ANYOPS_rmsRuleDefinitionDeleteReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRuleDefinitionDeleteReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRuleDefinitionDeleteReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRuleDefinitionDeleteReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRuleDefinitionDeleteReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRuleDefinitionDeleteReqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeInfo_struct
#ifdef _DCL_ANYOPS_rmsRecipeInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeInfoSequence
#ifdef _DCL_ANYOPS_rmsRecipeDeleteCheckInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeDeleteCheckInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeDeleteCheckInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeDeleteCheckInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeDeleteCheckInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeDeleteCheckInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeUsedByCheckInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeUsedByCheckInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeUsedByCheckInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeUsedByCheckInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeUsedByCheckInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeUsedByCheckInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeCopydFromGoldenReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeCopydFromGoldenReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeCopydFromGoldenReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeCopydFromGoldenReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeCopydFromGoldenReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeCopydFromGoldenReqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeUploadAllFromGoldenWithLimitReqResult_struct
#ifdef _DCL_ANYOPS_rmsGoldenViewEqpListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsGoldenViewEqpListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsGoldenViewEqpListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsGoldenViewEqpListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsGoldenViewEqpListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsGoldenViewEqpListInqResult_struct
#ifdef _DCL_ANYOPS_rmsAlarmEventParameter_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsAlarmEventParameter_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsAlarmEventParameter_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsAlarmEventParameter_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsAlarmEventParameter_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsAlarmEventParameter_struct
#ifdef _DCL_ANYOPS_rmsAlarmEventParameterSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsAlarmEventParameterSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsAlarmEventParameterSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsAlarmEventParameterSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsAlarmEventParameterSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsAlarmEventParameterSequence
#ifdef _DCL_ANYOPS_rmsChildRecipeInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsChildRecipeInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsChildRecipeInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsChildRecipeInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsChildRecipeInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsChildRecipeInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeLeaf_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeLeaf_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeLeaf_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeLeaf_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeLeaf_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeLeaf_struct
#ifdef _DCL_ANYOPS_rmsRecipeLeafSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeLeafSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeLeafSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeLeafSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeLeafSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeLeafSequence
#ifdef _DCL_ANYOPS_rmsRecipeTreeInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeTreeInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeTreeInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeTreeInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeTreeInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeTreeInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeLimitCopyReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeLimitCopyReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeLimitCopyReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeLimitCopyReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeLimitCopyReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeLimitCopyReqResult_struct
#ifdef _DCL_ANYOPS_rmsChildRecipeUploadReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsChildRecipeUploadReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsChildRecipeUploadReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsChildRecipeUploadReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsChildRecipeUploadReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsChildRecipeUploadReqResult_struct
#ifdef _DCL_ANYOPS_rmsMiscInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsMiscInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsMiscInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsMiscInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsMiscInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsMiscInqResult_struct
#ifdef _DCL_ANYOPS_rmsResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsResult_struct
#ifdef _DCL_ANYOPS_rmsMiscPair_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsMiscPair_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsMiscPair_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsMiscPair_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsMiscPair_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsMiscPair_struct
#ifdef _DCL_ANYOPS_rmsMiscPairSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsMiscPairSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsMiscPairSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsMiscPairSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsMiscPairSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsMiscPairSeq
#ifdef _DCL_ANYOPS_rmsMiscPairInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsMiscPairInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsMiscPairInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsMiscPairInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsMiscPairInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsMiscPairInqResult_struct
#ifdef _DCL_ANYOPS_rmsMandPRecipeInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsMandPRecipeInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsMandPRecipeInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsMandPRecipeInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsMandPRecipeInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsMandPRecipeInfo_struct
#ifdef _DCL_ANYOPS_rmsMandPRecipeInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsMandPRecipeInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsMandPRecipeInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsMandPRecipeInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsMandPRecipeInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsMandPRecipeInfoSequence
#ifdef _DCL_ANYOPS_rmsEqpRelatedRecipeAllInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpRelatedRecipeAllInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpRelatedRecipeAllInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpRelatedRecipeAllInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpRelatedRecipeAllInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpRelatedRecipeAllInqResult_struct
#ifdef _DCL_ANYOPS_rmsBatchJob_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsBatchJob_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsBatchJob_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsBatchJob_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsBatchJob_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsBatchJob_struct
#ifdef _DCL_ANYOPS_rmsBatchJobSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsBatchJobSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsBatchJobSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsBatchJobSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsBatchJobSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsBatchJobSeq
#ifdef _DCL_ANYOPS_rmsBatchJobInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsBatchJobInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsBatchJobInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsBatchJobInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsBatchJobInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsBatchJobInqResult_struct
#ifdef _DCL_ANYOPS_rmsEqpBatchJobRunTimeInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpBatchJobRunTimeInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpBatchJobRunTimeInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpBatchJobRunTimeInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpBatchJobRunTimeInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpBatchJobRunTimeInfo_struct
#ifdef _DCL_ANYOPS_rmsEqpBatchJobRunTimeInfoSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpBatchJobRunTimeInfoSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpBatchJobRunTimeInfoSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpBatchJobRunTimeInfoSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpBatchJobRunTimeInfoSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpBatchJobRunTimeInfoSeq
#ifdef _DCL_ANYOPS_rmsBatchJobRunTimeInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsBatchJobRunTimeInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsBatchJobRunTimeInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsBatchJobRunTimeInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsBatchJobRunTimeInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsBatchJobRunTimeInfo_struct
#ifdef _DCL_ANYOPS_rmsEqpProfile_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpProfile_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpProfile_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpProfile_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpProfile_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpProfile_struct
#ifdef _DCL_ANYOPS_rmsEqpProfileSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpProfileSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpProfileSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpProfileSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpProfileSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpProfileSeq
#ifdef _DCL_ANYOPS_rmsEqpProfileInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpProfileInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpProfileInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpProfileInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpProfileInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpProfileInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeProfile_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeProfile_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeProfile_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeProfile_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeProfile_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeProfile_struct
#ifdef _DCL_ANYOPS_rmsRecipeProfileSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeProfileSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeProfileSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeProfileSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeProfileSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeProfileSeq
#ifdef _DCL_ANYOPS_rmsRecipeProfileInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeProfileInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeProfileInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeProfileInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeProfileInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeProfileInqResult_struct
#ifdef _DCL_ANYOPS_rmsAuditFailInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsAuditFailInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsAuditFailInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsAuditFailInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsAuditFailInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsAuditFailInfo_struct
#ifdef _DCL_ANYOPS_rmsAuditFailInfoSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsAuditFailInfoSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsAuditFailInfoSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsAuditFailInfoSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsAuditFailInfoSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsAuditFailInfoSeq
#ifdef _DCL_ANYOPS_rmsAuditFailInfoInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsAuditFailInfoInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsAuditFailInfoInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsAuditFailInfoInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsAuditFailInfoInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsAuditFailInfoInqResult_struct
#ifdef _DCL_ANYOPS_rmsReGoldenInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsReGoldenInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsReGoldenInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsReGoldenInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsReGoldenInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsReGoldenInfo_struct
#ifdef _DCL_ANYOPS_rmsReGoldenInfoSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsReGoldenInfoSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsReGoldenInfoSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsReGoldenInfoSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsReGoldenInfoSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsReGoldenInfoSeq
#ifdef _DCL_ANYOPS_rmsReGoldenInfoInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsReGoldenInfoInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsReGoldenInfoInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsReGoldenInfoInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsReGoldenInfoInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsReGoldenInfoInqResult_struct
#ifdef _DCL_ANYOPS_rmsEnvVariable_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEnvVariable_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEnvVariable_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEnvVariable_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEnvVariable_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEnvVariable_struct
#ifdef _DCL_ANYOPS_rmsEnvVariableSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEnvVariableSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEnvVariableSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEnvVariableSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEnvVariableSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEnvVariableSeq
#ifdef _DCL_ANYOPS_rmsEnvVariableInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEnvVariableInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEnvVariableInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEnvVariableInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEnvVariableInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEnvVariableInqResult_struct
#ifdef _DCL_ANYOPS_rmsParentRecipe_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsParentRecipe_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsParentRecipe_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsParentRecipe_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsParentRecipe_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsParentRecipe_struct
#ifdef _DCL_ANYOPS_rmsParentRecipeSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsParentRecipeSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsParentRecipeSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsParentRecipeSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsParentRecipeSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsParentRecipeSeq
#ifdef _DCL_ANYOPS_rmsParentRecipeSeqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsParentRecipeSeqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsParentRecipeSeqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsParentRecipeSeqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsParentRecipeSeqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsParentRecipeSeqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeNode_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeNode_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeNode_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeNode_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeNode_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeNode_struct
#ifdef _DCL_ANYOPS_rmsRecipeNodeSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeNodeSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeNodeSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeNodeSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeNodeSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeNodeSeq
#ifdef _DCL_ANYOPS_rmsRecipeByLevel_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeByLevel_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeByLevel_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeByLevel_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeByLevel_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeByLevel_struct
#ifdef _DCL_ANYOPS_rmsRecipeByLevelSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeByLevelSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeByLevelSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeByLevelSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeByLevelSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeByLevelSeq
#ifdef _DCL_ANYOPS_rmsEqpRecipeByLevelInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpRecipeByLevelInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpRecipeByLevelInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpRecipeByLevelInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpRecipeByLevelInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpRecipeByLevelInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeRelationInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeRelationInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeRelationInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeRelationInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeRelationInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeRelationInqResult_struct
#ifdef _DCL_ANYOPS_rmsBulletinRecord_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsBulletinRecord_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsBulletinRecord_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsBulletinRecord_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsBulletinRecord_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsBulletinRecord_struct
#ifdef _DCL_ANYOPS_rmsBulletinRecordSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsBulletinRecordSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsBulletinRecordSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsBulletinRecordSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsBulletinRecordSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsBulletinRecordSequence
#ifdef _DCL_ANYOPS_rmsBulletinListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsBulletinListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsBulletinListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsBulletinListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsBulletinListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsBulletinListInqResult_struct
#ifdef _DCL_ANYOPS_rmsRIMJob_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRIMJob_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRIMJob_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRIMJob_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRIMJob_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRIMJob_struct
#ifdef _DCL_ANYOPS_rmsRIMJobSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRIMJobSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRIMJobSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRIMJobSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRIMJobSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRIMJobSeq
#ifdef _DCL_ANYOPS_rmsRIMJobInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRIMJobInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRIMJobInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRIMJobInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRIMJobInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRIMJobInqResult_struct
#ifdef _DCL_ANYOPS_rmsUATData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsUATData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsUATData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsUATData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsUATData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsUATData_struct
#ifdef _DCL_ANYOPS_rmsUATDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsUATDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsUATDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsUATDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsUATDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsUATDataSeq
#ifdef _DCL_ANYOPS_rmsUATDataInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsUATDataInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsUATDataInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsUATDataInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsUATDataInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsUATDataInqResult_struct
#ifdef _DCL_ANYOPS_rmsHoldDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsHoldDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsHoldDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsHoldDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsHoldDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsHoldDataSeq
#ifdef _DCL_ANYOPS_rmsHoldDataInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsHoldDataInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsHoldDataInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsHoldDataInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsHoldDataInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsHoldDataInqResult_struct
#ifdef _DCL_ANYOPS_rmsLabelData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLabelData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLabelData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLabelData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLabelData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLabelData_struct
#ifdef _DCL_ANYOPS_rmsLabelDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLabelDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLabelDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLabelDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLabelDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLabelDataSeq
#ifdef _DCL_ANYOPS_rmsLabelDataInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLabelDataInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLabelDataInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLabelDataInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLabelDataInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLabelDataInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeLabelData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeLabelData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeLabelData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeLabelData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeLabelData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeLabelData_struct
#ifdef _DCL_ANYOPS_rmsRecipeLabelDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeLabelDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeLabelDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeLabelDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeLabelDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeLabelDataSeq
#ifdef _DCL_ANYOPS_rmsRecipeLabelDataInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeLabelDataInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeLabelDataInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeLabelDataInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeLabelDataInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeLabelDataInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeLabelTreeSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeLabelTreeSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeLabelTreeSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeLabelTreeSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeLabelTreeSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeLabelTreeSeq
#ifdef _DCL_ANYOPS_rmsRecipeLabelTreeInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeLabelTreeInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeLabelTreeInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeLabelTreeInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeLabelTreeInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeLabelTreeInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeChange_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeChange_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeChange_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeChange_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeChange_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeChange_struct
#ifdef _DCL_ANYOPS_rmsRecipeChangeSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeChangeSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeChangeSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeChangeSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeChangeSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeChangeSeq
#ifdef _DCL_ANYOPS_rmsRecipeChangeInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeChangeInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeChangeInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeChangeInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeChangeInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeChangeInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcipeMatchedInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcipeMatchedInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcipeMatchedInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcipeMatchedInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcipeMatchedInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcipeMatchedInqResult_struct
#ifdef _DCL_ANYOPS_rmsECBatch_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECBatch_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECBatch_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECBatch_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECBatch_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECBatch_struct
#ifdef _DCL_ANYOPS_rmsECBatchSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECBatchSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECBatchSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECBatchSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECBatchSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECBatchSeq
#ifdef _DCL_ANYOPS_rmsECBatchInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECBatchInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECBatchInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECBatchInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECBatchInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECBatchInqResult_struct
#ifdef _DCL_ANYOPS_rmsECBatchAuditFailInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECBatchAuditFailInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECBatchAuditFailInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECBatchAuditFailInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECBatchAuditFailInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECBatchAuditFailInfo_struct
#ifdef _DCL_ANYOPS_rmsECBatchAuditFailSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECBatchAuditFailSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECBatchAuditFailSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECBatchAuditFailSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECBatchAuditFailSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECBatchAuditFailSeq
#ifdef _DCL_ANYOPS_rmsECBatchAuditFailInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECBatchAuditFailInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECBatchAuditFailInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECBatchAuditFailInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECBatchAuditFailInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECBatchAuditFailInqResult_struct
#ifdef _DCL_ANYOPS_csLotAttrForAudit_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotAttrForAudit_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotAttrForAudit_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotAttrForAudit_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotAttrForAudit_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLotAttrForAudit_struct
#ifdef _DCL_ANYOPS_csLotAttrForAuditSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotAttrForAuditSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotAttrForAuditSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotAttrForAuditSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotAttrForAuditSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csLotAttrForAuditSequence
#ifdef _DCL_ANYOPS_rmsLotAuditSkip_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLotAuditSkip_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLotAuditSkip_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLotAuditSkip_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLotAuditSkip_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLotAuditSkip_struct
#ifdef _DCL_ANYOPS_rmsLotAuditSkipSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLotAuditSkipSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLotAuditSkipSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLotAuditSkipSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLotAuditSkipSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLotAuditSkipSeq
#ifdef _DCL_ANYOPS_rmsLotAuditSkipInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLotAuditSkipInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLotAuditSkipInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLotAuditSkipInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLotAuditSkipInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLotAuditSkipInqResult_struct
#ifdef _DCL_ANYOPS_rmsEqpConstantBlock_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantBlock_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantBlock_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantBlock_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantBlock_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantBlock_struct
#ifdef _DCL_ANYOPS_rmsEqpConstantBlockSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantBlockSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantBlockSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantBlockSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantBlockSequence*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantBlockSequence
#ifdef _DCL_ANYOPS_rmsEqpConstantBlockInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpConstantBlockInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpConstantBlockInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpConstantBlockInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpConstantBlockInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpConstantBlockInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpBatch_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpBatch_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpBatch_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpBatch_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpBatch_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpBatch_struct
#ifdef _DCL_ANYOPS_rmsRcpBatchSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpBatchSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpBatchSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpBatchSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpBatchSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpBatchSeq
#ifdef _DCL_ANYOPS_rmsRcpBatchInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpBatchInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpBatchInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpBatchInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpBatchInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpBatchInqResult_struct
#ifdef _DCL_ANYOPS_rmsUserPrivilege_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsUserPrivilege_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsUserPrivilege_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsUserPrivilege_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsUserPrivilege_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsUserPrivilege_struct
#ifdef _DCL_ANYOPS_rmsUserPrivilegeSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsUserPrivilegeSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsUserPrivilegeSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsUserPrivilegeSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsUserPrivilegeSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsUserPrivilegeSeq
#ifdef _DCL_ANYOPS_rmsUserPrivilegeInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsUserPrivilegeInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsUserPrivilegeInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsUserPrivilegeInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsUserPrivilegeInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsUserPrivilegeInqResult_struct
#ifdef _DCL_ANYOPS_rmsPrivilege_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsPrivilege_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsPrivilege_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsPrivilege_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsPrivilege_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsPrivilege_struct
#ifdef _DCL_ANYOPS_rmsPrivilegeSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsPrivilegeSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsPrivilegeSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsPrivilegeSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsPrivilegeSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsPrivilegeSeq
#ifdef _DCL_ANYOPS_rmsPrivilegeInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsPrivilegeInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsPrivilegeInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsPrivilegeInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsPrivilegeInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsPrivilegeInqResult_struct
#ifdef _DCL_ANYOPS_rmsPrivilegeLevel_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsPrivilegeLevel_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsPrivilegeLevel_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsPrivilegeLevel_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsPrivilegeLevel_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsPrivilegeLevel_struct
#ifdef _DCL_ANYOPS_rmsPrivilegeLevelSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsPrivilegeLevelSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsPrivilegeLevelSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsPrivilegeLevelSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsPrivilegeLevelSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsPrivilegeLevelSeq
#ifdef _DCL_ANYOPS_rmsPrivilegeLevelInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsPrivilegeLevelInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsPrivilegeLevelInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsPrivilegeLevelInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsPrivilegeLevelInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsPrivilegeLevelInqResult_struct
#ifdef _DCL_ANYOPS_rmsEqpStatusChangeFlag_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpStatusChangeFlag_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpStatusChangeFlag_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpStatusChangeFlag_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpStatusChangeFlag_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpStatusChangeFlag_struct
#ifdef _DCL_ANYOPS_rmsEqpStatusChangeFlagSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpStatusChangeFlagSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpStatusChangeFlagSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpStatusChangeFlagSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpStatusChangeFlagSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpStatusChangeFlagSeq
#ifdef _DCL_ANYOPS_rmsEqpStatusChangeFlagResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpStatusChangeFlagResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpStatusChangeFlagResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpStatusChangeFlagResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpStatusChangeFlagResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpStatusChangeFlagResult_struct
#ifdef _DCL_ANYOPS_rmsEDMJob_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEDMJob_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEDMJob_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEDMJob_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEDMJob_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEDMJob_struct
#ifdef _DCL_ANYOPS_rmsEDMJobSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEDMJobSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEDMJobSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEDMJobSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEDMJobSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEDMJobSeq
#ifdef _DCL_ANYOPS_rmsEDMJobInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEDMJobInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEDMJobInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEDMJobInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEDMJobInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEDMJobInqResult_struct
#ifdef _DCL_ANYOPS_rmsForceAuditHistory_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsForceAuditHistory_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsForceAuditHistory_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsForceAuditHistory_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsForceAuditHistory_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsForceAuditHistory_struct
#ifdef _DCL_ANYOPS_rmsForceAuditHistorySeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsForceAuditHistorySeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsForceAuditHistorySeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsForceAuditHistorySeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsForceAuditHistorySeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsForceAuditHistorySeq
#ifdef _DCL_ANYOPS_rmsForceAuditHistoryInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsForceAuditHistoryInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsForceAuditHistoryInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsForceAuditHistoryInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsForceAuditHistoryInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsForceAuditHistoryInqResult_struct
#ifdef _DCL_ANYOPS_rmsECIMJob_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECIMJob_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECIMJob_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECIMJob_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECIMJob_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECIMJob_struct
#ifdef _DCL_ANYOPS_rmsECIMJobSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECIMJobSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECIMJobSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECIMJobSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECIMJobSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECIMJobSeq
#ifdef _DCL_ANYOPS_rmsECIMJobInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECIMJobInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECIMJobInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECIMJobInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECIMJobInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECIMJobInqResult_struct
#ifdef _DCL_ANYOPS_rmsECUATData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECUATData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECUATData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECUATData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECUATData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECUATData_struct
#ifdef _DCL_ANYOPS_rmsECUATDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECUATDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECUATDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECUATDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECUATDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECUATDataSeq
#ifdef _DCL_ANYOPS_rmsECUATDataInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsECUATDataInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsECUATDataInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsECUATDataInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsECUATDataInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsECUATDataInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpEvdSaveReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpEvdSaveReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpEvdSaveReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpEvdSaveReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpEvdSaveReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpEvdSaveReqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpEvdDetailInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpEvdDetailInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpEvdDetailInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpEvdDetailInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpEvdDetailInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpEvdDetailInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpExamSaveReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpExamSaveReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpExamSaveReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpExamSaveReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpExamSaveReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpExamSaveReqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpExamData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpExamData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpExamData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpExamData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpExamData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpExamData_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpExamDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpExamDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpExamDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpExamDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpExamDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpExamDataSeq
#ifdef _DCL_ANYOPS_rmsRcpCmpExamInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpExamInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpExamInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpExamInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpExamInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpExamInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpExamDetailData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpExamDetailData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpExamDetailData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpExamDetailData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpExamDetailData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpExamDetailData_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpExamDetailDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpExamDetailDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpExamDetailDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpExamDetailDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpExamDetailDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpExamDetailDataSeq
#ifdef _DCL_ANYOPS_rmsRcpCmpExamDetailInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpExamDetailInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpExamDetailInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpExamDetailInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpExamDetailInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpExamDetailInqResult_struct
#ifdef _DCL_ANYOPS_rmsRecipeGolden_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeGolden_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeGolden_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeGolden_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeGolden_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeGolden_struct
#ifdef _DCL_ANYOPS_rmsRecipeGoldenSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeGoldenSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeGoldenSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeGoldenSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeGoldenSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeGoldenSeq
#ifdef _DCL_ANYOPS_rmsRecipeGoldenInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRecipeGoldenInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRecipeGoldenInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRecipeGoldenInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRecipeGoldenInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRecipeGoldenInqResult_struct
#ifdef _DCL_ANYOPS_rmsGeneralConfig_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsGeneralConfig_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsGeneralConfig_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsGeneralConfig_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsGeneralConfig_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsGeneralConfig_struct
#ifdef _DCL_ANYOPS_rmsGeneralConfigSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsGeneralConfigSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsGeneralConfigSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsGeneralConfigSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsGeneralConfigSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsGeneralConfigSeq
#ifdef _DCL_ANYOPS_rmsGeneralConfigInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsGeneralConfigInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsGeneralConfigInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsGeneralConfigInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsGeneralConfigInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsGeneralConfigInqResult_struct
#ifdef _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpAuditFlagAutoTurnOnData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpAuditFlagAutoTurnOnData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpAuditFlagAutoTurnOnData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpAuditFlagAutoTurnOnData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnData_struct
#ifdef _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpAuditFlagAutoTurnOnDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpAuditFlagAutoTurnOnDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpAuditFlagAutoTurnOnDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpAuditFlagAutoTurnOnDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnDataSeq
#ifdef _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpAuditFlagAutoTurnOnInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpAuditFlagAutoTurnOnInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpAuditFlagAutoTurnOnInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpAuditFlagAutoTurnOnInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpAuditFlagAutoTurnOnInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpData_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpDataSeq
#ifdef _DCL_ANYOPS_rmsRcpCmpInqList_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpInqList_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpInqList_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpInqList_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpInqList_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpInqList_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpInqListSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpInqListSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpInqListSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpInqListSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpInqListSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpInqListSeq
#ifdef _DCL_ANYOPS_rmsRcpCmpInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpBatchSaveReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpBatchSaveReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpBatchSaveReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpBatchSaveReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpBatchSaveReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpBatchSaveReqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpBatchUpdateReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpBatchUpdateReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpBatchUpdateReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpBatchUpdateReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpBatchUpdateReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpBatchUpdateReqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpBatchDeleteReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpBatchDeleteReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpBatchDeleteReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpBatchDeleteReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpBatchDeleteReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpBatchDeleteReqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpBatchData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpBatchData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpBatchData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpBatchData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpBatchData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpBatchData_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpBatchDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpBatchDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpBatchDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpBatchDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpBatchDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpBatchDataSeq
#ifdef _DCL_ANYOPS_rmsRcpCmpBatchInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpBatchInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpBatchInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpBatchInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpBatchInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpBatchInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpPairData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpPairData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpPairData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpPairData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpPairData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpPairData_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpPairDataSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpPairDataSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpPairDataSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpPairDataSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpPairDataSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpPairDataSeq
#ifdef _DCL_ANYOPS_rmsRcpCmpPairInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpPairInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpPairInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpPairInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpPairInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpPairInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpPairNoInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpPairNoInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpPairNoInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpPairNoInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpPairNoInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpPairNoInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpPairAddReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpPairAddReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpPairAddReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpPairAddReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpPairAddReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpPairAddReqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpPairUpdateReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpPairUpdateReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpPairUpdateReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpPairUpdateReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpPairUpdateReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpPairUpdateReqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpPairList_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpPairList_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpPairList_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpPairList_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpPairList_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpPairList_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpPairListSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpPairListSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpPairListSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpPairListSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpPairListSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpPairListSeq
#ifdef _DCL_ANYOPS_rmsRcpCmpResultInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpResultInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpResultInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpResultInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpResultInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpResultInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpCmpSaveReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpCmpSaveReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpCmpSaveReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpCmpSaveReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpCmpSaveReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpCmpSaveReqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpBatchCnt_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpBatchCnt_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpBatchCnt_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpBatchCnt_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpBatchCnt_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpBatchCnt_struct
#ifdef _DCL_ANYOPS_rmsRcpBatchCntSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpBatchCntSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpBatchCntSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpBatchCntSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpBatchCntSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpBatchCntSeq
#ifdef _DCL_ANYOPS_rmsRcpBatchCntInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpBatchCntInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpBatchCntInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpBatchCntInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpBatchCntInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpBatchCntInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpAFI_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpAFI_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpAFI_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpAFI_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpAFI_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpAFI_struct
#ifdef _DCL_ANYOPS_rmsRcpAuditFailInhibitJobSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpAuditFailInhibitJobSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpAuditFailInhibitJobSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpAuditFailInhibitJobSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpAuditFailInhibitJobSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpAuditFailInhibitJobSeq
#ifdef _DCL_ANYOPS_rmsRcpAFIInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpAFIInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpAFIInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpAFIInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpAFIInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpAFIInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpChgAuditInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpChgAuditInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpChgAuditInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpChgAuditInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpChgAuditInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpChgAuditInfo_struct
#ifdef _DCL_ANYOPS_rmsRcpChgAuditResultSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpChgAuditResultSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpChgAuditResultSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpChgAuditResultSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpChgAuditResultSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpChgAuditResultSeq
#ifdef _DCL_ANYOPS_rmsRcpChgAuditResultInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpChgAuditResultInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpChgAuditResultInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpChgAuditResultInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpChgAuditResultInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpChgAuditResultInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpAutoLabelInqInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpAutoLabelInqInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpAutoLabelInqInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpAutoLabelInqInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpAutoLabelInqInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpAutoLabelInqInfo_struct
#ifdef _DCL_ANYOPS_rmsRcpAutoLabelAllInqResultSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpAutoLabelAllInqResultSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpAutoLabelAllInqResultSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpAutoLabelAllInqResultSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpAutoLabelAllInqResultSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpAutoLabelAllInqResultSeq
#ifdef _DCL_ANYOPS_rmsEqpRecipeAutoLabelAllInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpRecipeAutoLabelAllInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpRecipeAutoLabelAllInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpRecipeAutoLabelAllInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpRecipeAutoLabelAllInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpRecipeAutoLabelAllInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpLabelRuleInqInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpLabelRuleInqInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpLabelRuleInqInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpLabelRuleInqInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpLabelRuleInqInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpLabelRuleInqInfo_struct
#ifdef _DCL_ANYOPS_rmsRcpLabelRuleInqResultSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpLabelRuleInqResultSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpLabelRuleInqResultSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpLabelRuleInqResultSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpLabelRuleInqResultSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpLabelRuleInqResultSeq
#ifdef _DCL_ANYOPS_rmsEqpRcpLabelRuleInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsEqpRcpLabelRuleInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsEqpRcpLabelRuleInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsEqpRcpLabelRuleInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsEqpRcpLabelRuleInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsEqpRcpLabelRuleInqResult_struct
#ifdef _DCL_ANYOPS_rmsProRcpAuditRuleInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsProRcpAuditRuleInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsProRcpAuditRuleInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsProRcpAuditRuleInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsProRcpAuditRuleInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsProRcpAuditRuleInfo_struct
#ifdef _DCL_ANYOPS_rmsProdRcpAuditRuleSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsProdRcpAuditRuleSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsProdRcpAuditRuleSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsProdRcpAuditRuleSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsProdRcpAuditRuleSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsProdRcpAuditRuleSeq
#ifdef _DCL_ANYOPS_rmsProRcpAuditRuleInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsProRcpAuditRuleInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsProRcpAuditRuleInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsProRcpAuditRuleInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsProRcpAuditRuleInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsProRcpAuditRuleInqResult_struct
#ifdef _DCL_ANYOPS_rmsLoadMapRecipeInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLoadMapRecipeInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLoadMapRecipeInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLoadMapRecipeInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLoadMapRecipeInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLoadMapRecipeInfo_struct
#ifdef _DCL_ANYOPS_rmsLoadMapRecipeInfoSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLoadMapRecipeInfoSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLoadMapRecipeInfoSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLoadMapRecipeInfoSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLoadMapRecipeInfoSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLoadMapRecipeInfoSeq
#ifdef _DCL_ANYOPS_rmsLoadMapRecipeInfoResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsLoadMapRecipeInfoResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsLoadMapRecipeInfoResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsLoadMapRecipeInfoResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsLoadMapRecipeInfoResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsLoadMapRecipeInfoResult_struct
#ifdef _DCL_ANYOPS_rmsRcpTmpNameID_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpTmpNameID_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpTmpNameID_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpTmpNameID_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpTmpNameID_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpTmpNameID_struct
#ifdef _DCL_ANYOPS_rmsRcpTemplateNameIDSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpTemplateNameIDSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpTemplateNameIDSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpTemplateNameIDSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpTemplateNameIDSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpTemplateNameIDSeq
#ifdef _DCL_ANYOPS_rmsRcpTemplateNameIDInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpTemplateNameIDInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpTemplateNameIDInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpTemplateNameIDInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpTemplateNameIDInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpTemplateNameIDInqResult_struct
#ifdef _DCL_ANYOPS_rmsRcpTmpItems_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpTmpItems_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpTmpItems_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpTmpItems_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpTmpItems_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpTmpItems_struct
#ifdef _DCL_ANYOPS_rmsRcpTemplateItemsSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpTemplateItemsSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpTemplateItemsSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpTemplateItemsSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpTemplateItemsSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpTemplateItemsSeq
#ifdef _DCL_ANYOPS_rmsRcpItemValue_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpItemValue_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpItemValue_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpItemValue_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpItemValue_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpItemValue_struct
#ifdef _DCL_ANYOPS_rmsRcpItemValueSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpItemValueSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpItemValueSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpItemValueSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpItemValueSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpItemValueSeq
#ifdef _DCL_ANYOPS_rmsRcpItemValueCheckResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsRcpItemValueCheckResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsRcpItemValueCheckResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsRcpItemValueCheckResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsRcpItemValueCheckResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsRcpItemValueCheckResult_struct
#ifdef _DCL_ANYOPS_rmsSERJob_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsSERJob_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsSERJob_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsSERJob_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsSERJob_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsSERJob_struct
#ifdef _DCL_ANYOPS_rmsSERJobSeq
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsSERJobSeq &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsSERJobSeq *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsSERJobSeq*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsSERJobSeq*& _data);
#endif
#endif // _DCL_ANYOPS_rmsSERJobSeq
#ifdef _DCL_ANYOPS_rmsSERJobInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::rmsSERJobInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::rmsSERJobInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::rmsSERJobInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::rmsSERJobInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_rmsSERJobInqResult_struct
#ifdef _DCL_ANYOPS_RMSException
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::RMSException &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::RMSException *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::RMSException*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::RMSException*& _data);
#endif
#endif // _DCL_ANYOPS_RMSException

#endif /* _rmsstr_hh_included */

#endif /* _rmsstr_server_defined */
