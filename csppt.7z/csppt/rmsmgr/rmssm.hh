//----------------------------------------------------------------------------
//
//  Generated from rmssm.idl
//  On Tuesday, November 14, 2017 11:59:49 AM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _rmssm_server_defined
#ifndef _rmssm_hh_included
#define _rmssm_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif
#ifndef _DCL_RMServiceManager_SOM_IMPORTEXPORT
#define _DCL_RMServiceManager_SOM_IMPORTEXPORT 
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifdef SOMCBNOLOCALINCLUDES
#ifndef _rmsstr_hh_included
#include <rmsstr.hh>
#endif
#else
#ifndef _rmsstr_hh_included
#include "rmsstr.hh"
#endif
#endif

// Begin mapping for interface ::RMServiceManager

#ifndef _DCL_RMServiceManager
#define _DCL_RMServiceManager
#ifndef _DCL_RMServiceManager_SOM_IMPORTEXPORT
#define _DCL_RMServiceManager_SOM_IMPORTEXPORT 
#endif
class _DCL_RMServiceManager_SOM_IMPORTEXPORT
   RMServiceManager
    ;
class _DCL_RMServiceManager_SOM_IMPORTEXPORT RMServiceManager_var;
typedef RMServiceManager* RMServiceManager_ptr;
typedef RMServiceManager* RMServiceManagerRef;

_DCL_RMServiceManager_SOM_IMPORTEXPORT CORBA::Object_ptr SOMLINK RMServiceManager_getBase(void *);

_DCL_RMServiceManager_SOM_IMPORTEXPORT RMServiceManager_ptr SOMLINK RMServiceManager_aux_duplicate(RMServiceManager_ptr);
_DCL_RMServiceManager_SOM_IMPORTEXPORT RMServiceManager_ptr SOMLINK RMServiceManager_aux_narrow(::CORBA::Object_ptr);
_DCL_RMServiceManager_SOM_IMPORTEXPORT RMServiceManager_ptr SOMLINK RMServiceManager_aux_nil();
_DCL_RMServiceManager_SOM_IMPORTEXPORT const char* SOMLINK RMServiceManager_aux_CN();

    class _DCL_RMServiceManager_SOM_IMPORTEXPORT RMServiceManager_StructElem
    {
        public:

        RMServiceManager_StructElem ();

        RMServiceManager_StructElem (const RMServiceManager_StructElem &s);

        RMServiceManager_StructElem &operator= (RMServiceManager_ptr p);

        RMServiceManager_StructElem &operator= (RMServiceManager_var v);

        RMServiceManager_StructElem &operator= (const RMServiceManager_StructElem &s);

        ~RMServiceManager_StructElem ();

        operator ::CORBA::Object_ptr() const;

        operator RMServiceManager_ptr () const;

        RMServiceManager_ptr _ptr;

    }; // RMServiceManager_StructElem

    class _DCL_RMServiceManager_SOM_IMPORTEXPORT RMServiceManager_SeqElem
    {
       public:

       RMServiceManager_SeqElem (RMServiceManager_ptr* p, unsigned char rel);

       RMServiceManager_SeqElem &operator= (RMServiceManager_ptr p);

        RMServiceManager_SeqElem &operator= (RMServiceManager_var v);

       RMServiceManager_SeqElem &operator= (const RMServiceManager_SeqElem &s);

       operator RMServiceManager_ptr () const;

       RMServiceManager_ptr operator->() const;

       protected:
       RMServiceManager_ptr *_ptr;
       unsigned char _release;
   }; // RMServiceManager_SeqElem


class  RMServiceManager_var : public ::CORBA::__vb__
{
    public:

    RMServiceManager_var ();
    RMServiceManager_var (RMServiceManager *p);
    RMServiceManager_var (const RMServiceManager_var &s);
    RMServiceManager_var (const RMServiceManager_StructElem &s);
    RMServiceManager_var (const RMServiceManager_SeqElem &s);
    RMServiceManager_var &operator= (RMServiceManager *p);
    RMServiceManager_var &operator= (const RMServiceManager_var &s);
    RMServiceManager_var &operator= (const RMServiceManager_StructElem &s);
    RMServiceManager_var &operator= (const RMServiceManager_SeqElem &s);
    ~RMServiceManager_var ();
    RMServiceManager_ptr in() const;
    RMServiceManager_ptr& inout();
    RMServiceManager_ptr& out();
    RMServiceManager_ptr _retn();
    RMServiceManager_ptr operator-> ();
    operator RMServiceManager_ptr& ();
    operator const RMServiceManager_ptr& () const;
#ifdef __sun
    operator RMServiceManager_ptr () { return _ptr; };
#endif

    protected:
       RMServiceManager *_ptr;

    private:
       ::CORBA::__vb__& operator= (::CORBA::__vb__&);

};  // RMServiceManager_var

#endif /* _DCL_RMServiceManager */ 


class 

   RMServiceManager
: virtual public ::CORBA::Object {

public: 
    static const char* RMServiceManager_CN;
    static const char* RMServiceManager_RID;
    typedef RMServiceManager_ptr _ptr_type;
    typedef RMServiceManager_var _var_type;

    /* for Orbix compatibility */
    virtual void *_deref();

protected: 
    /* constructor */

   RMServiceManager
();
protected: 
    virtual ~

   RMServiceManager
();
private: 

   RMServiceManager
    (const 
   RMServiceManager
     &); // unimplemented

    void operator=(const 
   RMServiceManager
     &); // unimplemented
public: 

    static RMServiceManager_ptr SOMLINK _duplicate(RMServiceManager_ptr obj);

    static RMServiceManager_ptr SOMLINK _narrow (::CORBA::Object_ptr);

    virtual void* _has_ancestor(const char* classname);
    static RMServiceManager_ptr SOMLINK _nil ();

    RMServiceManager_ptr _self();
    RMServiceManager_ptr _this();
    virtual void *_SOMThis(const char *& ifname);


    virtual  ::rmsRecipeUploadAllFromGoldenWithLimitReqResult*  TxRMSRecipeUploadAllFromGoldenWithLimitReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeUploadAllFromGoldenWithLimitReqResult*  _req_TxRMSRecipeUploadAllFromGoldenWithLimitReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeDeleteCheckInqResult*  TxRMSRecipeDeleteCheckInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeDeleteCheckInqResult*  _req_TxRMSRecipeDeleteCheckInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeUsedByCheckInqResult*  TxRMSRecipeUsedByCheckInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeUsedByCheckInqResult*  _req_TxRMSRecipeUsedByCheckInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleRelationDeleteReqResult*  TxRMSRuleRelationDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, ::CORBA::Long recipeDependence, const char* recipeIDPattern, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleRelationDeleteReqResult*  _req_TxRMSRuleRelationDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, ::CORBA::Long recipeDependence, const char* recipeIDPattern, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleDefinitionDeleteReqResult*  TxRMSRuleDefinitionDeleteReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleDefinitionDeleteReqResult*  _req_TxRMSRuleDefinitionDeleteReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleRelationSetReqResult*  TxRMSRuleRelationSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, ::CORBA::Long recipeDependence, const char* recipeIDPattern, const char* actionType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleRelationSetReqResult*  _req_TxRMSRuleRelationSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, ::CORBA::Long recipeDependence, const char* recipeIDPattern, const char* actionType, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleRelationListResult*  TxRMSRuleRelationListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleRelationListResult*  _req_TxRMSRuleRelationListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleDefinitionSetReqResult*  TxRMSRuleDefinitionSetReq (const ::pptUser& requestUserID, const char* ruleID, const char* ownerDept, const ::rmsRuleInfo& strRuleInfo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleDefinitionSetReqResult*  _req_TxRMSRuleDefinitionSetReq (const ::pptUser& requestUserID, const char* ruleID, const char* ownerDept, const ::rmsRuleInfo& strRuleInfo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleDefinitionCheckOutReqResult*  TxRMSRuleDefinitionCheckOutReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleDefinitionCheckOutReqResult*  _req_TxRMSRuleDefinitionCheckOutReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleDefinitionCheckInReqResult*  TxRMSRuleDefinitionCheckInReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleDefinitionCheckInReqResult*  _req_TxRMSRuleDefinitionCheckInReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleDefinitionListInqResult*  TxRMSRuleDefinitionListInq (const ::pptUser& requestUserID, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleDefinitionListInqResult*  _req_TxRMSRuleDefinitionListInq (const ::pptUser& requestUserID, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRuleDefinitionInfoInqResult*  TxRMSRuleDefinitionInfoInq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRuleDefinitionInfoInqResult*  _req_TxRMSRuleDefinitionInfoInq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeDeleteReqResult*  TxRMSRecipeDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* recipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeDeleteReqResult*  _req_TxRMSRecipeDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* recipeID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptPrivilegeCheckReqResult*  TxRMSPrivilegeCheckReqForMM (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, const ::objectIdentifierSequence& productIDs, const ::objectIdentifierSequence& routeIDs, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifierSequence& machineRecipeIDs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptPrivilegeCheckReqResult*  _req_TxRMSPrivilegeCheckReqForMM (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, const ::objectIdentifierSequence& productIDs, const ::objectIdentifierSequence& routeIDs, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifierSequence& machineRecipeIDs, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpInAuditListInqResult*  TxRMSEqpInAuditListInq (const ::pptUser& requestUserID, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpInAuditListInqResult*  _req_TxRMSEqpInAuditListInq (const ::pptUser& requestUserID, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeHistoryInqResult*  TxRMSRecipeHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeHistoryInqResult*  _req_TxRMSRecipeHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsGeneralHistoryInqResult*  TxRMSGeneralHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* compareResult, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsGeneralHistoryInqResult*  _req_TxRMSGeneralHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* compareResult, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpListByOwnerInqResult*  TxRMSEqpListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpListByOwnerInqResult*  _req_TxRMSEqpListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpInfoListByOwnerInqResult*  TxRMSEqpInfoListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpInfoListByOwnerInqResult*  _req_TxRMSEqpInfoListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptUserDataInqResult*  TxRMSUserDataSetInq (const ::pptUser& requestUserID, const ::pptUserDataInqInParm__101& strUserDataInqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptUserDataInqResult*  _req_TxRMSUserDataSetInq (const ::pptUser& requestUserID, const ::pptUserDataInqInParm__101& strUserDataInqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptUserDataUpdateReqResult*  TxRMSUserDataSetReq (const ::pptUser& requestUserID, const ::pptUserDataUpdateReqInParm& strUserDataUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptUserDataUpdateReqResult*  _req_TxRMSUserDataSetReq (const ::pptUser& requestUserID, const ::pptUserDataUpdateReqInParm& strUserDataUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptEqpInfoInqResult*  TxRMSEqpInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptEqpInfoInqResult*  _req_TxRMSEqpInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptEqpInfoForInternalBufferInqResult*  TxRMSEqpInfoForInternalBufferInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForInternalBufferInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptEqpInfoForInternalBufferInqResult*  _req_TxRMSEqpInfoForInternalBufferInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForInternalBufferInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptUserDescInqResult*  TxRMSUserDescInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptUserDescInqResult*  _req_TxRMSUserDescInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptEqpListInqResult*  TxRMSEqpListInq (const ::pptUser& requestUserID, const ::objectIdentifier& workArea, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptEqpListInqResult*  _req_TxRMSEqpListInq (const ::pptUser& requestUserID, const ::objectIdentifier& workArea, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptReasonListInqResult*  TxRMSReasonListInq (const ::pptUser& requestUserID, const char* codeCategory, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptReasonListInqResult*  _req_TxRMSReasonListInq (const ::pptUser& requestUserID, const char* codeCategory, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csPrivilegeCheckForRMSReqResult*  TxRMSPrivilegeCheckReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csPrivilegeCheckForRMSReqResult*  _req_TxRMSPrivilegeCheckReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeLimitCopyReqResult*  TxRMSRecipeLimitCopyReq (const ::pptUser& requestUserID, const ::objectIdentifier& fromEquipmentID, const ::objectIdentifier& toEquipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* claimMemo, ::CORBA::Long copyType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeLimitCopyReqResult*  _req_TxRMSRecipeLimitCopyReq (const ::pptUser& requestUserID, const ::objectIdentifier& fromEquipmentID, const ::objectIdentifier& toEquipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* claimMemo, ::CORBA::Long copyType, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptEqpRelatedRecipeIDListInqResult*  TxRMSEqpRelatedRecipeIDListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptEqpRelatedRecipeIDListInqResult*  _req_TxRMSEqpRelatedRecipeIDListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Long isGolden, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptLogOnCheckReqResult*  TxRMSLogOnCheckReq (const ::pptUser& requestUserID, const char* subSystemID, const char* categoryID, ::CORBA::Boolean bProductRequestFlag, ::CORBA::Boolean bRecipeRequestFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptLogOnCheckReqResult*  _req_TxRMSLogOnCheckReq (const ::pptUser& requestUserID, const char* subSystemID, const char* categoryID, ::CORBA::Boolean bProductRequestFlag, ::CORBA::Boolean bRecipeRequestFlag, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeInqResult*  TxRMSRecipeInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, const char* orderCondition, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeInqResult*  _req_TxRMSRecipeInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, const char* orderCondition, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeUploadReqResult*  _req_TxRMSRecipeUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeCheckOutReqResult*  TxRMSRecipeCheckOutReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeCheckOutReqResult*  _req_TxRMSRecipeCheckOutReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeCheckInReqResult*  TxRMSRecipeCheckInReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeCheckInReqResult*  _req_TxRMSRecipeCheckInReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeSaveReqResult*  TxRMSRecipeSaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const ::rmsRecipeBodySeq& parsedRecipeBodys, ::CORBA::Long isGolden, ::CORBA::Boolean reNew, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeSaveReqResult*  _req_TxRMSRecipeSaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const ::rmsRecipeBodySeq& parsedRecipeBodys, ::CORBA::Long isGolden, ::CORBA::Boolean reNew, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeSaveReqResult*  TxRMSRecipeCopySaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const ::rmsRecipeBodySeq& parsedRecipeBodys, ::CORBA::Long isGolden, ::CORBA::Boolean reNew, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeSaveReqResult*  _req_TxRMSRecipeCopySaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const ::rmsRecipeBodySeq& parsedRecipeBodys, ::CORBA::Long isGolden, ::CORBA::Boolean reNew, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeSetGoldenReqResult*  TxRMSRecipeSetGoldenReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, const char* reasonCode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeSetGoldenReqResult*  _req_TxRMSRecipeSetGoldenReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, const char* reasonCode, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpConstantInqResult*  TxRMSEqpConstantInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean isNonManagedOnly, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpConstantInqResult*  _req_TxRMSEqpConstantInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean isNonManagedOnly, const char* eqpSpecial, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpConstantUploadReqResult*  TxRMSEqpConstantUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* TCSResourceName, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpConstantUploadReqResult*  _req_TxRMSEqpConstantUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* TCSResourceName, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpConstantCheckOutReqResult*  TxRMSEqpConstantCheckOutReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpConstantCheckOutReqResult*  _req_TxRMSEqpConstantCheckOutReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpConstantCheckInReqResult*  TxRMSEqpConstantCheckInReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpConstantCheckInReqResult*  _req_TxRMSEqpConstantCheckInReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpConstantSaveReqResult*  TxRMSEqpConstantSaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Boolean reNew, const char* blockName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpConstantSaveReqResult*  _req_TxRMSEqpConstantSaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Boolean reNew, const char* blockName, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsAuditReqResult*  TxRMSAuditReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsAuditReqResult*  _req_TxRMSAuditReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsAuditReqResult*  TxRMSAuditForTCSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, const ::tcsEqpConstantSequence& theECIDs, const ::tcsEqpConstantSequence& theSVIDs, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsAuditReqResult*  _req_TxRMSAuditForTCSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, const ::tcsEqpConstantSequence& theECIDs, const ::tcsEqpConstantSequence& theSVIDs, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsPreAuditInqResult*  TxRMSPreAuditInqReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsPreAuditInqResult*  _req_TxRMSPreAuditInqReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsSetDBUserPswdReqResult*  TxRMSSetDBUserPswdReq (const ::pptUser& requestUserID, const char* newDBName, const char* newDBUser, const char* newDBPswd, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsSetDBUserPswdReqResult*  _req_TxRMSSetDBUserPswdReq (const ::pptUser& requestUserID, const char* newDBName, const char* newDBUser, const char* newDBPswd, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsGoldenViewEqpListInqResult*  TxRMSGoldenViewEqpListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsGoldenViewEqpListInqResult*  _req_TxRMSGoldenViewEqpListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeCopydFromGoldenReqResult*  TxRMSRecipeCopydFromGoldenReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeCopydFromGoldenReqResult*  _req_TxRMSRecipeCopydFromGoldenReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsChildRecipeInqResult*  TxRMSChildRecipeInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsChildRecipeInqResult*  _req_TxRMSChildRecipeInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csEqpRMSFlgInqResult*  TxRMSEqpRMSFlgInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csEqpRMSFlgInqResult*  _req_TxRMSEqpRMSFlgInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeTreeInqResult*  TxRMSRecipeTreeInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeTreeInqResult*  _req_TxRMSRecipeTreeInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsChildRecipeUploadReqResult*  TxRMSChildRecipeUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsChildRecipeUploadReqResult*  _req_TxRMSChildRecipeUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsMiscInqResult*  TxRMSMiscInq (const ::pptUser& requestUserID, const char* keyName, const char* key, const char* valueName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsMiscInqResult*  _req_TxRMSMiscInq (const ::pptUser& requestUserID, const char* keyName, const char* key, const char* valueName, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsMiscPairInqResult*  TxRMSMiscPairInq (const ::pptUser& requestUserID, const char* keyName, const char* valueName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsMiscPairInqResult*  _req_TxRMSMiscPairInq (const ::pptUser& requestUserID, const char* keyName, const char* valueName, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSMiscSaveReq (const ::pptUser& requestUserID, const char* keyName, const char* key, const char* valueName, const char* value, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSMiscSaveReq (const ::pptUser& requestUserID, const char* keyName, const char* key, const char* valueName, const char* value, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpRelatedRecipeAllInqResult*  TxRMSEqpRelatedRecipeAllInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ownerDept, ::CORBA::Boolean getUploadedFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpRelatedRecipeAllInqResult*  _req_TxRMSEqpRelatedRecipeAllInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ownerDept, ::CORBA::Boolean getUploadedFlag, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeCopyReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* fromEqp, const char* fromInline, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long goldenFlag, const char* toEqp, const char* toInline, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeCopyReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* fromEqp, const char* fromInline, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long goldenFlag, const char* toEqp, const char* toInline, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeUpdateReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long goldenFlag, const ::rmsRecipeItemValueSeq& recipeItems, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeUpdateReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long goldenFlag, const ::rmsRecipeItemValueSeq& recipeItems, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSBatchJobSetReq (const ::pptUser& requestUserID, const ::rmsBatchJobSeq& jobs, const char* ownerDept, ::CORBA::Boolean isNew, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSBatchJobSetReq (const ::pptUser& requestUserID, const ::rmsBatchJobSeq& jobs, const char* ownerDept, ::CORBA::Boolean isNew, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSBatchJobDeleteReq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* registerTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSBatchJobDeleteReq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* registerTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsBatchJobInqResult*  TxRMSBatchJobInq (const ::pptUser& requestUserID, const char* ownerDept, const char* equipmentID, const char* eqpSpecial, const char* startTime, const char* endTime, const char* userCondition, const char* resultCondition, const char* closingCondition, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsBatchJobInqResult*  _req_TxRMSBatchJobInq (const ::pptUser& requestUserID, const char* ownerDept, const char* equipmentID, const char* eqpSpecial, const char* startTime, const char* endTime, const char* userCondition, const char* resultCondition, const char* closingCondition, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsBatchJobInqResult*  TxRMSBatchJobDetailInq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* registerUser, const char* registerTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsBatchJobInqResult*  _req_TxRMSBatchJobDetailInq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* registerUser, const char* registerTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsBatchJobRunTimeInfo*  TxRMSBatchJobRunTimeInfoInq (const ::pptUser& requestUserID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsBatchJobRunTimeInfo*  _req_TxRMSBatchJobRunTimeInfoInq (const ::pptUser& requestUserID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpProfileInqResult*  TxRMSEqpProfileInq (const ::objectIdentifierSequence& eqps, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpProfileInqResult*  _req_TxRMSEqpProfileInq (const ::objectIdentifierSequence& eqps, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSEqpProfileSetReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const ::rmsEqpProfileSeq& profiles, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSEqpProfileSetReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const ::rmsEqpProfileSeq& profiles, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeProfileInqResult*  TxRMSRecipeProfileInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeProfileInqResult*  _req_TxRMSRecipeProfileInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeProfileSetReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const char* claimMemo, const ::rmsRecipeProfileSeq& profiles, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeProfileSetReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const char* claimMemo, const ::rmsRecipeProfileSeq& profiles, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeProfileDeleteReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const char* physicalRecipeID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeProfileDeleteReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const char* physicalRecipeID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSCopyToleranceFromGoldenReq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long option, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSCopyToleranceFromGoldenReq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long option, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptEntityInhibitCancelReqResult*  TxRMSEntityInhibitCancelReq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailInfoSequence& entityInhibitions, const ::objectIdentifier& reasonCode, const char* claimMemo, const char* equipmentID, const char* physicalRecipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptEntityInhibitCancelReqResult*  _req_TxRMSEntityInhibitCancelReq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailInfoSequence& entityInhibitions, const ::objectIdentifier& reasonCode, const char* claimMemo, const char* equipmentID, const char* physicalRecipeID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptEntityInhibitListInqResult__101*  TxRMSEntityInhibitListInq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailAttributes& searchCondition, ::CORBA::Boolean entityInhibitReasonDetailInfoFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptEntityInhibitListInqResult__101*  _req_TxRMSEntityInhibitListInq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailAttributes& searchCondition, ::CORBA::Boolean entityInhibitReasonDetailInfoFlag, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsAuditFailInfoInqResult*  TxRMSAuditFailInfoInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsAuditFailInfoInqResult*  _req_TxRMSAuditFailInfoInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsGeneralHistoryInqResult*  TxRMSReGoldenHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsGeneralHistoryInqResult*  _req_TxRMSReGoldenHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsReGoldenInfoInqResult*  TxRMSReGoldenInfoInq (const ::pptUser& requestUserID, const char* eqp, const char* beginTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsReGoldenInfoInqResult*  _req_TxRMSReGoldenInfoInq (const ::pptUser& requestUserID, const char* eqp, const char* beginTime, const char* endTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsAuditReqResult*  TxRMSAuditByPreGoldenReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsAuditReqResult*  _req_TxRMSAuditByPreGoldenReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsGeneralHistoryInqResult*  TxRMSAuditFailHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* compareResult, const char* auditSource, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsGeneralHistoryInqResult*  _req_TxRMSAuditFailHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* compareResult, const char* auditSource, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEnvVariableInqResult*  TxRMSEnvVariableInq (const ::pptUser& requestUserID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEnvVariableInqResult*  _req_TxRMSEnvVariableInq (const ::pptUser& requestUserID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSSetEnvVariableReq (const ::pptUser& requestUserID, const ::rmsEnvVariableSeq& vars, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSSetEnvVariableReq (const ::pptUser& requestUserID, const ::rmsEnvVariableSeq& vars, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::pptEntityInhibitReqResult__101*  TxRMSEntityInhibitReq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailAttributes& searchCondition, const char* claimMemo, const char* physicalRecipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::pptEntityInhibitReqResult__101*  _req_TxRMSEntityInhibitReq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailAttributes& searchCondition, const char* claimMemo, const char* physicalRecipeID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSOrphanRecipeDeleteReq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSOrphanRecipeDeleteReq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeRelationInqResult*  TxRMSRecipeRelationInq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, const char* recipeId, ::CORBA::Long recipeLevel, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeRelationInqResult*  _req_TxRMSRecipeRelationInq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, const char* recipeId, ::CORBA::Long recipeLevel, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpRecipeByLevelInqResult*  TxRMSEqpRecipeByLevelInq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpRecipeByLevelInqResult*  _req_TxRMSEqpRecipeByLevelInq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsGeneralHistoryInqResult*  TxRMSDeptAuditFailHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, const char* compareResult, const char* auditSource, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsGeneralHistoryInqResult*  _req_TxRMSDeptAuditFailHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, const char* compareResult, const char* auditSource, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSUpdateAuditFailHistoryReq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqpId, const char* recipeID, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimTime, const char* reasonCode, const char* reasonDesc, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSUpdateAuditFailHistoryReq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqpId, const char* recipeID, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimTime, const char* reasonCode, const char* reasonDesc, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsReGoldenInfoInqResult*  TxRMSAuditFailReasonInfoInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsReGoldenInfoInqResult*  _req_TxRMSAuditFailReasonInfoInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsBulletinListInqResult*  TxRMSBulletinListInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* enable, const char* listMode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsBulletinListInqResult*  _req_TxRMSBulletinListInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* enable, const char* listMode, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSBulletinBoardSetReq (const ::pptUser& requestUserID, ::CORBA::Long bulletinId, const char* bulletinTime, const char* depId, const char* content, const char* enable, const char* beginTime, const char* endTime, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSBulletinBoardSetReq (const ::pptUser& requestUserID, ::CORBA::Long bulletinId, const char* bulletinTime, const char* depId, const char* content, const char* enable, const char* beginTime, const char* endTime, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRIMJobInqResult*  TxRMSRIMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRIMJobInqResult*  _req_TxRMSRIMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRIMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRIMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeToRIMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeUploadReqResult*  _req_TxRMSRecipeToRIMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSUATSetReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* claimTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSUATSetReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* claimTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsUATDataInqResult*  TxRMSUATInq (const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsUATDataInqResult*  _req_TxRMSUATInq (const char* eqpID, const char* subEqp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSUATReleaseReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSUATReleaseReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSUATAuditReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* s_equipmentID, const char* s_subEqp, const char* s_recipeID, ::CORBA::Long l_recipeLevel, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSUATAuditReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* s_equipmentID, const char* s_subEqp, const char* s_recipeID, ::CORBA::Long l_recipeLevel, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSHoldReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* claimTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSHoldReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* claimTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsParentRecipeSeqResult*  TxRMSParentRecipeInq (const ::objectIdentifier& equipmentID, const char* subRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsParentRecipeSeqResult*  _req_TxRMSParentRecipeInq (const ::objectIdentifier& equipmentID, const char* subRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRIMJobInqResult*  TxRMSGeneralRIMJobInq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqp, const char* recipeID, const char* recipeLevel, const char* actionCode, const char* jobStatus, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* result, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRIMJobInqResult*  _req_TxRMSGeneralRIMJobInq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqp, const char* recipeID, const char* recipeLevel, const char* actionCode, const char* jobStatus, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* result, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsUATDataInqResult*  TxRMSRIMInhibitInq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsUATDataInqResult*  _req_TxRMSRIMInhibitInq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRIMJobRecoveryReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRIMJobRecoveryReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsHoldDataInqResult*  TxRMSHoldInq (const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsHoldDataInqResult*  _req_TxRMSHoldInq (const char* eqpID, const char* subEqp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeDeleteReqResult*  TxRMSRIMRecipeDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* recipeID, ::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeDeleteReqResult*  _req_TxRMSRIMRecipeDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* recipeID, ::CORBA::Long jobIndex, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsLabelDataInqResult*  TxRMSLabelInq (const ::pptUser& requestUserID, const char* depID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsLabelDataInqResult*  _req_TxRMSLabelInq (const ::pptUser& requestUserID, const char* depID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSLabelSetReq (const ::pptUser& requestUserID, const char* depID, const char* label, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSLabelSetReq (const ::pptUser& requestUserID, const char* depID, const char* label, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeLabelDataInqResult*  TxRMSRecipeLabelInq (const ::pptUser& requestUserID, const char* depID, const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeLabelDataInqResult*  _req_TxRMSRecipeLabelInq (const ::pptUser& requestUserID, const char* depID, const char* eqpID, const char* subEqp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeLabelSetReq (const ::pptUser& requestUserID, const char* depID, const ::rmsRecipeLabelDataSeq& infos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeLabelSetReq (const ::pptUser& requestUserID, const char* depID, const ::rmsRecipeLabelDataSeq& infos, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeLabelTreeInqResult*  TxRMSRecipeLabelTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeLabelTreeInqResult*  _req_TxRMSRecipeLabelTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeLabelTreeInqResult*  TxRMSRecipeLabelSubTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeLabelTreeInqResult*  _req_TxRMSRecipeLabelSubTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeLabelTreeInqResult*  TxRMSLabeledRecipeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeLabelTreeInqResult*  _req_TxRMSLabeledRecipeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeLabelDataInqResult*  TxRMSLabelsByRecipeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeLabelDataInqResult*  _req_TxRMSLabelsByRecipeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRemoveLabelReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* recipeId, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRemoveLabelReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* recipeId, const char* label, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeLabelByRecipeSetReq (const ::pptUser& requestUserID, const char* depID, const char* eqpID, const char* subEqp, const char* recipeId, const ::rmsRecipeLabelDataSeq& infos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeLabelByRecipeSetReq (const ::pptUser& requestUserID, const char* depID, const char* eqpID, const char* subEqp, const char* recipeId, const ::rmsRecipeLabelDataSeq& infos, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeChangeRpt (const char* eqpID, const char* subEqp, const char* recipeId, const char* createTime, const char* modifier, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeChangeRpt (const char* eqpID, const char* subEqp, const char* recipeId, const char* createTime, const char* modifier, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeChangeInqResult*  TxRMSRecipeChangeInq (const char* status, const char* startTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeChangeInqResult*  _req_TxRMSRecipeChangeInq (const char* status, const char* startTime, const char* endTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeChangeSetStatusReq (const char* eqpID, const char* subEqp, const char* recipeId, const char* startTime, const char* endTime, const char* status, const char* eventProcessTime, const char* result, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeChangeSetStatusReq (const char* eqpID, const char* subEqp, const char* recipeId, const char* startTime, const char* endTime, const char* status, const char* eventProcessTime, const char* result, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcipeMatchedInqResult*  TxRMSMatchedRecipeInq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcipeMatchedInqResult*  _req_TxRMSMatchedRecipeInq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsAuditReqResult*  TxRMSAuditSingleReq (const char* eqpID, const char* subEqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsAuditReqResult*  _req_TxRMSAuditSingleReq (const char* eqpID, const char* subEqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsECBatchInqResult*  TxRMSECBatchInq (const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsECBatchInqResult*  _req_TxRMSECBatchInq (const char* status, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSECBatchSetReq (const char* eqpID, const char* subEqp, ::CORBA::Long batchNo, const char* createTime, const char* status, const char* execTime, const char* result, const char* resultDesc, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSECBatchSetReq (const char* eqpID, const char* subEqp, ::CORBA::Long batchNo, const char* createTime, const char* status, const char* execTime, const char* result, const char* resultDesc, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsAuditReqResult*  TxRMSECAuditReq (const char* eqpID, const char* subEqp, ::CORBA::Long batchNo, const char* createTime, ::CORBA::LongLong minConstId, ::CORBA::LongLong maxConstId, ::CORBA::Long auditFlag, const char* auditTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsAuditReqResult*  _req_TxRMSECAuditReq (const char* eqpID, const char* subEqp, ::CORBA::Long batchNo, const char* createTime, ::CORBA::LongLong minConstId, ::CORBA::LongLong maxConstId, ::CORBA::Long auditFlag, const char* auditTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsECBatchAuditFailInqResult*  TxRMSECBatchAuditFailInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqpId, const char* constID, const char* beginTime, const char* endTime, const char* audit, const char* toleranceBegin, const char* toleranceEnd, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsECBatchAuditFailInqResult*  _req_TxRMSECBatchAuditFailInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqpId, const char* constID, const char* beginTime, const char* endTime, const char* audit, const char* toleranceBegin, const char* toleranceEnd, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsAuditReqResult*  TxRMSAuditByLotReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsAuditReqResult*  _req_TxRMSAuditByLotReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsPreAuditInqResult*  TxRMSPreAuditByLotInqReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsPreAuditInqResult*  _req_TxRMSPreAuditByLotInqReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSLotAuditSkipSetReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* lotId, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSLotAuditSkipSetReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* lotId, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsLotAuditSkipInqResult*  TxRMSLotAuditSkipInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsLotAuditSkipInqResult*  _req_TxRMSLotAuditSkipInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpConstantBlockInqResult*  TxRMSEqpConstBlockTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpConstantBlockInqResult*  _req_TxRMSEqpConstBlockTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpConstantInqResult*  TxRMSEqpConstantByBlockInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* subEqp, const char* blockName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpConstantInqResult*  _req_TxRMSEqpConstantByBlockInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* subEqp, const char* blockName, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsAuditReqResult*  TxRMSAuditByLotForTCSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, const ::tcsEqpConstantSequence& theECIDs, const ::tcsEqpConstantSequence& theSVIDs, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsAuditReqResult*  _req_TxRMSAuditByLotForTCSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, const ::tcsEqpConstantSequence& theECIDs, const ::tcsEqpConstantSequence& theSVIDs, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpBatchInqResult*  TxRMSRcpBatchInq (const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpBatchInqResult*  _req_TxRMSRcpBatchInq (const char* status, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRcpBatchSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const char* status, const char* execTime, const char* result, const char* resultDesc, const char* batchCreateTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRcpBatchSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const char* status, const char* execTime, const char* result, const char* resultDesc, const char* batchCreateTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::csPrivilegeCheckForRMSReqResult*  TxRMSGeneralPrivilegeCheckReq (const ::pptUser& requestUserID, const char* deptID, const char* privilege, const ::objectIdentifier& equipmentID, const char* targetRcp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::csPrivilegeCheckForRMSReqResult*  _req_TxRMSGeneralPrivilegeCheckReq (const ::pptUser& requestUserID, const char* deptID, const char* privilege, const ::objectIdentifier& equipmentID, const char* targetRcp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsUserPrivilegeInqResult*  TxRMSUserPrivilegeListInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, const char* privilege, const char* level, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsUserPrivilegeInqResult*  _req_TxRMSUserPrivilegeListInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, const char* privilege, const char* level, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsPrivilegeInqResult*  TxRMSPrivilegeListInq (const ::pptUser& requestUserID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsPrivilegeInqResult*  _req_TxRMSPrivilegeListInq (const ::pptUser& requestUserID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSUserPrivilegeSetReq (const ::pptUser& requestUserID, const ::rmsUserPrivilegeSeq& userPrivileges, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSUserPrivilegeSetReq (const ::pptUser& requestUserID, const ::rmsUserPrivilegeSeq& userPrivileges, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsPrivilegeLevelInqResult*  TxRMSPrivilegeLevelInq (const ::pptUser& requestUserID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsPrivilegeLevelInqResult*  _req_TxRMSPrivilegeLevelInq (const ::pptUser& requestUserID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsUserPrivilegeInqResult*  TxRMSAllPrivilegesInq (const ::pptUser& requestUserID, const char* privilege, const char* level, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsUserPrivilegeInqResult*  _req_TxRMSAllPrivilegesInq (const ::pptUser& requestUserID, const char* privilege, const char* level, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsUserPrivilegeInqResult*  TxRMSUsersByPrivilegeInq (const ::pptUser& requestUserID, const char* privilege, const char* level, const char* targetEqp, const char* targetRcp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsUserPrivilegeInqResult*  _req_TxRMSUsersByPrivilegeInq (const ::pptUser& requestUserID, const char* privilege, const char* level, const char* targetEqp, const char* targetRcp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsUserPrivilegeInqResult*  TxRMSAllUsersInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsUserPrivilegeInqResult*  _req_TxRMSAllUsersInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsUserPrivilegeInqResult*  TxRMSPrivilegesByUserInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsUserPrivilegeInqResult*  _req_TxRMSPrivilegesByUserInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpStatusChangeFlagResult*  TxRMSEqpStatusChangeInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpStatusChangeFlagResult*  _req_TxRMSEqpStatusChangeInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEDMJobInqResult*  TxRMSEDMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEDMJobInqResult*  _req_TxRMSEDMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSEDMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSEDMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeToEDMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeUploadReqResult*  _req_TxRMSRecipeToEDMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeDelFromEDMReq (::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeUploadReqResult*  _req_TxRMSRecipeDelFromEDMReq (::CORBA::Long jobIndex, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsForceAuditHistoryInqResult*  TxRMSForceAuditHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqpId, const char* actioncode, const char* recipeid, const char* compresult, const char* beginTime, const char* endTime, const char* lotid, const char* lottype, const char* lotowner, const char* serflag, const char* auditrule, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsForceAuditHistoryInqResult*  _req_TxRMSForceAuditHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqpId, const char* actioncode, const char* recipeid, const char* compresult, const char* beginTime, const char* endTime, const char* lotid, const char* lottype, const char* lotowner, const char* serflag, const char* auditrule, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSMachineRecipeSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const ::rmsParentRecipeSeq& rmsParentRecipeList, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSMachineRecipeSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const ::rmsParentRecipeSeq& rmsParentRecipeList, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsECIMJobInqResult*  TxRMSECIMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsECIMJobInqResult*  _req_TxRMSECIMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSECIMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSECIMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsECIMJobInqResult*  TxRMSGeneralECIMJobInq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqp, const char* constID, const char* actionCode, const char* jobStatus, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* result, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsECIMJobInqResult*  _req_TxRMSGeneralECIMJobInq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqp, const char* constID, const char* actionCode, const char* jobStatus, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* result, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpConstantUploadReqResult*  TxRMSECToRIMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* TCSResourceName, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpConstantUploadReqResult*  _req_TxRMSECToRIMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* TCSResourceName, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsECUATDataInqResult*  TxRMSECUATInq (const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsECUATDataInqResult*  _req_TxRMSECUATInq (const char* eqpID, const char* subEqp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSECUATSetReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* constid, const char* eqpSpecial, ::CORBA::Long chgtoolstatus, ::CORBA::Long svidflag, const char* claimTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSECUATSetReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* constid, const char* eqpSpecial, ::CORBA::Long chgtoolstatus, ::CORBA::Long svidflag, const char* claimTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSECIMJobRecoveryReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSECIMJobRecoveryReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSECUATReleaseReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSECUATReleaseReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpEvdSaveReqResult*  TxRMSRcpCmpEvdSaveReq (const ::pptUser& requestUserID, const ::objectIdentifier& s_eqpID, const char* s_subEqpID, const char* s_recipeID, ::CORBA::Long s_recipeLevel, const ::rmsRecipeBodySeq& s_recipeBodys, const ::objectIdentifier& t_eqpID, const char* t_subEqpID, const char* t_recipeID, ::CORBA::Long t_recipeLevel, const ::rmsRecipeBodySeq& t_recipeBodys, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpEvdSaveReqResult*  _req_TxRMSRcpCmpEvdSaveReq (const ::pptUser& requestUserID, const ::objectIdentifier& s_eqpID, const char* s_subEqpID, const char* s_recipeID, ::CORBA::Long s_recipeLevel, const ::rmsRecipeBodySeq& s_recipeBodys, const ::objectIdentifier& t_eqpID, const char* t_subEqpID, const char* t_recipeID, ::CORBA::Long t_recipeLevel, const ::rmsRecipeBodySeq& t_recipeBodys, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpEvdDetailInqResult*  TxRMSRcpCmpEvdDetailInq (const ::pptUser& requestUserID, const ::objectIdentifier& s_eqpID, const char* s_subEqpID, const char* s_recipeID, ::CORBA::Long s_recipeLevel, const ::objectIdentifier& t_eqpID, const char* t_subEqpID, const char* t_recipeID, ::CORBA::Long t_recipeLevel, const char* evdID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpEvdDetailInqResult*  _req_TxRMSRcpCmpEvdDetailInq (const ::pptUser& requestUserID, const ::objectIdentifier& s_eqpID, const char* s_subEqpID, const char* s_recipeID, ::CORBA::Long s_recipeLevel, const ::objectIdentifier& t_eqpID, const char* t_subEqpID, const char* t_recipeID, ::CORBA::Long t_recipeLevel, const char* evdID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpExamSaveReqResult*  TxRMSRcpCmpExamSaveReq (const ::pptUser& requestUserID, const char* examID, const char* examDesc, const char* action, const ::rmsRcpCmpExamDetailDataSeq& rcpCmpExamInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpExamSaveReqResult*  _req_TxRMSRcpCmpExamSaveReq (const ::pptUser& requestUserID, const char* examID, const char* examDesc, const char* action, const ::rmsRcpCmpExamDetailDataSeq& rcpCmpExamInfos, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpExamInqResult*  TxRMSRcpCmpExamInq (const ::pptUser& requestUserID, const char* examID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpExamInqResult*  _req_TxRMSRcpCmpExamInq (const ::pptUser& requestUserID, const char* examID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpExamDetailInqResult*  TxRMSRcpCmpExamDetailInq (const ::pptUser& requestUserID, const char* pd_name, const char* e_eqpID, const char* e_recipeID, const char* examID, const char* inqType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpExamDetailInqResult*  _req_TxRMSRcpCmpExamDetailInq (const ::pptUser& requestUserID, const char* pd_name, const char* e_eqpID, const char* e_recipeID, const char* examID, const char* inqType, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSGoldenRecipeToMRSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const ::rmsParentRecipeSeq& rmsParentRecipeList, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSGoldenRecipeToMRSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const ::rmsParentRecipeSeq& rmsParentRecipeList, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeGoldenSetStatusReq (const char* eqpID, const char* subEqp, const char* recipeId, const char* startTime, const char* endTime, const char* status, const char* eventProcessTime, const char* result, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeGoldenSetStatusReq (const char* eqpID, const char* subEqp, const char* recipeId, const char* startTime, const char* endTime, const char* status, const char* eventProcessTime, const char* result, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeGoldenInqResult*  TxRMSGoldenRecipeToMRHistoryInq (const char* status, const char* startTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeGoldenInqResult*  _req_TxRMSGoldenRecipeToMRHistoryInq (const char* status, const char* startTime, const char* endTime, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeGoldenRpt (const char* eqpID, const char* subEqp, const char* recipeId, const char* createTime, const char* modifier, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeGoldenRpt (const char* eqpID, const char* subEqp, const char* recipeId, const char* createTime, const char* modifier, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSCheckRecipeIsUATInq (const char* eqpID, const char* recipeId, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSCheckRecipeIsUATInq (const char* eqpID, const char* recipeId, const char* subEqp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsGeneralConfigInqResult*  TxRMSGeneralConfigInq (const ::pptUser& requestUserID, const char* keyname, const char* key, const char* valuename, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsGeneralConfigInqResult*  _req_TxRMSGeneralConfigInq (const ::pptUser& requestUserID, const char* keyname, const char* key, const char* valuename, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSEqpAuditFlagAutoTurnOnSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& eqpID, const char* subEqp, const char* flagType, ::CORBA::Long autoTurnOnTime, const char* clmMemo, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSEqpAuditFlagAutoTurnOnSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& eqpID, const char* subEqp, const char* flagType, ::CORBA::Long autoTurnOnTime, const char* clmMemo, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpAuditFlagAutoTurnOnInqResult*  TxRMSEqpAuditFlagAutoTurnOnInq (const ::pptUser& requestUserID, const ::objectIdentifier& eqpID, const char* subEqp, const char* flagType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpAuditFlagAutoTurnOnInqResult*  _req_TxRMSEqpAuditFlagAutoTurnOnInq (const ::pptUser& requestUserID, const ::objectIdentifier& eqpID, const char* subEqp, const char* flagType, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSEqpStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* statecode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSEqpStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* statecode, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpInqResult*  TxRMSRcpCmpInq (const ::pptUser& requestUserID, const ::rmsRcpCmpInqListSeq& rcpCmpListInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpInqResult*  _req_TxRMSRcpCmpInq (const ::pptUser& requestUserID, const ::rmsRcpCmpInqListSeq& rcpCmpListInfos, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpBatchSaveReqResult*  TxRMSRcpCmpBatchSaveReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* batchDesc, const char* email, const ::rmsRcpCmpPairDataSeq& rcpCmpPairInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpBatchSaveReqResult*  _req_TxRMSRcpCmpBatchSaveReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* batchDesc, const char* email, const ::rmsRcpCmpPairDataSeq& rcpCmpPairInfos, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpBatchUpdateReqResult*  TxRMSRcpCmpBatchUpdateReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpBatchUpdateReqResult*  _req_TxRMSRcpCmpBatchUpdateReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* status, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpBatchDeleteReqResult*  TxRMSRcpCmpBatchDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpBatchDeleteReqResult*  _req_TxRMSRcpCmpBatchDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpBatchInqResult*  TxRMSRcpCmpBatchInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpBatchInqResult*  _req_TxRMSRcpCmpBatchInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* status, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpPairInqResult*  TxRMSRcpCmpPairInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* inqType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpPairInqResult*  _req_TxRMSRcpCmpPairInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* inqType, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpPairNoInqResult*  TxRMSRcpCmpPairNoInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpPairNoInqResult*  _req_TxRMSRcpCmpPairNoInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpPairAddReqResult*  TxRMSRcpCmpPairAddReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const ::rmsRcpCmpPairDataSeq& rcpCmpPairInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpPairAddReqResult*  _req_TxRMSRcpCmpPairAddReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const ::rmsRcpCmpPairDataSeq& rcpCmpPairInfos, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpPairUpdateReqResult*  TxRMSRcpCmpPairUpdateReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Long no, const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpPairUpdateReqResult*  _req_TxRMSRcpCmpPairUpdateReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Long no, const char* status, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpResultInqResult*  TxRMSRcpCmpResultInq (const ::pptUser& requestUserID, const ::rmsRcpCmpPairListSeq& rcpCmpPairListInfosInq, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpResultInqResult*  _req_TxRMSRcpCmpResultInq (const ::pptUser& requestUserID, const ::rmsRcpCmpPairListSeq& rcpCmpPairListInfosInq, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpCmpSaveReqResult*  TxRMSRcpCmpSaveReq (const ::pptUser& requestUserID, const ::rmsRcpCmpPairListSeq& rcpCmpPairListInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpCmpSaveReqResult*  _req_TxRMSRcpCmpSaveReq (const ::pptUser& requestUserID, const ::rmsRcpCmpPairListSeq& rcpCmpPairListInfos, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeTreeInqResult*  TxRMSRecipeTreeInqV2 (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeTreeInqResult*  _req_TxRMSRecipeTreeInqV2 (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSUpdateRCPLastAuditTimeSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSUpdateRCPLastAuditTimeSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpBatchCntInqResult*  TxRMSBatchRCPAuditCntInqReq (const ::pptUser& requestUserID, const char* equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpBatchCntInqResult*  _req_TxRMSBatchRCPAuditCntInqReq (const ::pptUser& requestUserID, const char* equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSBatchRCPAuditCntSetReq (const ::pptUser& requestUserID, const char* equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long cnt, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSBatchRCPAuditCntSetReq (const ::pptUser& requestUserID, const char* equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long cnt, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpAFIInqResult*  TxRMSRcpAuditFailInhibitInfoInq (const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpAFIInqResult*  _req_TxRMSRcpAuditFailInhibitInfoInq (const char* status, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRcpAuditFailInhibitSetReq (const char* eqpID, const char* subEqp, const char* mrrecipeId, const char* recipeId, ::CORBA::Long recipeLevel, const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRcpAuditFailInhibitSetReq (const char* eqpID, const char* subEqp, const char* mrrecipeId, const char* recipeId, ::CORBA::Long recipeLevel, const char* status, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRcpAuditFailInhibitSetStatusReq (const char* eqpId, const char* subEqp, const char* mrrecipeId, const char* recipeId, ::CORBA::Long recipeLevel, const char* claimTime, const char* status, ::CORBA::Long mrcount, const char* last_update_time, const char* result, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRcpAuditFailInhibitSetStatusReq (const char* eqpId, const char* subEqp, const char* mrrecipeId, const char* recipeId, ::CORBA::Long recipeLevel, const char* claimTime, const char* status, ::CORBA::Long mrcount, const char* last_update_time, const char* result, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpChgAuditResultInqResult*  TxRMSRcpChgAuditResultInq (const ::objectIdentifier& equipmentID, const char* subeqpId, const char* RecipeID, const char* beginTime, const char* endTime, const char* status, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpChgAuditResultInqResult*  _req_TxRMSRcpChgAuditResultInq (const ::objectIdentifier& equipmentID, const char* subeqpId, const char* RecipeID, const char* beginTime, const char* endTime, const char* status, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpRecipeAutoLabelAllInqResult*  TxRMSEqpRecipeAutoLabelAllInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpRecipeAutoLabelAllInqResult*  _req_TxRMSEqpRecipeAutoLabelAllInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpRelatedRecipeAllInqResult*  TxRMSEqpRecipeByAutoLabelInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpRelatedRecipeAllInqResult*  _req_TxRMSEqpRecipeByAutoLabelInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* label, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpRcpLabelRuleInqResult*  TxRMSRecipeLabelRuleInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, const char* rcppattern, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpRcpLabelRuleInqResult*  _req_TxRMSRecipeLabelRuleInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, const char* rcppattern, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSRecipeLabelRuleSetReq (const ::pptUser& requestUserID, const ::rmsRcpLabelRuleInqResultSeq& infos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSRecipeLabelRuleSetReq (const ::pptUser& requestUserID, const ::rmsRcpLabelRuleInqResultSeq& infos, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSDeleteLabelRuleReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* rcppattern, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSDeleteLabelRuleReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* rcppattern, const char* label, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsEqpRelatedRecipeAllInqResult*  TxRMSEqpRecipeByNoLabelInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsEqpRelatedRecipeAllInqResult*  _req_TxRMSEqpRecipeByNoLabelInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsProRcpAuditRuleInqResult*  TxRMSProRcpAuditRuleInq (const ::objectIdentifier& equipmentID, const char* subeqpId, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsProRcpAuditRuleInqResult*  _req_TxRMSProRcpAuditRuleInq (const ::objectIdentifier& equipmentID, const char* subeqpId, const char* ownerDept, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsLoadMapRecipeInfoResult*  TxRMSLoadMapRecipeUploadReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const char* recipeId, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsLoadMapRecipeInfoResult*  _req_TxRMSLoadMapRecipeUploadReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const char* recipeId, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpTemplateNameIDInqResult*  TxRMSRecipeTemplateInq (const char* actioncode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpTemplateNameIDInqResult*  _req_TxRMSRecipeTemplateInq (const char* actioncode, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRcpItemValueCheckResult*  TxRMSRecipeStepNameRuleCheckReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long goldenFlag, ::CORBA::Long recipeLevel, const char* actioncode, const char* nameid, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRcpItemValueCheckResult*  _req_TxRMSRecipeStepNameRuleCheckReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long goldenFlag, ::CORBA::Long recipeLevel, const char* actioncode, const char* nameid, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsSERJobInqResult*  TxRMSSERJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsSERJobInqResult*  _req_TxRMSSERJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsResult*  TxRMSSERJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsResult*  _req_TxRMSSERJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeToSERReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeUploadReqResult*  _req_TxRMSRecipeToSERReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeDelFromSERReq (::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::rmsRecipeUploadReqResult*  _req_TxRMSRecipeDelFromSERReq (::CORBA::Long jobIndex, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:

}; // end nesting scope for interface class ::RMServiceManager

#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif

class  RMServiceManager_ORBProxy : virtual public 

   RMServiceManager
, virtual public ::CORBA::Object_ORBProxy  {

public: 
    RMServiceManager_ORBProxy ();

    virtual  ::rmsRecipeUploadAllFromGoldenWithLimitReqResult*  TxRMSRecipeUploadAllFromGoldenWithLimitReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeDeleteCheckInqResult*  TxRMSRecipeDeleteCheckInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeUsedByCheckInqResult*  TxRMSRecipeUsedByCheckInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleRelationDeleteReqResult*  TxRMSRuleRelationDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, ::CORBA::Long recipeDependence, const char* recipeIDPattern, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleDefinitionDeleteReqResult*  TxRMSRuleDefinitionDeleteReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleRelationSetReqResult*  TxRMSRuleRelationSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, ::CORBA::Long recipeDependence, const char* recipeIDPattern, const char* actionType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleRelationListResult*  TxRMSRuleRelationListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ruleID, ::CORBA::Long recipeLevel, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleDefinitionSetReqResult*  TxRMSRuleDefinitionSetReq (const ::pptUser& requestUserID, const char* ruleID, const char* ownerDept, const ::rmsRuleInfo& strRuleInfo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleDefinitionCheckOutReqResult*  TxRMSRuleDefinitionCheckOutReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleDefinitionCheckInReqResult*  TxRMSRuleDefinitionCheckInReq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleDefinitionListInqResult*  TxRMSRuleDefinitionListInq (const ::pptUser& requestUserID, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRuleDefinitionInfoInqResult*  TxRMSRuleDefinitionInfoInq (const ::pptUser& requestUserID, const char* ruleID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeDeleteReqResult*  TxRMSRecipeDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* recipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptPrivilegeCheckReqResult*  TxRMSPrivilegeCheckReqForMM (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& stockerID, const ::objectIdentifierSequence& productIDs, const ::objectIdentifierSequence& routeIDs, const ::objectIdentifierSequence& lotIDs, const ::objectIdentifierSequence& machineRecipeIDs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpInAuditListInqResult*  TxRMSEqpInAuditListInq (const ::pptUser& requestUserID, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeHistoryInqResult*  TxRMSRecipeHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsGeneralHistoryInqResult*  TxRMSGeneralHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* compareResult, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpListByOwnerInqResult*  TxRMSEqpListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpInfoListByOwnerInqResult*  TxRMSEqpInfoListByOwnerInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptUserDataInqResult*  TxRMSUserDataSetInq (const ::pptUser& requestUserID, const ::pptUserDataInqInParm__101& strUserDataInqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptUserDataUpdateReqResult*  TxRMSUserDataSetReq (const ::pptUser& requestUserID, const ::pptUserDataUpdateReqInParm& strUserDataUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptEqpInfoInqResult*  TxRMSEqpInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptEqpInfoForInternalBufferInqResult*  TxRMSEqpInfoForInternalBufferInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean requestFlagForBRInfo, ::CORBA::Boolean requestFlagForStatusInfo, ::CORBA::Boolean requestFlagForPMInfo, ::CORBA::Boolean requestFlagForPortInfo, ::CORBA::Boolean requestFlagForChamberInfo, ::CORBA::Boolean requestFlagForInternalBufferInfo, ::CORBA::Boolean requestFlagForStockerInfo, ::CORBA::Boolean requestFlagForInprocessingLotInfo, ::CORBA::Boolean requestFlagForReservedControlJobInfo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptUserDescInqResult*  TxRMSUserDescInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptEqpListInqResult*  TxRMSEqpListInq (const ::pptUser& requestUserID, const ::objectIdentifier& workArea, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptReasonListInqResult*  TxRMSReasonListInq (const ::pptUser& requestUserID, const char* codeCategory, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csPrivilegeCheckForRMSReqResult*  TxRMSPrivilegeCheckReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeLimitCopyReqResult*  TxRMSRecipeLimitCopyReq (const ::pptUser& requestUserID, const ::objectIdentifier& fromEquipmentID, const ::objectIdentifier& toEquipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* claimMemo, ::CORBA::Long copyType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptEqpRelatedRecipeIDListInqResult*  TxRMSEqpRelatedRecipeIDListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptLogOnCheckReqResult*  TxRMSLogOnCheckReq (const ::pptUser& requestUserID, const char* subSystemID, const char* categoryID, ::CORBA::Boolean bProductRequestFlag, ::CORBA::Boolean bRecipeRequestFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeInqResult*  TxRMSRecipeInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, const char* orderCondition, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeCheckOutReqResult*  TxRMSRecipeCheckOutReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeCheckInReqResult*  TxRMSRecipeCheckInReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeSaveReqResult*  TxRMSRecipeSaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const ::rmsRecipeBodySeq& parsedRecipeBodys, ::CORBA::Long isGolden, ::CORBA::Boolean reNew, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeSaveReqResult*  TxRMSRecipeCopySaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const ::rmsRecipeBodySeq& parsedRecipeBodys, ::CORBA::Long isGolden, ::CORBA::Boolean reNew, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeSetGoldenReqResult*  TxRMSRecipeSetGoldenReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, const char* reasonCode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpConstantInqResult*  TxRMSEqpConstantInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, ::CORBA::Boolean isNonManagedOnly, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpConstantUploadReqResult*  TxRMSEqpConstantUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* TCSResourceName, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpConstantCheckOutReqResult*  TxRMSEqpConstantCheckOutReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpConstantCheckInReqResult*  TxRMSEqpConstantCheckInReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpConstantSaveReqResult*  TxRMSEqpConstantSaveReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Boolean reNew, const char* blockName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsAuditReqResult*  TxRMSAuditReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsAuditReqResult*  TxRMSAuditForTCSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, const ::tcsEqpConstantSequence& theECIDs, const ::tcsEqpConstantSequence& theSVIDs, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsPreAuditInqResult*  TxRMSPreAuditInqReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsSetDBUserPswdReqResult*  TxRMSSetDBUserPswdReq (const ::pptUser& requestUserID, const char* newDBName, const char* newDBUser, const char* newDBPswd, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsGoldenViewEqpListInqResult*  TxRMSGoldenViewEqpListInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeCopydFromGoldenReqResult*  TxRMSRecipeCopydFromGoldenReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsChildRecipeInqResult*  TxRMSChildRecipeInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csEqpRMSFlgInqResult*  TxRMSEqpRMSFlgInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeTreeInqResult*  TxRMSRecipeTreeInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsChildRecipeUploadReqResult*  TxRMSChildRecipeUploadReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsMiscInqResult*  TxRMSMiscInq (const ::pptUser& requestUserID, const char* keyName, const char* key, const char* valueName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsMiscPairInqResult*  TxRMSMiscPairInq (const ::pptUser& requestUserID, const char* keyName, const char* valueName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSMiscSaveReq (const ::pptUser& requestUserID, const char* keyName, const char* key, const char* valueName, const char* value, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpRelatedRecipeAllInqResult*  TxRMSEqpRelatedRecipeAllInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* ownerDept, ::CORBA::Boolean getUploadedFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeCopyReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* fromEqp, const char* fromInline, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long goldenFlag, const char* toEqp, const char* toInline, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeUpdateReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long goldenFlag, const ::rmsRecipeItemValueSeq& recipeItems, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSBatchJobSetReq (const ::pptUser& requestUserID, const ::rmsBatchJobSeq& jobs, const char* ownerDept, ::CORBA::Boolean isNew, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSBatchJobDeleteReq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* registerTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsBatchJobInqResult*  TxRMSBatchJobInq (const ::pptUser& requestUserID, const char* ownerDept, const char* equipmentID, const char* eqpSpecial, const char* startTime, const char* endTime, const char* userCondition, const char* resultCondition, const char* closingCondition, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsBatchJobInqResult*  TxRMSBatchJobDetailInq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* registerUser, const char* registerTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsBatchJobRunTimeInfo*  TxRMSBatchJobRunTimeInfoInq (const ::pptUser& requestUserID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpProfileInqResult*  TxRMSEqpProfileInq (const ::objectIdentifierSequence& eqps, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSEqpProfileSetReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const ::rmsEqpProfileSeq& profiles, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeProfileInqResult*  TxRMSRecipeProfileInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeProfileSetReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const char* claimMemo, const ::rmsRecipeProfileSeq& profiles, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeProfileDeleteReq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const char* equipmentID, const char* physicalRecipeID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSCopyToleranceFromGoldenReq (const ::pptUser& requestUserID, const char* equipmentID, const char* eqpSpecial, const char* physicalRecipeID, ::CORBA::Long recipeLevel, ::CORBA::Long option, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptEntityInhibitCancelReqResult*  TxRMSEntityInhibitCancelReq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailInfoSequence& entityInhibitions, const ::objectIdentifier& reasonCode, const char* claimMemo, const char* equipmentID, const char* physicalRecipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptEntityInhibitListInqResult__101*  TxRMSEntityInhibitListInq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailAttributes& searchCondition, ::CORBA::Boolean entityInhibitReasonDetailInfoFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsAuditFailInfoInqResult*  TxRMSAuditFailInfoInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsGeneralHistoryInqResult*  TxRMSReGoldenHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsReGoldenInfoInqResult*  TxRMSReGoldenInfoInq (const ::pptUser& requestUserID, const char* eqp, const char* beginTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsAuditReqResult*  TxRMSAuditByPreGoldenReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsGeneralHistoryInqResult*  TxRMSAuditFailHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* compareResult, const char* auditSource, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEnvVariableInqResult*  TxRMSEnvVariableInq (const ::pptUser& requestUserID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSSetEnvVariableReq (const ::pptUser& requestUserID, const ::rmsEnvVariableSeq& vars, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::pptEntityInhibitReqResult__101*  TxRMSEntityInhibitReq (const ::pptUser& requestUserID, const ::pptEntityInhibitDetailAttributes& searchCondition, const char* claimMemo, const char* physicalRecipeID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSOrphanRecipeDeleteReq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeRelationInqResult*  TxRMSRecipeRelationInq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, const char* recipeId, ::CORBA::Long recipeLevel, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpRecipeByLevelInqResult*  TxRMSEqpRecipeByLevelInq (const ::pptUser& requestUserID, const char* eqpId, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsGeneralHistoryInqResult*  TxRMSDeptAuditFailHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* recipeID, const char* actionCode, const char* beginTime, const char* endTime, const char* compareResult, const char* auditSource, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSUpdateAuditFailHistoryReq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqpId, const char* recipeID, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimTime, const char* reasonCode, const char* reasonDesc, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsReGoldenInfoInqResult*  TxRMSAuditFailReasonInfoInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* beginTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsBulletinListInqResult*  TxRMSBulletinListInq (const ::pptUser& requestUserID, const ::objectIdentifierSequence& eqps, const char* enable, const char* listMode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSBulletinBoardSetReq (const ::pptUser& requestUserID, ::CORBA::Long bulletinId, const char* bulletinTime, const char* depId, const char* content, const char* enable, const char* beginTime, const char* endTime, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRIMJobInqResult*  TxRMSRIMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRIMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeToRIMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSUATSetReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* claimTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsUATDataInqResult*  TxRMSUATInq (const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSUATReleaseReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSUATAuditReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* s_equipmentID, const char* s_subEqp, const char* s_recipeID, ::CORBA::Long l_recipeLevel, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSHoldReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* claimTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsParentRecipeSeqResult*  TxRMSParentRecipeInq (const ::objectIdentifier& equipmentID, const char* subRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRIMJobInqResult*  TxRMSGeneralRIMJobInq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqp, const char* recipeID, const char* recipeLevel, const char* actionCode, const char* jobStatus, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* result, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsUATDataInqResult*  TxRMSRIMInhibitInq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRIMJobRecoveryReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsHoldDataInqResult*  TxRMSHoldInq (const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeDeleteReqResult*  TxRMSRIMRecipeDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* recipeID, ::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsLabelDataInqResult*  TxRMSLabelInq (const ::pptUser& requestUserID, const char* depID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSLabelSetReq (const ::pptUser& requestUserID, const char* depID, const char* label, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeLabelDataInqResult*  TxRMSRecipeLabelInq (const ::pptUser& requestUserID, const char* depID, const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeLabelSetReq (const ::pptUser& requestUserID, const char* depID, const ::rmsRecipeLabelDataSeq& infos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeLabelTreeInqResult*  TxRMSRecipeLabelTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeLabelTreeInqResult*  TxRMSRecipeLabelSubTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeLabelTreeInqResult*  TxRMSLabeledRecipeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeLabelDataInqResult*  TxRMSLabelsByRecipeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRemoveLabelReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* recipeId, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeLabelByRecipeSetReq (const ::pptUser& requestUserID, const char* depID, const char* eqpID, const char* subEqp, const char* recipeId, const ::rmsRecipeLabelDataSeq& infos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeChangeRpt (const char* eqpID, const char* subEqp, const char* recipeId, const char* createTime, const char* modifier, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeChangeInqResult*  TxRMSRecipeChangeInq (const char* status, const char* startTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeChangeSetStatusReq (const char* eqpID, const char* subEqp, const char* recipeId, const char* startTime, const char* endTime, const char* status, const char* eventProcessTime, const char* result, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcipeMatchedInqResult*  TxRMSMatchedRecipeInq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsAuditReqResult*  TxRMSAuditSingleReq (const char* eqpID, const char* subEqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsECBatchInqResult*  TxRMSECBatchInq (const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSECBatchSetReq (const char* eqpID, const char* subEqp, ::CORBA::Long batchNo, const char* createTime, const char* status, const char* execTime, const char* result, const char* resultDesc, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsAuditReqResult*  TxRMSECAuditReq (const char* eqpID, const char* subEqp, ::CORBA::Long batchNo, const char* createTime, ::CORBA::LongLong minConstId, ::CORBA::LongLong maxConstId, ::CORBA::Long auditFlag, const char* auditTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsECBatchAuditFailInqResult*  TxRMSECBatchAuditFailInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqpId, const char* constID, const char* beginTime, const char* endTime, const char* audit, const char* toleranceBegin, const char* toleranceEnd, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsAuditReqResult*  TxRMSAuditByLotReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, const char* claimMemo, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsPreAuditInqResult*  TxRMSPreAuditByLotInqReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSLotAuditSkipSetReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* lotId, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsLotAuditSkipInqResult*  TxRMSLotAuditSkipInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpConstantBlockInqResult*  TxRMSEqpConstBlockTreeInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpConstantInqResult*  TxRMSEqpConstantByBlockInq (const ::pptUser& requestUserID, const ::pptUser& confirmUserID, const ::objectIdentifier& equipmentID, const char* subEqp, const char* blockName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsAuditReqResult*  TxRMSAuditByLotForTCSReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::tcsRecipeSequence& theRecipeSeq, const ::tcsEqpConstantSequence& theECIDs, const ::tcsEqpConstantSequence& theSVIDs, ::CORBA::Boolean checkEqpConst, ::CORBA::Boolean checkRecipe, const ::csLotAttrForAuditSequence& lotAttrs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpBatchInqResult*  TxRMSRcpBatchInq (const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRcpBatchSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const char* status, const char* execTime, const char* result, const char* resultDesc, const char* batchCreateTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::csPrivilegeCheckForRMSReqResult*  TxRMSGeneralPrivilegeCheckReq (const ::pptUser& requestUserID, const char* deptID, const char* privilege, const ::objectIdentifier& equipmentID, const char* targetRcp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsUserPrivilegeInqResult*  TxRMSUserPrivilegeListInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, const char* privilege, const char* level, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsPrivilegeInqResult*  TxRMSPrivilegeListInq (const ::pptUser& requestUserID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSUserPrivilegeSetReq (const ::pptUser& requestUserID, const ::rmsUserPrivilegeSeq& userPrivileges, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsPrivilegeLevelInqResult*  TxRMSPrivilegeLevelInq (const ::pptUser& requestUserID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsUserPrivilegeInqResult*  TxRMSAllPrivilegesInq (const ::pptUser& requestUserID, const char* privilege, const char* level, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsUserPrivilegeInqResult*  TxRMSUsersByPrivilegeInq (const ::pptUser& requestUserID, const char* privilege, const char* level, const char* targetEqp, const char* targetRcp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsUserPrivilegeInqResult*  TxRMSAllUsersInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsUserPrivilegeInqResult*  TxRMSPrivilegesByUserInq (const ::pptUser& requestUserID, const char* userID, const char* deptID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpStatusChangeFlagResult*  TxRMSEqpStatusChangeInfoInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEDMJobInqResult*  TxRMSEDMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSEDMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeToEDMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeDelFromEDMReq (::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsForceAuditHistoryInqResult*  TxRMSForceAuditHistoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqpId, const char* actioncode, const char* recipeid, const char* compresult, const char* beginTime, const char* endTime, const char* lotid, const char* lottype, const char* lotowner, const char* serflag, const char* auditrule, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSMachineRecipeSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const ::rmsParentRecipeSeq& rmsParentRecipeList, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsECIMJobInqResult*  TxRMSECIMJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSECIMJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsECIMJobInqResult*  TxRMSGeneralECIMJobInq (const ::pptUser& requestUserID, const char* eqpId, const char* subEqp, const char* constID, const char* actionCode, const char* jobStatus, const char* beginTime, const char* endTime, ::CORBA::Long searchCount, const char* result, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpConstantUploadReqResult*  TxRMSECToRIMReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* TCSResourceName, const ::rmsEqpConstantSequence& eqpConstants, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsECUATDataInqResult*  TxRMSECUATInq (const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSECUATSetReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const char* constid, const char* eqpSpecial, ::CORBA::Long chgtoolstatus, ::CORBA::Long svidflag, const char* claimTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSECIMJobRecoveryReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, const char* actionCode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSECUATReleaseReq (const ::pptUser& requestUserID, ::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpEvdSaveReqResult*  TxRMSRcpCmpEvdSaveReq (const ::pptUser& requestUserID, const ::objectIdentifier& s_eqpID, const char* s_subEqpID, const char* s_recipeID, ::CORBA::Long s_recipeLevel, const ::rmsRecipeBodySeq& s_recipeBodys, const ::objectIdentifier& t_eqpID, const char* t_subEqpID, const char* t_recipeID, ::CORBA::Long t_recipeLevel, const ::rmsRecipeBodySeq& t_recipeBodys, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpEvdDetailInqResult*  TxRMSRcpCmpEvdDetailInq (const ::pptUser& requestUserID, const ::objectIdentifier& s_eqpID, const char* s_subEqpID, const char* s_recipeID, ::CORBA::Long s_recipeLevel, const ::objectIdentifier& t_eqpID, const char* t_subEqpID, const char* t_recipeID, ::CORBA::Long t_recipeLevel, const char* evdID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpExamSaveReqResult*  TxRMSRcpCmpExamSaveReq (const ::pptUser& requestUserID, const char* examID, const char* examDesc, const char* action, const ::rmsRcpCmpExamDetailDataSeq& rcpCmpExamInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpExamInqResult*  TxRMSRcpCmpExamInq (const ::pptUser& requestUserID, const char* examID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpExamDetailInqResult*  TxRMSRcpCmpExamDetailInq (const ::pptUser& requestUserID, const char* pd_name, const char* e_eqpID, const char* e_recipeID, const char* examID, const char* inqType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSGoldenRecipeToMRSetReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long recipeLevel, const ::rmsParentRecipeSeq& rmsParentRecipeList, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeGoldenSetStatusReq (const char* eqpID, const char* subEqp, const char* recipeId, const char* startTime, const char* endTime, const char* status, const char* eventProcessTime, const char* result, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeGoldenInqResult*  TxRMSGoldenRecipeToMRHistoryInq (const char* status, const char* startTime, const char* endTime, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeGoldenRpt (const char* eqpID, const char* subEqp, const char* recipeId, const char* createTime, const char* modifier, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSCheckRecipeIsUATInq (const char* eqpID, const char* recipeId, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsGeneralConfigInqResult*  TxRMSGeneralConfigInq (const ::pptUser& requestUserID, const char* keyname, const char* key, const char* valuename, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSEqpAuditFlagAutoTurnOnSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& eqpID, const char* subEqp, const char* flagType, ::CORBA::Long autoTurnOnTime, const char* clmMemo, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpAuditFlagAutoTurnOnInqResult*  TxRMSEqpAuditFlagAutoTurnOnInq (const ::pptUser& requestUserID, const ::objectIdentifier& eqpID, const char* subEqp, const char* flagType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSEqpStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* statecode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpInqResult*  TxRMSRcpCmpInq (const ::pptUser& requestUserID, const ::rmsRcpCmpInqListSeq& rcpCmpListInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpBatchSaveReqResult*  TxRMSRcpCmpBatchSaveReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* batchDesc, const char* email, const ::rmsRcpCmpPairDataSeq& rcpCmpPairInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpBatchUpdateReqResult*  TxRMSRcpCmpBatchUpdateReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpBatchDeleteReqResult*  TxRMSRcpCmpBatchDeleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpBatchInqResult*  TxRMSRcpCmpBatchInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpPairInqResult*  TxRMSRcpCmpPairInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const char* inqType, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpPairNoInqResult*  TxRMSRcpCmpPairNoInq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpPairAddReqResult*  TxRMSRcpCmpPairAddReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, const ::rmsRcpCmpPairDataSeq& rcpCmpPairInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpPairUpdateReqResult*  TxRMSRcpCmpPairUpdateReq (const ::pptUser& requestUserID, const ::objectIdentifier& userID, const char* batchName, ::CORBA::Long no, const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpResultInqResult*  TxRMSRcpCmpResultInq (const ::pptUser& requestUserID, const ::rmsRcpCmpPairListSeq& rcpCmpPairListInfosInq, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpCmpSaveReqResult*  TxRMSRcpCmpSaveReq (const ::pptUser& requestUserID, const ::rmsRcpCmpPairListSeq& rcpCmpPairListInfos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeTreeInqResult*  TxRMSRecipeTreeInqV2 (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* physicalRecipeID, const char* eqpSpecial, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long isGolden, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSUpdateRCPLastAuditTimeSetReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpBatchCntInqResult*  TxRMSBatchRCPAuditCntInqReq (const ::pptUser& requestUserID, const char* equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSBatchRCPAuditCntSetReq (const ::pptUser& requestUserID, const char* equipmentID, const char* subeqp, const char* physicalRecipeID, ::CORBA::Long recipeLevel, const char* chamberID, ::CORBA::Long cnt, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpAFIInqResult*  TxRMSRcpAuditFailInhibitInfoInq (const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRcpAuditFailInhibitSetReq (const char* eqpID, const char* subEqp, const char* mrrecipeId, const char* recipeId, ::CORBA::Long recipeLevel, const char* status, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRcpAuditFailInhibitSetStatusReq (const char* eqpId, const char* subEqp, const char* mrrecipeId, const char* recipeId, ::CORBA::Long recipeLevel, const char* claimTime, const char* status, ::CORBA::Long mrcount, const char* last_update_time, const char* result, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpChgAuditResultInqResult*  TxRMSRcpChgAuditResultInq (const ::objectIdentifier& equipmentID, const char* subeqpId, const char* RecipeID, const char* beginTime, const char* endTime, const char* status, ::CORBA::Long searchCount, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpRecipeAutoLabelAllInqResult*  TxRMSEqpRecipeAutoLabelAllInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpRelatedRecipeAllInqResult*  TxRMSEqpRecipeByAutoLabelInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpRcpLabelRuleInqResult*  TxRMSRecipeLabelRuleInq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* label, const char* rcppattern, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSRecipeLabelRuleSetReq (const ::pptUser& requestUserID, const ::rmsRcpLabelRuleInqResultSeq& infos, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSDeleteLabelRuleReq (const ::pptUser& requestUserID, const char* eqpID, const char* subEqp, const char* rcppattern, const char* label, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsEqpRelatedRecipeAllInqResult*  TxRMSEqpRecipeByNoLabelInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* eqpSpecial, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsProRcpAuditRuleInqResult*  TxRMSProRcpAuditRuleInq (const ::objectIdentifier& equipmentID, const char* subeqpId, const char* ownerDept, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsLoadMapRecipeInfoResult*  TxRMSLoadMapRecipeUploadReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* TCSResourceName, const char* recipeId, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpTemplateNameIDInqResult*  TxRMSRecipeTemplateInq (const char* actioncode, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRcpItemValueCheckResult*  TxRMSRecipeStepNameRuleCheckReq (const char* eqpID, const char* subEqp, const char* recipeId, ::CORBA::Long goldenFlag, ::CORBA::Long recipeLevel, const char* actioncode, const char* nameid, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsSERJobInqResult*  TxRMSSERJobInq (const char* actionCode, const char* jobStatus, const char* jobExecStartDT, const char* jobExecEndDT, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsResult*  TxRMSSERJobSetReq (::CORBA::Long jobIndex, const char* jobStatus, const char* result, const char* resultDesc, ::CORBA::Long retryCount, const char* rmsStartDT, const char* rmsEndDT, const char* jobExecDT, const char* action, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeToSERReq (::CORBA::Long jobIndex, const ::objectIdentifier& equipmentID, const ::objectIdentifier& machineRecipeID, const char* physicalRecipeID, const char* eqpSpecial, const char* TCSResourceName, ::CORBA::Long recipeLevel, const char* chamberID, const char* option, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::rmsRecipeUploadReqResult*  TxRMSRecipeDelFromSERReq (::CORBA::Long jobIndex, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

}; /* end of ::RMServiceManager_ORBProxy*/
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
class  RMServiceManagerProxyFactory : virtual public ::CORBA::ObjectProxyFactory  {

public:
   RMServiceManagerProxyFactory (::CORBA::Boolean is_default = 0);

   virtual ::CORBA::Object_ptr create_proxy (const char* classname);
   virtual ::CORBA::Object_ptr asObject(void *obj);
}; // RMServiceManagerProxyFactory


class  RMServiceManager_Dispatcher : virtual public ::CORBA::Object_Dispatcher_2  {

  public:

   RMServiceManager_Dispatcher (::CORBA::Object_ptr target);

   RMServiceManager_Dispatcher (); 

   virtual ::CORBA::Boolean dispatch (::CORBA::Request &request);
#ifdef _MSC_VER
   ::CORBA::Boolean __RMServiceManager__dispatch(::CORBA::Request &_req);
#endif // _MSC_VER
}; // RMServiceManager_Dispatcher
#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
class  RMServiceManagerBOAImpl : virtual public 

   RMServiceManager
, virtual public ::CORBA::Object_ORBProxy { 
   public:
     RMServiceManagerBOAImpl() ;

     virtual ~RMServiceManagerBOAImpl();
     RMServiceManagerBOAImpl &operator= (const RMServiceManagerBOAImpl &s);
     RMServiceManagerBOAImpl (const RMServiceManagerBOAImpl &s);
};  // RMServiceManagerBOAImpl

    extern  ::CORBA::TypeCode_ptr _tc_RMServiceManager;
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_rmssm_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_rmssm_ANYOPERATOR__
#undef __NOTUSE_rmssm_ANYOPERATOR__
#endif //__USE_rmssm_ANYOPERATOR__
#ifndef __NOTUSE_rmssm_ANYOPERATOR__
#define _DCL_ANYOPS_RMServiceManager
#endif //__NOTUSE_rmssm_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_RMServiceManager
#ifndef __NOTUSE_ANYOPERATOR_INTERFACE__
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::RMServiceManager_ptr _data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::RMServiceManager_ptr *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::RMServiceManager_ptr& _data);
#endif
#endif //__NOTUSE_ANYOPERATOR_INTERFACE__
#endif // _DCL_ANYOPS_RMServiceManager

#endif /* _rmssm_hh_included */

#endif /* _rmssm_server_defined */
