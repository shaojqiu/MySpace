//----------------------------------------------------------------------------
//
//  Generated from cs_spcmgr.idl
//  On Tuesday, November 14, 2017 12:05:36 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_spcmgr_server_defined
#ifndef _cs_spcmgr_hh_included
#define _cs_spcmgr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif
#ifndef _DCL_CS_SPCMgr_SOM_IMPORTEXPORT
#define _DCL_CS_SPCMgr_SOM_IMPORTEXPORT 
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_SPCMgr_idl 
#define CS_SPCMgr_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_spcsvrstr_hh_included
#include <cs_spcsvrstr.hh>
#endif
#else
#ifndef _cs_spcsvrstr_hh_included
#include "cs_spcsvrstr.hh"
#endif
#endif

// Begin mapping for interface ::CS_SPCMgr

#ifndef _DCL_CS_SPCMgr
#define _DCL_CS_SPCMgr
#ifndef _DCL_CS_SPCMgr_SOM_IMPORTEXPORT
#define _DCL_CS_SPCMgr_SOM_IMPORTEXPORT 
#endif
class _DCL_CS_SPCMgr_SOM_IMPORTEXPORT
   CS_SPCMgr
    ;
class _DCL_CS_SPCMgr_SOM_IMPORTEXPORT CS_SPCMgr_var;
typedef CS_SPCMgr* CS_SPCMgr_ptr;
typedef CS_SPCMgr* CS_SPCMgrRef;

_DCL_CS_SPCMgr_SOM_IMPORTEXPORT CORBA::Object_ptr SOMLINK CS_SPCMgr_getBase(void *);

_DCL_CS_SPCMgr_SOM_IMPORTEXPORT CS_SPCMgr_ptr SOMLINK CS_SPCMgr_aux_duplicate(CS_SPCMgr_ptr);
_DCL_CS_SPCMgr_SOM_IMPORTEXPORT CS_SPCMgr_ptr SOMLINK CS_SPCMgr_aux_narrow(::CORBA::Object_ptr);
_DCL_CS_SPCMgr_SOM_IMPORTEXPORT CS_SPCMgr_ptr SOMLINK CS_SPCMgr_aux_nil();
_DCL_CS_SPCMgr_SOM_IMPORTEXPORT const char* SOMLINK CS_SPCMgr_aux_CN();

    class _DCL_CS_SPCMgr_SOM_IMPORTEXPORT CS_SPCMgr_StructElem
    {
        public:

        CS_SPCMgr_StructElem ();

        CS_SPCMgr_StructElem (const CS_SPCMgr_StructElem &s);

        CS_SPCMgr_StructElem &operator= (CS_SPCMgr_ptr p);

        CS_SPCMgr_StructElem &operator= (CS_SPCMgr_var v);

        CS_SPCMgr_StructElem &operator= (const CS_SPCMgr_StructElem &s);

        ~CS_SPCMgr_StructElem ();

        operator ::CORBA::Object_ptr() const;

        operator CS_SPCMgr_ptr () const;

        CS_SPCMgr_ptr _ptr;

    }; // CS_SPCMgr_StructElem

    class _DCL_CS_SPCMgr_SOM_IMPORTEXPORT CS_SPCMgr_SeqElem
    {
       public:

       CS_SPCMgr_SeqElem (CS_SPCMgr_ptr* p, unsigned char rel);

       CS_SPCMgr_SeqElem &operator= (CS_SPCMgr_ptr p);

        CS_SPCMgr_SeqElem &operator= (CS_SPCMgr_var v);

       CS_SPCMgr_SeqElem &operator= (const CS_SPCMgr_SeqElem &s);

       operator CS_SPCMgr_ptr () const;

       CS_SPCMgr_ptr operator->() const;

       protected:
       CS_SPCMgr_ptr *_ptr;
       unsigned char _release;
   }; // CS_SPCMgr_SeqElem


class  CS_SPCMgr_var : public ::CORBA::__vb__
{
    public:

    CS_SPCMgr_var ();
    CS_SPCMgr_var (CS_SPCMgr *p);
    CS_SPCMgr_var (const CS_SPCMgr_var &s);
    CS_SPCMgr_var (const CS_SPCMgr_StructElem &s);
    CS_SPCMgr_var (const CS_SPCMgr_SeqElem &s);
    CS_SPCMgr_var &operator= (CS_SPCMgr *p);
    CS_SPCMgr_var &operator= (const CS_SPCMgr_var &s);
    CS_SPCMgr_var &operator= (const CS_SPCMgr_StructElem &s);
    CS_SPCMgr_var &operator= (const CS_SPCMgr_SeqElem &s);
    ~CS_SPCMgr_var ();
    CS_SPCMgr_ptr in() const;
    CS_SPCMgr_ptr& inout();
    CS_SPCMgr_ptr& out();
    CS_SPCMgr_ptr _retn();
    CS_SPCMgr_ptr operator-> ();
    operator CS_SPCMgr_ptr& ();
    operator const CS_SPCMgr_ptr& () const;
#ifdef __sun
    operator CS_SPCMgr_ptr () { return _ptr; };
#endif

    protected:
       CS_SPCMgr *_ptr;

    private:
       ::CORBA::__vb__& operator= (::CORBA::__vb__&);

};  // CS_SPCMgr_var

#endif /* _DCL_CS_SPCMgr */ 


class 

   CS_SPCMgr
: virtual public ::CORBA::Object {

public: 
    static const char* CS_SPCMgr_CN;
    static const char* CS_SPCMgr_RID;
    typedef CS_SPCMgr_ptr _ptr_type;
    typedef CS_SPCMgr_var _var_type;

    /* for Orbix compatibility */
    virtual void *_deref();

protected: 
    /* constructor */

   CS_SPCMgr
();
protected: 
    virtual ~

   CS_SPCMgr
();
private: 

   CS_SPCMgr
    (const 
   CS_SPCMgr
     &); // unimplemented

    void operator=(const 
   CS_SPCMgr
     &); // unimplemented
public: 

    static CS_SPCMgr_ptr SOMLINK _duplicate(CS_SPCMgr_ptr obj);

    static CS_SPCMgr_ptr SOMLINK _narrow (::CORBA::Object_ptr);

    virtual void* _has_ancestor(const char* classname);
    static CS_SPCMgr_ptr SOMLINK _nil ();

    CS_SPCMgr_ptr _self();
    CS_SPCMgr_ptr _this();
    virtual void *_SOMThis(const char *& ifname);

static const char* theSiviewSecureReleaseVersion;

   static const char* ex_TXFailedSignal;
   class  TXFailedSignal : public ::CORBA::UserException {
     public:
       static const  char* _exception_id;

       ::CORBA::String_StructElem name;

       TXFailedSignal () : CORBA::UserException (ex_TXFailedSignal, "IDL:CS_SPCMgr/TXFailedSignal:1.0") { };
        TXFailedSignal(const TXFailedSignal&);
        TXFailedSignal& operator=(const TXFailedSignal&);
       TXFailedSignal ( const char* _name) : CORBA::UserException (ex_TXFailedSignal, "IDL:CS_SPCMgr/TXFailedSignal:1.0") { 
         name = _name;
       }

       // The _narrow methods are depricated; use _downcast 
       static  TXFailedSignal* SOMLINK _narrow (::CORBA::Exception *e);
       static  const TXFailedSignal* SOMLINK _narrow (const ::CORBA::Exception *e) {
         return _narrow ((::CORBA::Exception *)e); }
       static  TXFailedSignal* SOMLINK _downcast (::CORBA::Exception *e) {return _narrow(e);}
       static  const TXFailedSignal* SOMLINK _downcast (const ::CORBA::Exception *e) {return _narrow(e);}
       void  encodeOp(::CORBA::Request &_req) const;
       void  decodeOp(::CORBA::Request &_req);
   }; // exception TXFailedSignal

    static ::CORBA::TypeCode_ptr _tc_TXFailedSignal;

   static const char* ex_MemoryAllocationFailedSignal;
   class  MemoryAllocationFailedSignal : public ::CORBA::UserException {
     public:
       static const  char* _exception_id;

       ::CORBA::String_StructElem name;

       MemoryAllocationFailedSignal () : CORBA::UserException (ex_MemoryAllocationFailedSignal, "IDL:CS_SPCMgr/MemoryAllocationFailedSignal:1.0") { };
        MemoryAllocationFailedSignal(const MemoryAllocationFailedSignal&);
        MemoryAllocationFailedSignal& operator=(const MemoryAllocationFailedSignal&);
       MemoryAllocationFailedSignal ( const char* _name) : CORBA::UserException (ex_MemoryAllocationFailedSignal, "IDL:CS_SPCMgr/MemoryAllocationFailedSignal:1.0") { 
         name = _name;
       }

       // The _narrow methods are depricated; use _downcast 
       static  MemoryAllocationFailedSignal* SOMLINK _narrow (::CORBA::Exception *e);
       static  const MemoryAllocationFailedSignal* SOMLINK _narrow (const ::CORBA::Exception *e) {
         return _narrow ((::CORBA::Exception *)e); }
       static  MemoryAllocationFailedSignal* SOMLINK _downcast (::CORBA::Exception *e) {return _narrow(e);}
       static  const MemoryAllocationFailedSignal* SOMLINK _downcast (const ::CORBA::Exception *e) {return _narrow(e);}
       void  encodeOp(::CORBA::Request &_req) const;
       void  decodeOp(::CORBA::Request &_req);
   }; // exception MemoryAllocationFailedSignal

    static ::CORBA::TypeCode_ptr _tc_MemoryAllocationFailedSignal;

    virtual  ::CORBA::Void  CS_SPCMgr_init (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Void  _req_CS_SPCMgr_init (::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Void  CS_SPCMgr_uninit (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Void  _req_CS_SPCMgr_uninit (::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  CS_TxSpcCheckReq (const ::csSpcInput& strSpcInput, ::csSpcOutput*& strSpcOutput, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_CS_TxSpcCheckReq (const ::csSpcInput& strSpcInput, ::csSpcOutput*& strSpcOutput, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:

}; // end nesting scope for interface class ::CS_SPCMgr

#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif

class  CS_SPCMgr_ORBProxy : virtual public 

   CS_SPCMgr
, virtual public ::CORBA::Object_ORBProxy  {

public: 
    CS_SPCMgr_ORBProxy ();

    virtual  ::CORBA::Void  CS_SPCMgr_init (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Void  CS_SPCMgr_uninit (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  CS_TxSpcCheckReq (const ::csSpcInput& strSpcInput, ::csSpcOutput*& strSpcOutput, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

}; /* end of ::CS_SPCMgr_ORBProxy*/
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
class  CS_SPCMgrProxyFactory : virtual public ::CORBA::ObjectProxyFactory  {

public:
   CS_SPCMgrProxyFactory (::CORBA::Boolean is_default = 0);

   virtual ::CORBA::Object_ptr create_proxy (const char* classname);
   virtual ::CORBA::Object_ptr asObject(void *obj);
}; // CS_SPCMgrProxyFactory


class  CS_SPCMgr_Dispatcher : virtual public ::CORBA::Object_Dispatcher_2  {

  public:

   CS_SPCMgr_Dispatcher (::CORBA::Object_ptr target);

   CS_SPCMgr_Dispatcher (); 

   virtual ::CORBA::Boolean dispatch (::CORBA::Request &request);
#ifdef _MSC_VER
   ::CORBA::Boolean __CS_SPCMgr__dispatch(::CORBA::Request &_req);
#endif // _MSC_VER
}; // CS_SPCMgr_Dispatcher
#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
class  CS_SPCMgrBOAImpl : virtual public 

   CS_SPCMgr
, virtual public ::CORBA::Object_ORBProxy { 
   public:
     CS_SPCMgrBOAImpl() ;

     virtual ~CS_SPCMgrBOAImpl();
     CS_SPCMgrBOAImpl &operator= (const CS_SPCMgrBOAImpl &s);
     CS_SPCMgrBOAImpl (const CS_SPCMgrBOAImpl &s);
};  // CS_SPCMgrBOAImpl

    extern  ::CORBA::TypeCode_ptr _tc_CS_SPCMgr;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_spcmgr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_spcmgr_ANYOPERATOR__
#undef __NOTUSE_cs_spcmgr_ANYOPERATOR__
#endif //__USE_cs_spcmgr_ANYOPERATOR__
#ifndef __NOTUSE_cs_spcmgr_ANYOPERATOR__
#define _DCL_ANYOPS_CS_SPCMgr
#define _DCL_ANYOPS_CS_SPCMgr_TXFailedSignal
#define _DCL_ANYOPS_CS_SPCMgr_MemoryAllocationFailedSignal
#endif //__NOTUSE_cs_spcmgr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_CS_SPCMgr
#ifndef __NOTUSE_ANYOPERATOR_INTERFACE__
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_SPCMgr_ptr _data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_SPCMgr_ptr *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_SPCMgr_ptr& _data);
#endif
#endif //__NOTUSE_ANYOPERATOR_INTERFACE__
#endif // _DCL_ANYOPS_CS_SPCMgr
#ifndef _tc_CS_SPCMgr_TXFailedSignal
#define _tc_CS_SPCMgr_TXFailedSignal CS_SPCMgr::_tc_TXFailedSignal
#endif
#ifdef _DCL_ANYOPS_CS_SPCMgr_TXFailedSignal
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::CS_SPCMgr::TXFailedSignal &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_SPCMgr::TXFailedSignal *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_SPCMgr::TXFailedSignal*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::CS_SPCMgr::TXFailedSignal*& _data);
#endif
#endif // _DCL_ANYOPS_CS_SPCMgr_TXFailedSignal
#ifndef _tc_CS_SPCMgr_MemoryAllocationFailedSignal
#define _tc_CS_SPCMgr_MemoryAllocationFailedSignal CS_SPCMgr::_tc_MemoryAllocationFailedSignal
#endif
#ifdef _DCL_ANYOPS_CS_SPCMgr_MemoryAllocationFailedSignal
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::CS_SPCMgr::MemoryAllocationFailedSignal &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_SPCMgr::MemoryAllocationFailedSignal *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_SPCMgr::MemoryAllocationFailedSignal*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::CS_SPCMgr::MemoryAllocationFailedSignal*& _data);
#endif
#endif // _DCL_ANYOPS_CS_SPCMgr_MemoryAllocationFailedSignal

#endif /* _cs_spcmgr_hh_included */

#endif /* _cs_spcmgr_server_defined */
