//----------------------------------------------------------------------------
//
//  Generated from cs_spcsvrstr.idl
//  On Tuesday, November 14, 2017 12:13:51 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_spcsvrstr_server_defined
#ifndef _cs_spcsvrstr_hh_included
#define _cs_spcsvrstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_SPCSVRSTR_IDL 
#define CS_SPCSVRSTR_IDL 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _spcsvrstr_hh_included
#include <spcsvrstr.hh>
#endif
#else
#ifndef _spcsvrstr_hh_included
#include "spcsvrstr.hh"
#endif
#endif
    class  csSpcDcItem_struct_var;
    struct  csSpcDcItem_struct {
        typedef csSpcDcItem_struct_var _var_type;
       ::CORBA::String_StructElem dataItemName;
       ::CORBA::String_StructElem waferID;
       ::CORBA::String_StructElem waferPosition;
       ::CORBA::String_StructElem sitePosition;
       ::CORBA::Any dataValue;
       ::CORBA::Double targetValue;
       ::CORBA::String_StructElem specCheckResult;
       ::CORBA::String_StructElem comment;
       ::CORBA::String_StructElem chamber_list;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csSpcDcItem_struct();
       csSpcDcItem_struct(const csSpcDcItem_struct&);
       csSpcDcItem_struct& operator=(const csSpcDcItem_struct&);
       static CORBA::Info<csSpcDcItem_struct> csSpcDcItem_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csSpcDcItem_struct


typedef csSpcDcItem_struct* csSpcDcItem_struct_vPtr;
typedef const csSpcDcItem_struct* csSpcDcItem_struct_cvPtr;

class  csSpcDcItem_struct_var
{
    public:

    csSpcDcItem_struct_var ();

    csSpcDcItem_struct_var (csSpcDcItem_struct *_p);

    csSpcDcItem_struct_var (const csSpcDcItem_struct_var &_s);

    csSpcDcItem_struct_var &operator= (csSpcDcItem_struct *_p);

    csSpcDcItem_struct_var &operator= (const csSpcDcItem_struct_var &_s);

    ~csSpcDcItem_struct_var ();

    csSpcDcItem_struct* operator-> ();

    const csSpcDcItem_struct& in() const;
    csSpcDcItem_struct& inout();
    csSpcDcItem_struct*& out();
    csSpcDcItem_struct* _retn();

    operator csSpcDcItem_struct_cvPtr () const;

    operator csSpcDcItem_struct_vPtr& ();

    operator const csSpcDcItem_struct& () const;

    operator csSpcDcItem_struct& ();

    protected:
    csSpcDcItem_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csSpcDcItem_struct;
    typedef csSpcDcItem_struct csSpcDcItem;
    typedef csSpcDcItem_struct_var csSpcDcItem_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSpcDcItem;
class  _IDL_SEQ_csSpcDcItemSequence_0_var;
class  _IDL_SEQ_csSpcDcItemSequence_0 {
    public:
        typedef _IDL_SEQ_csSpcDcItemSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csSpcDcItem *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csSpcDcItemSequence_0 ();
    _IDL_SEQ_csSpcDcItemSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csSpcDcItemSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csSpcDcItem* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csSpcDcItemSequence_0 (const _IDL_SEQ_csSpcDcItemSequence_0&);

    ~_IDL_SEQ_csSpcDcItemSequence_0 ();

    _IDL_SEQ_csSpcDcItemSequence_0& operator= (const _IDL_SEQ_csSpcDcItemSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csSpcDcItem& operator [] (::CORBA::ULong indx);
    const csSpcDcItem& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csSpcDcItem* get_buffer (::CORBA::Boolean orphan=0);
    const csSpcDcItem* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csSpcDcItem* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csSpcDcItem* src, csSpcDcItem* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csSpcDcItem* data); 
  public:

    static csSpcDcItem* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csSpcDcItem* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csSpcDcItem* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csSpcDcItemSequence_0> csSpcDcItemSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csSpcDcItemSequence_0* _IDL_SEQ_csSpcDcItemSequence_0_vPtr;
typedef const _IDL_SEQ_csSpcDcItemSequence_0* _IDL_SEQ_csSpcDcItemSequence_0_cvPtr;

class  _IDL_SEQ_csSpcDcItemSequence_0_var
{
    public:

    _IDL_SEQ_csSpcDcItemSequence_0_var ();

    _IDL_SEQ_csSpcDcItemSequence_0_var (_IDL_SEQ_csSpcDcItemSequence_0 *_p);

    _IDL_SEQ_csSpcDcItemSequence_0_var (const _IDL_SEQ_csSpcDcItemSequence_0_var &_s);

    _IDL_SEQ_csSpcDcItemSequence_0_var &operator= (_IDL_SEQ_csSpcDcItemSequence_0 *_p);

    _IDL_SEQ_csSpcDcItemSequence_0_var &operator= (const _IDL_SEQ_csSpcDcItemSequence_0_var &_s);

    ~_IDL_SEQ_csSpcDcItemSequence_0_var ();

    _IDL_SEQ_csSpcDcItemSequence_0* operator-> ();

    operator _IDL_SEQ_csSpcDcItemSequence_0_cvPtr () const;

    operator _IDL_SEQ_csSpcDcItemSequence_0_vPtr& ();

    operator _IDL_SEQ_csSpcDcItemSequence_0() const;

    const csSpcDcItem& operator[] (::CORBA::ULong index) const;
    csSpcDcItem& operator[] (::CORBA::ULong index);
    const csSpcDcItem& operator[] (int index) const;
    csSpcDcItem& operator[] (int index);
    const _IDL_SEQ_csSpcDcItemSequence_0& in() const;
    _IDL_SEQ_csSpcDcItemSequence_0& inout();
    _IDL_SEQ_csSpcDcItemSequence_0*& out();
    _IDL_SEQ_csSpcDcItemSequence_0* _retn();

    protected:
    _IDL_SEQ_csSpcDcItemSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csSpcDcItemSequence_0 _csSpcDcItemSequence_seq;
    typedef _IDL_SEQ_csSpcDcItemSequence_0 _csSpcDcItemSequence_seq_1;
    typedef _IDL_SEQ_csSpcDcItemSequence_0 csSpcDcItemSequence;
    typedef _IDL_SEQ_csSpcDcItemSequence_0_var csSpcDcItemSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSpcDcItemSequence;
    class  csSpcInput_struct_var;
    struct  csSpcInput_struct {
        typedef csSpcInput_struct_var _var_type;
       ::objectIdentifier requestUserID;
       ::objectIdentifier lotID;
       ::objectIdentifier processEquipmentID;
       ::objectIdentifier processRecipeID;
       ::objectIdentifier processMainProcessDefinitionID;
       ::objectIdentifier processProcessDefinitionID;
       ::CORBA::String_StructElem processOperationNumber;
       ::objectIdentifier measurementEquipmentID;
       ::objectIdentifier technologyID;
       ::objectIdentifier productGroupID;
       ::objectIdentifier productID;
       ::objectIdentifier reticleID;
       ::objectIdentifierSequence reticleIDs;
       ::objectIdentifier fixtureID;
       ::objectIdentifier mainProcessDefinitionID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::String_StructElem operationName;
       ::objectIdentifier ownerUserID;
       ::CORBA::String_StructElem collectionType;
       ::objectIdentifier dcDefID;
       ::csSpcDcItemSequence dcItems;
       ::pptWaferIDByChamberSequence waferIDByChambers;
       ::CORBA::String_StructElem lotComment;
       ::CORBA::String_StructElem processTimestamp;
       ::CORBA::String_StructElem measurementTimestamp;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csSpcInput_struct();
       csSpcInput_struct(const csSpcInput_struct&);
       csSpcInput_struct& operator=(const csSpcInput_struct&);
       static CORBA::Info<csSpcInput_struct> csSpcInput_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csSpcInput_struct


typedef csSpcInput_struct* csSpcInput_struct_vPtr;
typedef const csSpcInput_struct* csSpcInput_struct_cvPtr;

class  csSpcInput_struct_var
{
    public:

    csSpcInput_struct_var ();

    csSpcInput_struct_var (csSpcInput_struct *_p);

    csSpcInput_struct_var (const csSpcInput_struct_var &_s);

    csSpcInput_struct_var &operator= (csSpcInput_struct *_p);

    csSpcInput_struct_var &operator= (const csSpcInput_struct_var &_s);

    ~csSpcInput_struct_var ();

    csSpcInput_struct* operator-> ();

    const csSpcInput_struct& in() const;
    csSpcInput_struct& inout();
    csSpcInput_struct*& out();
    csSpcInput_struct* _retn();

    operator csSpcInput_struct_cvPtr () const;

    operator csSpcInput_struct_vPtr& ();

    operator const csSpcInput_struct& () const;

    operator csSpcInput_struct& ();

    protected:
    csSpcInput_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csSpcInput_struct;
    typedef csSpcInput_struct csSpcInput;
    typedef csSpcInput_struct_var csSpcInput_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSpcInput;
    class  csSpcOutput_struct_var;
    struct  csSpcOutput_struct {
        typedef csSpcOutput_struct_var _var_type;
       ::CORBA::String_StructElem txRC;
       ::objectIdentifier lotID;
       ::CORBA::String_StructElem lotRC;
       ::CORBA::String_StructElem lotHoldAction;
       ::spcChamberHoldActionSequence chamberHoldActions;
       ::CORBA::String_StructElem equipmentHoldAction;
       ::CORBA::String_StructElem processHoldAction;
       ::CORBA::String_StructElem recipeHoldAction;
       ::CORBA::String_StructElem reworkBranchAction;
       ::CORBA::String_StructElem mailSendAction;
       ::CORBA::String_StructElem bankMoveAction;
       ::CORBA::String_StructElem bankID;
       ::CORBA::String_StructElem reworkRouteID;
       ::CORBA::String_StructElem productHoldAction;
       ::CORBA::String_StructElem reticleHoldAction;
       ::CORBA::String_StructElem reticleGroupHoldAction;
       ::CORBA::String_StructElem moduleHoldAction;
       ::CORBA::String_StructElem routeHoldAction;
       ::CORBA::String_StructElem routeOpeNoProductHoldAction;
       ::CORBA::String_StructElem eqptRecipeHoldAction;
       ::CORBA::String_StructElem eqptOpeNoHoldAction;
       ::CORBA::String_StructElem eqptReticleHoldAction;
       ::CORBA::String_StructElem eqptProcessHoldAction;
       ::CORBA::String_StructElem eqptChamberRecipeHoldAction;
       ::CORBA::String_StructElem eqptProductRecipeHoldAction;
       ::CORBA::String_StructElem routeOpeNoHoldAction;
       ::CORBA::String_StructElem eqptChamberHoldAction;
       ::CORBA::String_StructElem otherAction;
       ::spcItemResultSequence itemResults;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csSpcOutput_struct();
       csSpcOutput_struct(const csSpcOutput_struct&);
       csSpcOutput_struct& operator=(const csSpcOutput_struct&);
       static CORBA::Info<csSpcOutput_struct> csSpcOutput_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csSpcOutput_struct


typedef csSpcOutput_struct* csSpcOutput_struct_vPtr;
typedef const csSpcOutput_struct* csSpcOutput_struct_cvPtr;

class  csSpcOutput_struct_var
{
    public:

    csSpcOutput_struct_var ();

    csSpcOutput_struct_var (csSpcOutput_struct *_p);

    csSpcOutput_struct_var (const csSpcOutput_struct_var &_s);

    csSpcOutput_struct_var &operator= (csSpcOutput_struct *_p);

    csSpcOutput_struct_var &operator= (const csSpcOutput_struct_var &_s);

    ~csSpcOutput_struct_var ();

    csSpcOutput_struct* operator-> ();

    const csSpcOutput_struct& in() const;
    csSpcOutput_struct& inout();
    csSpcOutput_struct*& out();
    csSpcOutput_struct* _retn();

    operator csSpcOutput_struct_cvPtr () const;

    operator csSpcOutput_struct_vPtr& ();

    operator const csSpcOutput_struct& () const;

    operator csSpcOutput_struct& ();

    protected:
    csSpcOutput_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csSpcOutput_struct;
    typedef csSpcOutput_struct csSpcOutput;
    typedef csSpcOutput_struct_var csSpcOutput_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSpcOutput;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_spcsvrstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_spcsvrstr_ANYOPERATOR__
#undef __NOTUSE_cs_spcsvrstr_ANYOPERATOR__
#endif //__USE_cs_spcsvrstr_ANYOPERATOR__
#ifndef __NOTUSE_cs_spcsvrstr_ANYOPERATOR__
#define _DCL_ANYOPS_csSpcDcItem_struct
#define _DCL_ANYOPS_csSpcDcItemSequence
#define _DCL_ANYOPS_csSpcInput_struct
#define _DCL_ANYOPS_csSpcOutput_struct
#endif //__NOTUSE_cs_spcsvrstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_csSpcDcItem_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csSpcDcItem_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csSpcDcItem_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csSpcDcItem_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csSpcDcItem_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csSpcDcItem_struct
#ifdef _DCL_ANYOPS_csSpcDcItemSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csSpcDcItemSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csSpcDcItemSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csSpcDcItemSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csSpcDcItemSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csSpcDcItemSequence
#ifdef _DCL_ANYOPS_csSpcInput_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csSpcInput_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csSpcInput_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csSpcInput_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csSpcInput_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csSpcInput_struct
#ifdef _DCL_ANYOPS_csSpcOutput_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csSpcOutput_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csSpcOutput_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csSpcOutput_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csSpcOutput_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csSpcOutput_struct

#endif /* _cs_spcsvrstr_hh_included */

#endif /* _cs_spcsvrstr_server_defined */
