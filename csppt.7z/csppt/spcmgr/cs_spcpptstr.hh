//----------------------------------------------------------------------------
//
//  Generated from cs_spcpptstr.idl
//  On Tuesday, November 14, 2017 12:08:40 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_spcpptstr_server_defined
#ifndef _cs_spcpptstr_hh_included
#define _cs_spcpptstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_SPCPPT_Structures_idl 
#define CS_SPCPPT_Structures_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_spcsvrstr_hh_included
#include <cs_spcsvrstr.hh>
#endif
#else
#ifndef _cs_spcsvrstr_hh_included
#include "cs_spcsvrstr.hh"
#endif
#endif

   static const char* ex_SPCException = "SPCException";
   class  SPCException : public ::CORBA::UserException {
     public:
       static const  char* _exception_id;

       ::CORBA::String_StructElem functionName;
       ::CORBA::String_StructElem r1;
       ::CORBA::String_StructElem r2;
       ::CORBA::String_StructElem r3;
       ::CORBA::String_StructElem r4;
       ::CORBA::Long retn;

       SPCException () : CORBA::UserException (ex_SPCException, "IDL:SPCException:1.0") { };
        SPCException(const SPCException&);
        SPCException& operator=(const SPCException&);
       SPCException ( const char* _functionName, const char* _r1, const char* _r2, const char* _r3, const char* _r4, const ::CORBA::Long _retn) : CORBA::UserException (ex_SPCException, "IDL:SPCException:1.0") { 
         functionName = _functionName;
         r1 = _r1;
         r2 = _r2;
         r3 = _r3;
         r4 = _r4;
         retn = _retn;
       }

       // The _narrow methods are depricated; use _downcast 
       static  SPCException* SOMLINK _narrow (::CORBA::Exception *e);
       static  const SPCException* SOMLINK _narrow (const ::CORBA::Exception *e) {
         return _narrow ((::CORBA::Exception *)e); }
       static  SPCException* SOMLINK _downcast (::CORBA::Exception *e) {return _narrow(e);}
       static  const SPCException* SOMLINK _downcast (const ::CORBA::Exception *e) {return _narrow(e);}
       void  encodeOp(::CORBA::Request &_req) const;
       void  decodeOp(::CORBA::Request &_req);
   }; // exception SPCException

    extern  ::CORBA::TypeCode_ptr _tc_SPCException;
    class  pptSpcProfileTbl_struct_var;
    struct  pptSpcProfileTbl_struct {
        typedef pptSpcProfileTbl_struct_var _var_type;
       ::CORBA::String_StructElem pKey;
       ::CORBA::Long maxLog;
       ::CORBA::Long maxPoints;
       ::CORBA::Long analyzePoints;
       ::CORBA::Long sampleSize;
       ::CORBA::String_StructElem specFlag;
       ::CORBA::String_StructElem ruleFlag;
       ::CORBA::String_StructElem holdAction;
       ::CORBA::String_StructElem meanAnal;
       ::CORBA::String_StructElem dataHis;
       ::CORBA::String_StructElem rawHis;
       ::CORBA::String_StructElem alarmFlag;
       ::CORBA::Long rptDateW;
       ::CORBA::Long rptDateM;
       ::CORBA::Long rule01;
       ::CORBA::Long rule02;
       ::CORBA::Long rule03;
       ::CORBA::Long rule04;
       ::CORBA::Long rule05;
       ::CORBA::Long rule06;
       ::CORBA::Long rule07;
       ::CORBA::Long rule08;
       ::CORBA::Long rule09;
       ::CORBA::Long rule10;
       ::CORBA::Long rule11;
       ::CORBA::Long rule12;
       ::CORBA::Long rule13;
       ::CORBA::Long rule14;
       ::CORBA::Long rule15;
       ::CORBA::Long rule16;
       ::CORBA::Long rule17;
       ::CORBA::Long rule18;
       ::CORBA::Long rule19;
       ::CORBA::Long rule20;
       ::CORBA::Long rule21;
       ::CORBA::Long rule22;
       ::CORBA::Long rule23;
       ::CORBA::Long rule24;
       ::CORBA::Long rule25;
       ::CORBA::Long rule26;
       ::CORBA::Long rule27;
       ::CORBA::Long rule28;
       ::CORBA::Long rule29;
       ::CORBA::Long rule30;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcProfileTbl_struct();
       pptSpcProfileTbl_struct(const pptSpcProfileTbl_struct&);
       pptSpcProfileTbl_struct& operator=(const pptSpcProfileTbl_struct&);
       static CORBA::Info<pptSpcProfileTbl_struct> pptSpcProfileTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcProfileTbl_struct


typedef pptSpcProfileTbl_struct* pptSpcProfileTbl_struct_vPtr;
typedef const pptSpcProfileTbl_struct* pptSpcProfileTbl_struct_cvPtr;

class  pptSpcProfileTbl_struct_var
{
    public:

    pptSpcProfileTbl_struct_var ();

    pptSpcProfileTbl_struct_var (pptSpcProfileTbl_struct *_p);

    pptSpcProfileTbl_struct_var (const pptSpcProfileTbl_struct_var &_s);

    pptSpcProfileTbl_struct_var &operator= (pptSpcProfileTbl_struct *_p);

    pptSpcProfileTbl_struct_var &operator= (const pptSpcProfileTbl_struct_var &_s);

    ~pptSpcProfileTbl_struct_var ();

    pptSpcProfileTbl_struct* operator-> ();

    const pptSpcProfileTbl_struct& in() const;
    pptSpcProfileTbl_struct& inout();
    pptSpcProfileTbl_struct*& out();
    pptSpcProfileTbl_struct* _retn();

    operator pptSpcProfileTbl_struct_cvPtr () const;

    operator pptSpcProfileTbl_struct_vPtr& ();

    operator const pptSpcProfileTbl_struct& () const;

    operator pptSpcProfileTbl_struct& ();

    protected:
    pptSpcProfileTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcProfileTbl_struct;
    typedef pptSpcProfileTbl_struct pptSpcProfileTbl;
    typedef pptSpcProfileTbl_struct_var pptSpcProfileTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcProfileTbl;
class  _IDL_SEQ_pptSpcProfileTblSequence_0_var;
class  _IDL_SEQ_pptSpcProfileTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcProfileTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcProfileTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcProfileTblSequence_0 ();
    _IDL_SEQ_pptSpcProfileTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcProfileTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcProfileTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcProfileTblSequence_0 (const _IDL_SEQ_pptSpcProfileTblSequence_0&);

    ~_IDL_SEQ_pptSpcProfileTblSequence_0 ();

    _IDL_SEQ_pptSpcProfileTblSequence_0& operator= (const _IDL_SEQ_pptSpcProfileTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcProfileTbl& operator [] (::CORBA::ULong indx);
    const pptSpcProfileTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcProfileTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcProfileTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcProfileTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcProfileTbl* src, pptSpcProfileTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcProfileTbl* data); 
  public:

    static pptSpcProfileTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcProfileTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcProfileTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcProfileTblSequence_0> pptSpcProfileTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcProfileTblSequence_0* _IDL_SEQ_pptSpcProfileTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcProfileTblSequence_0* _IDL_SEQ_pptSpcProfileTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcProfileTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcProfileTblSequence_0_var ();

    _IDL_SEQ_pptSpcProfileTblSequence_0_var (_IDL_SEQ_pptSpcProfileTblSequence_0 *_p);

    _IDL_SEQ_pptSpcProfileTblSequence_0_var (const _IDL_SEQ_pptSpcProfileTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcProfileTblSequence_0_var &operator= (_IDL_SEQ_pptSpcProfileTblSequence_0 *_p);

    _IDL_SEQ_pptSpcProfileTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcProfileTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcProfileTblSequence_0_var ();

    _IDL_SEQ_pptSpcProfileTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcProfileTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcProfileTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcProfileTblSequence_0() const;

    const pptSpcProfileTbl& operator[] (::CORBA::ULong index) const;
    pptSpcProfileTbl& operator[] (::CORBA::ULong index);
    const pptSpcProfileTbl& operator[] (int index) const;
    pptSpcProfileTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcProfileTblSequence_0& in() const;
    _IDL_SEQ_pptSpcProfileTblSequence_0& inout();
    _IDL_SEQ_pptSpcProfileTblSequence_0*& out();
    _IDL_SEQ_pptSpcProfileTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcProfileTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcProfileTblSequence_0 _pptSpcProfileTblSequence_seq;
    typedef _IDL_SEQ_pptSpcProfileTblSequence_0 _pptSpcProfileTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcProfileTblSequence_0 pptSpcProfileTblSequence;
    typedef _IDL_SEQ_pptSpcProfileTblSequence_0_var pptSpcProfileTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcProfileTblSequence;
    class  pptSpcRpCpSumTbl_struct_var;
    struct  pptSpcRpCpSumTbl_struct {
        typedef pptSpcRpCpSumTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::String_StructElem rType;
       ::CORBA::String_StructElem bDate;
       ::CORBA::String_StructElem eDate;
       ::CORBA::String_StructElem gName;
       ::CORBA::String_StructElem cName;
       ::CORBA::Long cType;
       ::objectIdentifier productID;
       ::objectIdentifier processEquipmentID;
       ::CORBA::Double uslValue;
       ::CORBA::Double uclValue;
       ::CORBA::Double targetValue;
       ::CORBA::Double lclValue;
       ::CORBA::Double lslValue;
       ::CORBA::Double meanValue;
       ::CORBA::Double sigmaValue;
       ::CORBA::Long totalCount;
       ::CORBA::Long oosCount;
       ::CORBA::Double oosRate;
       ::CORBA::Long oocCount;
       ::CORBA::Double oocRate;
       ::CORBA::Long ooscCount;
       ::CORBA::Double ooscRate;
       ::CORBA::Double caValue;
       ::CORBA::Double cpValue;
       ::CORBA::Double cpkValue;
       ::CORBA::String_StructElem grade;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcRpCpSumTbl_struct();
       pptSpcRpCpSumTbl_struct(const pptSpcRpCpSumTbl_struct&);
       pptSpcRpCpSumTbl_struct& operator=(const pptSpcRpCpSumTbl_struct&);
       static CORBA::Info<pptSpcRpCpSumTbl_struct> pptSpcRpCpSumTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct pptSpcRpCpSumTbl_struct


typedef pptSpcRpCpSumTbl_struct* pptSpcRpCpSumTbl_struct_vPtr;
typedef const pptSpcRpCpSumTbl_struct* pptSpcRpCpSumTbl_struct_cvPtr;

class  pptSpcRpCpSumTbl_struct_var
{
    public:

    pptSpcRpCpSumTbl_struct_var ();

    pptSpcRpCpSumTbl_struct_var (pptSpcRpCpSumTbl_struct *_p);

    pptSpcRpCpSumTbl_struct_var (const pptSpcRpCpSumTbl_struct_var &_s);

    pptSpcRpCpSumTbl_struct_var &operator= (pptSpcRpCpSumTbl_struct *_p);

    pptSpcRpCpSumTbl_struct_var &operator= (const pptSpcRpCpSumTbl_struct_var &_s);

    ~pptSpcRpCpSumTbl_struct_var ();

    pptSpcRpCpSumTbl_struct* operator-> ();

    const pptSpcRpCpSumTbl_struct& in() const;
    pptSpcRpCpSumTbl_struct& inout();
    pptSpcRpCpSumTbl_struct*& out();
    pptSpcRpCpSumTbl_struct* _retn();

    operator pptSpcRpCpSumTbl_struct_cvPtr () const;

    operator pptSpcRpCpSumTbl_struct_vPtr& ();

    operator const pptSpcRpCpSumTbl_struct& () const;

    operator pptSpcRpCpSumTbl_struct& ();

    protected:
    pptSpcRpCpSumTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRpCpSumTbl_struct;
    typedef pptSpcRpCpSumTbl_struct pptSpcRpCpSumTbl;
    typedef pptSpcRpCpSumTbl_struct_var pptSpcRpCpSumTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRpCpSumTbl;
class  _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var;
class  _IDL_SEQ_pptSpcRpCpSumTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcRpCpSumTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcRpCpSumTblSequence_0 ();
    _IDL_SEQ_pptSpcRpCpSumTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcRpCpSumTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcRpCpSumTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcRpCpSumTblSequence_0 (const _IDL_SEQ_pptSpcRpCpSumTblSequence_0&);

    ~_IDL_SEQ_pptSpcRpCpSumTblSequence_0 ();

    _IDL_SEQ_pptSpcRpCpSumTblSequence_0& operator= (const _IDL_SEQ_pptSpcRpCpSumTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcRpCpSumTbl& operator [] (::CORBA::ULong indx);
    const pptSpcRpCpSumTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcRpCpSumTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcRpCpSumTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcRpCpSumTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcRpCpSumTbl* src, pptSpcRpCpSumTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcRpCpSumTbl* data); 
  public:

    static pptSpcRpCpSumTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcRpCpSumTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcRpCpSumTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcRpCpSumTblSequence_0> pptSpcRpCpSumTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcRpCpSumTblSequence_0* _IDL_SEQ_pptSpcRpCpSumTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcRpCpSumTblSequence_0* _IDL_SEQ_pptSpcRpCpSumTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var ();

    _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var (_IDL_SEQ_pptSpcRpCpSumTblSequence_0 *_p);

    _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var (const _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var &operator= (_IDL_SEQ_pptSpcRpCpSumTblSequence_0 *_p);

    _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcRpCpSumTblSequence_0_var ();

    _IDL_SEQ_pptSpcRpCpSumTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcRpCpSumTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcRpCpSumTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcRpCpSumTblSequence_0() const;

    const pptSpcRpCpSumTbl& operator[] (::CORBA::ULong index) const;
    pptSpcRpCpSumTbl& operator[] (::CORBA::ULong index);
    const pptSpcRpCpSumTbl& operator[] (int index) const;
    pptSpcRpCpSumTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcRpCpSumTblSequence_0& in() const;
    _IDL_SEQ_pptSpcRpCpSumTblSequence_0& inout();
    _IDL_SEQ_pptSpcRpCpSumTblSequence_0*& out();
    _IDL_SEQ_pptSpcRpCpSumTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcRpCpSumTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcRpCpSumTblSequence_0 _pptSpcRpCpSumTblSequence_seq;
    typedef _IDL_SEQ_pptSpcRpCpSumTblSequence_0 _pptSpcRpCpSumTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcRpCpSumTblSequence_0 pptSpcRpCpSumTblSequence;
    typedef _IDL_SEQ_pptSpcRpCpSumTblSequence_0_var pptSpcRpCpSumTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRpCpSumTblSequence;
    class  pptSpcRpDateRecTbl_struct_var;
    struct  pptSpcRpDateRecTbl_struct {
        typedef pptSpcRpDateRecTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::String_StructElem rType;
       ::CORBA::String_StructElem bDate;
       ::CORBA::String_StructElem eDate;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcRpDateRecTbl_struct();
       pptSpcRpDateRecTbl_struct(const pptSpcRpDateRecTbl_struct&);
       pptSpcRpDateRecTbl_struct& operator=(const pptSpcRpDateRecTbl_struct&);
       static CORBA::Info<pptSpcRpDateRecTbl_struct> pptSpcRpDateRecTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcRpDateRecTbl_struct


typedef pptSpcRpDateRecTbl_struct* pptSpcRpDateRecTbl_struct_vPtr;
typedef const pptSpcRpDateRecTbl_struct* pptSpcRpDateRecTbl_struct_cvPtr;

class  pptSpcRpDateRecTbl_struct_var
{
    public:

    pptSpcRpDateRecTbl_struct_var ();

    pptSpcRpDateRecTbl_struct_var (pptSpcRpDateRecTbl_struct *_p);

    pptSpcRpDateRecTbl_struct_var (const pptSpcRpDateRecTbl_struct_var &_s);

    pptSpcRpDateRecTbl_struct_var &operator= (pptSpcRpDateRecTbl_struct *_p);

    pptSpcRpDateRecTbl_struct_var &operator= (const pptSpcRpDateRecTbl_struct_var &_s);

    ~pptSpcRpDateRecTbl_struct_var ();

    pptSpcRpDateRecTbl_struct* operator-> ();

    const pptSpcRpDateRecTbl_struct& in() const;
    pptSpcRpDateRecTbl_struct& inout();
    pptSpcRpDateRecTbl_struct*& out();
    pptSpcRpDateRecTbl_struct* _retn();

    operator pptSpcRpDateRecTbl_struct_cvPtr () const;

    operator pptSpcRpDateRecTbl_struct_vPtr& ();

    operator const pptSpcRpDateRecTbl_struct& () const;

    operator pptSpcRpDateRecTbl_struct& ();

    protected:
    pptSpcRpDateRecTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRpDateRecTbl_struct;
    typedef pptSpcRpDateRecTbl_struct pptSpcRpDateRecTbl;
    typedef pptSpcRpDateRecTbl_struct_var pptSpcRpDateRecTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRpDateRecTbl;
class  _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var;
class  _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 {
    public:
        typedef _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcRpDateRecTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 ();
    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcRpDateRecTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 (const _IDL_SEQ_ppptSpcRpDateRecTblSequence_0&);

    ~_IDL_SEQ_ppptSpcRpDateRecTblSequence_0 ();

    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0& operator= (const _IDL_SEQ_ppptSpcRpDateRecTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcRpDateRecTbl& operator [] (::CORBA::ULong indx);
    const pptSpcRpDateRecTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcRpDateRecTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcRpDateRecTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcRpDateRecTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcRpDateRecTbl* src, pptSpcRpDateRecTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcRpDateRecTbl* data); 
  public:

    static pptSpcRpDateRecTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcRpDateRecTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcRpDateRecTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_ppptSpcRpDateRecTblSequence_0> ppptSpcRpDateRecTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_ppptSpcRpDateRecTblSequence_0* _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_vPtr;
typedef const _IDL_SEQ_ppptSpcRpDateRecTblSequence_0* _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_cvPtr;

class  _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var
{
    public:

    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var ();

    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var (_IDL_SEQ_ppptSpcRpDateRecTblSequence_0 *_p);

    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var (const _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var &_s);

    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var &operator= (_IDL_SEQ_ppptSpcRpDateRecTblSequence_0 *_p);

    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var &operator= (const _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var &_s);

    ~_IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var ();

    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0* operator-> ();

    operator _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_vPtr& ();

    operator _IDL_SEQ_ppptSpcRpDateRecTblSequence_0() const;

    const pptSpcRpDateRecTbl& operator[] (::CORBA::ULong index) const;
    pptSpcRpDateRecTbl& operator[] (::CORBA::ULong index);
    const pptSpcRpDateRecTbl& operator[] (int index) const;
    pptSpcRpDateRecTbl& operator[] (int index);
    const _IDL_SEQ_ppptSpcRpDateRecTblSequence_0& in() const;
    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0& inout();
    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0*& out();
    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0* _retn();

    protected:
    _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 _ppptSpcRpDateRecTblSequence_seq;
    typedef _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 _ppptSpcRpDateRecTblSequence_seq_1;
    typedef _IDL_SEQ_ppptSpcRpDateRecTblSequence_0 ppptSpcRpDateRecTblSequence;
    typedef _IDL_SEQ_ppptSpcRpDateRecTblSequence_0_var ppptSpcRpDateRecTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_ppptSpcRpDateRecTblSequence;
    class  pptSpcGmTbl_struct_var;
    struct  pptSpcGmTbl_struct {
        typedef pptSpcGmTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::Long gNo;
       ::CORBA::String_StructElem gName;
       ::CORBA::String_StructElem gDesc;
       ::CORBA::Long subGno;
       ::objectIdentifier processEquipmentID;
       ::objectIdentifier processRecipeID;
       ::CORBA::String_StructElem infoTag;
       ::CORBA::String_StructElem exclusionFlag;
       ::CORBA::String_StructElem groupType;
       ::CORBA::String_StructElem deptID;
       ::CORBA::String_StructElem option1;
       ::CORBA::String_StructElem option2;
       ::CORBA::String_StructElem option3;
       ::CORBA::String_StructElem option4;
       ::CORBA::String_StructElem option5;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcGmTbl_struct();
       pptSpcGmTbl_struct(const pptSpcGmTbl_struct&);
       pptSpcGmTbl_struct& operator=(const pptSpcGmTbl_struct&);
       static CORBA::Info<pptSpcGmTbl_struct> pptSpcGmTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct pptSpcGmTbl_struct


typedef pptSpcGmTbl_struct* pptSpcGmTbl_struct_vPtr;
typedef const pptSpcGmTbl_struct* pptSpcGmTbl_struct_cvPtr;

class  pptSpcGmTbl_struct_var
{
    public:

    pptSpcGmTbl_struct_var ();

    pptSpcGmTbl_struct_var (pptSpcGmTbl_struct *_p);

    pptSpcGmTbl_struct_var (const pptSpcGmTbl_struct_var &_s);

    pptSpcGmTbl_struct_var &operator= (pptSpcGmTbl_struct *_p);

    pptSpcGmTbl_struct_var &operator= (const pptSpcGmTbl_struct_var &_s);

    ~pptSpcGmTbl_struct_var ();

    pptSpcGmTbl_struct* operator-> ();

    const pptSpcGmTbl_struct& in() const;
    pptSpcGmTbl_struct& inout();
    pptSpcGmTbl_struct*& out();
    pptSpcGmTbl_struct* _retn();

    operator pptSpcGmTbl_struct_cvPtr () const;

    operator pptSpcGmTbl_struct_vPtr& ();

    operator const pptSpcGmTbl_struct& () const;

    operator pptSpcGmTbl_struct& ();

    protected:
    pptSpcGmTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcGmTbl_struct;
    typedef pptSpcGmTbl_struct pptSpcGmTbl;
    typedef pptSpcGmTbl_struct_var pptSpcGmTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcGmTbl;
class  _IDL_SEQ_pptSpcGmTblSequence_0_var;
class  _IDL_SEQ_pptSpcGmTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcGmTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcGmTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcGmTblSequence_0 ();
    _IDL_SEQ_pptSpcGmTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcGmTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcGmTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcGmTblSequence_0 (const _IDL_SEQ_pptSpcGmTblSequence_0&);

    ~_IDL_SEQ_pptSpcGmTblSequence_0 ();

    _IDL_SEQ_pptSpcGmTblSequence_0& operator= (const _IDL_SEQ_pptSpcGmTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcGmTbl& operator [] (::CORBA::ULong indx);
    const pptSpcGmTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcGmTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcGmTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcGmTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcGmTbl* src, pptSpcGmTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcGmTbl* data); 
  public:

    static pptSpcGmTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcGmTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcGmTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcGmTblSequence_0> pptSpcGmTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcGmTblSequence_0* _IDL_SEQ_pptSpcGmTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcGmTblSequence_0* _IDL_SEQ_pptSpcGmTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcGmTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcGmTblSequence_0_var ();

    _IDL_SEQ_pptSpcGmTblSequence_0_var (_IDL_SEQ_pptSpcGmTblSequence_0 *_p);

    _IDL_SEQ_pptSpcGmTblSequence_0_var (const _IDL_SEQ_pptSpcGmTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcGmTblSequence_0_var &operator= (_IDL_SEQ_pptSpcGmTblSequence_0 *_p);

    _IDL_SEQ_pptSpcGmTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcGmTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcGmTblSequence_0_var ();

    _IDL_SEQ_pptSpcGmTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcGmTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcGmTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcGmTblSequence_0() const;

    const pptSpcGmTbl& operator[] (::CORBA::ULong index) const;
    pptSpcGmTbl& operator[] (::CORBA::ULong index);
    const pptSpcGmTbl& operator[] (int index) const;
    pptSpcGmTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcGmTblSequence_0& in() const;
    _IDL_SEQ_pptSpcGmTblSequence_0& inout();
    _IDL_SEQ_pptSpcGmTblSequence_0*& out();
    _IDL_SEQ_pptSpcGmTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcGmTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcGmTblSequence_0 _pptSpcGmTblSequence_seq;
    typedef _IDL_SEQ_pptSpcGmTblSequence_0 _pptSpcGmTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcGmTblSequence_0 pptSpcGmTblSequence;
    typedef _IDL_SEQ_pptSpcGmTblSequence_0_var pptSpcGmTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcGmTblSequence;
    class  pptSpcCmTbl_struct_var;
    struct  pptSpcCmTbl_struct {
        typedef pptSpcCmTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cVersion;
       ::CORBA::String_StructElem mfldID;
       ::CORBA::String_StructElem itemNm;
       ::CORBA::Long cType;
       ::CORBA::String_StructElem cName;
       ::CORBA::String_StructElem cTitle;
       ::CORBA::String_StructElem cOwner;
       ::CORBA::String_StructElem unit;
       ::CORBA::Double uklValue;
       ::CORBA::Double lklValue;
       ::CORBA::Double scale;
       ::CORBA::String_StructElem targetFlag;
       ::CORBA::String_StructElem rawFlag;
       ::CORBA::Long sampleSize;
       ::CORBA::Long decimalLen;
       ::CORBA::Long maxPoints;
       ::CORBA::String_StructElem chamberInfo;
       ::CORBA::String_StructElem eqpID;
       ::CORBA::String_StructElem chartLevel;
       ::CORBA::String_StructElem specSync;
       ::CORBA::String_StructElem autoCalControl;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcCmTbl_struct();
       pptSpcCmTbl_struct(const pptSpcCmTbl_struct&);
       pptSpcCmTbl_struct& operator=(const pptSpcCmTbl_struct&);
       static CORBA::Info<pptSpcCmTbl_struct> pptSpcCmTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcCmTbl_struct


typedef pptSpcCmTbl_struct* pptSpcCmTbl_struct_vPtr;
typedef const pptSpcCmTbl_struct* pptSpcCmTbl_struct_cvPtr;

class  pptSpcCmTbl_struct_var
{
    public:

    pptSpcCmTbl_struct_var ();

    pptSpcCmTbl_struct_var (pptSpcCmTbl_struct *_p);

    pptSpcCmTbl_struct_var (const pptSpcCmTbl_struct_var &_s);

    pptSpcCmTbl_struct_var &operator= (pptSpcCmTbl_struct *_p);

    pptSpcCmTbl_struct_var &operator= (const pptSpcCmTbl_struct_var &_s);

    ~pptSpcCmTbl_struct_var ();

    pptSpcCmTbl_struct* operator-> ();

    const pptSpcCmTbl_struct& in() const;
    pptSpcCmTbl_struct& inout();
    pptSpcCmTbl_struct*& out();
    pptSpcCmTbl_struct* _retn();

    operator pptSpcCmTbl_struct_cvPtr () const;

    operator pptSpcCmTbl_struct_vPtr& ();

    operator const pptSpcCmTbl_struct& () const;

    operator pptSpcCmTbl_struct& ();

    protected:
    pptSpcCmTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCmTbl_struct;
    typedef pptSpcCmTbl_struct pptSpcCmTbl;
    typedef pptSpcCmTbl_struct_var pptSpcCmTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCmTbl;
class  _IDL_SEQ_pptSpcCmTblSequence_0_var;
class  _IDL_SEQ_pptSpcCmTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcCmTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcCmTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcCmTblSequence_0 ();
    _IDL_SEQ_pptSpcCmTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcCmTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcCmTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcCmTblSequence_0 (const _IDL_SEQ_pptSpcCmTblSequence_0&);

    ~_IDL_SEQ_pptSpcCmTblSequence_0 ();

    _IDL_SEQ_pptSpcCmTblSequence_0& operator= (const _IDL_SEQ_pptSpcCmTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcCmTbl& operator [] (::CORBA::ULong indx);
    const pptSpcCmTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcCmTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcCmTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcCmTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcCmTbl* src, pptSpcCmTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcCmTbl* data); 
  public:

    static pptSpcCmTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcCmTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcCmTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcCmTblSequence_0> pptSpcCmTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcCmTblSequence_0* _IDL_SEQ_pptSpcCmTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcCmTblSequence_0* _IDL_SEQ_pptSpcCmTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcCmTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcCmTblSequence_0_var ();

    _IDL_SEQ_pptSpcCmTblSequence_0_var (_IDL_SEQ_pptSpcCmTblSequence_0 *_p);

    _IDL_SEQ_pptSpcCmTblSequence_0_var (const _IDL_SEQ_pptSpcCmTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcCmTblSequence_0_var &operator= (_IDL_SEQ_pptSpcCmTblSequence_0 *_p);

    _IDL_SEQ_pptSpcCmTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcCmTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcCmTblSequence_0_var ();

    _IDL_SEQ_pptSpcCmTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcCmTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcCmTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcCmTblSequence_0() const;

    const pptSpcCmTbl& operator[] (::CORBA::ULong index) const;
    pptSpcCmTbl& operator[] (::CORBA::ULong index);
    const pptSpcCmTbl& operator[] (int index) const;
    pptSpcCmTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcCmTblSequence_0& in() const;
    _IDL_SEQ_pptSpcCmTblSequence_0& inout();
    _IDL_SEQ_pptSpcCmTblSequence_0*& out();
    _IDL_SEQ_pptSpcCmTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcCmTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcCmTblSequence_0 _pptSpcCmTblSequence_seq;
    typedef _IDL_SEQ_pptSpcCmTblSequence_0 _pptSpcCmTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcCmTblSequence_0 pptSpcCmTblSequence;
    typedef _IDL_SEQ_pptSpcCmTblSequence_0_var pptSpcCmTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCmTblSequence;
    class  pptSpcCdTbl_struct_var;
    struct  pptSpcCdTbl_struct {
        typedef pptSpcCdTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cType;
       ::CORBA::Double uplValue;
       ::CORBA::Double uslValue;
       ::CORBA::Double uclValue;
       ::CORBA::Double uwlValue;
       ::CORBA::Double targetValue;
       ::CORBA::Double meanValue;
       ::CORBA::Double lwlValue;
       ::CORBA::Double lclValue;
       ::CORBA::Double lslValue;
       ::CORBA::Double lplValue;
       ::CORBA::Double maxValue;
       ::CORBA::Double minValue;
       ::CORBA::Double sigmaValue;
       ::CORBA::Double caValue;
       ::CORBA::Double cpValue;
       ::CORBA::Double cpkValue;
       ::CORBA::Double cpmValue;
       ::CORBA::Double ppValue;
       ::CORBA::Double ppkValue;
       ::CORBA::Double ppmValue;
       ::CORBA::String_StructElem lastTxDatetime;
       ::CORBA::String_StructElem ackFlag;
       ::CORBA::String_StructElem specFlag;
       ::CORBA::String_StructElem ruleFlag;
       ::CORBA::Long rule01;
       ::CORBA::Long rule02;
       ::CORBA::Long rule03;
       ::CORBA::Long rule04;
       ::CORBA::Long rule05;
       ::CORBA::Long rule06;
       ::CORBA::Long rule07;
       ::CORBA::Long rule08;
       ::CORBA::Long rule09;
       ::CORBA::Long rule10;
       ::CORBA::Long rule11;
       ::CORBA::Long rule12;
       ::CORBA::Long rule13;
       ::CORBA::Long rule14;
       ::CORBA::Long rule15;
       ::CORBA::Long rule16;
       ::CORBA::Long rule17;
       ::CORBA::Long rule18;
       ::CORBA::Long rule19;
       ::CORBA::Long rule20;
       ::CORBA::Long rule21;
       ::CORBA::Long rule22;
       ::CORBA::Long rule23;
       ::CORBA::Long rule24;
       ::CORBA::Long rule25;
       ::CORBA::Long rule26;
       ::CORBA::Long rule27;
       ::CORBA::Long rule28;
       ::CORBA::Long rule29;
       ::CORBA::Long rule30;
       ::CORBA::String_StructElem ruleResult;
       ::CORBA::Double latestData;
       ::CORBA::Double prevData;
       ::CORBA::String_StructElem ruleResult01;
       ::CORBA::String_StructElem ruleResult02;
       ::CORBA::String_StructElem ruleResult03;
       ::CORBA::String_StructElem ruleResult04;
       ::CORBA::String_StructElem ruleResult05;
       ::CORBA::String_StructElem ruleResult06;
       ::CORBA::String_StructElem ruleResult07;
       ::CORBA::String_StructElem ruleResult08;
       ::CORBA::String_StructElem ruleResult09;
       ::CORBA::String_StructElem ruleResult10;
       ::CORBA::String_StructElem ruleResult11;
       ::CORBA::String_StructElem ruleResult12;
       ::CORBA::String_StructElem ruleResult13;
       ::CORBA::String_StructElem ruleResult14;
       ::CORBA::String_StructElem ruleResult15;
       ::CORBA::String_StructElem ruleResult16;
       ::CORBA::String_StructElem ruleResult17;
       ::CORBA::String_StructElem ruleResult18;
       ::CORBA::String_StructElem ruleResult19;
       ::CORBA::String_StructElem ruleResult20;
       ::CORBA::String_StructElem ruleResult21;
       ::CORBA::String_StructElem ruleResult22;
       ::CORBA::String_StructElem ruleResult23;
       ::CORBA::String_StructElem ruleResult24;
       ::CORBA::String_StructElem ruleResult25;
       ::CORBA::String_StructElem ruleResult26;
       ::CORBA::String_StructElem ruleResult27;
       ::CORBA::String_StructElem ruleResult28;
       ::CORBA::String_StructElem ruleResult29;
       ::CORBA::String_StructElem ruleResult30;
       ::CORBA::String_StructElem oosOcap;
       ::CORBA::String_StructElem oocOcap;
       ::CORBA::String_StructElem specCheck;
       ::CORBA::String_StructElem ctrlCheck;
       ::CORBA::String_StructElem totalAction;
       ::CORBA::String_StructElem detailAction;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcCdTbl_struct();
       pptSpcCdTbl_struct(const pptSpcCdTbl_struct&);
       pptSpcCdTbl_struct& operator=(const pptSpcCdTbl_struct&);
       static CORBA::Info<pptSpcCdTbl_struct> pptSpcCdTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcCdTbl_struct


typedef pptSpcCdTbl_struct* pptSpcCdTbl_struct_vPtr;
typedef const pptSpcCdTbl_struct* pptSpcCdTbl_struct_cvPtr;

class  pptSpcCdTbl_struct_var
{
    public:

    pptSpcCdTbl_struct_var ();

    pptSpcCdTbl_struct_var (pptSpcCdTbl_struct *_p);

    pptSpcCdTbl_struct_var (const pptSpcCdTbl_struct_var &_s);

    pptSpcCdTbl_struct_var &operator= (pptSpcCdTbl_struct *_p);

    pptSpcCdTbl_struct_var &operator= (const pptSpcCdTbl_struct_var &_s);

    ~pptSpcCdTbl_struct_var ();

    pptSpcCdTbl_struct* operator-> ();

    const pptSpcCdTbl_struct& in() const;
    pptSpcCdTbl_struct& inout();
    pptSpcCdTbl_struct*& out();
    pptSpcCdTbl_struct* _retn();

    operator pptSpcCdTbl_struct_cvPtr () const;

    operator pptSpcCdTbl_struct_vPtr& ();

    operator const pptSpcCdTbl_struct& () const;

    operator pptSpcCdTbl_struct& ();

    protected:
    pptSpcCdTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCdTbl_struct;
    typedef pptSpcCdTbl_struct pptSpcCdTbl;
    typedef pptSpcCdTbl_struct_var pptSpcCdTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCdTbl;
class  _IDL_SEQ_pptSpcCdTblSequence_0_var;
class  _IDL_SEQ_pptSpcCdTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcCdTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcCdTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcCdTblSequence_0 ();
    _IDL_SEQ_pptSpcCdTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcCdTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcCdTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcCdTblSequence_0 (const _IDL_SEQ_pptSpcCdTblSequence_0&);

    ~_IDL_SEQ_pptSpcCdTblSequence_0 ();

    _IDL_SEQ_pptSpcCdTblSequence_0& operator= (const _IDL_SEQ_pptSpcCdTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcCdTbl& operator [] (::CORBA::ULong indx);
    const pptSpcCdTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcCdTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcCdTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcCdTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcCdTbl* src, pptSpcCdTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcCdTbl* data); 
  public:

    static pptSpcCdTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcCdTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcCdTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcCdTblSequence_0> pptSpcCdTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcCdTblSequence_0* _IDL_SEQ_pptSpcCdTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcCdTblSequence_0* _IDL_SEQ_pptSpcCdTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcCdTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcCdTblSequence_0_var ();

    _IDL_SEQ_pptSpcCdTblSequence_0_var (_IDL_SEQ_pptSpcCdTblSequence_0 *_p);

    _IDL_SEQ_pptSpcCdTblSequence_0_var (const _IDL_SEQ_pptSpcCdTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcCdTblSequence_0_var &operator= (_IDL_SEQ_pptSpcCdTblSequence_0 *_p);

    _IDL_SEQ_pptSpcCdTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcCdTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcCdTblSequence_0_var ();

    _IDL_SEQ_pptSpcCdTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcCdTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcCdTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcCdTblSequence_0() const;

    const pptSpcCdTbl& operator[] (::CORBA::ULong index) const;
    pptSpcCdTbl& operator[] (::CORBA::ULong index);
    const pptSpcCdTbl& operator[] (int index) const;
    pptSpcCdTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcCdTblSequence_0& in() const;
    _IDL_SEQ_pptSpcCdTblSequence_0& inout();
    _IDL_SEQ_pptSpcCdTblSequence_0*& out();
    _IDL_SEQ_pptSpcCdTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcCdTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcCdTblSequence_0 _pptSpcCdTblSequence_seq;
    typedef _IDL_SEQ_pptSpcCdTblSequence_0 _pptSpcCdTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcCdTblSequence_0 pptSpcCdTblSequence;
    typedef _IDL_SEQ_pptSpcCdTblSequence_0_var pptSpcCdTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCdTblSequence;
    class  pptSpcCdPSpecTbl_struct_var;
    struct  pptSpcCdPSpecTbl_struct {
        typedef pptSpcCdPSpecTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cType;
       ::objectIdentifier productID;
       ::CORBA::Double uslValue;
       ::CORBA::Double lslValue;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcCdPSpecTbl_struct();
       pptSpcCdPSpecTbl_struct(const pptSpcCdPSpecTbl_struct&);
       pptSpcCdPSpecTbl_struct& operator=(const pptSpcCdPSpecTbl_struct&);
       static CORBA::Info<pptSpcCdPSpecTbl_struct> pptSpcCdPSpecTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct pptSpcCdPSpecTbl_struct


typedef pptSpcCdPSpecTbl_struct* pptSpcCdPSpecTbl_struct_vPtr;
typedef const pptSpcCdPSpecTbl_struct* pptSpcCdPSpecTbl_struct_cvPtr;

class  pptSpcCdPSpecTbl_struct_var
{
    public:

    pptSpcCdPSpecTbl_struct_var ();

    pptSpcCdPSpecTbl_struct_var (pptSpcCdPSpecTbl_struct *_p);

    pptSpcCdPSpecTbl_struct_var (const pptSpcCdPSpecTbl_struct_var &_s);

    pptSpcCdPSpecTbl_struct_var &operator= (pptSpcCdPSpecTbl_struct *_p);

    pptSpcCdPSpecTbl_struct_var &operator= (const pptSpcCdPSpecTbl_struct_var &_s);

    ~pptSpcCdPSpecTbl_struct_var ();

    pptSpcCdPSpecTbl_struct* operator-> ();

    const pptSpcCdPSpecTbl_struct& in() const;
    pptSpcCdPSpecTbl_struct& inout();
    pptSpcCdPSpecTbl_struct*& out();
    pptSpcCdPSpecTbl_struct* _retn();

    operator pptSpcCdPSpecTbl_struct_cvPtr () const;

    operator pptSpcCdPSpecTbl_struct_vPtr& ();

    operator const pptSpcCdPSpecTbl_struct& () const;

    operator pptSpcCdPSpecTbl_struct& ();

    protected:
    pptSpcCdPSpecTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCdPSpecTbl_struct;
    typedef pptSpcCdPSpecTbl_struct pptSpcCdPSpecTbl;
    typedef pptSpcCdPSpecTbl_struct_var pptSpcCdPSpecTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCdPSpecTbl;
class  _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var;
class  _IDL_SEQ_pptSpcCdPSpecTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcCdPSpecTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcCdPSpecTblSequence_0 ();
    _IDL_SEQ_pptSpcCdPSpecTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcCdPSpecTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcCdPSpecTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcCdPSpecTblSequence_0 (const _IDL_SEQ_pptSpcCdPSpecTblSequence_0&);

    ~_IDL_SEQ_pptSpcCdPSpecTblSequence_0 ();

    _IDL_SEQ_pptSpcCdPSpecTblSequence_0& operator= (const _IDL_SEQ_pptSpcCdPSpecTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcCdPSpecTbl& operator [] (::CORBA::ULong indx);
    const pptSpcCdPSpecTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcCdPSpecTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcCdPSpecTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcCdPSpecTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcCdPSpecTbl* src, pptSpcCdPSpecTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcCdPSpecTbl* data); 
  public:

    static pptSpcCdPSpecTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcCdPSpecTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcCdPSpecTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcCdPSpecTblSequence_0> pptSpcCdPSpecTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcCdPSpecTblSequence_0* _IDL_SEQ_pptSpcCdPSpecTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcCdPSpecTblSequence_0* _IDL_SEQ_pptSpcCdPSpecTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var ();

    _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var (_IDL_SEQ_pptSpcCdPSpecTblSequence_0 *_p);

    _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var (const _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var &operator= (_IDL_SEQ_pptSpcCdPSpecTblSequence_0 *_p);

    _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcCdPSpecTblSequence_0_var ();

    _IDL_SEQ_pptSpcCdPSpecTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcCdPSpecTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcCdPSpecTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcCdPSpecTblSequence_0() const;

    const pptSpcCdPSpecTbl& operator[] (::CORBA::ULong index) const;
    pptSpcCdPSpecTbl& operator[] (::CORBA::ULong index);
    const pptSpcCdPSpecTbl& operator[] (int index) const;
    pptSpcCdPSpecTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcCdPSpecTblSequence_0& in() const;
    _IDL_SEQ_pptSpcCdPSpecTblSequence_0& inout();
    _IDL_SEQ_pptSpcCdPSpecTblSequence_0*& out();
    _IDL_SEQ_pptSpcCdPSpecTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcCdPSpecTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcCdPSpecTblSequence_0 _pptSpcCdPSpecTblSequence_seq;
    typedef _IDL_SEQ_pptSpcCdPSpecTblSequence_0 _pptSpcCdPSpecTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcCdPSpecTblSequence_0 pptSpcCdPSpecTblSequence;
    typedef _IDL_SEQ_pptSpcCdPSpecTblSequence_0_var pptSpcCdPSpecTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCdPSpecTblSequence;
    class  pptSpcRuleTbl_struct_var;
    struct  pptSpcRuleTbl_struct {
        typedef pptSpcRuleTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cType;
       ::CORBA::String_StructElem ruleMsg01;
       ::CORBA::String_StructElem ruleMsg02;
       ::CORBA::String_StructElem ruleMsg03;
       ::CORBA::String_StructElem ruleMsg04;
       ::CORBA::String_StructElem ruleMsg05;
       ::CORBA::String_StructElem ruleMsg06;
       ::CORBA::String_StructElem ruleMsg07;
       ::CORBA::String_StructElem ruleMsg08;
       ::CORBA::String_StructElem ruleMsg09;
       ::CORBA::String_StructElem ruleMsg10;
       ::CORBA::String_StructElem ruleMsg11;
       ::CORBA::String_StructElem ruleMsg12;
       ::CORBA::String_StructElem ruleMsg13;
       ::CORBA::String_StructElem ruleMsg14;
       ::CORBA::String_StructElem ruleMsg15;
       ::CORBA::String_StructElem ruleMsg16;
       ::CORBA::String_StructElem ruleMsg17;
       ::CORBA::String_StructElem ruleMsg18;
       ::CORBA::String_StructElem ruleMsg19;
       ::CORBA::String_StructElem ruleMsg20;
       ::CORBA::String_StructElem ruleMsg21;
       ::CORBA::String_StructElem ruleMsg22;
       ::CORBA::String_StructElem ruleMsg23;
       ::CORBA::String_StructElem ruleMsg24;
       ::CORBA::String_StructElem ruleMsg25;
       ::CORBA::String_StructElem ruleMsg26;
       ::CORBA::String_StructElem ruleMsg27;
       ::CORBA::String_StructElem ruleMsg28;
       ::CORBA::String_StructElem ruleMsg29;
       ::CORBA::String_StructElem ruleMsg30;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcRuleTbl_struct();
       pptSpcRuleTbl_struct(const pptSpcRuleTbl_struct&);
       pptSpcRuleTbl_struct& operator=(const pptSpcRuleTbl_struct&);
       static CORBA::Info<pptSpcRuleTbl_struct> pptSpcRuleTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcRuleTbl_struct


typedef pptSpcRuleTbl_struct* pptSpcRuleTbl_struct_vPtr;
typedef const pptSpcRuleTbl_struct* pptSpcRuleTbl_struct_cvPtr;

class  pptSpcRuleTbl_struct_var
{
    public:

    pptSpcRuleTbl_struct_var ();

    pptSpcRuleTbl_struct_var (pptSpcRuleTbl_struct *_p);

    pptSpcRuleTbl_struct_var (const pptSpcRuleTbl_struct_var &_s);

    pptSpcRuleTbl_struct_var &operator= (pptSpcRuleTbl_struct *_p);

    pptSpcRuleTbl_struct_var &operator= (const pptSpcRuleTbl_struct_var &_s);

    ~pptSpcRuleTbl_struct_var ();

    pptSpcRuleTbl_struct* operator-> ();

    const pptSpcRuleTbl_struct& in() const;
    pptSpcRuleTbl_struct& inout();
    pptSpcRuleTbl_struct*& out();
    pptSpcRuleTbl_struct* _retn();

    operator pptSpcRuleTbl_struct_cvPtr () const;

    operator pptSpcRuleTbl_struct_vPtr& ();

    operator const pptSpcRuleTbl_struct& () const;

    operator pptSpcRuleTbl_struct& ();

    protected:
    pptSpcRuleTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRuleTbl_struct;
    typedef pptSpcRuleTbl_struct pptSpcRuleTbl;
    typedef pptSpcRuleTbl_struct_var pptSpcRuleTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRuleTbl;
class  _IDL_SEQ_pptSpcRuleTblSequence_0_var;
class  _IDL_SEQ_pptSpcRuleTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcRuleTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcRuleTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcRuleTblSequence_0 ();
    _IDL_SEQ_pptSpcRuleTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcRuleTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcRuleTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcRuleTblSequence_0 (const _IDL_SEQ_pptSpcRuleTblSequence_0&);

    ~_IDL_SEQ_pptSpcRuleTblSequence_0 ();

    _IDL_SEQ_pptSpcRuleTblSequence_0& operator= (const _IDL_SEQ_pptSpcRuleTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcRuleTbl& operator [] (::CORBA::ULong indx);
    const pptSpcRuleTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcRuleTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcRuleTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcRuleTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcRuleTbl* src, pptSpcRuleTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcRuleTbl* data); 
  public:

    static pptSpcRuleTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcRuleTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcRuleTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcRuleTblSequence_0> pptSpcRuleTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcRuleTblSequence_0* _IDL_SEQ_pptSpcRuleTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcRuleTblSequence_0* _IDL_SEQ_pptSpcRuleTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcRuleTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcRuleTblSequence_0_var ();

    _IDL_SEQ_pptSpcRuleTblSequence_0_var (_IDL_SEQ_pptSpcRuleTblSequence_0 *_p);

    _IDL_SEQ_pptSpcRuleTblSequence_0_var (const _IDL_SEQ_pptSpcRuleTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcRuleTblSequence_0_var &operator= (_IDL_SEQ_pptSpcRuleTblSequence_0 *_p);

    _IDL_SEQ_pptSpcRuleTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcRuleTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcRuleTblSequence_0_var ();

    _IDL_SEQ_pptSpcRuleTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcRuleTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcRuleTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcRuleTblSequence_0() const;

    const pptSpcRuleTbl& operator[] (::CORBA::ULong index) const;
    pptSpcRuleTbl& operator[] (::CORBA::ULong index);
    const pptSpcRuleTbl& operator[] (int index) const;
    pptSpcRuleTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcRuleTblSequence_0& in() const;
    _IDL_SEQ_pptSpcRuleTblSequence_0& inout();
    _IDL_SEQ_pptSpcRuleTblSequence_0*& out();
    _IDL_SEQ_pptSpcRuleTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcRuleTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcRuleTblSequence_0 _pptSpcRuleTblSequence_seq;
    typedef _IDL_SEQ_pptSpcRuleTblSequence_0 _pptSpcRuleTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcRuleTblSequence_0 pptSpcRuleTblSequence;
    typedef _IDL_SEQ_pptSpcRuleTblSequence_0_var pptSpcRuleTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRuleTblSequence;
    class  pptSpcActionTbl_struct_var;
    struct  pptSpcActionTbl_struct {
        typedef pptSpcActionTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cType;
       ::CORBA::String_StructElem ruleAction01;
       ::CORBA::String_StructElem ruleAction02;
       ::CORBA::String_StructElem ruleAction03;
       ::CORBA::String_StructElem ruleAction04;
       ::CORBA::String_StructElem ruleAction05;
       ::CORBA::String_StructElem ruleAction06;
       ::CORBA::String_StructElem ruleAction07;
       ::CORBA::String_StructElem ruleAction08;
       ::CORBA::String_StructElem ruleAction09;
       ::CORBA::String_StructElem ruleAction10;
       ::CORBA::String_StructElem ruleAction11;
       ::CORBA::String_StructElem ruleAction12;
       ::CORBA::String_StructElem ruleAction13;
       ::CORBA::String_StructElem ruleAction14;
       ::CORBA::String_StructElem ruleAction15;
       ::CORBA::String_StructElem ruleAction16;
       ::CORBA::String_StructElem ruleAction17;
       ::CORBA::String_StructElem ruleAction18;
       ::CORBA::String_StructElem ruleAction19;
       ::CORBA::String_StructElem ruleAction20;
       ::CORBA::String_StructElem ruleAction21;
       ::CORBA::String_StructElem ruleAction22;
       ::CORBA::String_StructElem ruleAction23;
       ::CORBA::String_StructElem ruleAction24;
       ::CORBA::String_StructElem ruleAction25;
       ::CORBA::String_StructElem ruleAction26;
       ::CORBA::String_StructElem ruleAction27;
       ::CORBA::String_StructElem ruleAction28;
       ::CORBA::String_StructElem ruleAction29;
       ::CORBA::String_StructElem ruleAction30;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcActionTbl_struct();
       pptSpcActionTbl_struct(const pptSpcActionTbl_struct&);
       pptSpcActionTbl_struct& operator=(const pptSpcActionTbl_struct&);
       static CORBA::Info<pptSpcActionTbl_struct> pptSpcActionTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcActionTbl_struct


typedef pptSpcActionTbl_struct* pptSpcActionTbl_struct_vPtr;
typedef const pptSpcActionTbl_struct* pptSpcActionTbl_struct_cvPtr;

class  pptSpcActionTbl_struct_var
{
    public:

    pptSpcActionTbl_struct_var ();

    pptSpcActionTbl_struct_var (pptSpcActionTbl_struct *_p);

    pptSpcActionTbl_struct_var (const pptSpcActionTbl_struct_var &_s);

    pptSpcActionTbl_struct_var &operator= (pptSpcActionTbl_struct *_p);

    pptSpcActionTbl_struct_var &operator= (const pptSpcActionTbl_struct_var &_s);

    ~pptSpcActionTbl_struct_var ();

    pptSpcActionTbl_struct* operator-> ();

    const pptSpcActionTbl_struct& in() const;
    pptSpcActionTbl_struct& inout();
    pptSpcActionTbl_struct*& out();
    pptSpcActionTbl_struct* _retn();

    operator pptSpcActionTbl_struct_cvPtr () const;

    operator pptSpcActionTbl_struct_vPtr& ();

    operator const pptSpcActionTbl_struct& () const;

    operator pptSpcActionTbl_struct& ();

    protected:
    pptSpcActionTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcActionTbl_struct;
    typedef pptSpcActionTbl_struct pptSpcActionTbl;
    typedef pptSpcActionTbl_struct_var pptSpcActionTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcActionTbl;
class  _IDL_SEQ_pptSpcActionTblSequence_0_var;
class  _IDL_SEQ_pptSpcActionTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcActionTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcActionTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcActionTblSequence_0 ();
    _IDL_SEQ_pptSpcActionTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcActionTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcActionTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcActionTblSequence_0 (const _IDL_SEQ_pptSpcActionTblSequence_0&);

    ~_IDL_SEQ_pptSpcActionTblSequence_0 ();

    _IDL_SEQ_pptSpcActionTblSequence_0& operator= (const _IDL_SEQ_pptSpcActionTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcActionTbl& operator [] (::CORBA::ULong indx);
    const pptSpcActionTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcActionTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcActionTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcActionTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcActionTbl* src, pptSpcActionTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcActionTbl* data); 
  public:

    static pptSpcActionTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcActionTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcActionTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcActionTblSequence_0> pptSpcActionTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcActionTblSequence_0* _IDL_SEQ_pptSpcActionTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcActionTblSequence_0* _IDL_SEQ_pptSpcActionTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcActionTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcActionTblSequence_0_var ();

    _IDL_SEQ_pptSpcActionTblSequence_0_var (_IDL_SEQ_pptSpcActionTblSequence_0 *_p);

    _IDL_SEQ_pptSpcActionTblSequence_0_var (const _IDL_SEQ_pptSpcActionTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcActionTblSequence_0_var &operator= (_IDL_SEQ_pptSpcActionTblSequence_0 *_p);

    _IDL_SEQ_pptSpcActionTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcActionTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcActionTblSequence_0_var ();

    _IDL_SEQ_pptSpcActionTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcActionTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcActionTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcActionTblSequence_0() const;

    const pptSpcActionTbl& operator[] (::CORBA::ULong index) const;
    pptSpcActionTbl& operator[] (::CORBA::ULong index);
    const pptSpcActionTbl& operator[] (int index) const;
    pptSpcActionTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcActionTblSequence_0& in() const;
    _IDL_SEQ_pptSpcActionTblSequence_0& inout();
    _IDL_SEQ_pptSpcActionTblSequence_0*& out();
    _IDL_SEQ_pptSpcActionTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcActionTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcActionTblSequence_0 _pptSpcActionTblSequence_seq;
    typedef _IDL_SEQ_pptSpcActionTblSequence_0 _pptSpcActionTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcActionTblSequence_0 pptSpcActionTblSequence;
    typedef _IDL_SEQ_pptSpcActionTblSequence_0_var pptSpcActionTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcActionTblSequence;
    class  pptSpcOnlineLogTbl_struct_var;
    struct  pptSpcOnlineLogTbl_struct {
        typedef pptSpcOnlineLogTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::String_StructElem txDateTime;
       ::CORBA::String_StructElem chartGroupID;
       ::CORBA::String_StructElem chartID;
       ::CORBA::String_StructElem chartType;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cType;
       ::CORBA::Long txSeq;
       ::objectIdentifier processEquipmentID;
       ::objectIdentifier processRecipeID;
       ::objectIdentifier productID;
       ::objectIdentifier processMainProcessDefinitionID;
       ::objectIdentifier mainProcessDefinitionID;
       ::CORBA::String_StructElem cName;
       ::CORBA::String_StructElem ruleFlag;
       ::CORBA::String_StructElem ruleResult;
       ::CORBA::String_StructElem specCheck;
       ::CORBA::String_StructElem ctrlCheck;
       ::CORBA::String_StructElem totalAction;
       ::CORBA::String_StructElem detailAction;
       ::CORBA::String_StructElem log;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcOnlineLogTbl_struct();
       pptSpcOnlineLogTbl_struct(const pptSpcOnlineLogTbl_struct&);
       pptSpcOnlineLogTbl_struct& operator=(const pptSpcOnlineLogTbl_struct&);
       static CORBA::Info<pptSpcOnlineLogTbl_struct> pptSpcOnlineLogTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct pptSpcOnlineLogTbl_struct


typedef pptSpcOnlineLogTbl_struct* pptSpcOnlineLogTbl_struct_vPtr;
typedef const pptSpcOnlineLogTbl_struct* pptSpcOnlineLogTbl_struct_cvPtr;

class  pptSpcOnlineLogTbl_struct_var
{
    public:

    pptSpcOnlineLogTbl_struct_var ();

    pptSpcOnlineLogTbl_struct_var (pptSpcOnlineLogTbl_struct *_p);

    pptSpcOnlineLogTbl_struct_var (const pptSpcOnlineLogTbl_struct_var &_s);

    pptSpcOnlineLogTbl_struct_var &operator= (pptSpcOnlineLogTbl_struct *_p);

    pptSpcOnlineLogTbl_struct_var &operator= (const pptSpcOnlineLogTbl_struct_var &_s);

    ~pptSpcOnlineLogTbl_struct_var ();

    pptSpcOnlineLogTbl_struct* operator-> ();

    const pptSpcOnlineLogTbl_struct& in() const;
    pptSpcOnlineLogTbl_struct& inout();
    pptSpcOnlineLogTbl_struct*& out();
    pptSpcOnlineLogTbl_struct* _retn();

    operator pptSpcOnlineLogTbl_struct_cvPtr () const;

    operator pptSpcOnlineLogTbl_struct_vPtr& ();

    operator const pptSpcOnlineLogTbl_struct& () const;

    operator pptSpcOnlineLogTbl_struct& ();

    protected:
    pptSpcOnlineLogTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcOnlineLogTbl_struct;
    typedef pptSpcOnlineLogTbl_struct pptSpcOnlineLogTbl;
    typedef pptSpcOnlineLogTbl_struct_var pptSpcOnlineLogTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcOnlineLogTbl;
class  _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var;
class  _IDL_SEQ_pptSpcOnlineLogTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcOnlineLogTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcOnlineLogTblSequence_0 ();
    _IDL_SEQ_pptSpcOnlineLogTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcOnlineLogTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcOnlineLogTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcOnlineLogTblSequence_0 (const _IDL_SEQ_pptSpcOnlineLogTblSequence_0&);

    ~_IDL_SEQ_pptSpcOnlineLogTblSequence_0 ();

    _IDL_SEQ_pptSpcOnlineLogTblSequence_0& operator= (const _IDL_SEQ_pptSpcOnlineLogTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcOnlineLogTbl& operator [] (::CORBA::ULong indx);
    const pptSpcOnlineLogTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcOnlineLogTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcOnlineLogTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcOnlineLogTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcOnlineLogTbl* src, pptSpcOnlineLogTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcOnlineLogTbl* data); 
  public:

    static pptSpcOnlineLogTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcOnlineLogTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcOnlineLogTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcOnlineLogTblSequence_0> pptSpcOnlineLogTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcOnlineLogTblSequence_0* _IDL_SEQ_pptSpcOnlineLogTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcOnlineLogTblSequence_0* _IDL_SEQ_pptSpcOnlineLogTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var ();

    _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var (_IDL_SEQ_pptSpcOnlineLogTblSequence_0 *_p);

    _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var (const _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var &operator= (_IDL_SEQ_pptSpcOnlineLogTblSequence_0 *_p);

    _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcOnlineLogTblSequence_0_var ();

    _IDL_SEQ_pptSpcOnlineLogTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcOnlineLogTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcOnlineLogTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcOnlineLogTblSequence_0() const;

    const pptSpcOnlineLogTbl& operator[] (::CORBA::ULong index) const;
    pptSpcOnlineLogTbl& operator[] (::CORBA::ULong index);
    const pptSpcOnlineLogTbl& operator[] (int index) const;
    pptSpcOnlineLogTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcOnlineLogTblSequence_0& in() const;
    _IDL_SEQ_pptSpcOnlineLogTblSequence_0& inout();
    _IDL_SEQ_pptSpcOnlineLogTblSequence_0*& out();
    _IDL_SEQ_pptSpcOnlineLogTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcOnlineLogTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcOnlineLogTblSequence_0 _pptSpcOnlineLogTblSequence_seq;
    typedef _IDL_SEQ_pptSpcOnlineLogTblSequence_0 _pptSpcOnlineLogTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcOnlineLogTblSequence_0 pptSpcOnlineLogTblSequence;
    typedef _IDL_SEQ_pptSpcOnlineLogTblSequence_0_var pptSpcOnlineLogTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcOnlineLogTblSequence;
    class  pptSpcDataTbl_struct_var;
    struct  pptSpcDataTbl_struct {
        typedef pptSpcDataTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::String_StructElem txDateTime;
       ::CORBA::String_StructElem opclmDateTime;
       ::objectIdentifier productID;
       ::objectIdentifier processMainProcessDefinitionID;
       ::CORBA::String_StructElem processOperationNumber;
       ::objectIdentifier processProcessDefinitionID;
       ::objectIdentifier technologyID;
       ::objectIdentifier productGroupID;
       ::objectIdentifier processEquipmentID;
       ::objectIdentifier processRecipeID;
       ::objectIdentifier currEquipmentID;
       ::objectIdentifier currRecipeID;
       ::objectIdentifier reticleID;
       ::objectIdentifier fixtureID;
       ::objectIdentifier lotID;
       ::objectIdentifier waferID;
       ::objectIdentifier emplUserID;
       ::CORBA::String_StructElem fromFlag;
       ::CORBA::String_StructElem mfldID;
       ::CORBA::String_StructElem itemNm;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cType;
       ::CORBA::Long txSeq;
       ::CORBA::String_StructElem cName;
       ::CORBA::String_StructElem dataHis;
       ::CORBA::String_StructElem rawHis;
       ::CORBA::String_StructElem rawFlag;
       ::CORBA::Double pointValue;
       ::CORBA::Long actSample;
       ::CORBA::Double uslValue;
       ::CORBA::Double uclValue;
       ::CORBA::Double uwlValue;
       ::CORBA::Double targetValue;
       ::CORBA::Double meanValue;
       ::CORBA::Double lwlValue;
       ::CORBA::Double lclValue;
       ::CORBA::Double lslValue;
       ::CORBA::Double maxValue;
       ::CORBA::Double minValue;
       ::CORBA::String_StructElem ruleResult;
       ::CORBA::String_StructElem oosOcap;
       ::CORBA::String_StructElem oocOcap;
       ::CORBA::String_StructElem specCheck;
       ::CORBA::String_StructElem ctrlCheck;
       ::CORBA::String_StructElem totalAction;
       ::CORBA::String_StructElem detailAction;
       ::CORBA::String_StructElem txCom;
       ::CORBA::String_StructElem lotCom;
       ::CORBA::String_StructElem comUser;
       ::CORBA::String_StructElem hideFlag;
       ::CORBA::String_StructElem comFlag;
       ::CORBA::String_StructElem comDateTime;
       ::CORBA::String_StructElem areaID;
       ::CORBA::String_StructElem reasonID;
       ::CORBA::String_StructElem actionID;
       ::CORBA::String_StructElem actionCom;
       ::CORBA::String_StructElem sheetNo;
       ::CORBA::String_StructElem reserve1;
       ::CORBA::String_StructElem reserve2;
       ::CORBA::String_StructElem reserve3;
       ::CORBA::String_StructElem reserve4;
       ::CORBA::String_StructElem reserve5;
       ::CORBA::String_StructElem reasonDesc;
       ::CORBA::String_StructElem actionDesc;
       ::CORBA::String_StructElem oosActUser;
       ::CORBA::String_StructElem oocActUser;
       ::CORBA::String_StructElem ocapReason;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcDataTbl_struct();
       pptSpcDataTbl_struct(const pptSpcDataTbl_struct&);
       pptSpcDataTbl_struct& operator=(const pptSpcDataTbl_struct&);
       static CORBA::Info<pptSpcDataTbl_struct> pptSpcDataTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct pptSpcDataTbl_struct


typedef pptSpcDataTbl_struct* pptSpcDataTbl_struct_vPtr;
typedef const pptSpcDataTbl_struct* pptSpcDataTbl_struct_cvPtr;

class  pptSpcDataTbl_struct_var
{
    public:

    pptSpcDataTbl_struct_var ();

    pptSpcDataTbl_struct_var (pptSpcDataTbl_struct *_p);

    pptSpcDataTbl_struct_var (const pptSpcDataTbl_struct_var &_s);

    pptSpcDataTbl_struct_var &operator= (pptSpcDataTbl_struct *_p);

    pptSpcDataTbl_struct_var &operator= (const pptSpcDataTbl_struct_var &_s);

    ~pptSpcDataTbl_struct_var ();

    pptSpcDataTbl_struct* operator-> ();

    const pptSpcDataTbl_struct& in() const;
    pptSpcDataTbl_struct& inout();
    pptSpcDataTbl_struct*& out();
    pptSpcDataTbl_struct* _retn();

    operator pptSpcDataTbl_struct_cvPtr () const;

    operator pptSpcDataTbl_struct_vPtr& ();

    operator const pptSpcDataTbl_struct& () const;

    operator pptSpcDataTbl_struct& ();

    protected:
    pptSpcDataTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcDataTbl_struct;
    typedef pptSpcDataTbl_struct pptSpcDataTbl;
    typedef pptSpcDataTbl_struct_var pptSpcDataTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcDataTbl;
class  _IDL_SEQ_pptSpcDataTblSequence_0_var;
class  _IDL_SEQ_pptSpcDataTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcDataTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcDataTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcDataTblSequence_0 ();
    _IDL_SEQ_pptSpcDataTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcDataTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcDataTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcDataTblSequence_0 (const _IDL_SEQ_pptSpcDataTblSequence_0&);

    ~_IDL_SEQ_pptSpcDataTblSequence_0 ();

    _IDL_SEQ_pptSpcDataTblSequence_0& operator= (const _IDL_SEQ_pptSpcDataTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcDataTbl& operator [] (::CORBA::ULong indx);
    const pptSpcDataTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcDataTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcDataTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcDataTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcDataTbl* src, pptSpcDataTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcDataTbl* data); 
  public:

    static pptSpcDataTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcDataTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcDataTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcDataTblSequence_0> pptSpcDataTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcDataTblSequence_0* _IDL_SEQ_pptSpcDataTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcDataTblSequence_0* _IDL_SEQ_pptSpcDataTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcDataTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcDataTblSequence_0_var ();

    _IDL_SEQ_pptSpcDataTblSequence_0_var (_IDL_SEQ_pptSpcDataTblSequence_0 *_p);

    _IDL_SEQ_pptSpcDataTblSequence_0_var (const _IDL_SEQ_pptSpcDataTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcDataTblSequence_0_var &operator= (_IDL_SEQ_pptSpcDataTblSequence_0 *_p);

    _IDL_SEQ_pptSpcDataTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcDataTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcDataTblSequence_0_var ();

    _IDL_SEQ_pptSpcDataTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcDataTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcDataTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcDataTblSequence_0() const;

    const pptSpcDataTbl& operator[] (::CORBA::ULong index) const;
    pptSpcDataTbl& operator[] (::CORBA::ULong index);
    const pptSpcDataTbl& operator[] (int index) const;
    pptSpcDataTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcDataTblSequence_0& in() const;
    _IDL_SEQ_pptSpcDataTblSequence_0& inout();
    _IDL_SEQ_pptSpcDataTblSequence_0*& out();
    _IDL_SEQ_pptSpcDataTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcDataTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcDataTblSequence_0 _pptSpcDataTblSequence_seq;
    typedef _IDL_SEQ_pptSpcDataTblSequence_0 _pptSpcDataTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcDataTblSequence_0 pptSpcDataTblSequence;
    typedef _IDL_SEQ_pptSpcDataTblSequence_0_var pptSpcDataTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcDataTblSequence;
    class  pptSpcRawTbl_struct_var;
    struct  pptSpcRawTbl_struct {
        typedef pptSpcRawTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::String_StructElem txDateTime;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long txSeq;
       ::CORBA::Long itemSeq;
       ::CORBA::String_StructElem waferPosition;
       ::CORBA::String_StructElem sitePosition;
       ::objectIdentifier waferID;
       ::CORBA::String_StructElem mfldID;
       ::CORBA::String_StructElem itemNm;
       ::CORBA::String_StructElem edclmDateTime;
       ::CORBA::Long sampling;
       ::CORBA::Double rawValue;
       ::CORBA::Double targetValue;
       ::CORBA::String_StructElem specRc;
       ::CORBA::Double scale;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcRawTbl_struct();
       pptSpcRawTbl_struct(const pptSpcRawTbl_struct&);
       pptSpcRawTbl_struct& operator=(const pptSpcRawTbl_struct&);
       static CORBA::Info<pptSpcRawTbl_struct> pptSpcRawTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct pptSpcRawTbl_struct


typedef pptSpcRawTbl_struct* pptSpcRawTbl_struct_vPtr;
typedef const pptSpcRawTbl_struct* pptSpcRawTbl_struct_cvPtr;

class  pptSpcRawTbl_struct_var
{
    public:

    pptSpcRawTbl_struct_var ();

    pptSpcRawTbl_struct_var (pptSpcRawTbl_struct *_p);

    pptSpcRawTbl_struct_var (const pptSpcRawTbl_struct_var &_s);

    pptSpcRawTbl_struct_var &operator= (pptSpcRawTbl_struct *_p);

    pptSpcRawTbl_struct_var &operator= (const pptSpcRawTbl_struct_var &_s);

    ~pptSpcRawTbl_struct_var ();

    pptSpcRawTbl_struct* operator-> ();

    const pptSpcRawTbl_struct& in() const;
    pptSpcRawTbl_struct& inout();
    pptSpcRawTbl_struct*& out();
    pptSpcRawTbl_struct* _retn();

    operator pptSpcRawTbl_struct_cvPtr () const;

    operator pptSpcRawTbl_struct_vPtr& ();

    operator const pptSpcRawTbl_struct& () const;

    operator pptSpcRawTbl_struct& ();

    protected:
    pptSpcRawTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRawTbl_struct;
    typedef pptSpcRawTbl_struct pptSpcRawTbl;
    typedef pptSpcRawTbl_struct_var pptSpcRawTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRawTbl;
class  _IDL_SEQ_pptSpcRawTblSequence_0_var;
class  _IDL_SEQ_pptSpcRawTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcRawTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcRawTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcRawTblSequence_0 ();
    _IDL_SEQ_pptSpcRawTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcRawTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcRawTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcRawTblSequence_0 (const _IDL_SEQ_pptSpcRawTblSequence_0&);

    ~_IDL_SEQ_pptSpcRawTblSequence_0 ();

    _IDL_SEQ_pptSpcRawTblSequence_0& operator= (const _IDL_SEQ_pptSpcRawTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcRawTbl& operator [] (::CORBA::ULong indx);
    const pptSpcRawTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcRawTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcRawTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcRawTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcRawTbl* src, pptSpcRawTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcRawTbl* data); 
  public:

    static pptSpcRawTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcRawTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcRawTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcRawTblSequence_0> pptSpcRawTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcRawTblSequence_0* _IDL_SEQ_pptSpcRawTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcRawTblSequence_0* _IDL_SEQ_pptSpcRawTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcRawTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcRawTblSequence_0_var ();

    _IDL_SEQ_pptSpcRawTblSequence_0_var (_IDL_SEQ_pptSpcRawTblSequence_0 *_p);

    _IDL_SEQ_pptSpcRawTblSequence_0_var (const _IDL_SEQ_pptSpcRawTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcRawTblSequence_0_var &operator= (_IDL_SEQ_pptSpcRawTblSequence_0 *_p);

    _IDL_SEQ_pptSpcRawTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcRawTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcRawTblSequence_0_var ();

    _IDL_SEQ_pptSpcRawTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcRawTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcRawTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcRawTblSequence_0() const;

    const pptSpcRawTbl& operator[] (::CORBA::ULong index) const;
    pptSpcRawTbl& operator[] (::CORBA::ULong index);
    const pptSpcRawTbl& operator[] (int index) const;
    pptSpcRawTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcRawTblSequence_0& in() const;
    _IDL_SEQ_pptSpcRawTblSequence_0& inout();
    _IDL_SEQ_pptSpcRawTblSequence_0*& out();
    _IDL_SEQ_pptSpcRawTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcRawTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcRawTblSequence_0 _pptSpcRawTblSequence_seq;
    typedef _IDL_SEQ_pptSpcRawTblSequence_0 _pptSpcRawTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcRawTblSequence_0 pptSpcRawTblSequence;
    typedef _IDL_SEQ_pptSpcRawTblSequence_0_var pptSpcRawTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcRawTblSequence;
    class  pptSpcHisDWTbl_struct_var;
    struct  pptSpcHisDWTbl_struct {
        typedef pptSpcHisDWTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::String_StructElem txDateTime;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cType;
       ::CORBA::Long txSeq;
       ::CORBA::String_StructElem action;
       ::CORBA::String_StructElem dataHis;
       ::CORBA::String_StructElem rawHis;
       ::CORBA::String_StructElem rawFlag;
       ::CORBA::Long maxPoints;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcHisDWTbl_struct();
       pptSpcHisDWTbl_struct(const pptSpcHisDWTbl_struct&);
       pptSpcHisDWTbl_struct& operator=(const pptSpcHisDWTbl_struct&);
       static CORBA::Info<pptSpcHisDWTbl_struct> pptSpcHisDWTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcHisDWTbl_struct


typedef pptSpcHisDWTbl_struct* pptSpcHisDWTbl_struct_vPtr;
typedef const pptSpcHisDWTbl_struct* pptSpcHisDWTbl_struct_cvPtr;

class  pptSpcHisDWTbl_struct_var
{
    public:

    pptSpcHisDWTbl_struct_var ();

    pptSpcHisDWTbl_struct_var (pptSpcHisDWTbl_struct *_p);

    pptSpcHisDWTbl_struct_var (const pptSpcHisDWTbl_struct_var &_s);

    pptSpcHisDWTbl_struct_var &operator= (pptSpcHisDWTbl_struct *_p);

    pptSpcHisDWTbl_struct_var &operator= (const pptSpcHisDWTbl_struct_var &_s);

    ~pptSpcHisDWTbl_struct_var ();

    pptSpcHisDWTbl_struct* operator-> ();

    const pptSpcHisDWTbl_struct& in() const;
    pptSpcHisDWTbl_struct& inout();
    pptSpcHisDWTbl_struct*& out();
    pptSpcHisDWTbl_struct* _retn();

    operator pptSpcHisDWTbl_struct_cvPtr () const;

    operator pptSpcHisDWTbl_struct_vPtr& ();

    operator const pptSpcHisDWTbl_struct& () const;

    operator pptSpcHisDWTbl_struct& ();

    protected:
    pptSpcHisDWTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcHisDWTbl_struct;
    typedef pptSpcHisDWTbl_struct pptSpcHisDWTbl;
    typedef pptSpcHisDWTbl_struct_var pptSpcHisDWTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcHisDWTbl;
class  _IDL_SEQ_pptSpcHisDWTblSequence_0_var;
class  _IDL_SEQ_pptSpcHisDWTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcHisDWTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcHisDWTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcHisDWTblSequence_0 ();
    _IDL_SEQ_pptSpcHisDWTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcHisDWTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcHisDWTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcHisDWTblSequence_0 (const _IDL_SEQ_pptSpcHisDWTblSequence_0&);

    ~_IDL_SEQ_pptSpcHisDWTblSequence_0 ();

    _IDL_SEQ_pptSpcHisDWTblSequence_0& operator= (const _IDL_SEQ_pptSpcHisDWTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcHisDWTbl& operator [] (::CORBA::ULong indx);
    const pptSpcHisDWTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcHisDWTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcHisDWTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcHisDWTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcHisDWTbl* src, pptSpcHisDWTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcHisDWTbl* data); 
  public:

    static pptSpcHisDWTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcHisDWTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcHisDWTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcHisDWTblSequence_0> pptSpcHisDWTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcHisDWTblSequence_0* _IDL_SEQ_pptSpcHisDWTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcHisDWTblSequence_0* _IDL_SEQ_pptSpcHisDWTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcHisDWTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcHisDWTblSequence_0_var ();

    _IDL_SEQ_pptSpcHisDWTblSequence_0_var (_IDL_SEQ_pptSpcHisDWTblSequence_0 *_p);

    _IDL_SEQ_pptSpcHisDWTblSequence_0_var (const _IDL_SEQ_pptSpcHisDWTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcHisDWTblSequence_0_var &operator= (_IDL_SEQ_pptSpcHisDWTblSequence_0 *_p);

    _IDL_SEQ_pptSpcHisDWTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcHisDWTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcHisDWTblSequence_0_var ();

    _IDL_SEQ_pptSpcHisDWTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcHisDWTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcHisDWTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcHisDWTblSequence_0() const;

    const pptSpcHisDWTbl& operator[] (::CORBA::ULong index) const;
    pptSpcHisDWTbl& operator[] (::CORBA::ULong index);
    const pptSpcHisDWTbl& operator[] (int index) const;
    pptSpcHisDWTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcHisDWTblSequence_0& in() const;
    _IDL_SEQ_pptSpcHisDWTblSequence_0& inout();
    _IDL_SEQ_pptSpcHisDWTblSequence_0*& out();
    _IDL_SEQ_pptSpcHisDWTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcHisDWTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcHisDWTblSequence_0 _pptSpcHisDWTblSequence_seq;
    typedef _IDL_SEQ_pptSpcHisDWTblSequence_0 _pptSpcHisDWTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcHisDWTblSequence_0 pptSpcHisDWTblSequence;
    typedef _IDL_SEQ_pptSpcHisDWTblSequence_0_var pptSpcHisDWTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcHisDWTblSequence;
    class  pptSpcFifoTbl_struct_var;
    struct  pptSpcFifoTbl_struct {
        typedef pptSpcFifoTbl_struct_var _var_type;
       ::CORBA::String_StructElem collectionType;
       ::CORBA::String_StructElem txDateTime;
       ::CORBA::Long gNo;
       ::CORBA::Long cNo;
       ::CORBA::Long cType;
       ::CORBA::Long txSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcFifoTbl_struct();
       pptSpcFifoTbl_struct(const pptSpcFifoTbl_struct&);
       pptSpcFifoTbl_struct& operator=(const pptSpcFifoTbl_struct&);
       static CORBA::Info<pptSpcFifoTbl_struct> pptSpcFifoTbl_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcFifoTbl_struct


typedef pptSpcFifoTbl_struct* pptSpcFifoTbl_struct_vPtr;
typedef const pptSpcFifoTbl_struct* pptSpcFifoTbl_struct_cvPtr;

class  pptSpcFifoTbl_struct_var
{
    public:

    pptSpcFifoTbl_struct_var ();

    pptSpcFifoTbl_struct_var (pptSpcFifoTbl_struct *_p);

    pptSpcFifoTbl_struct_var (const pptSpcFifoTbl_struct_var &_s);

    pptSpcFifoTbl_struct_var &operator= (pptSpcFifoTbl_struct *_p);

    pptSpcFifoTbl_struct_var &operator= (const pptSpcFifoTbl_struct_var &_s);

    ~pptSpcFifoTbl_struct_var ();

    pptSpcFifoTbl_struct* operator-> ();

    const pptSpcFifoTbl_struct& in() const;
    pptSpcFifoTbl_struct& inout();
    pptSpcFifoTbl_struct*& out();
    pptSpcFifoTbl_struct* _retn();

    operator pptSpcFifoTbl_struct_cvPtr () const;

    operator pptSpcFifoTbl_struct_vPtr& ();

    operator const pptSpcFifoTbl_struct& () const;

    operator pptSpcFifoTbl_struct& ();

    protected:
    pptSpcFifoTbl_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcFifoTbl_struct;
    typedef pptSpcFifoTbl_struct pptSpcFifoTbl;
    typedef pptSpcFifoTbl_struct_var pptSpcFifoTbl_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcFifoTbl;
class  _IDL_SEQ_pptSpcFiFoTblSequence_0_var;
class  _IDL_SEQ_pptSpcFiFoTblSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcFiFoTblSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcFifoTbl *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcFiFoTblSequence_0 ();
    _IDL_SEQ_pptSpcFiFoTblSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcFiFoTblSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcFifoTbl* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcFiFoTblSequence_0 (const _IDL_SEQ_pptSpcFiFoTblSequence_0&);

    ~_IDL_SEQ_pptSpcFiFoTblSequence_0 ();

    _IDL_SEQ_pptSpcFiFoTblSequence_0& operator= (const _IDL_SEQ_pptSpcFiFoTblSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcFifoTbl& operator [] (::CORBA::ULong indx);
    const pptSpcFifoTbl& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcFifoTbl* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcFifoTbl* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcFifoTbl* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcFifoTbl* src, pptSpcFifoTbl* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcFifoTbl* data); 
  public:

    static pptSpcFifoTbl* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcFifoTbl* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcFifoTbl* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcFiFoTblSequence_0> pptSpcFiFoTblSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcFiFoTblSequence_0* _IDL_SEQ_pptSpcFiFoTblSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcFiFoTblSequence_0* _IDL_SEQ_pptSpcFiFoTblSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcFiFoTblSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcFiFoTblSequence_0_var ();

    _IDL_SEQ_pptSpcFiFoTblSequence_0_var (_IDL_SEQ_pptSpcFiFoTblSequence_0 *_p);

    _IDL_SEQ_pptSpcFiFoTblSequence_0_var (const _IDL_SEQ_pptSpcFiFoTblSequence_0_var &_s);

    _IDL_SEQ_pptSpcFiFoTblSequence_0_var &operator= (_IDL_SEQ_pptSpcFiFoTblSequence_0 *_p);

    _IDL_SEQ_pptSpcFiFoTblSequence_0_var &operator= (const _IDL_SEQ_pptSpcFiFoTblSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcFiFoTblSequence_0_var ();

    _IDL_SEQ_pptSpcFiFoTblSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcFiFoTblSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcFiFoTblSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcFiFoTblSequence_0() const;

    const pptSpcFifoTbl& operator[] (::CORBA::ULong index) const;
    pptSpcFifoTbl& operator[] (::CORBA::ULong index);
    const pptSpcFifoTbl& operator[] (int index) const;
    pptSpcFifoTbl& operator[] (int index);
    const _IDL_SEQ_pptSpcFiFoTblSequence_0& in() const;
    _IDL_SEQ_pptSpcFiFoTblSequence_0& inout();
    _IDL_SEQ_pptSpcFiFoTblSequence_0*& out();
    _IDL_SEQ_pptSpcFiFoTblSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcFiFoTblSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcFiFoTblSequence_0 _pptSpcFiFoTblSequence_seq;
    typedef _IDL_SEQ_pptSpcFiFoTblSequence_0 _pptSpcFiFoTblSequence_seq_1;
    typedef _IDL_SEQ_pptSpcFiFoTblSequence_0 pptSpcFiFoTblSequence;
    typedef _IDL_SEQ_pptSpcFiFoTblSequence_0_var pptSpcFiFoTblSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcFiFoTblSequence;
    class  pptSpcWorst_struct_var;
    struct  pptSpcWorst_struct {
        typedef pptSpcWorst_struct_var _var_type;
       ::CORBA::String_StructElem ruleResult;
       ::CORBA::String_StructElem specCheck;
       ::CORBA::String_StructElem ctrlCheck;
       ::CORBA::String_StructElem totalAction;
       ::CORBA::String_StructElem detailAction;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcWorst_struct();
       pptSpcWorst_struct(const pptSpcWorst_struct&);
       pptSpcWorst_struct& operator=(const pptSpcWorst_struct&);
       static CORBA::Info<pptSpcWorst_struct> pptSpcWorst_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcWorst_struct


typedef pptSpcWorst_struct* pptSpcWorst_struct_vPtr;
typedef const pptSpcWorst_struct* pptSpcWorst_struct_cvPtr;

class  pptSpcWorst_struct_var
{
    public:

    pptSpcWorst_struct_var ();

    pptSpcWorst_struct_var (pptSpcWorst_struct *_p);

    pptSpcWorst_struct_var (const pptSpcWorst_struct_var &_s);

    pptSpcWorst_struct_var &operator= (pptSpcWorst_struct *_p);

    pptSpcWorst_struct_var &operator= (const pptSpcWorst_struct_var &_s);

    ~pptSpcWorst_struct_var ();

    pptSpcWorst_struct* operator-> ();

    const pptSpcWorst_struct& in() const;
    pptSpcWorst_struct& inout();
    pptSpcWorst_struct*& out();
    pptSpcWorst_struct* _retn();

    operator pptSpcWorst_struct_cvPtr () const;

    operator pptSpcWorst_struct_vPtr& ();

    operator const pptSpcWorst_struct& () const;

    operator pptSpcWorst_struct& ();

    protected:
    pptSpcWorst_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcWorst_struct;
    typedef pptSpcWorst_struct pptSpcWorst;
    typedef pptSpcWorst_struct_var pptSpcWorst_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcWorst;
class  _IDL_SEQ_pptSpcWorstSequence_0_var;
class  _IDL_SEQ_pptSpcWorstSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcWorstSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcWorst *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcWorstSequence_0 ();
    _IDL_SEQ_pptSpcWorstSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcWorstSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcWorst* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcWorstSequence_0 (const _IDL_SEQ_pptSpcWorstSequence_0&);

    ~_IDL_SEQ_pptSpcWorstSequence_0 ();

    _IDL_SEQ_pptSpcWorstSequence_0& operator= (const _IDL_SEQ_pptSpcWorstSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcWorst& operator [] (::CORBA::ULong indx);
    const pptSpcWorst& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcWorst* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcWorst* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcWorst* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcWorst* src, pptSpcWorst* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcWorst* data); 
  public:

    static pptSpcWorst* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcWorst* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcWorst* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcWorstSequence_0> pptSpcWorstSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcWorstSequence_0* _IDL_SEQ_pptSpcWorstSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcWorstSequence_0* _IDL_SEQ_pptSpcWorstSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcWorstSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcWorstSequence_0_var ();

    _IDL_SEQ_pptSpcWorstSequence_0_var (_IDL_SEQ_pptSpcWorstSequence_0 *_p);

    _IDL_SEQ_pptSpcWorstSequence_0_var (const _IDL_SEQ_pptSpcWorstSequence_0_var &_s);

    _IDL_SEQ_pptSpcWorstSequence_0_var &operator= (_IDL_SEQ_pptSpcWorstSequence_0 *_p);

    _IDL_SEQ_pptSpcWorstSequence_0_var &operator= (const _IDL_SEQ_pptSpcWorstSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcWorstSequence_0_var ();

    _IDL_SEQ_pptSpcWorstSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcWorstSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcWorstSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcWorstSequence_0() const;

    const pptSpcWorst& operator[] (::CORBA::ULong index) const;
    pptSpcWorst& operator[] (::CORBA::ULong index);
    const pptSpcWorst& operator[] (int index) const;
    pptSpcWorst& operator[] (int index);
    const _IDL_SEQ_pptSpcWorstSequence_0& in() const;
    _IDL_SEQ_pptSpcWorstSequence_0& inout();
    _IDL_SEQ_pptSpcWorstSequence_0*& out();
    _IDL_SEQ_pptSpcWorstSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcWorstSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcWorstSequence_0 _pptSpcWorstSequence_seq;
    typedef _IDL_SEQ_pptSpcWorstSequence_0 _pptSpcWorstSequence_seq_1;
    typedef _IDL_SEQ_pptSpcWorstSequence_0 pptSpcWorstSequence;
    typedef _IDL_SEQ_pptSpcWorstSequence_0_var pptSpcWorstSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcWorstSequence;
    class  pptSpcPartner_struct_var;
    struct  pptSpcPartner_struct {
        typedef pptSpcPartner_struct_var _var_type;
       ::CORBA::Long flag;
       ::CORBA::Long c_ary;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcPartner_struct();
       pptSpcPartner_struct(const pptSpcPartner_struct&);
       pptSpcPartner_struct& operator=(const pptSpcPartner_struct&);
       static CORBA::Info<pptSpcPartner_struct> pptSpcPartner_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcPartner_struct


typedef pptSpcPartner_struct* pptSpcPartner_struct_vPtr;
typedef const pptSpcPartner_struct* pptSpcPartner_struct_cvPtr;

class  pptSpcPartner_struct_var
{
    public:

    pptSpcPartner_struct_var ();

    pptSpcPartner_struct_var (pptSpcPartner_struct *_p);

    pptSpcPartner_struct_var (const pptSpcPartner_struct_var &_s);

    pptSpcPartner_struct_var &operator= (pptSpcPartner_struct *_p);

    pptSpcPartner_struct_var &operator= (const pptSpcPartner_struct_var &_s);

    ~pptSpcPartner_struct_var ();

    pptSpcPartner_struct* operator-> ();

    const pptSpcPartner_struct& in() const;
    pptSpcPartner_struct& inout();
    pptSpcPartner_struct& out();
    pptSpcPartner_struct _retn();

    operator pptSpcPartner_struct_cvPtr () const;

    operator pptSpcPartner_struct_vPtr& ();

    operator const pptSpcPartner_struct& () const;

    operator pptSpcPartner_struct& ();

    protected:
    pptSpcPartner_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcPartner_struct;
    typedef pptSpcPartner_struct pptSpcPartner;
    typedef pptSpcPartner_struct_var pptSpcPartner_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcPartner;
class  _IDL_SEQ_pptSpcPartnerSequence_0_var;
class  _IDL_SEQ_pptSpcPartnerSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcPartnerSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcPartner *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcPartnerSequence_0 ();
    _IDL_SEQ_pptSpcPartnerSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcPartnerSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcPartner* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcPartnerSequence_0 (const _IDL_SEQ_pptSpcPartnerSequence_0&);

    ~_IDL_SEQ_pptSpcPartnerSequence_0 ();

    _IDL_SEQ_pptSpcPartnerSequence_0& operator= (const _IDL_SEQ_pptSpcPartnerSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcPartner& operator [] (::CORBA::ULong indx);
    const pptSpcPartner& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcPartner* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcPartner* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcPartner* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcPartner* src, pptSpcPartner* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcPartner* data); 
  public:

    static pptSpcPartner* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcPartner* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcPartner* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcPartnerSequence_0> pptSpcPartnerSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcPartnerSequence_0* _IDL_SEQ_pptSpcPartnerSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcPartnerSequence_0* _IDL_SEQ_pptSpcPartnerSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcPartnerSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcPartnerSequence_0_var ();

    _IDL_SEQ_pptSpcPartnerSequence_0_var (_IDL_SEQ_pptSpcPartnerSequence_0 *_p);

    _IDL_SEQ_pptSpcPartnerSequence_0_var (const _IDL_SEQ_pptSpcPartnerSequence_0_var &_s);

    _IDL_SEQ_pptSpcPartnerSequence_0_var &operator= (_IDL_SEQ_pptSpcPartnerSequence_0 *_p);

    _IDL_SEQ_pptSpcPartnerSequence_0_var &operator= (const _IDL_SEQ_pptSpcPartnerSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcPartnerSequence_0_var ();

    _IDL_SEQ_pptSpcPartnerSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcPartnerSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcPartnerSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcPartnerSequence_0() const;

    const pptSpcPartner& operator[] (::CORBA::ULong index) const;
    pptSpcPartner& operator[] (::CORBA::ULong index);
    const pptSpcPartner& operator[] (int index) const;
    pptSpcPartner& operator[] (int index);
    const _IDL_SEQ_pptSpcPartnerSequence_0& in() const;
    _IDL_SEQ_pptSpcPartnerSequence_0& inout();
    _IDL_SEQ_pptSpcPartnerSequence_0*& out();
    _IDL_SEQ_pptSpcPartnerSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcPartnerSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcPartnerSequence_0 _pptSpcPartnerSequence_seq;
    typedef _IDL_SEQ_pptSpcPartnerSequence_0 _pptSpcPartnerSequence_seq_1;
    typedef _IDL_SEQ_pptSpcPartnerSequence_0 pptSpcPartnerSequence;
    typedef _IDL_SEQ_pptSpcPartnerSequence_0_var pptSpcPartnerSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcPartnerSequence;
    class  pptSpcPointValue_struct_var;
    struct  pptSpcPointValue_struct {
        typedef pptSpcPointValue_struct_var _var_type;
       ::CORBA::Double dMean;
       ::CORBA::Double dRange;
       ::CORBA::Double dSigma;
       ::CORBA::Double dUniformity;
       ::CORBA::Double dMax;
       ::CORBA::Double dMin;
       ::CORBA::Double dSingle;
       ::CORBA::Double dMovingRange;
       ::CORBA::Double dCount;
       ::CORBA::Double dRU;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcPointValue_struct();
       pptSpcPointValue_struct(const pptSpcPointValue_struct&);
       pptSpcPointValue_struct& operator=(const pptSpcPointValue_struct&);
       static CORBA::Info<pptSpcPointValue_struct> pptSpcPointValue_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcPointValue_struct


typedef pptSpcPointValue_struct* pptSpcPointValue_struct_vPtr;
typedef const pptSpcPointValue_struct* pptSpcPointValue_struct_cvPtr;

class  pptSpcPointValue_struct_var
{
    public:

    pptSpcPointValue_struct_var ();

    pptSpcPointValue_struct_var (pptSpcPointValue_struct *_p);

    pptSpcPointValue_struct_var (const pptSpcPointValue_struct_var &_s);

    pptSpcPointValue_struct_var &operator= (pptSpcPointValue_struct *_p);

    pptSpcPointValue_struct_var &operator= (const pptSpcPointValue_struct_var &_s);

    ~pptSpcPointValue_struct_var ();

    pptSpcPointValue_struct* operator-> ();

    const pptSpcPointValue_struct& in() const;
    pptSpcPointValue_struct& inout();
    pptSpcPointValue_struct& out();
    pptSpcPointValue_struct _retn();

    operator pptSpcPointValue_struct_cvPtr () const;

    operator pptSpcPointValue_struct_vPtr& ();

    operator const pptSpcPointValue_struct& () const;

    operator pptSpcPointValue_struct& ();

    protected:
    pptSpcPointValue_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcPointValue_struct;
    typedef pptSpcPointValue_struct pptSpcPointValue;
    typedef pptSpcPointValue_struct_var pptSpcPointValue_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcPointValue;
class  _IDL_SEQ_pptSpcPointValueSequence_0_var;
class  _IDL_SEQ_pptSpcPointValueSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcPointValueSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcPointValue *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcPointValueSequence_0 ();
    _IDL_SEQ_pptSpcPointValueSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcPointValueSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcPointValue* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcPointValueSequence_0 (const _IDL_SEQ_pptSpcPointValueSequence_0&);

    ~_IDL_SEQ_pptSpcPointValueSequence_0 ();

    _IDL_SEQ_pptSpcPointValueSequence_0& operator= (const _IDL_SEQ_pptSpcPointValueSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcPointValue& operator [] (::CORBA::ULong indx);
    const pptSpcPointValue& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcPointValue* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcPointValue* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcPointValue* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcPointValue* src, pptSpcPointValue* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcPointValue* data); 
  public:

    static pptSpcPointValue* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcPointValue* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcPointValue* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcPointValueSequence_0> pptSpcPointValueSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcPointValueSequence_0* _IDL_SEQ_pptSpcPointValueSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcPointValueSequence_0* _IDL_SEQ_pptSpcPointValueSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcPointValueSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcPointValueSequence_0_var ();

    _IDL_SEQ_pptSpcPointValueSequence_0_var (_IDL_SEQ_pptSpcPointValueSequence_0 *_p);

    _IDL_SEQ_pptSpcPointValueSequence_0_var (const _IDL_SEQ_pptSpcPointValueSequence_0_var &_s);

    _IDL_SEQ_pptSpcPointValueSequence_0_var &operator= (_IDL_SEQ_pptSpcPointValueSequence_0 *_p);

    _IDL_SEQ_pptSpcPointValueSequence_0_var &operator= (const _IDL_SEQ_pptSpcPointValueSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcPointValueSequence_0_var ();

    _IDL_SEQ_pptSpcPointValueSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcPointValueSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcPointValueSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcPointValueSequence_0() const;

    const pptSpcPointValue& operator[] (::CORBA::ULong index) const;
    pptSpcPointValue& operator[] (::CORBA::ULong index);
    const pptSpcPointValue& operator[] (int index) const;
    pptSpcPointValue& operator[] (int index);
    const _IDL_SEQ_pptSpcPointValueSequence_0& in() const;
    _IDL_SEQ_pptSpcPointValueSequence_0& inout();
    _IDL_SEQ_pptSpcPointValueSequence_0*& out();
    _IDL_SEQ_pptSpcPointValueSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcPointValueSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcPointValueSequence_0 _pptSpcPointValueSequence_seq;
    typedef _IDL_SEQ_pptSpcPointValueSequence_0 _pptSpcPointValueSequence_seq_1;
    typedef _IDL_SEQ_pptSpcPointValueSequence_0 pptSpcPointValueSequence;
    typedef _IDL_SEQ_pptSpcPointValueSequence_0_var pptSpcPointValueSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcPointValueSequence;
    class  pptSpcCheckResult_struct_var;
    struct  pptSpcCheckResult_struct {
        typedef pptSpcCheckResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csSpcOutput strSpcOutput;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcCheckResult_struct();
       pptSpcCheckResult_struct(const pptSpcCheckResult_struct&);
       pptSpcCheckResult_struct& operator=(const pptSpcCheckResult_struct&);
       static CORBA::Info<pptSpcCheckResult_struct> pptSpcCheckResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct pptSpcCheckResult_struct


typedef pptSpcCheckResult_struct* pptSpcCheckResult_struct_vPtr;
typedef const pptSpcCheckResult_struct* pptSpcCheckResult_struct_cvPtr;

class  pptSpcCheckResult_struct_var
{
    public:

    pptSpcCheckResult_struct_var ();

    pptSpcCheckResult_struct_var (pptSpcCheckResult_struct *_p);

    pptSpcCheckResult_struct_var (const pptSpcCheckResult_struct_var &_s);

    pptSpcCheckResult_struct_var &operator= (pptSpcCheckResult_struct *_p);

    pptSpcCheckResult_struct_var &operator= (const pptSpcCheckResult_struct_var &_s);

    ~pptSpcCheckResult_struct_var ();

    pptSpcCheckResult_struct* operator-> ();

    const pptSpcCheckResult_struct& in() const;
    pptSpcCheckResult_struct& inout();
    pptSpcCheckResult_struct*& out();
    pptSpcCheckResult_struct* _retn();

    operator pptSpcCheckResult_struct_cvPtr () const;

    operator pptSpcCheckResult_struct_vPtr& ();

    operator const pptSpcCheckResult_struct& () const;

    operator pptSpcCheckResult_struct& ();

    protected:
    pptSpcCheckResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCheckResult_struct;
    typedef pptSpcCheckResult_struct pptSpcCheckResult;
    typedef pptSpcCheckResult_struct_var pptSpcCheckResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcCheckResult;
    class  pptSpcItemValue_struct_var;
    struct  pptSpcItemValue_struct {
        typedef pptSpcItemValue_struct_var _var_type;
       ::CORBA::String_StructElem wfr_id;
       ::CORBA::String_StructElem wafer_pos;
       ::CORBA::String_StructElem site_pos;
       ::CORBA::Double val;
       ::CORBA::String_StructElem spec_rc;
       ::CORBA::String_StructElem lot_com;
       ::CORBA::String_StructElem chamber_list;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcItemValue_struct();
       pptSpcItemValue_struct(const pptSpcItemValue_struct&);
       pptSpcItemValue_struct& operator=(const pptSpcItemValue_struct&);
       static CORBA::Info<pptSpcItemValue_struct> pptSpcItemValue_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct pptSpcItemValue_struct


typedef pptSpcItemValue_struct* pptSpcItemValue_struct_vPtr;
typedef const pptSpcItemValue_struct* pptSpcItemValue_struct_cvPtr;

class  pptSpcItemValue_struct_var
{
    public:

    pptSpcItemValue_struct_var ();

    pptSpcItemValue_struct_var (pptSpcItemValue_struct *_p);

    pptSpcItemValue_struct_var (const pptSpcItemValue_struct_var &_s);

    pptSpcItemValue_struct_var &operator= (pptSpcItemValue_struct *_p);

    pptSpcItemValue_struct_var &operator= (const pptSpcItemValue_struct_var &_s);

    ~pptSpcItemValue_struct_var ();

    pptSpcItemValue_struct* operator-> ();

    const pptSpcItemValue_struct& in() const;
    pptSpcItemValue_struct& inout();
    pptSpcItemValue_struct*& out();
    pptSpcItemValue_struct* _retn();

    operator pptSpcItemValue_struct_cvPtr () const;

    operator pptSpcItemValue_struct_vPtr& ();

    operator const pptSpcItemValue_struct& () const;

    operator pptSpcItemValue_struct& ();

    protected:
    pptSpcItemValue_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcItemValue_struct;
    typedef pptSpcItemValue_struct pptSpcItemValue;
    typedef pptSpcItemValue_struct_var pptSpcItemValue_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcItemValue;
class  _IDL_SEQ_pptSpcItemValueSequence_0_var;
class  _IDL_SEQ_pptSpcItemValueSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcItemValueSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcItemValue *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcItemValueSequence_0 ();
    _IDL_SEQ_pptSpcItemValueSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcItemValueSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcItemValue* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcItemValueSequence_0 (const _IDL_SEQ_pptSpcItemValueSequence_0&);

    ~_IDL_SEQ_pptSpcItemValueSequence_0 ();

    _IDL_SEQ_pptSpcItemValueSequence_0& operator= (const _IDL_SEQ_pptSpcItemValueSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcItemValue& operator [] (::CORBA::ULong indx);
    const pptSpcItemValue& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcItemValue* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcItemValue* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcItemValue* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcItemValue* src, pptSpcItemValue* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcItemValue* data); 
  public:

    static pptSpcItemValue* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcItemValue* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcItemValue* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcItemValueSequence_0> pptSpcItemValueSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcItemValueSequence_0* _IDL_SEQ_pptSpcItemValueSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcItemValueSequence_0* _IDL_SEQ_pptSpcItemValueSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcItemValueSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcItemValueSequence_0_var ();

    _IDL_SEQ_pptSpcItemValueSequence_0_var (_IDL_SEQ_pptSpcItemValueSequence_0 *_p);

    _IDL_SEQ_pptSpcItemValueSequence_0_var (const _IDL_SEQ_pptSpcItemValueSequence_0_var &_s);

    _IDL_SEQ_pptSpcItemValueSequence_0_var &operator= (_IDL_SEQ_pptSpcItemValueSequence_0 *_p);

    _IDL_SEQ_pptSpcItemValueSequence_0_var &operator= (const _IDL_SEQ_pptSpcItemValueSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcItemValueSequence_0_var ();

    _IDL_SEQ_pptSpcItemValueSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcItemValueSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcItemValueSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcItemValueSequence_0() const;

    const pptSpcItemValue& operator[] (::CORBA::ULong index) const;
    pptSpcItemValue& operator[] (::CORBA::ULong index);
    const pptSpcItemValue& operator[] (int index) const;
    pptSpcItemValue& operator[] (int index);
    const _IDL_SEQ_pptSpcItemValueSequence_0& in() const;
    _IDL_SEQ_pptSpcItemValueSequence_0& inout();
    _IDL_SEQ_pptSpcItemValueSequence_0*& out();
    _IDL_SEQ_pptSpcItemValueSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcItemValueSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcItemValueSequence_0 _pptSpcItemValueSequence_seq;
    typedef _IDL_SEQ_pptSpcItemValueSequence_0 _pptSpcItemValueSequence_seq_1;
    typedef _IDL_SEQ_pptSpcItemValueSequence_0 pptSpcItemValueSequence;
    typedef _IDL_SEQ_pptSpcItemValueSequence_0_var pptSpcItemValueSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcItemValueSequence;
    class  pptSpcItem_struct_var;
    struct  pptSpcItem_struct {
        typedef pptSpcItem_struct_var _var_type;
       ::CORBA::String_StructElem mfld_id;
       ::CORBA::String_StructElem item_nm;
       ::CORBA::Long target_blank_flag;
       ::CORBA::Double target;
       ::CORBA::Long value_cnt;
       ::pptSpcItemValueSequence value;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       pptSpcItem_struct();
       pptSpcItem_struct(const pptSpcItem_struct&);
       pptSpcItem_struct& operator=(const pptSpcItem_struct&);
       static CORBA::Info<pptSpcItem_struct> pptSpcItem_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct pptSpcItem_struct


typedef pptSpcItem_struct* pptSpcItem_struct_vPtr;
typedef const pptSpcItem_struct* pptSpcItem_struct_cvPtr;

class  pptSpcItem_struct_var
{
    public:

    pptSpcItem_struct_var ();

    pptSpcItem_struct_var (pptSpcItem_struct *_p);

    pptSpcItem_struct_var (const pptSpcItem_struct_var &_s);

    pptSpcItem_struct_var &operator= (pptSpcItem_struct *_p);

    pptSpcItem_struct_var &operator= (const pptSpcItem_struct_var &_s);

    ~pptSpcItem_struct_var ();

    pptSpcItem_struct* operator-> ();

    const pptSpcItem_struct& in() const;
    pptSpcItem_struct& inout();
    pptSpcItem_struct*& out();
    pptSpcItem_struct* _retn();

    operator pptSpcItem_struct_cvPtr () const;

    operator pptSpcItem_struct_vPtr& ();

    operator const pptSpcItem_struct& () const;

    operator pptSpcItem_struct& ();

    protected:
    pptSpcItem_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_pptSpcItem_struct;
    typedef pptSpcItem_struct pptSpcItem;
    typedef pptSpcItem_struct_var pptSpcItem_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcItem;
class  _IDL_SEQ_pptSpcItemSequence_0_var;
class  _IDL_SEQ_pptSpcItemSequence_0 {
    public:
        typedef _IDL_SEQ_pptSpcItemSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    pptSpcItem *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_pptSpcItemSequence_0 ();
    _IDL_SEQ_pptSpcItemSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_pptSpcItemSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, pptSpcItem* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_pptSpcItemSequence_0 (const _IDL_SEQ_pptSpcItemSequence_0&);

    ~_IDL_SEQ_pptSpcItemSequence_0 ();

    _IDL_SEQ_pptSpcItemSequence_0& operator= (const _IDL_SEQ_pptSpcItemSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    pptSpcItem& operator [] (::CORBA::ULong indx);
    const pptSpcItem& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    pptSpcItem* get_buffer (::CORBA::Boolean orphan=0);
    const pptSpcItem* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, pptSpcItem* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcItem* src, pptSpcItem* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, pptSpcItem* data); 
  public:

    static pptSpcItem* SOMLINK allocbuf(::CORBA::ULong nelems);
    static pptSpcItem* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(pptSpcItem* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_pptSpcItemSequence_0> pptSpcItemSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_pptSpcItemSequence_0* _IDL_SEQ_pptSpcItemSequence_0_vPtr;
typedef const _IDL_SEQ_pptSpcItemSequence_0* _IDL_SEQ_pptSpcItemSequence_0_cvPtr;

class  _IDL_SEQ_pptSpcItemSequence_0_var
{
    public:

    _IDL_SEQ_pptSpcItemSequence_0_var ();

    _IDL_SEQ_pptSpcItemSequence_0_var (_IDL_SEQ_pptSpcItemSequence_0 *_p);

    _IDL_SEQ_pptSpcItemSequence_0_var (const _IDL_SEQ_pptSpcItemSequence_0_var &_s);

    _IDL_SEQ_pptSpcItemSequence_0_var &operator= (_IDL_SEQ_pptSpcItemSequence_0 *_p);

    _IDL_SEQ_pptSpcItemSequence_0_var &operator= (const _IDL_SEQ_pptSpcItemSequence_0_var &_s);

    ~_IDL_SEQ_pptSpcItemSequence_0_var ();

    _IDL_SEQ_pptSpcItemSequence_0* operator-> ();

    operator _IDL_SEQ_pptSpcItemSequence_0_cvPtr () const;

    operator _IDL_SEQ_pptSpcItemSequence_0_vPtr& ();

    operator _IDL_SEQ_pptSpcItemSequence_0() const;

    const pptSpcItem& operator[] (::CORBA::ULong index) const;
    pptSpcItem& operator[] (::CORBA::ULong index);
    const pptSpcItem& operator[] (int index) const;
    pptSpcItem& operator[] (int index);
    const _IDL_SEQ_pptSpcItemSequence_0& in() const;
    _IDL_SEQ_pptSpcItemSequence_0& inout();
    _IDL_SEQ_pptSpcItemSequence_0*& out();
    _IDL_SEQ_pptSpcItemSequence_0* _retn();

    protected:
    _IDL_SEQ_pptSpcItemSequence_0 *_ptr;
};

    typedef _IDL_SEQ_pptSpcItemSequence_0 _pptSpcItemSequence_seq;
    typedef _IDL_SEQ_pptSpcItemSequence_0 _pptSpcItemSequence_seq_1;
    typedef _IDL_SEQ_pptSpcItemSequence_0 pptSpcItemSequence;
    typedef _IDL_SEQ_pptSpcItemSequence_0_var pptSpcItemSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_pptSpcItemSequence;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_spcpptstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_spcpptstr_ANYOPERATOR__
#undef __NOTUSE_cs_spcpptstr_ANYOPERATOR__
#endif //__USE_cs_spcpptstr_ANYOPERATOR__
#ifndef __NOTUSE_cs_spcpptstr_ANYOPERATOR__
#define _DCL_ANYOPS_SPCException
#define _DCL_ANYOPS_pptSpcProfileTbl_struct
#define _DCL_ANYOPS_pptSpcProfileTblSequence
#define _DCL_ANYOPS_pptSpcRpCpSumTbl_struct
#define _DCL_ANYOPS_pptSpcRpCpSumTblSequence
#define _DCL_ANYOPS_pptSpcRpDateRecTbl_struct
#define _DCL_ANYOPS_ppptSpcRpDateRecTblSequence
#define _DCL_ANYOPS_pptSpcGmTbl_struct
#define _DCL_ANYOPS_pptSpcGmTblSequence
#define _DCL_ANYOPS_pptSpcCmTbl_struct
#define _DCL_ANYOPS_pptSpcCmTblSequence
#define _DCL_ANYOPS_pptSpcCdTbl_struct
#define _DCL_ANYOPS_pptSpcCdTblSequence
#define _DCL_ANYOPS_pptSpcCdPSpecTbl_struct
#define _DCL_ANYOPS_pptSpcCdPSpecTblSequence
#define _DCL_ANYOPS_pptSpcRuleTbl_struct
#define _DCL_ANYOPS_pptSpcRuleTblSequence
#define _DCL_ANYOPS_pptSpcActionTbl_struct
#define _DCL_ANYOPS_pptSpcActionTblSequence
#define _DCL_ANYOPS_pptSpcOnlineLogTbl_struct
#define _DCL_ANYOPS_pptSpcOnlineLogTblSequence
#define _DCL_ANYOPS_pptSpcDataTbl_struct
#define _DCL_ANYOPS_pptSpcDataTblSequence
#define _DCL_ANYOPS_pptSpcRawTbl_struct
#define _DCL_ANYOPS_pptSpcRawTblSequence
#define _DCL_ANYOPS_pptSpcHisDWTbl_struct
#define _DCL_ANYOPS_pptSpcHisDWTblSequence
#define _DCL_ANYOPS_pptSpcFifoTbl_struct
#define _DCL_ANYOPS_pptSpcFiFoTblSequence
#define _DCL_ANYOPS_pptSpcWorst_struct
#define _DCL_ANYOPS_pptSpcWorstSequence
#define _DCL_ANYOPS_pptSpcPartner_struct
#define _DCL_ANYOPS_pptSpcPartnerSequence
#define _DCL_ANYOPS_pptSpcPointValue_struct
#define _DCL_ANYOPS_pptSpcPointValueSequence
#define _DCL_ANYOPS_pptSpcCheckResult_struct
#define _DCL_ANYOPS_pptSpcItemValue_struct
#define _DCL_ANYOPS_pptSpcItemValueSequence
#define _DCL_ANYOPS_pptSpcItem_struct
#define _DCL_ANYOPS_pptSpcItemSequence
#endif //__NOTUSE_cs_spcpptstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_SPCException
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::SPCException &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::SPCException *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::SPCException*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::SPCException*& _data);
#endif
#endif // _DCL_ANYOPS_SPCException
#ifdef _DCL_ANYOPS_pptSpcProfileTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcProfileTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcProfileTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcProfileTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcProfileTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcProfileTbl_struct
#ifdef _DCL_ANYOPS_pptSpcProfileTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcProfileTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcProfileTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcProfileTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcProfileTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcProfileTblSequence
#ifdef _DCL_ANYOPS_pptSpcRpCpSumTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcRpCpSumTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcRpCpSumTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcRpCpSumTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcRpCpSumTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcRpCpSumTbl_struct
#ifdef _DCL_ANYOPS_pptSpcRpCpSumTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcRpCpSumTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcRpCpSumTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcRpCpSumTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcRpCpSumTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcRpCpSumTblSequence
#ifdef _DCL_ANYOPS_pptSpcRpDateRecTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcRpDateRecTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcRpDateRecTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcRpDateRecTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcRpDateRecTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcRpDateRecTbl_struct
#ifdef _DCL_ANYOPS_ppptSpcRpDateRecTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::ppptSpcRpDateRecTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::ppptSpcRpDateRecTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ppptSpcRpDateRecTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ppptSpcRpDateRecTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_ppptSpcRpDateRecTblSequence
#ifdef _DCL_ANYOPS_pptSpcGmTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcGmTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcGmTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcGmTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcGmTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcGmTbl_struct
#ifdef _DCL_ANYOPS_pptSpcGmTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcGmTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcGmTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcGmTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcGmTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcGmTblSequence
#ifdef _DCL_ANYOPS_pptSpcCmTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcCmTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcCmTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcCmTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcCmTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcCmTbl_struct
#ifdef _DCL_ANYOPS_pptSpcCmTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcCmTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcCmTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcCmTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcCmTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcCmTblSequence
#ifdef _DCL_ANYOPS_pptSpcCdTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcCdTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcCdTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcCdTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcCdTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcCdTbl_struct
#ifdef _DCL_ANYOPS_pptSpcCdTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcCdTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcCdTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcCdTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcCdTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcCdTblSequence
#ifdef _DCL_ANYOPS_pptSpcCdPSpecTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcCdPSpecTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcCdPSpecTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcCdPSpecTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcCdPSpecTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcCdPSpecTbl_struct
#ifdef _DCL_ANYOPS_pptSpcCdPSpecTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcCdPSpecTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcCdPSpecTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcCdPSpecTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcCdPSpecTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcCdPSpecTblSequence
#ifdef _DCL_ANYOPS_pptSpcRuleTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcRuleTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcRuleTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcRuleTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcRuleTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcRuleTbl_struct
#ifdef _DCL_ANYOPS_pptSpcRuleTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcRuleTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcRuleTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcRuleTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcRuleTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcRuleTblSequence
#ifdef _DCL_ANYOPS_pptSpcActionTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcActionTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcActionTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcActionTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcActionTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcActionTbl_struct
#ifdef _DCL_ANYOPS_pptSpcActionTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcActionTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcActionTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcActionTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcActionTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcActionTblSequence
#ifdef _DCL_ANYOPS_pptSpcOnlineLogTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcOnlineLogTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcOnlineLogTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcOnlineLogTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcOnlineLogTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcOnlineLogTbl_struct
#ifdef _DCL_ANYOPS_pptSpcOnlineLogTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcOnlineLogTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcOnlineLogTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcOnlineLogTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcOnlineLogTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcOnlineLogTblSequence
#ifdef _DCL_ANYOPS_pptSpcDataTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcDataTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcDataTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcDataTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcDataTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcDataTbl_struct
#ifdef _DCL_ANYOPS_pptSpcDataTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcDataTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcDataTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcDataTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcDataTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcDataTblSequence
#ifdef _DCL_ANYOPS_pptSpcRawTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcRawTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcRawTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcRawTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcRawTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcRawTbl_struct
#ifdef _DCL_ANYOPS_pptSpcRawTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcRawTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcRawTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcRawTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcRawTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcRawTblSequence
#ifdef _DCL_ANYOPS_pptSpcHisDWTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcHisDWTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcHisDWTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcHisDWTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcHisDWTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcHisDWTbl_struct
#ifdef _DCL_ANYOPS_pptSpcHisDWTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcHisDWTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcHisDWTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcHisDWTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcHisDWTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcHisDWTblSequence
#ifdef _DCL_ANYOPS_pptSpcFifoTbl_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcFifoTbl_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcFifoTbl_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcFifoTbl_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcFifoTbl_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcFifoTbl_struct
#ifdef _DCL_ANYOPS_pptSpcFiFoTblSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcFiFoTblSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcFiFoTblSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcFiFoTblSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcFiFoTblSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcFiFoTblSequence
#ifdef _DCL_ANYOPS_pptSpcWorst_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcWorst_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcWorst_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcWorst_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcWorst_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcWorst_struct
#ifdef _DCL_ANYOPS_pptSpcWorstSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcWorstSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcWorstSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcWorstSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcWorstSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcWorstSequence
#ifdef _DCL_ANYOPS_pptSpcPartner_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcPartner_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcPartner_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcPartner_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcPartner_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcPartner_struct
#ifdef _DCL_ANYOPS_pptSpcPartnerSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcPartnerSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcPartnerSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcPartnerSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcPartnerSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcPartnerSequence
#ifdef _DCL_ANYOPS_pptSpcPointValue_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcPointValue_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcPointValue_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcPointValue_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcPointValue_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcPointValue_struct
#ifdef _DCL_ANYOPS_pptSpcPointValueSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcPointValueSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcPointValueSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcPointValueSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcPointValueSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcPointValueSequence
#ifdef _DCL_ANYOPS_pptSpcCheckResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcCheckResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcCheckResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcCheckResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcCheckResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcCheckResult_struct
#ifdef _DCL_ANYOPS_pptSpcItemValue_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcItemValue_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcItemValue_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcItemValue_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcItemValue_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcItemValue_struct
#ifdef _DCL_ANYOPS_pptSpcItemValueSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcItemValueSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcItemValueSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcItemValueSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcItemValueSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcItemValueSequence
#ifdef _DCL_ANYOPS_pptSpcItem_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcItem_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcItem_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcItem_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcItem_struct*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcItem_struct
#ifdef _DCL_ANYOPS_pptSpcItemSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::pptSpcItemSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::pptSpcItemSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::pptSpcItemSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::pptSpcItemSequence*& _data);
#endif
#endif // _DCL_ANYOPS_pptSpcItemSequence

#endif /* _cs_spcpptstr_hh_included */

#endif /* _cs_spcpptstr_server_defined */
