//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APC_LithoRecipeParameter_Replace.cpp
//

#include "cs_pptmgr.hpp"


// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APC_LithoRecipeParameter_Replace.cpp
//
//
// Innotron Modification History:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009 Nick Tsai      Replace APC recommended recipe parameter to strStartCassette
// 2017/11/03 INN-R170009 Qufd           Replace APC recommended recipe parameter to strStartCassette
//
// Function Description:
//
// Input Parameters:
//    csObjAPC_LithoRecipeParameter_Replace_out&       strObjAPC_LithoRecipeParameter_Replace_out,
//    const pptObjCommonIn&                            strObjCommonIn,
//    const csObjAPC_LithoRecipeParameter_Replace_in&  strObjAPC_LithoRecipeParameter_Replace_in
//
// typedef struct csObjAPC_LithoRecipeParameter_Replace_in_struct {
//     pptStartRecipeParameterSequence           strStartRecipeParameterSeq;
//     csAPCLithoRecommendReticleSequence        strAPCLithoRecommendReticleSeq;
//     any                                       siInfo;
// }csObjAPC_LithoRecipeParameter_Replace_in;
//
//
// Output Parameters:
// typedef struct csObjAPC_LithoRecipeParameter_Replace_out_struct {
//     pptRetCode                      strResult;
//     pptStartRecipeParameterSequence strStartRecipeParameterSeq;
//     any                             siInfo;
// }csObjAPC_LithoRecipeParameter_Replace_out;
//
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//


CORBA::Long CS_PPTManager_i::cs_APC_LithoRecipeParameter_Replace (
    csObjAPC_LithoRecipeParameter_Replace_out&       strObjAPC_LithoRecipeParameter_Replace_out,
    const pptObjCommonIn&                            strObjCommonIn,
    const csObjAPC_LithoRecipeParameter_Replace_in&  strObjAPC_LithoRecipeParameter_Replace_in
)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APC_LithoRecipeParameter_Replace");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        
        pptStartRecipeParameterSequence tmpstrStartRecipeParameterSeq;
        csAPCLithoRecommendReticleSequence tmpstrAPCLithoRecommendReticleSeq;

        tmpstrStartRecipeParameterSeq    = strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq;
        tmpstrAPCLithoRecommendReticleSeq = strObjAPC_LithoRecipeParameter_Replace_in.strAPCLithoRecommendReticleSeq;

        CORBA::Long SRPLen = tmpstrStartRecipeParameterSeq.length();

        strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq.length(SRPLen);

        CORBA::Long h = 0;
        for ( CORBA::Long i = 0; i < SRPLen; i++,h++ )
        {
            PPT_METHODTRACE_V2("", "loop tmpstrStartRecipeParameterSeq",i ); 
            PPT_METHODTRACE_V2("", "loop outstrStartRecipeParameterSeq",h ); 

            PPT_METHODTRACE_V2("", "in para Recipe.parameterName....   ",tmpstrStartRecipeParameterSeq[i].parameterName );
            PPT_METHODTRACE_V2("", "in para Recipe.parameterValue...   ",tmpstrStartRecipeParameterSeq[i].parameterValue );
            PPT_METHODTRACE_V2("", "in para Recipe.targetValue......   ",tmpstrStartRecipeParameterSeq[i].targetValue );


            /**********************************************************************************
             Use Current| MM Default            |APC	                |Result
             Value      |                       |                       |
             ----------------------------------------------------------------------------------
                        | Parameter | Parameter | Parameter | Parameter | Parameter | Parameter  
                        | Name      | Value     | Name      | Value     | Name      | Value
             ----------------------------------------------------------------------------------
             No         | Parm001   | 10        | Parm001   | 15        | Parm001   | 15
             ----------------------------------------------------------------------------------
             No         | Parm002   | 20        | Parm002   | 20        | Parm002   | 20
             ----------------------------------------------------------------------------------
             No         | Parm003   | 35        |           |           | Parm003   | 35
             ----------------------------------------------------------------------------------
                        |           |           | Parm004   | 30        |           |
             ----------------------------------------------------------------------------------
             Yes        | Parm005   | 120       | Parm005   | 127       | Parm005   | 120
             ----------------------------------------------------------------------------------
             No         | Parm006   | -999      |           |           |           |
             ----------------------------------------------------------------------------------
             No         | Parm007   | -999      | Parm007   | 127       | Parm007   | 127
             ----------------------------------------------------------------------------------
             No         | Parm008   | *         | Parm008   | -999      |           |
             *********************************************************************************/ 

            //If the parameter value is defined -999(CS_RPARM_INEFFECTIVE_VALUE) in SM system
            // MM will not report the parameter to TCS expect if APC recommend the parameter value.

            if ( tmpstrStartRecipeParameterSeq[i].useCurrentSettingValueFlag == TRUE )
            { 
                PPT_METHODTRACE_V1("", "if (tmpstrStartRecipeParameterSeq[i].useCurrentSettingValueFlag == TRUE)");

                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[h].parameterName = tmpstrStartRecipeParameterSeq[i].parameterName;
                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[h].parameterValue = tmpstrStartRecipeParameterSeq[i].parameterValue;
            }
            else
            {
                PPT_METHODTRACE_V1("", "if (tmpstrStartRecipeParameterSeq[i].useCurrentSettingValueFlag == FALSE)");

                CORBA::Long ALRLen = tmpstrAPCLithoRecommendReticleSeq.length();
                CORBA::Long j; 
                   
                for ( j = 0; j < ALRLen; j++ )
                {
                    PPT_METHODTRACE_V2("", "in para reticleID....   ",tmpstrAPCLithoRecommendReticleSeq[j].reticleID.identifier);
                    PPT_METHODTRACE_V2("", "loop tmpstrAPCLithoRecommendReticleSeq", j ); 

                    csAPCLithoRecipeParameterSequence tmpstrAPCLithoRecipeParameterSeq;
                    tmpstrAPCLithoRecipeParameterSeq = tmpstrAPCLithoRecommendReticleSeq[j].strAPCLithoRecipeParameterSeq;

                    CORBA::Long ARPLen = tmpstrAPCLithoRecipeParameterSeq.length();
                    CORBA::Long exposure_cnt = 0; 

                    if ( ARPLen > 2 )
                    {
                        PPT_METHODTRACE_V1("", "if ( ARPLen > 2 )" );
                        PPT_SET_MSG_RC_KEY( strObjAPC_LithoRecipeParameter_Replace_out,
                                            CS_MSG_INVALID_EXPOSURE_COUNT,
                                            CS_RC_INVALID_EXPOSURE_COUNT,
                                            tmpstrAPCLithoRecommendReticleSeq[j].reticleID.identifier );
                        return CS_RC_INVALID_EXPOSURE_COUNT;
                    }

                    CORBA::Long k;
                    for ( k = 0; k < ARPLen; k++ )
                    {
                        PPT_METHODTRACE_V2("", "loop tmpstrAPCLithoRecipeParameterSeq",k ); 
                        PPT_METHODTRACE_V2("", "in para Reticle.parameterName ",tmpstrAPCLithoRecipeParameterSeq[k].parameterName );
                        PPT_METHODTRACE_V2("", "in para Reticle.parameterValue",tmpstrAPCLithoRecipeParameterSeq[k].parameterValue);

                        //Recipe parameter in double exposure
                        //Naming rule is "D1_" and "D2_".
                        //"D1_" is reticle1, "D2_" is reticle2.
                        CORBA::String_var dRecipeName; 

                        if ( ARPLen == 2 )
                        {
                            PPT_METHODTRACE_V1("", "if (ARPLen = 2)");

                            char *ptr = CORBA::string_alloc(CIMFWStrLen(tmpstrAPCLithoRecipeParameterSeq[k].parameterName)+4);
             
                            sprintf(ptr, "D%d_%s", k+1, (char *)tmpstrAPCLithoRecipeParameterSeq[k].parameterName); 

                            dRecipeName = ptr;

                            PPT_METHODTRACE_V2("", "dRecipeName ", dRecipeName);
                        } 
                        else
                        {
                            PPT_METHODTRACE_V2("", "if (ARPLen != 2)", ARPLen);
                            dRecipeName = tmpstrAPCLithoRecipeParameterSeq[k].parameterName;
                        }

                        char *TmpStr =NULL;
                        CORBA::String_var LoopFlag ;

                        tmpstrAPCLithoRecommendReticleSeq[j].strAPCLithoRecipeParameterSeq[k].siInfo >>= TmpStr; 
                        LoopFlag = CIMFWStrDup(TmpStr); 

                        if ( CIMFWStrLen(LoopFlag) != 0 && CIMFWStrCmp( LoopFlag, "L" ) == 0 )
                        {
                            PPT_METHODTRACE_V1("", "if ( CIMFWStrLen(LoopFlag) != 0 && CIMFWStrCmp( LoopFlag, \"L\" ) == 0 )");
                            exposure_cnt++;
                            continue;
                        }

                        if ( CIMFWStrCmp( dRecipeName, tmpstrStartRecipeParameterSeq[i].parameterName  ) == 0 )
                        {
                            PPT_METHODTRACE_V1("", "if ( CIMFWStrCmp(dRecipeName, tmpstrStartRecipeParameterSeq[i].parameterName) == 0 )");

                            exposure_cnt++;
                            tmpstrAPCLithoRecommendReticleSeq[j].strAPCLithoRecipeParameterSeq[k].siInfo <<= CIMFWStrDup( "L" );

                            if ( CIMFWStrCmp( tmpstrAPCLithoRecipeParameterSeq[k].parameterValue, CS_RPARM_INEFFECTIVE_VALUE ) != 0 )
                            { 
                                PPT_METHODTRACE_V1("", "if ( CIMFWStrCmp( tmpstrAPCLithoRecipeParameterSeq[k].parameterValue, CS_RPARM_INEFFECTIVE_VALUE ) != 0 )");

                                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[h].parameterName = tmpstrAPCLithoRecipeParameterSeq[k].parameterName;
                                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[h].parameterValue = tmpstrAPCLithoRecipeParameterSeq[k].parameterValue;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "tmpstrAPCLithoRecipeParameterSeq[k].parameterValue==CS_RPARM_INEFFECTIVE_VALUE");
                                h--;
                            }

                            break;
                        }
                    }

                    if ( ARPLen == exposure_cnt && i != SRPLen-1 )
                    {
                        PPT_METHODTRACE_V4("", "if (ARPLen == exposure_cnt  && i != SRPLen-1)", ARPLen, exposure_cnt, i);

                        if ( j != ALRLen-1 )
                        {
                            PPT_METHODTRACE_V3("", "if ( j != ALRLen-1 )", j, ALRLen);
                            tmpstrAPCLithoRecommendReticleSeq[j] = tmpstrAPCLithoRecommendReticleSeq[ALRLen-1];
                        }
        
                        ALRLen--;
                        tmpstrAPCLithoRecommendReticleSeq.length( ALRLen );

                        PPT_METHODTRACE_V2("", "in para reticleID....   ",tmpstrAPCLithoRecommendReticleSeq[j].reticleID.identifier);
                        j--;
                    }

                    if ( k == ARPLen ) 
                    { 
                        PPT_METHODTRACE_V3("", "if ( k == ARPLen )", k, ARPLen);
                        continue;
                    }
                    else
                    {
                        PPT_METHODTRACE_V3("", "if ( k != ARPLen )", k, ARPLen);
                        break;
                    }
                }

                if ( j == ALRLen ) 
                {
                    PPT_METHODTRACE_V2("", "if ( j == ALRLen )", j);
                    
                    if ( CIMFWStrCmp( tmpstrStartRecipeParameterSeq[i].parameterValue, CS_RPARM_INEFFECTIVE_VALUE ) != 0 )
                    { 
                        PPT_METHODTRACE_V1("", "if (CIMFWStrCmp(tmpstrStartRecipeParameterSeq[i].parameterValue, CS_RPARM_INEFFECTIVE_VALUE) != 0 )");

                        strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[h].parameterName = tmpstrStartRecipeParameterSeq[i].parameterName;
                        strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[h].parameterValue = tmpstrStartRecipeParameterSeq[i].parameterValue;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "tmpstrStartRecipeParameterSeq[i].parameterValue=CS_RPARM_INEFFECTIVE_VALUE)");
                        h--;
                    }
                }
            }
        }

        strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq.length(h);

        //Trace For: strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq 
        for (CORBA::Long m = 0; m < h; m++)
        {
            PPT_METHODTRACE_V2("", "loop Out:strStartRecipeParameterSeq",m ); 

            PPT_METHODTRACE_V2("", "in para Out.parameterName.......",strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[m].parameterName);
            PPT_METHODTRACE_V2("", "in para Out.parameterValue......",strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[m].parameterValue );
        }


        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APC_LithoRecipeParameter_Replace");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjAPC_LithoRecipeParameter_Replace_out, cs_APC_LithoRecipeParameter_Replace, methodName)
}
