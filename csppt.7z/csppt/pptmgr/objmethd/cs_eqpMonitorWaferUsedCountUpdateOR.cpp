//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: cs_eqpMonitorWaferUsedCountUpdateOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pwafer.hh"
#include "plot.hh"
#include "pprsp.hh"     //INN-R170016
#include "ppsctgy.hh"   //INN-R170016

// Class: PPTManager
//
// Service: eqpMonitorWaferUsedCountUpdate()
//
//[Object Function Name]: long   eqpMonitorWaferUsedCountUpdate
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
//
// Change history:
// Date        Defect#      Person         Comments
// ----------  -----------  -------------- ------------------------------------------
// 2017/11/06  INN-R170016  JJ.Zhang       EqpMonitor enhancement
//
//[Function Description]:
//
//[Input Parameters]:
//    const pptObjCommonIn&                         strObjCommonIn
//    const objEqpMonitorWaferUsedCountUpdate_in&   strEqpMonitorWaferUsedCountUpdate_in
//
//     typedef struct objeqpMonitorChangeEvent_Make_in_struct {
//            string                              action;
//            objectIdentifier                    lotID;
//            pptEqpMonitorWaferUsedCountSequence strEqpMonitorWaferUsedCountSeq;
//            any                                 siInfo; }
//
//[Output Parameters]:
//
//     typedef struct objEqpMonitorWaferUsedCountUpdate_out_struct {
//         pptRetCode strResult;
//         pptEqpMonitorWaferUsedCountSequence strEqpMonitorWaferUsedCountSeq;
//         any	siInfo;
//     }objEqpMonitorWaferUsedCountUpdate_out;
//
//    typedef objBase_out objEqpMonitorWaferUsedCountUpdate_out;
//
//[Return Value]:
//  Return Code                  Messsage ID
//  -------------------------   --------------------------------------------------
//  RC_OK                        MSG_OK
//  RC_INVALID_EVENTRECORD_TYPE  MSG_INVALID_EVENTRECORD_TYPE
//

//INN-R170016 CORBA::Long PPTManager_i::eqpMonitorWaferUsedCountUpdate(
CORBA::Long CS_PPTManager_i::eqpMonitorWaferUsedCountUpdate( //INN-R170016
        objEqpMonitorWaferUsedCountUpdate_out&        strEqpMonitorWaferUsedCountUpdate_out,
        const pptObjCommonIn&                         strObjCommonIn,
        const objEqpMonitorWaferUsedCountUpdate_in&   strEqpMonitorWaferUsedCountUpdate_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::eqpMonitorWaferUsedCountUpdate");

        //--------------//
        //  Initialize  //
        //--------------//
        CORBA::Long rc = RC_OK;
        pptEqpMonitorWaferUsedCountSequence strEqpMonitorWaferUsedCountSeq;
        //------------------//
        //Trace InParameters//
        //------------------//
        PPT_METHODTRACE_V2( "", "in para lotID",               strEqpMonitorWaferUsedCountUpdate_in.lotID.identifier);
        PPT_METHODTRACE_V2( "", "in para Action",              strEqpMonitorWaferUsedCountUpdate_in.action);

        //----------------------//
        //Update EqpMonUsedCount//
        //----------------------//
        CORBA::ULong nWafer = 0;
        if ( 0 == CIMFWStrCmp(strEqpMonitorWaferUsedCountUpdate_in.action, SP_EQPMONUSEDCNT_ACTION_UPDATE) )
        {
            //----------------------
            // Update: Update EqpMonUsedCount based on strEqpMonitorWaferUsedCountSeq
            //----------------------
            PPT_METHODTRACE_V1( "","strEqpMonitorWaferUsedCountAction is Update");
            for(nWafer = 0; nWafer< strEqpMonitorWaferUsedCountUpdate_in.strEqpMonitorWaferUsedCountSeq.length(); nWafer++)
            {
                PPT_METHODTRACE_V2("","set eqpMonitorUsedCount for each wafer",nWafer);
                PosWafer_var aPosWafer;
                PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
                                                 strEqpMonitorWaferUsedCountUpdate_in.strEqpMonitorWaferUsedCountSeq[nWafer].waferID,
                                                 strEqpMonitorWaferUsedCountUpdate_out,
                                                 eqpMonitorWaferUsedCountUpdate );
                try
                {
                    aPosWafer->setEqpMonitorUsedCount(strEqpMonitorWaferUsedCountUpdate_in.strEqpMonitorWaferUsedCountSeq[nWafer].eqpMonitorUsedCount);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::setEqpMonitorUsedCount)

            }
        }
        else if ( 0 == CIMFWStrCmp(strEqpMonitorWaferUsedCountUpdate_in.action,SP_EQPMONUSEDCNT_ACTION_INCREMENT) )
        {
            //----------------------
            // Increment: Increment EqpMonUsedCount for lot's all wafer
            //----------------------
            PPT_METHODTRACE_V1( "","strEqpMonitorWaferUsedCountAction is Increment");
            PosLot_var aLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aLot, strEqpMonitorWaferUsedCountUpdate_in.lotID, strEqpMonitorWaferUsedCountUpdate_out, eqpMonitorWaferUsedCountUpdate);

//INN-R170016 Add Start
            //------------------------------------------------------
            // Get product spec Id from Lot
            //------------------------------------------------------
            PosProductSpecification_var aProdSpec;
            try
            {
                ProductSpecification_var aTmpProdSpec;
                aTmpProdSpec = aLot->getProductSpecification();
                aProdSpec = PosProductSpecification::_narrow(aTmpProdSpec);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

            if (CORBA::is_nil(aProdSpec) == TRUE)
            {
                PPT_METHODTRACE_V1("","CORBA::is_nil(aProdSpec) == TRUE");
                SET_MSG_RC(strEqpMonitorWaferUsedCountUpdate_out, MSG_NOT_FOUND_PRODUCTSPEC, RC_NOT_FOUND_PRODUCTSPEC);
                return(RC_NOT_FOUND_PRODUCTSPEC);
            }
            CORBA::String_var prodSpecID;
            try
            {
                prodSpecID = aProdSpec->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(ProductSpecification::getIdentifier);

            //------------------------------------------------------
            // Get NPW inventory definition
            //------------------------------------------------------
            CORBA::Long useCountLimit = 0;
            CORBA::Long maxUsedCount  = 0;

            csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
            strEqpMonitorInventory_ListGetDR_in.npwType = CS_EqpMonitor_NPW_Type_Monitor;
            strEqpMonitorInventory_ListGetDR_in.productID = prodSpecID;

            csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
            rc = cs_eqpMonitorInventory_ListGetDR(strEqpMonitorInventory_ListGetDR_out,
                                         strObjCommonIn,
                                         strEqpMonitorInventory_ListGetDR_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_list_GetDR() rc != RC_OK");
                strEqpMonitorWaferUsedCountUpdate_out.strResult = strEqpMonitorInventory_ListGetDR_out.strResult;
                return rc;
            }
            else if (strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length() > 0)
            {
                PPT_METHODTRACE_V1("", "not NPW Recycle Product");
                useCountLimit = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq[0].useCountLimit;
            }
            PPT_METHODTRACE_V2("", "useCountLimit", useCountLimit);
//INN-R170016 Add End
            
            //------------------------------------------------------
            // Get all wafer information of  Lot
            //------------------------------------------------------
            PosWaferInfoSequence*    lotWaferInfo = NULL;
            PosWaferInfoSequence_var lotWaferInfoVar;
            try
            {
                lotWaferInfo    = aLot->getAllWaferInfo();
                lotWaferInfoVar = lotWaferInfo;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getAllWaferInfo)

            if ( 0 == lotWaferInfoVar->length() )
            {
                SET_MSG_RC( strEqpMonitorWaferUsedCountUpdate_out,
                            MSG_NOT_FOUND_WAFER_IN_LOT,
                            RC_NOT_FOUND_WAFER_IN_LOT );
                return RC_NOT_FOUND_WAFER_IN_LOT;
            }
            strEqpMonitorWaferUsedCountSeq.length(lotWaferInfo->length());
            for (CORBA::ULong w = 0; w<lotWaferInfo->length(); w++)
            {
                PPT_METHODTRACE_V2("","Increment eqpMonitorUsedCount for each wafer", w);
                PosWafer_var aPosWafer;
                PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
                             lotWaferInfoVar[w].waferID,
                             strEqpMonitorWaferUsedCountUpdate_out,
                             eqpMonitorWaferUsedCountUpdate );
                long nOrgEqpMonitorUsedCount;
                try
                {
                    nOrgEqpMonitorUsedCount = aPosWafer->getEqpMonitorUsedCount();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getEqpMonitorUsedCount)
                try
                {
                    aPosWafer->increaseEqpMonitorUsedCount();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::increaseEqpMonitorUsedCount)
                strEqpMonitorWaferUsedCountSeq[w].waferID = lotWaferInfoVar[w].waferID;
                strEqpMonitorWaferUsedCountSeq[w].eqpMonitorUsedCount = nOrgEqpMonitorUsedCount+1;
                maxUsedCount = (strEqpMonitorWaferUsedCountSeq[w].eqpMonitorUsedCount > maxUsedCount) ? (strEqpMonitorWaferUsedCountSeq[w].eqpMonitorUsedCount) : maxUsedCount; //INN-R170016
            }
//INN-R170016 Add Start
            //Set NPW_Recycle_Request=Yes for all lots in the carrier if maxUsedCount is over
            if( useCountLimit > 0 && maxUsedCount >= useCountLimit )
            {
                PPT_METHODTRACE_V3("", "maxUsedCount is over", useCountLimit, maxUsedCount);
                //------------------------------------------------------
                //  get all lots in carrier
                //------------------------------------------------------
                objLot_cassetteList_GetDR_out   strLot_cassetteList_GetDR_out;
                rc = lot_cassetteList_GetDR( strLot_cassetteList_GetDR_out, strObjCommonIn, strEqpMonitorWaferUsedCountUpdate_in.lotID);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_cassetteList_GetDR rc!=RC_OK", rc);
                    strEqpMonitorWaferUsedCountUpdate_out.strResult = strLot_cassetteList_GetDR_out.strResult ;
                    return ( rc );
                }
                objCassette_lotList_GetDR_out   strCassette_lotList_GetDR_out;
                rc = cassette_lotList_GetDR( strCassette_lotList_GetDR_out,
                                             strObjCommonIn,
                                             strLot_cassetteList_GetDR_out.cassetteID);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() != RC_OK");
                    strEqpMonitorWaferUsedCountUpdate_out.strResult = strCassette_lotList_GetDR_out.strResult ;
                    return(rc);
                }
                CORBA::Long lotLen = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID.length();

                for( CORBA::Long i = 0; i < lotLen; i++ )
                {
                    PPT_METHODTRACE_V2("", "strLotListInCassetteInfo.lotID", strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[i].identifier);

                    PosLot_var aMonitorLot;
                    PPT_CONVERT_LOTID_TO_LOT_OR( aMonitorLot, strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[i], strEqpMonitorWaferUsedCountUpdate_out, eqpMonitorWaferUsedCountUpdate);

                    CORBA::String_var strUdataValue;
                    SI_PPT_USERDATA_GET_STRING(aMonitorLot, CS_M_LOT_NPW_Recycle_Request, strUdataValue);
                    PPT_METHODTRACE_V2("", "CS_M_LOT_NPW_Recycle_Request", strUdataValue);

                    if( 0 != CIMFWStrCmp(strUdataValue, SP_UData_True) )
                    {
                        SI_PPT_USERDATA_SET_STRING(aMonitorLot, CS_M_LOT_NPW_Recycle_Request, SP_UData_True);
                    }
                }
            }
//INN-R170016 Add End
        }
        else if ( 0 == CIMFWStrCmp(strEqpMonitorWaferUsedCountUpdate_in.action,SP_EQPMONUSEDCNT_ACTION_RESET) )
        {
            //----------------------
            // Reset: Reset EqpMonUsedCount with 0 for lot's all wafer
            //----------------------
            PPT_METHODTRACE_V1( "","strEqpMonitorWaferUsedCountAction is Reset");
            PosLot_var aLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aLot, strEqpMonitorWaferUsedCountUpdate_in.lotID, strEqpMonitorWaferUsedCountUpdate_out, eqpMonitorWaferUsedCountUpdate);
            //------------------------------------------------------
            // Get all wafer information of  Lot
            //------------------------------------------------------
            PosWaferInfoSequence*    lotWaferInfo = NULL;
            PosWaferInfoSequence_var lotWaferInfoVar;
            try
            {
                lotWaferInfo    = aLot->getAllWaferInfo();
                lotWaferInfoVar = lotWaferInfo;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getAllWaferInfo)

            if ( 0 == lotWaferInfoVar->length() )
            {
                SET_MSG_RC( strEqpMonitorWaferUsedCountUpdate_out,
                            MSG_NOT_FOUND_WAFER_IN_LOT,
                            RC_NOT_FOUND_WAFER_IN_LOT );
                return RC_NOT_FOUND_WAFER_IN_LOT;
            }
            strEqpMonitorWaferUsedCountSeq.length(lotWaferInfo->length());
            for (CORBA::ULong w = 0; w<lotWaferInfo->length(); w++)
            {
                PPT_METHODTRACE_V2("","Increment eqpMonitorUsedCount for each wafer", w);
                PosWafer_var aPosWafer;
                PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
                             lotWaferInfoVar[w].waferID,
                             strEqpMonitorWaferUsedCountUpdate_out,
                             eqpMonitorWaferUsedCountUpdate );
                try
                {
                    aPosWafer->setEqpMonitorUsedCount(0);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::setEqpMonitorUsedCount)
                strEqpMonitorWaferUsedCountSeq[w].waferID = lotWaferInfoVar[w].waferID;
                strEqpMonitorWaferUsedCountSeq[w].eqpMonitorUsedCount = 0;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "action is invalid");
            PPT_SET_MSG_RC_KEY( strEqpMonitorWaferUsedCountUpdate_out,
                                MSG_INVALID_PARAMETER_WITH_MSG,
                                RC_INVALID_PARAMETER_WITH_MSG,
                                "Specified action is invalid" );
            return RC_INVALID_PARAMETER_WITH_MSG;
        }
        if ( 0 == CIMFWStrCmp(strEqpMonitorWaferUsedCountUpdate_in.action, SP_EQPMONUSEDCNT_ACTION_UPDATE) )
        {
            PPT_METHODTRACE_V1("", "Action is UPDATE, strEqpMonitorWaferUsedCountSeq is same as input.");
            strEqpMonitorWaferUsedCountUpdate_out.strEqpMonitorWaferUsedCountSeq = strEqpMonitorWaferUsedCountUpdate_in.strEqpMonitorWaferUsedCountSeq;
        }
        else
        {
            PPT_METHODTRACE_V1("", "Action is not UPDATE, set strEqpMonitorWaferUsedCountSeq");
            strEqpMonitorWaferUsedCountUpdate_out.strEqpMonitorWaferUsedCountSeq = strEqpMonitorWaferUsedCountSeq;
        }
        //--------------------//
        //  Return to Caller  //
        //--------------------//
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::eqpMonitorWaferUsedCountUpdate");
        return RC_OK ;
    }
    CATCH_GLOBAL_EXCEPTIONS(strEqpMonitorWaferUsedCountUpdate_out, eqpMonitorWaferUsedCountUpdate, methodName);
}
