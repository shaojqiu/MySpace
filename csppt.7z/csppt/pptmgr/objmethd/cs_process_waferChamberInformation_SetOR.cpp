#ifndef lint
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. #ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_process_waferChamberInformation_SetOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:23:36 [ 7/13/07 20:23:37 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: process_waferChamberInformation_Set.cpp
//

#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "ppcope.hh"
#include "pwafer.hh" //INN-R170006
#include "ppcdr.hh"  //INN-R170006

//[Object Function Name]: long   process_waferChamberInformation_Set
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2004-04-19  D5100088  M.Kase         Initial Release (R5.1.1)
//
// Innotron Modification history :
// Date        Defect#       Person     Comments
// ----------  ------------- ---------- -------------------------------------------
// 2017/09/11  INN-R170006   YangXigang For fixture
//
//[Function Description]:
//  Set the value of theAssignedProcessResources for wafer-chamber information.
//
//[Input Parameters]:
//  in  pptObjCommonIn                    strObjCommonIn;
//  in  pptChamberProcessLotInfoSequence  strChamberProcessLotInfos;
//
//[Output Parameters]:
//  out objProcess_waferChamberInformation_Set_out  strProcess_waferChamberInformation_Set_out;
//
//  typedef struct objProcess_waferChamberInformation_Set_out_struct {
//      pptRetCode  strResult;
//  } objProcess_waferChamberInformation_Set_out;
//
//[Return Value]:
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_PO             MSG_NOT_FOUND_PO
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//
//
//[Pseudo Code]:
//

CORBA::Long CS_PPTManager_i::process_waferChamberInformation_Set(
                    objProcess_waferChamberInformation_Set_out& strProcess_waferChamberInformation_Set_out,
                    const pptObjCommonIn&                       strObjCommonIn,
                    const pptChamberProcessLotInfoSequence&     strChamberProcessLotInfos )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::process_waferChamberInformation_Set");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long i, j, k;
        CORBA::Long lenLot = strChamberProcessLotInfos.length();
        PPT_METHODTRACE_V2("", "lenLot = ", lenLot);

        for ( i=0; i<lenLot; i++ )
        {
            PPT_METHODTRACE_V3("", "loop to strChamberProcessLotInfos.length() : ", lenLot, i);

            /*--------------------*/
            /*   Get Lot Object   */
            /*--------------------*/
            PosLot_var aPosLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                         strChamberProcessLotInfos[i].lotID,
                                         strProcess_waferChamberInformation_Set_out,
                                         process_waferChamberInformation_Set );

            /*--------------------------------------------------*/
            /*   Get and Check Lot's Process Operation Object   */
            /*--------------------------------------------------*/
            ProcessOperation_var    aPO;
            PosProcessOperation_var aPosPO;
            try
            {
                aPO = aPosLot->getProcessOperation();
                aPosPO = PosProcessOperation::_narrow( aPO );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

            if ( !CORBA::is_nil(aPosPO) )
            {
                PPT_METHODTRACE_V1("", "aPosPO is not nil");

                CORBA::Long lenWafer = strChamberProcessLotInfos[i].strChamberProcessWaferInfos.length();
                PPT_METHODTRACE_V2("", "lenWafer = ", lenWafer);

                for ( j=0; j<lenWafer; j++ )
                {
                    PPT_METHODTRACE_V4("", "loop to strChamberProcessLotInfos[i].strChamberProcessWaferInfos.length() : ", lenWafer, i, j);

                    /*-----------------------------------*/
                    /*   Get Wafer-Chamber Information   */
                    /*-----------------------------------*/
                    posProcessResourceInfo*    processResourceInfo = NULL;
                    posProcessResourceInfo_var processResourceInfoVar;
                    try
                    {
                        processResourceInfo = aPosPO->findAssignedProcessResourceInfo(strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID.identifier);
                        processResourceInfoVar = processResourceInfo;
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findAssignedProcessResourceInfo);

                    posProcessResourceInfo     tmpProcessResourceInfo;

                    if ( CIMFWStrLen( processResourceInfo->processWafer ) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "CIMFWStrLen( processResourceInfo->processWafer ) == 0");

                        /*---------------------------------------------------------*/
                        /*   Setup Wafer-Chamber Information using reported data   */
                        /*---------------------------------------------------------*/
                        tmpProcessResourceInfo.processWafer = strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID.identifier;

                        CORBA::Long lenChamber = strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos.length();
                        PPT_METHODTRACE_V2("", "lenChamber = ", lenChamber);
                        tmpProcessResourceInfo.processResourceIDs.length(lenChamber);

                        for ( k=0; k<lenChamber; k++ )
                        {
                            PPT_METHODTRACE_V5("", "loop to strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos.length() : ", lenChamber, i, j, k);
                            tmpProcessResourceInfo.processResourceIDs[k] = strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos[k].chamberID;
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "CIMFWStrLen( processResourceInfo->processWafer ) != 0");

                        /*----------------------------------------------------------------------*/
                        /*   Setup Wafer-Chamber Information using existing and reported data   */
                        /*----------------------------------------------------------------------*/
                        tmpProcessResourceInfo.processWafer = processResourceInfo->processWafer;

                        CORBA::Long lenExistChamber = processResourceInfo->processResourceIDs.length();
                        PPT_METHODTRACE_V2("", "lenExistChamber = ", lenExistChamber);
                        CORBA::Long lenChamber = strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos.length();
                        PPT_METHODTRACE_V2("", "lenChamber = ", lenChamber);
                        tmpProcessResourceInfo.processResourceIDs.length(lenExistChamber+lenChamber);

                        for ( k=0; k<lenExistChamber; k++ )
                        {
                            PPT_METHODTRACE_V3("", "loop to processResourceInfo->processResourceIDs.length() : ", lenExistChamber, k);
                            tmpProcessResourceInfo.processResourceIDs[k] = processResourceInfo->processResourceIDs[k];
                        }

                        for ( k=0; k<lenChamber; k++ )
                        {
                            PPT_METHODTRACE_V5("", "loop to strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos.length() : ", lenChamber, i, j, k);
                            tmpProcessResourceInfo.processResourceIDs[lenExistChamber+k] = strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos[k].chamberID;
                        }
                    }

                    /*-----------------------------------*/
                    /*   Add Wafer-Chamber Information   */
                    /*-----------------------------------*/
                    try
                    {
                        aPosPO->addAssignedProcessResourceInfo(tmpProcessResourceInfo);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::addAssignedProcessResourceInfo);
                    
                    // INN-R170006 add start
                    
                    csChamberProcessWafer_siInfo *pChamberProcessWafer_siInfo = NULL; 
                    if ( strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].siInfo >>= pChamberProcessWafer_siInfo )
                    { 
                        PosWafer_var aWafer; 
                        objectIdentifier processWaferID; 
                        processWaferID.identifier = tmpProcessResourceInfo.processWafer; 
                        PPT_CONVERT_WAFERID_TO_WAFER_OR( aWafer, processWaferID, strProcess_waferChamberInformation_Set_out, process_waferChamberInformation_Set ); 
                        CORBA::Long nFixture = pChamberProcessWafer_siInfo->fixtureIDs.length(); 
                        
                        for (CORBA::Long iFix = 0; iFix < nFixture; iFix++) 
                        { 
                            // Check fixture ID is valid PosProcessDurable_var aFixture; 
                            PosProcessDurable_var aFixture;
                            PPT_CONVERT_FIXTUREID_TO_FIXTURE_OR( aFixture, 
                                                                pChamberProcessWafer_siInfo->fixtureIDs[iFix], 
                                                                strProcess_waferChamberInformation_Set_out, 
                                                                process_waferChamberInformation_Set ); 
                        } 
                        
                        if ( 0 == nFixture ) 
                        { 
                            CS_PPT_SET_MSG_RC_KEY1( strProcess_waferChamberInformation_Set_out, MSG_NOT_FOUND_FIXTURE, RC_NOT_FOUND_FIXTURE, "******" ); 
                            return RC_NOT_FOUND_FIXTURE ; 
                        } 
                        
                        CORBA::Long lngOrigTchCnt = 0; 
                        try 
                        { 
                            SI_PPT_USERDATA_GET_INTEGER(aWafer, CS_M_WAFER_FixtureTouchCount, lngOrigTchCnt); 
                        } 
                        CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getUserDataNamed) 
                        
                        try 
                        {   
                            SI_PPT_USERDATA_SET_INTEGER(aWafer, CS_M_WAFER_FixtureTouchCount, lngOrigTchCnt + nFixture); 
                        } 
                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataSetNamed);
                    }
                    // INN-R170006 add end
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "aPosPO is nil");

                PPT_SET_MSG_RC_KEY2( strProcess_waferChamberInformation_Set_out,
                                     MSG_NOT_FOUND_PO,
                                     RC_NOT_FOUND_PO,
                                     "*****",
                                     strChamberProcessLotInfos[i].lotID.identifier );
                return RC_NOT_FOUND_PO;
            }
        }

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::process_waferChamberInformation_Set");

        return RC_OK;
    } 
    CATCH_GLOBAL_EXCEPTIONS(strProcess_waferChamberInformation_Set_out, process_waferChamberInformation_Set, methodName)
}
