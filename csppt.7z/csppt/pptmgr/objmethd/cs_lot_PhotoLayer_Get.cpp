//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2011. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2011. All rights reserved.
//
// SiView
// Name: cs_lot_PhotoLayer_Get.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "ppcope.hh"

// Class: CS_PPTManager
//
// Service: cs_lot_PhotoLayer_Get()
//
// Innotron Modification History:
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017/10/23 INN-R170009   Gary Ke        Lot Photo Layer Get
//
// Description:
//
// Return:
//     Long
//
// Input Parameter:
// in csObjLot_PhotoLayer_Get_in  strLot_PhotoLayer_Get_in
//
// typedef struct csObjLot_PhotoLayer_Get_in_struct {
// objectIdentifier        lotID;
// boolean                 previousPOFlag;
// any                     siInfo;
// } csObjLot_PhotoLayer_Get_in;
//
// Output Parameter:
// typedef struct csObjLot_PhotoLayer_Get_out_struct {
// pptRetCode              strResult;
// string                  photoLayer;
// any                     siInfo;
// } csObjLot_PhotoLayer_Get_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//

CORBA::Long CS_PPTManager_i::cs_lot_PhotoLayer_Get (
    csObjLot_PhotoLayer_Get_out&              strLot_PhotoLayer_Get_out,
    const pptObjCommonIn&                     strObjCommonIn,
    const csObjLot_PhotoLayer_Get_in&         strLot_PhotoLayer_Get_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_lot_PhotoLayer_Get")

        //=================//
        //   Initialize    //
        //=================//
        CORBA::Long rc = RC_OK ;

        //---------------------------//
        //   Get Lot Object          //
        //---------------------------//
        PosLot_var varLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( varLot,
                                     strLot_PhotoLayer_Get_in.lotID,
                                     strLot_PhotoLayer_Get_out,
                                     cs_lot_PhotoLayer_Get );

        //---------------------------//
        //   Get PO Object           //
        //---------------------------//
        PosProcessOperation_var varPO;
        if ( strLot_PhotoLayer_Get_in.previousPOFlag )
        {
            // Get previous PosProcessOperation Object from PosLot
            try
            {
                ProcessOperation_var varTmpPO;
                varTmpPO = varLot->getPreviousProcessOperation();
                varPO = PosProcessOperation::_narrow(varTmpPO);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getPreviousProcessOperation);
        }
        else
        {
            // Get current PosProcessOperation Object from PosLot
            try
            {
                ProcessOperation_var varTmpPO;
                varTmpPO = varLot->getProcessOperation();
                varPO  = PosProcessOperation::_narrow( varTmpPO );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)
        }

        if( CORBA::is_nil( varPO ) == TRUE )
        {
            PPT_METHODTRACE_V1("", "varPO is nil");
            PPT_SET_MSG_RC_KEY2( strLot_PhotoLayer_Get_out,
                                 MSG_NOT_FOUND_PO,
                                 RC_NOT_FOUND_PO,
                                 "*****",
                                 strLot_PhotoLayer_Get_in.lotID.identifier);
            return( RC_NOT_FOUND_PO );
        }
        else
        {
            //---------------------------//
            //   Get Photo Layer         //
            //---------------------------//
            CORBA::String_var varPhotoLayer;
            try
            {
                varPhotoLayer = varPO->getPhotoLayer();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getPhotoLayer);
            PPT_METHODTRACE_V2("", "varPhotoLayer", varPhotoLayer);

            strLot_PhotoLayer_Get_out.photoLayer = CIMFWStrDup( varPhotoLayer );
        }

        //=============//
        //   Return    //
        //=============//
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_lot_PhotoLayer_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_PhotoLayer_Get_out, cs_lot_PhotoLayer_Get, methodName)
}

