#ifndef lint
static char *sccsid =  "@(#) 1.8 superpos/src/spppt/source/posppt/pptmgr/objmethd/whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq.cpp, mm_srv_120e_ppt, mm_srv_120e_ppt 10/26/07 13:17:01 [ 10/26/07 13:17:03 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReqOR.cpp
//

#include "cs_pptmgr.hpp" //INN-R170002
#include "pcas.hh"
#include "plcrc.hh"
#include "pprsp.hh"
#include "pmcrc.hh"     //D4200092
#include "plot.hh"      //P4200137
#include "pptconvert.h" //D9000005
#include "pptconverter.h" //DSIV00000099
#include "ppcflwx.hh"     //DSN000081739
#include "ppcope.hh"      //DSN000081739

//[Object Function Name]: long   whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2001/06/26  D4000015     K.Matsuei      Internal Buffuer Contorl.
// 2001/08/09  D4000048     M.Ameshita     Reticle set support.
// 2001/08/20  P4000099     K.Matsuei      Invalid obj-method filename.
// 2001/08/24  P4000015     K.Matsuei      add logic. "0.02"
// 2001/08/29  D4000016     M.Shimizu      add logic Contamination Control(Copper/Non Copper [R40 Core])
// 2001/09/17  D4000184     K.Matsuei      The problem of CopperNonCopper was found with CassetteDelivery.
// 2001/09/19  0.03         K.Matsuei      Comment Out Unnecessary Logic.
// 2001-10-23  D4000227     K.Matsuei      The specification change of CassetteDelivery.
// 2001/10/25  P4000390     K.Matsuei      EmptyCarrier was acquired without checking of OpeStartFlag in CassetteDelivery.
// 2001/11/28  P4100010     K.Matsuei      Copper/NonCopper Check doesn't go well in CassetteDelivery.
// 2001/11/28  P4100019     K.Matsuei      Bug fix CassetteDelivery for InternalBuffer.
// 2002/03/05  D4100036     K.Matsuei      FlowBatch Control.
// 2002/03/25  P4100258     K.Matsuei      Lot isn't select in CassetteDelivery. Unnecessary MinWaferCheck.
// 2002/08/29  D4200092     K.Matsuei      RecipeParameter is not stored into PosPO with Auto-3.
// 2002/09/06  P4200137     K.Matsuei      There is an item which is not set to StartCassette by StartReserve of CassetteDelivery(Auto3).
// 2002/10/03  P4200182     K.Matsuei      FlowBatching Lot of ML-SR cannot Dispatch by CassetteDelivery.
// 2003/06/19  P5000047     K.Matsuei      BMR in CassetteExchange of Delivery of InternalBuffer.
// 2003/12/11  P5100073     K.Matsuei      EmptyCassettes are assigned to the same Port by CassetteDelivery.
// 2004/09/07  D51M0007     K.Matsuei      Performance improvement of WhatsNext.
// 2005/08/31  D6000415     K.Kido         Call findRecipeParametersForSubLotType() to get correct Recipe Parameter taken into account for Chamber Machine State.
// 2005/11/14  D7000074     F.Masada       Multiple Recipe Type is supported for Internal Buffer Eqp.
// 2005/12/07  D7000042     K.Kido         Get Machine Recipe by findMachineRecipeForSubLotType for findRecipeParametersForSubLotType.
// 2006/02/17  P7000106     K.Matsuei      StartReserve is completed incorrectly.
// 2006/01/23  D7000183     K.Matsuei      Select Lot in consideration of MinBatchSize in CassetteDelivery.
// 2006/12/05  D8000024     H.Mutoh        Flexible Process Condition Change (R80)
// 2007/09/20  D9000079     D.Tamura       FlowBatch Enhancement.
// 2007/10/23  D9000001     K.Matsuei      64bit support.
// 2007/10/24  D9000005     M.Murata       cassette_FillInTxPDQ007DR -> cassette_ListGetDR__090
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/04 DSIV00000099 M.Ogawa        cassette_ListGetDR__090 -> cassette_ListGetDR__100
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
// 2011/09/28 DSN000020767 T.Ishida       Auto Dispatch Control Support
// 2013/10/31 DSN000081739 Shudi Wang     Equipment Monitor Automation Support
// 2015/11/10 DSN000096126 C.Mo           cassette_ListGetDR__100 ==> cassette_ListGetDR__160
//                                        cassette_DBInfo_GetDR__120 ==> cassette_DBInfo_GetDR__160
// 2016/07/27 DSN000101569 C.Mo           cassette_ListGetDR__160 ==> cassette_ListGetDR__170
//                                        cassette_DBInfo_GetDR__160 ==> cassette_DBInfo_GetDR__170
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/02 INN-R170002  JJ.Zhang       Contamination Control
//
//[Function Description]:
// Choose Lots from WIPLots, and return it with StartCassette.
// Choose it until Shelf becomes full.
// Believe InternalBufferEquipment is Batch.
//
//[Input Parameters]:
//  in  pptObjCommonIn                                   strObjCommonIn;
//  in  objectIdentifier                                 equipmentID;
//  const objEquipment_targetPort_Pickup_out_struct&     strEquipment_targetPort_Pickup_out;
//  const pptWhatNextLotListForInternalBufferInqResult&  strWhatNextLotListForInternalBufferInqResult;  //D4000015
//  const CORBA::Boolean&                                bEqpInternalBufferInfo;                        //D4000015
//  const pptEqpInternalBufferInfoSequence&              strEqpInternalBufferInfoSeq;                   //D4000015
//D4000015//  in  pptPortGroupSequence                         strPortGroup;
//D4000015//  in  pptWhatNextLotListInqResult                  strWhatNextLotListInqResult;
//
//[Output Parameters]:
//  out objWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out   strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out;
//
//  typedef objWhatNextLotList_to_StartCassetteForDeliveryReq_out  objWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out
//
//  typedef struct objWhatNextLotList_to_StartCassetteForDeliveryReq_out_struct {
//      pptRetCode                  strResult;
//      pptStartCassetteSequence    strStartCassette;
//  } objWhatNextLotList_to_StartCassetteForDeliveryReq_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_TARGET_PORT    MSG_NOT_FOUND_TARGET_PORT
//  RC_NOT_SPACE_EQP_SELF       MSG_NOT_SPACE_EQP_SELF
//  RC_NOT_FOUND_FILLEDCAST     MSG_NOT_FOUND_FILLEDCAST
//
//[Pseudo Code]:
//

//INN-R170002 CORBA::Long PPTManager_i::whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq(
CORBA::Long CS_PPTManager_i::whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq( //INN-R170002
    objWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out&  strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
    const pptObjCommonIn&                                                    strObjCommonIn,
    const objectIdentifier&                                                  equipmentID,
//    const pptPortGroupSequence&                                              strPortGroup,
    const objEquipment_targetPort_Pickup_out_struct&                         strEquipment_targetPort_Pickup_out,
    const pptWhatNextLotListForInternalBufferInqResult&                      strWhatNextLotListForInternalBufferInqResult,
    const CORBA::Boolean&                                                    bEqpInternalBufferInfo,        //D4000015
    const pptEqpInternalBufferInfoSequence&                                  strEqpInternalBufferInfoSeq )  //D4000015
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq");

        /*---------------------------------*/
        /*   Debug Trace Input Parameter   */
        /*---------------------------------*/
{
        CORBA::Long ii, jj, kk, len, len2, len3;
        PPT_METHODTRACE_V1("","*****************************************************************");
        PPT_METHODTRACE_V1("","  Input Parameter");
        PPT_METHODTRACE_V1("","*****************************************************************");
        PPT_METHODTRACE_V2("","equipmentID__________________________",equipmentID.identifier);

        PPT_METHODTRACE_V1("","=================================================================");
        PPT_METHODTRACE_V1("","***** WIPLot Info ");
        PPT_METHODTRACE_V1("","=================================================================");
        PPT_METHODTRACE_V2("", "equipmentCategory___________________", strWhatNextLotListForInternalBufferInqResult.equipmentCategory);
        PPT_METHODTRACE_V2("", "processRunSizeMaximum_______________", strWhatNextLotListForInternalBufferInqResult.processRunSizeMaximum);
        PPT_METHODTRACE_V2("", "processRunSizeMinimum_______________", strWhatNextLotListForInternalBufferInqResult.processRunSizeMinimum);
        len = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes.length();
        PPT_METHODTRACE_V2("", "strWhatNextAttributes.length________", len);
        for (ii=0; ii < len; ii++)
        {
        PPT_METHODTRACE_V2("", "lotID //////////////////////////////", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].lotID.identifier);
        PPT_METHODTRACE_V2("", "  cassetteID________________________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].cassetteID.identifier);
        PPT_METHODTRACE_V2("", "  lotType___________________________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].lotType);
        PPT_METHODTRACE_V2("", "  multiLotType______________________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].multiLotType);
        PPT_METHODTRACE_V2("", "  transferStatus____________________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].transferStatus);
        PPT_METHODTRACE_V2("", "  requiredCassetteCategory__________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].requiredCassetteCategory);
        PPT_METHODTRACE_V2("", "  cassetteCategory__________________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].cassetteCategory);
        PPT_METHODTRACE_V2("", "  next2requiredCassetteCategory_____", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].next2requiredCassetteCategory);
        PPT_METHODTRACE_V2("", "  routeID___________________________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].routeID.identifier); //P7000106
        PPT_METHODTRACE_V2("", "  operationID_______________________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].operationID.identifier); //P7000106
        PPT_METHODTRACE_V2("", "  operationNumber___________________", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[ii].operationNumber); //P7000106
        }

        PPT_METHODTRACE_V1("","=================================================================");
        PPT_METHODTRACE_V1("","***** Terget Port Info ");
        PPT_METHODTRACE_V1("","=================================================================");

        PPT_METHODTRACE_V2("", "  equipmentID_______________________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.equipmentID.identifier);
        len = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup.length();
        PPT_METHODTRACE_V2("", "strPortGroup.length_________________", len);
        for (ii=0; ii < len; ii++)
        {
        PPT_METHODTRACE_V2("", "portGroup_//////////////////////////", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].portGroup);
        len2 = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID.length();
        PPT_METHODTRACE_V2("", "  strPortID.length__________________", len2);
        for (jj=0; jj < len2; jj++)
        {
        PPT_METHODTRACE_V2("", "    portID /////////////////////////", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portID.identifier);
        PPT_METHODTRACE_V2("", "    loadSequenceNoInPortGroup_______", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].loadSequenceNoInPortGroup);
        PPT_METHODTRACE_V2("", "    portUsage_______________________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portUsage);
        PPT_METHODTRACE_V2("", "    usageType_______________________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].usageType);
        PPT_METHODTRACE_V2("", "    loadPurposeType_________________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].loadPurposeType);
        PPT_METHODTRACE_V2("", "    portState_______________________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portState);
        PPT_METHODTRACE_V2("", "    cassetteID______________________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].cassetteID.identifier);
        PPT_METHODTRACE_V2("", "    dispatchState___________________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchState);
        PPT_METHODTRACE_V2("", "    dispatchState_TimeStamp_________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchState_TimeStamp);
        PPT_METHODTRACE_V2("", "    dispatchLoadLotID_______________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchLoadLotID.identifier);
        PPT_METHODTRACE_V2("", "    dispatchLoadCassetteID__________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchLoadCassetteID.identifier);
        PPT_METHODTRACE_V2("", "    dispatchUnloadLotID_____________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchUnloadLotID.identifier);
        PPT_METHODTRACE_V2("", "    dispatchUnloadCassetteID________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchUnloadCassetteID.identifier);
        len3 = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].categoryCapability.length();
        PPT_METHODTRACE_V2("", "    categoryCapability.length_______", len3);
        for (kk=0; kk < len3; kk++)
        {
        PPT_METHODTRACE_V2("", "    categoryCapability______________", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].categoryCapability[kk]);
        }
        }
        }
        PPT_METHODTRACE_V1("","");
}

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        CORBA::Long i, j, k;

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Check Condition and Get Information                                                                      */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

        /*----------------------------*/
        /*   Check Target Port Info   */
        /*----------------------------*/
        if ( 0 != CIMFWStrCmp(strEquipment_targetPort_Pickup_out.targetPortType, SP_PortRsc_PortState_LoadReq) )
        {
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out, MSG_NOT_FOUND_TARGET_PORT, RC_NOT_FOUND_TARGET_PORT);
            return RC_NOT_FOUND_TARGET_PORT;
        }
        CORBA::Long nCanBeUsedPortCount = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID.length();

        /*---------------------------------------------*/
        /*   Get Equipment's Process Batch Condition   */
        /*---------------------------------------------*/
        PPT_METHODTRACE_V1("", "/*---------------------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Get Equipment's Process Batch Condition   */");
        PPT_METHODTRACE_V1("", "/*---------------------------------------------*/");
        objEquipment_processBatchCondition_Get_out strEquipment_processBatchCondition_Get_out;
        rc = equipment_processBatchCondition_Get( strEquipment_processBatchCondition_Get_out,
                                                  strObjCommonIn,
                                                  equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### equipment_processBatchCondition_Get != RC_OK")
            strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strEquipment_processBatchCondition_Get_out.strResult;
            return ( rc );
        }
        PPT_METHODTRACE_V2("", "minBatchSize--------------->", strEquipment_processBatchCondition_Get_out.minBatchSize);
        PPT_METHODTRACE_V2("", "maxBatchSize--------------->", strEquipment_processBatchCondition_Get_out.maxBatchSize);
        PPT_METHODTRACE_V2("", "minWaferSize--------------->", strEquipment_processBatchCondition_Get_out.minWaferSize);
//D9000001        PPT_METHODTRACE_V2("", "cassetteExchangeFlag------->", (long)strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag);
//D9000001        PPT_METHODTRACE_V2("", "monitorCreationFlag-------->", (long)strEquipment_processBatchCondition_Get_out.monitorCreationFlag);
        PPT_METHODTRACE_V2("", "cassetteExchangeFlag------->", (int)strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag); //D9000001
        PPT_METHODTRACE_V2("", "monitorCreationFlag-------->", (int)strEquipment_processBatchCondition_Get_out.monitorCreationFlag); //D9000001
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

        /*----------------------------------*/
        /*   Get Eqp Internal Buffer Info   */
        /*----------------------------------*/
        PPT_METHODTRACE_V1("", "/*----------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Get Eqp Internal Buffer Info   */");
        PPT_METHODTRACE_V1("", "/*----------------------------------*/");
        objEquipment_internalBufferInfo_Get_out strEquipment_internalBufferInfo_Get_out;

        if ( FALSE == bEqpInternalBufferInfo )
        {
            PPT_METHODTRACE_V1("", "FALSE == bEqpInternalBufferInfo");
            rc = equipment_internalBufferInfo_Get( strEquipment_internalBufferInfo_Get_out,
                                                   strObjCommonIn,
                                                   equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### RC_OK != equipment_internalBufferInfo_Get()");
                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strEquipment_internalBufferInfo_Get_out.strResult;
                return rc;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "TRUE == bEqpInternalBufferInfo");
            strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo = strEqpInternalBufferInfoSeq;
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

        /*------------------------------------*/
        /*   Get Internal Buffer Free Shelf   */
        /*------------------------------------*/
        PPT_METHODTRACE_V1("", "/*------------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Get Internal Buffer Free Shelf   */");
        PPT_METHODTRACE_V1("", "/*------------------------------------*/");
        objEquipment_shelfSpaceForInternalBuffer_Get_out strEquipment_shelfSpaceForInternalBuffer_Get_out;
        rc = equipment_shelfSpaceForInternalBuffer_Get( strEquipment_shelfSpaceForInternalBuffer_Get_out,
                                                        strObjCommonIn,
                                                        equipmentID,
                                                        TRUE,
                                                        strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### RC_OK != equipment_shelfSpaceForInternalBuffer_Get()");
            strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strEquipment_shelfSpaceForInternalBuffer_Get_out.strResult;
            return rc;
        }
        PPT_METHODTRACE_V2("", "Shelf-->processLotSpace   ", strEquipment_shelfSpaceForInternalBuffer_Get_out.processLotSpace);
        PPT_METHODTRACE_V2("", "Shelf-->emptyCassetteSpace", strEquipment_shelfSpaceForInternalBuffer_Get_out.emptyCassetteSpace);
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

        /**********************************************************************/
        /*                                                                    */
        /*   Get Empty Cassette                                               */
        /*                                                                    */
        /**********************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Get Empty Cassette");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        objCassetteList_emptyAvailable_Pickup_out strCassetteList_emptyAvailable_Pickup_out;
//D4000184        CORBA::Long nCanBeUsedEmptyCassetteCount = 0;
//D4000184        CORBA::Long nUsedEmptyCassetteCount = 0;
        CORBA::Long nShelfSpaceOfEmptyCassette = 0;                 //D4000184
        CORBA::Long nAssignEmptyCassetteCnt = 0;                    //D4000184
        objectIdentifierSequence useEmptyCassetteIDSeq;             //D4000184
        objectIdentifierSequence useAssignEmptyCassettePortSeq;     //D4000184

        if ( TRUE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag        // P4000015 0.02
          || TRUE == strEquipment_processBatchCondition_Get_out.monitorCreationFlag )       // P4000015 0.02
        {
            PPT_METHODTRACE_V1("","EmptyCassette is necessary");
            /*--------------------------------------------------------------------*/
            /*   EmptyCassette is necessary at This point!!                       */
            /*   But, make it an ERROR because ShelfSpace of EmptyCassette is 0   */
            /*--------------------------------------------------------------------*/
            if ( 0 == strEquipment_shelfSpaceForInternalBuffer_Get_out.emptyCassetteSpace )
            {
                PPT_METHODTRACE_V1("", "##### EmptyCassette is necessary But!! ShelfSpace of EmptyCassette is 0");
                PPT_SET_MSG_RC_KEY( strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                    MSG_NOT_SPACE_EQP_SELF,
                                    RC_NOT_SPACE_EQP_SELF,
                                    SP_LoadPurposeType_EmptyCassette );
                return RC_NOT_SPACE_EQP_SELF;
            }

//D4000184//D4000016 Add Start
//D4000184            /*--------------------------------------------------*/
//D4000184            /*   Get Next2 Operation RequiredCassetteCategory   */
//D4000184            /*--------------------------------------------------*/
//D4000184            PPT_METHODTRACE_V1("", "/*--------------------------------------------------*/");
//D4000184            PPT_METHODTRACE_V1("", "/*   Get Next2 Operation RequiredCassetteCategory   */");
//D4000184            PPT_METHODTRACE_V1("", "/*--------------------------------------------------*/");
//D4000184            objLot_requiredCassetteCategory_GetForNextOperation_out strLot_requiredCassetteCategory_GetForNextOperation_out;
//D4000184            rc = lot_requiredCassetteCategory_GetForNextOperation(
//D4000184                            strLot_requiredCassetteCategory_GetForNextOperation_out,
//D4000184                            strObjCommonIn,
//D4000184                            strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[0].lotID );
//D4000184
//D4000184            if ( rc != RC_OK )
//D4000184            {
//D4000184                PPT_METHODTRACE_V1("", "lot_requiredCassetteCategory_GetForNextOperation() rc != RC_OK");
//D4000184                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strLot_requiredCassetteCategory_GetForNextOperation_out.strResult;
//D4000184                return( rc );
//D4000184            }
//D4000184            CORBA::String_var nextRequiredCassetteCategory;
//D4000184            nextRequiredCassetteCategory = strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory;
//D4000184            PPT_METHODTRACE_V2("", "nextRequiredCassetteCategory =  ",nextRequiredCassetteCategory);
//D4000184            PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
//D4000184//D4000016 Add End

            /*------------------------*/
            /*   Get Empty Cassette   */
            /*------------------------*/
//D9000005            PPT_METHODTRACE_V1("", "/*---------------------------------*/");
//D9000005            PPT_METHODTRACE_V1("", "/*   cassette_FillInTxPDQ007DR()   */");
//D9000005            PPT_METHODTRACE_V1("", "/*---------------------------------*/");
//D9000005            objectIdentifier aTempOI;
//D9000005
//D9000005//D4000184//D4000016 Edit Start
//D9000005//D4000184            pptCassetteListInqResult strCassetteListInqResult;
//D9000005//D4000184            rc = txCassetteListInq( strCassetteListInqResult,
//D9000005//D4000184                                    strObjCommonIn,
//D9000005//D4000184                                    nextRequiredCassetteCategory, // const char * cassetteCategory,
//D9000005//D4000184                                    TRUE,                         // CORBA::Boolean emptyFlag,
//D9000005//D4000184                                    aTempOI,                      // const objectIdentifier& stockerID,
//D9000005//D4000184                                    aTempOI,                      // const objectIdentifier& cassetteID
//D9000005//D4000184                                    CIMFW_Durable_Available,      // const char * cassetteStatus
//D9000005//D4000184                                    10);                          // CORBA:Long maxRetrieveCount
//D9000005//D4000184//D4000016 Edit End
//D9000005
//D9000005//D4000184 start
//D9000005             objCassette_FillInTxPDQ007DR_out strCassette_FillInTxPDQ007DR_out;
//D9000005             rc = cassette_FillInTxPDQ007DR( strCassette_FillInTxPDQ007DR_out,
//D9000005                                             strObjCommonIn,
//D9000005                                             "",                         // const char * cassetteCategory,
//D9000005                                             TRUE,                       // CORBA::Boolean emptyFlag,
//D9000005                                             aTempOI,                    // const objectIdentifier& stockerID,
//D9000005                                             aTempOI,                    // const objectIdentifier& cassetteID
//D9000005                                             CIMFW_Durable_Available,    // const char * cassetteStatus
//D9000005                                             -1 );                       // CORBA:Long maxRetrieveCount
//D9000005//D4000184 end
//D9000005
//D9000005            if ( rc != RC_OK )
//D9000005            {
//D9000005                PPT_METHODTRACE_V1("", "##### RC_OK != cassette_FillInTxPDQ007DR()");
//D9000005                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strCassette_FillInTxPDQ007DR_out.strResult;
//D9000005                return( rc );
//D9000005            }
//DSIV00000099//D9000005 add start
//DSIV00000099            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSIV00000099            PPT_METHODTRACE_V1("", "/*   cassette_ListGetDR__090()   */");
//DSIV00000099            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSIV00000099            objCassette_ListGetDR_in__090  strCassette_ListGetDR_in;
//DSIV00000099            strCassette_ListGetDR_in.emptyFlag                  = TRUE;
//DSIV00000099            strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);
//DSIV00000099            strCassette_ListGetDR_in.maxRetrieveCount           = -1;
//DSIV00000099            strCassette_ListGetDR_in.sorterJobCreationCheckFlag = FALSE;
//DSIV00000099
//DSIV00000099            objCassette_ListGetDR_out__090 strCassette_ListGetDR_out;
//DSIV00000099            rc = cassette_ListGetDR__090( strCassette_ListGetDR_out,
//DSIV00000099                                          strObjCommonIn,
//DSIV00000099                                          strCassette_ListGetDR_in );
//DSIV00000099            if ( rc != RC_OK )
//DSIV00000099            {
//DSIV00000099                PPT_METHODTRACE_V1("", "cassette_ListGetDR__090() rc != RC_OK");
//DSIV00000099                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strCassette_ListGetDR_out.strResult ;
//DSIV00000099                return( rc );
//DSIV00000099            }
//DSIV00000099
//DSIV00000099            PPTConvert convFoundCast(strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette);
//DSIV00000099            pptFoundCassetteSequence strFoundCassette = convFoundCast;
//DSIV00000099//D9000005 add end
//DSIV00000099 add start
            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSN000096126            PPT_METHODTRACE_V1("", "/*   cassette_ListGetDR__100()   */");
            PPT_METHODTRACE_V1("", "/*   cassette_ListGetDR__170()   */"); //DSN000096126
            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSN000096126            objCassette_ListGetDR_in__100  strCassette_ListGetDR_in;
//DSN000101569            objCassette_ListGetDR_in__160  strCassette_ListGetDR_in; //DSN000096126
            objCassette_ListGetDR_in__170  strCassette_ListGetDR_in;                                                            //DSN000101569
            strCassette_ListGetDR_in.emptyFlag                  = TRUE;
            strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);
            strCassette_ListGetDR_in.maxRetrieveCount           = -1;
            strCassette_ListGetDR_in.sorterJobCreationCheckFlag = FALSE;
            objectIdentifier dummyID;                                      //DSN000096126
            dummyID.identifier = CIMFWStrDup("");                          //DSN000096126
            strCassette_ListGetDR_in.bankID                     = dummyID; //DSN000096126
            strCassette_ListGetDR_in.durableSubStatus           = dummyID;                                                      //DSN000101569
            strCassette_ListGetDR_in.flowStatus                 = CIMFWStrDup("");                                              //DSN000101569
//DSN000096126            objCassette_ListGetDR_out__100 strCassette_ListGetDR_out;
//DSN000096126            rc = cassette_ListGetDR__100( strCassette_ListGetDR_out,
//DSN000096126                                          strObjCommonIn,
//DSN000096126                                          strCassette_ListGetDR_in );
//DSN000101569            objCassette_ListGetDR_out__160 strCassette_ListGetDR_out; //DSN000096126
//DSN000101569            rc = cassette_ListGetDR__160(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in); //DSN000096126
            objCassette_ListGetDR_out__170 strCassette_ListGetDR_out;                                                           //DSN000101569
            rc = cassette_ListGetDR__170(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);                  //DSN000101569
            if ( rc != RC_OK )
            {
//DSN000096126                PPT_METHODTRACE_V2("", "cassette_ListGetDR__100() != RC_OK", rc);
                PPT_METHODTRACE_V2("", "cassette_ListGetDR__170() != RC_OK", rc); //DSN000096126
                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strCassette_ListGetDR_out.strResult ;
                return( rc );
            }

            pptFoundCassetteSequence strFoundCassette;
            PPTConverter converter;
//DSN000096126            converter.Convert100_to_080( strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette, strFoundCassette );
//DSN000101569            converter.Convert160_to_080( strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette, strFoundCassette ); //DSN000096126
            converter.Convert170_to_080(strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette, strFoundCassette); //DSN000101569
//DSIV00000099 add end
            /*-----------------------------------*/
            /*   Pick Up Target Empty Cassette   */
            /*-----------------------------------*/
            PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   cassetteList_emptyAvailable_Pickup()   */");
            PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
            rc = cassetteList_emptyAvailable_Pickup( strCassetteList_emptyAvailable_Pickup_out,
                                                     strObjCommonIn,
//D9000005                                           strCassette_FillInTxPDQ007DR_out.strCassetteListInqResult.strFoundCassette);  // Send to Node of equipmentID.
                                                     strFoundCassette);  // Send to Node of equipmentID.    //D9000005

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### RC_OK != cassetteList_emptyAvailable_Pickup()");
                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strCassetteList_emptyAvailable_Pickup_out.strResult;
                return( rc );
            }

//D4000184            nCanBeUsedEmptyCassetteCount = strCassetteList_emptyAvailable_Pickup_out.strFoundCassette.length();
//D4000184            PPT_METHODTRACE_V2("", "Found Empty Cassette Count", nCanBeUsedEmptyCassetteCount);
//D4000184
//D4000184            if ( strEquipment_shelfSpaceForInternalBuffer_Get_out.emptyCassetteSpace < nCanBeUsedEmptyCassetteCount )
//D4000184            {
//D4000184                PPT_METHODTRACE_V1("", "shelfSpace.emptyCassetteSpace < nCanBeUsedEmptyCassetteCount");
//D4000184                PPT_METHODTRACE_V1("", "nCanBeUsedEmptyCassetteCount <--- shelfSpace.emptyCassetteSpace");
//D4000184                nCanBeUsedEmptyCassetteCount = strEquipment_shelfSpaceForInternalBuffer_Get_out.emptyCassetteSpace;
//D4000184            }

//D4000184 start
            nShelfSpaceOfEmptyCassette = strEquipment_shelfSpaceForInternalBuffer_Get_out.emptyCassetteSpace;
            PPT_METHODTRACE_V2("", "nShelfSpaceOfEmptyCassette", nShelfSpaceOfEmptyCassette);
            useEmptyCassetteIDSeq.length( nShelfSpaceOfEmptyCassette );
//P5000047            useAssignEmptyCassettePortSeq.length( nCanBeUsedPortCount );
            useAssignEmptyCassettePortSeq.length( nShelfSpaceOfEmptyCassette );  //P5000047
//D4000184 end
        }               //P4000015 0.02
        else
        {
            PPT_METHODTRACE_V1("","EmptyCassette is unnecessary");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


        /*-------------------------------------------*/
        /*   Get Equipment's MultiRecipeCapability   */
        /*-------------------------------------------*/
        PPT_METHODTRACE_V1("", "/*-------------------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Get Equipment's MultiRecipeCapability   */");
        PPT_METHODTRACE_V1("", "/*-------------------------------------------*/");
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         equipmentID,
                                         strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                         whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq);

        CORBA::String_var multiRecipeCapability;
        try
        {
            multiRecipeCapability = aMachine->getMultipleRecipeCapability();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getMultipleRecipeCapability);
        PPT_METHODTRACE_V2("", "aMachine->getMultipleRecipeCapability", multiRecipeCapability);

        //D7000074 if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_MultipleRecipe) )
        //D7000074 {
        //D7000074     PPT_METHODTRACE_V1("","##### return RC_CAST_EQP_CONDITION_ERROR!!");
        //D7000074     SET_MSG_RC( strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
        //D7000074                 MSG_CAST_EQP_CONDITION_ERROR,
        //D7000074                 RC_CAST_EQP_CONDITION_ERROR );
        //D7000074     return RC_CAST_EQP_CONDITION_ERROR;
        //D7000074 }

//D4000015        /*--------------------------*/
//D4000015        /*   Get PortID List        */
//D4000015        /*--------------------------*/
//D4000015        objectIdentifierSequence portID;
//D4000015        longSequence loadSequenceNumber;
//D4000015        stringSequence loadPurposeType;
//D4000015
//D4000015        CORBA::Long PortCount = 0;
//D4000015        CORBA::Long nPortGrpLen = strPortGroup.length();
//D4000015        PPT_METHODTRACE_V2("", "strPortGroup.length() =",nPortGrpLen);
//D4000015        for ( i=0; i<nPortGrpLen; i++ )
//D4000015        {
//D4000015            CORBA::Long nPortLen = strPortGroup[i].strPortID.length();
//D4000015            PPT_METHODTRACE_V2("", "strPortGroup[i].strPortID.lenght() =",nPortLen);
//D4000015            for ( j=0; j<nPortLen; j++ )
//D4000015            {
//D4000015                if (CIMFWStrCmp(strPortGroup[i].strPortID[j].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
//D4000015                {
//D4000015                    continue;
//D4000015                }
//D4000015                portID.length(PortCount+1);
//D4000015                portID[PortCount] =  strPortGroup[i].strPortID[j].portID;
//D4000015                loadSequenceNumber.length(PortCount+1);
//D4000015                loadSequenceNumber[PortCount] = strPortGroup[i].strPortID[j].loadSequenceNoInPortGroup;
//D4000015                loadPurposeType.length(PortCount+1);
//D4000015                loadPurposeType[PortCount] = CIMFWStrDup(strPortGroup[i].strPortID[j].loadPurposeType);
//D4000015
//D4000015                PPT_METHODTRACE_V4("","PortCount:portID:loadSequenceNumber",PortCount,portID[PortCount].identifier,loadSequenceNumber[PortCount]);
//D4000015                PortCount++;
//D4000015            }
//D4000015        }

        /*------------------------------------------*/
        /*   Get Check Equipment's ProcessRunSize   */
        /*------------------------------------------*/
        PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Get Check Equipment's ProcessRunSize   */");
        PPT_METHODTRACE_V1("", "/*------------------------------------------*/");

        CORBA::Long processRunCount = 0;
        CORBA::Long processRunSizeMaximum = strWhatNextLotListForInternalBufferInqResult.processRunSizeMaximum;
        PPT_METHODTRACE_V2("","processRunSizeMaximum", processRunSizeMaximum);

        if ( processRunSizeMaximum > strEquipment_shelfSpaceForInternalBuffer_Get_out.processLotSpace )
        {
            PPT_METHODTRACE_V1("", "processRunSizeMaximum > strEquipment_shelfSpaceForInternalBuffer_Get_out.processLotSpace");
            processRunSizeMaximum = strEquipment_shelfSpaceForInternalBuffer_Get_out.processLotSpace;
            PPT_METHODTRACE_V2("","@@@@@@@@@@ change!! processRunSizeMaximum", processRunSizeMaximum);
        }

        if ( 0 == processRunSizeMaximum )
        {
            PPT_METHODTRACE_V1("", "##### 0 == processRunSizeMaximum" );
            PPT_SET_MSG_RC_KEY( strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                MSG_NOT_SPACE_EQP_SELF,
                                RC_NOT_SPACE_EQP_SELF,
                                SP_LoadPurposeType_ProcessLot );
            return RC_NOT_SPACE_EQP_SELF;
        }

        CORBA::Long attrLen = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes.length();
        PPT_METHODTRACE_V2("","strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes.length()", attrLen);

        if( 0 == attrLen )
        {
            PPT_METHODTRACE_V1("","0 == strWhatNextAttributes.length");
            SET_MSG_RC( strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                        MSG_NOT_FOUND_FILLEDCAST,
                        RC_NOT_FOUND_FILLEDCAST );
            return RC_NOT_FOUND_FILLEDCAST;
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

//D4100036 start  <<< FlowBatch Control >>>
        /**********************************************************************/
        /*                                                                    */
        /*   Get and Check FlowBatch Info                                     */
        /*                                                                    */
        /**********************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Get and Check FlowBatch Info");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        PPT_METHODTRACE_V1("", "call flowBatch_CheckConditionForCassetteDelivery()");
        pptWhatNextLotListInqResult  strWhatNextLotListInqResult = strWhatNextLotListForInternalBufferInqResult;
        objFlowBatch_CheckConditionForCassetteDelivery_out   strFlowBatch_CheckConditionForCassetteDelivery_out;
        rc = flowBatch_CheckConditionForCassetteDelivery( strFlowBatch_CheckConditionForCassetteDelivery_out,
                                                          strObjCommonIn,
                                                          equipmentID,
                                                          strWhatNextLotListInqResult );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### RC_OK != flowBatch_CheckConditionForCassetteDelivery()");
            strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strFlowBatch_CheckConditionForCassetteDelivery_out.strResult;
            return( rc );
        }
//D4100036 end  <<< FlowBatch Control >>>


        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Make strStartCassette Process                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  make strStartCassette Process                                           */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        pptStartCassetteSequence  strStartCassette;

//D7000183 start
        CORBA::Boolean bCheckMinBatchSize = FALSE;
        CORBA::String_var checkMinBatchSize = CIMFWStrDup(getenv(SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY));
        PPT_METHODTRACE_V2("","SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY ---> ", checkMinBatchSize);
        if ( 0 == CIMFWStrCmp(checkMinBatchSize, "1") && 1 < strEquipment_processBatchCondition_Get_out.minBatchSize )
        {
            PPT_METHODTRACE_V1("","bCheckMinBatchSize is 1");
            bCheckMinBatchSize = TRUE;
        }

        CORBA::Long nEmptyShelfCnt = nShelfSpaceOfEmptyCassette;
        CORBA::Boolean bShortOfEmptyCassette = FALSE;

        objectIdentifierSequence omitCassetteSeq;
        omitCassetteSeq.length(0);

        while ( 1 ) // MinBatchSize support loop.
        {
            // Reset variable.
            processRunCount = 0;
            nAssignEmptyCassetteCnt = 0;
            nShelfSpaceOfEmptyCassette = nEmptyShelfCnt;
            useEmptyCassetteIDSeq.length( nEmptyShelfCnt );
            useAssignEmptyCassettePortSeq.length( nEmptyShelfCnt );
//D7000183 end

            strStartCassette.length( (processRunSizeMaximum * 2) + 1 );

            CORBA::String_var multiLotType;
            CORBA::Long startNo = 0;
            CORBA::Boolean bWhileExitFlag = FALSE;
            objectIdentifier baseLogicalRecipeID;
            objectIdentifier baseMachineRecipeID;
            objectIdentifier tmpBaseLogicalRecipeID;
            objectIdentifier tmpBaseMachineRecipeID;
            CORBA::Boolean bAlreadyCheckMonitorCreationFlag = FALSE;
//D7000183        CORBA::Boolean bShortOfEmptyCassette = FALSE;
            bShortOfEmptyCassette = FALSE; //D7000183

            while ( processRunCount < processRunSizeMaximum )
            {
                PPT_METHODTRACE_V1("","");
                PPT_METHODTRACE_V1("","while ( processRunCount < processRunSizeMaximum ) --------------------------");
                PPT_METHODTRACE_V2("", "processRunCount =", processRunCount);

                if ( bWhileExitFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("","bWhileExitFlag == TRUE    break!!");
                    break;
                }

                CORBA::Boolean bTmpBaseRecipeFlag = FALSE;      // Temporary Base Recipe Flag

                pptStartCassetteSequence  tmpStartCassette;
                tmpStartCassette.length(0);

                /**********************************************************************************/
                /*                                                                                */
                /*   Set Cassette Info                                                            */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set Cassette Info");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                for ( i=startNo; i < attrLen; i++ )
                {
                    PPT_METHODTRACE_V2("","for-loop counter--------------------------------------[i]",i);

                    PPT_METHODTRACE_V1("","Entry WhatNextData=====================================");
                    PPT_METHODTRACE_V2("","lotID...........................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID.identifier);
                    PPT_METHODTRACE_V2("","cassetteID......................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteID.identifier);
                    PPT_METHODTRACE_V2("","lotType.........................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotType);
                    PPT_METHODTRACE_V2("","multiLotType....................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].multiLotType);
                    PPT_METHODTRACE_V2("","transferStatus..................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].transferStatus);
                    PPT_METHODTRACE_V2("","stockerID.......................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].stockerID.identifier);
                    PPT_METHODTRACE_V2("","logicalRecipeID.................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].logicalRecipeID.identifier);
                    PPT_METHODTRACE_V2("","machineRecipeID.................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].machineRecipeID.identifier);
                    PPT_METHODTRACE_V2("","totalWaferCount.................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].totalWaferCount);
                    PPT_METHODTRACE_V2("","requiredCassetteCategory........", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].requiredCassetteCategory);
                    PPT_METHODTRACE_V2("","cassetteCategory................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteCategory);
                    PPT_METHODTRACE_V2("","next2requiredCassetteCategory...", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].next2requiredCassetteCategory);
                    PPT_METHODTRACE_V2("","routeID.........................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].routeID.identifier); //P7000106
                    PPT_METHODTRACE_V2("","operationID.....................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].operationID.identifier); //P7000106
                    PPT_METHODTRACE_V2("","operationNumber.................", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].operationNumber); //P7000106
                    PPT_METHODTRACE_V1("","=======================================================");

                    /*-----------------------------*/
                    /*   Omit CassetteID is NULL   */
                    /*-----------------------------*/
                    if ( 0 == CIMFWStrLen(strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteID.identifier) )
                    {
                        PPT_METHODTRACE_V1("","cassetteID is NULL  ...<<<continue>>>");
                        continue;
                    }

//D7000183 start
                    CORBA::Boolean bOmitCassette = FALSE;
                    CORBA::Long lenOmitCst = omitCassetteSeq.length();
                    for ( CORBA::Long m=0; m < lenOmitCst; m++ )
                    {
                        if ( 0 == CIMFWStrCmp(omitCassetteSeq[m].identifier,
                                              strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteID.identifier) )
                        {
                            bOmitCassette = TRUE;
                            break;
                        }
                    }
                    if ( bOmitCassette )
                    {
                        PPT_METHODTRACE_V1("","Omit CassetteID   ..<<continue>>");
                        continue; // [i]
                    }
//D7000183 end

                    /*------------------------------------------*/
                    /*   Omit already saved strStartCassette    */
                    /*------------------------------------------*/
                    CORBA::Boolean bFoundFlag = FALSE;
                    for ( j=0; j < processRunCount; j++ )
                    {
                        if ( 0 == CIMFWStrCmp(strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteID.identifier,
                                              strStartCassette[j].cassetteID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","strWhatNextAttributes[i].cassetteID == strStartCassette[j].cassetteID  ...<<<continue>>>");
                            bFoundFlag = TRUE;
                            break;
                        }
                    }
                    if ( bFoundFlag == TRUE )
                    {
                        PPT_METHODTRACE_V2("","already saved strStartCassette  ...<<<continue>>>", strStartCassette[j].cassetteID.identifier);
                        continue;
                    }

                    if ( tmpStartCassette.length() != 0 )
                    {
                        if ( 0 != CIMFWStrCmp(strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteID.identifier,
                                              tmpStartCassette[0].cassetteID.identifier) )
                        {
                            startNo = i;
                            PPT_METHODTRACE_V2("","Next for-loop StartNo.=", startNo);
                            break;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","strWhatNextAttributes[i].cassetteID == tmpStartCassette[0].cassetteID  ...<<<continue>>>");
                            continue;
                        }
                    }

    //D4100036 start  <<< FlowBatch Control >>>
                    /*---------------------------------------------------------------------*/
                    /*   Omit Lot which is not FlowBatchingLots in the case of FlowBatch   */
                    /*---------------------------------------------------------------------*/
                    if ( 0 < CIMFWStrLen(strFlowBatch_CheckConditionForCassetteDelivery_out.flowBatchID.identifier) )
                    {
                        PPT_METHODTRACE_V1("","Omit Lot which is not FlowBatchingLots in the case of FlowBatch");
                        CORBA::Boolean bFound = FALSE;
                        CORBA::Long lenFlowBatchLots = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch.length();
                        for ( j=0; j < lenFlowBatchLots; j++ )
                        {
                            if ( 0 == CIMFWStrCmp(strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID.identifier,
                                                  strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[j].lotID.identifier) )
                            {
                                bFound = TRUE;
                                break; // [j]
                            }
                        } //end of [j]
                        if ( FALSE == bFound )
                        {
                            PPT_METHODTRACE_V1("","LotID is not FlowBatchingLots   ..<<continue>>");
                            continue; // [i]
                        }

                        PPT_METHODTRACE_V2("","Lot is FlowBatching Lot!!", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID.identifier);
                    }
    //D4100036 end  <<< FlowBatch Control >>>

//DSN000081739 Add Start
                    //----------------------------------------------------------------------------------------
                    //   Omit lot if "Monitor" label is put on lot's process and the lot doesn't have EqpMonitor job
                    //----------------------------------------------------------------------------------------
                    if ( 0 == CIMFWStrCmp( getenv(SP_EQPMONITOR_SWITCH), "1" ) )
                    {
                        PPT_METHODTRACE_V1("","SP_EQPMONITOR_SWITCH is 1");

                        //Check Lot type
                        objLot_lotType_Get_out strLot_lotType_Get_out;
                        objLot_lotType_Get_in  strLot_lotType_Get_in;
                        strLot_lotType_Get_in.lotID = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID;
                        rc = lot_lotType_Get(strLot_lotType_Get_out,strObjCommonIn,strLot_lotType_Get_in);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
                            strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strLot_lotType_Get_out.strResult;
                            return (rc);
                        }
                        if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
                          || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot))
                        {
                            PPT_METHODTRACE_V1("","lotType is Equipment Monitor or Dummy.");
                            objLot_eqpMonitorOperationLabel_Get_out strLot_eqpMonitorOperationLabel_Get_out;
                            objLot_eqpMonitorOperationLabel_Get_in  strLot_eqpMonitorOperationLabel_Get_in;
                            strLot_eqpMonitorOperationLabel_Get_in.lotID = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID;
                            rc = lot_eqpMonitorOperationLabel_Get( strLot_eqpMonitorOperationLabel_Get_out,
                                                                   strObjCommonIn,
                                                                   strLot_eqpMonitorOperationLabel_Get_in );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "lot_eqpMonitorOperationLabel_Get() != RC_OK", rc);
                                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strLot_eqpMonitorOperationLabel_Get_out.strResult;
                                return (rc);
                            }
                            CORBA::Boolean bMonitorLabel = FALSE;
                            for ( CORBA::ULong x=0; x<strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq.length(); x++ )
                            {
                                PPT_METHODTRACE_V2("","Loop through strEqpMonitorLabelInfoSeq",x);
                                if( 0 == CIMFWStrCmp(strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq[x].operationLabel,SP_EqpMonitor_OpeLabel_Monitor) )
                                {
                                    PPT_METHODTRACE_V1("","Found Monitor label.");
                                    bMonitorLabel = TRUE;
                                    break;
                                }
                            }

                            if ( TRUE == bMonitorLabel )
                            {
                                PPT_METHODTRACE_V1("","bMonitorLabel is TRUE.");
                                objLot_eqpMonitorJob_Get_out strLot_eqpMonitorJob_Get_out;
                                objLot_eqpMonitorJob_Get_in  strLot_eqpMonitorJob_Get_in;
                                strLot_eqpMonitorJob_Get_in.lotID = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID;
                                rc = lot_eqpMonitorJob_Get(strLot_eqpMonitorJob_Get_out,strObjCommonIn,strLot_eqpMonitorJob_Get_in);
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "lot_eqpMonitorJob_Get() rc != RC_OK", rc);
                                    strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strLot_eqpMonitorJob_Get_out.strResult;
                                    return rc;
                                }

                                if( 0 == CIMFWStrLen(strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.eqpMonitorJobID.identifier))
                                {
                                    PPT_METHODTRACE_V1("", "eqpMonitorJobID is not attached to lot");
                                    continue;
                                }

                                PosLot_var aPosLot;
                                PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID,strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq);
                                PosProcessOperation_var aPosPO;
                                try
                                {
                                    ProcessOperation_var aPO = aPosLot->getProcessOperation();
                                    aPosPO = PosProcessOperation::_narrow(aPO);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);
                                if( CORBA::is_nil(aPosPO) )
                                {
                                    PPT_METHODTRACE_V1("", "aPosPO is nill");
                                    PPT_SET_MSG_RC_KEY2( strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                                         MSG_NOT_FOUND_PO,
                                                         RC_NOT_FOUND_PO,
                                                         "",
                                                         strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID.identifier );
                                    return RC_NOT_FOUND_PO;
                                }

                                CORBA::String_var strOPNumber;
                                try
                                {
                                    strOPNumber = aPosPO->getOperationNumber();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber);
                                PosProcessFlowContext_var aPFX ;
                                try
                                {
                                    aPFX = aPosLot->getProcessFlowContext() ;
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);
                                if ( CORBA::is_nil(aPFX) == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "CORBA::is_nil(aPFX)")

                                    PPT_SET_MSG_RC_KEY(strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                                       MSG_NOT_FOUND_PFX,
                                                       RC_NOT_FOUND_PFX,
                                                       "");

                                    return( RC_NOT_FOUND_PFX );
                                }

                                CORBA::String_var strEqpMonitorKey;
                                try
                                {
                                    strEqpMonitorKey = aPFX->getEqpMonOperationKey(strOPNumber);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getEqpMonOperationKey);

                                if( 0 != CIMFWStrCmp(strEqpMonitorKey, strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.monitorOpeKey))
                                {
                                    //The EqpMonitor job is for another Monitor process
                                    PPT_METHODTRACE_V1("","EqpMonitorKey is not same.");
                                    continue;
                                }
                                else
                                {
                                    // Check OK
                                    PPT_METHODTRACE_V1("","EqpMonitorKey is same.");
                                }
                            }
                        }
                    }
//DSN000081739 Add End

    //D4000227 start
                    /*----------------------------------------------------*/
                    /*   Check Stocker which Lot belongs to, Available?   */
                    /*----------------------------------------------------*/
                    PPT_METHODTRACE_V2("","Call equipment_CheckAvail()   stockerID --->", strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].stockerID.identifier);
                    objEquipment_CheckAvail_out   strEquipment_CheckAvail_out;
                    rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn,
                                                    strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].stockerID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","RC_OK != equipment_CheckAvail()   ..<<continue>>", strEquipment_CheckAvail_out.strResult.returnCode);
                        continue; //[i]
                    }
    //D4000227 end

    //P4100010 start
                    /*-------------------------------------------------------------------------------*/
                    /*   Check Category for Copper/Non Copper                                        */
                    /*                                                                               */
                    /*   (*) Because it is all same, CarrierCategory of Port set the first PortID.   */
                    /*-------------------------------------------------------------------------------*/
                    PPT_METHODTRACE_V1("","Check Category for Copper/Non Copper");
                    objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
                    rc = lot_CassetteCategory_CheckForContaminationControl(
                                                strLot_CassetteCategory_CheckForContaminationControl_out,
                                                strObjCommonIn,
                                                strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotID,
                                                strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteID,
                                                equipmentID,
                                                strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[0].portID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","UnMatch CarrierCategory (Copper/NonCopper)   ..<<continue>>", rc);
                        continue; //[i]
                    }
    //P4100010 end

    //D51M0007 start
                    /*-----------------------*/
                    /*   Check Scrap Wafer   */
                    /*-----------------------*/
                    objectIdentifierSequence cassetteIDs;
                    cassetteIDs.length(1);
                    cassetteIDs[0] = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteID;

                    PPT_METHODTRACE_V1("", "call cassette_scrapWafer_SelectDR()");
                    objCassette_scrapWafer_SelectDR_out strCassette_scrapWafer_SelectDR_out;
                    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out, strObjCommonIn, cassetteIDs );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### cassette_scrapWafer_SelectDR() != RC_OK", rc);
                        strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
                        return(rc);
                    }
                    CORBA::Long nScrapCnt = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
                    PPT_METHODTRACE_V2("", "nScrapCnt", nScrapCnt);
                    if ( 0 < nScrapCnt )
                    {
                        PPT_METHODTRACE_V1("","Cassette has ScrapWafer ..<<continue>>");
                        continue; //[i]
                    }
    //D51M0007 end

//DSN000020767 Add Start
//DSN000096126                    objCassette_DBInfo_GetDR_out__120 strCassette_DBInfo_GetDR_out;
//DSN000096126                    objCassette_DBInfo_GetDR_in__100 strCassette_DBInfo_GetDR_in;
//DSN000096126                    strCassette_DBInfo_GetDR_in.cassetteID = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;
//DSN000096126
//DSN000096126                    rc = cassette_DBInfo_GetDR__120( strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in );
//DSN000096126                    if ( rc != RC_OK )
//DSN000096126                    {
//DSN000096126                        PPT_METHODTRACE_V2("", "cassette_DBInfo_GetDR__120() != RC_OK",rc);
//DSN000096126                        strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strCassette_DBInfo_GetDR_out.strResult ;
//DSN000096126                        return( rc );
//DSN000096126                    }
//DSN000096126 Add Start
//DSN000101569                    objCassette_DBInfo_GetDR_out__160  strCassette_DBInfo_GetDR_out;
                    objCassette_DBInfo_GetDR_out__170  strCassette_DBInfo_GetDR_out;                                            //DSN000101569
                    objCassette_DBInfo_GetDR_in__160   strCassette_DBInfo_GetDR_in;
                    strCassette_DBInfo_GetDR_in.cassetteID                  = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;
                    strCassette_DBInfo_GetDR_in.durableOperationInfoFlag    = FALSE;
                    strCassette_DBInfo_GetDR_in.durableWipOperationInfoFlag = FALSE;
//DSN000101569                    rc = cassette_DBInfo_GetDR__160(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);
                    rc = cassette_DBInfo_GetDR__170(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in); //DSN000101569
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cassette_DBInfo_GetDR__170() != RC_OK",rc);
                        strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strCassette_DBInfo_GetDR_out.strResult;
                        return rc;
                    }
//DSN000096126 Add End

                    CORBA::Long lotLen = 0;
                    CORBA::Long lotCnt = 0;
                    CORBA::Boolean bCastDispatchDisableFlag = FALSE;
                    lotLen = strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteStatusInfo.strContainedLotInfo.length();
                    for( lotCnt = 0; lotCnt < lotLen; lotCnt++ )
                    {
                        if( strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteStatusInfo.strContainedLotInfo[lotCnt].autoDispatchDisableFlag == TRUE )
                        {
                            bCastDispatchDisableFlag = TRUE;
                            break;
                        }
                    }

                    if( bCastDispatchDisableFlag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "##### Cassette Auto Dispatch Disable Flag == TRUE ..<<continue>>");
                        continue; //[i]
                    }
//DSN000020767 Add End

                    tmpStartCassette.length(1);
                    tmpStartCassette[0].cassetteID = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].cassetteID;

                    PPT_METHODTRACE_V2("","Candidate CassetteID--->", tmpStartCassette[0].cassetteID.identifier);

                    /*-------------------------------*/
                    /*   Set Temporary Base Recipe   */
                    /*-------------------------------*/
                    PPT_METHODTRACE_V1("","===== Set Temporary Base Recipe ===============");
                    if ( processRunCount == 0 )
                    {
                        PPT_METHODTRACE_V1("","processRunCount == 0");
                        if ( bTmpBaseRecipeFlag == FALSE )
                        {
                            // Temporary Base Recipe
                            PPT_METHODTRACE_V1("","bTmpBaseRecipeFlag == FALSE");
                            tmpBaseLogicalRecipeID = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].logicalRecipeID;
                            tmpBaseMachineRecipeID = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].machineRecipeID;
                            bTmpBaseRecipeFlag = TRUE;

                            PPT_METHODTRACE_V2("","  tmpBaseLogicalRecipeID <---", tmpBaseLogicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","  tmpBaseMachineRecipeID <---", tmpBaseMachineRecipeID.identifier);
                        }
                    }
                    PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

                    /*-------------------*/
                    /*   Set Port Info   */
                    /*-------------------*/
                    PPT_METHODTRACE_V1("","===== Set Port Info ==================");
                    tmpStartCassette[0].loadSequenceNumber = 1;

    //P4100019                if ( 0 == CIMFWStrCmp(strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[i].lotType, SP_Lot_Type_ProductionMonitorLot) )
    //P4100019                {
    //P4100019                    PPT_METHODTRACE_V1("","LotType == ProcessMonitorLot");
    //P4100019                    tmpStartCassette[0].loadPurposeType = CIMFWStrDup(SP_LoadPurposeType_ProcessMonitorLot);
    //P4100019                }
    //P4100019                else
    //P4100019                {
    //P4100019                    PPT_METHODTRACE_V1("","LotType == ProcessLot");
                        tmpStartCassette[0].loadPurposeType = CIMFWStrDup( SP_LoadPurposeType_ProcessLot );
    //P4100019                }

                    tmpStartCassette[0].loadPortID = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[0].portID;

    //D4000015                tmpStartCassette[0].loadSequenceNumber = loadSequenceNumber[processRunCount];
    //D4000015                tmpStartCassette[0].loadPurposeType    = CIMFWStrDup(loadPurposeType[processRunCount]);
    //D4000015                tmpStartCassette[0].loadPortID         = portID[processRunCount];

    //D4000015                bFoundFlag = FALSE;
    //D4000015                for ( j=0; j < nPortGrpLen; j++ )
    //D4000015                {
    //D4000015                    CORBA::Long nPortLen = strPortGroup[j].strPortID.length();
    //D4000015                    for ( k=0; k < nPortLen; k++ )
    //D4000015                    {
    //D4000015                        if (CIMFWStrCmp(tmpStartCassette[0].loadPortID.identifier, strPortGroup[j].strPortID[k].portID.identifier) == 0)
    //D4000015                        {
    //D4000015                            portGroupID = CIMFWStrDup(strPortGroup[j].portGroup);
    //D4000015                            bFoundFlag = TRUE;
    //D4000015                            break;
    //D4000015                        }
    //D4000015                    }
    //D4000015                    if (bFoundFlag == TRUE)
    //D4000015                    {
    //D4000015                        break;
    //D4000015                    }
    //D4000015                }
                    PPT_METHODTRACE_V2("","cassetteID         = ", tmpStartCassette[0].cassetteID.identifier);
                    PPT_METHODTRACE_V2("","loadSequenceNumber = ", tmpStartCassette[0].loadSequenceNumber);
                    PPT_METHODTRACE_V2("","loadPurposeType    = ", tmpStartCassette[0].loadPurposeType);
                    PPT_METHODTRACE_V2("","loadPortID         = ", tmpStartCassette[0].loadPortID.identifier);
    //D4000015                PPT_METHODTRACE_V2("","portGroupID        = ", portGroupID);

                    /*-----------------------------------*/
                    /*   Get Contained Lot in Cassette   */
                    /*-----------------------------------*/
                    PPT_METHODTRACE_V2("","===== cassette_GetLotList() ==================", tmpStartCassette[0].cassetteID.identifier);
                    objCassette_GetLotList_out strCassette_GetLotList_out;
                    rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, tmpStartCassette[0].cassetteID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK  ...<<<continue>>>", rc);
                        continue;
                    }

                    CORBA::Long nLotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
                    tmpStartCassette[0].strLotInCassette.length(nLotLen);

                    PPT_METHODTRACE_V2("","LotLen", nLotLen);
                    for ( j=0; j < nLotLen; j++ )
                    {
                        tmpStartCassette[0].strLotInCassette[j].recipeParameterChangeType = CIMFWStrDup(SP_Rparm_ChangeType_ByLot);
                        tmpStartCassette[0].strLotInCassette[j].operationStartFlag = TRUE;
                        tmpStartCassette[0].strLotInCassette[j].lotID = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[j];
    //P4100019                    if ( 0 == CIMFWStrCmp(tmpStartCassette[0].loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot ) )
    //P4100019                    {
    //P4100019                        PPT_METHODTRACE_V1("","tmpStartCassette[0].loadPurposeType == SP_LoadPurposeType_ProcessMonitorLot");
    //P4100019
    //P4100019                        /*------------------*/
    //P4100019                        /*   Get Lot Type   */
    //P4100019                        /*------------------*/
    //P4100019                        PPT_METHODTRACE_V2("","===== lot_type_Get() ==================", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
    //P4100019                        objLot_type_Get_out strLot_type_Get_out;
    //P4100019                        rc = lot_type_Get( strLot_type_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
    //P4100019                        if ( rc != RC_OK )
    //P4100019                        {
    //P4100019                            PPT_METHODTRACE_V2("", "lot_type_Get() != RC_OK  ...<<<continue>>>", rc);
    //P4100019                            continue;
    //P4100019                        }
    //P4100019                        if (CIMFWStrCmp(strLot_type_Get_out.theLotType, SP_Lot_Type_ProductionMonitorLot ) == 0)
    //P4100019                        {
    //P4100019                            PPT_METHODTRACE_V1("","theLotType == [ProductionMonitorLot]");
    //P4100019                            tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = TRUE;
    //P4100019                        }
    //P4100019                        else
    //P4100019                        {
    //P4100019                            PPT_METHODTRACE_V1("","theLotType != [ProductionMonitorLot]");
    //P4100019                            tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = FALSE;
    //P4100019                        }
    //P4100019                    }
    //P4100019                    else
    //P4100019                    {
    //P4100019                        PPT_METHODTRACE_V1("","tmpStartCassette[0].loadPurposeType != SP_LoadPurposeType_ProcessMonitorLot");
                            tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = FALSE;
    //P4100019                    }

                        PPT_METHODTRACE_V3("","tmpStartCassette[0].strLotInCassette[j].lotID", j, tmpStartCassette[0].strLotInCassette[j].lotID.identifier);

    //P4200137 start
                        PosLot_var aLot;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot, tmpStartCassette[0].strLotInCassette[j].lotID,
                                                     strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                                     whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq );
                        try
                        {
                            tmpStartCassette[0].strLotInCassette[j].lotType = aLot->getLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)
                        PPT_METHODTRACE_V2("", "lotType", tmpStartCassette[0].strLotInCassette[j].lotType);

                        try
                        {
                            tmpStartCassette[0].strLotInCassette[j].subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType)
                        PPT_METHODTRACE_V2("", "subLotType", tmpStartCassette[0].strLotInCassette[j].subLotType);

                        objLot_productID_Get_out  strLot_productID_Get_out;
                        rc = lot_productID_Get( strLot_productID_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "##### lot_productID_Get() != RC_OK")
                            strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strLot_productID_Get_out.strResult;
                            return ( rc );
                        }

                        tmpStartCassette[0].strLotInCassette[j].productID = strLot_productID_Get_out.productID;
                        PPT_METHODTRACE_V2("", "productID", tmpStartCassette[0].strLotInCassette[j].productID.identifier);
    //P4200137 end

    //P7000106 start
                        /*------------------------*/
                        /*   Set Operation Info   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1("", "Set Operation Info")
                        for ( CORBA::Long m=0; m < attrLen; m++ )
                        {
                            if ( 0 == CIMFWStrCmp(tmpStartCassette[0].strLotInCassette[j].lotID.identifier,
                                                  strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[m].lotID.identifier) )
                            {
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.routeID         = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[m].routeID;
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationID     = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[m].operationID;
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationNumber = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[m].operationNumber;

                                PPT_METHODTRACE_V2("", "lotID          ", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
                                PPT_METHODTRACE_V2("", "routeID        ", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.routeID.identifier);
                                PPT_METHODTRACE_V2("", "operationID    ", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationID.identifier);
                                PPT_METHODTRACE_V2("", "operationNumber", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationNumber);
                                break;
                            }
                        }
    //P7000106 end

                        /*--------------------------------*/
                        /*   Get Contained Wafer in Lot   */
                        /*--------------------------------*/
                        PPT_METHODTRACE_V2("","===== lot_waferMap_Get() ==================", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
                        objLot_waferMap_Get_out strLot_waferMap_Get_out;
                        rc = lot_waferMap_Get( strLot_waferMap_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "lot_waferMap_Get() != RC_OK  ...<<<continue>>>");
                            continue;
                        }
                        CORBA::Long nWafLen = strLot_waferMap_Get_out.strLotWaferMap.length();

                        tmpStartCassette[0].strLotInCassette[j].strLotWafer.length(nWafLen);

                        for ( k=0; k < nWafLen; k++ )
                        {
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].waferID          = strLot_waferMap_Get_out.strLotWaferMap[k].waferID;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].slotNumber       = strLot_waferMap_Get_out.strLotWaferMap[k].slotNumber;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].controlWaferFlag = strLot_waferMap_Get_out.strLotWaferMap[k].controlWaferFlag;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length(0);

                            PPT_METHODTRACE_V4("","tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].waferID", j,k, tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].waferID.identifier);
                        }
                    }

    //0.03                /*-------------------------------------------*/
    //0.03                /*   Get Information for Start Reservation   */
    //0.03                /*-------------------------------------------*/
    //0.03                PPT_METHODTRACE_V1("", "process_startReserveInformation_GetBaseInfoForClient()");
    //0.03                objProcess_startReserveInformation_GetBaseInfoForClient_out strProcess_startReserveInformation_GetBaseInfoForClient_out;
    //0.03                rc = process_startReserveInformation_GetBaseInfoForClient( strProcess_startReserveInformation_GetBaseInfoForClient_out,
    //0.03                                                                           strObjCommonIn,
    //0.03                                                                           equipmentID,
    //0.03                                                                           tmpStartCassette );
    //0.03                if ( rc != RC_OK )
    //0.03                {
    //0.03                    PPT_METHODTRACE_V1("", "process_startReserveInformation_GetBaseInfoForClient() != RC_OK  ...<<<continue>>>");
    //0.03                    continue;
    //0.03                }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


                if ( i == attrLen )
                {
                    PPT_METHODTRACE_V1("","i==attLen");
                    bWhileExitFlag = TRUE;
                }
                PPT_METHODTRACE_V1("","----------------------------------------------");
                PPT_METHODTRACE_V1("","make strStartCassette Process  done.");
                PPT_METHODTRACE_V2("","CassetteID", tmpStartCassette[0].cassetteID.identifier);
                PPT_METHODTRACE_V1("","----------------------------------------------");

    //D4000227 start
                if ( 0 == CIMFWStrLen(tmpStartCassette[0].cassetteID.identifier) )
                {
                    PPT_METHODTRACE_V1("","tmpStartCassette[0].cassetteID.identifier is null  ..<<continue>>");
                    continue;   //while ( processRunCount < processRunSizeMaximum )
                }
    //D4000227 end

                /**********************************************************************************/
                /*                                                                                */
                /*   Set logicalRecipeID, machineRecipeID and Set not use operationStartFlag      */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set logicalRecipeID, machineRecipeID and Set not use operationStartFlag");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                PPT_METHODTRACE_V2("","  atteLen", attrLen);
                PPT_METHODTRACE_V2("","  nLotLen", nLotLen);

                for ( i=0; i < nLotLen; i++ )
                {
                    CORBA::Long bLotFindFlag = FALSE;
                    for ( j=0; j < attrLen; j++ )
                    {
                        if ( 0 == CIMFWStrCmp(strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[j].lotID.identifier,
                                              tmpStartCassette[0].strLotInCassette[i].lotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[j].lotID == tmpStartCassette[0].strLotInCassette[i].lotID");
                            /*-------------------------------------------------------------------------------------------*/
                            /*   Set logicalRecipeID, machineRecipeID for strWhatNextLotListForInternalBufferInqResult   */
                            /*-------------------------------------------------------------------------------------------*/
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID
                                                = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[j].logicalRecipeID;
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID
                                                = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[j].machineRecipeID;
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.physicalRecipeID
                                                = strWhatNextLotListForInternalBufferInqResult.strWhatNextAttributes[j].physicalRecipeID;
                            bLotFindFlag = TRUE;

                            PPT_METHODTRACE_V3("","    lotID             ", i, tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                            PPT_METHODTRACE_V3("","      logicalRecipeID ", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID.identifier);
                            PPT_METHODTRACE_V3("","      machineRecipeID ", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID.identifier);
                            PPT_METHODTRACE_V3("","      physicalRecipeID", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.physicalRecipeID);
                        }
                    }
                    if ( bLotFindFlag == FALSE )
                    {
                        /*-----------------------------------------------------------------------------*/
                        /*   Set operationStartFlag for strWhatNextLotListForInternalBufferInqResult   */
                        /*-----------------------------------------------------------------------------*/
                        PPT_METHODTRACE_V2("","operationStartFlag <--- FALSE", i);
                        tmpStartCassette[0].strLotInCassette[i].operationStartFlag = FALSE;
                    }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


                /**********************************************************************************/
                /*                                                                                */
                /*   Set operationStartFlag for Recipe                                            */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set operationStartFlag for Recipe");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                /*-------------------------*/
                /*   Get Cassette Object   */
                /*-------------------------*/
                PosCassette_var aCassette;
                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                       tmpStartCassette[0].cassetteID,
                                                       strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                                       whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq );

                /*---------------------------------*/
                /*   Get Cassette's MultiLotType   */
                /*---------------------------------*/
                try
                {
                    multiLotType = aCassette->getMultiLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType);

                PPT_METHODTRACE_V2("","multiRecipeCapability", multiRecipeCapability);
                PPT_METHODTRACE_V2("","multiLotType         ", multiLotType);

                if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe)
                  && 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_MultiLotMultiRecipe) )
                {
                    CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                    PPT_METHODTRACE_V2("","#   LotLen", nLotLen);
                    for ( j=0; j < nLotLen; j++ )
                    {
                        // Set operationStartFlag for Recipe
                        PPT_METHODTRACE_V3("","#     lotID", j, tmpStartCassette[0].strLotInCassette[j].lotID.identifier);

                        /*-------------------------------*/
                        /*   Set Temporary Base Recipe   */
                        /*-------------------------------*/
                        if ( processRunCount == 0 )
                        {
                            // Temporary Base Recipe
                            PPT_METHODTRACE_V1("","Temporary Base Recipe");
                        }
                        else
                        {
                            // Final Base Recipe
                            PPT_METHODTRACE_V2("","processRunCount", processRunCount);
                            PPT_METHODTRACE_V1("","Final Base Recipe");
                            tmpBaseLogicalRecipeID = baseLogicalRecipeID;
                            tmpBaseMachineRecipeID = baseMachineRecipeID;
                        }

                        objectIdentifier logicalRecipeID = tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID;
                        objectIdentifier machineRecipeID = tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID;

                        PPT_METHODTRACE_V1("","    Recipe Check");
                        PPT_METHODTRACE_V2("","      tmpBaseLogicalRecipeID", tmpBaseLogicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      tmpBaseMachineRecipeID", tmpBaseMachineRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      logicalRecipeID       ", logicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      machineRecipeID       ", machineRecipeID.identifier);

                        if ( 0 == CIMFWStrCmp(tmpBaseLogicalRecipeID.identifier, logicalRecipeID.identifier)
                          && 0 == CIMFWStrCmp(tmpBaseMachineRecipeID.identifier, machineRecipeID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","tmpBaseLogicalRecipeID == logicalRecipeID && tmpBaseMachineRecipeID == machineRecipeID");
                        }
                        else
                        {
                            PPT_METHODTRACE_V2("","#       operationStartFlag <--- FALSE", j);
                            tmpStartCassette[0].strLotInCassette[j].operationStartFlag = FALSE;
                        }
                    }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   Set operationStartFlag for Recipe");

    //D4200092 start
                /**********************************************************************************/
                /*                                                                                */
                /*   Set StartRecipeParameter                                                     */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set StartRecipeParameter");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                for ( CORBA::Long j=0; j < nLotLen; j++ )
                {
                    if ( TRUE != tmpStartCassette[0].strLotInCassette[j].operationStartFlag )
                    {
                        PPT_METHODTRACE_V1("", "tmpStartCassette[0].strLotInCassette[j].operationStartFlag is FALSE  ..<continue>");
                        continue;
                    }

                    PosLogicalRecipe_var aLogicalRecipe;
                    PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                     tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                                     strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                                                     whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq );

                    PosMachineRecipe_var aMachineRecipe;
    //D7000042      PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR( aMachineRecipe,
    //D7000042                                                tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID,
    //D7000042                                                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
    //D7000042                                                whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq );

    //D6000415 add start
                    /************************/
                    /*   Get subLotType     */
                    /************************/
                    PosLot_var aLot ; //DSIV00001443
                    CORBA::String_var subLotType;
                    if( 0 == CIMFWStrLen( tmpStartCassette[0].strLotInCassette[j].subLotType) )
                    {
//DSIV00001443                        PosLot_var aLot ;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                                     tmpStartCassette[0].strLotInCassette[j].lotID,
                                                     strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                                     whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq );
                        try
                        {
                            subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
                    }
                    else
                    {
                        subLotType = tmpStartCassette[0].strLotInCassette[j].subLotType ;
                    }
    //D6000415 add end
    //D8000024 add start
                    CORBA::Boolean skipFlag = FALSE;
                    objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                    rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                                   SP_FPC_ExchangeType_StartReserveInfo,
                                                   equipmentID,
                                                   tmpStartCassette[0].strLotInCassette[j].lotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                        strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult =
                            strLot_effectiveFPCInfo_Get_out.strResult;
                        return rc;
                    }

                    if( strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "MachineRecipe is overwritten by FPC");
                    }
                    else
                    {
    //D8000024 add end
                        if( searchCondition == 1 )                                                                                   //DSIV00001443
                        {                                                                                                            //DSIV00001443
                            if( CORBA::is_nil(aLot) == TRUE )                                                                        //DSIV00001443
                            {                                                                                                        //DSIV00001443
                                PPT_CONVERT_LOTID_TO_LOT_OR( aLot,                                                                   //DSIV00001443
                                                             tmpStartCassette[0].strLotInCassette[j].lotID,                          //DSIV00001443
                                                             strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out, //DSIV00001443
                                                             whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq );      //DSIV00001443
                            }                                                                                                        //DSIV00001443
                            try                                                                                                      //DSIV00001443
                            {                                                                                                        //DSIV00001443
                                aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine );                             //DSIV00001443
                            }                                                                                                        //DSIV00001443
                            CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)                                       //DSIV00001443
                        }                                                                                                            //DSIV00001443
                        else                                                                                                         //DSIV00001443
                        {                                                                                                            //DSIV00001443
    //D7000042 add start
                            try
                            {
                                aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType( aMachine, subLotType );
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType)
    //D7000042 add end
                        }                                                                                                            //DSIV00001443

                        PosRecipeParameterSequence*    recipeParameterSeq = NULL;
                        PosRecipeParameterSequence_var recipeParameterSeqVar;
                        try
                        {
    //D6000415          recipeParameterSeq = aLogicalRecipe->findRecipeParametersFor( aMachine, aMachineRecipe );
                            recipeParameterSeq = aLogicalRecipe->findRecipeParametersForSubLotType( aMachine, aMachineRecipe, subLotType );    //D6000415
                            recipeParameterSeqVar = recipeParameterSeq;
                        }
    //D6000415      CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersFor);
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersForSubLotType);    //D6000415

                        CORBA::Long rpmCnt = recipeParameterSeq->length();
                        PPT_METHODTRACE_V2("", "recipeParameterSeq->length()", rpmCnt);

                        CORBA::Long nWafLen = tmpStartCassette[0].strLotInCassette[j].strLotWafer.length();
                        for ( CORBA::Long k=0; k < nWafLen; k++ )
                        {
                            if ( NULL == recipeParameterSeq )
                            {
                                tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length(0);
                            }
                            else
                            {
                                tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length( rpmCnt );

                                for ( CORBA::Long l=0; l < rpmCnt; l++ )
                                {
                                    PPT_METHODTRACE_V2("", "rpmCnt----------------------------", l);
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName = (*recipeParameterSeq)[l].parameterName;
                                    if ( TRUE == (*recipeParameterSeq)[l].useCurrentValueFlag )
                                    {
                                        PPT_METHODTRACE_V1("", "(*recipeParameterSeq)[l].useCurrentValueFlag is TRUE");
                                        tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue = (const char*)"";
                                    }
                                    else
                                    {
                                        tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue = (*recipeParameterSeq)[l].defaultValue;
                                    }
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue = (*recipeParameterSeq)[l].defaultValue;
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag = (*recipeParameterSeq)[l].useCurrentValueFlag;

                                    PPT_METHODTRACE_V2("", ".parameterName _______________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName);
                                    PPT_METHODTRACE_V2("", ".parameterValue ______________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue);
                                    PPT_METHODTRACE_V2("", ".targetValue _________________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue);
//D9000001                                    PPT_METHODTRACE_V2("", ".useCurrentSettingValueFlag __", (long)tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag);
                                    PPT_METHODTRACE_V2("", ".useCurrentSettingValueFlag __", (int)tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag); //D9000001
                                }
                            }
                        }
                    }    //D8000024
                }
    //D4200092 end


                /**********************************************************************************/
                /*                                                                                */
                /*   check strStartCassette Process                                               */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  check strStartCassette Process");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Cassette                                          */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== cassette_CheckConditionForOperationForInternalBuffer() ==========");
                objCassette_CheckConditionForOperationForInternalBuffer_out  strCassette_CheckConditionForOperationForInternalBuffer_out;
                rc = cassette_CheckConditionForOperationForInternalBuffer( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                                           strObjCommonIn,
                                                                           equipmentID,
                                                                           tmpStartCassette,
                                                                           SP_Operation_CassetteDelivery );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cassette_CheckConditionForOperationForInternalBuffer() != RC_OK  ...<<<continue>>>");
                    continue;
                }

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Lot                                               */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== lot_CheckConditionForOperationForInternalBuffer() ==========");
                objLot_CheckConditionForOperationForInternalBuffer_out  strLot_CheckConditionForOperationForInternalBuffer_out;
                rc = lot_CheckConditionForOperationForInternalBuffer( strLot_CheckConditionForOperationForInternalBuffer_out,
                                                                      strObjCommonIn,
                                                                      equipmentID,
                                                                      tmpStartCassette,
    //P4100258                                                                  SP_Operation_StartReservation );
                                                                      SP_Operation_CassetteDelivery );    //P4100258
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_CheckConditionForOperationForInternalBuffer() != RC_OK  ...<<<continue>>>");
                    continue;
                }

                /*-----------------------------------------------------------------------------*/
                /*                                                                             */
                /*   Check Equipment Port for Start Reservation                                */
                /*                                                                             */
                /*-----------------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== equipment_portState_CheckForStartReservationForInternalBuffer() ==========");
                objEquipment_portState_CheckForStartReservationForInternalBuffer_out  strEquipment_portState_CheckForStartReservationForInternalBuffer_out;
                rc = equipment_portState_CheckForStartReservationForInternalBuffer( strEquipment_portState_CheckForStartReservationForInternalBuffer_out,
                                                                                    strObjCommonIn,
                                                                                    equipmentID,
                                                                                    tmpStartCassette );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "equipment_portState_CheckForStartReservation() != RC_OK  ...<<<continue>>>");
                    continue;
                }

    //D4100036 delete start
    //D4100036            /*-----------------------------------------------------------------------*/
    //D4100036            /*                                                                       */
    //D4100036            /*   Check Process for FlowBatch                                         */
    //D4100036            /*                                                                       */
    //D4100036            /*-----------------------------------------------------------------------*/
    //D4100036            PPT_METHODTRACE_V1("","===== equipment_lot_CheckFlowBatchConditionForOpeStart() ==========");
    //D4100036            objEquipment_lot_CheckFlowBatchConditionForOpeStart_out strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
    //D4100036            rc = equipment_lot_CheckFlowBatchConditionForOpeStart( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
    //D4100036                                                                   strObjCommonIn,
    //D4100036                                                                   equipmentID,
    //D4100036                                                                   "",                  //portGroupID
    //D4100036                                                                   tmpStartCassette );
    //D4100036            if ( rc != RC_OK )
    //D4100036            {
    //D4100036                PPT_METHODTRACE_V1("", "equipment_lot_CheckFlowBatchConditionForOpeStart() != RC_OK  ...<<<continue>>>");
    //D4100036                continue;
    //D4100036            }
    //D4100036 delete end

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Process Durable                                   */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== equipment_processDurableRequiredFlag_Get() ==========");
                CORBA::Boolean DurableRequiredFlag = FALSE;

                objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
                rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out,
                                                               strObjCommonIn,
                                                               equipmentID );
                if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
                {
                    PPT_METHODTRACE_V1("","rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");

                    if ( CIMFWStrCmp(tmpStartCassette[0].loadPurposeType, SP_LoadPurposeType_EmptyCassette) != 0)
                    {
                        PPT_METHODTRACE_V1("","tmpStartCassette[0].loadPurposeType != [EmptyCassette]");

                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for ( j=0; j < nLotLen; j++ )
                        {
                            PPT_METHODTRACE_V2("","counter[j]", j);

                            if ( tmpStartCassette[0].strLotInCassette[j].operationStartFlag == FALSE )
                            {
                                PPT_METHODTRACE_V1("","tmpStartCassette[0].strLotInCassette[j].operationStartFlag == FALSE  ...<<<continue>>>");
                                continue;
                            }

                            PPT_METHODTRACE_V2("","logicalRecipeID", tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","machineRecipeID", tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier);

                            /*--------------------------------------------------*/
                            /*   Check Process Durable Condition for OpeStart   */
                            /*--------------------------------------------------*/
                            PPT_METHODTRACE_V1("","processDurable_CheckConditionForOpeStart()");
                            objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                            rc = processDurable_CheckConditionForOpeStart( strProcessDurable_CheckConditionForOpeStart_out,
                                                                           strObjCommonIn,
                                                                           equipmentID,
                                                                           tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID,
    //D4000048                                                             tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID );
                                                                           tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID,       //D4000048
                                                                           tmpStartCassette[0].strLotInCassette[j].lotID                          );     //D4000048
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","processDurable_CheckConditionForOpeStart != RC_OK");
                                DurableRequiredFlag = TRUE;
                                PPT_METHODTRACE_V1("","DurableRequiredFlag = TRUE");
                                break;
                            }

                            /*---------------------------------------*/
                            /*   Set Available Reticles / Fixtures   */
                            /*---------------------------------------*/
                            tmpStartCassette[0].strLotInCassette[j].strStartRecipe.strStartReticle = strProcessDurable_CheckConditionForOpeStart_out.strStartReticle;
                            tmpStartCassette[0].strLotInCassette[j].strStartRecipe.strStartFixture = strProcessDurable_CheckConditionForOpeStart_out.strStartFixture;
                        }
                        if ( DurableRequiredFlag == TRUE)
                        {
                            PPT_METHODTRACE_V1("","DurableRequiredFlag == TRUE  ...<<<continue>>>");
                            continue;
                        }
                    }
                }
                else if ( rc != RC_EQP_PROCDRBL_NOT_REQD )
                {
                    PPT_METHODTRACE_V1("","rc != RC_EQP_PROCDRBL_NOT_REQD  ...<<<continue>>>");
                    continue;
                }

    //P4100010 delete start
    //P4100010//D4000016 Add Start
    //P4100010            /*---------------------------------------------------------------------------*/
    //P4100010            /*                                                                           */
    //P4100010            /*   Check Category for Copper/Non Copper                                    */
    //P4100010            /*                                                                           */
    //P4100010            /*   It is checked in the following method whether it is the condition       */
    //P4100010            /*   that Lot of the object is made of OpeStart.                             */
    //P4100010            /*                                                                           */
    //P4100010            /*   1. It is checked whether CassetteCategory of RequiredCassetteCategory   */
    //P4100010            /*      of PosLot and PosCassette is the same.                               */
    //P4100010            /*                                                                           */
    //P4100010            /*   2. It is checked whether CassetteCategoryCapability of CassetteCategory */
    //P4100010            /*      of PosCassette and PosPortResource is the same.                      */
    //P4100010            /*                                                                           */
    //P4100010            /*   3. It is proper condition if CassetteCategoryCapability is the same     */
    //P4100010            /*      as RequiredCassetteCategory and CassetteCategory.                    */
    //P4100010            /*                                                                           */
    //P4100010            /*---------------------------------------------------------------------------*/
    //P4100010            PPT_METHODTRACE_V1("","===== Check Category for Copper/Non Copper ==========");
    //P4100010
    //P4100010            CORBA::Long ii;
    //P4100010            CORBA::Long jj;
    //P4100010            CORBA::Long nCastLen = strStartCassette.length();
    //P4100010            CORBA::Long nLotInCastLen;
    //P4100010            CORBA::Boolean bCategory = TRUE;
    //P4100010
    //P4100010            for ( ii = 0; ii < nCastLen; ii++ )
    //P4100010            {
    //P4100010                PPT_METHODTRACE_V2("","--------------------------round[ii]", ii);
    //P4100010                nLotInCastLen = strStartCassette[ii].strLotInCassette.length();
    //P4100010                for ( jj = 0; jj < nLotInCastLen; jj++ )
    //P4100010                {
    //P4100010                    PPT_METHODTRACE_V1("","call lot_CassetteCategory_CheckForContaminationControl()");
    //P4100010                    objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
    //P4100010                    rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
    //P4100010                                                              strObjCommonIn,
    //P4100010                                                              strStartCassette[ii].strLotInCassette[jj].lotID,
    //P4100010                                                              strStartCassette[ii].cassetteID,
    //P4100010                                                              equipmentID,
    //P4100010                                                              strStartCassette[0].loadPortID);
    //P4100010                    if ( rc != RC_OK )
    //P4100010                    {
    //P4100010                        PPT_METHODTRACE_V1("","rc != RC_OK   break");
    //P4100010                        bCategory = FALSE;
    //P4100010                        break;
    //P4100010                    }
    //P4100010                }
    //P4100010            }
    //P4100010
    //P4100010            if( bCategory == FALSE )
    //P4100010            {
    //P4100010                PPT_METHODTRACE_V1("","bCategory == FALSE   ..<<continue>>");
    //P4100010                continue;
    //P4100010            }
    //P4100010//D4000016 Add End
    //P4100010 delete end
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   check strStartCassette Process");


                /**********************************************************************************/
                /*                                                                                */
                /*   Check multiRecipeCapability and multiLotType                                 */
                /*   and Decide finally to put it in StartCassette                                */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Check multiRecipeCapability and multiLotType");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                //--------------------------------------------------------------------
                //      Equipment's         Cassette's
                // multiRecipeCapability    multiLotType    Same Recipe Check
                // ===================================================================
    //D4000015            // M-Recipe                 SL-SR           FALSE
    //D4000015            //                          ML-SR           FALSE
    //D4000015            //                          ML-MR           FALSE
                // -----------------------  --------------------------------------------
                // S-Recipe                 SL-SR           TRUE
                //                          ML-SR           TRUE
                //                          ML-MR           TRUE
                // -----------------------  --------------------------------------------
                // Batch                    SL-SR           TRUE
                //                          ML-SR           TRUE
                //                          ML-MR           Error
                // -----------------------  --------------------------------------------
                CORBA::Boolean bAddStartCassette = FALSE;       //D4000015

                if ( CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_MultipleRecipe) == 0 )
                {
    //D4000015    No Support  --- MultipleRecipe Machine ---
    //D4000015
    //D4000015                // M-Recipe: SL-SR, ML-SR, ML-MR
    //D4000015                // Same Recipe Check : FALSE
    //D4000015                PPT_METHODTRACE_V1("","M-Recipe: SL-SR, ML-SR, ML-MR");
    //D4000015                PPT_METHODTRACE_V1("","Same Recipe Check : FALSE");
    //D4000015
    //D4000015                PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);
    //D4000015
    //D4000015                strStartCassette[processRunCount] = tmpStartCassette[0];
    //D4000015                processRunCount++;

                    //D7000074 PPT_METHODTRACE_V1("","MuitipleRecipe EQP:  ...<<<continue>>>");
                    //D7000074 continue;                                                           //D4000015
                    //D7000074 start
                    // M-Recipe: SL-SR, ML-SR, ML-MR
                    // Same Recipe Check : FALSE
                    PPT_METHODTRACE_V1("","M-Recipe: SL-SR, ML-SR, ML-MR");
                    PPT_METHODTRACE_V1("","Same Recipe Check : FALSE");

                    PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);
                    bAddStartCassette = TRUE;
                    //D7000074 end

                }
                else if ( CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch)      == 0 &&
                          CIMFWStrCmp(multiLotType         , SP_Cas_MultiLotType_MultiLotMultiRecipe) == 0 )
                {
                    // Batch and ML-MR
                    // Error
                    PPT_METHODTRACE_V1("","Batch and ML-MR:  ...<<<continue>>>");
                    continue;
                }
                else
                {
                    // S-Recipe: SL-SR, ML-SR, ML-MR
                    // Batch   : SL-SR, ML-SR
                    // Same Recipe Check : TRUE
                    PPT_METHODTRACE_V1("","S-Recipe: SL-SR, ML-SR, ML-MR");
                    PPT_METHODTRACE_V1("","Batch   : SL-SR, ML-SR");
                    PPT_METHODTRACE_V1("","Same Recipe Check : TRUE");

                    if ( processRunCount == 0 )
                    {
                        PPT_METHODTRACE_V1("","processRunCount == 0");

    //D4000015                    PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);
    //D4000015                    strStartCassette[0] = tmpStartCassette[0];
    //D4000015                    processRunCount++;
                        bAddStartCassette = TRUE;   //D4000015

                        /*------------------------------------------------------------*/
                        /*   Set Base Recipe (First operationStartFlag=TRUE Recipe)   */
                        /*------------------------------------------------------------*/
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for ( i=0; i < nLotLen; i++ )
                        {
                            if ( tmpStartCassette[0].strLotInCassette[i].operationStartFlag == TRUE )
                            {
                                baseLogicalRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID;
                                baseMachineRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID;
                                break;
                            }
                        }
                        if ( CIMFWStrLen(baseLogicalRecipeID.identifier) == 0 || CIMFWStrLen(baseMachineRecipeID.identifier) == 0 )
                        {
                            PPT_METHODTRACE_V1("","################## Can not Found Base Recipe!! ###################");
                            PPT_METHODTRACE_V2("","###  baseLogicalRecipeID", baseLogicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","###  baseMachineRecipeID", baseMachineRecipeID.identifier);
                            PPT_METHODTRACE_V1("","##################################################################");
                        }
                    }
                    else
                    {
                        objectIdentifier logicalRecipeID;
                        objectIdentifier machineRecipeID;
                        /*--------------------------------------------------------*/
                        /*   Find Recipe (First operationStartFlag=TRUE Recipe)   */
                        /*--------------------------------------------------------*/
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for ( i=0; i < nLotLen; i++ )
                        {
                            if ( tmpStartCassette[0].strLotInCassette[i].operationStartFlag == TRUE )
                            {
                                logicalRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID;
                                machineRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID;
                                break;
                            }
                        }
                        if ( CIMFWStrLen(logicalRecipeID.identifier) == 0 || CIMFWStrLen(machineRecipeID.identifier) == 0 )
                        {
                            PPT_METHODTRACE_V1("","################## Can not Found Recipe!! ###################");
                            PPT_METHODTRACE_V2("","###  logicalRecipeID", logicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","###  machineRecipeID", machineRecipeID.identifier);
                            PPT_METHODTRACE_V1("","#############################################################");
                        }

                        PPT_METHODTRACE_V1("","Recipe Check");
                        PPT_METHODTRACE_V2("","  baseLogicalRecipeID", baseLogicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  baseMachineRecipeID", baseMachineRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  logicalRecipeID    ", logicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  machineRecipeID    ", machineRecipeID.identifier);

                        if( CIMFWStrCmp(baseLogicalRecipeID.identifier, logicalRecipeID.identifier) == 0
                         && CIMFWStrCmp(baseMachineRecipeID.identifier, machineRecipeID.identifier) == 0 )
                        {
                            PPT_METHODTRACE_V1("","baseLogicalRecipeID == logicalRecipeID && baseMachineRecipeID == machineRecipeID");
    //D4000015                        PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);
    //D4000015                        strStartCassette[processRunCount] = tmpStartCassette[0];
    //D4000015                        processRunCount++;
                            bAddStartCassette = TRUE;   //D4000015
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","###############################################");
                            PPT_METHODTRACE_V1("","Deferent Recipe.  ...<<<continue>>>");
                            PPT_METHODTRACE_V1("","###############################################");
                            continue;
                        }
                    }
                } //D7000074
                //D7000074 adjust indent
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   Add tmpStartCassette to StartCassette");


                /**********************************************************************************/
                /*                                                                                */
                /*   Add tmpStartCassette to StartCassette                                        */
                /*                                                                                */
                /**********************************************************************************/
                if ( TRUE == bAddStartCassette )
                {
                    /*******************************************************************************/
                    /*   Check MonitorCreationFlag                                                 */
                    /*   Only one time of the beginnings                                           */
                    /*******************************************************************************/
                    if ( FALSE == bAlreadyCheckMonitorCreationFlag
                      && TRUE == strEquipment_processBatchCondition_Get_out.monitorCreationFlag )
                    {
                        PPT_METHODTRACE_V1("","===== Check MonitorCreationFlag ==========");

                        // Stop Pickup of Lot if ShelfSpace of EmptyCassette becomes 0
                        if ( 0 == nShelfSpaceOfEmptyCassette )
                        {
                            PPT_METHODTRACE_V1("", "0 == nShelfSpaceOfEmptyCassette  ...<<<continue>>>");
                            bWhileExitFlag = TRUE;
                            continue;
                        }

                        PosLogicalRecipe_var aLogicalRecipe;
                        PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                         tmpBaseLogicalRecipeID,
                                                                         strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                                                         whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq );
                        PosProductSpecification_var aMonitorProduct;
                        try
                        {
                            aMonitorProduct = aLogicalRecipe->getMonitorProduct();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::getMonitorProduct)

                        if( TRUE != CORBA::is_nil(aMonitorProduct) )
                        {
                            //***** EmptyCassette is necessary! *****
                            PPT_METHODTRACE_V1("", "===== Set EmptyCassette for MonitorCreation ==========");
//INN-R170002 Add Start
                            CORBA::String_var strReqUsageType;
                            SI_PPT_USERDATA_GET_STRING( aMonitorProduct, CS_S_PROD_CarrierUsageType, strReqUsageType );
//INN-R170002 Add End
                            
    //D4000184                    nUsedEmptyCassetteCount++;
    //D4000184 start
                            /*------------------------------------------------*/
                            /*   Look for Port to assign, and EmptyCassette   */
                            /*------------------------------------------------*/
                            PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                            PPT_METHODTRACE_V1("","/*   Look for Port to assign, and EmptyCassette   */");
                            PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                            objectIdentifier dummyLotID;
                            objectIdentifierSequence dummyPortIDSeq;
                            objCassetteDelivery_SearchEmptyCassetteAssignPort_out strCassetteDelivery_SearchEmptyCassetteAssignPort_out;
//INN-R170002               rc = cassetteDelivery_SearchEmptyCassetteAssignPort(
                            rc = cs_cassetteDelivery_SearchEmptyCassetteAssignPort( //INN-R170002
                                            strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
                                            strObjCommonIn,
                                            dummyLotID,         // Because it is MonitorCreation, it doesn't have Lot
                                            strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID,
                                            strReqUsageType,    //INN-R170002
                                            strCassetteList_emptyAvailable_Pickup_out.strFoundCassette,
                                            useEmptyCassetteIDSeq,
                                            dummyPortIDSeq );   // Port can overlap with InternalBufferEQP
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","##### NotFound!! Assign EmptyCassette or Assign Port!   set bWhileExitFlag = TRUE");
                                bWhileExitFlag = TRUE;
                                continue;
                            }

                            // Hold EmptyCasstte and Port to prevent duplication
                            PPT_METHODTRACE_V1("", "Hold EmptyCasstte and Port to prevent duplication");
                            useAssignEmptyCassettePortSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;
                            useEmptyCassetteIDSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                            nAssignEmptyCassetteCnt++;
                            PPT_METHODTRACE_V2("", "nAssignEmptyCassetteCnt--------->", nAssignEmptyCassetteCnt);

                            // Reduce the number of the rest of Shelf of EmptyCasstte
                            nShelfSpaceOfEmptyCassette--;
                            PPT_METHODTRACE_V2("", "nShelfSpaceOfEmptyCassette------>", nShelfSpaceOfEmptyCassette);
    //D4000184 end
                        }

                        bAlreadyCheckMonitorCreationFlag = TRUE;
                    }

                    /*******************************************************************************/
                    /*   Set EmptyCassette if it is necessary                                      */
                    /*******************************************************************************/
                    if ( TRUE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag )
                    {
                        PPT_METHODTRACE_V1("", "cassetteExchangeFlag == TRUE");

    //D4000184 start
                        // Stop Pickup of Lot if ShelfSpace of EmptyCassette becomes 0
                        if ( 0 == nShelfSpaceOfEmptyCassette )
                        {
                            PPT_METHODTRACE_V1("", "0 == nShelfSpaceOfEmptyCassette  ...<<<continue>>>");
                            bWhileExitFlag = TRUE;
                            continue;
                        }

    //P4000390 start
                        /*------------------------------------------------------*/
                        /*   Look for the first Lot when OpeStartFlag is TRUE   */
                        /*------------------------------------------------------*/
                        PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
                        PPT_METHODTRACE_V1("","/*   Look for the first Lot when OpeStartFlag is TRUE   */");
                        PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
                        objectIdentifier targetLotID;
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","tmpStartCassette[0].strLotInCassette.length", nLotLen);
                        for ( CORBA::Long i=0; i < nLotLen; i++ )
                        {
                            PPT_METHODTRACE_V3("","tmpStartCassette[0].strLotInCassette[i].lotID", i, tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                            if ( TRUE == tmpStartCassette[0].strLotInCassette[i].operationStartFlag )
                            {
                                PPT_METHODTRACE_V2("","Found!! Target LotID --->", tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                                targetLotID = tmpStartCassette[0].strLotInCassette[i].lotID;
                                break;
                            }
                        }
                        if ( 0 == CIMFWStrLen(targetLotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","targetLotID is null  ...<<<continue>>>");
                            continue; //base loop
                        }
    //P4000390 end
//INN-R170002 Add Start
                        PosProductSpecification_var aProductSpecification;
                        PPT_CONVERT_PRODUCTID_TO_PRODUCTSP_OR( aProductSpecification,
                                                               tmpStartCassette[0].strLotInCassette[i].productID,
                                                               strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                                               whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq );

                        CORBA::String_var strReqUsageType;
                        SI_PPT_USERDATA_GET_STRING( aProductSpecification, CS_S_PROD_CarrierUsageType, strReqUsageType );
//INN-R170002 Add End

                        /*------------------------------------------------*/
                        /*   Look for Port to assign, and EmptyCassette   */
                        /*------------------------------------------------*/
                        PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                        PPT_METHODTRACE_V1("","/*   Look for Port to assign, and EmptyCassette   */");
                        PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                        objectIdentifierSequence dummyPortIDSeq;
                        objCassetteDelivery_SearchEmptyCassetteAssignPort_out strCassetteDelivery_SearchEmptyCassetteAssignPort_out;
//INN-R170002           rc = cassetteDelivery_SearchEmptyCassetteAssignPort(
                        rc = cs_cassetteDelivery_SearchEmptyCassetteAssignPort(    //INN-R170002
                                        strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
                                        strObjCommonIn,
    //P4000390                                    tmpStartCassette[0].strLotInCassette[0].lotID,
                                        targetLotID,                //P4000390
                                        strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID,
                                        strReqUsageType,            //INN-R170002
                                        strCassetteList_emptyAvailable_Pickup_out.strFoundCassette,
                                        useEmptyCassetteIDSeq,
                                        dummyPortIDSeq );       // Port can overlap with InternalBufferEQP
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("","##### NotFound!! Assign EmptyCassette or Assign Port!   set bWhileExitFlag = TRUE");
                            bWhileExitFlag = TRUE;
                            continue;
                        }

                        // Hold EmptyCasstte and Port to prevent duplication
                        PPT_METHODTRACE_V1("", "Hold EmptyCasstte and Port to prevent duplication");
                        useAssignEmptyCassettePortSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;
                        useEmptyCassetteIDSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                        nAssignEmptyCassetteCnt++;
                        PPT_METHODTRACE_V2("", "nAssignEmptyCassetteCnt------->", nAssignEmptyCassetteCnt);

                        // Reduce the number of the rest of Shelf of EmptyCasstte
                        nShelfSpaceOfEmptyCassette--;
                        PPT_METHODTRACE_V2("", "nShelfSpaceOfEmptyCassette---->", nShelfSpaceOfEmptyCassette);
    //D4000184 end

    //D4000184                        if ( nCanBeUsedEmptyCassetteCount <= nUsedEmptyCassetteCount )
    //D4000184                        {
    //D4000184                            PPT_METHODTRACE_V1("", "nCanBeUsedEmptyCassetteCount <= nUsedEmptyCassetteCount  ...<<<continue>>>");
    //D4000184                            bWhileExitFlag = TRUE;
    //D4000184
    //D4000184                            // Short of EmptyCassette Count!!
    //D4000184                            bShortOfEmptyCassette = TRUE;
    //D4000184                            continue;
    //D4000184                        }
    //D4000184
    //D4000184                        nUsedEmptyCassetteCount++;
    //D4000184                        PPT_METHODTRACE_V2("","nUsedEmptyCassetteCount++", nUsedEmptyCassetteCount);
                    }

                    /*******************************************************************************/
                    /*   Add tmpStartCassette to StartCassette                                     */
                    /*******************************************************************************/
                    PPT_METHODTRACE_V1("","===== Add tmpStartCassette to StartCassette ==========");
                    strStartCassette[ processRunCount ] = tmpStartCassette[0];
                    processRunCount++;
                    PPT_METHODTRACE_V2("","processRunCount++", processRunCount);
                }
                //D7000074 adjust indent
                //D7000074 }
            }

            PPT_METHODTRACE_V1("","                       @@@@@@@@@@@@@@@@@@@@@@@@@@@");
            PPT_METHODTRACE_V2("","Select Cassette Result @@@@@ ProcessRunCount @@@@@", processRunCount);
            PPT_METHODTRACE_V1("","                       @@@@@@@@@@@@@@@@@@@@@@@@@@@");

//D7000183 start
            /*-----------------------------------------------------------------------------------------*/
            /*   If selected Carrier does not fulfill MinBatchSize, they are omitted from candidate.   */
            /*-----------------------------------------------------------------------------------------*/
            if ( bCheckMinBatchSize
              && 0 < processRunCount && processRunCount < strEquipment_processBatchCondition_Get_out.minBatchSize )
            {
                PPT_METHODTRACE_V1("", "processRunCount < minBatchSize");
                for ( CORBA::Long m=0; m < processRunCount; m++ )
                {
                    CORBA::Long lenOmitCst = omitCassetteSeq.length();
                    omitCassetteSeq.length( lenOmitCst + 1 );
                    omitCassetteSeq[ lenOmitCst ] = strStartCassette[m].cassetteID;
                    PPT_METHODTRACE_V2("", "Omit CassetteID", strStartCassette[m].cassetteID.identifier);
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "MinBatchSize support loop");
                break;
            }
        } // MinBatchSize support loop.
//D7000183 end


        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Final Check                                                                                              */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  Final Check                                                             */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        /*----------------------------------------*/
        /*   Check Short of EmptyCassette Count   */
        /*----------------------------------------*/
        PPT_METHODTRACE_V1("","/*----------------------------------------*/");
//D9000001        PPT_METHODTRACE_V2("","/*   Check Short of EmptyCassette Count   */", (long)bShortOfEmptyCassette);
        PPT_METHODTRACE_V2("","/*   Check Short of EmptyCassette Count   */", (int)bShortOfEmptyCassette); //D9000001
        PPT_METHODTRACE_V1("","/*----------------------------------------*/");
        if ( processRunCount == 0 && TRUE == bShortOfEmptyCassette )
        {
            PPT_METHODTRACE_V1("","##### processRunCount == 0 && TRUE == bShortOfEmptyCassette     return RC_NOT_ENOUGH_EMPTYCAST");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out, MSG_NOT_ENOUGH_EMPTYCAST, RC_NOT_ENOUGH_EMPTYCAST);
            return RC_NOT_ENOUGH_EMPTYCAST;
        }

        /*---------------------------*/
        /*   Check ProcessRunCount   */
        /*---------------------------*/
        PPT_METHODTRACE_V1("","/*---------------------------*/");
        PPT_METHODTRACE_V2("","/*   Check ProcessRunCount   */", processRunCount);
        PPT_METHODTRACE_V1("","/*---------------------------*/");
        if ( processRunCount == 0 )
        {
            PPT_METHODTRACE_V1("","##### processRunCount == 0     return RC_NOT_FOUND_FILLEDCAST");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST);
            return RC_NOT_FOUND_FILLEDCAST;
        }

        /*------------------------------------------------------*/
        /*   Check MinimumBatchSize of Equipment                */
        /*       The check of MaxBatchSize is done in the top   */
        /*------------------------------------------------------*/
        PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   Check MinimumBatchSize of Equipment                */");
        PPT_METHODTRACE_V1("","/*       The check of MaxBatchSize is done in the top   */");
        PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
        PPT_METHODTRACE_V2("","minBatchSize", strEquipment_processBatchCondition_Get_out.minBatchSize);
        if ( processRunCount < strEquipment_processBatchCondition_Get_out.minBatchSize )
        {
            PPT_METHODTRACE_V1("","##### processRunCount < minBatchSize");

            char procCnt[16];
            char minSize[16];
            char maxSize[16];
            sprintf( procCnt, "%d", processRunCount );
            sprintf( minSize, "%d", strEquipment_processBatchCondition_Get_out.minBatchSize );
            sprintf( maxSize, "%d", strEquipment_processBatchCondition_Get_out.maxBatchSize );

            PPT_SET_MSG_RC_KEY3( strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
                                 MSG_INVALID_PROCESS_BATCH_COUNT,
                                 RC_INVALID_PROCESS_BATCH_COUNT,
                                 procCnt,
                                 minSize,
                                 maxSize );
            return RC_INVALID_PROCESS_BATCH_COUNT;
        }

//P4100258 start
        /*-------------------------------*/
        /*   Check Mininum Wafer Count   */
        /*-------------------------------*/
        PPT_METHODTRACE_V1("","Check Mininum Wafer Count");
        CORBA::Long nTotalWaferCount = 0;
        for ( i=0; i < processRunCount; i++ )
        {
            CORBA::Long lenLot = strStartCassette[i].strLotInCassette.length();
            for ( CORBA::Long j=0; j < lenLot; j++ )
            {
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE )
                {
                    nTotalWaferCount += strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                    PPT_METHODTRACE_V2( "","Add nTotalWaferCount", nTotalWaferCount);
                }
            }
        }
        PPT_METHODTRACE_V2( "","nTotalWaferCount", nTotalWaferCount);
        if ( strEquipment_processBatchCondition_Get_out.minWaferSize > nTotalWaferCount )
        {
            PPT_METHODTRACE_V1( "","##### return RC_INVALID_INPUT_WAFER_COUNT");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out, MSG_INVALID_INPUT_WAFER_COUNT, RC_INVALID_INPUT_WAFER_COUNT);
            return RC_INVALID_INPUT_WAFER_COUNT;
        }
//P4100258 end

//D4100036 start  <<< FlowBatch Control >>>
        if ( 0 < CIMFWStrLen(strFlowBatch_CheckConditionForCassetteDelivery_out.flowBatchID.identifier) )
        {
            PPT_METHODTRACE_V1("","Check!! processRunCount must be the same as FlowBatching Lots Count");
            /*-----------------------------------------------------------------*/
            /*   processRunCount must be the same as FlowBatching Lots Count   */
            /*-----------------------------------------------------------------*/
            CORBA::Long lenFlowBatchLots = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch.length();
//P4200182 start
            PPT_METHODTRACE_V2("","lenFlowBatchLots", lenFlowBatchLots);
            objectIdentifierSequence cassetteIDSeq;
            cassetteIDSeq.length( lenFlowBatchLots );
            CORBA::Long nFlowBatchCasIdx = 0;
            for ( i=0; i < lenFlowBatchLots; i++ )
            {
                CORBA::Boolean bFound = FALSE;
                CORBA::Long lenCas = cassetteIDSeq.length();
                for ( CORBA::Long j=0; j < lenCas; j++ )
                {
                    if ( 0 == CIMFWStrCmp(cassetteIDSeq[j].identifier,
                                          strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[i].cassetteID.identifier) )
                    {
                        bFound = TRUE;
                        break;
                    }
                }
                if ( TRUE != bFound )
                {
                    cassetteIDSeq[nFlowBatchCasIdx] = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[i].cassetteID;
                    nFlowBatchCasIdx++;
                }
            }
            cassetteIDSeq.length( nFlowBatchCasIdx );
            PPT_METHODTRACE_V2("","nFlowBatchCasIdx", nFlowBatchCasIdx);
//P4200182 end

            if ( processRunCount != nFlowBatchCasIdx )  //P4200182
//P4200182            if ( processRunCount != lenFlowBatchLots )
            {
                // return [All FlowBatchingLotss weren't select.]
                PPT_METHODTRACE_V1("","##### return RC_NOT_SELECT_ALL_FLOWBATCH_LOTS");
                SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out, MSG_NOT_SELECT_ALL_FLOWBATCH_LOTS, RC_NOT_SELECT_ALL_FLOWBATCH_LOTS);
                return RC_NOT_SELECT_ALL_FLOWBATCH_LOTS;
            }
        }

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Process for FlowBatch                                         */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
//D9000079        PPT_METHODTRACE_V1("","===== equipment_lot_CheckFlowBatchConditionForOpeStart() ==========");
//D9000079        objEquipment_lot_CheckFlowBatchConditionForOpeStart_out strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
//D9000079        rc = equipment_lot_CheckFlowBatchConditionForOpeStart( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
//D9000079                                                               strObjCommonIn,
//D9000079                                                               equipmentID,
//D9000079                                                               "",                  //portGroupID
//D9000079                                                               strStartCassette );
//D9000079  add start
        PPT_METHODTRACE_V1("","===== equipment_lot_CheckFlowBatchConditionForOpeStart__090() ==========");
        objEquipment_lot_CheckFlowBatchConditionForOpeStart_out__090 strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
        objEquipment_lot_CheckFlowBatchConditionForOpeStart_in__090  strEquipment_lot_CheckFlowBatchConditionForOpeStart_in;
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.equipmentID = equipmentID;
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.portGroupID = "";
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.strStartCassette = strStartCassette;
        rc  = equipment_lot_CheckFlowBatchConditionForOpeStart__090( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
                                                                     strObjCommonIn,
                                                                     strEquipment_lot_CheckFlowBatchConditionForOpeStart_in );

//D9000079 add end
        if ( rc != RC_OK )
        {
//D9000079            PPT_METHODTRACE_V2("", "##### RC_OK != equipment_lot_CheckFlowBatchConditionForOpeStart()", rc);
            PPT_METHODTRACE_V2("", "##### RC_OK != equipment_lot_CheckFlowBatchConditionForOpeStart__090()", rc);         //D9000079
            strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.strResult;
            return rc;
        }
//D4100036 end  <<< FlowBatch Control >>>

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Make Output Struct                                                                                       */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  Make Output Struct                                                      */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        /*--------------------------------------------------------*/
        /*   Set LoadPortID of StartCassette. Only ProcessLot!!   */
        /*--------------------------------------------------------*/
        PPT_METHODTRACE_V1("","/*--------------------------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   Set LoadPortID of StartCassette. Only ProcessLot!!   */");
        PPT_METHODTRACE_V1("","/*--------------------------------------------------------*/");
        CORBA::Long nSetPortIdx = 0;
        for ( i=0; i < processRunCount; i++ )
        {
            // Set PortID by the rotation
            strStartCassette[i].loadPortID = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[ nSetPortIdx ].portID;
            nSetPortIdx++;
            if ( nSetPortIdx > nCanBeUsedPortCount - 1 )
            {
                nSetPortIdx = 0;
            }
        }

        /*----------------------------------------*/
        /*   Add EmptyCassette to StartCassette   */
        /*----------------------------------------*/
        PPT_METHODTRACE_V1("","/*----------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   Add EmptyCassette to StartCassette   */");
        PPT_METHODTRACE_V1("","/*----------------------------------------*/");
        PPT_METHODTRACE_V2("","Add EmptyCassette Count", nAssignEmptyCassetteCnt);
        CORBA::Long nSetStart = processRunCount;
        PPT_METHODTRACE_V2("","nSetStart of strStartCassette----->", nSetStart);
//D4000184 start
        for ( i=0; i < nAssignEmptyCassetteCnt; i++ )
        {
            PPT_METHODTRACE_V2("","-------------------------------round[i]", i);
            PPT_METHODTRACE_V2("","  CassetteID", useEmptyCassetteIDSeq[i].identifier);
            PPT_METHODTRACE_V2("","  LoadPortID", useAssignEmptyCassettePortSeq[i].identifier);
            strStartCassette[ nSetStart + i ].cassetteID = useEmptyCassetteIDSeq[i];
//P5100073            strStartCassette[ nSetStart + i ].loadPortID = useAssignEmptyCassettePortSeq[i];
//P5100073 start
            strStartCassette[ nSetStart + i ].loadPortID = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[ nSetPortIdx ].portID;
            nSetPortIdx++;
            if ( nSetPortIdx > nCanBeUsedPortCount - 1 )
            {
                 nSetPortIdx = 0;
            }
//P5100073 end
            strStartCassette[ nSetStart + i ].loadPurposeType = CIMFWStrDup( SP_LoadPurposeType_EmptyCassette );
        }
//D4000184 end

//D4000184        for ( i=0; i < nUsedEmptyCassetteCount; i++ )
//D4000184        {
//D4000184            // There must not be this error here
//D4000184            if ( nCanBeUsedEmptyCassetteCount < i )
//D4000184            {
//D4000184                PPT_METHODTRACE_V1("","##### There must not be this error here <<<RC_NOT_FOUND_EMPTYCAST>>> !?!?!?!?!?!?!?!?!?");
//D4000184                SET_MSG_RC( strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
//D4000184                            MSG_NOT_FOUND_EMPTYCAST,
//D4000184                            RC_NOT_FOUND_EMPTYCAST );
//D4000184                return RC_NOT_FOUND_EMPTYCAST;
//D4000184            }
//D4000184
//D4000184            strStartCassette[ nSetStart + i ].cassetteID = strCassetteList_emptyAvailable_Pickup_out.strFoundCassette[i].cassetteID;
//D4000184            strStartCassette[ nSetStart + i ].loadPurposeType = CIMFWStrDup( SP_LoadPurposeType_EmptyCassette );
//D4000184        }

        /*-----------------------------------------------*/
        /*   Set Total SequenceLength of StartCassette   */
        /*-----------------------------------------------*/
        PPT_METHODTRACE_V1("","/*-----------------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   Set Total SequenceLength of StartCassette   */");
        PPT_METHODTRACE_V1("","/*-----------------------------------------------*/");
        strStartCassette.length( processRunCount + nAssignEmptyCassetteCnt );
        PPT_METHODTRACE_V2("","Total(ProcessLot + EmptyCasstte) strStartCassette.length----->", processRunCount + nAssignEmptyCassetteCnt);

        /*--------------------------------------------*/
        /*   loadSequenceNumber is set again from 1   */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("","/*--------------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   loadSequenceNumber is set again from 1   */");
        PPT_METHODTRACE_V1("","/*--------------------------------------------*/");
        for ( i=0; i < processRunCount + nAssignEmptyCassetteCnt; i++ )
        {
            strStartCassette[i].loadSequenceNumber = i + 1;
        }

//D8000024 add start
//D9000001        CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
        CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) ); //D9000001
        if( 1 == tmpFPCAdoptFlag )
        {
            PPT_METHODTRACE_V1("","FPC Adopt Flag is ON. Now apply FPCInfo.");
            objFPCStartCassetteInfo_Exchange_out  strFPCStartCassetteInfo_Exchange_out;
            rc = FPCStartCassetteInfo_Exchange( strFPCStartCassetteInfo_Exchange_out,
                                                strObjCommonIn,
                                                SP_FPC_ExchangeType_StartReserveInfo,
                                                equipmentID,
                                                strStartCassette );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("","FPCStartCassetteInfo_Exchange() != RC_OK", rc);
                strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strResult = strFPCStartCassetteInfo_Exchange_out.strResult;
                return rc;
            }

            strStartCassette = strFPCStartCassetteInfo_Exchange_out.strStartCassette;
        }
        else
        {
            PPT_METHODTRACE_V1("","FPC Adopt Flag is OFF.");
        }
//D8000024 add end

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Set Return Struct                                                                                        */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  Set Return Struct                                                       */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out.strStartCassette = strStartCassette;

        PPT_METHODTRACE_V1("","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        PPT_METHODTRACE_V1("","@@@@@ Normal End.");
        PPT_METHODTRACE_V1("","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");




PPT_METHODTRACE_V1("","******************** DEBUG TRACE StartCassette start ********************");
CORBA::Long lenStartCassette = strStartCassette.length();
PPT_METHODTRACE_V2("","strStartCassette.length", lenStartCassette);
for ( i=0; i < lenStartCassette; i++ )
{
    PPT_METHODTRACE_V2("", "--------------------------------------------round[i]",i);
    PPT_METHODTRACE_V2("", "[cassetteID        ]" , strStartCassette[i].cassetteID.identifier );
    PPT_METHODTRACE_V2("", "[loadSequenceNumber]" , strStartCassette[i].loadSequenceNumber );
    PPT_METHODTRACE_V2("", "[loadPurposeType   ]" , strStartCassette[i].loadPurposeType );
    PPT_METHODTRACE_V2("", "[loadPortID        ]" , strStartCassette[i].loadPortID.identifier );

    CORBA::Long nLotInCassetteLen = strStartCassette[i].strLotInCassette.length();
    for ( j=0; j < nLotInCassetteLen; j++ )
    {
        PPT_METHODTRACE_V2("", "**[lotID              ]" , strStartCassette[i].strLotInCassette[j].lotID.identifier );
        PPT_METHODTRACE_V2("", "  [lotType            ]" , strStartCassette[i].strLotInCassette[j].lotType);
        PPT_METHODTRACE_V2("", "  [subLotType         ]" , strStartCassette[i].strLotInCassette[j].subLotType );
//D9000001        PPT_METHODTRACE_V2("", "  [operationStartFlag ]" , (long)strStartCassette[i].strLotInCassette[j].operationStartFlag );
//D9000001        PPT_METHODTRACE_V2("", "  [monitorLotFlag     ]" , (long)strStartCassette[i].strLotInCassette[j].monitorLotFlag );
        PPT_METHODTRACE_V2("", "  [operationStartFlag ]" , (int)strStartCassette[i].strLotInCassette[j].operationStartFlag ); //D9000001
        PPT_METHODTRACE_V2("", "  [monitorLotFlag     ]" , (int)strStartCassette[i].strLotInCassette[j].monitorLotFlag ); //D9000001
        PPT_METHODTRACE_V2("", "  [waferCount         ]" , strStartCassette[i].strLotInCassette[j].strLotWafer.length() );
    }
}
PPT_METHODTRACE_V1("","******************** DEBUG TRACE StartCassette end ********************");

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out, whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq, methodName);
}
