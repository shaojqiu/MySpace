//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptmgr.hpp"
#include "pportrs.hh"
#include "pcas.hh"
#include "ppcdr.hh"

CORBA::Long CS_PPTManager_i::cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer
(
    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out&         strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
    const pptObjCommonIn&                                                               strObjCommonIn,
    const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in&    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in
)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "CS_PPTManager_i::cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer" );

        //--------------//
        //  Initialize  //
        //--------------//
        CORBA::Long rc = RC_OK;

        const csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in& strInParm = strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in;

        //Trace InParameters
        PPT_METHODTRACE_V2("", "in-parm operation       ", strInParm.operation);
        PPT_METHODTRACE_V2("", "in-parm equipmentID     ", strInParm.equipmentID.identifier);
        PPT_METHODTRACE_V2("", "in-parm durableCategory ", strInParm.durableCategory);

        const char* durableCategory = strInParm.durableCategory;
        if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
         && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
         && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
        {
            PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
            PPT_SET_MSG_RC_KEY( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                MSG_INVALID_DURABLE_CATEGORY,
                                RC_INVALID_DURABLE_CATEGORY,
                                durableCategory );
            return RC_INVALID_DURABLE_CATEGORY ;
        }

        CORBA::ULong durableLen = strInParm.strStartDurables.length();
        CORBA::ULong durableCnt = 0;

        PPT_METHODTRACE_V2("", "strStartDurables.length", durableLen);

        //---------------------------------
        //  Get Eqp Internal Buffer Info
        //---------------------------------
        PPT_METHODTRACE_V1("", "Get Internal Buffer Information.");
        objEquipment_internalBufferInfo_Get_out strEquipment_internalBufferInfo_Get_out;
        rc = equipment_internalBufferInfo_Get( strEquipment_internalBufferInfo_Get_out,
                                               strObjCommonIn,
                                               strInParm.equipmentID );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "equipment_internalBufferInfo_Get() != RC_OK", rc);
            strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strEquipment_internalBufferInfo_Get_out.strResult;
            return rc;
        }

        //---------------------------//
        //  Get equipment port info  //
        //---------------------------//
        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                     strObjCommonIn,
                                     strInParm.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_portInfo_Get() != RC_OK", rc)
            strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strEquipment_portInfo_Get_out.strResult;
            return rc;
        }

        CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        PPT_METHODTRACE_V2("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length", lenEqpPort);

        //---------------------------//
        //  Main check               //
        //---------------------------//
        if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) )
        {
            PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation");

            if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
            {
                PPT_METHODTRACE_V1("", "durableCategory is Cassette");

                PosMachine_var aMachine;
                PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                                 strInParm.equipmentID,
                                                 strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                 cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer );

                /*----------------------------------------------------*/
                /*   Check each port state                            */
                /*----------------------------------------------------*/
                for ( CORBA::Long indI = 0; indI < lenEqpPort; indI++ )
                {
                    /*----------------------------------------*/
                    /*   Ignore Port which hasn't been used   */
                    /*----------------------------------------*/
                    PPT_METHODTRACE_V1("", "Ignore Port which hasn't been used");

                    CORBA::Boolean bFoundPort = FALSE;
                    for ( durableCnt = 0; durableCnt < durableLen; durableCnt++ )
                    {
                        if ( 0 == CIMFWStrCmp(strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indI].portID.identifier) )
                        {
                            PPT_METHODTRACE_V2("", "Found Port in StartDurables", strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier);
                            bFoundPort = TRUE;
                            break;
                        }
                    }

                    if ( FALSE == bFoundPort )
                    {
                        PPT_METHODTRACE_V1("", "Not Found Port in StartCassette!!  ...<<<continue>>");
                        continue;
                    }

                    /*-----------------------------------*/
                    /*   Get and Check Port's LoadMode   */
                    /*-----------------------------------*/
                    PPT_METHODTRACE_V1("","Get and Check Port's LoadMode");

                    PortResource_var aPs;
                    PosPortResource_var aPort;
                    PPT_CONVERT_PORTID_TO_PORTRESOURCE_OR( aMachine,
                                                           aPs,
                                                           strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indI].portID,
                                                           strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                           cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer );
                    aPort = PosPortResource::_narrow(aPs);

                    CORBA::String_var loadMode;
                    try
                    {
                        loadMode = aPort->getPortUsage();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getPortUsage)
                    PPT_METHODTRACE_V2("", "loadMode", loadMode);

                    if ( 0 == CIMFWStrCmp(loadMode, CIMFW_PortRsc_Input)
                      || 0 == CIMFWStrCmp(loadMode, CIMFW_PortRsc_InputOutput) )
                    {
                        PPT_METHODTRACE_V1("", "loadMode = CIMFW_PortRsc_Input and loadMode = CIMFW_PortRsc_InputOutput")
                        rc = RC_OK;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "##### return RC_INVALID_PORT_LOADMODE");
                        SET_MSG_RC( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                    MSG_INVALID_PORT_LOADMODE,
                                    RC_INVALID_PORT_LOADMODE );

                        return RC_INVALID_PORT_LOADMODE;
                    }
                    
                    /*-----------------------------------------*/
                    /*   Get Equipment's Operation Mode Info   */
                    /*-----------------------------------------*/
                    objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
                    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                                strObjCommonIn,
                                                                strInParm.equipmentID,
                                                                strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "portResource_currentOperationMode_Get() != RC_OK", rc);
                        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
                        return rc;
                    }

                    /*-------------------------------------*/
                    /*   Get and Check Port's Port State   */
                    /*-------------------------------------*/
                    PPT_METHODTRACE_V1("","Get and Check Port's Port State");

                    if ( 0 != CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode,
                                          SP_Eqp_OnlineMode_Offline) )
                    {
                        PPT_METHODTRACE_V1("", "onlineMode = [Offline]");

                        if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indI].portState,
                                              SP_PortRsc_PortState_LoadAvail)
                          || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indI].portState,
                                              SP_PortRsc_PortState_LoadReq)
                          || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indI].portState,
                                              SP_PortRsc_PortState_LoadComp) )
                        {
                            PPT_METHODTRACE_V1("", "portState == [LoadAvail] or [LoadReq] or [LoadComp]")
                            rc = RC_OK;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "##### return RC_INVALID_PORT_STATE");
                            PPT_SET_MSG_RC_KEY2( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                 MSG_INVALID_PORT_STATE,
                                                 RC_INVALID_PORT_STATE,
                                                 strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indI].portID.identifier,
                                                 strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indI].portState );
                            return RC_INVALID_PORT_STATE;
                        }
                    }
                }

                /*----------------------------------------------------*/
                /*   Check All OperationMode of PortID is the same    */
                /*----------------------------------------------------*/
                objectIdentifier operationModeID;
                for ( durableCnt = 0; durableCnt < durableLen; durableCnt++ )
                {
                    CORBA::Boolean bFoundPort = FALSE;

                    for ( CORBA::Long indJ = 0; indJ < lenEqpPort; indJ++ )
                    {
                        // found the same portID in strEquipment_portInfo_Get_out
                        if ( 0 == CIMFWStrCmp(strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indJ].portID.identifier) )
                        {
                            PPT_METHODTRACE_V2("","find loadPortID", strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier);
                            bFoundPort = TRUE;
                            break;
                        }
                    }

                    if ( TRUE == bFoundPort )
                    {
                        PPT_METHODTRACE_V1("","TRUE == bFoundPort");

                        if ( 0 == durableCnt )
                        {
                            operationModeID = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indJ].operationModeID;
                            PPT_METHODTRACE_V2("", "0 == i   operationModeID", operationModeID.identifier);
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "0 != i");

                            if ( 0 != CIMFWStrCmp(operationModeID.identifier,
                                                  strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indJ].operationModeID.identifier) )
                            {
                                PPT_METHODTRACE_V2("", "not same operationModeID!!", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indJ].operationModeID.identifier);
                                PPT_SET_MSG_RC_KEY2( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                     MSG_INVALID_EQP_MODE,
                                                     RC_INVALID_EQP_MODE,
                                                     strInParm.equipmentID.identifier,
                                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[indJ].operationMode );
                                return RC_INVALID_EQP_MODE;
                            }
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "##### Not found PortID !?!?!?");
                        PPT_SET_MSG_RC_KEY( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                            MSG_NOT_FOUND_PORT,
                                            RC_NOT_FOUND_PORT,
                                            strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier );
                        return RC_NOT_FOUND_PORT;
                    }
                }
            }
            else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
            {
                PPT_METHODTRACE_V1("", "durableCategory is ReticlePod");

                /*---------------------------------------------------------*/
                /*    In-parm's portID must not have durableControlJobID   */
                /*---------------------------------------------------------*/
                objEquipment_reservedDurableControlJobID_GetDR_out strEquipment_reservedDurableControlJobID_GetDR_out;
                objEquipment_reservedDurableControlJobID_GetDR_in  strEquipment_reservedDurableControlJobID_GetDR_in;
                strEquipment_reservedDurableControlJobID_GetDR_in.equipmentID = strInParm.equipmentID;
                rc = equipment_reservedDurableControlJobID_GetDR( strEquipment_reservedDurableControlJobID_GetDR_out,
                                                                  strObjCommonIn,
                                                                  strEquipment_reservedDurableControlJobID_GetDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_reservedDurableControlJobID_GetDR() != RC_OK", rc)
                    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strEquipment_reservedDurableControlJobID_GetDR_out.strResult;
                    return rc;
                }

                objectIdentifierSequence reservedDurableControlJobIDs = strEquipment_reservedDurableControlJobID_GetDR_out.reservedDurableControlJobIDs;
                for ( CORBA::ULong iCnt6=0; iCnt6 < reservedDurableControlJobIDs.length(); iCnt6++ )
                {
                    PPT_METHODTRACE_V2("", "loop to reservedDurableControlJobIDs.length()", iCnt6);
                    objDurableControlJob_durableList_GetDR_out strDurableControlJob_durableList_GetDR_out;
                    objDurableControlJob_durableList_GetDR_in  strDurableControlJob_durableList_GetDR_in;
                    strDurableControlJob_durableList_GetDR_in.durableControlJobID = reservedDurableControlJobIDs[iCnt6];
                    rc = durableControlJob_durableList_GetDR( strDurableControlJob_durableList_GetDR_out,
                                                              strObjCommonIn,
                                                              strDurableControlJob_durableList_GetDR_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "durableControlJob_durableList_GetDR() != RC_OK", rc)
                        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strDurableControlJob_durableList_GetDR_out.strResult;
                        return rc;
                    }

                    pptStartDurableSequence startDurables = strDurableControlJob_durableList_GetDR_out.strStartDurables;
                    for ( CORBA::ULong iCnt7=0; iCnt7 < startDurables.length(); iCnt7++ )
                    {
                        PPT_METHODTRACE_V2("", "loop to startDurables.length()", iCnt7);
                        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
                            if ( 0 == CIMFWStrCmp(startDurables[iCnt7].strStartDurablePort.loadPortID.identifier,
                                                  strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "LoadPort already has reserved DurableControlJob.");
                                PPT_SET_MSG_RC_KEY( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                    MSG_ALREADY_RESERVED_DCTRLJOB,
                                                    RC_ALREADY_RESERVED_DCTRLJOB,
                                                    startDurables[iCnt7].strStartDurablePort.loadPortID.identifier );
                                return RC_ALREADY_RESERVED_DCTRLJOB;
                            }
                        }
                    }
                }

                /*-----------------------------------------*/
                /*   Get Equipment's Operation Mode Info   */
                /*-----------------------------------------*/
                objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
                rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out,
                                               strObjCommonIn,
                                               strInParm.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
                    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strEquipment_onlineMode_Get_out.strResult;
                    return rc;
                }

                objEquipment_reticlePodPortInfo_GetDR_out strEquipment_reticlePodPortInfo_GetDR_out;
                rc = equipment_reticlePodPortInfo_GetDR( strEquipment_reticlePodPortInfo_GetDR_out,
                                                         strObjCommonIn,
                                                         strInParm.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_reticlePodPortInfo_GetDR() != RC_OK", rc);
                    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strEquipment_reticlePodPortInfo_GetDR_out.strResult;
                    return rc;
                }

                CORBA::String_var accessMode;
                CORBA::ULong rppLen = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length();
                for ( CORBA::ULong iCnt9=0; iCnt9 < rppLen; iCnt9++ )
                {
                    PPT_METHODTRACE_V2("", "loop to strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length()", iCnt9);
                    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
                    {
                        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
                        if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].reticlePodPortID.identifier,
                                              strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "Reticle Pod Port found.");

                            /*-----------------------------*/
                            /*   Check Port's Port State   */
                            /*-----------------------------*/
                            if ( 0 != CIMFWStrCmp(strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline) )
                            {
                                PPT_METHODTRACE_V1("", "strEquipment_onlineMode_Get_out.onlineMode != SP_Eqp_OnlineMode_Offline")

                                if ( 0 != CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].portStatus, SP_PortRsc_PortState_LoadAvail)
                                  && 0 != CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].portStatus, SP_PortRsc_PortState_LoadReq) )
                                {
                                    PPT_METHODTRACE_V1("", "portState must be SP_PortRsc_PortState_LoadAvail or SP_PortRsc_PortState_LoadReq")
                                    PPT_SET_MSG_RC_KEY2( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                         MSG_INVALID_PORT_STATE,
                                                         RC_INVALID_PORT_STATE,
                                                         strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].reticlePodPortID.identifier,
                                                         strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].portStatus );
                                    return RC_INVALID_PORT_STATE;
                                }
                            }

                            /*-----------------------------------------------------------*/
                            /*    In-Parm's load port must not have loadedReticlePodID   */
                            /*-----------------------------------------------------------*/
                            if ( 0 != CIMFWStrLen(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].loadedReticlePodID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "Another reticlePod is already loaded on the specified port.");
                                if ( 0 != CIMFWStrCmp(strInParm.strStartDurables[durableCnt].durableID.identifier, strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].loadedReticlePodID.identifier) )
                                {
                                    SET_MSG_RC( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                MSG_PORT_HAS_LOADED_RETICLEPOD,
                                                RC_PORT_HAS_LOADED_RETICLEPOD );
                                    return RC_PORT_HAS_LOADED_RETICLEPOD;
                                }
                            }

                            /*--------------------------------------------------------------*/
                            /*    accessMode of all In-Parm's load ports must be the same   */
                            /*--------------------------------------------------------------*/
                            if ( 0 == CIMFWStrLen(accessMode) )
                            {
                                PPT_METHODTRACE_V2("", "Set accessMode", accessMode);
                                accessMode = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].accessMode;
                            }
                            else if ( 0 != CIMFWStrCmp(accessMode, strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].accessMode) )
                            {
                                PPT_METHODTRACE_V1("", "accessMode is different");
                                PPT_SET_MSG_RC_KEY2( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                     MSG_INVALID_PORT_ACCESSMODE,
                                                     RC_INVALID_PORT_ACCESSMODE,
                                                     strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].reticlePodPortID.identifier,
                                                     strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt9].accessMode );
                                return RC_INVALID_PORT_ACCESSMODE;
                            }

                            break;
                        }
                    }
                }
            }
        }
        else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
        {
            PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");

            if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
            {
                PPT_METHODTRACE_V1("", "durableCategory is Cassette");

                for ( durableCnt = 0; durableCnt < durableLen; durableCnt++ )
                {
                    CORBA::String_var eqpInfoLoadPurposeType;

                    //-----------------------------------
                    //  Find Internal Buffer Info
                    //-----------------------------------
                    //  Loop of Buffer Category
                    CORBA::Boolean bCassetteFoundInBuffer = FALSE;

                    CORBA::Long nBufferCategoryLen = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo.length();
                    PPT_METHODTRACE_V2("", "nBufferCategoryLen", nBufferCategoryLen);

                    for (CORBA::Long bi = 0; bi < nBufferCategoryLen; bi++) // 'bi' Buffer-i
                    {
                        CORBA::Long nShelfLen = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[bi].strShelfInBuffer.length();
                        PPT_METHODTRACE_V3("", "nShelfLen", bi, nShelfLen);

                        // Loop of Cassette in Buffer
                        for (CORBA::Long bj = 0; bj < nShelfLen; bj++) // 'bj' Buffer-j
                        {
                            if (CIMFWStrCmp( strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[bi].strShelfInBuffer[bj].loadedCarrierID.identifier) == 0)
                            {
                                PPT_METHODTRACE_V1("", "Input cassette was found in Internal Buffer of equipment.");
                                bCassetteFoundInBuffer = TRUE;

                                // set LoadPurposeType for Internal Bufer Category
                                eqpInfoLoadPurposeType = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[bi].bufferCategory;
                                break;
                            }
                        }
                    }

                    if (bCassetteFoundInBuffer == FALSE)
                    {
                        PPT_METHODTRACE_V1("", "bCassetteFoundInBuffer == FALSE");
                        SET_MSG_RC( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out, MSG_INVALID_CAST_PORT_COMBINATION, RC_INVALID_CAST_PORT_COMBINATION );
                        return RC_INVALID_CAST_PORT_COMBINATION;
                    }

                    /*------------------------------------------------------------*/
                    /*    Check Eqp Port's LoadPurpose VS In-Parm's LoadPurpose   */
                    /*------------------------------------------------------------*/
                    if (CIMFWStrCmp( eqpInfoLoadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
                    {
                        PPT_METHODTRACE_V1("", "eqpInfoLoadPurposeType == SP_LoadPurposeType_EmptyCassette");
                        rc = RC_OK;
                    }
                    else if (CIMFWStrCmp( eqpInfoLoadPurposeType, SP_LoadPurposeType_Any ) == 0)
                    {
                        PPT_METHODTRACE_V1("", "eqpInfoLoadPurposeType == SP_LoadPurposeType_Any");

                        if (CIMFWStrCmp( strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
                        {
                            PPT_METHODTRACE_V1("", "strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPurposeType == SP_LoadPurposeType_EmptyCassette");
                            rc = RC_OK;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPurposeType != SP_LoadPurposeType_EmptyCassette");
                            PPT_SET_MSG_RC_KEY4( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                 MSG_NOT_SAME_LOAD_PURPOSE,
                                                 RC_NOT_SAME_LOAD_PURPOSE,
                                                 strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                 strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPurposeType,
                                                 strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                                 eqpInfoLoadPurposeType );
                            return RC_NOT_SAME_LOAD_PURPOSE;
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "eqpInfoLoadPurposeType != SP_LoadPurposeType_Any, SP_LoadPurposeType_EmptyCassette");
                        PPT_SET_MSG_RC_KEY4( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                             MSG_NOT_SAME_LOAD_PURPOSE,
                                             RC_NOT_SAME_LOAD_PURPOSE,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPurposeType,
                                             strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                             eqpInfoLoadPurposeType );
                        return RC_NOT_SAME_LOAD_PURPOSE;
                    }
                }
            }
            else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
            {
                PPT_METHODTRACE_V1("", "durableCategory is ReticlePod");

                /*-----------------------------------------*/
                /*   Get Equipment's Operation Mode Info   */
                /*-----------------------------------------*/
                objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
                rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out,
                                               strObjCommonIn,
                                               strInParm.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
                    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strEquipment_onlineMode_Get_out.strResult;
                    return rc;
                }

                objEquipment_reticlePodPortInfo_GetDR_out strEquipment_reticlePodPortInfo_GetDR_out;
                rc = equipment_reticlePodPortInfo_GetDR( strEquipment_reticlePodPortInfo_GetDR_out,
                                                         strObjCommonIn,
                                                         strInParm.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_reticlePodPortInfo_GetDR() != RC_OK", rc);
                    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strEquipment_reticlePodPortInfo_GetDR_out.strResult;
                    return rc;
                }

                CORBA::ULong rppLen = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length();
                for ( CORBA::ULong iCnt3=0; iCnt3 < rppLen; iCnt3++ )
                {
                    PPT_METHODTRACE_V2("", "loop to strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length()", iCnt3);
                    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
                    {
                        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
                        if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt3].reticlePodPortID.identifier,
                                              strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "Reticle Pod Port found.");

                            /*-----------------------------*/
                            /*   Check Port's Port State   */
                            /*-----------------------------*/
                            if ( 0 != CIMFWStrCmp(strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline) )
                            {
                                PPT_METHODTRACE_V1("", "strEquipment_onlineMode_Get_out.onlineMode != SP_Eqp_OnlineMode_Offline")

                                if ( 0 != CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt3].portStatus, SP_PortRsc_PortState_LoadComp) )
                                {
                                    PPT_METHODTRACE_V1("", "portState must be SP_PortRsc_PortState_LoadComp")
                                    PPT_SET_MSG_RC_KEY2( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                         MSG_INVALID_PORT_STATE,
                                                         RC_INVALID_PORT_STATE,
                                                         strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt3].reticlePodPortID.identifier,
                                                         strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt3].portStatus );
                                    return RC_INVALID_PORT_STATE;
                                }
                            }

                            /*------------------------------------------------------------------------*/
                            /*    Check In-Parm's reticlePod/load port vs Port's loadedReticlePodID   */
                            /*------------------------------------------------------------------------*/
                            if ( 0 != CIMFWStrCmp(strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                  strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt3].loadedReticlePodID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "Input reticle pod is different from current loaded reticle pod on equipment/port");
                                PPT_SET_MSG_RC_KEY4( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                     MSG_RTCLPOD_LOADED_RTCLPOD,
                                                     RC_RTCLPOD_LOADED_RTCLPOD,
                                                     strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                     strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt3].loadedReticlePodID.identifier,
                                                     strInParm.equipmentID.identifier,
                                                     strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt3].reticlePodPortID.identifier);
                                return RC_RTCLPOD_LOADED_RTCLPOD;
                            }

                            break;
                        }
                    }
                }
            }
        }
        else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OperationComp) )
        {
            PPT_METHODTRACE_V1("", "operation == SP_Operation_OperationComp");
            if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
            {
                PPT_METHODTRACE_V1("", "durableCategory is Cassette");

                for ( durableCnt = 0; durableCnt < durableLen; durableCnt++ )
                {
                    CORBA::String_var eqpInfoLoadPurposeType;

                    //-----------------------------------
                    //  Find Internal Buffer Info
                    //-----------------------------------
                    //  Loop of Buffer Category
                    CORBA::Boolean bCassetteFoundInBuffer = FALSE;

                    CORBA::Long nBufferCategoryLen = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo.length();
                    PPT_METHODTRACE_V2("", "nBufferCategoryLen", nBufferCategoryLen);

                    for (CORBA::Long bi = 0; bi < nBufferCategoryLen; bi++) // 'bi' Buffer-i
                    {
                        CORBA::Long nShelfLen = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[bi].strShelfInBuffer.length();
                        PPT_METHODTRACE_V3("", "nShelfLen", bi, nShelfLen);

                        // Loop of Cassette in Buffer
                        for (CORBA::Long bj = 0; bj < nShelfLen; bj++) // 'bj' Buffer-j
                        {
                            if (CIMFWStrCmp( strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[bi].strShelfInBuffer[bj].loadedCarrierID.identifier) == 0)
                            {
                                PPT_METHODTRACE_V1("", "Input cassette was found in Internal Buffer of equipment.");
                                bCassetteFoundInBuffer = TRUE;

                                // set LoadPurposeType for Internal Bufer Category
                                eqpInfoLoadPurposeType = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[bi].bufferCategory;
                                break;
                            }
                        }
                    }

                    if (bCassetteFoundInBuffer == FALSE)
                    {
                        PPT_METHODTRACE_V1("", "bCassetteFoundInBuffer == FALSE");
                        SET_MSG_RC( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out, MSG_INVALID_CAST_PORT_COMBINATION, RC_INVALID_CAST_PORT_COMBINATION );
                        return RC_INVALID_CAST_PORT_COMBINATION;
                    }
                }
            }
            else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
            {
                PPT_METHODTRACE_V1("", "durableCategory is ReticlePod");

                /*------------------------------------*/
                /*   Get reticlePodPort Information   */
                /*------------------------------------*/
                objEquipment_reticlePodPortInfo_GetDR_out strEquipment_reticlePodPortInfo_GetDR_out;
                rc = equipment_reticlePodPortInfo_GetDR( strEquipment_reticlePodPortInfo_GetDR_out,
                                                         strObjCommonIn,
                                                         strInParm.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_reticlePodPortInfo_GetDR() != RC_OK", rc);
                    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult = strEquipment_reticlePodPortInfo_GetDR_out.strResult;
                    return rc;
                }

                /*----------------------------------------*/
                /*   For-Loop for strStartDurables Info   */
                /*----------------------------------------*/
                for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
                {
                    PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
                    /*-------------------------*/
                    /*   Find Specified Port   */
                    /*-------------------------*/
                    CORBA::Boolean findFlag = FALSE;
                    CORBA::ULong rppLen = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length();
                    for ( CORBA::ULong iCnt2=0; iCnt2 < rppLen; iCnt2++)
                    {
                        PPT_METHODTRACE_V2("", "loop to strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length()", iCnt2);
                        CORBA::String_var RPPIdent;
                        CORBA::String_var PIDIdent;
                        RPPIdent = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt2].reticlePodPortID.identifier;
                        PIDIdent = strInParm.strStartDurables[durableCnt].strStartDurablePort.unloadPortID.identifier;
                        if ( 0 == CIMFWStrCmp(RPPIdent, PIDIdent) )
                        {
                            PPT_METHODTRACE_V1("", "0 == CIMFWStrCmp(RPPIdent, PIDIdent)");
                            findFlag = TRUE;
                            break;
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");
                        PPT_SET_MSG_RC_KEY( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                            MSG_NOT_FOUND_PORT,
                                            RC_NOT_FOUND_PORT,
                                            strInParm.strStartDurables[durableCnt].strStartDurablePort.unloadPortID.identifier );
                        return RC_NOT_FOUND_PORT;
                    }

                    /*------------------------*/
                    /*   Compare CassetteID   */
                    /*------------------------*/
                    CORBA::String_var RPPIdent;
                    CORBA::String_var CIDIdent;
                    RPPIdent = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[iCnt2].loadedReticlePodID.identifier;
                    CIDIdent = strInParm.strStartDurables[durableCnt].durableID.identifier;
                    if ( 0 != CIMFWStrCmp(RPPIdent, CIDIdent) )
                    {
                        PPT_METHODTRACE_V1("", "0 != CIMFWStrCmp(RPPIdent, CIDIdent)");
                        SET_MSG_RC( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                    MSG_INVALID_RETICLEPOD_PORT_COMBINATION,
                                    RC_INVALID_RETICLEPOD_PORT_COMBINATION );
                        return RC_INVALID_RETICLEPOD_PORT_COMBINATION;
                    }
                }
            }
        }

        if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OperationComp)
          || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservationCancel)
          || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStartCancel) )
        {
            PPT_METHODTRACE_V2("", "operation is ", strInParm.operation);

            for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
                PosDurableControlJob_var aDurableControlJob;
                if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory is Cassette");
                    PosCassette_var aCassette;
                    PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                           strInParm.strStartDurables[durableCnt].durableID,
                                                           strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                           cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer );

                    try
                    {
                        aDurableControlJob = aCassette->getDurableControlJob();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableControlJob)
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory is ReticlePod");
                    PosReticlePod_var aReticlePod;
                    PPT_CONVERT_RETICLEPODID_TO_RETICLEPOD_OR( aReticlePod,
                                                               strInParm.strStartDurables[durableCnt].durableID,
                                                               strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                               cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer );

                    try
                    {
                        aDurableControlJob = aReticlePod->getDurableControlJob();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableControlJob)
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory is Reticle");
                    PosProcessDurable_var aReticle;
                    PPT_CONVERT_RETICLEID_TO_RETICLE_OR( aReticle,
                                                         strInParm.strStartDurables[durableCnt].durableID,
                                                         strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                         cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer );

                    try
                    {
                        aDurableControlJob = aReticle->getDurableControlJob();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableControlJob)
                }

                if ( TRUE == CORBA::is_nil(aDurableControlJob) )
                {
                    PPT_METHODTRACE_V1("", "aDurableControlJob is nil");
                    SET_MSG_RC( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                MSG_DURABLECTRLJOBID_BLANK,
                                RC_DURABLECTRLJOBID_BLANK );
                    return RC_DURABLECTRLJOBID_BLANK;
                }

                PosMachine_var aDurableMachine;
                try
                {
                    aDurableMachine = aDurableControlJob->getMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosDurableControlJob::getMachine)

                if ( TRUE == CORBA::is_nil(aDurableMachine) )
                {
                    PPT_METHODTRACE_V1("", "##### aDurableMachine is Nil");
                    PPT_SET_MSG_RC_KEY( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                        MSG_NOT_FOUND_EQP,
                                        RC_NOT_FOUND_EQP,
                                        "*****" );
                    return RC_NOT_FOUND_EQP;
                }

                objectIdentifier durableEquipmentID;
                PPT_SET_OBJECT_IDENTIFIER( durableEquipmentID,
                                           aDurableMachine,
                                           strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                           cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer,
                                           PosMachine );

                if ( 0 != CIMFWStrCmp(strInParm.equipmentID.identifier, durableEquipmentID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "The equipment could not be found from Durable Control Job");
                    PPT_SET_MSG_RC_KEY( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                        MSG_NOT_FOUND_EQP_FROM_DCTRLJOB,
                                        RC_NOT_FOUND_EQP_FROM_DCTRLJOB,
                                        "*****" );
                    return RC_NOT_FOUND_EQP_FROM_DCTRLJOB;
                }
            }
        }

        //--------------------//
        //  Return to Caller  //
        //--------------------//
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out, cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer, methodName );
}
