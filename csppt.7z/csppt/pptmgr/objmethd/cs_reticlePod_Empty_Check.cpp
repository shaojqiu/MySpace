//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_reticlePod_Empty_Check.cpp
//

#include "cs_pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"
#include "ppcdr.hh"
#include "ppcdrcp.hh"
#include "pperson.hh"
#include "pmc.hh"
#include "pstmc.hh"
#include "pperson.hh"
#include "pbufrs.hh"
#include "pdrmggl.hh"
#include "mtrllctn.hh"

// Class: CS_PPTManager
//
// Service: cs_reticlePod_Empty_Check()
//
// Change history:
// Date       Defect#       Person        Comments
// ---------- --------      ------------- -------------------------------------------
// 2017/09/14 INN-R170003   Joan Zhou     INN-R170003:Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    csObjReticlePod_Empty_Check_out&        strObjReticlePod_Empty_Check_out,
//    const pptObjCommonIn&                   strObjCommonIn,
//    csObjReticlePod_Empty_Check_in&         strObjReticlePod_Empty_Check_in,
//
//    typedef struct csObjReticlePod_Empty_Check_out_struct {
//        pptRetCode              strResult;
//        boolean                 isEmpty;
//        any                     siInfo;
//    }  csObjReticlePod_Empty_Check_out;
//    
//    typedef struct csObjReticlePod_Empty_Check_in_struct {
//        objectIdentifier        reticlePodID;
//        any                     siInfo;
//    }  csObjReticlePod_Empty_Check_in;
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_reticlePod_Empty_Check(
    csObjReticlePod_Empty_Check_out&      strObjReticlePod_Empty_Check_out,
    const pptObjCommonIn&                 strObjCommonIn,
    csObjReticlePod_Empty_Check_in&       strObjReticlePod_Empty_Check_in)

{
    char * methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_reticlePod_Empty_Check");
        objectIdentifier reticlePodID = strObjReticlePod_Empty_Check_in.reticlePodID;
        PPT_METHODTRACE_V2("","strObjReticlePod_Empty_Check_in reticlePodID----------------->", reticlePodID.identifier );
        //------------------------------------------
        // retrieve object reference of reticlePod
        //------------------------------------------
        CORBA::Boolean reticlePodFound = FALSE;
        PosReticlePod_var aPosReticlePod;;

        PPT_CONVERT_RETICLEPODID_TO_RETICLEPOD_WITH_NO_RETURN( aPosReticlePod, reticlePodID );

        if ( reticlePodFound == FALSE )
        {
            PPT_METHODTRACE_V1("", "aPosReticlePod is not found");

            PPT_SET_MSG_RC_KEY( strObjReticlePod_Empty_Check_out,
                                MSG_NOT_FOUND_RETICLE_POD,
                                RC_NOT_FOUND_RETICLE_POD,
                                reticlePodID.identifier );

            return RC_NOT_FOUND_RETICLE_POD;
        }

        try
        {
            PPT_METHODTRACE_V1("", "aPosReticlePod is found");            
            strObjReticlePod_Empty_Check_out.isEmpty = aPosReticlePod->isEmpty();
            PPT_METHODTRACE_V2("","Reticle Empty Check----------------->", strObjReticlePod_Empty_Check_out.isEmpty );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isEmpty);

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjReticlePod_Empty_Check_out, cs_reticlePod_Empty_Check, methodName)
}


