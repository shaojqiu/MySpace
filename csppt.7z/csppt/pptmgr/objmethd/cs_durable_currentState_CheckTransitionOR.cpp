//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_durable_currentState_CheckTransitionOR.cpp
//

//INN-R170003 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"    //INN-R170003

#include "pcas.hh"
#include "prtclp.hh"
#include "ppcdr.hh"
#include "plot.hh"

// Class: CS_PPTManager
//
// Service: durable_currentState_CheckTransition()
//
// Change history:
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2016/07/25 DSN000101569 C.Mo           Durable Sub Status Control Support.
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/11/02 INN-R170003  Nick Tsai      Support Fixture
//
//[Function Description]:
//  This function check Durable Sub Status transition.
//
//[Input Parameters]:
//  const pptObjCommonIn&                             strObjCommonIn,
//  const objDurable_currentState_CheckTransition_in& strDurable_currentState_CheckTransition_in
//
//  typedef struct objDurable_currentState_CheckTransition_in_struct {
//      string                              durableCategory;                        //<i>Durable Category
//      objectIdentifier                    durableID;                              //<i>Durable ID
//      string                              durableStatus;                          //<i>Durable Status
//      objectIdentifier                    durableSubStatus;                       //<i>Durable Sub Status
//      string                              currentDurableStatus;                   //<i>Current Durable Status
//      objectIdentifier                    currentDurableSubStatus;                //<i>Current Durable Sub Status
//      any                                 siInfo;                                 //<i>Reserved for SI customization
//  } objDurable_currentState_CheckTransition_in;
//
//[Output Parameters]:
//  objDurable_currentState_CheckTransition_out&      strDurable_currentState_CheckTransition_out
//
//  typedef objBase_out objDurable_currentState_CheckTransition_out;
//
//[Return Value]:
//  Return Code                                   Messsage ID
//  -------------------------                     --------------------------------------------------
//  RC_OK                                         MSG_OK
//  RC_DURABLE_STAT_CHANGED_BY_OTHER_OPERATION    MSG_DURABLE_STAT_CHANGED_BY_OTHER_OPERATION
//  RC_DURABLE_SUBSTAT_CHANGED_BY_OTHER_OPERATION MSG_DURABLE_SUBSTAT_CHANGED_BY_OTHER_OPERATION
//  RC_DURABLE_NEW_SUBSTAT_BLANK                  MSG_DURABLE_NEW_SUBSTAT_BLANK
//  RC_SAME_DURABLE_SUBSTAT                       MSG_SAME_DURABLE_SUBSTAT
//  RC_DURABLE_STAT_SUBSTAT_UNMATCH               MSG_DURABLE_STAT_SUBSTAT_UNMATCH
//  RC_INVALID_STATE_TRANSITION                   MSG_INVALID_STATE_TRANSITION
//  RC_CAST_HAS_ANY_LOTS                          MSG_CAST_HAS_ANY_LOTS
//
//INN-R170003 CORBA::Long PPTManager_i::durable_currentState_CheckTransition(
CORBA::Long CS_PPTManager_i::durable_currentState_CheckTransition(     //INN-R170003
    objDurable_currentState_CheckTransition_out&      strDurable_currentState_CheckTransition_out,
    const pptObjCommonIn&                             strObjCommonIn,
    const objDurable_currentState_CheckTransition_in& strDurable_currentState_CheckTransition_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::durable_currentState_CheckTransition");
        CORBA::String_var currentDurableState;
        PosDurableSubState_var objectCurrentDurableSubState;
        PosCassette_var aCassette;

        //---------------------------------
        //   Get Durable status,sub-status
        //---------------------------------
        if (CIMFWStrCmp(strDurable_currentState_CheckTransition_in.durableCategory, SP_DurableCat_Cassette) == 0)
        {
            PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Cassette");

            //---------------------------------
            //   Get Cassette Object
            //---------------------------------
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strDurable_currentState_CheckTransition_in.durableID,
                                                   strDurable_currentState_CheckTransition_out,
                                                   durable_currentState_CheckTransition );

            try
            {
                currentDurableState = aCassette->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableState);

            try
            {
                objectCurrentDurableSubState = aCassette->getDurableSubState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableSubState);
        }
        else if (0 == CIMFWStrCmp(strDurable_currentState_CheckTransition_in.durableCategory, SP_DurableCat_ReticlePod))
        {
            PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_ReticlePod");

            //---------------------------------
            //   Get ReticlePod Object
            //---------------------------------
            PosReticlePod_var aReticlePod;
            PPT_CONVERT_RETICLEPODID_TO_RETICLEPOD_OR( aReticlePod,
                                                       strDurable_currentState_CheckTransition_in.durableID,
                                                       strDurable_currentState_CheckTransition_out,
                                                       durable_currentState_CheckTransition );
            CORBA::Boolean isAvailableFlag = FALSE;
            try
            {
                isAvailableFlag = aReticlePod->isAvailable();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isAvailable);

            CORBA::Boolean isInUseFlag = FALSE;
            try
            {
                isInUseFlag = aReticlePod->isInUse();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isInUse);

            CORBA::Boolean isNotAvailableFlag = FALSE;
            try
            {
                isNotAvailableFlag = aReticlePod->isNotAvailable();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isNotAvailable);

            CORBA::Boolean isScrappedFlag = FALSE;
            try
            {
                isScrappedFlag = aReticlePod->isScrapped();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isScrapped);

            if (isAvailableFlag == TRUE)
            {
                currentDurableState = CIMFWStrDup(CIMFW_Durable_Available);
            }
            else if (isInUseFlag == TRUE)
            {
                currentDurableState = CIMFWStrDup(CIMFW_Durable_InUse);
            }
            else if (isNotAvailableFlag == TRUE)
            {
                currentDurableState = CIMFWStrDup(CIMFW_Durable_NotAvailable);
            }
            else if (isScrappedFlag == TRUE)
            {
                currentDurableState = CIMFWStrDup(CIMFW_Durable_Scrapped);
            }
            else
            {
                currentDurableState = CIMFWStrDup(CIMFW_Durable_Undefined);
            }

            try
            {
                objectCurrentDurableSubState = aReticlePod->getDurableSubState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableSubState);
        }
        else if (0 == CIMFWStrCmp(strDurable_currentState_CheckTransition_in.durableCategory, SP_DurableCat_Reticle))
        {
            PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Reticle");

            //---------------------------------
            //   Get Reticle Object
            //---------------------------------
            PosProcessDurable_var aReticle;
            PPT_CONVERT_RETICLEID_TO_RETICLE_OR( aReticle,
                                                 strDurable_currentState_CheckTransition_in.durableID,
                                                 strDurable_currentState_CheckTransition_out,
                                                 durable_currentState_CheckTransition );

            try
            {
                currentDurableState = aReticle->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableState);

            try
            {
                objectCurrentDurableSubState = aReticle->getDurableSubState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableSubState);
        }
        //INN-R170003 add start
        else if (0 == CIMFWStrCmp(strDurable_currentState_CheckTransition_in.durableCategory, SP_DurableCat_Fixture))
        {
            PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Fixture");

            //---------------------------------
            //   Get Fixture Object
            //---------------------------------
            PosProcessDurable_var aFixture;
            PPT_CONVERT_FIXTUREID_TO_FIXTURE_OR( aFixture,
                                                 strDurable_currentState_CheckTransition_in.durableID,
                                                 strDurable_currentState_CheckTransition_out,
                                                 durable_currentState_CheckTransition );

            try
            {
                currentDurableState = aFixture->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableState);

            try
            {
                objectCurrentDurableSubState = aFixture->getDurableSubState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableSubState);
        }
        //INN-R170003 add end

        objectIdentifier currentDurableSubStateID;
        PPT_SET_OBJECT_IDENTIFIER( currentDurableSubStateID, objectCurrentDurableSubState,
                                   strDurable_currentState_CheckTransition_out,
                                   durable_currentState_CheckTransition,
                                   PosDurableSubState );

        PPT_METHODTRACE_V2("", "durable state ", currentDurableState);
        PPT_METHODTRACE_V2("", "durable sub-state ", currentDurableSubStateID.identifier);

        //--------------------------------------
        //   Check param's currentDurableStatus
        //--------------------------------------
        if (CIMFWStrLen(strDurable_currentState_CheckTransition_in.currentDurableStatus) > 0)
        {
            PPT_METHODTRACE_V2("", "input param's currentDurableStatus ", strDurable_currentState_CheckTransition_in.currentDurableStatus);

            if (CIMFWStrCmp(strDurable_currentState_CheckTransition_in.currentDurableStatus, currentDurableState) != 0)
            {
                PPT_METHODTRACE_V1("", "durable's status not equal input current durable status");
                PPT_SET_MSG_RC_KEY2(strDurable_currentState_CheckTransition_out,
                                    MSG_DURABLE_STAT_CHANGED_BY_OTHER_OPERATION,
                                    RC_DURABLE_STAT_CHANGED_BY_OTHER_OPERATION,
                                    strDurable_currentState_CheckTransition_in.durableID.identifier,
                                    currentDurableState);
                return RC_DURABLE_STAT_CHANGED_BY_OTHER_OPERATION;
            }
        }

        //----------------------------------------
        //   Check param's currentDurableSubStatus
        //----------------------------------------
        if (CIMFWStrLen(strDurable_currentState_CheckTransition_in.currentDurableSubStatus.identifier) > 0)
        {
            PPT_METHODTRACE_V2("", "input param's currentDurableSubStatus ", strDurable_currentState_CheckTransition_in.currentDurableSubStatus.identifier);

            if (CIMFWStrCmp(strDurable_currentState_CheckTransition_in.currentDurableSubStatus.identifier, currentDurableSubStateID.identifier) != 0)
            {
                PPT_METHODTRACE_V1("", "durable's sub-status is not equal to input current durable sub-status");
                PPT_SET_MSG_RC_KEY2(strDurable_currentState_CheckTransition_out,
                                    MSG_DURABLE_SUBSTAT_CHANGED_BY_OTHER_OPERATION,
                                    RC_DURABLE_SUBSTAT_CHANGED_BY_OTHER_OPERATION,
                                    strDurable_currentState_CheckTransition_in.durableID.identifier,
                                    currentDurableSubStateID.identifier);
                return RC_DURABLE_SUBSTAT_CHANGED_BY_OTHER_OPERATION;
            }
        }

        //--------------------------------------
        //   Check param's durableSubStatus
        //--------------------------------------
        if (CIMFWStrLen(strDurable_currentState_CheckTransition_in.durableSubStatus.identifier) == 0)
        {
            PPT_METHODTRACE_V1("", "input param's durableSubStatus is blank");

            if (CORBA::is_nil(objectCurrentDurableSubState) != TRUE)
            {
                PPT_METHODTRACE_V1("", "durable's sub-status is not nil");
                SET_MSG_RC(strDurable_currentState_CheckTransition_out, MSG_DURABLE_NEW_SUBSTAT_BLANK, RC_DURABLE_NEW_SUBSTAT_BLANK);
                return RC_DURABLE_NEW_SUBSTAT_BLANK;
            } else {
                PPT_METHODTRACE_EXIT("PPTManager_i::durable_currentState_CheckTransition");
                return RC_OK;
            }
        }

        PosDurableSubState_var newDurableSubState;
        PPT_CONVERT_DURABLESUBSTATECODE_TO_DURABLESUBSTATE_OR(newDurableSubState,
                                                              strDurable_currentState_CheckTransition_in.durableSubStatus,
                                                              strDurable_currentState_CheckTransition_out,
                                                              durable_currentState_CheckTransition);

        if (CORBA::is_nil(objectCurrentDurableSubState) != TRUE)
        {
            PPT_METHODTRACE_V1("", "durable's sub-status is not nil");

            if(CIMFWStrCmp(currentDurableSubStateID.identifier, strDurable_currentState_CheckTransition_in.durableSubStatus.identifier) == 0)
            {
                PPT_METHODTRACE_V1("", "input param's durableSubStatus is equal to durable's sub-status");

                PPT_SET_MSG_RC_KEY(strDurable_currentState_CheckTransition_out,
                                   MSG_SAME_DURABLE_SUBSTAT,
                                   RC_SAME_DURABLE_SUBSTAT,
                                   strDurable_currentState_CheckTransition_in.durableSubStatus.identifier);
                return RC_SAME_DURABLE_SUBSTAT;
            }
        }

        //--------------------------------------
        //   Check param's durableStatus
        //--------------------------------------
        CORBA::String_var newDurableState;
        try
        {
            newDurableState = newDurableSubState->getDurableState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosDurableSubState::getDurableState)
        PPT_METHODTRACE_V2("", "newDurableSubState->getDurableState()", newDurableState);

        if(CIMFWStrLen(strDurable_currentState_CheckTransition_in.durableStatus) > 0)
        {
            PPT_METHODTRACE_V2("", "input param's durableStatus ", strDurable_currentState_CheckTransition_in.durableStatus);

            if(CIMFWStrCmp(strDurable_currentState_CheckTransition_in.durableStatus, newDurableState) != 0)
            {
                PPT_METHODTRACE_V1("", "The combination of param's durable status/sub-stauts is not valid.");
                PPT_SET_MSG_RC_KEY2(strDurable_currentState_CheckTransition_out,
                                    MSG_DURABLE_STAT_SUBSTAT_UNMATCH,
                                    RC_DURABLE_STAT_SUBSTAT_UNMATCH,
                                    strDurable_currentState_CheckTransition_in.durableStatus,
                                    strDurable_currentState_CheckTransition_in.durableSubStatus.identifier)
                return RC_DURABLE_STAT_SUBSTAT_UNMATCH;
            }
        }

        //--------------------------------------
        //   Check next durableStatus
        //--------------------------------------
        if (CIMFWStrCmp(currentDurableState, newDurableState) != 0)
        {
            PPT_METHODTRACE_V1("", "current durable status is not equal new durable status");
            if (CORBA::is_nil(objectCurrentDurableSubState) != TRUE
             && objectCurrentDurableSubState->isChangeToOtherDurableState() == FALSE)
            {
                PPT_METHODTRACE_V1("", "objectCurrentDurableSubState->isChangeToOtherDurableState() is False");
                SET_MSG_RC(strDurable_currentState_CheckTransition_out, MSG_INVALID_STATE_TRANSITION, RC_INVALID_STATE_TRANSITION);
                return RC_INVALID_STATE_TRANSITION;
            }
            else if (newDurableSubState->isChangeFromOtherDurableState() == FALSE)
            {
                PPT_METHODTRACE_V1("", "newDurableSubState->isChangeFromOtherDurableState() is False");
                SET_MSG_RC(strDurable_currentState_CheckTransition_out, MSG_INVALID_STATE_TRANSITION, RC_INVALID_STATE_TRANSITION);
                return RC_INVALID_STATE_TRANSITION;
            }
        }

        //--------------------------------------------------
        //   Get SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION
        //--------------------------------------------------
        CORBA::Long nTransitionLimit = 0;
        nTransitionLimit = atoi(getenv(SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION));
        PPT_METHODTRACE_V2("", "Env SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION ", nTransitionLimit);

        //--------------------------------------------------
        //   Check next transition sub-state
        //--------------------------------------------------
        if (CORBA::is_nil(objectCurrentDurableSubState) != TRUE
         && (CIMFWStrCmp(currentDurableState, newDurableState) == 0 || nTransitionLimit == 1))
        {
            PPT_METHODTRACE_V1("", "Durable status do not change and SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION is 1");
            CORBA::Boolean checkFlag = false;

            objectIdentifierSequence_var nextTransitionSubStateSeq;
            try
            {
                nextTransitionSubStateSeq = objectCurrentDurableSubState->allDurableSubStateTransitions();
            }
            CATCH_AND_RAISE_EXCEPTIONS(objectCurrentDurableSubState::allDurableSubStateTransitions)

            CORBA::ULong nextTransitionSubStateLen = nextTransitionSubStateSeq->length();
            PPT_METHODTRACE_V2("", "objectCurrentDurableSubState->allDurableSubStateTransitions() length", nextTransitionSubStateLen);

            if (nextTransitionSubStateLen > 0)
            {
                PPT_METHODTRACE_V1("", "nextTransitionSubStateLen > 0");
                for (CORBA::ULong nextTransitionSubStateCnt = 0; nextTransitionSubStateCnt < nextTransitionSubStateLen; nextTransitionSubStateCnt++)
                {
                    if (0 == CIMFWStrCmp(strDurable_currentState_CheckTransition_in.durableSubStatus.identifier,
                                         (*nextTransitionSubStateSeq)[nextTransitionSubStateCnt].identifier))
                    {
                        PPT_METHODTRACE_V1("", "Specified DurableSubStatus was found in NextTransitionStatus.");
                        checkFlag = TRUE;
                        break;
                    }
                }

                if (checkFlag == FALSE)
                {
                    PPT_METHODTRACE_V1("", "Specified DurableSubStatus was not found in NextTransitionStatus.");
                    SET_MSG_RC(strDurable_currentState_CheckTransition_out, MSG_INVALID_STATE_TRANSITION, RC_INVALID_STATE_TRANSITION);
                    return RC_INVALID_STATE_TRANSITION;
                }
            }
        }

        if (CIMFWStrCmp(strDurable_currentState_CheckTransition_in.durableCategory, SP_DurableCat_Cassette) == 0)
        {
            PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Cassette");

            if (CIMFWStrCmp(newDurableState, CIMFW_Durable_Scrapped) == 0)
            {
                PPT_METHODTRACE_V1("", "newDurableState is CIMFW_Durable_Scrapped");

                LotSequence_var aLotSequence;
                try
                {
                    aLotSequence = aCassette->allLots();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

                CORBA::ULong nLotLen = aLotSequence->length();
                PPT_METHODTRACE_V2("", "aLotSeq->length() ", nLotLen);

                if (nLotLen > 0)
                {
                    PPT_METHODTRACE_V1("", "Can not change to Scrapped when cassette contains same lots.");
                    PPT_SET_MSG_RC_KEY(strDurable_currentState_CheckTransition_out,
                                       MSG_CAST_HAS_ANY_LOTS,
                                       RC_CAST_HAS_ANY_LOTS,
                                       newDurableState)
                    return RC_CAST_HAS_ANY_LOTS;
                }
            }
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::durable_currentState_CheckTransition");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strDurable_currentState_CheckTransition_out, durable_currentState_CheckTransition, methodName)
}
