//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_carrier_UsageTypeChange.cpp
//
#include "cs_pptmgr.hpp"

#include "pcas.hh"
// Class: CS_PPTManager
//
// Service: cs_carrier_UsageTypeChange()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-14 INN-R170002   JJ.Zhang       Contamination control 
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn                   strObjCommonIn;
//  in  csObjCarrier_UsageTypeChange_in  strCarrier_UsageTypeChange_in
//
//[Output Parameters]:
//
//  out csObjCarrier_UsageTypeChange_out  strCarrier_UsageTypeChange_out;
//
//  typedef objBase_out csObjCarrier_UsageTypeChange_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_carrier_UsageTypeChange(
    csObjCarrier_UsageTypeChange_out      &strCarrier_UsageTypeChange_out,
    const pptObjCommonIn                  &strObjCommonIn,
    const csObjCarrier_UsageTypeChange_in &strCarrier_UsageTypeChange_in)
{
    char * methodName = NULL;
    try
    {        
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_carrier_UsageTypeChange");
        CORBA::Long rc = RC_OK;

        CORBA::Long nCarrierLen = strCarrier_UsageTypeChange_in.carrierIDs.length();
        PPT_METHODTRACE_V2("","carrierID.length", nCarrierLen);
        PPT_METHODTRACE_V2("","change usageType", strCarrier_UsageTypeChange_in.usageType);

        if( 0 != CIMFWStrCmp(strCarrier_UsageTypeChange_in.usageType, CS_CarrierUsageType_Production)
         && 0 != CIMFWStrCmp(strCarrier_UsageTypeChange_in.usageType, CS_CarrierUsageType_NonProduction) )
        {
            PPT_METHODTRACE_V1("", "usageType should be Production/Non-Production" );
            CS_PPT_SET_MSG_RC_KEY1( strCarrier_UsageTypeChange_out,
                                    CS_MSG_INVALID_CARRIER_USAGETYPE,
                                    CS_RC_INVALID_CARRIER_USAGETYPE,
                                    strCarrier_UsageTypeChange_in.usageType );
            return CS_RC_INVALID_CARRIER_USAGETYPE;
        }

        //In-Parameter for event make
        pptHashedInfoSequence strHashedInfoSeq;
        strHashedInfoSeq.length(1);
        strHashedInfoSeq[0].hashKey = SP_HashData_CAST_ID;

        pptUserDataActionSequence strUserDataActionSeq;
        strUserDataActionSeq.length(1);
        strUserDataActionSeq[0].userDataName = CS_M_CAST_UsageType;
        strUserDataActionSeq[0].originator   = SP_USERDATA_ORIG_MM;
        strUserDataActionSeq[0].actionCode   = SP_UserDataUpdateResult_ActionCode_Update;
        strUserDataActionSeq[0].fromType     = CIMFWStrDup("");
        strUserDataActionSeq[0].toType       = CIMFWStrDup("");
        strUserDataActionSeq[0].toValue      = strCarrier_UsageTypeChange_in.usageType;

        for( CORBA::Long i=0; i<nCarrierLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop for carrierID", strCarrier_UsageTypeChange_in.carrierIDs[i].identifier);
            //------------------------------------------------
            //  Carrier should be empty
            //------------------------------------------------
            objCassette_CheckEmpty_out strCassette_CheckEmpty_out;
            rc = cassette_CheckEmpty( strCassette_CheckEmpty_out, strObjCommonIn, strCarrier_UsageTypeChange_in.carrierIDs[i] );
            if ( rc != RC_OK  )
            {
                PPT_METHODTRACE_V2("", "cassette_CheckEmpty() != RC_OK ", rc);
                strCarrier_UsageTypeChange_out.strResult = strCassette_CheckEmpty_out.strResult;
                return( rc );
            }

            //------------------------------------------------
            //  Change usage type for carrier
            //------------------------------------------------
            PosCassette_var aPosCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, strCarrier_UsageTypeChange_in.carrierIDs[i],
                                                   strCarrier_UsageTypeChange_out,
                                                   cs_carrier_UsageTypeChange );

            CORBA::String_var varCurUsageType;
            SI_PPT_USERDATA_GET_STRING( aPosCassette, CS_M_CAST_UsageType, varCurUsageType );

            PPT_METHODTRACE_V2("", "varCurUsageType", varCurUsageType);

            if( 0 != CIMFWStrCmp(strCarrier_UsageTypeChange_in.usageType, varCurUsageType) )
            {
                //set new usage type to U-data
                SI_PPT_USERDATA_SET_STRING( aPosCassette, CS_M_CAST_UsageType, strCarrier_UsageTypeChange_in.usageType );

                //---------------------------------------------------
                // Create User Data Change Event
                //---------------------------------------------------
                PPT_METHODTRACE_V1("", "call object_userData_ChangeEvent_Make()");

                strHashedInfoSeq[0].hashData = strCarrier_UsageTypeChange_in.carrierIDs[i].identifier;
                strUserDataActionSeq[0].fromValue  = varCurUsageType;

                objObject_UserData_ChangeEvent_Make_out strObject_UserData_ChangeEvent_Make_out;
                rc = object_userData_ChangeEvent_Make( strObject_UserData_ChangeEvent_Make_out,
                                                       strObjCommonIn,
                                                       "",                       //stringifiedObjectReference
                                                       SP_ClassName_PosCassette, //aClassName
                                                       strHashedInfoSeq,
                                                       strUserDataActionSeq,
                                                       strCarrier_UsageTypeChange_in.claimMemo );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "object_userData_ChangeEvent_Make() rc != RC_OK" );
                    strCarrier_UsageTypeChange_out.strResult = strObject_UserData_ChangeEvent_Make_out.strResult;
                    return rc;
                }
            }
        }

        //----------------------------------------------
        //Set PR flag for child lot
        //----------------------------------------------
       PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_carrier_UsageTypeChange");
       return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCarrier_UsageTypeChange_out, cs_carrier_UsageTypeChange, methodName)
}
