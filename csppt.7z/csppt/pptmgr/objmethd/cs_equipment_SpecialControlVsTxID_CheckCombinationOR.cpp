//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_equipment_SpecialControlVsTxID_CheckCombinationOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pmc.hh"

// Class: CS_PPTManager
//
// Service: equipment_SpecialControlVsTxID_CheckCombination()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2014/11/25 DSN000085770 Sa Guo         Durable Management.
// 2015/07/22 DSN000096126 C.Mo           Durable Process Flow Control Support.
//
//
// Innotron change history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//
//
//[Function Description]:
//   Transaction ID and SpecialControl of Equipment Category consisytency Check.
//
//[Input Parameters]:
//  const pptObjCommonIn&                                        strObjCommonIn;
//  const objEquipment_SpecialControlVsTxID_CheckCombination_in& strEquipment_SpecialControlVsTxID_CheckCombination_in;
//
//    typedef struct objEquipment_SpecialControlVsTxID_CheckCombination_in_struct{
//        objectIdentifier   equipmentID;
//        any                siInfo;
//    } objEquipment_SpecialControlVsTxID_CheckCombination_in;
//
//[Output Parameters]:
//  objEquipment_SpecialControlVsTxID_CheckCombination_out&      strEquipment_SpecialControlVsTxID_CheckCombination_out;
//
//    typedef objBase_out                                        objEquipment_SpecialControlVsTxID_CheckCombination_out;
//
//[Return Value]:
//
//  Return Code                         Messsage ID
//  ----------------------------------- ------------------------------------------------
//  RC_OK                               MSG_OK
//  RC_EQP_SPECIALCONTROL_TXID_MISMATCH MSG_EQP_SPECIALCONTROL_TXID_MISMATCH

CORBA::Long CS_PPTManager_i::equipment_SpecialControlVsTxID_CheckCombination(
    objEquipment_SpecialControlVsTxID_CheckCombination_out&       strEquipment_SpecialControlVsTxID_CheckCombination_out,
    const pptObjCommonIn&                                         strObjCommonIn,
    const objEquipment_SpecialControlVsTxID_CheckCombination_in&  strEquipment_SpecialControlVsTxID_CheckCombination_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "CS_PPTManager_i::equipment_SpecialControlVsTxID_CheckCombination" );

        //--------------//
        //  Initialize  //
        //--------------//

        //Trace InParameters
        PPT_METHODTRACE_V2("", "in-parm equipmentID   ", strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID.identifier);

        //--------------------------------------------------------
        //  Get Equipment Special Control
        //--------------------------------------------------------
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID,
                                         strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                         equipment_SpecialControlVsTxID_CheckCombination );

        stringSequence_var specialControls;
        try
        {
            specialControls = aMachine->getSpecialEquipmentControls();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getSpecialEquipmentControls)

        //--------------------------------------------------------------------------------------------------
        // These TransactionIDs must be done when 'Durable' is included in SpecialControl of the equipment
        //--------------------------------------------------------------------------------------------------
        if ( 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXPDC040")     //TxStartDurablesReservationReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXPDC041")     //TxStartDurablesReservationCancelReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXPDQ022")     //TxDurablesInfoForOpeStartInq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXPDC042")     //TxDurableOperationStartReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXPDC043")     //TxDurableOperationStartCancelReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXPDQ031")     //TxDurablesInfoForStartReservationInq //DSN000096126
//INN-R170003          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXPDC044") )   //TxDurableOpeCompReq
//INN-R170003 add start
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXPDC044")     //TxDurableOpeCompReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "CSPDC006")     //CS_TxStartDurablesReservationForInternalBufferReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "CSPDC007")     //CS_TxStartDurablesReservationCancelForInternalBufferReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "CSPDQ002")     //CS_TxDurablesInfoForOpeStartForInternalBufferInq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "CSPDQ001")     //CS_TxDurablesInfoForStartReservationForInternalBufferInq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "CSPDC008")     //CS_TxDurableOperationStartForInternalBufferReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "CSPDC009")     //CS_TxDurableOperationStartCancelForInternalBufferReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "CSPDC010")     //CS_TxDurableOpeCompForInternalBufferReq
        )
//INN-R170003 add end
        {
            PPT_METHODTRACE_V1("", "Durable transaction.");
            CORBA::Boolean bFound = FALSE;
            for ( CORBA::ULong iCnt=0; iCnt < specialControls->length(); iCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to specialControls->length()", iCnt);
                if ( 0 == CIMFWStrCmp((*specialControls)[iCnt], SP_Mc_SpecialEquipmentControl_DurableCarrier)
                  || 0 == CIMFWStrCmp((*specialControls)[iCnt], SP_Mc_SpecialEquipmentControl_DurableReticle)
                  || 0 == CIMFWStrCmp((*specialControls)[iCnt], SP_Mc_SpecialEquipmentControl_DurableReticlePod) )
                {
                    PPT_METHODTRACE_V1("", "specialControl is DurableCarrier or DurableReticle or DurableReticlePod");
                    bFound = TRUE;
                    break;
                }
            }
            if ( FALSE == bFound )
            {
                PPT_METHODTRACE_V1("", "FALSE == bFound");
                PPT_SET_MSG_RC_KEY( strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                    MSG_EQP_SPECIALCONTROL_TXID_MISMATCH,
                                    RC_EQP_SPECIALCONTROL_TXID_MISMATCH,
                                    strObjCommonIn.transactionID );
                return RC_EQP_SPECIALCONTROL_TXID_MISMATCH;
            }
        }

        //--------------------//
        //  Return to Caller  //
        //--------------------//
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::equipment_SpecialControlVsTxID_CheckCombination" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strEquipment_SpecialControlVsTxID_CheckCombination_out, equipment_SpecialControlVsTxID_CheckCombination, methodName );
}
