#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForUnloading.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:32:28 [ 7/13/07 19:32:30 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_cassette_CheckConditionForUnloadingOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"

//[Object Function Name]: long   cassette_CheckConditionForUnloading
//
// Date        Level  Author         Note
// ----------  -----  -------------  -------------------------------------------
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Jun Zhang      New Transfer State PI/PO.
//
//[Function Description]:
//  Check cassette's condition for Unloading.
//  The following conditions are checked.
//
//  <<< transferState >>>
//  Cassette's transfer state must be EI.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            cassetteID;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForUnloading_out   strCassette_CheckConditionForUnloading_out;
//
//  typedef struct objCassette_CheckConditionForUnloading_out_struct {
//      pptRetCode                  strResult;
//  } objCassette_CheckConditionForUnloading_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR

CORBA::Long CS_PPTManager_i::cassette_CheckConditionForUnloading(
                            objCassette_CheckConditionForUnloading_out& strCassette_CheckConditionForUnloading_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& cassetteID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cassette_CheckConditionForUnloading");
        PPT_METHODTRACE_V2( "CS_PPTManager_i::cassette_CheckConditionForUnloading","in-parm's cassetteID", cassetteID.identifier);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*--------------------------------------*/
        /*                                      */
        /*   Check Cassette's Transfer Status   */
        /*                                      */
        /*--------------------------------------*/

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,cassetteID,strCassette_CheckConditionForUnloading_out,cassette_CheckConditionForUnloading);

        /*-----------------------*/
        /*   Get TransferState   */
        /*-----------------------*/
        CORBA::String_var transferState;
        try
        {
            transferState = aCassette->getTransportState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState);

//INN-R170003 if (CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) == 0)
        if (CIMFWStrCmp(transferState,SP_TransState_EquipmentIn ) == 0 ||  //INN-R170003
            CIMFWStrCmp(transferState,SP_TransState_EquipmentOut) == 0 )   //INN-R170003
        {
            PPT_METHODTRACE_V1( "CS_PPTManager_i::cassette_CheckConditionForUnloading","transferState == SP_TransState_EquipmentIn or SP_TransState_EquipmentOut");
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1( "CS_PPTManager_i::cassette_CheckConditionForUnloading","transferState != SP_TransState_EquipmentIn and SP_TransState_EquipmentOut");
            PPT_SET_MSG_RC_KEY2(strCassette_CheckConditionForUnloading_out, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,transferState, cassetteID.identifier )
            return(RC_INVALID_CAST_XFERSTAT);
        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cassette_CheckConditionForUnloading");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForUnloading_out, cassette_CheckConditionForUnloading, methodName);
}
