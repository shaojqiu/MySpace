#ifndef lint
static char *sccsid =  "@(#) 1.6 superpos/src/csppt/source/posppt/pptmgr/objmethd/cs_processDurable_CheckConditionForOpeStartOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 10/10/07 11:41:38 [ 10/10/07 11:41:40 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_processDurable_CheckConditionForOpeStartOR.cpp
//

#include "cs_pptmgr.hpp"
#include "plcrc.hh"
#include "pmcrc.hh"
#include "ppcdrcp.hh"
#include "plot.hh"
#include "ppcope.hh"  //D4200031
#include "ppcopsp.hh" //D4200031
#include "ppcdr.hh"     //DSN000101569
#include "pptconvert.h" //D9000084
#include "pcas.hh"

//[Object Function Name]: long   cs_processDurable_CheckConditionForOpeStartOR
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-09-09  0.01      Y.Iwasaki      Bug fix for reticle set / fixture set
// 2000-09-16  Q3000066  Y.Iwaswaki     Add reticle/fixture group count check logic
// 2000/11/10  P2200204  R.Furuta       Initialize local pointers
// 2001-03-07  P3100077  K.Matsuei      Reticle Inhibit is not effected for Loding / StartReserve
// 2001-07-11  D4000043  O.Sugiyama     Add Parameter in reticle_FillInTxPDQ004DR and fixture_FillInTxPDQ001DR
// 2001-08-09  D4000048  M.Ameshita     Reticle set support (Rel4.0)
// 2001-09-07  P4000157  M.Ameshita     Fix to set sub lot type to check reticle inhibition.
// 2002-08-07  D4200081  K.Matsuei      New combination of Inhibit is supported.
// 2002-09-19  D4200031  H.Adachi       Chg not to check reticle group when a lot is in a operation with no photo layer.
// 2002-09-19  P4200085  H.Adachi       Fix the way to retrieve the photo layer.
// 2002-09-18  P4200170  Y.Iwasaki      Add check logic whether Lot.ReticleSet is existing or not
// 2004-04-26  D5100087  K.Kido         Change for Chaber Inhibit Support.
// 2005-06-07  P6000448  H.Adachi       Change Parameter for getting Reticle and Fixture.
// 2005-08-31  D6000415  K.Kido         Call findFixtureGroupsForSubLotType() to get correct fixture group taken into account for Chamber Machine State.
// 2005/12/07  D7000042  K.Kido         Get Machine Recipe by findMachineRecipeForSubLotType for findFixtureGroupsForSubLotType.
// 2006/10/19  D8000024  H.Mutoh        Add input parameter of reticle_FillInTxPDQ004DR() and the changing reticles for FPC.
// 2007/09/20  D9000084  K.Kido         reticle_FillInTxPDQ004DR ==> reticle_list_GetDR__090
//                                      Allow a lot reservation while the reticle which the lot requires is being retrieved to a pod.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
// 2015/11/12 DSN000096126 C.Mo           reticle_list_GetDR__090 ==> reticle_list_GetDR__160
// 2016/07/13 DSN000101569 K.Yamaoku      Durable Sub Status Control
// 2016/07/27 DSN000101569 C.Mo           reticle_list_GetDR__160 ==> reticle_list_GetDR__170
//
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/31 INN-R170009  Gary Ke        Add for durableSubStatus
//
//[Function Description]:
//  Check the following items.
//
//  1. Whether equipment requires process durable or not
//     If no-need, return OK;
//
//  2. At least one of reticle / fixture for each reticleGroup / fixtureGroup
//     is in the equipment or not.
//     Even if required reticle is in the equipment, its status must be _Available or
//     _InUse.
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  objectIdentifier            logicalRecipeID;
//  in  objectIdentifier            machineRecipeID;
//
//[Output Parameters]:
//  out objProcessDurable_CheckConditionForOpeStart_out   strProcessDurable_CheckConditionForOpeStart_out;
//
//  typedef struct objProcessDurable_CheckConditionForOpeStart_out_struct {
//      pptRetCode                  strResult;
//      pptpptStartReticleSequence  strStartReticle;
//      pptpptStartFixtureSequence  strStartFixture;
//  } objProcessDurable_CheckConditionForOpeStart_out;
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_NOT_FOUND_EQP                   MSG_NOT_FOUND_EQP
//  RC_NOT_FOUND_LOT                   MSG_NOT_FOUND_LOT
//  RC_NOT_FOUND_MCRECIPE              MSG_NOT_FOUND_MCRECIPE
//  RC_NOT_FOUND_LCRECIPE              MSG_NOT_FOUND_LCRECIPE
//  RC_NOT_AVAILABLE_RETICLE           MSG_NOT_AVAILABLE_RETICLE
//  RC_NOT_AVAILABLE_FIXTURE           MSG_NOT_AVAILABLE_FIXTURE
//  RC_INVALID_RETICLE_XFER_STAT       MSG_INVALID_RETICLE_XFER_STAT
//  RC_INVALID_FIXTURE_XFER_STAT       MSG_INVALID_FIXTURE_XFER_STAT
//  RC_RETICLE_NOT_IN_THE_EQP          MSG_RETICLE_NOT_IN_THE_EQP
//  RC_FIXTURE_NOT_IN_THE_EQP          MSG_FIXTURE_NOT_IN_THE_EQP
//  RC_LOCKED_BY_ANOTHER               MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//  RC_EQP_PROCDRBL_NOT_REQD           MSG_EQP_PROCDRBL_NOT_REQD
//  RC_NOT_FOUND_FIXTURE               MSG_NOT_FOUND_FIXTURE
//  RC_NOT_FOUND_RETICLE               MSG_NOT_FOUND_RETICLE

CORBA::Long CS_PPTManager_i::processDurable_CheckConditionForOpeStart(
                            objProcessDurable_CheckConditionForOpeStart_out& strProcessDurable_CheckConditionForOpeStart_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const objectIdentifier& logicalRecipeID,
//D4000048                  const objectIdentifier& machineRecipeID)
                            const objectIdentifier& machineRecipeID,                                             //D4000048
                            const objectIdentifier& lotID)                                                       //D4000048
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::processDurable_CheckConditionForOpeStart");
        PPT_METHODTRACE_V2( "","in-parm's equipmentID", equipmentID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's logicalRecipeID", logicalRecipeID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's machineRecipeID", machineRecipeID.identifier);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        strProcessDurable_CheckConditionForOpeStart_out.strStartReticle.length(0);
        strProcessDurable_CheckConditionForOpeStart_out.strStartFixture.length(0);

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        /*------------------------------------------------------*/
        /*                                                      */
        /*   Check Equipment requires Process Durables or Not   */
        /*                                                      */
        /*------------------------------------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine,equipmentID,strProcessDurable_CheckConditionForOpeStart_out,processDurable_CheckConditionForOpeStart);

        CORBA::Long reticleRequiredFlag = FALSE;
        CORBA::Long fixtureRequiredFlag = FALSE;

        reticleRequiredFlag;
        try
        {
            reticleRequiredFlag = aMachine->isReticleRequired();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::isReticleRequired);

        fixtureRequiredFlag;
        try
        {
            fixtureRequiredFlag = aMachine->isFixtureRequired();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::isFixtureRequired);

        /*-----------------------------------------------*/
        /*                                               */
        /*   Get and Check Reticle Status for Each Lot   */
        /*                                               */
        /*-----------------------------------------------*/
        if (reticleRequiredFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", "reticleRequiredFlag == TRUE");

            /*-----------------------------------------------*/                                          //D4200031
            /*                                               */                                          //D4200031
            /*   Get photo layer to decide if reticle check  */                                          //D4200031
            /*   is required, or not.                        */                                          //D4200031
            /*                                               */                                          //D4200031
            /*-----------------------------------------------*/                                          //D4200031
            PosLot_var aLot;                                                                             //D4200031
                                                                                                         //D4200031
            PPT_CONVERT_LOTID_TO_LOT_OR( aLot                                            ,               //D4200031
                                         lotID                                           ,               //D4200031
                                         strProcessDurable_CheckConditionForOpeStart_out ,               //D4200031
                                         processDurable_CheckConditionForOpeStart)       ;               //D4200031
                                                                                                         //D4200031
            if(CORBA::is_nil(aLot))                                                                      //D4200031
            {                                                                                            //D4200031
                PPT_SET_MSG_RC_KEY( strProcessDurable_CheckConditionForOpeStart_out,                     //D4200031
                                    MSG_NOT_FOUND_LOT,                                                   //D4200031
                                    RC_NOT_FOUND_LOT, "" );                                              //D4200031
                return RC_NOT_FOUND_LOT ;                                                                //D4200031
            }                                                                                            //D4200031
                                                                                                         //D4200031
            ProcessOperation_var aPO ;                                                                   //D4200031
            try                                                                                          //D4200031
            {                                                                                            //D4200031
                aPO = aLot->getProcessOperation() ;                                                      //D4200031
            }                                                                                            //D4200031
            CATCH_AND_RAISE_EXCEPTIONS(Lot::getProcessOperation) ;                                       //D4200031
                                                                                                         //D4200031
            if(CORBA::is_nil(aPO))                                                                       //D4200031
            {                                                                                            //D4200031
                PPT_SET_MSG_RC_KEY( strProcessDurable_CheckConditionForOpeStart_out,                     //D4200031
                                    MSG_NOT_FOUND_OPERATION,                                             //D4200031
                                    RC_NOT_FOUND_OPERATION, "" );                                        //D4200031
                return RC_NOT_FOUND_OPERATION ;                                                          //D4200031
            }                                                                                            //D4200031
                                                                                                         //D4200031
//P4200085  ProcessOperationSpecification_var aPOS ;                                                     //D4200031
//P4200085  try                                                                                          //D4200031
//P4200085  {                                                                                            //D4200031
//P4200085      aPOS = aPO->getProcessOperationSpecification() ;                                         //D4200031
//P4200085  }                                                                                            //D4200031
//P4200085  CATCH_AND_RAISE_EXCEPTIONS(ProcessOperation::getProcessOperationSpecificaiton)               //D4200031
//P4200085                                                                                               //D4200031
//P4200085  if(CORBA::is_nil(aPOS))                                                                      //D4200031
//P4200085  {                                                                                            //D4200031
//P4200085      PPT_SET_MSG_RC_KEY( strProcessDurable_CheckConditionForOpeStart_out,                     //D4200031
//P4200085                          MSG_NOT_FOUND_POS,                                                   //D4200031
//P4200085                          RC_NOT_FOUND_POS, "" );                                              //D4200031
//P4200085      return RC_NOT_FOUND_POS ;                                                                //D4200031
//P4200085  }                                                                                            //D4200031
//P4200085                                                                                               //D4200031
//P4200085  PosProcessOperationSpecification_var aPosPOS = PosProcessOperationSpecification::_narrow( aPOS ) ; //D4200031
//P4200085                                                                                               //D4200031
//P4200085  CORBA::String_var aPhotoLayer = aPosPOS->getPhotoLayer();                                    //D4200031

            PosProcessOperation_var aPosPO = PosProcessOperation::_narrow( aPO ) ;                       //P4200085

            CORBA::String_var aPhotoLayer;                                                               //D4200031
            try                                                                                          //D4200031
            {                                                                                            //D4200031
                aPhotoLayer = aPosPO->getPhotoLayer();                                                   //D4200031
            }                                                                                            //D4200031
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getPhotoLayer);                              //D4200031

            if (CIMFWStrLen(aPhotoLayer) > 0 )                                                           //D4200031
            {                                                                                            //D4200031

                /*----------------------------*/
                /*   Get Reticle Group List   */
                /*----------------------------*/
                PosLogicalRecipe_var aLogicalRecipe;
                PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR(aLogicalRecipe,logicalRecipeID,strProcessDurable_CheckConditionForOpeStart_out,processDurable_CheckConditionForOpeStart);

//D7000042      PosMachineRecipe_var aMachineRecipe;
//D7000042      PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR(aMachineRecipe,machineRecipeID,strProcessDurable_CheckConditionForOpeStart_out,processDurable_CheckConditionForOpeStart);

                PosProcessDurableCapabilitySequence* aReticleGroupSeq = NULL; //P2200204
                PosProcessDurableCapabilitySequence_var aVarReticleGroupSeq;
//D4200031      PosLot_var aLot;                                                                       //P4000157

                try
                {
//D4000048          aReticleGroupSeq = aLogicalRecipe->findReticleGroupsFor(aMachine,aMachineRecipe);
                    CORBA::String_var anEqpID = aMachine->getIdentifier();                             //D4000048
//P4000157          PosLot_var aLot;                                                                   //D4000048
//D4200031          PPT_CONVERT_LOTID_TO_LOT_OR( aLot                                            ,     //D4000048
//D4200031                                       lotID                                           ,     //D4000048
//D4200031                                       strProcessDurable_CheckConditionForOpeStart_out ,     //D4000048
//D4200031                                       processDurable_CheckConditionForOpeStart)       ;     //D4000048
//D4200031          if ( !CORBA::is_nil(aLot) )                                                        //D4000048
//D4200031          {                                                                                  //D4000048
                        aReticleGroupSeq = aLot->getReticleGroupsFor( anEqpID );                       //D4000048
//D4200031          }                                                                                  //D4000048
                    aVarReticleGroupSeq = aReticleGroupSeq;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findReticleGroupsFor);

//DSN000101569 add start
                // Get lot's SubLotType
                CORBA::String_var subLotType;
                try
                {
                    subLotType = aLot->getSubLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
                PPT_METHODTRACE_V2("", "subLotType", subLotType)

                stringSequence subLotTypeList;
                subLotTypeList.length(1);
                subLotTypeList[0] = subLotType;
//DSN000101569 add end

                /*----------------------*/
                /*   Get Reticle List   */
                /*----------------------*/
                CORBA::Long RGSLength;
                RGSLength = (*aReticleGroupSeq).length();

//D8000024 add start
                CORBA::String_var tmpFPCCategory;
                objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                               SP_FPC_ExchangeType_StartReserveReq, equipmentID, lotID );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                    strProcessDurable_CheckConditionForOpeStart_out.strResult = strLot_effectiveFPCInfo_Get_out.strResult;
                    return rc;
                }

                if( strLot_effectiveFPCInfo_Get_out.reticleActionRequired == TRUE )
                {
                    PPT_METHODTRACE_V1("", "This operation is overwritten by FPC");
                    RGSLength = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strReticleInfoList.length();
                }
//D8000024 add end

                //Q3000066 add start
                if ( RGSLength == 0 )
                {
                    PPT_METHODTRACE_V1("", "RGSLength == 0");
                    SET_MSG_RC(strProcessDurable_CheckConditionForOpeStart_out,MSG_NOT_AVAILABLE_RETICLE,RC_NOT_AVAILABLE_RETICLE);
                    return(RC_NOT_AVAILABLE_RETICLE);
                }
                //Q3000066 add end

                strProcessDurable_CheckConditionForOpeStart_out.strStartReticle.length(RGSLength);

                for (CORBA::Long i=0 ; i<RGSLength ; i++)
                {
//D8000024                    PPT_METHODTRACE_V3("", "loop to (*aReticleGroupSeq).length()",RGSLength,i);

                    objectIdentifier reticleGroupID;
//D8000024 add start
                    if( strLot_effectiveFPCInfo_Get_out.reticleActionRequired == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "This operation is overwritten by FPC");
                        PPT_METHODTRACE_V3("", "loop to FPC.reticleInfoList.length()",RGSLength,i);
                        reticleGroupID = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strReticleInfoList[i].reticleGroup;
                    }
                    else
                    {
//D8000024 add end
                        PPT_METHODTRACE_V3("", "loop to (*aReticleGroupSeq).length()",RGSLength,i);
                        PPT_SET_OBJECT_IDENTIFIER(reticleGroupID,(*aReticleGroupSeq)[i],strProcessDurable_CheckConditionForOpeStart_out,processDurable_CheckConditionForOpeStart, PosProcessDurableCapability);
                    }    //D8000024

//D9000084                    objectIdentifier equipmentID_nil;
//D9000084                    objectIdentifier lotID_nil;
//D9000084                    objectIdentifier reticleID_nil;
//D9000084                    CORBA::String_var reticlePartNumber_nil;
//D9000084                    CORBA::String_var reticleStatus_nil;                           //D4000043
//D9000084
//D9000084                    objReticle_FillInTxPDQ004DR_out strReticle_FillInTxPDQ004DR_out;
//D9000084
//D9000084                    //P6000448 Add Start
//D9000084                    rc = reticle_FillInTxPDQ004DR( strReticle_FillInTxPDQ004DR_out,
//D9000084                                                   strObjCommonIn,
//D9000084                                                   equipmentID,
//D9000084                                                   lotID_nil,
//D9000084                                                   reticleID_nil,
//D9000084                                                   reticlePartNumber_nil,
//D9000084                                                   reticleGroupID,
//D9000084                                                   reticleStatus_nil,
//D9000084//D8000024                                                   0 );
//D9000084                                                   0,                                   //D8000024
//D9000084                                                   tmpFPCCategory,                      //D8000024
//D9000084                                                   SP_WhiteDef_SearchCriteria_All );    //D8000024
//D9000084                    //P6000448 Add End
//D9000084
//D9000084//P6000448                    rc = reticle_FillInTxPDQ004DR( strReticle_FillInTxPDQ004DR_out,
//D9000084//P6000448                                                   strObjCommonIn,
//D9000084//P6000448                                                   equipmentID_nil,
//D9000084//P6000448                                                   lotID_nil,
//D9000084//P6000448                                                   reticleID_nil,
//D9000084//P6000448                                                   reticlePartNumber_nil,
//D9000084//P6000448                                                   reticleGroupID,
//D9000084//P6000448                                                   reticleStatus_nil,               //D4000043
//D9000084//P6000448                                                   SP_Durable_MaxCountInGroup );    //D4000043
//D9000084
//D9000084                    if (rc != RC_OK)
//D9000084                    {
//D9000084                        PPT_METHODTRACE_V1("", "reticle_FillInTxPDQ004DR() != RC_OK");
//D9000084                        strProcessDurable_CheckConditionForOpeStart_out.strResult = strReticle_FillInTxPDQ004DR_out.strResult ;
//D9000084                        return(rc);
//D9000084                    }
//DSN000096126//D9000084 add start
//DSN000096126                    objReticle_list_GetDR_out__090  strReticle_FillInTxPDQ004DR_out;
//DSN000096126                    objReticle_list_GetDR_in__090   strReticle_list_GetDR_in;
//DSN000096126                    strReticle_list_GetDR_in.equipmentID            = equipmentID;
//DSN000096126                    strReticle_list_GetDR_in.reticleGroupID         = reticleGroupID;
//DSN000096126                    strReticle_list_GetDR_in.maxRetrieveCount       = 0;
//DSN000096126                    strReticle_list_GetDR_in.FPCCategory            = tmpFPCCategory;
//DSN000096126                    strReticle_list_GetDR_in.whiteDefSearchCriteria = CIMFWStrDup(SP_WhiteDef_SearchCriteria_All);
//DSN000096126                    rc = reticle_list_GetDR__090( strReticle_FillInTxPDQ004DR_out, strObjCommonIn,
//DSN000096126                                                  strReticle_list_GetDR_in );
//DSN000096126                    if( rc != RC_OK )
//DSN000096126                    {
//DSN000096126                        PPT_METHODTRACE_V1("", "reticle_list_GetDR__090() != RC_OK")
//DSN000096126                        strProcessDurable_CheckConditionForOpeStart_out.strResult  = strReticle_FillInTxPDQ004DR_out.strResult ;
//DSN000096126                        return( rc );
//DSN000096126                    }
//DSN000096126//D9000084 add end
//DSN000096126 Add Start
//DSN000101569                    objReticle_list_GetDR_out__160  strReticle_FillInTxPDQ004DR_out;
//DSN000101569                    objReticle_list_GetDR_in__160   strReticle_list_GetDR_in;
                    objectIdentifier dummyID;                                                                                   //DSN000101569
                    dummyID.identifier = CIMFWStrDup("");                                                                       //DSN000101569
                    objReticle_list_GetDR_out__170  strReticle_FillInTxPDQ004DR_out;                                            //DSN000101569
                    objReticle_list_GetDR_in__170   strReticle_list_GetDR_in;                                                   //DSN000101569
                    strReticle_list_GetDR_in.equipmentID            = equipmentID;
                    strReticle_list_GetDR_in.reticleGroupID         = reticleGroupID;
                    strReticle_list_GetDR_in.maxRetrieveCount       = 0;
                    strReticle_list_GetDR_in.FPCCategory            = tmpFPCCategory;
                    strReticle_list_GetDR_in.whiteDefSearchCriteria = CIMFWStrDup(SP_WhiteDef_SearchCriteria_All);
                    strReticle_list_GetDR_in.durableSubStatus       = dummyID;                                                  //DSN000101569
                    strReticle_list_GetDR_in.flowStatus             = CIMFWStrDup("");                                          //DSN000101569
//DSN000101569                    rc = reticle_list_GetDR__160(strReticle_FillInTxPDQ004DR_out, strObjCommonIn, strReticle_list_GetDR_in);
                    rc = reticle_list_GetDR__170(strReticle_FillInTxPDQ004DR_out, strObjCommonIn, strReticle_list_GetDR_in);    //DSN000101569
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "reticle_list_GetDR__170() != RC_OK")
                        strProcessDurable_CheckConditionForOpeStart_out.strResult  = strReticle_FillInTxPDQ004DR_out.strResult;
                        return( rc );
                    }
//DSN000096126 Add End

                    CORBA::Boolean bInhibitErr = FALSE;     //P3100077
                    objectIdentifier inhibitErrReticleID;   //P3100077

                    CORBA::Boolean findFlag = FALSE;
                    CORBA::Long FRLength;
                    FRLength = strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle.length();

                    //--- Get sub lot type to use in reticle inhibition ---------------------------//   //P4000157
                    CORBA::String_var aSubLotType = CORBA::String(NULL) ;                               //P4000157
                    if ( !CORBA::is_nil(aLot) )                                                         //P4000157
                    {                                                                                   //P4000157
                        aSubLotType = aLot->getSubLotType();                                            //P4000157
                        PPT_METHODTRACE_V2("", "Sub Lot Type", aSubLotType );                           //P4000157
                    }                                                                                   //P4000157

//D8000024 add start
                    if( strLot_effectiveFPCInfo_Get_out.reticleActionRequired == TRUE )
                    {
                        CORBA::Boolean reticleExFlag = FALSE;
//DSN000096126                        pptFoundReticleSequence tmpFoundReticles;
//DSN000101569                        pptFoundReticleSequence__160 tmpFoundReticles; //DSN000096126
                        pptFoundReticleSequence__170 tmpFoundReticles;                                                     //DSN000101569
                        tmpFoundReticles.length(1);
                        PPT_METHODTRACE_V1("", "Check reticle existence");
                        for( CORBA::Long reticleCnt=0; reticleCnt<FRLength; reticleCnt++ )
                        {
                            if( CIMFWStrCmp(strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[reticleCnt].reticleID.identifier,
                                strLot_effectiveFPCInfo_Get_out.strFPCInfo.strReticleInfoList[i].reticleID.identifier ) == 0 )
                            {
                                PPT_METHODTRACE_V3("", "Specified Reticle by FPC exist in equipment correctly.",
                                                   strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[reticleCnt].reticleID.identifier,
                                                   strLot_effectiveFPCInfo_Get_out.strFPCInfo.strReticleInfoList[i].reticleID.identifier);
//DSN000096126//D9000084                      tmpFoundReticles[0] = strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[reticleCnt];
//DSN000096126//D9000084 add start
//DSN000096126                                PPTConvert conv(strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[reticleCnt]);
//DSN000096126                                tmpFoundReticles[0] = conv;
//DSN000096126//D9000084 add end
                                tmpFoundReticles[0] = strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[reticleCnt]; //DSN000096126
                                reticleExFlag = TRUE;
                                break;
                            }
                        }

                        if( reticleExFlag == TRUE )
                        {
                            FRLength = 1;    // because, specified reticle and reticleGroup for FPC is one-one relation.
//DSN000096126//D9000084                  strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle =
//DSN000096126//D9000084                      tmpFoundReticles;
//DSN000096126//D9000084 add start
//DSN000096126                            PPTConvert conv(tmpFoundReticles);
//DSN000096126                            strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle = conv;
//DSN000096126//D9000084 add end
                            strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle = tmpFoundReticles; //DSN000096126
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "Specified Reticle by FPC is not found in equipment.");
                            SET_MSG_RC( strProcessDurable_CheckConditionForOpeStart_out,
                                        MSG_NOT_AVAILABLE_RETICLE,RC_NOT_AVAILABLE_RETICLE );
                            return RC_NOT_AVAILABLE_RETICLE;
                        }
                    }
//D8000024 add end

                    for ( CORBA::Long j=0; j < FRLength; j++ )
                    {
                        PPT_METHODTRACE_V3("", "loop to strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle.length()",FRLength,j);
                        PPT_METHODTRACE_V3("", "  equipmentID", j, strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.equipmentID.identifier);
                        PPT_METHODTRACE_V3("", "  transferStatus", j, strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.transferStatus);
                        PPT_METHODTRACE_V3("", "  reticleStatus", j, strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.reticleStatus);

//DSN000101569 add start
                        PosProcessDurable_var aReticle;
                        PPT_CONVERT_RETICLEID_TO_RETICLE_OR( aReticle,
                                                             strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID,
                                                             strProcessDurable_CheckConditionForOpeStart_out,
                                                             processDurable_CheckConditionForOpeStart );

                        CORBA::Boolean availableFlag = FALSE;
                        try
                        {
                            availableFlag = aReticle->isLotProcessAvailable(subLotTypeList);
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::isLotProcessAvailable)
                        PPT_METHODTRACE_V2("", "availableFlag", ( availableFlag ? "TRUE" : "FALSE" ))
//DSN000101569 add end

                        if ( CIMFWStrCmp(strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.equipmentID.identifier,equipmentID.identifier) == 0 &&
                             CIMFWStrCmp(strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.transferStatus,SP_TransState_EquipmentIn) == 0 &&
//DSN000101569                            (CIMFWStrCmp(strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.reticleStatus,CIMFW_Durable_Available) == 0 ||
//DSN000101569                             CIMFWStrCmp(strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.reticleStatus,CIMFW_Durable_InUse) == 0))
                             TRUE == availableFlag )  //DSN000101569
                        {
//D4200081 delete start
//D4200081//P3100077 start
//D4200081                        PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100077 start @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//D4200081                        /*------------------------------*/
//D4200081                        /*   Check Reticle Inhibition   */
//D4200081                        /*------------------------------*/
//D4200081                        PPT_METHODTRACE_V2("", "check ReticleID", strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID.identifier);
//D4200081
//D4200081                        pptEntityInhibitAttributes entityInhibitAttributes;
//D4200081                        entityInhibitAttributes.entities.length(1);
//D4200081
//D4200081                        entityInhibitAttributes.entities[0].className = CIMFWStrDup( SP_InhibitClassID_Reticle );
//D4200081                        entityInhibitAttributes.entities[0].objectID  = strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID;
//D4200081                        entityInhibitAttributes.entities[0].attrib    = CIMFWStrDup( "" );
//D4200081
//D4200081                        //--- Set sub lot type --------------------------------------------------------//  //P4000157
//D4200081                        if ( aSubLotType != NULL )                                                         //P4000157
//D4200081                        {                                                                                  //P4000157
//D4200081                            entityInhibitAttributes.subLotTypes.length(1) ;                                //P4000157
//D4200081                            entityInhibitAttributes.subLotTypes[0] = CIMFWStrDup( aSubLotType ) ;          //P4000157
//D4200081                        }                                                                                  //P4000157
//D4200081                        else                                                                               //P4000157
//D4200081                        {                                                                                  //P4000157
//D4200081                            entityInhibitAttributes.subLotTypes.length(0) ;                                //P4000157
//D4200081                        }                                                                                  //P4000157
//D4200081
//D4200081                        objEntityInhibit_CheckForEntities_out strEntityInhibit_CheckForEntities_out;
//D4200081                        rc = entityInhibit_CheckForEntities( strEntityInhibit_CheckForEntities_out, strObjCommonIn, entityInhibitAttributes );
//D4200081
//D4200081                        if ( rc != RC_OK )
//D4200081                        {
//D4200081                            PPT_METHODTRACE_V2("", "entityInhibit_CheckForEntities() rc != RC_OK", j);
//D4200081                            strProcessDurable_CheckConditionForOpeStart_out.strResult = strEntityInhibit_CheckForEntities_out.strResult;
//D4200081                            return( rc );
//D4200081                        }
//D4200081
//D4200081                        CORBA::Long lenInhibit = strEntityInhibit_CheckForEntities_out.entityInhibitInfo.length();
//D4200081                        PPT_METHODTRACE_V2("", "lenInhibit ---> ", lenInhibit);
//D4200081
//D4200081                        if ( 0 < lenInhibit )
//D4200081                        {
//D4200081                            if ( FALSE == bInhibitErr )
//D4200081                            {
//D4200081                                PPT_METHODTRACE_V1("", "save first inhibit error");
//D4200081
//D4200081                                // save first inhibit error
//D4200081                                bInhibitErr = TRUE;
//D4200081                                inhibitErrReticleID = strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID;
//D4200081                            }
//D4200081                            PPT_METHODTRACE_V1("", "0 < lenInhibit  --->  continue!!");
//D4200081                            continue;
//D4200081                        }
//D4200081
//D4200081                        PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100077 end @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//D4200081//P3100077 end
//D4200081 delete end
//INN-R170009 Add start
                            //get DurableSubState
                            PPT_METHODTRACE_V1("", "get DurableSubState");
                            PosDurableSubState_var aDurableSubState;
                            try
                            {
                                aDurableSubState = aReticle -> getDurableSubState();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableSubState)

                            CORBA::String_var varDurableSubState;
                            if( TRUE != CORBA::is_nil(aDurableSubState))
                            {
                                PPT_METHODTRACE_V1("", "TRUE != CORBA::is_nil(aDurableSubState)");
                                varDurableSubState = aDurableSubState -> getIdentifier();
                            }

                            PPT_METHODTRACE_V2("", "varDurableSubState", varDurableSubState);
                            if( CIMFWStrnCmp( varDurableSubState, "Insp", 4) == 0)
                            {
                                PPT_METHODTRACE_V1("", "CIMFWStrnCmp( varDurableSubState, Insp, 4) == 0");
                                continue;
                            }
//INN-R170009 Add end
//D4200081 start
                            PPT_METHODTRACE_V1("", "call equipment_CheckInhibitForLotWithMachineRecipe()");
                            pptStartCassetteSequence strStartCassetteSeq;
                            strStartCassetteSeq.length(1);
                            strStartCassetteSeq[0].strLotInCassette.length(1);

                            objectIdentifierSequence checkLotIDs;
                            checkLotIDs.length(1);
                            checkLotIDs[0] = lotID;
                            PPT_METHODTRACE_V2("", "lotID", lotID.identifier);

                            strStartCassetteSeq[0].strLotInCassette[0].lotID = lotID;
                            strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.machineRecipeID = machineRecipeID;
                            PPT_METHODTRACE_V2("", "machineRecipeID", machineRecipeID.identifier);

                            strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartReticle.length(1);
                            strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartReticle[0].reticleID
                                    = strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID;
                            PPT_METHODTRACE_V2("", "reticleID", strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID.identifier);

                            strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.logicalRecipeID = logicalRecipeID;   //D5100087
                            PPT_METHODTRACE_V2("", "logicalRecipe", logicalRecipeID.identifier);                           //D5100087

                            objEquipment_CheckInhibitForLotWithMachineRecipe_out strEquipment_CheckInhibitForLotWithMachineRecipe_out;
                            rc = equipment_CheckInhibitForLotWithMachineRecipe( strEquipment_CheckInhibitForLotWithMachineRecipe_out,
                                                                                strObjCommonIn,
                                                                                equipmentID,
                                                                                checkLotIDs,
                                                                                strStartCassetteSeq );
                            if ( RC_OK != rc )
                            {
                                PPT_METHODTRACE_V2("", "RC_OK != equipment_CheckInhibitForLotWithMachineRecipe() ...continue", rc);
                                continue;
                            }
//D4200081 end

//D9000084 add start
                            /*--------------------------------------*/
                            /*  Check ReticleDispatchJob existence  */
                            /*--------------------------------------*/
                            objectIdentifier dummyID;
                            objReticle_dispatchJob_CheckExistenceDR_out strReticle_dispatchJob_CheckExistenceDR_out;
                            rc = reticle_dispatchJob_CheckExistenceDR(strReticle_dispatchJob_CheckExistenceDR_out,
                                                                      strObjCommonIn,
                                                                      strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID,
                                                                      dummyID,   //reticlePodID
                                                                      dummyID);  //toEquipmentID
                            if(rc != RC_OK)
                            {
                                PPT_METHODTRACE_V2("", "reticle_dispatchJob_CheckExistenceDR() != RC_OK ...continue", rc);
                                continue;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "reticle_dispatchJob_CheckExistenceDR() == RC_OK");
                            }

                            /*--------------------------------*/
                            /*  Check Reticle Pod relation.   */
                            /*--------------------------------*/
                            if( 0 != CIMFWStrLen( strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.reticlePodID.identifier ) )
                            {
                                PPT_METHODTRACE_V3("","Required reticle relates with reticlePod.",
                                                      strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID.identifier,
                                                      strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleStatusInfo.reticlePodID.identifier );
                                continue;
                            }
//D9000084 add end

                            PPT_METHODTRACE_V1("", "returned strFoundReticle value == TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }

                    if ( findFlag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == TRUE");
//0.01                  strProcessDurable_CheckConditionForOpeStart_out.strStartReticle[i+1].sequenceNumber = i+1;
//0.01                  strProcessDurable_CheckConditionForOpeStart_out.strStartReticle[i+1].reticleID      = strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID;
                        strProcessDurable_CheckConditionForOpeStart_out.strStartReticle[i].sequenceNumber = i+1; //0.01
                        strProcessDurable_CheckConditionForOpeStart_out.strStartReticle[i].reticleID      = strReticle_FillInTxPDQ004DR_out.strReticleListInqResult.strFoundReticle[j].reticleID; //0.01
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "findFlag != TRUE");

//D4200081//P3100077 start
//D4200081                        if ( TRUE == bInhibitErr )
//D4200081                        {
//D4200081                            PPT_METHODTRACE_V1("", "TRUE == bInhibitErr");
//D4200081                            PPT_SET_MSG_RC_KEY2 ( strProcessDurable_CheckConditionForOpeStart_out,
//D4200081                                                  MSG_INHIBIT_ENTITY,
//D4200081                                                  RC_INHIBIT_ENTITY,
//D4200081                                                  inhibitErrReticleID.identifier,
//D4200081                                                  SP_InhibitClassID_Reticle );
//D4200081                            return(RC_INHIBIT_ENTITY);
//D4200081                        }
//D4200081//P3100077 end

                        SET_MSG_RC(strProcessDurable_CheckConditionForOpeStart_out,MSG_NOT_AVAILABLE_RETICLE,RC_NOT_AVAILABLE_RETICLE);
                        return(RC_NOT_AVAILABLE_RETICLE);
                    }
                }
            }
        }                                                                                                //D4200031

        /*-----------------------------------------------*/
        /*                                               */
        /*   Get and Check Fixture Status for Each Lot   */
        /*                                               */
        /*-----------------------------------------------*/
        if (fixtureRequiredFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", "fixtureRequiredFlag == TRUE");

            /*----------------------------*/
            /*   Get Fixture Group List   */
            /*----------------------------*/
            PosLogicalRecipe_var aLogicalRecipe;
            PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR(aLogicalRecipe,logicalRecipeID,strProcessDurable_CheckConditionForOpeStart_out,processDurable_CheckConditionForOpeStart);

            PosMachineRecipe_var aMachineRecipe;
//D7000042  PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR(aMachineRecipe,machineRecipeID,strProcessDurable_CheckConditionForOpeStart_out,processDurable_CheckConditionForOpeStart);

//D6000415 add start
            /************************/
            /*   Get subLotType     */
            /************************/
            PosLot_var aLot ;
            PPT_CONVERT_LOTID_TO_LOT_OR( aLot, lotID,
                                         strProcessDurable_CheckConditionForOpeStart_out,
                                         processDurable_CheckConditionForOpeStart );
            CORBA::String_var subLotType;
            try
            {
                subLotType = aLot->getSubLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
//D6000415 add end
            if( searchCondition == 1 )                                                       //DSIV00001443
            {                                                                                //DSIV00001443
                try                                                                          //DSIV00001443
                {                                                                            //DSIV00001443
                    aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine ); //DSIV00001443
                }                                                                            //DSIV00001443
                CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)           //DSIV00001443
            }                                                                                //DSIV00001443
            else                                                                             //DSIV00001443
            {                                                                                //DSIV00001443
//D7000042 add start
                try
                {
                    aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType( aMachine, subLotType );
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType)
//D7000042 add end
            }                                                                                //DSIV00001443

            PosProcessDurableCapabilitySequence* aFixtureGroupSeq = NULL; //P2200204
            PosProcessDurableCapabilitySequence_var aVarFixtureGroupSeq;
            try
            {
//D6000415      aFixtureGroupSeq = aLogicalRecipe->findFixtureGroupsFor(aMachine,aMachineRecipe);
                aFixtureGroupSeq = aLogicalRecipe->findFixtureGroupsForSubLotType( aMachine, aMachineRecipe, subLotType ) ;    //D6000415
                aVarFixtureGroupSeq = aFixtureGroupSeq;
            }
//D6000415  CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findFixtureGroupsFor);
            CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findFixtureGroupsForSubLotType);    //D6000415

            /*----------------------*/
            /*   Get Fixture List   */
            /*----------------------*/
            CORBA::Long FGSLength;
            FGSLength = (*aFixtureGroupSeq).length();

            //Q3000066 add start
            if ( FGSLength == 0 )
            {
                PPT_METHODTRACE_V1("", "FGSLength == 0");
                SET_MSG_RC(strProcessDurable_CheckConditionForOpeStart_out,MSG_NOT_AVAILABLE_FIXTURE,RC_NOT_AVAILABLE_FIXTURE);
                return(RC_NOT_AVAILABLE_FIXTURE);
            }
            //Q3000066 add end

            strProcessDurable_CheckConditionForOpeStart_out.strStartFixture.length(FGSLength);

            for (CORBA::Long i=0 ; i<FGSLength ; i++)
            {
                PPT_METHODTRACE_V3("", "loop to (*aFixtureGroupSeq).length()",FGSLength,i);

                objectIdentifier fixtureGroupID;
                PPT_SET_OBJECT_IDENTIFIER(fixtureGroupID,(*aFixtureGroupSeq)[i],strProcessDurable_CheckConditionForOpeStart_out,processDurable_CheckConditionForOpeStart, PosProcessDurableCapability);

                objectIdentifier equipmentID_nil;
                objectIdentifier lotID_nil;
                objectIdentifier fixtureID_nil;
                CORBA::String_var fixturePartNumber_nil;
                objectIdentifier fixtureCategoryID_nil;
                CORBA::String_var fixtureStatus_nil;          //D4000043
                objFixture_FillInTxPDQ001DR_out strFixture_FillInTxPDQ001DR_out;
//D4000043      rc = fixture_FillInTxPDQ001DR(strFixture_FillInTxPDQ001DR_out,strObjCommonIn,equipmentID_nil,lotID_nil,fixtureID_nil,fixturePartNumber_nil,fixtureGroupID,fixtureCategoryID_nil);
//P6000448                rc = fixture_FillInTxPDQ001DR(strFixture_FillInTxPDQ001DR_out,strObjCommonIn,equipmentID_nil,lotID_nil,fixtureID_nil,fixturePartNumber_nil,fixtureGroupID,fixtureCategoryID_nil,fixtureStatus_nil,SP_Durable_MaxCountInGroup); //D4000043

                //P6000448 Add Start
                rc = fixture_FillInTxPDQ001DR( strFixture_FillInTxPDQ001DR_out,
                                               strObjCommonIn,
                                               equipmentID,
                                               lotID_nil,
                                               fixtureID_nil,
                                               fixturePartNumber_nil,
                                               fixtureGroupID,
                                               fixtureCategoryID_nil,
                                               fixtureStatus_nil,
                                               0 );
                //P6000448 Add End

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "fixture_FillInTxPDQ001DR() != RC_OK");
                    strProcessDurable_CheckConditionForOpeStart_out.strResult = strFixture_FillInTxPDQ001DR_out.strResult;
                    return(rc);
                }

                CORBA::Boolean findFlag = FALSE;
                CORBA::Long FFLength;
                FFLength = strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture.length();
                for (CORBA::Long j=0 ; j<FFLength ; j++)
                {
                    PPT_METHODTRACE_V3("", "loop to strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture.length()",FFLength,j);

                    if ( CIMFWStrCmp(strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureStatusInfo.equipmentID.identifier,equipmentID.identifier) == 0 &&
                         CIMFWStrCmp(strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureStatusInfo.transferStatus,SP_TransState_EquipmentIn) == 0 &&
                        (CIMFWStrCmp(strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureStatusInfo.fixtureStatus,CIMFW_Durable_Available) == 0 ||
                         CIMFWStrCmp(strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureStatusInfo.fixtureStatus,CIMFW_Durable_InUse) == 0))
                    {
//D4200081 start
                        PPT_METHODTRACE_V1("", "call equipment_CheckInhibitForLotWithMachineRecipe()");
                        pptStartCassetteSequence strStartCassetteSeq;
                        strStartCassetteSeq.length(1);
                        strStartCassetteSeq[0].strLotInCassette.length(1);

                        objectIdentifierSequence checkLotIDs;
                        checkLotIDs.length(1);
                        checkLotIDs[0] = lotID;
                        PPT_METHODTRACE_V2("", "lotID", lotID.identifier);

                        strStartCassetteSeq[0].strLotInCassette[0].lotID = lotID;
                        strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.machineRecipeID = machineRecipeID;
                            PPT_METHODTRACE_V2("", "machineRecipeID", machineRecipeID.identifier);

                        strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartFixture.length(1);
                        strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartFixture[0].fixtureID
                                = strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureStatusInfo.fixtureID;
                        PPT_METHODTRACE_V2("", "fixtureID", strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureStatusInfo.fixtureID.identifier);

                        strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.logicalRecipeID = logicalRecipeID;   //D5100087
                        PPT_METHODTRACE_V2("", "logicalRecipe", logicalRecipeID.identifier);                           //D5100087

                        objEquipment_CheckInhibitForLotWithMachineRecipe_out strEquipment_CheckInhibitForLotWithMachineRecipe_out;
                        rc = equipment_CheckInhibitForLotWithMachineRecipe( strEquipment_CheckInhibitForLotWithMachineRecipe_out,
                                                                            strObjCommonIn,
                                                                            equipmentID,
                                                                            checkLotIDs,
                                                                            strStartCassetteSeq );
                        if ( RC_OK != rc )
                        {
                            PPT_METHODTRACE_V2("", "RC_OK != equipment_CheckInhibitForLotWithMachineRecipe() ...continue", rc);
                            continue;
                        }
//D4200081 end

                        PPT_METHODTRACE_V1("", "returned strFoundFixture value == TRUE");
                        findFlag = TRUE;
                        break;
                    }
                }

                if (findFlag == TRUE)
                {
                    PPT_METHODTRACE_V1("", "findFlag == TRUE");
//0.01              strProcessDurable_CheckConditionForOpeStart_out.strStartFixture[i+1].fixtureID       = strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureStatusInfo.fixtureID;
//0.01              strProcessDurable_CheckConditionForOpeStart_out.strStartFixture[i+1].fixtureCategory = CIMFWStrDup(strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureCategoryID.identifier);
                    strProcessDurable_CheckConditionForOpeStart_out.strStartFixture[i].fixtureID       = strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureStatusInfo.fixtureID; //0.01
                    strProcessDurable_CheckConditionForOpeStart_out.strStartFixture[i].fixtureCategory = CIMFWStrDup(strFixture_FillInTxPDQ001DR_out.strFixtureListInqResult.strFoundFixture[j].fixtureCategoryID.identifier); //0.01
                }
                else
                {
                    PPT_METHODTRACE_V1("", "findFlag != TRUE");
                    SET_MSG_RC(strProcessDurable_CheckConditionForOpeStart_out,MSG_NOT_AVAILABLE_FIXTURE,RC_NOT_AVAILABLE_FIXTURE);
                    return(RC_NOT_AVAILABLE_FIXTURE);
                }
            }
        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::processDurable_CheckConditionForOpeStart");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strProcessDurable_CheckConditionForOpeStart_out, processDurable_CheckConditionForOpeStart, methodName);
}

