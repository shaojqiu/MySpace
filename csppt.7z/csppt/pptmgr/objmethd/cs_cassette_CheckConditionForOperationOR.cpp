#ifndef lint
static char *sccsid =  "%Z% %I% %W% %G% %U% [ %H% %T% ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_cassette_CheckConditionForOperationOR.cpp
//

#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "pcas.hh"
#include "ppcope.hh"
#include "pmc.hh"
#include "plcrc.hh"
#include "pmcrc.hh"


//[Object Function Name]: long   cassette_CheckConditionForOperation
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2000-07-01  0.00         Y.Iwasaki      Initial Release
// 2000-08-08  0.01         Y.Iwasaki      Change controlJobID check logic for OpeStart
// 2000-08-08  0.02         Y.Iwasaki      Change rc and msg
// 2000-08-24  0.03         Y.Iwasaki      Change method getCurrentState->getDurableState
// 2000-08-29  0.04         Y.Iwasaki      Change method getMultiRecipeCapability ->
//                                                 getMultipleRecipeCapability
// 2000-09-07  P3000062     Y.Iwasaki      Change define of multiRecipeCapability
//                                               A -> Multiple Recipe
//                                               B -> Single Recipe
//                                               C -> Batch
// 2000-09-14  P3000175     Y.Iwasaki      Bug fix for CassetteCount Check
// 2000-09-16  P3000185     Y.Iwasaki      Add Start Cassette's Loading Order Check Logic
// 2000-09-20  Q3000107     Y.Iwasaki      Change EmptyCassetteCount check logic
// 2000-09-21  0.05         Y.Iwasaki      Bug fix of Eqp-Capability vs Cast-MultiLotType
//                                            compare logic for Empty Cassette
// 2000-10-02  P3000248     Y.Iwasaki      Bug fix for LoadPurposeType (meaning of _Any)
// 2000-10-26  D3000079     Y.Iwasaki      Add check logic for combination of eqp's
//                                            multiRecipeCapability VS recipeParameter value
// 2000/11/09  P2200204     R.Furuta       Initialize local pointers
// 2000/12/18  0.06         K.Matsuei      Logic fix for Delivery Eqp to Eqp
// 2001/03/12  P3100097     K.Matsuei      Add Check ParamerterValue
// 2001/04/09  P3100252     K.Matsuei      Upper/Lower Limit Check is wrong for RecipeParameterChange
// 2001/04/17  P3100289     K.Matsuei      Add Check MonitorLotCount and OperationStartLotCount
// 2001/04/24  P3100301     K.Matsuei      There is a case which surely becomes an error
//                                            with RecipeParameter of OpeStart.
// 2001/07/24  D4000028     K.Takikita     Add new logic for Non-WIP Carrier Xfer.
// 2001/08/23  D4000028     K.Takikita     Add MultiLotType Single Recipe And Multi Recipe
// 2001/08/27  D4000028     K.Takikita     Change logic for Non-WIP Carrier Xfer.
// 2001/09/07  D4000028(1)  T.Yamamoto     Add cassetteState Check Logic
//                                            Port:Other&NPW->NoCheck
// 2001/09/21  0.07         K.Matsuei      Make it an error when AccessMode is Manual and XferStatus is EI.
// 2002/02/01  P4100105     K.Matsuei      Cassette's XferStatus CheckLogic is Incorrect in StartLotsReservation.
// 2002/07/25  D4200069     H.Adachi       Add Start Cassette and Start Lot Combination Check.
// 2002/09/25  P4200192     H.Adachi       Add Nil Check
// 2002/10/02  D4200122     K.Matsuei      Measure from which empty ControlJob is made by OpeStart.
// 2002/10/30  P4200290     H.Adachi       Add Start Cassette and Start Lot Combination Check For StartReserve.
// 2002/11/22  P4200398     M.Kase         Modify check logic of recipe parameter value for OpeStart.
// 2003/02/07  P4200533     H.Adachi       Add ProcessMonitorLot Quantity Check
// 2003/03/13  P5000003     H.Adachi       MM Server Down at narrow to PosMachineObject.
// 2003/08/15  D5000194     K.Matsuei      ReRoute of Xfer is supported by CassetteDelivery.
// 2003/10/09  P5100030     K.Matsuei      Limit of Integer type of RecipeParameter is not checked.
// 2003/10/17  D5100053     T.Hikari       ProcessMonitoring By ProductionLot.
// 2005/08/31  D6000415     K.Kido         Call findRecipeParametersForSubLotType() to get correct Recipe Parameter taken into account for Chamber Machine State.
// 2005/12/07  D7000042     K.Kido         Get Machine Recipe by findMachineRecipeForSubLotType for findRecipeParametersForSubLotType.
// 2006/11/23  D8000024     H.Mutoh        When FPC overwrite the machineRecipe, skip the logic of machineRecipe getting from PO.
//                                           if FPC overwrite the recipeParameter, the parameter check is taken place with the FPC's parameter.
// 2007/02/23  P8000119     K.Matsuei      OpeStartCancel and OpeComp cannot perform.
// 2007/06/12  D9000005     H.Hotta        WaferSorter automation support.
// 2007/10/15  D9000001     K.Matsuei      64bit support.
// 2008/08/08  P9000002     K.Kido         Change reroute logic for EO/SO cassette.
// 2008/12/08  DSIV00000518   K.Matsuei    ReRoute of BO is permitted by Auto3.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
// 2010/07/09 DSIV00001788 S.Kawabe       Improve the sequence of loading a cassette on equipment
// 2012/12/18 PSN000062207 GC.Wang        Error message fix for Start Lots Reservation
// 2013/10/15 DSN000080573 JJ.Zhang       Performance improvement on StartLotsReservation
// 2015/08/04 DSN000096135 T.Ishida       Virtual Operation
// 2016/07/13 DSN000101569 K.Yamaoku      Durable Sub Status Control
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Jun Zhang      New Transfer State PI/PO.
//
//[Function Description]:
//  Check cassette's condition for StartReservation, OpeStart, and FlowBatching.
//  The following conditions are checked for each specified operation.
//
//  - controlJobID
//  - multiLotType
//  - transferState
//  - transferReserved
//  - dispatchState
//  - cassetteState
//  - maxBatchSize
//  - minBatchSize
//  - cassette's loadingSequenceNumber                  //P3000185
//  - eqp's multiRecipeCapability and recipeParameter   //D3000079
//
//  <<< Condition for controlJobID, multiLotType, transferState, transferReserved >>>
//
//                       || control multiLot transfer transfer dispatch
//   in-parm's operation ||  JobID    Type    State   Reserved  State
//   ====================||======== ======== ======== ======== ========
//    StartReservation   ||  null     (*1)     (*2)     (*2)    FALSE
////  OpeStart           ||  null     (*1)      EI       na      na
//    OpeStart           ||  (*0)     (*1)      EI       na      na      //0.01
//    FlowBatching       ||  null     (*1)   SI/MI/BI   FALSE   FALSE
//    Non-WIP Carrier    ||  null      na    SI/MI/BI   FALSE   FALSE    //D4000028
//
//  About *0, all of cassettes' controlJobID must be same. If it is not null case,  //0.01
//  strStartCassette[]'s cassettes and PosProcessJob's contained cassettes must be  //0.01
//  same perfectlly.                                                                //0.01
//
//  About *1, the following conditions must be met.
//  If LoadPurposeType is EmptyCassette case, this check is passed.                 //0.05
//
//            Eqp's         ||                Cassette's
//    multiRecipeCapability ||               multiLotType
//    ======================||=============================================
//        Multiple Recipe   ||               everything OK                          //P3000062
//    --------------------- || --------------------------------------------
//         SIngle Recipe    ||               everything OK                          //P3000062
//    --------------------- || --------------------------------------------
//                          ||  SP_Cas_MultiLotType_SingleLotSingleRecipe
//             Batch        ||                     or                               //P3000062
//                          ||  SP_Cas_MultiLotType_MultiLotSingleRecipe
//
//  About *2, the following conditions must be met.
//
//                          ||                 Cassette's
//       Eqp's accessMode   ||    transferState    |    transferReserved
//    ======================||=====================|=======================
//            MANUAL        ||       no-check      |        no-check
//    --------------------- || ------------------- | ----------------------
//                          ||       SI/MI/BI      |         FALSE
//            AUTO (*3)     || ------------------- | ----------------------
//                          ||         (EI)        |         (FALSE)    //0.06
////                          ||         (EI)        |         (TRUE)
//
//  About *3, if accessMode is AUTO case, basically transferState must be SI/MI/BI,
//  and transferReserved must be FALSE. However, in the case of Eqp-to-Eqp Xfer,
//  transferState is EI, and transferReserved is TURE. In this Eqp-to-Eqp case,
//  MM must check originator eqp's EqpToEqp transfer Flag is TURE or not, and
//  originator eqp's accessMode (=cassette's equipmentID) must be AUTO.
//
//  <<< Condition for cassetteState >>>
//
//D4000028(1)  - About cassetteState, it must be _Available or _InUse.
//  - About cassetteState, it is not required to check for SP_Operation_NPWCarrierXfer in-param's. //D4000028(1)
//                            & port's LoadPurposeType: _Other or _Empty                           //D4000028(1)
//      The other Case,    it must be _Available or _InUse.                                        //D4000028(1)
//
//  <<< Condition for maxBatchSize, minBatchSize, emptyCassetteCount >>>
//
//  - About maxBatchSize, minBatchSize
//    The total count of cassette, which loadPurposeType is "ProcessLot", "ProcessMonitorLot",
//    or "Any", must be inside of equipment's maxBatchSize and minBatchSize.
//    The total count of cassette, which loadPurposeType is "ProcessLot" or "ProcessMonitorLot" //P3000248
//    must be inside of equipment's maxBatchSize and minBatchSize.                              //P3000248
//
//  - About emptyCassetteCount
//    If equipment is registered as "CassetteExchange" type, process lot's cassette count
//    and empty cassette count must be same.
//    If equipment is registered as "MonitorCreation" type, empty cassette count must be 1.
//    (This check is not required for FlowBatching)
//
//  <<< Condition for cassette's loadingSequenceNumber >>>                      //P3000185
//    the followings are not required to check for SP_Operation_NPWCarrierXfer in-param's. //D4000028
//  - strStartCassette[].loadSequenceNumber must be correct order from 1 to N.  //P3000185
//
//  <<< eqp's multiRecipeCapability and recipeParameter >>>                              //D3000079
//    the followings are not required to check for SP_Operation_NPWCarrierXfer in-param's. //D4000028
//  - If equipment's multiRecipeCapability is Batch or Single-Recipe, all of startLots'  //D3000079
//    recipeParameter-set must be same.                                                  //D3000079
//
//  The following input-parameters must be filled to call this object function.
//  - equipmentID
//  - portGroupID
//  - operation
//  - strStartCassette[].cassetteID
//D3000079  - strStartCassette[].loadPurposeType   <--- if operation is SP_Operation_FlowBatching,
//D3000079                                              no need to fill
//D4000028  From here, the followings are not required to fill for SP_Operation_FlowBatching               //D3000079
//  From here, the followings are not required to fill for SP_Operation_FlowBatching and SP_NPWCarrierXfer//D4000028
//  - strStartCassette[].strLotInCassette[].recipeParameterChangeType                              //D3000079
//  - strStartCassette[].strLotInCassette[].strLotWafer[].strStartRecipeParameter[].parameterName  //D3000079
//  - strStartCassette[].strLotInCassette[].strLotWafer[].strStartRecipeParameter[].parameterValue //D3000079
//
//  The number of Lot that MonitorLotFlag is TRUE should be 0 or 1.                                     //P3100289
//  And, the number (OperationStartFlag = TRUE) of Lot except for this Lot should be beyond 1 with 1    //P3100289
//  the number of Lot that MonitorLotFlag is TRUE.                                                      //P3100289
//
// <<< Sorter job existence >>>
//  Check whether input cassette has SorterJob or not.
//  When the cassette has SorterJob, Start Lot Reservation and OperStart are prevented.
//  If operation is NPW reservation, then the Sorter Job validity is checked.
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  string                      portGroupID;
//  in  sequence <pptStartCassette> strStartCassette;
//  in  string                      operation;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForOperation_out   strCassette_CheckConditionForOperation_out;
//
//  typedef struct objCassette_CheckConditionForOperation_out_struct {
//      pptRetCode                  strResult;
//  } objCassette_CheckConditionForOperation_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//
//[Pseudo Code]:
//

CORBA::Long CS_PPTManager_i::cassette_CheckConditionForOperation(
                            objCassette_CheckConditionForOperation_out& strCassette_CheckConditionForOperation_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const char * portGroupID,
                            const pptStartCassetteSequence& strStartCassette,
                            const char * operation )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cassette_CheckConditionForOperation");

        PPT_METHODTRACE_V2("","in para equipmentID", equipmentID.identifier);
        PPT_METHODTRACE_V2("","in para portGroupID", portGroupID);
        PPT_METHODTRACE_V2("","in para operation  ", operation);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        //DSN000096135 Add Start
        CORBA::Boolean virtualOperationFlag = FALSE;

        if( CIMFWStrLen( portGroupID ) <= 0 && CIMFWStrCmp( operation, SP_Operation_OpeStart ) == 0 )
        {
            objVirtualOperation_CheckByStartCassette_out strVirtualOperation_CheckByStartCassette_out;
            objVirtualOperation_CheckByStartCassette_in  strVirtualOperation_CheckByStartCassette_in;

            strVirtualOperation_CheckByStartCassette_in.strStartCassette = strStartCassette;

            rc = virtualOperation_CheckByStartCassette( strVirtualOperation_CheckByStartCassette_out, strObjCommonIn, strVirtualOperation_CheckByStartCassette_in );

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "virtualOperation_CheckByStartCassette() != RC_OK" );
                strCassette_CheckConditionForOperation_out.strResult = strVirtualOperation_CheckByStartCassette_out.strResult;
                return( rc );
            }

            PPT_METHODTRACE_V2( "", "virtualOperationFlag = ", strVirtualOperation_CheckByStartCassette_out.virtualOperationFlag );
            virtualOperationFlag = strVirtualOperation_CheckByStartCassette_out.virtualOperationFlag;
        }
        //DSN000096135 Add End

        /*-------------------------------------------------------------------------------------*/
        /*                                                                                     */
        /*   Check Condition of controlJobID, multiLotType, transferState, transferReserved,   */
        /*   dispatchState, and cassetteState for all cassettes                                */
        /*   dispatchState, cassetteState, and loadingSequenceNumber for all cassettes         */ //P3000185
        /*                                                                                     */
        /*-------------------------------------------------------------------------------------*/

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PPT_METHODTRACE_V1("","Get Equipment Object");

        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         equipmentID,
                                         strCassette_CheckConditionForOperation_out,
                                         cassette_CheckConditionForOperation );

        /*-------------------------------------------*/
        /*   Get Equipment's MultiRecipeCapability   */
        /*-------------------------------------------*/
        PPT_METHODTRACE_V1("","Get Equipment's MultiRecipeCapability");

        CORBA::String_var multiRecipeCapability;
        try
        {
            multiRecipeCapability = aMachine->getMultipleRecipeCapability();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getMultipleRecipeCapability)

        /*-----------------------------------------*/
        /*   Get Equipment's Operation Mode Info   */
        /*-----------------------------------------*/
        PPT_METHODTRACE_V1("","Get Equipment's Operation Mode Info");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
        {
            PPT_METHODTRACE_V1("","operation == SP_Operation_OpeStart, SP_Operation_StartReservation");

            objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;

            if( virtualOperationFlag == FALSE )    //DSN000096135
            {                                      //DSN000096135
                rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                            strObjCommonIn,
                                                            equipmentID,
                                                            strStartCassette[0].loadPortID );

                if ( rc != RC_OK )
                {
                    strCassette_CheckConditionForOperation_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
                    return rc;
                }
                PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get=RC_OK")
            }                                      //DSN000096135
        }
        else
        {
            PPT_METHODTRACE_V1("", "operation != SP_Operation_OpeStart && operation != SP_Operation_StartReservation")
        }

        /*------------------------------*/
        /*   Check Cassette Condition   */
        /*------------------------------*/
        CORBA::Long i, j, k, l, m;
        CORBA::Long lenCassette = strStartCassette.length();
        objectIdentifier saveControlJobID;      //0.01
        CORBA::Long cjCastCnt;                  //P3000175

        PPT_METHODTRACE_V2("","Check Cassette Condition  lenCassette=", lenCassette);

        CORBA::Long sequenceCondition = 0;                                                                                         //DSIV00001788
        CORBA::String_var sequenceCondition_var = CIMFWStrDup(getenv("SP_CASSETTE_LOAD_SEQUENCE_CONDITION"));                      //DSIV00001788
        if( CIMFWStrLen(sequenceCondition_var) > 0 )                                                                               //DSIV00001788
        {                                                                                                                          //DSIV00001788
            sequenceCondition = atoi(sequenceCondition_var);                                                                       //DSIV00001788
        }                                                                                                                          //DSIV00001788
                                                                                                                                   //DSIV00001788
        CORBA::Boolean bCassetteLoadingCheck = FALSE;                                                                              //DSIV00001788
        if( sequenceCondition == 0 &&                                                                                              //DSIV00001788
           ( ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)))) //DSIV00001788
        {                                                                                                                          //DSIV00001788
            PPT_METHODTRACE_V1("", "(operation == SP_Operation_OpeStart) || (operation == SP_Operation_StartReservation)");        //DSIV00001788
            bCassetteLoadingCheck = TRUE;                                                                                          //DSIV00001788
        }                                                                                                                          //DSIV00001788
        if( sequenceCondition == 1 && 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )                                 //DSIV00001788
        {                                                                                                                          //DSIV00001788
            PPT_METHODTRACE_V1("", "(operation == SP_Operation_StartReservation)");                                                //DSIV00001788
            bCassetteLoadingCheck = TRUE;                                                                                          //DSIV00001788
        }                                                                                                                          //DSIV00001788

        for ( i=0; i < lenCassette; i++ )
        {
            PPT_METHODTRACE_V3("","  [].cassetteID", i, strStartCassette[i].cassetteID.identifier);

//D9000005 add start
            /*-------------------------------*/
            /*   Check SorterJob existence   */
            /*-------------------------------*/
            if( 0 == CIMFWStrCmp( operation, SP_Operation_NPWCarrierXfer )  ||
                0 == CIMFWStrCmp( operation, SP_Operation_StartReservation) ||
                0 == CIMFWStrCmp( operation, SP_Operation_OpeStart))
            {
                objectIdentifierSequence dummyIDs;
                pptEquipmentLoadPortAttribute equipmentPortAttribute;
                equipmentPortAttribute.strCassetteLoadPortSeq.length(1);
                equipmentPortAttribute.strCassetteLoadPortSeq[0].portID     = strStartCassette[i].loadPortID;
                equipmentPortAttribute.strCassetteLoadPortSeq[0].cassetteID = strStartCassette[i].cassetteID;
                equipmentPortAttribute.equipmentID                          = equipmentID;

                objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
                objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
                strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = equipmentPortAttribute;
                strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs.length(1);
                strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs[0]                = strStartCassette[i].cassetteID;
                strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyIDs;
                strWaferSorter_sorterJob_CheckForOperation_in.operation                     = operation;

                rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                              strObjCommonIn,
                                                              strWaferSorter_sorterJob_CheckForOperation_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
                    strCassette_CheckConditionForOperation_out.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
                    return( rc );
                }
            }
//D9000005 add end

//P3000185 add start
            /*------------------------------------------*/
            /*   Check Start Cassette's Loading Order   */
            /*------------------------------------------*/
//DSIV00001788            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
            if( bCassetteLoadingCheck == TRUE )                                                                                    //DSIV00001788
            {
//DSIV00001788                PPT_METHODTRACE_V1("", "(operation == SP_Operation_OpeStart) || (operation == SP_Operation_StartReservation)");

                if( virtualOperationFlag == FALSE )    //DSN000096135
                {                                      //DSN000096135
                    if ( strStartCassette[i].loadSequenceNumber != (i+1) )
                    {
                        PPT_METHODTRACE_V1("", "strStartCassette[i].loadSequenceNumber != i");
                        PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperation_out,
                                            MSG_INVALID_LOADING_SEQ,
                                            RC_INVALID_LOADING_SEQ,
                                            strStartCassette[i].cassetteID.identifier );

                        return RC_INVALID_LOADING_SEQ;
                    }
                }                                      //DSN000096135
            }
//P3000185 add end

            /*-------------------------*/
            /*   Get Cassette Object   */
            /*-------------------------*/
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strStartCassette[i].cassetteID,
                                                   strCassette_CheckConditionForOperation_out,
                                                   cassette_CheckConditionForOperation );

            /*--------------------------------*/
            /*   Get and Check ControlJobID   */
            /*--------------------------------*/
            PosControlJob_var aControlJob;
            try
            {
                aControlJob = aCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

//0.01 start
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
            {
                PPT_METHODTRACE_V2("","operation == SP_Operation_OpeStart", operation);

                if ( i == 0 )
                {
                    PPT_METHODTRACE_V1("","i == 0");

                    PPT_SET_OBJECT_IDENTIFIER( saveControlJobID,
                                               aControlJob,
                                               strCassette_CheckConditionForOperation_out,
                                               cassette_CheckConditionForOperation,
                                               PosControlJob );
                }
                else
                {
                    PPT_METHODTRACE_V1("","i != 0");

                    objectIdentifier castControlJobID;
                    PPT_SET_OBJECT_IDENTIFIER( castControlJobID,
                                               aControlJob,
                                               strCassette_CheckConditionForOperation_out,
                                               cassette_CheckConditionForOperation,
                                               PosControlJob );

                    if ( 0 != CIMFWStrCmp(castControlJobID.identifier, saveControlJobID.identifier) )
                    {
                        PPT_METHODTRACE_V1("","castControlJobID != saveControlJobID");
                        SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                    MSG_CAST_CTRLJOB_MIX,
                                    RC_CAST_CTRLJOB_MIX );

                        return RC_CAST_CTRLJOB_MIX;
                    }
                }
            }
            else
            {
//0.01 end
                if ( ! CORBA::is_nil(aControlJob) )
                {

                    PPT_METHODTRACE_V1("","aControlJob is not nil");
//0.02 start
                    SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                MSG_CAST_CTRLJOBID_FILLED,
                                RC_CAST_CTRLJOBID_FILLED );
//0.02        set strResult by using RC_CASSETTE_CONTROLJOBID_FILLED, MSG_CASSETTE_CONTROLJOBID_FILLED
//0.02        return( RC_CASSETTE_CONTROLJOBID_FILLED );
//0.02 end

                    return RC_CAST_CTRLJOBID_FILLED;
                }
            }

            /*---------------------------------*/
            /*   Get Cassette's MultiLotType   */
            /*---------------------------------*/
            PPT_METHODTRACE_V1("","Get Cassette's MultiLotType");

            CORBA::String_var multiLotType;
            try
            {
                multiLotType = aCassette->getMultiLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType)

            /*-------------------------------------------------*/
            /*   Check MultiRecipeCapability VS MultiLotType   */
            /*-------------------------------------------------*/
            PPT_METHODTRACE_V1("","Check MultiRecipeCapability VS MultiLotType");

//0.05 start
            if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
            {
                PPT_METHODTRACE_V1("","strStartCassette[i].loadPurposeType == SP_LoadPurposeType_EmptyCassette");
                rc = RC_OK;
            }
            else
//0.05 end
//P3000062  if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_A) )
            if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_MultipleRecipe) ) //P3000062
            {
                PPT_METHODTRACE_V1("","multiRecipeCapability == SP_Eqp_MultiRecipeCapability_A");

                rc = RC_OK;
            }
//P3000062  else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_B) )
            else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe) ) //P3000062
            {
                PPT_METHODTRACE_V1("","multiRecipeCapability == SP_Eqp_MultiRecipeCapability_B");

                rc = RC_OK;
            }
//P3000062  else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_C) )
            else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) ) //P3000062
            {
                PPT_METHODTRACE_V1("","multiRecipeCapability == SP_Eqp_MultiRecipeCapability_C");

//D4000028                 if ( 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_SingleLotSingleRecipe)
//D4000028                   || 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_MultiLotSingleRecipe) )
                if ( 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer) )                     //D4000028
                {
                    PPT_METHODTRACE_V2("","(operation == SP_Operation_NPWCarrierXfer)", operation); //D4000028
                    PPT_METHODTRACE_V1("","rc = RC_OK");

                    rc = RC_OK;
                }
                else if( ( 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_SingleLotSingleRecipe) ) || //D4000028
                        ( 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_MultiLotSingleRecipe) ) )    //D4000028
                {                                                                                         //D4000028
                    PPT_METHODTRACE_V2("","(multiLotType ==  SP_Cas_MultiLotType_SingleLotSingleRecipe || SP_Cas_MultiLotType_MultiLotSingleRecipe)", operation); //D4000028
                    PPT_METHODTRACE_V1("","rc = RC_OK");
                    rc = RC_OK;                                                                           //D4000028
                }                                                                                         //D4000028
                else
                {
                    PPT_METHODTRACE_V1("","return RC_CAST_EQP_CONDITION_ERROR!!");
                    SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                MSG_CAST_EQP_CONDITION_ERROR,
                                RC_CAST_EQP_CONDITION_ERROR );

                    return RC_CAST_EQP_CONDITION_ERROR;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","No Process <Check MultiRecipeCapability VS MultiLotType>");
            }

            /*--------------------------------------*/
            /*   Check Cassette's Transfer Status   */
            /*--------------------------------------*/

            /*-----------------------*/
            /*   Get TransferState   */
            /*-----------------------*/
            PPT_METHODTRACE_V1("","Get TransferState");

            CORBA::String_var transferState;
            try
            {
                transferState = aCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

            /*------------------------------*/
            /*   Get TransferReserveState   */
            /*------------------------------*/
            PPT_METHODTRACE_V1("","Get TransferReserveState");

            CORBA::Boolean transferReserved;
            try
            {
                transferReserved = aCassette->isReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isReserved)


PPT_METHODTRACE_V2("", "operation--->", operation);
PPT_METHODTRACE_V2("", "transferState--->", transferState);
if (transferReserved){
    PPT_METHODTRACE_V1("", "transferReserved--->TRUE");
}
else{
    PPT_METHODTRACE_V1("", "transferReserved--->FALSE");
}


            /*===== for OpeStart =====*/
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
            {
                PPT_METHODTRACE_V1("", "operation = SP_Operation_OpeStart")

                if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                {
                    PPT_METHODTRACE_V1("","transferState == SP_TransState_EquipmentIn");

                    rc = RC_OK;
                }
                else
                {
                    if( virtualOperationFlag == FALSE )    //DSN000096135
                    {                                      //DSN000096135
                        PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT!!");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             strStartCassette[i].cassetteID.identifier );

                        return RC_INVALID_CAST_XFERSTAT;
                    }                                      //DSN000096135
                }
            }
            /*===== for FlowBatching =====*/
            else if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching) )
            {
                PPT_METHODTRACE_V1("", "operation = SP_Operation_FlowBatching")

                if ((0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)
                  || 0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)
                  || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn))
                  && (transferReserved == FALSE) )
                {
                    PPT_METHODTRACE_V1("","rc = RC_OK");

                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         transferState,
                                         strStartCassette[i].cassetteID.identifier );

                    return RC_INVALID_CAST_XFERSTAT;
                }
            }
            /*===== for StartReservation =====*/
//D4000028            else if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
            else if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)        //D4000028
                   || 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer))         //D4000028
            {
//D4000028                PPT_METHODTRACE_V1("", "operation = SP_Operation_StartReservation")
                PPT_METHODTRACE_V2("", "(operation == SP_Operation_StartReservation) || (operation == SP_Operation_NPWCarrierXfer)", operation); //D4000028

                objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
                rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                            strObjCommonIn,
                                                            equipmentID,
                                                            strStartCassette[i].loadPortID );

//P4100105 start
                pptEqpPortStatus strOrgEqpPortStatus;
                PosMachine_var aOrgMachine;

//INN-R170003   if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) ||  //INN-R170003
                     0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut) )  //INN-R170003
                {
                    /*-------------------------------*/
                    /*   Get Originator Eqp's Info   */
                    /*-------------------------------*/

                    /*--------------------------------*/
                    /*   Get Originator EquipmentID   */
                    /*--------------------------------*/
                    PPT_METHODTRACE_V1("","Get Originator EquipmentID");

                    Machine_var aMachine;
                    try
                    {
                        aMachine = aCassette->currentAssignedMachine();
//P5000003                        aOrgMachine = PosMachine::_narrow( aMachine );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)

                    //P5000003 Add Start
                    if ( TRUE != CORBA::is_nil(aMachine) )
                    {
                        CORBA::Boolean isStorageBool = FALSE;
                        try
                        {
                            isStorageBool = aMachine->isStorageMachine();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(Machine::isStorageMachine)

                        if ( TRUE != isStorageBool )
                        {
                            aOrgMachine = PosMachine::_narrow( aMachine );
                            PPT_METHODTRACE_V1( "", "isStorageBool is not TRUE: Equipment. So narrow to PosMachine" );
                        }
                        else
                        {
                            PPT_METHODTRACE_V1( "", "isStorageBool is TRUE: Storage" );
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1( "", "aMachine is Nill" );
                    }
                    //P5000003 Add End

                    //P4200192 Add Start
                    if ( CORBA::is_nil(aOrgMachine) )
                    {
                        PPT_METHODTRACE_V1("","aOrgMachine is Nil");
                        PPT_SET_MSG_RC_KEY(strCassette_CheckConditionForOperation_out,
                                           MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, equipmentID.identifier)
                        return RC_NOT_FOUND_EQP;
                    }
                    //P4200192 Add End

                    objectIdentifier orgEquipmentID;
                    PPT_SET_OBJECT_IDENTIFIER( orgEquipmentID,
                                               aOrgMachine,
                                               strCassette_CheckConditionForOperation_out,
                                               cassette_CheckConditionForOperation,
                                               PosMachine );

                    /*---------------------------------*/
                    /*   Get Cassette Info in OrgEqp   */
                    /*---------------------------------*/
                    PPT_METHODTRACE_V1("","Get Cassette Info in OrgEqp");
                    pptEqpPortInfo equipmentPortInfo;
                    CORBA::String_var equipmentCategory;
                    try
                    {
                        equipmentCategory = aOrgMachine->getCategory();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory)
                    PPT_METHODTRACE_V2("","aOrgMachine->getCategory()", equipmentCategory);

                    if ( 0 == CIMFWStrCmp(equipmentCategory, SP_Mc_Category_InternalBuffer) )
                    {
                        PPT_METHODTRACE_V1("","equipmentCategory is [InternalBuffer]");
                        objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
                        rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                                        strObjCommonIn,
                                                                        orgEquipmentID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
                            strCassette_CheckConditionForOperation_out.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                            return( rc );
                        }
                        equipmentPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","equipmentCategory is not [InternalBuffer]");
                        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                                     strObjCommonIn,
                                                     orgEquipmentID );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "equipment_portInfo_Get != RC_OK")
                            strCassette_CheckConditionForOperation_out.strResult = strEquipment_portInfo_Get_out.strResult;
                            return rc;
                        }
                        equipmentPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo;
                    }

                    /*--------------------------------------*/
                    /*   Find Assigned Port's portGroupID   */
                    /*--------------------------------------*/
                    PPT_METHODTRACE_V1("","Find Assigned Port's portGroupID");

                    CORBA::Boolean bFound = FALSE;
                    CORBA::Long lenEqpPort = equipmentPortInfo.strEqpPortStatus.length();
                    for ( j=0; j < lenEqpPort; j++ )
                    {
                        PPT_METHODTRACE_V2("", "portID..............", equipmentPortInfo.strEqpPortStatus[j].portID.identifier);
                        PPT_METHODTRACE_V2("", "loadedCassetteID....", equipmentPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier);

                        if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
                                              equipmentPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","break!!");
                            strOrgEqpPortStatus = equipmentPortInfo.strEqpPortStatus[j];
                            bFound = TRUE;
                            break;
                        }
                    }

                    if ( FALSE == bFound )
                    {
                        PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             strStartCassette[i].cassetteID.identifier );
                        return RC_INVALID_CAST_XFERSTAT;
                    }

                }
//P4100105 end

                if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,
                                      SP_Eqp_AccessMode_Manual) )
                {
                    PPT_METHODTRACE_V1("", ".strOperationMode.accessMode = SP_Eqp_AccessMode_Manual")
//0.07 start
                    /*-------------------------------------------------------------------------*/
                    /*   When TransferStatus is EI, AccessMode makes it an error with Manual   */
                    /*-------------------------------------------------------------------------*/
                    if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                    {
//P4100105 start
                        PPT_METHODTRACE_V1("", ".transferState is [EI]")
                        /*---------------------------------------------------------------------------*/
                        /*   Permit Carrier which a person can deliver in StartLotReserve.           */
                        /*   As for the condition, OperationMode is "***-1" and XferState is "EI".   */
                        /*---------------------------------------------------------------------------*/
                        if ( 0 != CIMFWStrCmp(strOrgEqpPortStatus.accessMode, SP_Eqp_AccessMode_Manual)
                          || 0 == CIMFWStrLen(strOrgEqpPortStatus.loadedCassetteID.identifier) )
                        {
//P4100105 end
                            PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_CAST_XFERSTAT;
                        }   //P4100105
                    }
//0.07 end
                    rc = RC_OK;
                }
                else
                {
//D5000194 start
                    CORBA::Boolean bReRouteFlg = FALSE;
                    CORBA::String_var reRouteXferFlag = CIMFWStrDup(getenv(SP_REROUTE_XFER_FLAG));
                    PPT_METHODTRACE_V2("","SP_REROUTE_XFER_FLAG ---> ",reRouteXferFlag);

                    PPT_METHODTRACE_V2("","operationMode", strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier); //DSIV00000518

                    if ( 0 == CIMFWStrCmp(reRouteXferFlag, "1")
//DSIV00000518                      && ( 0 == CIMFWStrCmp("TXDSC008", strObjCommonIn.transactionID) || 0 == CIMFWStrCmp("TXDSC012", strObjCommonIn.transactionID) )
                      && ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier, SP_Eqp_Port_OperationMode_Auto_3) ) //DSIV00000518
                      && ( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn) ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)     ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn)  ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_BayOut) )
                      && ( transferReserved == FALSE ) )
                    {
//DSIV00000518                        PPT_METHODTRACE_V1("", "Transaction is [TXDSC008]TxCassetteDelvieryReq or [TXDSC012]TxCassetteDeliveryForInternalBufferReq")
                        PPT_METHODTRACE_V1("", "operationMode is Auto-3") //DSIV00000518
                        PPT_METHODTRACE_V1("", "transferState = [SI], [BI], [MI], [BO] and transferReserved is FALSE")
                        rc = RC_OK;
                    }
//D5000194 end
//D5000194                    if (( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)
                    else if (( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)  //D5000194
                            || 0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)
                            || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn))
                            && (transferReserved == FALSE) )
                    {
                        PPT_METHODTRACE_V1("", "(transferState = [SI], [BI], [MI] and transferReserved is FALSE")
                        rc = RC_OK;
                    }
//P9000002 add start
                    else if ((   0 == CIMFWStrCmp(transferState, SP_TransState_StationOut)
//INN-R170003                 || 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut)
                              || 0 == CIMFWStrCmp(transferState, CS_TRANS_STATE_PORT_OUT)   //INN-R170003
                             )
                            && (transferReserved == FALSE)
                            )
                    {
                        PPT_METHODTRACE_V1("", "(transferState = [SO], [PO], and transferReserved is FALSE")

                        //-------------------------------------
                        //  Check transfer job existence
                        //-------------------------------------
                        objCassette_transferJobRecord_GetDR_out strCassette_transferJobRecord_GetDR_out;
                        rc = cassette_transferJobRecord_GetDR( strCassette_transferJobRecord_GetDR_out,
                                                               strObjCommonIn,
                                                               strStartCassette[i].cassetteID );

                        if( rc == RC_CARRIER_NOT_TRANSFERING )
                        {
                            PPT_METHODTRACE_V1("", "The Carrier is not transfering. Return error...");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_CAST_XFERSTAT;
                        }
                        else if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "cassette_transferJobRecord_GetDR() rc != RC_OK");
                            strCassette_CheckConditionForOperation_out.strResult = strCassette_transferJobRecord_GetDR_out.strResult ;
                            return( rc );
                        }

                        objStocker_type_GetDR_out  strStocker_type_GetDR_out;
                        rc = stocker_type_GetDR( strStocker_type_GetDR_out,
                                                 strObjCommonIn,
                                                 strCassette_transferJobRecord_GetDR_out.strCarrierJobResult.toMachine );

                        if( rc == RC_UNDEFINED_STOCKER_TYPE )
                        {
                            PPT_METHODTRACE_V1("", "The cassette destination is not stocker . Return error...");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_CAST_XFERSTAT;
                        }
                        else if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "stocker_type_GetDR() != RC_OK");
                            strCassette_CheckConditionForOperation_out.strResult = strStocker_type_GetDR_out.strResult;
                            return( rc );
                        }

                        rc = RC_OK;
                    }
//P9000002 add end
//INN-R170003       else if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn)
                    else if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut)  //INN-R170003
//0.06                           && transferReserved == TRUE )
                           && transferReserved == FALSE )    //0.06
                    {
                        PPT_METHODTRACE_V1("", "(transferState = SP_TransState_EquipmentOut) and (transferReserved == FALSE)")

//P4100105 start
                        /*-----------------------------------------------------------------------------------------------*/
                        /*   The following StartLotReserve isn't permitted in Transfer EQP to EQP of CassetteDelivery.   */
                        /*                                                                                               */
                        /*   -----------------------------                                                               */
                        /*   |         FromEQP           |                                                               */
                        /*   ----------------------------|                                                               */
                        /*   | OperationMode : Offline-2 |                                                               */
                        /*   | XferState     : EI        |                                                               */
                        /*   -----------------------------                                                               */
                        /*-----------------------------------------------------------------------------------------------*/
                        if ( 0 == CIMFWStrCmp(strOrgEqpPortStatus.accessMode, SP_Eqp_AccessMode_Auto)
                          && 0 == CIMFWStrCmp(strOrgEqpPortStatus.onlineMode, SP_Eqp_OnlineMode_Offline) )
                        {
                            PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_CAST_XFERSTAT;
                        }
//P4100105 end

//P4100105 delete start    Because, This Locig was moved to the top.
//P4100105                        /*--------------------------------------*/
//P4100105                        /*   Get Originator Eqp's Access Mode   */
//P4100105                        /*--------------------------------------*/
//P4100105
//P4100105                        /*--------------------------------*/
//P4100105                        /*   Get Originator EquipmentID   */
//P4100105                        /*--------------------------------*/
//P4100105                        PPT_METHODTRACE_V1("","Get Originator EquipmentID");
//P4100105
//P4100105                        Machine_var aMachine;
//P4100105                        PosMachine_var aOrgMachine;
//P4100105                        try
//P4100105                        {
//P4100105                            aMachine = aCassette->currentAssignedMachine();
//P4100105                            aOrgMachine = PosMachine::_narrow( aMachine );
//P4100105                        }
//P4100105                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)
//P4100105
//P4100105                        objectIdentifier orgEquipmentID;
//P4100105                        PPT_SET_OBJECT_IDENTIFIER( orgEquipmentID,
//P4100105                                                   aOrgMachine,
//P4100105                                                   strCassette_CheckConditionForOperation_out,
//P4100105                                                   cassette_CheckConditionForOperation,
//P4100105                                                   PosMachine );
//P4100105
//P4100105                        /*---------------------------------*/
//P4100105                        /*   Get Cassette Info in OrgEqp   */
//P4100105                        /*---------------------------------*/
//P4100105                        PPT_METHODTRACE_V1("","Get Cassette Info in OrgEqp");
//P4100105
//P4100105                        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//P4100105                        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
//P4100105                                                     strObjCommonIn,
//P4100105                                                     orgEquipmentID );
//P4100105
//P4100105                        if ( rc != RC_OK )
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("", "equipment_portInfo_Get != RC_OK")
//P4100105                            strCassette_CheckConditionForOperation_out.strResult = strEquipment_portInfo_Get_out.strResult;
//P4100105                            return rc;
//P4100105                        }
//P4100105
//P4100105                        /*--------------------------------------*/
//P4100105                        /*   Find Assigned Port's portGroupID   */
//P4100105                        /*--------------------------------------*/
//P4100105                        PPT_METHODTRACE_V1("","Find Assigned Port's portGroupID");
//P4100105
//P4100105                        CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//P4100105                        for ( j=0; j < lenEqpPort; j++ )
//P4100105                        {
//P4100105                            if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
//P4100105                                                  strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
//P4100105                            {
//P4100105                                PPT_METHODTRACE_V1("","break!!");
//P4100105
//P4100105                                break;
//P4100105                            }
//P4100105                        }
//P4100105
//P4100105                        if ( j == lenEqpPort )
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
//P4100105                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
//P4100105                                                 MSG_INVALID_CAST_XFERSTAT,
//P4100105                                                 RC_INVALID_CAST_XFERSTAT,
//P4100105                                                 transferState,
//P4100105                                                 strStartCassette[i].cassetteID.identifier );
//P4100105
//P4100105                            return RC_INVALID_CAST_XFERSTAT;
//P4100105                        }
//P4100105
//P4100105                        /*----------------------------------------------------*/
//P4100105                        /*   Get Originator Equipment's Operation Mode Info   */
//P4100105                        /*----------------------------------------------------*/
//P4100105                        PPT_METHODTRACE_V1("","Get Originator Equipment's Operation Mode Info");
//P4100105
//P4100105                        objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
//P4100105                        rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
//P4100105                                                                    strObjCommonIn,
//P4100105                                                                    equipmentID,
//P4100105                                                                    strStartCassette[i].loadPortID );
//P4100105
//P4100105                        if ( rc != RC_OK )
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get != RC_OK")
//P4100105                            strCassette_CheckConditionForOperation_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
//P4100105                            return rc;
//P4100105                        }
//P4100105 delete end

//P4100105                        if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,
//P4100105                                              SP_Eqp_AccessMode_Auto) )
//P4100105 start
                        /*-----------------------------------------------------------------------------------------------*/
                        /*   The following StartLotReserve isn't permitted in Transfer EQP to EQP of CassetteDelivery.   */
                        /*                                                                                               */
                        /*   ToEQP's OperationMode : ***-2                                                               */
                        /*-----------------------------------------------------------------------------------------------*/
                        if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto)
                          && 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.dispatchMode, SP_Eqp_DispatchMode_Auto) )
//P4100105 end
                        {
                            PPT_METHODTRACE_V1("","rc = RC_OK");

                            rc = RC_OK;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );

                            return RC_INVALID_CAST_XFERSTAT;
                        }
//0.06 start
                        /*---------------------------------------------------------*/
                        /*   Check orgEqp's EqpToEqpTransfer Flag is TRUE or Not   */
                        /*---------------------------------------------------------*/
                        CORBA::Boolean bEqpToEqpXFerFlag;
                        try
                        {
                            bEqpToEqpXFerFlag = aOrgMachine->isEqpToEqpTransferFlagOn();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)

                        if (TRUE == bEqpToEqpXFerFlag)
                        {
                            PPT_METHODTRACE_V1("","rc = RC_OK");
                            rc = RC_OK;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );

                            return RC_INVALID_CAST_XFERSTAT;
                        }
//0.06 end
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             strStartCassette[i].cassetteID.identifier );

                        return RC_INVALID_CAST_XFERSTAT;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","No Process <for Ope Start>");
            }

            /*----------------------------------------------*/
            /*   Get and Check Cassette's Dispatch Status   */
            /*----------------------------------------------*/

            /*------------------------------------*/
            /*   Get Cassette's Dispatch Status   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1("","Get Cassette's Dispatch Status");

            CORBA::Boolean dispatchReserveFlag;
            try
            {
                dispatchReserveFlag = aCassette->isDispatchReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchtReserved)

//D4000028            if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
//D4000028              || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching) )
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)         //D4000028
             || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching)              //D4000028
             || 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer))           //D4000028
            {
//D4000028                PPT_METHODTRACE_V1("","operation == SP_Operation_StartReservation, SP_Operation_FlowBatching");
                PPT_METHODTRACE_V2("", "(operation == SP_Operation_StartReservation) || (operation == SP_Operation_FlowBatching)|| (operation == SP_Operation_NPWCarrierXfer)", operation); //D4000028
                if ( dispatchReserveFlag != FALSE )
                {
                    PPT_METHODTRACE_V1("","dispatchReserveFlag != FALSE");
                    SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                MSG_ALREADY_DISPATCH_RESVED_CST,
                                RC_ALREADY_DISPATCH_RESVED_CST );

                    return RC_ALREADY_DISPATCH_RESVED_CST;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","operation != SP_Operation_StartReservation && operation != SP_Operation_FlowBatching");
            }

            /*-------------------------------------*/
            /*   Get and Check Cassette's Status   */
            /*-------------------------------------*/
            PPT_METHODTRACE_V1("","Get and Check Cassette's Status");

            CORBA::String_var cassetteState;
            try
            {
//0.03          cassetteState = aCassette->getCurrentState();
                cassetteState = aCassette->getDurableState();       //0.03
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCurrentState)

//D4000028(1)             if ( 0 == CIMFWStrCmp(cassetteState, CIMFW_Durable_Available)
//D4000028(1)              || 0 == CIMFWStrCmp(cassetteState, CIMFW_Durable_InUse) )
//D4000028(1)            {
//D4000028(1)               PPT_METHODTRACE_V1("", "cassetteState = CIMFW_Durable_Available or CIMFW_Durable_InUse")
//D4000028(1)                rc = RC_OK;
//D4000028(1)             }
//D4000028(1)             else
//D4000028(1)             {
//D4000028(1)                 PPT_METHODTRACE_V1("","return RC_INVALID_CAST_STAT");
//D4000028(1)                 PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
//D4000028(1)                                      MSG_INVALID_CAST_STAT,
//D4000028(1)                                      RC_INVALID_CAST_STAT,
//D4000028(1)                                      cassetteState,
//D4000028(1)                                      strStartCassette[i].cassetteID.identifier );
//D4000028(1)
//D4000028(1)                 return RC_INVALID_CAST_STAT;
//D4000028(1)             }

            //D4000028(1) add start
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer) &&
                (0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_Other        ) ||
                 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette)) )
            {
                PPT_METHODTRACE_V2("", "_NPWCarrierXfer && _Other",__LINE__);
                rc = RC_OK;
            }
//DSN000101569 add start
            else if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
            {
                PPT_METHODTRACE_V1("","operation == SP_Operation_OpeStart or SP_Operation_StartReservation");

                SPDynamicTableS< char*, char*, char*, char*, stringSequence, stringSequence > subLotTypeList;

                // for empty carrier
                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                {
                    PPT_METHODTRACE_V1("","Empty carrier");

                    // Get all carrier's start lots SubLotType
                    CORBA::ULong startCastLen = strStartCassette.length();
                    PPT_METHODTRACE_V2("", "startCastLen", startCastLen)
                    for ( CORBA::ULong startCastIndex = 0; startCastIndex < startCastLen; startCastIndex++ )
                    {
                        PPT_METHODTRACE_V2("", "startCastIndex", startCastIndex)

                        CORBA::ULong lotInCastLen = strStartCassette[startCastIndex].strLotInCassette.length();
                        PPT_METHODTRACE_V2("", "lotInCastLen", lotInCastLen)
                        for ( CORBA::ULong lotInCastIndex = 0; lotInCastIndex < lotInCastLen; lotInCastIndex++ )
                        {
                            PPT_METHODTRACE_V2("", "lotInCastIndex", lotInCastIndex)
                            if ( TRUE == strStartCassette[startCastIndex].strLotInCassette[lotInCastIndex].operationStartFlag )
                            {
                                const char* subLotType = strStartCassette[startCastIndex].strLotInCassette[lotInCastIndex].subLotType;
                                PPT_METHODTRACE_V2("", "subLotType", subLotType)
                                if( !subLotTypeList.exists( (char*)subLotType ) )
                                {
                                    PPT_METHODTRACE_V1("", "Add subLotType");
                                    subLotTypeList.add( CIMFWStrDup(subLotType), CIMFWStrDup(subLotType) );
                                }
                            }
                        }
                    }
                }
                // for lot in carrier
                else
                {
                    PPT_METHODTRACE_V1("","Lot in carrier");

                    // Get carrier's start lots SubLotType
                    CORBA::ULong lotInCastLen = strStartCassette[i].strLotInCassette.length();
                    PPT_METHODTRACE_V2("", "lotInCastLen", lotInCastLen)
                    for ( CORBA::ULong lotInCastIndex = 0; lotInCastIndex < lotInCastLen; lotInCastIndex++ )
                    {
                        PPT_METHODTRACE_V2("", "lotInCastIndex", lotInCastIndex)

                        if ( TRUE == strStartCassette[i].strLotInCassette[lotInCastIndex].operationStartFlag )
                        {
                            const char* subLotType = strStartCassette[i].strLotInCassette[lotInCastIndex].subLotType;
                            PPT_METHODTRACE_V2("", "subLotType", subLotType)
                            if( !subLotTypeList.exists( (char*)subLotType ) )
                            {
                                PPT_METHODTRACE_V1("", "Add subLotType");
                                subLotTypeList.add( CIMFWStrDup(subLotType), CIMFWStrDup(subLotType) );
                            }
                        }
                    }
                }

                stringSequence_var subLotTypeListSeq = subLotTypeList.getSequence();
                PPT_METHODTRACE_V2("", "subLotTypeListSeq length", subLotTypeListSeq->length())

                CORBA::Boolean availableFlag = FALSE;
                try
                {
                    availableFlag = aCassette->isLotProcessAvailable(subLotTypeListSeq);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isLotProcessAvailable)

                if ( TRUE == availableFlag )
                {
                    PPT_METHODTRACE_V1("", "availableFlag == TRUE");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "availableFlag != TRUE");
                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperation_out,
                                        MSG_DRBL_NOT_AVAILSTAT_FOR_LOTPROCESS,
                                        RC_DRBL_NOT_AVAILSTAT_FOR_LOTPROCESS,
                                        strStartCassette[i].cassetteID.identifier );
                    return RC_DRBL_NOT_AVAILSTAT_FOR_LOTPROCESS;
                }
            }
//DSN000101569 add end
            else
            {
                if ( 0 == CIMFWStrCmp(cassetteState, CIMFW_Durable_Available)
                  || 0 == CIMFWStrCmp(cassetteState, CIMFW_Durable_InUse) )
                {
                    PPT_METHODTRACE_V1("", "cassetteState = CIMFW_Durable_Available or CIMFW_Durable_InUse")
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_CAST_STAT");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                         MSG_INVALID_CAST_STAT,
                                         RC_INVALID_CAST_STAT,
                                         cassetteState,
                                         strStartCassette[i].cassetteID.identifier );
                    return RC_INVALID_CAST_STAT;
               }
            }
            //D4000028(1) add end

            //D4200069 Add Start
            //-----------------------------------------------
            // Check Start Cassette And Start Lot Combination
            //-----------------------------------------------
//P410095   if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart))

            if (( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)) ||
                ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)))    //P4200290
            {
//P4200290      PPT_METHODTRACE_V1("", "OpeStart ! Start Cassette and Start Lot Combination Check" );
                PPT_METHODTRACE_V2("", "Start Cassette and Start Lot Combination Check", operation);    //P4200290

                LotSequence*    aLotSequence = NULL;
                LotSequence_var aLotSequenceVar;

                try
                {
                    aLotSequence     = aCassette->allLots();
                    aLotSequenceVar  = aLotSequence;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

                CORBA::Long lotLen           = aLotSequence->length();
                CORBA::Long lotLenInCassette = strStartCassette[i].strLotInCassette.length();

                if ( lotLen == lotLenInCassette )
                {
                    PPT_METHODTRACE_V2("", "Lot Count is Matching", lotLen );

                    CORBA::Boolean    bLotMatch = FALSE;
                    CORBA::Long jj = 0;
                    CORBA::Long kk = 0;

                    //--------------------------------
                    // All Lot in Start Cassette Loop
                    //--------------------------------
                    for ( jj=0; jj<lotLen; jj++ )
                    {
                        bLotMatch = FALSE;
                        CORBA::String_var    strTempLotID;

                        if ( TRUE != CORBA::is_nil((*aLotSequence)[jj]) )
                        {
                            try                                                           //P4200290 Add
                            {
                                strTempLotID = (*aLotSequence)[jj]->getIdentifier();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getIdentifier)             //P4200290 Add

                            //---------------------------------
                            // Inpara Lot in StartCassette Loop
                            //---------------------------------
                            for ( kk=0; kk<lotLenInCassette; kk++ )
                            {
                                if ( 0 == CIMFWStrCmp( strTempLotID,
                                                       strStartCassette[i].strLotInCassette[kk].lotID.identifier ) )
                                {
                                    PPT_METHODTRACE_V2("", "Find Matching Lot", strTempLotID );

                                    bLotMatch = TRUE;
                                    break;
                                }
                            }
                            if ( bLotMatch == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "Lot in Start Cassette Miss Match", strTempLotID );
                                SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                            MSG_LOT_START_CAST_UNMATCH,
                                            RC_LOT_START_CAST_UNMATCH );
                                return RC_LOT_START_CAST_UNMATCH;
                            }
                        }
                        else
                        {
                            PPT_METHODTRACE_V2("", "aLotSequence[jj] is Nill", jj );
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_LOT_CAST_UNMATCH,
                                                 RC_LOT_CAST_UNMATCH,
                                                 "*****",
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_LOT_CAST_UNMATCH;
                        }
                    }

                    //P4200290 Add Start
                    //--------------------------------
                    // Check Cassette & Lot combination
                    //  Inpara Lot --> Lot in Cassette
                    //--------------------------------
                    for ( jj=0; jj<lotLenInCassette; jj++ )
                    {
                        bLotMatch = FALSE;
                        CORBA::String_var    strTempLotID;

                        //---------------------------------
                        // All Lot of in Cassette Loop
                        //---------------------------------
                        for ( kk=0; kk<lotLen; kk++ )
                        {
                            if ( TRUE != CORBA::is_nil((*aLotSequence)[kk]) )
                            {
                                try
                                {
                                    strTempLotID = (*aLotSequence)[kk]->getIdentifier();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getIdentifier)

                                if ( 0 == CIMFWStrCmp( strTempLotID,
                                                       strStartCassette[i].strLotInCassette[jj].lotID.identifier ) )
                                {
                                    PPT_METHODTRACE_V2("", "Find Matching Lot", strTempLotID );

                                    bLotMatch = TRUE;
                                    break;
                                }
                            }
                            else
                            {
                                PPT_METHODTRACE_V2("", "aLotSequence[kk] is Nill", kk );
                                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                     MSG_LOT_CAST_UNMATCH,
                                                     RC_LOT_CAST_UNMATCH,
                                                     "*****",
                                                     strStartCassette[i].cassetteID.identifier );
                                return RC_LOT_CAST_UNMATCH;
                            }
                        }

                        if ( bLotMatch == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "Lot in Start Cassette Miss Match", strTempLotID );
                            SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                        MSG_LOT_START_CAST_UNMATCH,
                                        RC_LOT_START_CAST_UNMATCH );
                            return RC_LOT_START_CAST_UNMATCH;
                        }
                    }
                    //P4200290 Add End

                }
                else
                {
                    PPT_METHODTRACE_V3("", "Lot in Start Cassette Count Miss Match", lotLen, lotLenInCassette );
                    SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                MSG_LOT_START_CAST_UNMATCH,
                                RC_LOT_START_CAST_UNMATCH );
                    return RC_LOT_START_CAST_UNMATCH;
                }
            }
            //D4200069 Add End

        }

//0.01 start
        /*---------------------------------------------------------*/
        /*   Check Cassette's ControlJobID vs Eqp's ControlJobID   */
        /*---------------------------------------------------------*/
        PPT_METHODTRACE_V1("","Check Cassette's ControlJobID vs Eqp's ControlJobID");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
        {
            PPT_METHODTRACE_V1("","operation == SP_Operation_OpeStart");

            /*===== get reserved controlJobID for each portGroup =====*/
            objEquipment_reservedControlJobID_Get_out strEquipment_reservedControlJobID_Get_out;
            rc = equipment_reservedControlJobID_Get( strEquipment_reservedControlJobID_Get_out,
                                                     strObjCommonIn,
                                                     equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","equipment_reservedControlJobID_Get != RC_OK");
                strCassette_CheckConditionForOperation_out.strResult = strEquipment_reservedControlJobID_Get_out.strResult;
                return rc ;
            }

            CORBA::Long rsvCJLen = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();

            /*===== find reserved controlJobID for specified portGroup =====*/
            objectIdentifier eqpControlJobID;

//P8000119 start
            PosStartCassetteInfoSequence*    startCassetteInfo = NULL;
            PosStartCassetteInfoSequence_var startCassetteInfoVar;
//P8000119 end

            for ( i=0; i < rsvCJLen; i++ )
            {
                if ( 0 == CIMFWStrCmp(strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[i].portGroupID,
                                      portGroupID) )
                {
                    PPT_METHODTRACE_V1("","in-parm's portGroup is found in reservedControlJobInfo...");

                    eqpControlJobID = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[i].controlJobID;

                    //P3000175 add start
                    /*---------------------------*/
                    /*   Get ControlJob Object   */
                    /*---------------------------*/
                    PPT_METHODTRACE_V1("","Get ControlJob Object...");

                    PosControlJob_var aReserveControlJob;
                    PPT_CONVERT_CONTROLJOBID_TO_CONTROLJOB_OR(aReserveControlJob,eqpControlJobID,strEquipment_reservedControlJobID_Get_out,equipment_reservedControlJobID_Get);

                    /*-------------------------------------------*/
                    /*   Get PosStartCassetteInfoSequence Info   */
                    /*-------------------------------------------*/
//P8000119                    PosStartCassetteInfoSequence*    startCassetteInfo = NULL; //P2200204
//P8000119                    PosStartCassetteInfoSequence_var startCassetteInfoVar;

                    try
                    {
                        startCassetteInfo    = aReserveControlJob->getStartCassetteInfo();
                        startCassetteInfoVar = startCassetteInfo;
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getStartCassetteInfo);

                    cjCastCnt = (*startCassetteInfo).length();
                    PPT_METHODTRACE_V2("","controlJob's cassetteCount = ",cjCastCnt);
                    //P3000175 add end

                    PPT_METHODTRACE_V1("","break!!");
                    break;
                }
            }

            /*===== compare reserved controlJobID vs cassette's controlJobID =====*/
            if ( 0 != CIMFWStrCmp(saveControlJobID.identifier, eqpControlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("","compare reserved controlJobID vs cassette's controlJobID");

                SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                            MSG_CAST_PORT_CTRLJOB_UNMATCH,
                            RC_CAST_PORT_CTRLJOB_UNMATCH );

                return RC_CAST_PORT_CTRLJOB_UNMATCH;
            }

            /*===== check reserved controlJobID's cassette count vs in-parm's cassette count =====*/
            if ( 0 < CIMFWStrLen(saveControlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("","check reserved controlJobID's cassette count vs in-parm's cassette count");

                lenCassette = strStartCassette.length();
//P3000175      if ( rsvCJLen != lenCassette )
                if ( cjCastCnt != lenCassette ) //P3000175

                {
                    PPT_METHODTRACE_V1("","return RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH");
                    SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                MSG_CAST_PORT_CTRLJOB_COUNT_UNMATCH,
                                RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH );

                    return RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH;
                }
            }
//P8000119 start
            /*===== check reserved controlJobID's StartCassetteInfo vs in-parm's StartCassetteInfo =====*/
            if ( NULL != startCassetteInfo )
            {
                PPT_METHODTRACE_V1("", "check reserved controlJobID's StartCassetteInfo vs in-parm's StartCassetteInfo");

                // Loop of InParameter's StartCassette information.
                CORBA::Long nCstLen = strStartCassette.length();
                for ( CORBA::Long nCst=0; nCst < nCstLen; nCst++ )
                {
                    CORBA::Long nLotLen = strStartCassette[nCst].strLotInCassette.length();
                    for ( CORBA::Long nLot=0; nLot < nLotLen; nLot++ )
                    {
                        PPT_METHODTRACE_V2("", "LotID (InParam)", strStartCassette[nCst].strLotInCassette[nLot].lotID.identifier);

                        // Loop of ControlJob's StartCassette information.
                        CORBA::Boolean bSameCondition = FALSE;
                        CORBA::Long nCJCstLen = (*startCassetteInfo).length();
                        for ( CORBA::Long nCstCJ=0; nCstCJ < nCJCstLen; nCstCJ++ )
                        {
                            CORBA::Long nCJLotLen = (*startCassetteInfo)[nCstCJ].lotInCassetteInfo.length();
                            for ( CORBA::Long nLotCJ=0; nLotCJ < nCJLotLen; nLotCJ++ )
                            {
                                PPT_METHODTRACE_V2("", "  LotID (CJ)", (*startCassetteInfo)[nCstCJ].lotInCassetteInfo[nLotCJ].lotID.identifier);

                                if ( 0 == CIMFWStrCmp(strStartCassette[nCst].strLotInCassette[nLot].lotID.identifier,
                                                      (*startCassetteInfo)[nCstCJ].lotInCassetteInfo[nLotCJ].lotID.identifier)
                                  && strStartCassette[nCst].strLotInCassette[nLot].operationStartFlag == (*startCassetteInfo)[nCstCJ].lotInCassetteInfo[nLotCJ].operationStartFlag )
                                {
                                    PPT_METHODTRACE_V1("", "Found same condition Lot.");
                                    bSameCondition = TRUE;
                                    break;
                                }
                            } //end of [nLotCJ]

                            if ( bSameCondition )
                            {
                                break;
                            }
                        } //end of [nCstCJ]

                        if ( !bSameCondition )
                        {
                            PPT_METHODTRACE_V1("", "return RC_STARTRSVCJ_OPESTACJ_UNMATCH");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_STARTRSVCJ_OPESTACJ_UNMATCH, RC_STARTRSVCJ_OPESTACJ_UNMATCH,
                                                 equipmentID.identifier,
                                                 eqpControlJobID.identifier );
                            return RC_STARTRSVCJ_OPESTACJ_UNMATCH;
                        }
                    } //end of [nLot]
                } //end of [nCst]
            }
//P8000119 end
        }
        else
        {
            PPT_METHODTRACE_V1("","operation != SP_Operation_OpeStart");
        }
//0.01 end

        /*------------------------------------------------------------------------*/
        /*                                                                        */
        /*   Check Condition for maxBatchSize, minBatchSize, emptyCassetteCount   */
        /*                                                                        */
        /*------------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("","Check Condition for maxBatchSize, minBatchSize, emptyCassetteCount");

//D4000028        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
//D4000028          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
//D4000028(1) delete Start
//        if (0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)              //D4000028
//          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)     //D4000028
//          || 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer))      //D4000028
//D4000028(1) delete end
        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)               //D4000028(1)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )     //D4000028(1)
        {
//D4000028            PPT_METHODTRACE_V1("", "operation = SP_Operation_OpeStart or SP_Operation_StartReservation")
                PPT_METHODTRACE_V2("", "(operation == SP_Operation_OpeStart) || (operation == SP_Operation_StartReservation)|| (operation == SP_Operation_NPWCarrierXfer)", operation); //D4000028

            /*---------------------------------------------*/
            /*   Get Equipment's Process Batch Condition   */
            /*---------------------------------------------*/
            objEquipment_processBatchCondition_Get_out strEquipment_processBatchCondition_Get_out;
            rc = equipment_processBatchCondition_Get( strEquipment_processBatchCondition_Get_out,
                                                      strObjCommonIn,
                                                      equipmentID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_processBatchCondition_Get != RC_OK")
                strCassette_CheckConditionForOperation_out.strResult = strEquipment_processBatchCondition_Get_out.strResult;
                return rc;
            }

            /*--------------------------*/
            /*   Check Cassette Count   */
            /*--------------------------*/
            PPT_METHODTRACE_V1("","Check Cassette Count");

            CORBA::Long processCassetteCount = 0;
            CORBA::Long emptyCassetteCount   = 0;

            lenCassette = strStartCassette.length();
            for ( i=0; i < lenCassette; i++ )
            {
//P3000248      if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessLot)
//P3000248        || 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot)
//P3000248        || 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_Any) )
                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessLot)           //P3000248
                  || 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot) )  //P3000248
                {
                    PPT_METHODTRACE_V1("","processCassetteCount++");

                    processCassetteCount++;
                }
                else if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                {
                    PPT_METHODTRACE_V1("","emptyCassetteCount++");

                    emptyCassetteCount++;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "else loadPurposeType");
                }
            }

            PPT_METHODTRACE_V2("", "processCassetteCount ---> ", processCassetteCount);
            PPT_METHODTRACE_V2("", "EQP.minBatchSize -------> ", strEquipment_processBatchCondition_Get_out.minBatchSize);
            PPT_METHODTRACE_V2("", "EQP.maxBatchSize -------> ", strEquipment_processBatchCondition_Get_out.maxBatchSize);

            /*===== for maxBatchSize, minBatchSize =====*/
            if ( processCassetteCount >= strEquipment_processBatchCondition_Get_out.minBatchSize
              && processCassetteCount <= strEquipment_processBatchCondition_Get_out.maxBatchSize )
            {
                PPT_METHODTRACE_V1("", "processCassetteCount >= .minBatchSize and processCassetteCount <= .maxBatchSize")
                rc = RC_OK;
            }
            else
            {
                if( virtualOperationFlag == FALSE )    //DSN000096135
                {                                      //DSN000096135
                    PPT_METHODTRACE_V1("","return RC_INVALID_INPUT_CAST_COUNT");
                    SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                MSG_INVALID_INPUT_CAST_COUNT,
                                RC_INVALID_INPUT_CAST_COUNT );

                    return RC_INVALID_INPUT_CAST_COUNT;
                }                                      //DSN000096135
            }

//Q3000107 delete start
//Q3000107            /*===== for emptyCassetteCount =====*/
//Q3000107            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
//Q3000107              || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
//Q3000107            {
//Q3000107                PPT_METHODTRACE_V1("","operation == SP_Operation_OpeStart, SP_Operation_StartReservation");
//Q3000107
//Q3000107                if ( strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag == TRUE )
//Q3000107                {
//Q3000107                    PPT_METHODTRACE_V1("","cassetteExchangeFlag == TRUE");
//Q3000107
//Q3000107                    if ( emptyCassetteCount == processCassetteCount )
//Q3000107                    {
//Q3000107                        PPT_METHODTRACE_V1("", "emptyCassetteCount = processCassetteCount")
//Q3000107                        rc = RC_OK;
//Q3000107                    }
//Q3000107                    else
//Q3000107                    {
//Q3000107                        PPT_METHODTRACE_V1("","return RC_INVALID_EMPTY_COUNT");
//Q3000107                        char v1[16];
//Q3000107                        char v2[16];
//Q3000107                        sprintf( v1, "%d", processCassetteCount );
//Q3000107                        sprintf( v2, "%d", emptyCassetteCount );
//Q3000107
//Q3000107                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
//Q3000107                                             MSG_INVALID_EMPTY_COUNT,
//Q3000107                                             RC_INVALID_EMPTY_COUNT,
//Q3000107                                             v1,
//Q3000107                                             v2 );
//Q3000107
//Q3000107                        return RC_INVALID_EMPTY_COUNT;
//Q3000107                   }
//Q3000107                }
//Q3000107                else
//Q3000107                {
//Q3000107                    if ( emptyCassetteCount == 0 )
//Q3000107                    {
//Q3000107                        PPT_METHODTRACE_V1("", "emptyCassetteCount = 0 <1>")
//Q3000107                        rc = RC_OK;
//Q3000107                    }
//Q3000107                    else
//Q3000107                    {
//Q3000107//0.02 start
//Q3000107                        PPT_METHODTRACE_V1("","return RC_INVALID_NUMBER_OF_EMPTYCAST");
//Q3000107                        SET_MSG_RC( strCassette_CheckConditionForOperation_out,
//Q3000107                                    MSG_INVALID_NUMBER_OF_EMPTYCAST,
//Q3000107                                    RC_INVALID_NUMBER_OF_EMPTYCAST );
//Q3000107
//Q3000107                        return RC_INVALID_NUMBER_OF_EMPTYCAST;
//Q3000107//0.02            set strResult by using RC_INVALID_EMPTY_COUNT, MSG_INVALID_EMPTY_COUNT
//Q3000107//0.02            return( RC_INVALID_EMPTY_COUNT );
//Q3000107//0.02 end
//Q3000107                    }
//Q3000107                }
//Q3000107
//Q3000107                if ( strEquipment_processBatchCondition_Get_out.monitorCreationFlag == TRUE )
//Q3000107                {
//Q3000107                    PPT_METHODTRACE_V1("","monitorCreationFlag == TRUE");
//Q3000107
//Q3000107                    if ( emptyCassetteCount == 1 )
//Q3000107                    {
//Q3000107                        PPT_METHODTRACE_V1("", "emptyCassetteCount = 1")
//Q3000107                        rc = RC_OK;
//Q3000107                    }
//Q3000107                    else
//Q3000107                    {
//Q3000107                        PPT_METHODTRACE_V1("","return RC_INVALID_EMPTY_COUNT");
//Q3000107                        char v1[16];
//Q3000107                        char v2[16];
//Q3000107                        sprintf( v1, "%d", processCassetteCount );
//Q3000107                        sprintf( v2, "%d", emptyCassetteCount );
//Q3000107
//Q3000107                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
//Q3000107                                             MSG_INVALID_EMPTY_COUNT,
//Q3000107                                             RC_INVALID_EMPTY_COUNT,
//Q3000107                                             v1,
//Q3000107                                             v2 );
//Q3000107
//Q3000107                        return RC_INVALID_EMPTY_COUNT;
//Q3000107                    }
//Q3000107                }
//Q3000107                else
//Q3000107                {
//Q3000107                    PPT_METHODTRACE_V1("","monitorCreationFlag != TRUE");
//Q3000107
//Q3000107                    if ( emptyCassetteCount == 0 )
//Q3000107                    {
//Q3000107                        PPT_METHODTRACE_V1("", "emptyCassetteCount == 0 <2>")
//Q3000107                        rc = RC_OK;
//Q3000107                    }
//Q3000107                    else
//Q3000107                    {
//Q3000107                        PPT_METHODTRACE_V1("","return RC_INVALID_EMPTY_COUNT");
//Q3000107                        char v1[16];
//Q3000107                        char v2[16];
//Q3000107                        sprintf( v1, "%d", processCassetteCount );
//Q3000107                        sprintf( v2, "%d", emptyCassetteCount );
//Q3000107
//Q3000107                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
//Q3000107                                             MSG_INVALID_EMPTY_COUNT,
//Q3000107                                             RC_INVALID_EMPTY_COUNT,
//Q3000107                                             v1,
//Q3000107                                             v2 );
//Q3000107
//Q3000107                        return RC_INVALID_EMPTY_COUNT;
//Q3000107                    }
//Q3000107                }
//Q3000107            }
//Q3000107        }
//Q3000107        else
//Q3000107        {
//Q3000107            PPT_METHODTRACE_V1("","operation != SP_Operation_OpeStart && operation != SP_Operation_StartReservation");
//Q3000107        }
//Q3000107 delete end

//Q3000107 add start
            /*===== for emptyCassetteCount =====*/
            if ( strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag == TRUE &&
                 strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == TRUE )
            {
                PPT_METHODTRACE_V1("","cassetteExchangeFlag == TRUE && monitorCreationFlag  == TRUE");

                if ( emptyCassetteCount == processCassetteCount + 1 )
                {
                    PPT_METHODTRACE_V1("","emptyCassetteCount == processCassetteCount + 1");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_EMPTY_COUNT");
                    char v1[16];
                    char v2[16];
                    sprintf( v1, "%d", emptyCassetteCount );
                    sprintf( v2, "%d", processCassetteCount+1 );

                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                         MSG_INVALID_EMPTY_COUNT,
                                         RC_INVALID_EMPTY_COUNT,
                                         v1,
                                         v2 );

                    return RC_INVALID_EMPTY_COUNT;
                }
            }
            else if ( strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag == TRUE &&
                      strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == FALSE )
            {
                PPT_METHODTRACE_V1("","cassetteExchangeFlag == TRUE && monitorCreationFlag  == FALSE");

                if ( emptyCassetteCount == processCassetteCount )
                {
                    PPT_METHODTRACE_V1("","emptyCassetteCount == processCassetteCount");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_EMPTY_COUNT");
                    char v1[16];
                    char v2[16];
                    sprintf( v1, "%d", emptyCassetteCount );
                    sprintf( v2, "%d", processCassetteCount );

                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                         MSG_INVALID_EMPTY_COUNT,
                                         RC_INVALID_EMPTY_COUNT,
                                         v1,
                                         v2 );

                    return RC_INVALID_EMPTY_COUNT;
                }
            }
            else if ( strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag == FALSE &&
                      strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == TRUE )
            {
                PPT_METHODTRACE_V1("","cassetteExchangeFlag == FALSE && monitorCreationFlag  == TRUE");

                if ( emptyCassetteCount == 1 )
                {
                    PPT_METHODTRACE_V1("","emptyCassetteCount == 1");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_EMPTY_COUNT");
                    char v1[16];
                    char v2[16];
                    sprintf( v1, "%d", emptyCassetteCount );
                    sprintf( v2, "%d", 1 );

                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                         MSG_INVALID_EMPTY_COUNT,
                                         RC_INVALID_EMPTY_COUNT,
                                         v1,
                                         v2 );

                    return RC_INVALID_EMPTY_COUNT;
                }
            }
            else if ( strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag == FALSE &&
                      strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == FALSE )
            {
                PPT_METHODTRACE_V1("","cassetteExchangeFlag == FALSE && monitorCreationFlag  == FALSE");

                if ( emptyCassetteCount == 0 )
                {
                    PPT_METHODTRACE_V1("","emptyCassetteCount == 0");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_EMPTY_COUNT");
                    char v1[16];
                    char v2[16];
                    sprintf( v1, "%d", emptyCassetteCount );
                    sprintf( v2, "%d", 0 );

                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                         MSG_INVALID_EMPTY_COUNT,
                                         RC_INVALID_EMPTY_COUNT,
                                         v1,
                                         v2 );

                    return RC_INVALID_EMPTY_COUNT;
                }
            }
//Q3000107 add end
        }

//D3000079 add start
        /*------------------------------------------------------------------------------*/
        /*                                                                              */
        /*   Check Condition for Eqp's MultiRecipeCapability VS RecipeParameterValue    */
        /*                                                                              */
        /*------------------------------------------------------------------------------*/
        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
        {
            PPT_METHODTRACE_V1("", "operation = SP_Operation_OpeStart or SP_Operation_StartReservation")

            if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe)
              || 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) )
            {
                PPT_METHODTRACE_V1("", "multiRecipeCapability = SP_Eqp_MultiRecipeCapability_SingleRecipe or SP_Eqp_MultiRecipeCapability_Batch")
                /*-----------------------------------*/
                /*   Work Valiable for Check Logic   */
                /*-----------------------------------*/
                CORBA::Long baseSetFlag = FALSE;
                CORBA::Long baseI       = 0;
                CORBA::Long baseJ       = 0;
                CORBA::Long baseRPLen   = 0;

                /*-------------------------------*/
                /*   Loop for strStartCassette   */
                /*-------------------------------*/
                for ( i=0; i < lenCassette; i++ )
                {
                    /*------------------------*/
                    /*   Omit EmptyCassette   */
                    /*------------------------*/
                    if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                    {
                        PPT_METHODTRACE_V1("","strStartCassette[i].loadPurposeType == SP_LoadPurposeType_EmptyCassette");
                        continue;
                    }

                    /*-------------------------------*/
                    /*   Loop for strLotInCassette   */
                    /*-------------------------------*/
                    CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();

                    for ( j=0; j < lenLotInCassette; j++ )
                    {
                        /*------------------------*/
                        /*   Omit Non-Start Lot   */
                        /*------------------------*/
                        if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");
                            continue;
                        }

                        /*-------------------------------------*/
                        /*   Check RecipeParameterChangeType   */
                        /*-------------------------------------*/
                        if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].recipeParameterChangeType, SP_Rparm_ChangeType_ByLot ) )
                        {
                            PPT_METHODTRACE_V1("","return RC_INVALID_RPARM_CHANGETYPE!!");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                 MSG_INVALID_RPARM_CHANGETYPE,
                                                 RC_INVALID_RPARM_CHANGETYPE,
                                                 strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_RPARM_CHANGETYPE;
                        }

                        /*--------------------*/
                        /*   Save Base Info   */
                        /*--------------------*/
                        if ( baseSetFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("","baseSetFlag == FALSE");
                            baseSetFlag = TRUE;
                            baseI       = i;
                            baseJ       = j;

                            if ( strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0 )
                            {
                                PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0");
                                baseRPLen = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter.length();
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT!!");
                                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out,
                                                     MSG_INVALID_WAFER_CNT,
                                                     RC_INVALID_WAFER_CNT,
                                                     strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                     strStartCassette[i].cassetteID.identifier );

                                return RC_INVALID_WAFER_CNT;
                            }
                        }

                        /*--------------------------*/
                        /*   Loop for strLotWafer   */
                        /*--------------------------*/
                        CORBA::Long lwLen = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                        for ( k=0 ; k<lwLen ; k++ )
                        {
                            /*---------------------------------*/
                            /*   Check RecipeParameter Count   */
                            /*---------------------------------*/
                            CORBA::Long rpLen = strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length();

                            if ( rpLen != baseRPLen )
                            {
                                PPT_METHODTRACE_V1("","return RC_NOT_SAME_PRARM_INFO!!");
                                PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForOperation_out,
                                                     MSG_NOT_SAME_RPARM_INFO,
                                                     RC_NOT_SAME_RPARM_INFO,
                                                     strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                     strStartCassette[i].cassetteID.identifier,
                                                     strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                     strStartCassette[baseI].cassetteID.identifier );

                                return RC_NOT_SAME_RPARM_INFO;
                            }

                            /*--------------------------------------*/
                            /*   Loop for strStartRecipeParameter   */
                            /*--------------------------------------*/
                            for ( CORBA::Long l=0 ; l<rpLen ; l++ )
                            {

                                /*-----------------------------------------------*/
                                /*   Check RecipeParameter Info is Same or Not   */
                                /*-----------------------------------------------*/
                                /*===== parameterName check (string) =====*/
                                if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName, strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].parameterName ) )
                                {
                                    PPT_METHODTRACE_V1("","return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForOperation_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }

                                /*===== parameterValue check (string) =====*/
                                if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue, strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].parameterValue ) )
                                {
                                    PPT_METHODTRACE_V1("","return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForOperation_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }

                                /*===== useCurrentSettingValueFlag check (boolean) =====*/
                                if ( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag !=  strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].useCurrentSettingValueFlag )
                                {
                                    PPT_METHODTRACE_V1("","return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForOperation_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }
                            }
                        }
                    }
                }
            }
        }
//D3000079 add end

//P3100097 start
        PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100097 start @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        /*-------------------------------------------------------*/
        /*   Check Upper/Lower Limit for RecipeParameterChange   */
        /*-------------------------------------------------------*/

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)                    //P3100289
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )          //P3100289
        {                                                                          //P3100289
            PPT_METHODTRACE_V1("", "operation = SP_Operation_OpeStart or SP_Operation_StartReservation")

            /*---------------------------------*/
            /*   Check StartRecipeParameters   */
            /*---------------------------------*/
            PPT_METHODTRACE_V2("", "lenCassette ---> ", lenCassette);
            for ( i=0; i < lenCassette; i++ )
            {
                PPT_METHODTRACE_V3("", "StartCassette-------------------------------round [i]", i, strStartCassette[i].cassetteID.identifier);
                /*------------------------*/
                /*   Omit EmptyCassette   */
                /*------------------------*/
                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                {
                    PPT_METHODTRACE_V1("","### continue ###  strStartCassette[i].loadPurposeType == SP_LoadPurposeType_EmptyCassette");
                    continue;
                }

                /*-------------------------------*/
                /*   Loop for strLotInCassette   */
                /*-------------------------------*/
                CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();
                PPT_METHODTRACE_V2("", "lenLotInCassette ---> ", lenLotInCassette);

                for ( j=0; j < lenLotInCassette; j++ )
                {
                    PPT_METHODTRACE_V3("", "LotInCassette-----------------------------------round [j]", j,
                                                strStartCassette[i].strLotInCassette[j].lotID.identifier);
                    /*------------------------*/
                    /*   Omit Non-Start Lot   */
                    /*------------------------*/
                    if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("","### continue ###  strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");
                        continue;
                    }

//D8000024 add start
                    CORBA::Boolean skipFlag = FALSE;
                    CORBA::Boolean paramCheckWithFPC = FALSE;
                    objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                    rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                                   SP_FPC_ExchangeType_StartReserveInfo,
                                                   equipmentID,
                                                   strStartCassette[i].strLotInCassette[j].lotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                        strCassette_CheckConditionForOperation_out.strResult =
                            strLot_effectiveFPCInfo_Get_out.strResult;
                        return rc;
                    }
                    paramCheckWithFPC = strLot_effectiveFPCInfo_Get_out.recipeParameterActionRequired;
//D8000024 add end

                    PPT_METHODTRACE_V1("", "call PPT_CONVERT_EQPID_TO_MACHINE_OR");
                    PosMachine_var aMachine;
                    PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine, equipmentID,
                                                     strCassette_CheckConditionForOperation_out,
                                                     cassette_CheckConditionForOperation );

                    PPT_METHODTRACE_V1("", "call PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR");
                    PosLogicalRecipe_var aLogicalRecipe;
                    PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                     strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                                     strCassette_CheckConditionForOperation_out,
                                                                     cassette_CheckConditionForOperation );

                    PPT_METHODTRACE_V1("", "call PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR");
                    PosMachineRecipe_var aMachineRecipe;
//D7000042          PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR( aMachineRecipe,
//D7000042                                                    strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
//D7000042                                                    strCassette_CheckConditionForOperation_out,
//D7000042                                                    cassette_CheckConditionForOperation );
//D6000415          PPT_METHODTRACE_V1("", "call aLogicalRecipe->findRecipeParametersFor");
//D6000415 add start
                    /************************/
                    /*   Get subLotType     */
                    /************************/
                    PosLot_var aLot ; //DSIV00001443
                    CORBA::String_var subLotType;
                    if( 0 == CIMFWStrLen( strStartCassette[i].strLotInCassette[j].subLotType) )
                    {
//DSIV00001443                        PosLot_var aLot ;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                                     strStartCassette[i].strLotInCassette[j].lotID,
                                                     strCassette_CheckConditionForOperation_out,
                                                     cassette_CheckConditionForOperation );

                        try
                        {
                            subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
                    }
                    else
                    {
                        subLotType = strStartCassette[i].strLotInCassette[j].subLotType ;
                    }
                    PPT_METHODTRACE_V1("", "call aLogicalRecipe->findRecipeParametersForSubLotType");
//D6000415 add end
                    if( searchCondition == 1 )                                                          //DSIV00001443
                    {                                                                                   //DSIV00001443
                        if( CORBA::is_nil(aLot) == TRUE )                                               //DSIV00001443
                        {                                                                               //DSIV00001443
                            PPT_CONVERT_LOTID_TO_LOT_OR( aLot,                                          //DSIV00001443
                                                         strStartCassette[i].strLotInCassette[j].lotID, //DSIV00001443
                                                         strCassette_CheckConditionForOperation_out,    //DSIV00001443
                                                         cassette_CheckConditionForOperation );         //DSIV00001443
                        }                                                                               //DSIV00001443
                        try                                                                             //DSIV00001443
                        {                                                                               //DSIV00001443
                            aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine );    //DSIV00001443
                        }                                                                               //DSIV00001443
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)              //DSIV00001443
                    }                                                                                   //DSIV00001443
                    else                                                                                //DSIV00001443
                    {                                                                                   //DSIV00001443
//D7000042 add start
                        try
                        {
                            aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType( aMachine, subLotType );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType)
//D7000042 add end
                    }                                                                                   //DSIV00001443
//D8000024 add start
                    if( CORBA::is_nil(aMachineRecipe) == TRUE &&
                        strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "MachineRecipe is overwritten by FPC");
                        skipFlag = TRUE;
                    }

//D8000024 add end
                        PosRecipeParameterSequence* aRecipeParameters = NULL;
//D8000024 add start
                    if( skipFlag == FALSE && paramCheckWithFPC == FALSE )
                    {
//D8000024 add end
//PSN000062207 add start
                        if( CORBA::is_nil(aMachineRecipe) )
                        {
                            PPT_METHODTRACE_V1("", "aMachineRecipe is nil");
                            SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                        MSG_NOT_FOUND_MCRECIPE,
                                        RC_NOT_FOUND_MCRECIPE );
                            return RC_NOT_FOUND_MCRECIPE;
                        }
//PSN000062207 add end
                        try
                        {
//D6000415                  aRecipeParameters = aLogicalRecipe->findRecipeParametersFor( aMachine, aMachineRecipe );
                            aRecipeParameters = aLogicalRecipe->findRecipeParametersForSubLotType( aMachine, aMachineRecipe, subLotType );    //D6000415
                        }
//D6000415              CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findRecipeParametersFor)
//PSN000062207                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findRecipeParametersForSubLotType)    //D6000415
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersForSubLotType)                     //PSN000062207
                    }  //D8000024

                    PosRecipeParameterSequence_var aTmpRecipeParametersVar = aRecipeParameters;

//D8000024 add start
                    if( paramCheckWithFPC == FALSE )
                    {
                        PPT_METHODTRACE_V1("","Recipe Parameter Check with SM Information.");
//D8000024 add end
                        CORBA::Long lenParams = aRecipeParameters->length();
                        PPT_METHODTRACE_V2("", "lenParams ---> ", lenParams);
//DSN000080573 add start
                        CORBA::Long lenLotWafer = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                        PPT_METHODTRACE_V2("", "lenLotWafer ---> ", lenLotWafer);
                        CORBA::String_var recipeParameterChangeType = strStartCassette[i].strLotInCassette[j].recipeParameterChangeType;
                        if ( CIMFWStrCmp(recipeParameterChangeType, SP_Rparm_ChangeType_ByLot) == 0 )
                        {
                            PPT_METHODTRACE_V2("", "recipeParameterChangeType is ByLot, check first wafer only", strStartCassette[i].strLotInCassette[j].lotID.identifier);
                            lenLotWafer = 1;
                        }
//DSN000080573 add end
                        for ( k=0; k < lenParams; k++ )
                        {
                            PPT_METHODTRACE_V2("", "PosRecipeParameterSequence--------------------------round [k]", k);
                            PPT_METHODTRACE_V1("", "");
                            PPT_METHODTRACE_V2("", "aRecipeParameters->parameterName ------->", (*aRecipeParameters)[k].parameterName);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->unit----------------->", (*aRecipeParameters)[k].unit);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->dataType------------->", (*aRecipeParameters)[k].dataType);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->defaultValue--------->", (*aRecipeParameters)[k].defaultValue);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->lowerLimit----------->", (*aRecipeParameters)[k].lowerLimit);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->upperLimit----------->", (*aRecipeParameters)[k].upperLimit);
//D9000001                            PPT_METHODTRACE_V2("", "aRecipeParameters->useCurrentValueFlag-->", (long)(*aRecipeParameters)[k].useCurrentValueFlag);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->useCurrentValueFlag-->", (int)(*aRecipeParameters)[k].useCurrentValueFlag); //D9000001
                            PPT_METHODTRACE_V1("", "");

//P3100252 start
                            if ( 0 == CIMFWStrCmp( (*aRecipeParameters)[k].dataType, SP_DCDef_Val_String) )
                            {
                                PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_String -----> continue !!");
                                continue;
                            }
//P3100252 end

                            /*----------------------------------------------------*/
                            /* Find strStartRecipeParameter from strStartCassette */
                            /*----------------------------------------------------*/
//DSN000080573              CORBA::Long lenLotWafer = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
//DSN000080573              PPT_METHODTRACE_V2("", "lenLotWafer ---> ", lenLotWafer);
                            for ( l=0; l < lenLotWafer; l++ )
                            {
                                PPT_METHODTRACE_V3("", "lenLotWafer---------------------------------------------round [l]", l,
                                                            strStartCassette[i].strLotInCassette[j].strLotWafer[l].waferID.identifier);

                                CORBA::Long lenRecipeParam = strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter.length();
                                PPT_METHODTRACE_V2("", "lenRecipeParam ---> ", lenRecipeParam);
//DSN000080573 add start
                                CORBA::Boolean bRcpParamFound = FALSE;
                                if ( (k<lenRecipeParam) && 
                                     0 == CIMFWStrCmp(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[k].parameterName,(*aRecipeParameters)[k].parameterName) )
                                {
                                    PPT_METHODTRACE_V3("", "found recipe name at index=k", (*aRecipeParameters)[k].parameterName, k);
                                    bRcpParamFound = TRUE;
                                    m = k;
                                }
                                else
                                {
//DSN000080573 add end
//DSN000080573 indent start
                                    for ( m=0; m < lenRecipeParam; m++ )
                                    {
                                        PPT_METHODTRACE_V3("", "lenRecipeParam----------------------------------------------round [m]", m,
                                                    strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterName);

                                        PPT_METHODTRACE_V2("", "    StartCassette.parameterValue------->", strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue);
                                        PPT_METHODTRACE_V2("", "    StartCassette.targetValue---------->", strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].targetValue);
//D9000001                                    PPT_METHODTRACE_V2("", "    StartCassette.useCurrentValueFlag-->", (long)strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].useCurrentSettingValueFlag);
                                        PPT_METHODTRACE_V2("", "    StartCassette.useCurrentValueFlag-->", (int)strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].useCurrentSettingValueFlag); //D9000001

                                        if ( 0 == CIMFWStrCmp(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterName,
                                                              (*aRecipeParameters)[k].parameterName) )
                                        {
                                            PPT_METHODTRACE_V2("", "### found ###  Same Parameter Name!!", (*aRecipeParameters)[k].parameterName);
//DSN000080573 add start
                                            bRcpParamFound = TRUE;
                                            break;
                                        }
                                    }
                                }
                                if( TRUE == bRcpParamFound )
                                {
//DSN000080573 add end
                                    if ( TRUE == (*aRecipeParameters)[k].useCurrentValueFlag )
                                    {
                                        PPT_METHODTRACE_V1("", "TRUE == (*aRecipeParameters)[k].useCurrentValueFlag");

//P3100301 start
                                        if ( 0 < CIMFWStrLen(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue) )
                                        {
                                            PPT_METHODTRACE_V1("", "0 < CIMFWStrLen(parameterValue)");
                                            PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperation_out,
                                                                MSG_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                                RC_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                                (*aRecipeParameters)[k].parameterName );

                                            return RC_INVALID_PARAMETERVALUE_MUST_BE_NULL;
                                        }
                                        else
                                        {
                                            PPT_METHODTRACE_V1("", "parameterValue = NULL ---> <<<<< Check OK!! >>>>>");
                                        }
//P3100301 end

//P3100301                                        if ( atol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue)
//P3100301                                          != atol((*aRecipeParameters)[k].defaultValue) )
//P3100301                                        {
//P3100301                                            PPT_METHODTRACE_V1("", "Not Same!! parameterValue");
//P3100301                                            PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperation_out,
//P3100301                                                                MSG_NOT_SAME_DEFAULT_PRRAMETER_VALUE,
//P3100301                                                                RC_NOT_SAME_DEFAULT_PRRAMETER_VALUE,
//P3100301                                                                (*aRecipeParameters)[k].defaultValue );
//P3100301
//P3100301                                            return RC_NOT_SAME_DEFAULT_PRRAMETER_VALUE;
//P3100301                                        }
                                    }
                                    else
                                    {
                                        PPT_METHODTRACE_V1("", "FALSE == (*aRecipeParameters)[k].useCurrentValueFlag");

//P4200398 start
                                        if ( 0 == CIMFWStrCmp( (*aRecipeParameters)[k].dataType, SP_DCDef_Val_Integer) )
                                        {
                                            PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Integer");
//P5100030 start
                                            CORBA::Boolean bIsLong = TRUE;
                                            errno = 0;
                                            char *endptr;
                                            long nResult = strtol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, &endptr, 10);
                                            PPT_METHODTRACE_V2("", "nResult", nResult);
                                            if ( ERANGE == errno )
                                            {
                                                // overflow or underflow
                                                PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                                bIsLong = FALSE;
                                            }
                                            else if ( strlen(endptr) == 0 )
                                            {
                                                // The character which can be recognized as a numerical value
                                                PPT_METHODTRACE_V1("", "bIsLong = TRUE");
                                                bIsLong = TRUE;
                                            }
                                            else
                                            {
                                                // // The character which cannot be recognized as a numerical value
                                                PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                                bIsLong = FALSE;
                                            }
//P5100030 end

                                            CORBA::Long parameterValue, lowerLimit, upperLimit;
//D9000001                                                sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%ld", &parameterValue);
//D9000001                                                sscanf((*aRecipeParameters)[k].lowerLimit, "%ld", &lowerLimit);
//D9000001                                                sscanf((*aRecipeParameters)[k].upperLimit, "%ld", &upperLimit);

                                            sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%d", &parameterValue); //D9000001
                                            sscanf((*aRecipeParameters)[k].lowerLimit, "%d", &lowerLimit); //D9000001
                                            sscanf((*aRecipeParameters)[k].upperLimit, "%d", &upperLimit); //D9000001

                                            if ( !bIsLong || ((parameterValue < lowerLimit) || (parameterValue > upperLimit)) ) //P5100030
//P5100030                                            if ( (parameterValue < lowerLimit) || (parameterValue > upperLimit) )
                                            {
                                                PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                                PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperation_out,
                                                                     MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                                     RC_INVALID_PARAMETER_VALUE_RANGE,
                                                                     (*aRecipeParameters)[k].parameterName,
                                                                     (*aRecipeParameters)[k].lowerLimit,
                                                                     (*aRecipeParameters)[k].upperLimit );

                                                return RC_INVALID_PARAMETER_VALUE_RANGE;
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                                            }
                                        }
                                        else if ( 0 == CIMFWStrCmp( (*aRecipeParameters)[k].dataType, SP_DCDef_Val_Float) )
                                        {
                                            PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Float");
                                            CORBA::Double parameterValue, lowerLimit, upperLimit;
                                            sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%lf", &parameterValue);
                                            sscanf((*aRecipeParameters)[k].lowerLimit, "%lf", &lowerLimit);
                                            sscanf((*aRecipeParameters)[k].upperLimit, "%lf", &upperLimit);
                                            if ( (parameterValue < lowerLimit) || (parameterValue > upperLimit) )
                                            {
                                                PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                                PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperation_out,
                                                                     MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                                     RC_INVALID_PARAMETER_VALUE_RANGE,
                                                                     (*aRecipeParameters)[k].parameterName,
                                                                     (*aRecipeParameters)[k].lowerLimit,
                                                                     (*aRecipeParameters)[k].upperLimit );

                                                return RC_INVALID_PARAMETER_VALUE_RANGE;
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                                            }
                                        }
//P4200398 end
//P4200398                                        if ( atol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue)
//P4200398                                           < atol((*aRecipeParameters)[k].lowerLimit) ||
//P4200398                                             atol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue)
//P4200398                                           > atol((*aRecipeParameters)[k].upperLimit) )
//P4200398                                        {
//P4200398                                            PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
//P4200398                                            PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperation_out,
//P4200398                                                                 MSG_INVALID_PARAMETER_VALUE_RANGE,
//P4200398                                                                 RC_INVALID_PARAMETER_VALUE_RANGE,
//P4200398                                                                 (*aRecipeParameters)[k].parameterName,
//P4200398                                                                 (*aRecipeParameters)[k].lowerLimit,
//P4200398                                                                 (*aRecipeParameters)[k].upperLimit );
//P4200398
//P4200398                                            return RC_INVALID_PARAMETER_VALUE_RANGE;
//P4200398                                        }
//P4200398                                        else
//P4200398                                        {
//P4200398                                            PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
//P4200398                                        }
                                    }
//DSN000080573 indent end
//DSN000080573                                    }
                                }
                            }
                        }
//D8000024 add start
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","Recipe Parameter Check with FPC Information.");

                        // Following logic is based on paramCheckWithFPC == FALSE case.

                        /*----------------------------------------------------*/
                        /* Find strStartRecipeParameter from strStartCassette */
                        /*----------------------------------------------------*/
                        CORBA::Long lenLotWafer = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                        PPT_METHODTRACE_V2("", "lenLotWafer ---> ", lenLotWafer);
                        for ( l=0; l < lenLotWafer; l++ )
                        {
                            PPT_METHODTRACE_V3("", "lenLotWafer---------------------------------------------round [l]", l,
                                                        strStartCassette[i].strLotInCassette[j].strLotWafer[l].waferID.identifier);

                            //FPC Wafer Matching
                            objectIdentifier  tmpWaferID;
                            tmpWaferID = strStartCassette[i].strLotInCassette[j].strLotWafer[l].waferID;
                            CORBA::Long  fpcWaferCount = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList.length();
                            PPT_METHODTRACE_V2("","FPCInfo waferCount", fpcWaferCount);
                            CORBA::Long  wPos = 0;
                            for(wPos = 0; wPos < fpcWaferCount; wPos++)
                            {
                                if( 0 == CIMFWStrCmp(tmpWaferID.identifier, strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].waferID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("","wafer found in FPCInfo");
                                    break;
                                }
                            }
                            if( wPos == fpcWaferCount )
                            {
                                PPT_METHODTRACE_V2("","wafer not found in FPCInfo.", tmpWaferID.identifier);
                                SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                            MSG_FPC_WAFER_MISMATCH_IN_FPC_GROUP,
                                            RC_FPC_WAFER_MISMATCH_IN_FPC_GROUP );

                                return RC_FPC_WAFER_MISMATCH_IN_FPC_GROUP;
                            }
                            //FPC Wafer Matching END. use wPos.

                            CORBA::Long lenRecipeParam = strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter.length();
                            PPT_METHODTRACE_V2("", "lenRecipeParam ---> ", lenRecipeParam);
                            for ( m=0; m < lenRecipeParam; m++ )
                            {
                                PPT_METHODTRACE_V3("", "lenRecipeParam----------------------------------------------round [m]", m,
                                            strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterName);

                                PPT_METHODTRACE_V2("", "    StartCassette.parameterValue------->", strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue);
                                PPT_METHODTRACE_V2("", "    StartCassette.targetValue---------->", strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].targetValue);
//D9000001                                PPT_METHODTRACE_V2("", "    StartCassette.useCurrentValueFlag-->", (long)strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].useCurrentSettingValueFlag);
                                PPT_METHODTRACE_V2("", "    StartCassette.useCurrentValueFlag-->", (int)strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].useCurrentSettingValueFlag); //D9000001

                                //FPC RecipeParam Matching
                                CORBA::String_var  fpcParamName = strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterName;
                                CORBA::Long  fpcRParamCount = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList.length();
                                PPT_METHODTRACE_V2("","FPCInfo RParamCount", fpcRParamCount);
                                CORBA::Long  pPos = 0;
                                for(pPos = 0; pPos < fpcRParamCount; pPos++)
                                {
                                    if( 0 == CIMFWStrCmp(fpcParamName, strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterName) )
                                    {
                                        PPT_METHODTRACE_V1("","recipeParam found in FPCInfo.");
                                        break;
                                    }
                                }
                                if( pPos == fpcRParamCount )
                                {
                                    PPT_METHODTRACE_V2("","recipeParam not found in FPCinfo.", fpcParamName);
                                    SET_MSG_RC( strCassette_CheckConditionForOperation_out,
                                                MSG_FPC_RECIPEPARM_ERROR, RC_FPC_RECIPEPARM_ERROR);

                                    return RC_FPC_RECIPEPARM_ERROR;
                                }
                                CORBA::String_var  fpcParamUnit          = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterUnit;
                                CORBA::String_var  fpcParamDataType      = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterDataType;
                                CORBA::String_var  fpcParamLowerLimit    = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterLowerLimit;
                                CORBA::String_var  fpcParamUpperLimit    = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterUpperLimit;
                                CORBA::Boolean  fpcUseCurrentSettingFlag = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].useCurrentSettingValueFlag;
                                CORBA::String_var  fpcParamTargetValue   = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterTargetValue;
                                CORBA::String_var  fpcParamValue         = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterValue;
                                CORBA::String_var  fpcParamTag           = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterTag;
                                //FPC RecipeParam Matching END.

                                if ( 0 == CIMFWStrCmp( fpcParamDataType, SP_DCDef_Val_String) )
                                {
                                    PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_String -----> continue !!");
                                    continue;
                                }

                                if ( TRUE == fpcUseCurrentSettingFlag )
                                {
                                    PPT_METHODTRACE_V1("", "FPC useCurrentSettingValueFlag is TRUE");

                                    if ( 0 < CIMFWStrLen(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue) )
                                    {
                                        PPT_METHODTRACE_V1("", "0 < CIMFWStrLen(parameterValue)");
                                        PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperation_out,
                                                            MSG_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                            RC_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                            fpcParamName );

                                        return RC_INVALID_PARAMETERVALUE_MUST_BE_NULL;
                                    }
                                    else
                                    {
                                        PPT_METHODTRACE_V1("", "parameterValue = NULL ---> <<<<< Check OK!! >>>>>");
                                    }
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("", "FPC useCurrentSettingValueFlag is FALSE");

                                    if ( 0 == CIMFWStrCmp( fpcParamDataType, SP_DCDef_Val_Integer) )
                                    {
                                        PPT_METHODTRACE_V1("", "########## FPC dataType is SP_DCDef_Val_Integer");
                                        CORBA::Boolean bIsLong = TRUE;
                                        errno = 0;
                                        char *endptr = NULL;
                                        long nResult = strtol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, &endptr, 10);
                                        PPT_METHODTRACE_V2("", "nResult", nResult);
                                        if ( ERANGE == errno )
                                        {
                                            // overflow or underflow
                                            PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                            bIsLong = FALSE;
                                        }
                                        else if ( strlen(endptr) == 0 )
                                        {
                                            // The character which can be recognized as a numerical value
                                            PPT_METHODTRACE_V1("", "bIsLong = TRUE");
                                            bIsLong = TRUE;
                                        }
                                        else
                                        {
                                            // // The character which cannot be recognized as a numerical value
                                            PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                            bIsLong = FALSE;
                                        }

                                        CORBA::Long parameterValue = 0;
                                        CORBA::Long lowerLimit     = 0;
                                        CORBA::Long upperLimit     = 0;
//D9000001                                        sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%ld", &parameterValue);
//D9000001                                        sscanf(fpcParamLowerLimit, "%ld", &lowerLimit);
//D9000001                                        sscanf(fpcParamUpperLimit, "%ld", &upperLimit);

                                        sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%d", &parameterValue); //D9000001
                                        sscanf(fpcParamLowerLimit, "%d", &lowerLimit); //D9000001
                                        sscanf(fpcParamUpperLimit, "%d", &upperLimit); //D9000001

                                        if ( !bIsLong || ((parameterValue < lowerLimit) || (parameterValue > upperLimit)) )
                                        {
                                            PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                            PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperation_out,
                                                                 MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                                 RC_INVALID_PARAMETER_VALUE_RANGE,
                                                                 fpcParamName,
                                                                 fpcParamLowerLimit,
                                                                 fpcParamUpperLimit );

                                            return RC_INVALID_PARAMETER_VALUE_RANGE;
                                        }
                                        else
                                        {
                                            PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                                        }
                                    }
                                    else if ( 0 == CIMFWStrCmp( fpcParamDataType, SP_DCDef_Val_Float) )
                                    {
                                        PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Float");
                                        CORBA::Double parameterValue = 0.0;
                                        CORBA::Double lowerLimit     = 0.0;
                                        CORBA::Double upperLimit     = 0.0;
                                        sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%lf", &parameterValue);
                                        sscanf(fpcParamLowerLimit, "%lf", &lowerLimit);
                                        sscanf(fpcParamUpperLimit, "%lf", &upperLimit);
                                        if ( (parameterValue < lowerLimit) || (parameterValue > upperLimit) )
                                        {
                                            PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                            PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperation_out,
                                                                 MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                                 RC_INVALID_PARAMETER_VALUE_RANGE,
                                                                 fpcParamName,
                                                                 fpcParamLowerLimit,
                                                                 fpcParamUpperLimit );

                                            return RC_INVALID_PARAMETER_VALUE_RANGE;
                                        }
                                        else
                                        {
                                            PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                                        }
                                    }
                                }
                            }
                        }
                    }
//D8000024 add end
                }
            }
        }                        //P3100289
        PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100097 end @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//P3100097 end

//P3100289 start
        PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100289 start @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        /*------------------------------------------------------*/
        /*   Check MonitorLotCount and OperationStartLotCount   */
        /*------------------------------------------------------*/
        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
        {
            PPT_METHODTRACE_V1("", "operation = SP_Operation_OpeStart or SP_Operation_StartReservation")

            CORBA::Long nStartLotCnt = 0;
            CORBA::Long nMonitorLotCnt = 0;

            /*-------------------------------*/
            /*   Loop for strStartCassette   */
            /*-------------------------------*/
            lenCassette = strStartCassette.length();
            PPT_METHODTRACE_V2("", "lenCassette--->", lenCassette);

            for ( i=0; i < lenCassette; i++ )
            {
                PPT_METHODTRACE_V3("","loadPurposeType--->", i, strStartCassette[i].loadPurposeType);

                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessLot)
                  || 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot) )
                {
                    PPT_METHODTRACE_V1("","loadPurposeType = SP_LoadPurposeType_ProcessLot or SP_LoadPurposeType_ProcessMonitorLot");

                    /*-------------------------------*/
                    /*   Loop for strLotInCassette   */
                    /*-------------------------------*/
                    CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();
                    PPT_METHODTRACE_V2("", "lenLotInCassette--->", lenLotInCassette);

                    for ( j=0; j < lenLotInCassette; j++ )
                    {
                        if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE )
                        {
                            PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE");
                            nStartLotCnt++;
//P4200533 Remove and Following Logic was Nested                        }

                            if ( strStartCassette[i].strLotInCassette[j].monitorLotFlag == TRUE )
                            {
                                PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].monitorLotFlag == TRUE");
                                nMonitorLotCnt++;
                            }
                        }       //P4200533
                    }
                }
            }

//D4200122 start
            if ( 0 == nStartLotCnt )
            {
                if( virtualOperationFlag == FALSE )    //DSN000096135
                {                                      //DSN000096135
                    PPT_METHODTRACE_V1("", "##### return RC_INVALID_INPUT_LOT_COUNT");
                    PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperation_out,
                                         MSG_INVALID_INPUT_LOT_COUNT,
                                         RC_INVALID_INPUT_LOT_COUNT,
                                         "0",
                                         "1",
                                         "n" );
                    return( RC_INVALID_INPUT_LOT_COUNT );
                }                                      //DSN000096135
            }
//D4200122 end

            if ( nMonitorLotCnt > 1 )
            {
                PPT_METHODTRACE_V1("", "nMonitorLotCnt > 1");
                SET_MSG_RC(strCassette_CheckConditionForOperation_out, MSG_INVALID_PROCMONITOR_COUNT, RC_INVALID_PROCMONITOR_COUNT);
                return( RC_INVALID_PROCMONITOR_COUNT );
            }

            if ( nMonitorLotCnt == 1 && nStartLotCnt == 1 )
            {
                char strStatrLotCnt[16];
                sprintf(strStatrLotCnt, "%ld", nStartLotCnt);

                PPT_METHODTRACE_V1("", "nMonitorLotCnt == 1 && nStartLotCnt == 1");
                PPT_SET_MSG_RC_KEY3(strCassette_CheckConditionForOperation_out,
                                    MSG_INVALID_INPUT_LOT_COUNT,
                                    RC_INVALID_INPUT_LOT_COUNT,
                                    strStatrLotCnt,
                                    "2",
                                    "n");
                return( RC_INVALID_INPUT_LOT_COUNT );
            }
            //P4200533 add start
            //-----------------------------------------------------------//
            //                                                           //
            //   Final Check for LoadPurposeType:ProcessMonitorLot       //
            //                                                           //
            //   The lot, which meets fhe following conditions must be   //
            //   exist, and its lot count must be 1.                     //
            //      - OpeStartFlag   : TRUE                              //
            //      - LotType        : ProcessMonitor                    //
            //      - MonitorLotFlag : TRUE                              //
            //                                                           //
            //-----------------------------------------------------------//
            CORBA::Long    i_cast = 0;
            CORBA::Long    cassetteLen = strStartCassette.length();

            for ( i_cast = 0; i_cast < cassetteLen; i_cast++ )
            {
                PPT_METHODTRACE_V3("", "strStartCassette Info", strStartCassette[i_cast].cassetteID.identifier,
                                    strStartCassette[i_cast].loadPurposeType );

                if (CIMFWStrCmp( strStartCassette[i_cast].loadPurposeType,
                                 SP_LoadPurposeType_ProcessMonitorLot ) ==0 )
                {
                    PPT_METHODTRACE_V2( "", "loadPurposeType is ProcessMonitorLot", i_cast )

                    if ( nMonitorLotCnt != 1 )
                    {
                        PPT_METHODTRACE_V2( "", "nMonitorLotCnt != 1", nMonitorLotCnt );
                        SET_MSG_RC(strCassette_CheckConditionForOperation_out, MSG_INVALID_PROCMONITOR_COUNT, RC_INVALID_PROCMONITOR_COUNT);
                        return( RC_INVALID_PROCMONITOR_COUNT );
                    }

                    CORBA::Long    j_lot = 0;
                    CORBA::Long    lotLen = strStartCassette[i_cast].strLotInCassette.length();

                    for ( j_lot = 0 ; j_lot < lotLen ; j_lot++ )
                    {
                        if (( strStartCassette[i_cast].strLotInCassette[j_lot].monitorLotFlag     == TRUE )&&
                            ( strStartCassette[i_cast].strLotInCassette[j_lot].operationStartFlag == TRUE ))
                        {
                            PPT_METHODTRACE_V3( "", "LotID & LotType", strStartCassette[i_cast].strLotInCassette[j_lot].lotID.identifier,
                                                                       strStartCassette[i_cast].strLotInCassette[j_lot].lotType );

                            if ( CIMFWStrCmp(strStartCassette[i_cast].strLotInCassette[j_lot].lotType,
                                             SP_Lot_Type_ProductionMonitorLot ) != 0 )
                            {
//D5100053 Add Start
                                objLot_monitorRouteFlag_Get_out strLot_monitorRouteFlag_Get_out;

                                rc = lot_monitorRouteFlag_Get(strLot_monitorRouteFlag_Get_out,
                                                              strObjCommonIn,
                                                              strStartCassette[i_cast].strLotInCassette[j_lot].lotID);
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V1("","lot_monitorRouteFlag_Get() != RC_OK");
                                    strCassette_CheckConditionForOperation_out.strResult = strLot_monitorRouteFlag_Get_out.strResult;
                                    return ( rc );
                                }

                                PPT_METHODTRACE_V2( "", "monitorRoute_Flag =", strLot_monitorRouteFlag_Get_out.monitorRoute_Flag );

                                if ( strLot_monitorRouteFlag_Get_out.monitorRoute_Flag == FALSE )
                                {
                                    PPT_METHODTRACE_V1( "", "Specified Lot Type is not ProductionMonitorLot" );
                                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out, MSG_INVALID_LOT_TYPE, RC_INVALID_LOT_TYPE,
                                                         strStartCassette[i_cast].strLotInCassette[j_lot].lotType,
                                                         strStartCassette[i_cast].strLotInCassette[j_lot].lotID.identifier );
                                    return( RC_INVALID_LOT_TYPE );
                                }
//D5100053 Add End
//D5100053                                PPT_METHODTRACE_V1( "", "Specified Lot Type is not ProductionMonitorLot" );
//D5100053                                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperation_out, MSG_INVALID_LOT_TYPE, RC_INVALID_LOT_TYPE,
//D5100053                                                     strStartCassette[i_cast].strLotInCassette[j_lot].lotType,
//D5100053                                                     strStartCassette[i_cast].strLotInCassette[j_lot].lotID.identifier );
//D5100053                                return( RC_INVALID_LOT_TYPE );
                            }

                            break;

                        }
                    }
                }
            }
            //P4200533 add end
        }
        PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100289 end @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//P3100289 end

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cassette_CheckConditionForOperation");

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForOperation_out, cassette_CheckConditionForOperation, methodName)
}
