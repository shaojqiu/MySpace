//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APC_LithoContextInfo_Get.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "pcode.hh"
#include "pwafer.hh"
#include "plotfm.hh"

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APC_LithoContextInfo_Get.cpp
//
//
// Innotron Modification History:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009 Nick Tsai      Get Recommend Context Info for APC
//
// Function Description:
//
// Input Parameters:
//    csObjAPC_LithoContextInfo_Get_out&       strObjAPC_LithoContextInfo_Get_out,
//    const pptObjCommonIn&                             strObjCommonIn,
//    const csObjAPC_LithoContextInfo_Get_in&  strObjAPC_LithoContextInfo_Get_in
//
// typedef struct csObjAPC_LithoContextInfo_Get_in_struct {
//     objectIdentifier                  equipmentID;
//     objectIdentifier                  lotID;
//     objectIdentifier                  routeID;
//     string                            operationNumber;
//     pptStartReticleSequence           strStartReticleSeq;
//     pptStartRecipeParameterSequence   strStartRecipeParameterSeq;
//     string                            action;
//     any                               siInfo;
// }csObjAPC_LithoContextInfo_Get_in;
//
//
// Output Parameters:
// typedef struct csObjAPC_LithoContextInfo_Get_out_struct {
//     pptRetCode                      strResult;
//     csAPCLithoContextInfo           strAPCLithoContextInfo;
//     any                             siInfo;
// }csObjAPC_LithoContextInfo_Get_out;
//
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//


CORBA::Long CS_PPTManager_i::cs_APC_LithoContextInfo_Get (
    csObjAPC_LithoContextInfo_Get_out&       strObjAPC_LithoContextInfo_Get_out,
    const pptObjCommonIn&                    strObjCommonIn,
    const csObjAPC_LithoContextInfo_Get_in&  strObjAPC_LithoContextInfo_Get_in
)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APC_LithoContextInfo_Get");
        //================================================================//
        //   Print input parameters                                       //
        //================================================================//
        PPT_METHODTRACE_V2("", "action ",           strObjAPC_LithoContextInfo_Get_in.action);
        PPT_METHODTRACE_V2("", "equipmentID ",      strObjAPC_LithoContextInfo_Get_in.equipmentID.identifier);
        PPT_METHODTRACE_V2("", "lotID ",            strObjAPC_LithoContextInfo_Get_in.lotID.identifier);
        PPT_METHODTRACE_V2("", "routeID ",          strObjAPC_LithoContextInfo_Get_in.routeID.identifier);
        PPT_METHODTRACE_V2("", "operationNumber ",  strObjAPC_LithoContextInfo_Get_in.operationNumber);
        for ( CORBA::Long i = 0 ; i < strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq.length() ; i ++ )
        {
            PPT_METHODTRACE_V2("", "i ",               i );
            PPT_METHODTRACE_V2("", "sequenceNumber ",  strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq[i].sequenceNumber);
            PPT_METHODTRACE_V2("", "reticleID ",       strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq[i].reticleID.identifier);
        }

        for ( i = 0 ; i < strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq.length() ; i ++ )
        {
            PPT_METHODTRACE_V2("", "i ",                          i );
            PPT_METHODTRACE_V2("", "parameterName ",              strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName);
            PPT_METHODTRACE_V2("", "parameterValue ",             strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterValue);
            PPT_METHODTRACE_V2("", "targetValue ",                strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].targetValue);
            PPT_METHODTRACE_V2("", "useCurrentSettingValueFlag ", strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].useCurrentSettingValueFlag);
        }

        //================================================================//
        //   Check input parameters                                       //
        //================================================================//
        if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND ) != 0 &&
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND ) != 0 &&
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_USED           ) != 0 &&
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_METROLOGY      ) != 0   )
        {
            PPT_METHODTRACE_V1("","action is invalid");
            SET_MSG_RC( strObjAPC_LithoContextInfo_Get_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        if ( CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.equipmentID.identifier) == 0 )
        {
            PPT_METHODTRACE_V1("","CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.equipmentID.identifier) == 0");
            PPT_SET_MSG_RC_KEY( strObjAPC_LithoContextInfo_Get_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, "*******" );
            return RC_NOT_FOUND_EQP;
        }

        if ( CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.lotID.identifier) == 0 )
        {
            PPT_METHODTRACE_V1("","CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.lotID.identifier) == 0");
            PPT_SET_MSG_RC_KEY( strObjAPC_LithoContextInfo_Get_out, MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT, "*******" );
            return RC_NOT_FOUND_LOT;
        }

        if ( strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq.length() == 0 )
        {
            PPT_METHODTRACE_V1("","reticle count is invalid");
            SET_MSG_RC( strObjAPC_LithoContextInfo_Get_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND ) == 0 ||
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND ) == 0  )
        {
            objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
            rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, strObjAPC_LithoContextInfo_Get_in.lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                strObjAPC_LithoContextInfo_Get_out.strResult = strLot_currentOperationInfo_Get_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "Current RouteID",           strLot_currentOperationInfo_Get_out.routeID.identifier  );
            PPT_METHODTRACE_V2("", "Current OperationNumber",   strLot_currentOperationInfo_Get_out.operationNumber     );

            if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.routeID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier ) != 0 ||
                 CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.operationNumber,    strLot_currentOperationInfo_Get_out.operationNumber    ) != 0    )
            {
                PPT_METHODTRACE_V1("","input route/operationNumber are different with current route/operationNumber");
                SET_MSG_RC( strObjAPC_LithoContextInfo_Get_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
                return RC_INVALID_INPUT_PARM;
            }
        }

        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                     strObjAPC_LithoContextInfo_Get_in.lotID,
                                     strObjAPC_LithoContextInfo_Get_out,
                                     cs_APC_LithoContextInfo_Get );

        //================================================================//
        //   Declare Context structure for the result                     //
        //================================================================//
        csAPCLithoContextInfo strAPCLithoContextInfo;
        strAPCLithoContextInfo.lotID            = strObjAPC_LithoContextInfo_Get_in.lotID.identifier   ;
        strAPCLithoContextInfo.routeID          = strObjAPC_LithoContextInfo_Get_in.routeID.identifier ;
        strAPCLithoContextInfo.operationNumber  = strObjAPC_LithoContextInfo_Get_in.operationNumber    ;

        //================================================================//
        //   controlJobType                                               //
        //================================================================//
        if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND ) == 0 ||
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND ) == 0 ||
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_USED           ) == 0   )   //Nick:specific controlJobType
        {
            strAPCLithoContextInfo.controlJobType = CIMFWStrDup ( CS_APC_CONTROLJOB_TYPE_LITHO_RECOMMEND );
        }
        else
        {   //Nick How to identify CD/OL
            strAPCLithoContextInfo.controlJobType = CIMFWStrDup ( CS_APC_CONTROLJOB_TYPE_OL_METROLOGY );

            strAPCLithoContextInfo.controlJobType = CIMFWStrDup ( CS_APC_CONTROLJOB_TYPE_CD_METROLOGY );
        }
        PPT_METHODTRACE_V2("", "controlJobType = ", strAPCLithoContextInfo.controlJobType );


        //================================================================//
        //   transactionID / recommendTransactionID / usedTransactionID   //
        //   (LOT_IDYYYYmmddHHMMSS)                                       //
        //================================================================//
        PPT_METHODTRACE_V2("", "lotID = ",           strObjAPC_LithoContextInfo_Get_in.lotID.identifier );
        PPT_METHODTRACE_V2("", "reportTimeStamp = ", strObjCommonIn.strTimeStamp.reportTimeStamp        );
        char arrReportTimeStamp[256];
        memset ( arrReportTimeStamp, '\0', sizeof (arrReportTimeStamp) );
        CIMFWStrCpy ( arrReportTimeStamp, strObjCommonIn.strTimeStamp.reportTimeStamp );

        CORBA::Long lIDLen = CIMFWStrLen(strObjAPC_LithoContextInfo_Get_in.lotID.identifier) + CIMFWStrLen(arrReportTimeStamp);
        PPT_METHODTRACE_V2("", "lIDLen = ", lIDLen );

        CORBA::String_var varTransactionID = CORBA::string_alloc ( lIDLen );

        CIMFWStrCpy ( varTransactionID, strObjAPC_LithoContextInfo_Get_in.lotID.identifier );
        PPT_METHODTRACE_V2("", "varTransactionID(LOT_ID) = ", varTransactionID );

        char* pReportTimeStamp = arrReportTimeStamp ;
        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 4 );   //YYYY
        pReportTimeStamp = pReportTimeStamp +5 ;
        PPT_METHODTRACE_V2("", "varTransactionID(YYYY) = ", varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //mm
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(mm) = ",   varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //dd
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(dd) = ",   varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //HH
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(HH) = ",   varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //MM
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(MM) = ",   varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //SS
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(SS) = ",   varTransactionID );

        strAPCLithoContextInfo.transactionID = varTransactionID;

        // Recommend : set the transaction ID to M_LOT_RecTxID
        if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND ) == 0 ||
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND ) == 0 )
        {
            PPT_METHODTRACE_V2("", "set M_LOT_RecTxID when APC Recommend ", strObjAPC_LithoContextInfo_Get_in.action );
            SI_PPT_USERDATA_SET_STRING( aLot, "M_LOT_RecTxID", strAPCLithoContextInfo.transactionID );   //Nick need const
        }
        // Used : set the transaction ID to M_LOT_UsedTxID and get M_LOT_RecTxID into recommendTransactionID
        else if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_USED ) == 0 )
        {
            //set the transaction ID to M_LOT_UsedTxID
            PPT_METHODTRACE_V2("", "set M_LOT_UsedTxID and get M_LOT_RecTxID when APC Used", strObjAPC_LithoContextInfo_Get_in.action );
            SI_PPT_USERDATA_SET_STRING( aLot, "M_LOT_UsedTxID", strAPCLithoContextInfo.transactionID );   //Nick need const

            //get M_LOT_RecTxID into recommendTransactionID
            SI_PPT_USERDATA_GET_STRING( aLot, "M_LOT_RecTxID", strAPCLithoContextInfo.recommendTransactionID );   //Nick need const
        }
        // Metrology : get M_LOT_UsedTxID into usedTransactionID
        else if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_METROLOGY ) == 0 )
        {
            //get M_LOT_UsedTxID into usedTransactionID
            PPT_METHODTRACE_V2("", "get M_LOT_UsedTxID when APC Metrology ", strObjAPC_LithoContextInfo_Get_in.action );
            SI_PPT_USERDATA_GET_STRING( aLot, "M_LOT_UsedTxID", strAPCLithoContextInfo.usedTransactionID );   //Nick need const
        }

        PPT_METHODTRACE_V2("", "transactionID = ",          strAPCLithoContextInfo.transactionID );
        PPT_METHODTRACE_V2("", "recommendTransactionID = ", strAPCLithoContextInfo.recommendTransactionID );
        PPT_METHODTRACE_V2("", "usedTransactionID = ",      strAPCLithoContextInfo.usedTransactionID );

        //================================================================//
        //   lotType                                                      //
        //================================================================//
        CORBA::String_var varLotType;
        try
        {
            varLotType = aLot->getLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)

        PPT_METHODTRACE_V2("", "lotType ", varLotType );
        if ( CIMFWStrCmp ( varLotType, SP_Lot_Type_ProductionLot ) == 0 )
        {
            PPT_METHODTRACE_V1("", "lot is SP_Lot_Type_ProductionLot " );
            strAPCLithoContextInfo.lotType = CIMFWStrDup ( CS_APC_LOT_TYPE_PRODUCTION_LOT );
        }
        else if ( CIMFWStrCmp ( varLotType, SP_Lot_Type_EngineeringLot ) == 0 )
        {
            PPT_METHODTRACE_V1("", "lot is SP_Lot_Type_EngineeringLot " );
            strAPCLithoContextInfo.lotType = CIMFWStrDup ( CS_APC_LOT_TYPE_ENGINEERING_LOT );
        }
        else if ( CIMFWStrCmp ( varLotType, SP_Lot_Type_ProductionMonitorLot ) == 0 ||
                  CIMFWStrCmp ( varLotType, SP_Lot_Type_EquipmentMonitorLot ) == 0  )
        {
            PPT_METHODTRACE_V1("", "lot is SP_Lot_Type_ProductionMonitorLot or SP_Lot_Type_EquipmentMonitorLot " );
            strAPCLithoContextInfo.lotType = CIMFWStrDup ( CS_APC_LOT_TYPE_MONITOR_LOT );
        }

        PPT_METHODTRACE_V2("", "lotType = ",    strAPCLithoContextInfo.lotType );

        //================================================================//
        //   partID                                                       //
        //================================================================//
        ProductSpecification_var aProductSpec;
        CORBA::String_var varProductID;
        try
        {
            aProductSpec = aLot->getProductSpecification();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification)

        if ( CORBA::is_nil(aProductSpec) == FALSE )
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(aProductSpec) == FALSE" );
            try
            {
                varProductID = aProductSpec->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(ProductSpecification::getIdentifier)
            strAPCLithoContextInfo.partID = varProductID ;
        }

        PPT_METHODTRACE_V2("", "partID = ",    strAPCLithoContextInfo.partID );

        //================================================================//
        //   layer                                                        //
        //================================================================//
        ProcessDefinition_var    varPD;
        PosProcessDefinition_var varPosPD;
        try
        {
            varPD = theProcessDefinitionManager->findMainProcessDefinitionNamed( strObjAPC_LithoContextInfo_Get_in.routeID.identifier ) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProcessDefinitionManager::findMainProcessDefinitionNamed);
        PPT_METHODTRACE_V2("", "varPD", varPD);
        varPosPD = PosProcessDefinition::_narrow( varPD ) ;
        if( CORBA::is_nil( varPosPD ) )
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil( varPosPD )");
            PPT_SET_MSG_RC_KEY( strUserData_GetByOperation_out,
                                MSG_NOT_FOUND_PD,
                                RC_NOT_FOUND_PD,
                                routeID.identifier );
            return RC_NOT_FOUND_PD ;
        }

        PosProcessFlow_var varPosProcessFlow;
        try
        {
            varPosProcessFlow = varPosPD->getActiveProcessFlow();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getActiveProcessFlow)
        PPT_METHODTRACE_V2("", "varPosProcessFlow", varPosProcessFlow);
        if(CORBA::is_nil(varPosProcessFlow))
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(varPosProcessFlow)");
            PPT_SET_MSG_RC_KEY( strUserData_GetByOperation_out,
                                MSG_NOT_FOUND_PF,
                                RC_NOT_FOUND_PF, "" );
            return RC_NOT_FOUND_PF ;
        }

        PosProcessOperationSpecification_var varMainPOS;
        try
        {
            varMainPOS = varPosProcessFlow->findProcessOperationSpecificationOnDefault( strObjAPC_LithoContextInfo_Get_in.operationNumber );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlow::findProcessOperationSpecificationOnDefault)

        CORBA::String_var aPhotoLayer;
        try
        {
            aPhotoLayer = varMainPOS->getPhotoLayer();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getPhotoLayer);

        strAPCLithoContextInfo.layer = aPhotoLayer;
        PPT_METHODTRACE_V2("", "layer = ",    strAPCLithoContextInfo.layer );

        //================================================================//
        //   routeGroup                                                   //
        //================================================================//
        if ( CORBA::is_nil(aProductSpec) == FALSE )
        {
            PPT_METHODTRACE_V1("", "get routeGroup " );
            SI_PPT_USERDATA_GET_STRING( aProductSpec, CS_S_PROD_ROUTE_GROUP, strAPCLithoContextInfo.routeGroup );
        }
        PPT_METHODTRACE_V2("", "routeGroup = ",    strAPCLithoContextInfo.routeGroup );

        //================================================================//
        //   reticleID                                                    //
        //================================================================//
        CORBA::Long lAPCReticleLen = 0;
        for ( i = 0 ; i < strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq.length() ; i ++ )
        {
            CORBA::Long lReticleLen = CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq[i].reticleID.identifier ) ;
            PPT_METHODTRACE_V2("", "lReticleLen ",    lReticleLen );

            lAPCReticleLen = lAPCReticleLen + lReticleLen + 1;
            PPT_METHODTRACE_V2("", "lAPCReticleLen ", lAPCReticleLen );
        }

        CORBA::String_var varAPCReticleID = CORBA::string_alloc ( lAPCReticleLen );

        for ( i = 0 ; i < strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq.length() ; i ++ )
        {
            PPT_METHODTRACE_V2("", "reticleID ",    strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq[i].reticleID.identifier );

            if ( i > 0 )
            {
                PPT_METHODTRACE_V1("", "i > 0 " );
                CIMFWStrCat ( varAPCReticleID, " " ) ;
            }

            CIMFWStrCat ( varAPCReticleID, strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq[i].reticleID.identifier ) ;

            PPT_METHODTRACE_V2("", "varAPCReticleID ",    varAPCReticleID );
        }

        strAPCLithoContextInfo.reticleID = varAPCReticleID ;
        PPT_METHODTRACE_V2("", "reticleID = ",    strAPCLithoContextInfo.reticleID );

        //================================================================//
        //   processEquipmentID                                           //
        //================================================================//
        strAPCLithoContextInfo.processEquipmentID = strObjAPC_LithoContextInfo_Get_in.equipmentID.identifier ;
        PPT_METHODTRACE_V2("", "processEquipmentID = ",    strAPCLithoContextInfo.processEquipmentID );

        //================================================================//
        //   processEquipmentType                                         //
        //================================================================//
        objectIdentifier processEquipmentID;
        processEquipmentID.identifier = strAPCLithoContextInfo.processEquipmentID ;

        objMachine_type_Get_out strMachine_type_Get_out__process;
        rc = machine_type_Get( strMachine_type_Get_out__process, strObjCommonIn, processEquipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "machine_type_Get() != RC_OK", rc);
            strObjAPC_LithoContextInfo_Get_out.strResult = strMachine_type_Get_out__process.strResult;
            return( rc );
        }
        objectIdentifier processEquipmentTypeID ;
        processEquipmentTypeID.identifier = strMachine_type_Get_out__process.equipmentType ;

        PosCategory_var aCategory;
        PosCode_var     aProcessEquipmentType;
        try
        {
            aCategory = theCodeManager->findCategoryNamed( SP_CATEGORY_EQUIPMENTTYPE );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCodeManager::findCategoryNamed);

        if( CORBA::is_nil( aCategory ) )
        {
            PPT_METHODTRACE_V1("", "aCategory is nil");
            PPT_SET_MSG_RC_KEY(strObjAPC_LithoContextInfo_Get_out, MSG_NOT_FOUND_CATEGORY, RC_NOT_FOUND_CATEGORY, SP_CATEGORY_EQUIPMENTTYPE);
            return RC_NOT_FOUND_CATEGORY;
        }

        PPT_CONVERT_CODEID_TO_CODE_OR( aCategory,
                                       aProcessEquipmentType,
                                       processEquipmentTypeID,
                                       strObjAPC_LithoContextInfo_Get_out,
                                       cs_APC_LithoContextInfo_Get );

        SI_PPT_USERDATA_GET_STRING( aProcessEquipmentType, CS_S_EQPTYPE_PROCESS_EQP_TYPE, strAPCLithoContextInfo.processEquipmentType );

        PPT_METHODTRACE_V2("", "processEquipmentID = ",    strAPCLithoContextInfo.processEquipmentType );

        //================================================================//
        //   reworkLotFlag                                                //
        //================================================================//
        strAPCLithoContextInfo.reworkLotFlag = FALSE ;

        objLot_wafers_GetDR_out__150 strLot_wafers_GetDR_out;
        objLot_wafers_GetDR_in       strLot_wafers_GetDR_in;
        strLot_wafers_GetDR_in.lotID            = strObjAPC_LithoContextInfo_Get_in.lotID ;
        strLot_wafers_GetDR_in.scrapCheckFlag   = TRUE ;

        rc = lot_wafers_GetDR__150( strLot_wafers_GetDR_out, strObjCommonIn, strLot_wafers_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_wafers_GetDR__150() != RC_OK", rc);
            strObjAPC_LithoContextInfo_Get_out.strResult = strLot_wafers_GetDR_out.strResult;
            return( rc );
        }

        char*  pRwkCntKey = CORBA::string_alloc(  CIMFWStrLen( strObjAPC_LithoContextInfo_Get_in.routeID.identifier )   +
                                                  CIMFWStrLen( SP_Key_Separator_Dot ) +
                                                  CIMFWStrLen( strObjAPC_LithoContextInfo_Get_in.operationNumber ) ) ;
        if( pRwkCntKey != NULL )
        {
            pRwkCntKey[0] = NULL;

            CIMFWStrCpy( pRwkCntKey, strObjAPC_LithoContextInfo_Get_in.routeID.identifier );
            CIMFWStrCat( pRwkCntKey, SP_Key_Separator_Dot );
            CIMFWStrCat( pRwkCntKey, strObjAPC_LithoContextInfo_Get_in.operationNumber );
        }
        CORBA::String_var varRwkCntKey = pRwkCntKey;

        PPT_METHODTRACE_V2("", "The key to check the rework count of the target lot's wafers", pRwkCntKey);

        for ( CORBA::Long j = 0 ; j < strLot_wafers_GetDR_out.strLotWaferAttributes.length() ; j ++ )
        {
            PPT_METHODTRACE_V2("", "j",         j);
            PPT_METHODTRACE_V2("", "waferID",   strLot_wafers_GetDR_out.strLotWaferAttributes[j].waferID.identifier);

            PosWafer_var aWafer;
            PPT_CONVERT_WAFERID_TO_WAFER_OR( aWafer,
                                             strLot_wafers_GetDR_out.strLotWaferAttributes[j].waferID,
                                             strObjAPC_LithoContextInfo_Get_out,
                                             cs_APC_LithoContextInfo_Get );

            CORBA::Long  lReworkCount = 0;
            try
            {
                lReworkCount = aWafer->getReworkCount( pRwkCntKey );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getReworkCount)
            PPT_METHODTRACE_V2("", "lReworkCount", lReworkCount);

            if ( lReworkCount > 0 )
            {
                PPT_METHODTRACE_V1 ("", "lReworkCount > 0");
                strAPCLithoContextInfo.reworkLotFlag = TRUE ;
                break;
            }
        }

        PPT_METHODTRACE_V2("", "reworkLotFlag = ",  strAPCLithoContextInfo.reworkLotFlag );

        //================================================================//
        //   recommendMode                                                //
        //================================================================//
        CORBA::String_var varTargetingFlag ;
        SI_PPT_USERDATA_GET_STRING( aLot, "M_LOT_TargetingLithoFlag", varTargetingFlag );   //Nick need const
        PPT_METHODTRACE_V2("", "M_LOT_TargetingLithoFlag", varTargetingFlag);

        if ( CIMFWStrCmp ( varTargetingFlag, "TRUE" ) == 0 )   //Nick need const
        {
            PPT_METHODTRACE_V1 ("", "TargetingFlag is TRUE");
            strAPCLithoContextInfo.recommendMode = CIMFWStrDup ( CS_APC_RECOMMEND_MODE_SENDAHEAD );
        }
        else if ( strAPCLithoContextInfo.reworkLotFlag == TRUE )
        {
            PPT_METHODTRACE_V1 ("", "ReworkLotFlag is TRUE");
            strAPCLithoContextInfo.recommendMode = CIMFWStrDup ( CS_APC_RECOMMEND_MODE_REWORK );
        }
        else
        {
            PPT_METHODTRACE_V1 ("", "TargetingFlag is FALSE and ReworkLotFlag is FALSE");
            strAPCLithoContextInfo.recommendMode = CIMFWStrDup ( CS_APC_RECOMMEND_MODE_CALCULATE );
        }
        PPT_METHODTRACE_V2("", "recommendMode = ",  strAPCLithoContextInfo.recommendMode );

        //================================================================//
        //   parentLotID                                                  //
        //================================================================//
        LotFamily_var varLotFamily;
        PosLotFamily_var aLotFamily;
        try
        {
            varLotFamily = aLot->getLotFamily();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotFamily)

        aLotFamily = PosLotFamily::_narrow(varLotFamily);

        if( CORBA::is_nil(aLotFamily) )
        {
            SET_MSG_RC(strObjAPC_LithoContextInfo_Get_out, MSG_NOT_FOUND_LOTFAMILY, RC_NOT_FOUND_LOTFAMILY);
            return RC_NOT_FOUND_LOTFAMILY ;
        }

        try
        {
            strAPCLithoContextInfo.parentLotID = aLotFamily->getIdentifier();
        }
        CATCH_AND_RAISE_EXCEPTIONS(LotFamily::getIdentifier)

        PPT_METHODTRACE_V2("", "parentLotID = ",  strAPCLithoContextInfo.parentLotID );

        //================================================================//
        //   preToolID                                                    //
        //================================================================//
        csObjUserData_GetByOperation_out strUserData_GetByOperation_out;

        csObjUserData_GetByOperation_in  strUserData_GetByOperation_in ;
        strUserData_GetByOperation_in.routeID           = strObjAPC_LithoContextInfo_Get_in.routeID ;
        strUserData_GetByOperation_in.operationNumber   = strObjAPC_LithoContextInfo_Get_in.operationNumber ;
        strUserData_GetByOperation_in.userDataNameSeq.length(1) ;
        strUserData_GetByOperation_in.userDataNameSeq[0] = CIMFWStrDup ( "S_MAINPD_OpeAPCPreOpeNo" ) ;

        rc = cs_userData_GetByOperation( strUserData_GetByOperation_out, strObjCommonIn, strUserData_GetByOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_userData_GetByOperation() != RC_OK", rc);
            strObjAPC_LithoContextInfo_Get_out.strResult = strUserData_GetByOperation_out.strResult;
            return( rc );
        }
/*
        if ( strUserData_GetByOperation_out.strUserDataSeq.length() > 0 )
        {
            PPT_METHODTRACE_V2("", "S_MAINPD_OpeAPCPreOpeNo", strUserData_GetByOperation_out.strUserDataSeq[0].value);

            csObjLot_POObj_GetByOperationDR_out strLot_POObj_GetByOperationDR_out;
            csObjLot_POObj_GetByOperationDR_in  strLot_POObj_GetByOperationDR_in ;
            strLot_POObj_GetByOperationDR_in.lotID                  = strObjAPC_LithoContextInfo_Get_in.lotID ;
            strLot_POObj_GetByOperationDR_in.routeID                = strObjAPC_LithoContextInfo_Get_in.routeID ;
            strLot_POObj_GetByOperationDR_in.operationNumber        = strUserData_GetByOperation_out.strUserDataSeq[0].value ;
            strLot_POObj_GetByOperationDR_in.lastestPassCountFlag   = TRUE;

            rc = cs_lot_POObj_GetByOperationDR( strLot_POObj_GetByOperationDR_out, strObjCommonIn, strLot_POObj_GetByOperationDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cs_lot_POObj_GetByOperationDR() != RC_OK", rc);
                strObjAPC_LithoContextInfo_Get_out.strResult = strLot_POObj_GetByOperationDR_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "poObj", strLot_POObj_GetByOperationDR_out.poObj);

            if ( CIMFWStrLen ( strLot_POObj_GetByOperationDR_out.poObj ) > 0 )
            {
                objProcessOperation_Info_GetDR_out strProcessOperation_Info_GetDR_out;
                objProcessOperation_Info_GetDR_in  strProcessOperation_Info_GetDR_in;
                strProcessOperation_Info_GetDR_in.poObj = strLot_POObj_GetByOperationDR_out.poObj;

                rc = processOperation_Info_GetDR( strProcessOperation_Info_GetDR_out, strObjCommonIn, strProcessOperation_Info_GetDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "cs_userData_GetByOperation() != RC_OK", rc);
                    strObjAPC_LithoContextInfo_Get_out.strResult = strProcessOperation_Info_GetDR_out.strResult;
                    return( rc );
                }
                PPT_METHODTRACE_V2("", "asgnEqpID",  strProcessOperation_Info_GetDR_out.asgnEqpID.identifier );
                strAPCLithoContextInfo.preToolID = strProcessOperation_Info_GetDR_out.asgnEqpID.identifier
            }
            PPT_METHODTRACE_V2("", "preToolID = ",  strAPCLithoContextInfo.preToolID );
        }
*/

        //================================================================//
        //   sendAheadFlag                                                //
        //================================================================//
        strAPCLithoContextInfo.sendAheadFlag = FALSE ;
        if ( CIMFWStrCmp ( varTargetingFlag, "TRUE" ) == 0 )   //Nick need const
        {
            PPT_METHODTRACE_V1 ("", "TargetingFlag is TRUE");
            strAPCLithoContextInfo.sendAheadFlag = TRUE ;
        }

        PPT_METHODTRACE_V2("", "sendAheadFlag = ",  strAPCLithoContextInfo.sendAheadFlag );

        //================================================================//
        //   ParameterNames                                               //
        //================================================================//
        CORBA::Long lAPCRParmLen = 0;
        for ( i = 0 ; i < strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq.length() ; i ++ )
        {
            CORBA::Long lRParmLen = CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName ) ;
            PPT_METHODTRACE_V2("", "lRParmLen ",    lRParmLen );

            lAPCRParmLen = lAPCRParmLen + lRParmLen + 1;
            PPT_METHODTRACE_V2("", "lAPCRParmLen ", lAPCReticleLen );
        }

        CORBA::String_var varAPCRParms = CORBA::string_alloc ( lAPCRParmLen );

        for ( i = 0 ; i < strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq.length() ; i ++ )
        {
            PPT_METHODTRACE_V2("", "parameterName ",    strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName );

            if ( i > 0 )
            {
                PPT_METHODTRACE_V1("", "i > 0 " );
                CIMFWStrCat ( varAPCReticleID, " " ) ;
            }

            if ( strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq.length() > 1 )   //Consider about D1_ & D2_
            {
                PPT_METHODTRACE_V1("", "Double Exposure " );
                if ( CIMFWStrnCmp ( strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName, CS_DOUBLE_EXPOSURE_RECIPE_PARM_D1, 3 ) == 0  ||
                     CIMFWStrnCmp ( strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName, CS_DOUBLE_EXPOSURE_RECIPE_PARM_D2, 3 ) == 0   )
                {
                    CIMFWStrCat ( varAPCRParms, strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName ) ;
                    PPT_METHODTRACE_V2("", "varAPCRParms ", varAPCRParms );
                }
            }
            else if ( strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq.length() == 1 )   //Consider about without D1_ & D2_
            {
                PPT_METHODTRACE_V1("", "Single Reticle " );
                if ( CIMFWStrnCmp ( strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName, CS_DOUBLE_EXPOSURE_RECIPE_PARM_D1 ,3 ) != 0  &&
                     CIMFWStrnCmp ( strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName, CS_DOUBLE_EXPOSURE_RECIPE_PARM_D2, 3 ) != 0   )
                {
                    CIMFWStrCat ( varAPCRParms, strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq[i].parameterName ) ;
                    PPT_METHODTRACE_V2("", "varAPCRParms ", varAPCRParms );
                }
            }

            PPT_METHODTRACE_V2("", "varAPCRParms ",    varAPCRParms );
        }

        strAPCLithoContextInfo.ParameterNames = varAPCRParms ;
        PPT_METHODTRACE_V2("", "ParameterNames = ",    strAPCLithoContextInfo.ParameterNames );

        //================================================================//
        //   availableSubUnit    11|10|01|00                              //
        //================================================================//
        CORBA::String_var varSubUnit = CORBA::string_alloc ( 2 );

        objEquipment_chamberInfo_GetDR_out_struct strEquipment_chamberInfo_GetDR_out;
        rc = equipment_chamberInfo_GetDR( strEquipment_chamberInfo_GetDR_out, strObjCommonIn, strObjAPC_LithoContextInfo_Get_in.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_chamberInfo_GetDR() != RC_OK", rc);
            strObjAPC_LithoContextInfo_Get_out.strResult = strEquipment_chamberInfo_GetDR_out.strResult;
            return( rc );
        }

        CORBA::Long lChuckCnt = 0 ;
        for ( i = 0 ; i < strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus.length() ; i ++ )
        {
            PPT_METHODTRACE_V2("", "i",         i);
            PPT_METHODTRACE_V2("", "chamberID", strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus[i].chamberID.identifier);
            if ( CIMFWStrnCmp ( strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus[i].chamberID.identifier, CS_CHAMBER_CHUCK, 5 ) == 0 )
            {
                PPT_METHODTRACE_V2("", "chamberAvailableFlag", strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus[i].chamberAvailableFlag);
                if ( strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus[i].chamberAvailableFlag == 1 )
                {
                    PPT_METHODTRACE_V1("", "Chuck is Available");
                    CIMFWStrCat ( varSubUnit, "1" ) ;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "Chuck is NotAvailable");
                    CIMFWStrCat ( varSubUnit, "0" ) ;
                }
                lChuckCnt ++ ;

                if ( lChuckCnt == 2 )
                {
                    PPT_METHODTRACE_V1("", "Chuck Count is up to 2");
                    break;
                }
            }
        }

        strAPCLithoContextInfo.availableSubUnit = varSubUnit ;
        PPT_METHODTRACE_V2("", "availableSubUnit = ",    strAPCLithoContextInfo.availableSubUnit );

        //================================================================//
        //   opeStartRecommendFlag                                        //
        //================================================================//
        strAPCLithoContextInfo.opeStartRecommendFlag = FALSE ;
        if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND ) == 0 )
        {
            PPT_METHODTRACE_V1("", "action is CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND " );
            strAPCLithoContextInfo.opeStartRecommendFlag = TRUE ;
        }
        PPT_METHODTRACE_V2("", "opeStartRecommendFlag = ",    strAPCLithoContextInfo.opeStartRecommendFlag );

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APC_LithoContextInfo_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjAPC_LithoContextInfo_Get_out, cs_APC_LithoContextInfo_Get, methodName)
}