//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_durable_CheckConditionForOperationOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"
#include "ppcdr.hh"
#include "pdpflwx.hh"

// Class: PPTManager
//
// Service: durable_CheckConditionForOperation()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2014/11/28 DSN000085770 Sa Guo         Durable Management.
// 2015/07/24 DSN000096126 JQ.Shao        Durable Process Flow Control Support.
// 2016/07/13 DSN000101569 K.Yamaoku      Durable Sub Status Control
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
//[Function Description]:
//   Check durable's condition for Durables Management Operation.
//
//[Input Parameters]:
//  const pptObjCommonIn&                             strObjCommonIn;
//  const objDurable_CheckConditionForOperation_in&   strDurable_CheckConditionForOperation_in;
//
//    typedef struct objDurable_CheckConditionForOperation_in_struct{
//        string                     operation;
//        objectIdentifier           equipmentID;
//        string                     durableCategory;
//        pptStartDurableSequence    strStartDurables;
//        pptDurableStartRecipe      strDurableStartRecipe;
//        any                        siInfo;
//    } objDurable_CheckConditionForOperation_in;
//
//[Output Parameters]:
//  objDurable_CheckConditionForOperation_out&        strDurable_CheckConditionForOperation_out;
//
//    typedef objBase_out                             objDurable_CheckConditionForOperation_out;
//
//[Return Value]:
//
//  Return Code               Message ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//DSN000096126 Add Start  
//  RC_INVALID_DURABLE_HOLDSTAT MSG_INVALID_DURABLE_HOLDSTAT
//  RC_INVALID_Durable_PROCSTAT MSG_INVALID_Durable_PROCSTAT
//  RC_INVALID_Durable_INVENTORYSTAT MSG_INVALID_Durable_INVENTORYSTAT
//  RC_NOT_CORRECT_EQP_FOR_OPESTART MSG_NOT_CORRECT_EQP_FOR_OPESTART
//  RC_BANKIN_OPERATION        MSG_BANKIN_OPERATION
//  RC_NOT_BANKIN_OPERATION    MSG_NOT_BANKIN_OPERATION
//  RC_INVALID_INPUT_PARM      MSG_INVALID_INPUT_PARM
//  RC_DURABLE_INPOSTPROCESS   MSG_DURABLE_INPOSTPROCESS
//DSN000096126 Add End

CORBA::Long CS_PPTManager_i::durable_CheckConditionForOperation(
    objDurable_CheckConditionForOperation_out&        strDurable_CheckConditionForOperation_out,
    const pptObjCommonIn&                             strObjCommonIn,
    const objDurable_CheckConditionForOperation_in&   strDurable_CheckConditionForOperation_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "CS_PPTManager_i::durable_CheckConditionForOperation" );

        //--------------//
        //  Initialize  //
        //--------------//
        CORBA::Long rc = RC_OK;
//DSN000096126 Add Start
        PosMachineSequence_var aMachineSeq;
        CORBA::Boolean isBankInRequired         = FALSE;
//DSN000096126 Add End

        const objDurable_CheckConditionForOperation_in& strInParm = strDurable_CheckConditionForOperation_in;

        //Trace InParameters
        PPT_METHODTRACE_V2("", "in-parm operation        ", strInParm.operation);
        PPT_METHODTRACE_V2("", "in-parm equipmentID      ", strInParm.equipmentID.identifier);
        PPT_METHODTRACE_V2("", "in-parm durableCategory  ", strInParm.durableCategory);

        const char* durableCategory = strInParm.durableCategory;
        if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
         && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
         && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
        {
            PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                MSG_INVALID_DURABLE_CATEGORY,
                                RC_INVALID_DURABLE_CATEGORY,
                                durableCategory );
            return RC_INVALID_DURABLE_CATEGORY ;
        }

        CORBA::Long sequenceCondition = atoi( getenv("SP_CASSETTE_LOAD_SEQUENCE_CONDITION") );
        CORBA::Boolean bCassetteLoadingCheck = FALSE;
        if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
        {
            PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
            if ( sequenceCondition == 0
              && ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) ) )
            {
                PPT_METHODTRACE_V1("", "(operation == SP_Operation_OpeStart) || (operation == SP_Operation_StartReservation)");
                bCassetteLoadingCheck = TRUE;
            }
            if ( sequenceCondition == 1 && 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) )
            {
                PPT_METHODTRACE_V1("", "(operation == SP_Operation_StartReservation)");
                bCassetteLoadingCheck = TRUE;
            }
        }

        CORBA::ULong durableLen = strInParm.strStartDurables.length();
        CORBA::ULong durableCnt = 0;

//DSN000096126 Add Start
        //-------------------------//
        //   Check LogicalRecipe   //
        //-------------------------//
        if ( 0 < CIMFWStrLen(strInParm.strDurableStartRecipe.logicalRecipeID.identifier)
          && ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation)
            || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) ) )
        {
            PPT_METHODTRACE_V1("", "Check LogicalRecipe..." );
            PPT_METHODTRACE_V2("", "logicalRecipeID", strInParm.strDurableStartRecipe.logicalRecipeID.identifier );

            CORBA::ULong invalidCnt = 0;
            CORBA::String_var invalidDurableID;
            for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);

                objDurable_recipe_Get_out strDurable_recipe_Get_out;
                objDurable_recipe_Get_in strDurable_recipe_Get_in;
                strDurable_recipe_Get_in.durableCategory = strInParm.durableCategory;
                strDurable_recipe_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                strDurable_recipe_Get_in.equipmentID     = strInParm.equipmentID;
                rc = durable_recipe_Get(strDurable_recipe_Get_out, strObjCommonIn, strDurable_recipe_Get_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "durable_recipe_Get() != RC_OK");
                    strDurable_CheckConditionForOperation_out.strResult = strDurable_recipe_Get_out.strResult;
                    return( rc );
                }
                PPT_METHODTRACE_V2("", "Current LogicalRecipeID", strDurable_recipe_Get_out.logicalRecipeID.identifier );

                if ( 0 != CIMFWStrCmp(strInParm.strDurableStartRecipe.logicalRecipeID.identifier, strDurable_recipe_Get_out.logicalRecipeID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "LogicalRecipe check NG.");
                    invalidCnt++;
                    if ( NULL == invalidDurableID)
                    {
                        invalidDurableID = strInParm.strStartDurables[durableCnt].durableID.identifier;
                        PPT_METHODTRACE_V2("", "invalidDurableID", invalidDurableID);
                    }
                }
            }

            if ( 0 < invalidCnt )
            {
                PPT_METHODTRACE_V1("", "0 < invalidCnt");
                if ( invalidCnt != durableCnt )
                {
                    PPT_METHODTRACE_V1("", "LogicalRecipe check NG. (LogicalRecipe is not the same as that for other durables.)");
                    PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                        MSG_NOT_SAME_LOGICAL_RECIPE_FOR_DURABLE,
                                        RC_NOT_SAME_LOGICAL_RECIPE_FOR_DURABLE,
                                        invalidDurableID );
                    return RC_NOT_SAME_LOGICAL_RECIPE_FOR_DURABLE;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "Logical Recipe is invalid.");
                    PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                        MSG_INVALID_PARAMETER_WITH_MSG,
                                        RC_INVALID_PARAMETER_WITH_MSG,
                                        "Logical Recipe is invalid." );
                    return RC_INVALID_PARAMETER_WITH_MSG;
                }
            }
        }
//DSN000096126 Add End

        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
            PosDurableProcessFlowContext_var aDurablePFX;
            PosCassette_var aCassette;
            PosReticlePod_var aReticlePod;
            PosProcessDurable_var aReticle;
            if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
            {
                PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                       strInParm.strStartDurables[durableCnt].durableID,
                                                       strDurable_CheckConditionForOperation_out,
                                                       durable_CheckConditionForOperation );

                try
                {
                    aDurablePFX = aCassette->getDurableProcessFlowContext();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableProcessFlowContext)
            }
            else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
            {
                PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
                PPT_CONVERT_RETICLEPODID_TO_RETICLEPOD_OR( aReticlePod,
                                                           strInParm.strStartDurables[durableCnt].durableID,
                                                           strDurable_CheckConditionForOperation_out,
                                                           durable_CheckConditionForOperation );

                try
                {
                    aDurablePFX = aReticlePod->getDurableProcessFlowContext();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableProcessFlowContext)
            }
            else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
            {
                PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
                PPT_CONVERT_RETICLEID_TO_RETICLE_OR( aReticle,
                                                     strInParm.strStartDurables[durableCnt].durableID,
                                                     strDurable_CheckConditionForOperation_out,
                                                     durable_CheckConditionForOperation );

                try
                {
                    aDurablePFX = aReticle->getDurableProcessFlowContext();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableProcessFlowContext)
            }

            if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_PFXCreate) )
            {
                PPT_METHODTRACE_V1("", "operation == SP_Operation_PFXCreate");
//DSN000096126                if ( FALSE == CORBA::is_nil( aDurablePFX ) )
//DSN000096126                {
//DSN000096126                    PPT_METHODTRACE_V2("", "PFX for this durable has already exists.", strInParm.strStartDurables[durableCnt].durableID.identifier);
//DSN000096126                    PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
//DSN000096126                                        MSG_ALREADY_EXIST_DURABLE_PFX,
//DSN000096126                                        RC_ALREADY_EXIST_DURABLE_PFX,
//DSN000096126                                        strInParm.strStartDurables[durableCnt].durableID.identifier );
//DSN000096126                    return RC_ALREADY_EXIST_DURABLE_PFX;
//DSN000096126                }
//DSN000096126 Add Start
                objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
                objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
                strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
                strDurable_OnRoute_Check_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
                if( rc == RC_DURABLE_ONROUTE )
                {
                    PPT_METHODTRACE_V1("", "##### durable is on route");
                    //---------------------------------------
                    // Check Durable Inventory State 
                    //---------------------------------------
                    objDurable_inventoryState_Get_out strDurable_inventoryState_Get_out;
                    objDurable_inventoryState_Get_in  strDurable_inventoryState_Get_in;
                    strDurable_inventoryState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_inventoryState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_inventoryState_Get(strDurable_inventoryState_Get_out, strObjCommonIn, strDurable_inventoryState_Get_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "durable_inventoryState_Get() != RC_OK", rc);
                        strDurable_CheckConditionForOperation_out.strResult = strDurable_inventoryState_Get_out.strResult;
                        return( rc );
                    }
                    else if ( CIMFWStrCmp(strDurable_inventoryState_Get_out.durableInventoryState, SP_Durable_InventoryState_InBank) != 0 )
                    {
                        PPT_METHODTRACE_V1("", "durableInventoryState != SP_Durable_InventoryState_InBank");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_DURABLE_INVENTORYSTAT,
                                             RC_INVALID_DURABLE_INVENTORYSTAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             strDurable_inventoryState_Get_out.durableInventoryState );
                        return(RC_INVALID_DURABLE_INVENTORYSTAT);
                    }
                }
//DSN000096126 Add End
            }
            else
            {
                PPT_METHODTRACE_V1("", "operation != SP_Operation_PFXCreate");
                if ( TRUE == CORBA::is_nil( aDurablePFX ) )
                {
                    PPT_METHODTRACE_V2("", "Cannot get PFX for this durable.", strInParm.strStartDurables[durableCnt].durableID.identifier);
                    PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                        MSG_NOT_FOUND_PFX,
                                        RC_NOT_FOUND_PFX,
                                        "" );
                    return RC_NOT_FOUND_PFX;
                }
            }

            if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation)
              || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
            {
                PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation || SP_Operation_OpeStart");

//DSN000096126 Add Start
                //---------------------------------------
                //  Get InPostProcessFlag of Cassette
                //---------------------------------------
                objDurable_inPostProcessFlag_Get_out strDurable_inPostProcessFlag_Get_out;
                objDurable_inPostProcessFlag_Get_in  strDurable_inPostProcessFlag_Get_in;
                strDurable_inPostProcessFlag_Get_in.durableCategory = strInParm.durableCategory;
                strDurable_inPostProcessFlag_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;

                rc = durable_inPostProcessFlag_Get( strDurable_inPostProcessFlag_Get_out,
                                                    strObjCommonIn,
                                                    strDurable_inPostProcessFlag_Get_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Get() != RC_OK");
                    strDurable_CheckConditionForOperation_out.strResult = strDurable_inPostProcessFlag_Get_out.strResult;
                    return( rc );
                }

                if(strDurable_inPostProcessFlag_Get_out.isPostProcessFlagOn == TRUE)
                {
                    PPT_METHODTRACE_V1("", "NOT External Post Process User!");
                    PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out, 
                                        MSG_DURABLE_INPOSTPROCESS,  RC_DURABLE_INPOSTPROCESS,
                                        strInParm.strStartDurables[durableCnt].durableID.identifier );
                    return RC_DURABLE_INPOSTPROCESS;
                }

                //------------------------------------
                //   Check equipment availability
                //------------------------------------
                objEquipment_CheckAvailForDurable_out strEquipment_CheckAvailForDurable_out;
                objEquipment_CheckAvailForDurable_in  strEquipment_CheckAvailForDurable_in;
                strEquipment_CheckAvailForDurable_in.equipmentID = strInParm.equipmentID;
                rc = equipment_CheckAvailForDurable( strEquipment_CheckAvailForDurable_out, strObjCommonIn, strEquipment_CheckAvailForDurable_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "Equipment is not available. return to caller.", rc);
                    strDurable_CheckConditionForOperation_out.strResult = strEquipment_CheckAvailForDurable_out.strResult;
                    return( rc );
                }
//DSN000096126 Add End

                if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
//DSN000096126 Add Start
                    //-----------------------------------------------------------
                    // Check cassette interFabXferState
                    //-----------------------------------------------------------
                    objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
                    objCassette_interFabXferState_Get_in strCassette_interFabXferState_Get_in;
                    strCassette_interFabXferState_Get_in.cassetteID = strInParm.strStartDurables[durableCnt].durableID;

                    rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out,
                                                         strObjCommonIn,
                                                         strCassette_interFabXferState_Get_in );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cassette_interFabXferState_Get() != RC_OK", rc);
                        strDurable_CheckConditionForOperation_out.strResult = strCassette_interFabXferState_Get_out.strResult;
                        return rc;
                    }

                    if ( 0 == CIMFWStrCmp( strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) )
                    {
                         PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
                         PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                              MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                              RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                              strInParm.strStartDurables[durableCnt].durableID.identifier,
                                              strCassette_interFabXferState_Get_out.interFabXferState );
                         return RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ;
                    }

                    try
                    {
                        aMachineSeq = aCassette->getQueuedMachines();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getQueuedMachines);
//DSN000096126 Add End

                    /*-------------------------------*/
                    /*   Check SorterJob existence   */
                    /*-------------------------------*/
                    objectIdentifierSequence dummyIDs;
                    pptEquipmentLoadPortAttribute equipmentPortAttribute;
                    equipmentPortAttribute.strCassetteLoadPortSeq.length(1);
                    equipmentPortAttribute.strCassetteLoadPortSeq[0].portID     = strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID;
                    equipmentPortAttribute.strCassetteLoadPortSeq[0].cassetteID = strInParm.strStartDurables[durableCnt].durableID;
                    equipmentPortAttribute.equipmentID                          = strInParm.equipmentID;

                    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
                    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
                    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = equipmentPortAttribute;
                    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs.length(1);
                    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs[0]                = strInParm.strStartDurables[durableCnt].durableID;
                    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyIDs;
                    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = strInParm.operation;

                    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                                  strObjCommonIn,
                                                                  strWaferSorter_sorterJob_CheckForOperation_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" ,rc);
                        strDurable_CheckConditionForOperation_out.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
                        return rc;
                    }

                    /*------------------------------------------*/
                    /*   Check Start Cassette's Loading Order   */
                    /*------------------------------------------*/
                    if ( TRUE == bCassetteLoadingCheck )
                    {
                        PPT_METHODTRACE_V1("", "TRUE == bCassetteLoadingCheck");
                        if ( strInParm.strStartDurables[durableCnt].strStartDurablePort.loadSequenceNumber != (durableCnt+1) )
                        {
                            PPT_METHODTRACE_V1("", "Cassette's loading sequence is invalid.");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_INVALID_LOADING_SEQ,
                                                RC_INVALID_LOADING_SEQ,
                                                strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_INVALID_LOADING_SEQ;
                        }
                    }

                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation");
                        /*--------------------------------*/
                        /*   Get and Check ControlJobID   */
                        /*--------------------------------*/
                        PosControlJob_var aControlJob;
                        try
                        {
                            aControlJob = aCassette->getControlJob();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

                        if ( FALSE == CORBA::is_nil(aControlJob) )
                        {
                            PPT_METHODTRACE_V1("", "aControlJob is not nil");
                            SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                        MSG_CAST_CTRLJOBID_FILLED,
                                        RC_CAST_CTRLJOBID_FILLED );
                            return RC_CAST_CTRLJOBID_FILLED;
                        }

                        /*---------------------------------------*/
                        /*   Get and Check DurableControlJobID   */
                        /*---------------------------------------*/
                        PosDurableControlJob_var aDurableControlJob;
                        try
                        {
                            aDurableControlJob = aCassette->getDurableControlJob();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableControlJob)

                        if ( FALSE == CORBA::is_nil(aDurableControlJob) )
                        {
                            PPT_METHODTRACE_V1("", "aDurableControlJob is not nil");
                            SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                        MSG_DURABLECTRLJOBID_FILLED,
                                        RC_DURABLECTRLJOBID_FILLED );
                            return RC_DURABLECTRLJOBID_FILLED;
                        }

                        /*----------------------------------------------*/
                        /*   Get and Check Cassette's Dispatch Status   */
                        /*----------------------------------------------*/
                        CORBA::Boolean dispatchReserveFlag;
                        try
                        {
                            dispatchReserveFlag = aCassette->isDispatchReserved();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchReserved)

                        if ( dispatchReserveFlag != FALSE )
                        {
                            PPT_METHODTRACE_V1("", "dispatchReserveFlag != FALSE");
                            SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                        MSG_ALREADY_DISPATCH_RESVED_CST,
                                        RC_ALREADY_DISPATCH_RESVED_CST );
                            return RC_ALREADY_DISPATCH_RESVED_CST;
                        }
                    }

                    /*--------------------------------------*/
                    /*   Check Cassette's Transfer Status   */
                    /*--------------------------------------*/

                    /*-----------------------*/
                    /*   Get TransferState   */
                    /*-----------------------*/
                    PPT_METHODTRACE_V1("", "Get TransferState");

                    CORBA::String_var transferState;
                    try
                    {
                        transferState = aCassette->getTransportState();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

                    /*------------------------------*/
                    /*   Get TransferReserveState   */
                    /*------------------------------*/
                    PPT_METHODTRACE_V1("", "Get TransferReserveState");

                    CORBA::Boolean transferReserved;
                    try
                    {
                        transferReserved = aCassette->isReserved();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isReserved)

                    PPT_METHODTRACE_V2("", "operation--->", strInParm.operation);
                    PPT_METHODTRACE_V2("", "transferState--->", transferState);
                    if ( TRUE == transferReserved )
                    {
                        PPT_METHODTRACE_V1("", "transferReserved--->TRUE");
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "transferReserved--->FALSE");
                    }

                    /*===== for OpeStart =====*/
                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");

                        if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                        {
                            PPT_METHODTRACE_V1("", "transferState == SP_TransState_EquipmentIn");
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "return RC_INVALID_CAST_XFERSTAT!!");
                            PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_INVALID_CAST_XFERSTAT;
                        }
                    }
                    /*===== for StartReservation =====*/
                    else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation");

                        objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
                        rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                                    strObjCommonIn,
                                                                    strInParm.equipmentID,
                                                                    strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "objPortResource_currentOperationMode_Get_out() != RC_OK" ,rc);
                            strDurable_CheckConditionForOperation_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
                            return rc;
                        }

                        pptEqpPortStatus strOrgEqpPortStatus;
                        PosMachine_var aOrgMachine;

                        // INN-R170003 if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                        // INN-R170003 add start 
                        if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) ||
                             0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut))
                        // INN-R170003 add end                    
                        {
                            /*-------------------------------*/
                            /*   Get Originator Eqp's Info   */
                            /*-------------------------------*/

                            /*--------------------------------*/
                            /*   Get Originator EquipmentID   */
                            /*--------------------------------*/
                            PPT_METHODTRACE_V1("","Get Originator EquipmentID");
                            PPT_METHODTRACE_V2("", "transferState = ", transferState);
                            Machine_var aMachine;
                            try
                            {
                                aMachine = aCassette->currentAssignedMachine();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)

                            if ( TRUE != CORBA::is_nil(aMachine) )
                            {
                                PPT_METHODTRACE_V1( "", "aMachine is not Nill" );
                                CORBA::Boolean isStorageBool = FALSE;
                                try
                                {
                                    isStorageBool = aMachine->isStorageMachine();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(Machine::isStorageMachine)

                                if ( TRUE != isStorageBool )
                                {
                                    PPT_METHODTRACE_V1( "", "isStorageBool is not TRUE: Equipment. So narrow to PosMachine" );
                                    aOrgMachine = PosMachine::_narrow( aMachine );
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1( "", "isStorageBool is TRUE: Storage" );
                                }
                            }
                            else
                            {
                                PPT_METHODTRACE_V1( "", "aMachine is Nill" );
                            }

                            if ( CORBA::is_nil(aOrgMachine) )
                            {
                                PPT_METHODTRACE_V1("", "aOrgMachine is Nil");
                                PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                    MSG_NOT_FOUND_EQP,
                                                    RC_NOT_FOUND_EQP,
                                                    strInParm.equipmentID.identifier );
                                return RC_NOT_FOUND_EQP;
                            }

                            objectIdentifier orgEquipmentID;
                            PPT_SET_OBJECT_IDENTIFIER( orgEquipmentID,
                                                       aOrgMachine,
                                                       strDurable_CheckConditionForOperation_out,
                                                       durable_CheckConditionForOperation,
                                                       PosMachine );

                            /*---------------------------------*/
                            /*   Get Cassette Info in OrgEqp   */
                            /*---------------------------------*/
                            PPT_METHODTRACE_V1("", "Get Cassette Info in OrgEqp");
                            pptEqpPortInfo equipmentPortInfo;
                            CORBA::String_var equipmentCategory;
                            try
                            {
                                equipmentCategory = aOrgMachine->getCategory();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory)
                            PPT_METHODTRACE_V2("", "aOrgMachine->getCategory()", equipmentCategory);

                            if ( 0 == CIMFWStrCmp(equipmentCategory, SP_Mc_Category_InternalBuffer) )
                            {
                                PPT_METHODTRACE_V1("","equipmentCategory is [InternalBuffer]");
                                objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
                                rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                                                strObjCommonIn,
                                                                                orgEquipmentID );
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK", rc);
                                    strDurable_CheckConditionForOperation_out.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                                    return rc;
                                }
                                equipmentPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","equipmentCategory is not [InternalBuffer]");
                                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                                             strObjCommonIn,
                                                             orgEquipmentID );

                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "equipment_portInfo_Get != RC_OK", rc);
                                    strDurable_CheckConditionForOperation_out.strResult = strEquipment_portInfo_Get_out.strResult;
                                    return rc;
                                }
                                equipmentPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo;
                            }

                            CORBA::Boolean bFound = FALSE;
                            CORBA::Long lenEqpPort = equipmentPortInfo.strEqpPortStatus.length();
                            for ( CORBA::ULong portCnt=0; portCnt < lenEqpPort; portCnt++ )
                            {
                                PPT_METHODTRACE_V2("", "loop to equipmentPortInfo.strEqpPortStatus.length()", portCnt);
                                PPT_METHODTRACE_V2("", "portID..............", equipmentPortInfo.strEqpPortStatus[portCnt].portID.identifier);
                                PPT_METHODTRACE_V2("", "loadedCassetteID....", equipmentPortInfo.strEqpPortStatus[portCnt].loadedCassetteID.identifier);

                                if ( 0 == CIMFWStrCmp(strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                      equipmentPortInfo.strEqpPortStatus[portCnt].loadedCassetteID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");
                                    strOrgEqpPortStatus = equipmentPortInfo.strEqpPortStatus[portCnt];
                                    bFound = TRUE;
                                    break;
                                }
                            }

                            if ( FALSE == bFound )
                            {
                                PPT_METHODTRACE_V1("", "return RC_INVALID_CAST_XFERSTAT");
                                PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                     MSG_INVALID_CAST_XFERSTAT,
                                                     RC_INVALID_CAST_XFERSTAT,
                                                     transferState,
                                                     strInParm.strStartDurables[durableCnt].durableID.identifier );
                                return RC_INVALID_CAST_XFERSTAT;
                            }
                        }

                        if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,
                                              SP_Eqp_AccessMode_Manual) )
                        {
                            PPT_METHODTRACE_V1("", ".strOperationMode.accessMode == SP_Eqp_AccessMode_Manual");
                            /*-------------------------------------------------------------------------*/
                            /*   When TransferStatus is EI, AccessMode makes it an error with Manual   */
                            /*-------------------------------------------------------------------------*/
                            // INN-R170003 if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                            // INN-R170003 add start
                               if (    0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) 
                                    || 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut)
                                  )
                            // INN-R170003 add end                        
                            {
                                PPT_METHODTRACE_V1("", ".transferState is [EI]")
                                PPT_METHODTRACE_V2("", "+yangxigang 2 + transferState = ", transferState);
                                
                                /*---------------------------------------------------------------------------*/
                                /*   Permit Carrier which a person can deliver in StartLotReserve.           */
                                /*   As for the condition, OperationMode is "***-1" and XferState is "EI".   */
                                /*---------------------------------------------------------------------------*/
                                if ( 0 != CIMFWStrCmp(strOrgEqpPortStatus.accessMode, SP_Eqp_AccessMode_Manual)
                                  || 0 == CIMFWStrLen(strOrgEqpPortStatus.loadedCassetteID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "##### return RC_INVALID_CAST_XFERSTAT");
                                    PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                         MSG_INVALID_CAST_XFERSTAT,
                                                         RC_INVALID_CAST_XFERSTAT,
                                                         transferState,
                                                         strInParm.strStartDurables[durableCnt].durableID.identifier );
                                    return RC_INVALID_CAST_XFERSTAT;
                                }
                            }
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", ".strOperationMode.accessMode != SP_Eqp_AccessMode_Manual");
                            CORBA::Boolean bReRouteFlg = FALSE;
                            CORBA::String_var reRouteXferFlag = CIMFWStrDup(getenv(SP_REROUTE_XFER_FLAG));
                            PPT_METHODTRACE_V2("","SP_REROUTE_XFER_FLAG ---> ",reRouteXferFlag);

                            PPT_METHODTRACE_V2("","operationMode", strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier); //DSIV00000518

                            if ( 0 == CIMFWStrCmp(reRouteXferFlag, "1")
                              && ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier, SP_Eqp_Port_OperationMode_Auto_3) )
                              && ( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn) ||
                                   0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)     ||
                                   0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn)  ||
                                   0 == CIMFWStrCmp(transferState, SP_TransState_BayOut) )
                              && ( transferReserved == FALSE ) )
                            {
                                PPT_METHODTRACE_V1("", "operationMode is Auto-3")
                                PPT_METHODTRACE_V1("", "transferState = [SI], [BI], [MI], [BO] and transferReserved is FALSE")
                            }
                            else if ( ( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)
                                     || 0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)
                                     || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn) )
                                     && (transferReserved == FALSE) )
                            {
                                PPT_METHODTRACE_V1("", "(transferState = [SI], [BI], [MI] and transferReserved is FALSE")
                            }
                            else if ( ( 0 == CIMFWStrCmp(transferState, SP_TransState_StationOut)
                          //INN-R170003 || 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut) )
                                        || 0 == CIMFWStrCmp(transferState, CS_TRANS_STATE_PORT_OUT) )//INN-R170003
                                   && (transferReserved == FALSE) )
                            {
                                PPT_METHODTRACE_V1("", "(transferState = [SO], [EO], and transferReserved is FALSE")
                                PPT_METHODTRACE_V2("", "transferState = ", transferState);
                                //-------------------------------------
                                //  Check transfer job existence
                                //-------------------------------------
                                objCassette_transferJobRecord_GetDR_out strCassette_transferJobRecord_GetDR_out;
                                rc = cassette_transferJobRecord_GetDR( strCassette_transferJobRecord_GetDR_out,
                                                                       strObjCommonIn,
                                                                       strInParm.strStartDurables[durableCnt].durableID );

                                if( rc == RC_CARRIER_NOT_TRANSFERING )
                                {
                                    PPT_METHODTRACE_V1("", "The Carrier is not transfering. Return error...");
                                    PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                         MSG_INVALID_CAST_XFERSTAT,
                                                         RC_INVALID_CAST_XFERSTAT,
                                                         transferState,
                                                         strInParm.strStartDurables[durableCnt].durableID.identifier );
                                    return RC_INVALID_CAST_XFERSTAT;
                                }
                                else if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "cassette_transferJobRecord_GetDR() != RC_OK", rc);
                                    strDurable_CheckConditionForOperation_out.strResult = strCassette_transferJobRecord_GetDR_out.strResult;
                                    return rc;
                                }

                                objStocker_type_GetDR_out  strStocker_type_GetDR_out;
                                rc = stocker_type_GetDR( strStocker_type_GetDR_out,
                                                         strObjCommonIn,
                                                         strCassette_transferJobRecord_GetDR_out.strCarrierJobResult.toMachine );

                                if( rc == RC_UNDEFINED_STOCKER_TYPE )
                                {
                                    PPT_METHODTRACE_V1("", "The cassette destination is not stocker . Return error...");
                                    PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                         MSG_INVALID_CAST_XFERSTAT,
                                                         RC_INVALID_CAST_XFERSTAT,
                                                         transferState,
                                                         strInParm.strStartDurables[durableCnt].durableID.identifier );
                                    return RC_INVALID_CAST_XFERSTAT;
                                }
                                else if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "stocker_type_GetDR() != RC_OK", rc);
                                    strDurable_CheckConditionForOperation_out.strResult = strStocker_type_GetDR_out.strResult;
                                    return rc;
                                }
                            }
             // INN-R170003 else if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) && transferReserved == FALSE )
                            else if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut) && transferReserved == FALSE )// INN-R170003
                            {
                                PPT_METHODTRACE_V1("", "(transferState = SP_TransState_EquipmentIn) and (transferReserved == FALSE)")
                                PPT_METHODTRACE_V2("", "transferState = ", transferState);
                                /*-----------------------------------------------------------------------------------------------*/
                                /*   The following StartLotReserve isn't permitted in Transfer EQP to EQP of CassetteDelivery.   */
                                /*                                                                                               */
                                /*   -----------------------------                                                               */
                                /*   |         FromEQP           |                                                               */
                                /*   ----------------------------|                                                               */
                                /*   | OperationMode : Offline-2 |                                                               */
                                /*   | XferState     : EI        |                                                               */
                                /*   -----------------------------                                                               */
                                /*-----------------------------------------------------------------------------------------------*/
                                if ( 0 == CIMFWStrCmp(strOrgEqpPortStatus.accessMode, SP_Eqp_AccessMode_Auto)
                                  && 0 == CIMFWStrCmp(strOrgEqpPortStatus.onlineMode, SP_Eqp_OnlineMode_Offline) )
                                {
                                    PPT_METHODTRACE_V1("", "##### return RC_INVALID_CAST_XFERSTAT");
                                    PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                         MSG_INVALID_CAST_XFERSTAT,
                                                         RC_INVALID_CAST_XFERSTAT,
                                                         transferState,
                                                         strInParm.strStartDurables[durableCnt].durableID.identifier );
                                    return RC_INVALID_CAST_XFERSTAT;
                                }

                                /*-----------------------------------------------------------------------------------------------*/
                                /*   The following StartLotReserve isn't permitted in Transfer EQP to EQP of CassetteDelivery.   */
                                /*                                                                                               */
                                /*   ToEQP's OperationMode : ***-2                                                               */
                                /*-----------------------------------------------------------------------------------------------*/
                                if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto)
                                  && 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.dispatchMode, SP_Eqp_DispatchMode_Auto) )
                                {
                                    PPT_METHODTRACE_V1("", "accessMode == SP_Eqp_AccessMode_Auto && dispatchMode == SP_Eqp_DispatchMode_Auto");
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                                    PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                         MSG_INVALID_CAST_XFERSTAT,
                                                         RC_INVALID_CAST_XFERSTAT,
                                                         transferState,
                                                         strInParm.strStartDurables[durableCnt].durableID.identifier );
                                    return RC_INVALID_CAST_XFERSTAT;
                                }

                                /*---------------------------------------------------------*/
                                /*   Check orgEqp's EqpToEqpTransfer Flag is TRUE or Not   */
                                /*---------------------------------------------------------*/
                                CORBA::Boolean bEqpToEqpXFerFlag;
                                try
                                {
                                    bEqpToEqpXFerFlag = aOrgMachine->isEqpToEqpTransferFlagOn();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)

                                if ( TRUE == bEqpToEqpXFerFlag )
                                {
                                    PPT_METHODTRACE_V1("", "TRUE == bEqpToEqpXFerFlag");
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("", "return RC_INVALID_CAST_XFERSTAT");
                                    PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                         MSG_INVALID_CAST_XFERSTAT,
                                                         RC_INVALID_CAST_XFERSTAT,
                                                         transferState,
                                                         strInParm.strStartDurables[durableCnt].durableID.identifier );
                                    return RC_INVALID_CAST_XFERSTAT;
                                }
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "return RC_INVALID_CAST_XFERSTAT");
                                PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                     MSG_INVALID_CAST_XFERSTAT,
                                                     RC_INVALID_CAST_XFERSTAT,
                                                     transferState,
                                                     strInParm.strStartDurables[durableCnt].durableID.identifier );
                                return RC_INVALID_CAST_XFERSTAT;
                            }
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","No Process <for Ope Start>");
                    }

//DSN000101569 add start
                    if ( 0 == atoi( getenv( SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER ) ) )
                    {
                        PPT_METHODTRACE_V1("", "SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER == 0");
//DSN000101569 add end
                        /*--------------------------------*/
                        /*   Check Cassette is Empty      */
                        /*--------------------------------*/
                        CORBA::Boolean bEmpty;
                        try
                        {
                            bEmpty = aCassette->isEmpty();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isEmpty)

                        if ( FALSE == bEmpty )
                        {
                            PPT_METHODTRACE_V1("", "FALSE == bEmpty");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_CAST_NOT_EMPTY,
                                                RC_CAST_NOT_EMPTY,
                                                strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_CAST_NOT_EMPTY;
                        }
                    }  //DSN000101569

                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");
                        /*-----------------------------------------------------------------------*/
                        /*   Check Cassette's DurableControlJobID vs Eqp's DurableControlJobID   */
                        /*-----------------------------------------------------------------------*/
                        PosDurableControlJob_var aDurableControlJob;
                        try
                        {
                            aDurableControlJob = aCassette->getDurableControlJob();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableControlJob)

                        if ( TRUE == CORBA::is_nil(aDurableControlJob) )
                        {
                            PPT_METHODTRACE_V1("", "aDurableControlJob is nil");
                            SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                        MSG_DURABLECTRLJOBID_BLANK,
                                        RC_DURABLECTRLJOBID_BLANK );
                            return RC_DURABLECTRLJOBID_BLANK;
                        }

                        objectIdentifier durableCJID;
                        PPT_SET_OBJECT_IDENTIFIER( durableCJID,
                                                   aDurableControlJob,
                                                   strDurable_CheckConditionForOperation_out,
                                                   durable_CheckConditionForOperation,
                                                   PosDurableControlJob );

                        objEquipment_reservedDurableControlJobID_GetDR_out strEquipment_reservedDurableControlJobID_GetDR_out;
                        objEquipment_reservedDurableControlJobID_GetDR_in  strEquipment_reservedDurableControlJobID_GetDR_in;
                        strEquipment_reservedDurableControlJobID_GetDR_in.equipmentID = strInParm.equipmentID;
                        rc = equipment_reservedDurableControlJobID_GetDR( strEquipment_reservedDurableControlJobID_GetDR_out,
                                                                          strObjCommonIn,
                                                                          strEquipment_reservedDurableControlJobID_GetDR_in );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "equipment_reservedDurableControlJobID_GetDR() != RC_OK", rc);
                            strDurable_CheckConditionForOperation_out.strResult = strEquipment_reservedDurableControlJobID_GetDR_out.strResult;
                            return rc;
                        }

                        objectIdentifierSequence reservedDurableControlJobIDs = strEquipment_reservedDurableControlJobID_GetDR_out.reservedDurableControlJobIDs;

                        CORBA::Boolean durableCJFound = FALSE;
                        for ( CORBA::ULong reservedDurableCJCnt=0; reservedDurableCJCnt<reservedDurableControlJobIDs.length(); reservedDurableCJCnt++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to reservedDurableControlJobIDs.length()", reservedDurableCJCnt);
                            if ( 0 == CIMFWStrCmp(durableCJID.identifier, reservedDurableControlJobIDs[reservedDurableCJCnt].identifier) )
                            {
                                PPT_METHODTRACE_V1("", "durableCJFound = TRUE");
                                durableCJFound = TRUE;
                                break;
                            }
                        }

                        if ( FALSE == durableCJFound )
                        {
                            PPT_METHODTRACE_V1("", "FALSE == durableCJFound");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_DURABLE_EQP_DRBCTRLJOB_UNMATCH,
                                                RC_DURABLE_EQP_DRBCTRLJOB_UNMATCH,
                                                strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_DURABLE_EQP_DRBCTRLJOB_UNMATCH;
                        }
                    }
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
//DSN000096126 Add Start
                    try
                    {
                        aMachineSeq = aReticlePod->getQueuedMachines();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getQueuedMachines);
//DSN000096126 Add End

                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");
                        /*-------------------------------------------*/
                        /*   1. Check ReticleDispatchJob existence   */
                        /*-------------------------------------------*/
                        objectIdentifier dummyID;
                        objReticle_dispatchJob_CheckExistenceDR_out strReticle_dispatchJob_CheckExistenceDR_out;
                        rc = reticle_dispatchJob_CheckExistenceDR( strReticle_dispatchJob_CheckExistenceDR_out,
                                                                   strObjCommonIn,
                                                                   dummyID,    //reticleID
                                                                   strInParm.strStartDurables[durableCnt].durableID,    //reticlePodID
                                                                   dummyID );  //toEquipmentID
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "reticle_dispatchJob_CheckExistenceDR() != RC_OK", rc);
                            strDurable_CheckConditionForOperation_out.strResult = strReticle_dispatchJob_CheckExistenceDR_out.strResult;
                            return( rc );
                        }
                    }

                    /*---------------------------------------*/
                    /*   Get and Check DurableControlJobID   */
                    /*---------------------------------------*/
                    PosDurableControlJob_var aDurableControlJob;
                    try
                    {
                        aDurableControlJob = aReticlePod->getDurableControlJob();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableControlJob)

                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation");
                        if ( FALSE == CORBA::is_nil(aDurableControlJob) )
                        {
                            PPT_METHODTRACE_V1("", "aDurableControlJob is not nil");
                            SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                        MSG_DURABLECTRLJOBID_FILLED,
                                        RC_DURABLECTRLJOBID_FILLED );
                            return RC_DURABLECTRLJOBID_FILLED;
                        }
                    }

                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");
                        /*-------------------------------------------------------------------------*/
                        /*   Check ReticlePod's DurableControlJobID vs Eqp's DurableControlJobID   */
                        /*-------------------------------------------------------------------------*/
                        if ( TRUE == CORBA::is_nil(aDurableControlJob) )
                        {
                            PPT_METHODTRACE_V1("", "aDurableControlJob is nil");
                            SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                        MSG_DURABLECTRLJOBID_BLANK,
                                        RC_DURABLECTRLJOBID_BLANK );
                            return RC_DURABLECTRLJOBID_BLANK;
                        }

                        objectIdentifier durableCJID;
                        PPT_SET_OBJECT_IDENTIFIER( durableCJID,
                                                   aDurableControlJob,
                                                   strDurable_CheckConditionForOperation_out,
                                                   durable_CheckConditionForOperation,
                                                   PosDurableControlJob );

                        objEquipment_reservedDurableControlJobID_GetDR_out strEquipment_reservedDurableControlJobID_GetDR_out;
                        objEquipment_reservedDurableControlJobID_GetDR_in  strEquipment_reservedDurableControlJobID_GetDR_in;
                        strEquipment_reservedDurableControlJobID_GetDR_in.equipmentID = strInParm.equipmentID;
                        rc = equipment_reservedDurableControlJobID_GetDR( strEquipment_reservedDurableControlJobID_GetDR_out,
                                                                          strObjCommonIn,
                                                                          strEquipment_reservedDurableControlJobID_GetDR_in );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "equipment_reservedDurableControlJobID_GetDR() != RC_OK", rc);
                            strDurable_CheckConditionForOperation_out.strResult = strEquipment_reservedDurableControlJobID_GetDR_out.strResult;
                            return rc;
                        }

                        objectIdentifierSequence reservedDurableControlJobIDs = strEquipment_reservedDurableControlJobID_GetDR_out.reservedDurableControlJobIDs;

                        CORBA::Boolean durableCJFound = FALSE;
                        for ( CORBA::ULong reservedDurableCJCnt=0; reservedDurableCJCnt<reservedDurableControlJobIDs.length(); reservedDurableCJCnt++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to reservedDurableControlJobIDs.length()", reservedDurableCJCnt);
                            if ( 0 == CIMFWStrCmp(durableCJID.identifier, reservedDurableControlJobIDs[reservedDurableCJCnt].identifier) )
                            {
                                PPT_METHODTRACE_V1("", "durableCJFound = TRUE");
                                durableCJFound = TRUE;
                                break;
                            }
                        }

                        if ( FALSE == durableCJFound )
                        {
                            PPT_METHODTRACE_V1("", "FALSE == durableCJFound");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_DURABLE_EQP_DRBCTRLJOB_UNMATCH,
                                                RC_DURABLE_EQP_DRBCTRLJOB_UNMATCH,
                                                strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_DURABLE_EQP_DRBCTRLJOB_UNMATCH;
                        }
                    }

                    /*----------------------------------------*/
                    /*   Check ReticlePod's Transfer Status   */
                    /*----------------------------------------*/
                    CORBA::String_var transferStatus;
                    try
                    {
                        transferStatus = aReticlePod->getTransferStatus();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getTransferStatus)

                    /*===== for OpeStart =====*/
                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");

                        if ( 0 == CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) )
                        {
                            PPT_METHODTRACE_V1("", "transferStatus == SP_TransState_EquipmentIn");
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "return RC_INVALID_RETICLEPOD_XFER_STAT!!");
                            PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                 MSG_INVALID_RETICLEPOD_XFER_STAT,
                                                 RC_INVALID_RETICLEPOD_XFER_STAT,
                                                 strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                 transferStatus );
                            return RC_INVALID_RETICLEPOD_XFER_STAT;
                        }
                    }
                    /*===== for StartReservation =====*/
                    else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation");

                        if ( 0 == CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) )
                        {
                            PPT_METHODTRACE_V1("", "transferStatus == SP_TransState_EquipmentIn");

                            objEquipment_reticlePodPortInfo_GetDR_out strEquipment_reticlePodPortInfo_GetDR_out;
                            rc = equipment_reticlePodPortInfo_GetDR( strEquipment_reticlePodPortInfo_GetDR_out,
                                                                     strObjCommonIn,
                                                                     strInParm.equipmentID );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "equipment_reticlePodPortInfo_GetDR() != RC_OK", rc);
                                strDurable_CheckConditionForOperation_out.strResult = strEquipment_reticlePodPortInfo_GetDR_out.strResult;
                                return rc;
                            }

                            // ReticlePod is loaded by specified port
                            CORBA::ULong rppLen = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length();
                            for ( CORBA::ULong rtclPodPortCnt=0; rtclPodPortCnt < rppLen; rtclPodPortCnt++ )
                            {
                                PPT_METHODTRACE_V2("", "loop to strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length()", rtclPodPortCnt);
                                if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[rtclPodPortCnt].reticlePodPortID.identifier,
                                                      strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "Reticle Pod Port found.");
                                    if ( 0 != CIMFWStrCmp(strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                          strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[rtclPodPortCnt].loadedReticlePodID.identifier) )
                                    {
                                        PPT_METHODTRACE_V1("", "Input reticle pod is different from current loaded reticle pod on equipment/port");
                                        PPT_SET_MSG_RC_KEY4( strDurable_CheckConditionForOperation_out,
                                                             MSG_RTCLPOD_LOADED_RTCLPOD,
                                                             RC_RTCLPOD_LOADED_RTCLPOD,
                                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                             strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[rtclPodPortCnt].loadedReticlePodID.identifier,
                                                             strInParm.equipmentID.identifier,
                                                             strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[rtclPodPortCnt].reticlePodPortID.identifier);
                                        return RC_RTCLPOD_LOADED_RTCLPOD;
                                    }
                                }
                            }
                        }
                    }

//DSN000101569 add start
                    if ( 0 == atoi( getenv( SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD ) ) )
                    {
                        PPT_METHODTRACE_V1("", "SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD == 0");
//DSN000101569 add end
                        /*----------------------------------*/
                        /*   Check reticlePod is Empty      */
                        /*----------------------------------*/
                        CORBA::Boolean bEmpty;
                        try
                        {
                            bEmpty = aReticlePod->isEmpty();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isEmpty)

                        if ( FALSE == bEmpty )
                        {
                            PPT_METHODTRACE_V1("", "FALSE == bEmpty");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_RTCLPOD_NOT_EMPTY,
                                                RC_RTCLPOD_NOT_EMPTY,
                                                strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_RTCLPOD_NOT_EMPTY;
                        }
                    }  //DSN000101569
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
//DSN000096126 Add Start
                    try
                    {
                        aMachineSeq = aReticle->getQueuedMachines();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getQueuedMachines);
//DSN000096126 Add End

                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");
                        
                        /*-------------------------------------------*/
                        /*   1. Check ReticleDispatchJob existence   */
                        /*-------------------------------------------*/
                        objectIdentifier dummyID;
                        objReticle_dispatchJob_CheckExistenceDR_out strReticle_dispatchJob_CheckExistenceDR_out;
                        rc = reticle_dispatchJob_CheckExistenceDR( strReticle_dispatchJob_CheckExistenceDR_out,
                                                                   strObjCommonIn,
                                                                   strInParm.strStartDurables[durableCnt].durableID,    //reticleID
                                                                   dummyID,    //reticlePodID
                                                                   dummyID );  //toEquipmentID
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "reticle_dispatchJob_CheckExistenceDR() != RC_OK", rc);
                            strDurable_CheckConditionForOperation_out.strResult = strReticle_dispatchJob_CheckExistenceDR_out.strResult;
                            return( rc );
                        }
                    }

                    /*---------------------------------------*/
                    /*   Get and Check DurableControlJobID   */
                    /*---------------------------------------*/
                    PosDurableControlJob_var aDurableControlJob;
                    try
                    {
                        aDurableControlJob = aReticle->getDurableControlJob();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableControlJob)

                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation");
                        if ( FALSE == CORBA::is_nil(aDurableControlJob) )
                        {
                            PPT_METHODTRACE_V1("", "aDurableControlJob is not nil");
                            SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                        MSG_DURABLECTRLJOBID_FILLED,
                                        RC_DURABLECTRLJOBID_FILLED );
                            return RC_DURABLECTRLJOBID_FILLED;
                        }
                    }

                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");
                        /*----------------------------------------------------------------------*/
                        /*   Check Reticle's DurableControlJobID vs Eqp's DurableControlJobID   */
                        /*----------------------------------------------------------------------*/
                        if ( TRUE == CORBA::is_nil(aDurableControlJob) )
                        {
                            PPT_METHODTRACE_V1("", "aDurableControlJob is nil");
                            SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                        MSG_DURABLECTRLJOBID_BLANK,
                                        RC_DURABLECTRLJOBID_BLANK );
                            return RC_DURABLECTRLJOBID_BLANK;
                        }

                        objectIdentifier durableCJID;
                        PPT_SET_OBJECT_IDENTIFIER( durableCJID,
                                                   aDurableControlJob,
                                                   strDurable_CheckConditionForOperation_out,
                                                   durable_CheckConditionForOperation,
                                                   PosDurableControlJob );

                        objEquipment_reservedDurableControlJobID_GetDR_out strEquipment_reservedDurableControlJobID_GetDR_out;
                        objEquipment_reservedDurableControlJobID_GetDR_in  strEquipment_reservedDurableControlJobID_GetDR_in;
                        strEquipment_reservedDurableControlJobID_GetDR_in.equipmentID = strInParm.equipmentID;
                        rc = equipment_reservedDurableControlJobID_GetDR( strEquipment_reservedDurableControlJobID_GetDR_out,
                                                                          strObjCommonIn,
                                                                          strEquipment_reservedDurableControlJobID_GetDR_in );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "equipment_reservedDurableControlJobID_GetDR() != RC_OK", rc);
                            strDurable_CheckConditionForOperation_out.strResult = strEquipment_reservedDurableControlJobID_GetDR_out.strResult;
                            return rc;
                        }

                        objectIdentifierSequence reservedDurableControlJobIDs = strEquipment_reservedDurableControlJobID_GetDR_out.reservedDurableControlJobIDs;

                        CORBA::Boolean durableCJFound = FALSE;
                        for ( CORBA::ULong reservedDurableCJCnt=0; reservedDurableCJCnt<reservedDurableControlJobIDs.length(); reservedDurableCJCnt++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to reservedDurableControlJobIDs.length()", reservedDurableCJCnt);
                            if ( 0 == CIMFWStrCmp(durableCJID.identifier, reservedDurableControlJobIDs[reservedDurableCJCnt].identifier) )
                            {
                                PPT_METHODTRACE_V1("", "durableCJFound = TRUE");
                                durableCJFound = TRUE;
                                break;
                            }
                        }

                        if ( FALSE == durableCJFound )
                        {
                            PPT_METHODTRACE_V1("", "FALSE == durableCJFound");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_DURABLE_EQP_DRBCTRLJOB_UNMATCH,
                                                RC_DURABLE_EQP_DRBCTRLJOB_UNMATCH,
                                                strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_DURABLE_EQP_DRBCTRLJOB_UNMATCH;
                        }
                    }

                    /*----------------------------------------*/
                    /*   Check Reticle's Transfer Status      */
                    /*----------------------------------------*/
                    CORBA::String_var transferStatus;
                    try
                    {
                        transferStatus = aReticle->getTransportState();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getTransportState)

                    /*===== for OpeStart =====*/
                    if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStart");

                        if ( 0 == CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) )
                        {
                            PPT_METHODTRACE_V1("", "transferStatus == SP_TransState_EquipmentIn");
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "return RC_INVALID_RETICLE_XFER_STAT!!");
                            PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                 MSG_INVALID_RETICLE_XFER_STAT,
                                                 RC_INVALID_RETICLE_XFER_STAT,
                                                 strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                 transferStatus );
                            return RC_INVALID_RETICLE_XFER_STAT;
                        }
                    }
                    /*===== for StartReservation =====*/
                    else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation) )
                    {
                        PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation");

                        if ( 0 == CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) )
                        {
                            PPT_METHODTRACE_V1("", "transferStatus == SP_TransState_EquipmentIn");

                            objEquipment_storedReticle_GetDR_out strEquipment_storedReticle_GetDR_out;
                            rc = equipment_storedReticle_GetDR( strEquipment_storedReticle_GetDR_out,
                                                                strObjCommonIn,
                                                                strInParm.equipmentID );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "equipment_storedReticle_GetDR() != RC_OK", rc);
                                strDurable_CheckConditionForOperation_out.strResult = strEquipment_storedReticle_GetDR_out.strResult;
                                return rc;
                            }

                            // Reticle is in the specified equipment
                            CORBA::Boolean bReticleFoundInEqp = FALSE;
                            CORBA::ULong srLen = strEquipment_storedReticle_GetDR_out.strStoredReticles.length();
                            for ( CORBA::ULong srCnt=0; srCnt < srLen; srCnt++ )
                            {
                                PPT_METHODTRACE_V2("", "loop to strEquipment_storedReticle_GetDR_out.strStoredReticles.length()", srCnt);
                                if ( 0 == CIMFWStrCmp(strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                      strEquipment_storedReticle_GetDR_out.strStoredReticles[srCnt].reticleID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "bReticleFoundInEqp = TRUE");
                                    bReticleFoundInEqp = TRUE;
                                    break;
                                }
                            }

                            if ( bReticleFoundInEqp == FALSE )
                            {
                                PPT_METHODTRACE_V1("", "bReticleFoundInEqp == FALSE");
                                PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                    MSG_RETICLE_NOT_IN_THE_EQP,
                                                    RC_RETICLE_NOT_IN_THE_EQP,
                                                    strInParm.strStartDurables[durableCnt].durableID.identifier );
                                return RC_RETICLE_NOT_IN_THE_EQP;
                            }
                        }
                    }
                }
//DSN000096126 Add Start
                objDurable_inventoryState_Get_out strDurable_inventoryState_Get_out;
                objDurable_inventoryState_Get_in  strDurable_inventoryState_Get_in;
                strDurable_inventoryState_Get_in.durableCategory = strInParm.durableCategory;
                strDurable_inventoryState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                rc = durable_inventoryState_Get(strDurable_inventoryState_Get_out, strObjCommonIn, strDurable_inventoryState_Get_in);

                if(0 == CIMFWStrCmp(strDurable_inventoryState_Get_out.durableInventoryState, SP_Durable_InventoryState_InBank))
                {
                    PPT_METHODTRACE_V1("","#### durableInventoryState == [InBank]");
                    PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                         MSG_INVALID_DURABLE_INVENTORYSTAT, RC_INVALID_DURABLE_INVENTORYSTAT,
                                         strInParm.strStartDurables[durableCnt].durableID.identifier,
                                         strDurable_inventoryState_Get_out.durableInventoryState );
                    return(RC_INVALID_DURABLE_INVENTORYSTAT);
                }

                objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
                objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
                strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
                strDurable_OnRoute_Check_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);

                if( rc == RC_DURABLE_ONROUTE )
                {
                    PPT_METHODTRACE_V1("","##### durable is on route");
                    objDurable_holdState_Get_out strDurable_holdState_Get_out;
                    objDurable_holdState_Get_in  strDurable_holdState_Get_in;
                    strDurable_holdState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_holdState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_holdState_Get(strDurable_holdState_Get_out, strObjCommonIn, strDurable_holdState_Get_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "durable_holdState_Get() returned error.");
                        strDurable_CheckConditionForOperation_out.strResult = strDurable_holdState_Get_out.strResult ;
                        return(rc);
                    }

                    if(0 != CIMFWStrCmp(strDurable_holdState_Get_out.durableHoldState, SP_Durable_HoldState_NotOnHold))
                    {
                        PPT_METHODTRACE_V1("","##### durableHoldState != [NotOnHold]");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_DURABLE_HOLDSTAT, RC_INVALID_DURABLE_HOLDSTAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier, strDurable_holdState_Get_out.durableHoldState );
                        return(RC_INVALID_DURABLE_HOLDSTAT);
                    }

                    objDurable_processState_Get_out strDurable_processState_Get_out;
                    objDurable_processState_Get_in  strDurable_processState_Get_in;
                    strDurable_processState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_processState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_processState_Get(strDurable_processState_Get_out, strObjCommonIn, strDurable_processState_Get_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "durable_processState_Get() returned error.");
                        strDurable_CheckConditionForOperation_out.strResult = strDurable_processState_Get_out.strResult;
                        return( rc );
                    }

                    if(0 != CIMFWStrCmp(strDurable_processState_Get_out.durableProcessState, SP_Durable_ProcState_Waiting))
                    {
                        PPT_METHODTRACE_V1("","##### durableProcessState != [Waiting]");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_DURABLE_PROCSTAT, RC_INVALID_DURABLE_PROCSTAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             strDurable_processState_Get_out.durableProcessState );
                        return(RC_INVALID_DURABLE_PROCSTAT);
                    }

                    CORBA::Boolean matchFlag = FALSE;
                    CORBA::Long machineLen = aMachineSeq->length();
                    for(CORBA::Long machineSeq=0; machineSeq<machineLen; machineSeq++)
                    {
                        PPT_METHODTRACE_V3("","loop to aMachineSeq->length()", machineLen, machineSeq);
                        objectIdentifier qEquipmentID;
                        PPT_SET_OBJECT_IDENTIFIER( qEquipmentID, (*aMachineSeq)[machineSeq], 
                                                   strDurable_CheckConditionForOperation_out, 
                                                   durable_CheckConditionForOperation, 
                                                   PosMachine );
                        if(CIMFWStrCmp(qEquipmentID.identifier, strInParm.equipmentID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","qEquipmentID == equipmentID");
                            matchFlag = TRUE;
                            break;
                        }
                    }

                    if(matchFlag == FALSE)
                    {
                        PPT_METHODTRACE_V1("","matchFlag == FALSE");
                        SET_MSG_RC(strDurable_CheckConditionForOperation_out, MSG_NOT_CORRECT_EQP_FOR_OPESTART_FOR_DURABLE, RC_NOT_CORRECT_EQP_FOR_OPESTART_FOR_DURABLE);
                        return(RC_NOT_CORRECT_EQP_FOR_OPESTART_FOR_DURABLE);
                    }

                    objDurable_CheckEndBankIn_out strDurable_CheckEndBankIn_out;
                    objDurable_CheckEndBankIn_in  strDurable_CheckEndBankIn_in;
                    strDurable_CheckEndBankIn_in.durableCategory = strInParm.durableCategory;
                    strDurable_CheckEndBankIn_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_CheckEndBankIn(strDurable_CheckEndBankIn_out, strObjCommonIn, strDurable_CheckEndBankIn_in);
                    if(rc == RC_BANKIN_OPERATION)
                    {
                        PPT_METHODTRACE_V1("","#### CheckEndBankIn == [BankInOperation]");
                        SET_MSG_RC(strDurable_CheckConditionForOperation_out, MSG_BANKIN_OPERATION, RC_BANKIN_OPERATION);
                        return(RC_BANKIN_OPERATION);
                    }

                    //-----------------------//
                    //   Check Route/OpeNo   //
                    //-----------------------//
                    PPT_METHODTRACE_V1("", "Check Route/OpeNo..." );
                    PPT_METHODTRACE_V2("", "routeID", strInParm.strStartDurables[durableCnt].strStartOperationInfo.routeID.identifier );
                    PPT_METHODTRACE_V2("", "operationNumber", strInParm.strStartDurables[durableCnt].strStartOperationInfo.operationNumber );

                    if ( 0 < CIMFWStrLen(strInParm.strStartDurables[durableCnt].strStartOperationInfo.routeID.identifier) &&
                         0 < CIMFWStrLen(strInParm.strStartDurables[durableCnt].strStartOperationInfo.operationNumber) )
                    {
                        objDurable_currentOperationInfo_Get_out strDurable_currentOperationInfo_Get_out;
                        objDurable_currentOperationInfo_Get_in  strDurable_currentOperationInfo_Get_in;
                        strDurable_currentOperationInfo_Get_in.durableCategory = strInParm.durableCategory;
                        strDurable_currentOperationInfo_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                        rc = durable_currentOperationInfo_Get(strDurable_currentOperationInfo_Get_out, strObjCommonIn, strDurable_currentOperationInfo_Get_in);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "durable_currentOperationInfo_Get() != RC_OK");
                            strDurable_CheckConditionForOperation_out.strResult = strDurable_currentOperationInfo_Get_out.strResult;
                            return( rc );
                        }
                        PPT_METHODTRACE_V2("", "Current RouteID", strDurable_currentOperationInfo_Get_out.routeID.identifier );
                        PPT_METHODTRACE_V2("", "Current OperationNumber", strDurable_currentOperationInfo_Get_out.operationNumber );

                        if ( 0 == CIMFWStrCmp(strInParm.strStartDurables[durableCnt].strStartOperationInfo.routeID.identifier, strDurable_currentOperationInfo_Get_out.routeID.identifier)
                          && 0 == CIMFWStrCmp(strInParm.strStartDurables[durableCnt].strStartOperationInfo.operationNumber   , strDurable_currentOperationInfo_Get_out.operationNumber) )
                        {
                            PPT_METHODTRACE_V1("", "Route/Operation check OK. Go ahead...");
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "Route/Operation check NG.");
                            SET_MSG_RC(strDurable_CheckConditionForOperation_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
                            return( RC_INVALID_INPUT_PARM );
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "Route/Operation check skipped. Go ahead...");
                    }

                }
//DSN000096126 Add End                
            }
//DSN000096126            else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OperationComp)
//DSN000096126                   || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStartCancel) )
            else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStartCancel) ) //DSN000096126
            {
//DSN000096126                PPT_METHODTRACE_V1("", "operation == SP_Operation_OperationComp || SP_Operation_OpeStartCancel");
                PPT_METHODTRACE_V1("", "operation == SP_Operation_OpeStartCancel"); //DSN000096126

                if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
                    objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
                    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                                strObjCommonIn,
                                                                strInParm.equipmentID,
                                                                strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "objPortResource_currentOperationMode_Get_out() != RC_OK" ,rc);
                        strDurable_CheckConditionForOperation_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
                        return rc;
                    }

                    if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto) )
                    {
                        PPT_METHODTRACE_V1("", ".strOperationMode.accessMode == SP_Eqp_AccessMode_Auto");
                        CORBA::String_var transferState;
                        try
                        {
                            transferState = aCassette->getTransportState();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

                        if ( 0 != CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                        {
                            PPT_METHODTRACE_V1("", "transferState != SP_TransState_EquipmentIn");
                            PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_INVALID_CAST_XFERSTAT;
                        }
                    }
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
                    objReticlePodPortResource_currentAccessMode_Get_out strReticlePodPortResource_currentAccessMode_Get_out;
                    objReticlePodPortResource_currentAccessMode_Get_in  strReticlePodPortResource_currentAccessMode_Get_in;
                    strReticlePodPortResource_currentAccessMode_Get_in.equipmentID      = strInParm.equipmentID;
                    strReticlePodPortResource_currentAccessMode_Get_in.reticlePodPortID = strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID;
                    rc = reticlePodPortResource_currentAccessMode_Get( strReticlePodPortResource_currentAccessMode_Get_out,
                                                                       strObjCommonIn,
                                                                       strReticlePodPortResource_currentAccessMode_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "reticlePodPortResource_currentAccessMode_Get() != RC_OK" ,rc);
                        strDurable_CheckConditionForOperation_out.strResult = strReticlePodPortResource_currentAccessMode_Get_out.strResult;
                        return rc;
                    }

                    if ( 0 == CIMFWStrCmp(strReticlePodPortResource_currentAccessMode_Get_out.accessMode, SP_Eqp_AccessMode_Auto) )
                    {
                        PPT_METHODTRACE_V1("", ".accessMode == SP_Eqp_AccessMode_Auto");
                        CORBA::String_var transferStatus;
                        try
                        {
                            transferStatus = aReticlePod->getTransferStatus();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getTransferStatus)

                        if ( 0 != CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) )
                        {
                            PPT_METHODTRACE_V1("", "transferStatus != SP_TransState_EquipmentIn");
                            PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                                 MSG_INVALID_RETICLEPOD_XFER_STAT,
                                                 RC_INVALID_RETICLEPOD_XFER_STAT,
                                                 strInParm.strStartDurables[durableCnt].durableID.identifier,
                                                 transferStatus );
                            return RC_INVALID_RETICLEPOD_XFER_STAT;
                        }
                    }
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
                    CORBA::String_var transferStatus;
                    try
                    {
                        transferStatus = aReticle->getTransportState();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getTransportState)

                    if ( 0 != CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) )
                    {
                        PPT_METHODTRACE_V1("", "transferStatus != SP_TransState_EquipmentIn");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_RETICLE_XFER_STAT,
                                             RC_INVALID_RETICLE_XFER_STAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             transferStatus );
                        return RC_INVALID_RETICLE_XFER_STAT;
                    }
                }

//DSN000096126 Add Start
                objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
                objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
                strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
                strDurable_OnRoute_Check_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);

                if( rc == RC_DURABLE_ONROUTE )
                {
                    PPT_METHODTRACE_V1("", "##### durable is on route");
                    objDurable_holdState_Get_out strDurable_holdState_Get_out;
                    objDurable_holdState_Get_in  strDurable_holdState_Get_in;
                    strDurable_holdState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_holdState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_holdState_Get(strDurable_holdState_Get_out, strObjCommonIn, strDurable_holdState_Get_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "durable_holdState_Get() returned error.");
                        strDurable_CheckConditionForOperation_out.strResult = strDurable_holdState_Get_out.strResult ;
                        return(rc);
                    }

                    if(0 != CIMFWStrCmp(strDurable_holdState_Get_out.durableHoldState, SP_Durable_HoldState_NotOnHold))
                    {
                        PPT_METHODTRACE_V1("","##### durableHoldState != [NotOnHold]");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_DURABLE_HOLDSTAT, RC_INVALID_DURABLE_HOLDSTAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier, strDurable_holdState_Get_out.durableHoldState );
                        return(RC_INVALID_DURABLE_HOLDSTAT);
                    }

                    objDurable_processState_Get_out strDurable_processState_Get_out;
                    objDurable_processState_Get_in  strDurable_processState_Get_in;
                    strDurable_processState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_processState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_processState_Get(strDurable_processState_Get_out, strObjCommonIn, strDurable_processState_Get_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "durable_processState_Get() returned error.");
                        strDurable_CheckConditionForOperation_out.strResult = strDurable_processState_Get_out.strResult;
                        return( rc );
                    }

                    if(0 != CIMFWStrCmp(strDurable_processState_Get_out.durableProcessState, SP_Durable_ProcState_Processing))
                    {
                        PPT_METHODTRACE_V1("","##### durableProcessState != [Processing]");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_DURABLE_PROCSTAT, RC_INVALID_DURABLE_PROCSTAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             strDurable_processState_Get_out.durableProcessState );
                        return(RC_INVALID_DURABLE_PROCSTAT);
                    }
                }
//DSN000096126 Add End
            }
//DSN000096126 Add Start
            else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OperationComp) )
            {
                PPT_METHODTRACE_V1("", "operation == SP_Operation_OperationComp");

                CORBA::String_var transferStatus = CIMFWStrDup("");
                CORBA::String_var accessMode     = CIMFWStrDup("");
                CORBA::String_var onlineMode     = CIMFWStrDup("");
                if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
                    objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
                    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                                strObjCommonIn,
                                                                strInParm.equipmentID,
                                                                strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "objPortResource_currentOperationMode_Get_out() != RC_OK" ,rc);
                        strDurable_CheckConditionForOperation_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
                        return rc;
                    }

                    accessMode = strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode;
                    onlineMode = strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode;

                    try
                    {
                        transferStatus = aCassette->getTransportState();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)
                }
                else
                {
                    PPT_METHODTRACE_V1("", "operation != SP_Operation_OperationComp");

                    /*-----------------------------------------*/
                    /*   Get Equipment's Operation Mode Info   */
                    /*-----------------------------------------*/
                    objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
                    rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out,
                                                   strObjCommonIn,
                                                   strInParm.equipmentID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
                        strDurable_CheckConditionForOperation_out.strResult = strEquipment_onlineMode_Get_out.strResult;
                        return rc;
                    }

                    onlineMode = strEquipment_onlineMode_Get_out.onlineMode;

                    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
                    {
                        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
                        objReticlePodPortResource_currentAccessMode_Get_out strReticlePodPortResource_currentAccessMode_Get_out;
                        objReticlePodPortResource_currentAccessMode_Get_in  strReticlePodPortResource_currentAccessMode_Get_in;
                        strReticlePodPortResource_currentAccessMode_Get_in.equipmentID      = strInParm.equipmentID;
                        strReticlePodPortResource_currentAccessMode_Get_in.reticlePodPortID = strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID;
                        rc = reticlePodPortResource_currentAccessMode_Get( strReticlePodPortResource_currentAccessMode_Get_out,
                                                                           strObjCommonIn,
                                                                           strReticlePodPortResource_currentAccessMode_Get_in );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "reticlePodPortResource_currentAccessMode_Get() != RC_OK" ,rc);
                            strDurable_CheckConditionForOperation_out.strResult = strReticlePodPortResource_currentAccessMode_Get_out.strResult;
                            return rc;
                        }

                        accessMode = strReticlePodPortResource_currentAccessMode_Get_out.accessMode;

                        try
                        {
                            transferStatus = aReticlePod->getTransferStatus();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getTransferStatus)
                    }
                    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
                    {
                        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");

                        try
                        {
                            transferStatus = aReticle->getTransportState();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getTransportState)
                    }
                }

                if ( 0 == CIMFWStrCmp(onlineMode, SP_Eqp_OnlineMode_Offline) ||
                     0 == CIMFWStrCmp(accessMode, SP_Eqp_AccessMode_Auto) )
                {
                    PPT_METHODTRACE_V1("", "onlineMode == SP_Eqp_OnlineMode_Offline or accessMode == SP_Eqp_AccessMode_Auto");
                    if ( 0 != CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) )
                    {
                        PPT_METHODTRACE_V1("", "transferStatus != SP_TransState_EquipmentIn");
                        SET_MSG_RC(strDurable_CheckConditionForOperation_out, MSG_INVALID_TRANSSTATE, RC_INVALID_TRANSSTATE);
                        return RC_INVALID_TRANSSTATE;
                    }
                }

                if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
                    //-----------------------------------------------------------
                    // Check cassette interFabXferState
                    //-----------------------------------------------------------
                    objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
                    objCassette_interFabXferState_Get_in strCassette_interFabXferState_Get_in;
                    strCassette_interFabXferState_Get_in.cassetteID = strInParm.strStartDurables[durableCnt].durableID;

                    rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out,
                                                         strObjCommonIn,
                                                         strCassette_interFabXferState_Get_in );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cassette_interFabXferState_Get() != RC_OK", rc);
                        strDurable_CheckConditionForOperation_out.strResult = strCassette_interFabXferState_Get_out.strResult;
                        return rc;
                    }

                    if ( 0 == CIMFWStrCmp( strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) )
                    {
                         PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
                         PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                              MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                              RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                              strInParm.strStartDurables[durableCnt].durableID.identifier,
                                              strCassette_interFabXferState_Get_out.interFabXferState );
                         return RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ;
                    }
                }

                objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
                objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
                strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
                strDurable_OnRoute_Check_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
                if( rc == RC_DURABLE_ONROUTE )
                {
                    PPT_METHODTRACE_V1("", "durable is on route");
                    objDurable_holdState_Get_out strDurable_holdState_Get_out;
                    objDurable_holdState_Get_in  strDurable_holdState_Get_in;
                    strDurable_holdState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_holdState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_holdState_Get(strDurable_holdState_Get_out, strObjCommonIn, strDurable_holdState_Get_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "durable_holdState_Get() returned error.");
                        strDurable_CheckConditionForOperation_out.strResult = strDurable_holdState_Get_out.strResult ;
                        return(rc);
                    }

                    if(0 != CIMFWStrCmp(strDurable_holdState_Get_out.durableHoldState, SP_Durable_HoldState_NotOnHold))
                    {
                        PPT_METHODTRACE_V1("","##### durableHoldState != [NotOnHold]");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_DURABLE_HOLDSTAT, RC_INVALID_DURABLE_HOLDSTAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier, strDurable_holdState_Get_out.durableHoldState );
                        return(RC_INVALID_DURABLE_HOLDSTAT);
                    }

                    objDurable_processState_Get_out strDurable_processState_Get_out;
                    objDurable_processState_Get_in  strDurable_processState_Get_in;
                    strDurable_processState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_processState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_processState_Get(strDurable_processState_Get_out, strObjCommonIn, strDurable_processState_Get_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "durable_processState_Get() returned error.");
                        strDurable_CheckConditionForOperation_out.strResult = strDurable_processState_Get_out.strResult;
                        return( rc );
                    }

                    if(0 != CIMFWStrCmp(strDurable_processState_Get_out.durableProcessState, SP_Durable_ProcState_Processing))
                    {
                        PPT_METHODTRACE_V1("","##### durableProcessState != [Processing]");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_DURABLE_PROCSTAT, RC_INVALID_DURABLE_PROCSTAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             strDurable_processState_Get_out.durableProcessState );
                        return(RC_INVALID_DURABLE_PROCSTAT);
                    }
                }
            }
//DSN000096126 Add End
            else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservationCancel) )
            {
                PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservationCancel");
                if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
                    /*----------------------------------------------*/
                    /*   Get and Check Cassette's Dispatch Status   */
                    /*----------------------------------------------*/
                    CORBA::Boolean dispatchReserveFlag;
                    try
                    {
                        dispatchReserveFlag = aCassette->isDispatchReserved();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchReserved)

                    if ( dispatchReserveFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "dispatchReserveFlag == FALSE");
                        SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                    MSG_NOT_DISPATCH_RESVED_CST,
                                    RC_NOT_DISPATCH_RESVED_CST );
                        return RC_NOT_DISPATCH_RESVED_CST;
                    }
                }

//DSN000096126 Add Start
                objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
                objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
                strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
                strDurable_OnRoute_Check_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
                if( rc == RC_DURABLE_ONROUTE )
                {
                    PPT_METHODTRACE_V1("", "durable is on route");
                    objDurable_processState_Get_out strDurable_processState_Get_out;
                    objDurable_processState_Get_in  strDurable_processState_Get_in;
                    strDurable_processState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_processState_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
                    rc = durable_processState_Get(strDurable_processState_Get_out, strObjCommonIn, strDurable_processState_Get_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "durable_processState_Get() returned error.");
                        strDurable_CheckConditionForOperation_out.strResult = strDurable_processState_Get_out.strResult;
                        return( rc );
                    }

                    if(0 == CIMFWStrCmp(strDurable_processState_Get_out.durableProcessState, SP_Durable_ProcState_Processing))
                    {
                        PPT_METHODTRACE_V1("","##### durableProcessState == [Processing]");
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_DURABLE_PROCSTAT, RC_INVALID_DURABLE_PROCSTAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             strDurable_processState_Get_out.durableProcessState );
                        return(RC_INVALID_DURABLE_PROCSTAT);
                    }
                }
//DSN000096126 Add End
            }
            else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_Loading) )
            {
                PPT_METHODTRACE_V1("", "operation == SP_Operation_Loading");
                if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
                    /*-------------------------------*/
                    /*   Check SorterJob existence   */
                    /*-------------------------------*/
                    objectIdentifierSequence dummyIDs;
                    pptEquipmentLoadPortAttribute equipmentPortAttribute;
                    equipmentPortAttribute.strCassetteLoadPortSeq.length(1);
                    equipmentPortAttribute.strCassetteLoadPortSeq[0].portID     = strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID;
                    equipmentPortAttribute.strCassetteLoadPortSeq[0].cassetteID = strInParm.strStartDurables[durableCnt].durableID;
                    equipmentPortAttribute.equipmentID                          = strInParm.equipmentID;

                    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
                    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
                    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = equipmentPortAttribute;
                    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyIDs;
                    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyIDs;
                    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_LoadingLot);

                    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                                  strObjCommonIn,
                                                                  strWaferSorter_sorterJob_CheckForOperation_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" ,rc);
                        strDurable_CheckConditionForOperation_out.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
                        return rc;
                    }

                    /*--------------------------------------*/
                    /*   Check Cassette's Transfer Status   */
                    /*--------------------------------------*/

                    /*-----------------------*/
                    /*   Get TransferState   */
                    /*-----------------------*/
                    PPT_METHODTRACE_V1("", "Get TransferState");

                    CORBA::String_var transferState;
                    try
                    {
                        transferState = aCassette->getTransportState();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

                    if ( 0 == CIMFWStrCmp(transferState, SP_TransState_StationOut     )
                      || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualOut      )
       // INN-R170003 || 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut   )
                      // INN-R170003 add start
                      || 0 == CIMFWStrCmp(transferState, CS_TRANS_STATE_PORT_IN      )
                      || 0 == CIMFWStrCmp(transferState, CS_TRANS_STATE_PORT_OUT      )
                      // INN-R170003 add end
                      || 0 == CIMFWStrCmp(transferState, SP_TransState_IntermediateOut)
                      || 0 == CIMFWStrCmp(transferState, SP_TransState_ShelfOut       )
                      || 0 == CIMFWStrCmp(transferState, SP_TransState_AbnormalOut    )
                      || 0 == CIMFWStrCmp(transferState, SP_UNDEFINED_STATE           ) )
                    {
                        PPT_METHODTRACE_V2("", "transferState == ", transferState);
                        PPT_METHODTRACE_V2("", "transferState = ", transferState);
                    }
                    else
                    {
                        PPT_METHODTRACE_V2("", "transferState == ", transferState);
                        PPT_METHODTRACE_V2("", "transferState = ", transferState);
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier );
                        return RC_INVALID_CAST_XFERSTAT;
                    }

                    //-----------------------------------------------------------
                    // Check cassette interFabXferState
                    //-----------------------------------------------------------
                    objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
                    objCassette_interFabXferState_Get_in strCassette_interFabXferState_Get_in;
                    strCassette_interFabXferState_Get_in.cassetteID = strInParm.strStartDurables[durableCnt].durableID;

                    rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out,
                                                         strObjCommonIn,
                                                         strCassette_interFabXferState_Get_in );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cassette_interFabXferState_Get() != RC_OK", rc);
                        strDurable_CheckConditionForOperation_out.strResult = strCassette_interFabXferState_Get_out.strResult;
                        return rc;
                    }

                    if ( 0 == CIMFWStrCmp( strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) )
                    {
                         PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
                         PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                              MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                              RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                              strInParm.strStartDurables[durableCnt].durableID.identifier,
                                              strCassette_interFabXferState_Get_out.interFabXferState );
                         return RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ;
                    }

//DSN000101569 add start
                    if ( 0 == atoi( getenv( SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER ) ) )
                    {
                        PPT_METHODTRACE_V1("", "SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER == 0");
//DSN000101569 add end
                        /*--------------------------------*/
                        /*   Check Cassette is Empty      */
                        /*--------------------------------*/
                        CORBA::Boolean bEmpty;
                        try
                        {
                            bEmpty = aCassette->isEmpty();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isEmpty)

                        if ( FALSE == bEmpty )
                        {
                            PPT_METHODTRACE_V1("", "FALSE == bEmpty");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_CAST_NOT_EMPTY,
                                                RC_CAST_NOT_EMPTY,
                                                strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_CAST_NOT_EMPTY;
                        }
                    }  //DSN000101569
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
                    /*----------------------------------------*/
                    /*   Check ReticlePod's Transfer Status   */
                    /*----------------------------------------*/
                    CORBA::String_var transferStatus;
                    try
                    {
                        transferStatus = aReticlePod->getTransferStatus();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getTransferStatus)

                    if ( 0 == CIMFWStrCmp(transferStatus, SP_TransState_StationOut     )
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_ManualOut      )
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut   )
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_IntermediateOut)
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_ShelfOut       )
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_AbnormalOut    )
                      || 0 == CIMFWStrCmp(transferStatus, SP_UNDEFINED_STATE           ) )
                    {
                        PPT_METHODTRACE_V2("", "transferStatus == ", transferStatus);
                    }
                    else
                    {
                        PPT_METHODTRACE_V2("", "transferStatus == ", transferStatus);
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_RETICLEPOD_XFER_STAT,
                                             RC_INVALID_RETICLEPOD_XFER_STAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             transferStatus );
                        return RC_INVALID_RETICLEPOD_XFER_STAT;
                    }

//DSN000101569 add start
                    if ( 0 == atoi( getenv( SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD ) ) )
                    {
                        PPT_METHODTRACE_V1("", "SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD == 0");
//DSN000101569 add end
                        /*----------------------------------*/
                        /*   Check reticlePod is Empty      */
                        /*----------------------------------*/
                        CORBA::Boolean bEmpty;
                        try
                        {
                            bEmpty = aReticlePod->isEmpty();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isEmpty)

                        if ( FALSE == bEmpty )
                        {
                            PPT_METHODTRACE_V1("", "FALSE == bEmpty");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_RTCLPOD_NOT_EMPTY,
                                                RC_RTCLPOD_NOT_EMPTY,
                                                strInParm.strStartDurables[durableCnt].durableID.identifier );
                            return RC_RTCLPOD_NOT_EMPTY;
                        }
                    }  //DSN000101569
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
                    /*----------------------------------------*/
                    /*   Check Reticle's Transfer Status      */
                    /*----------------------------------------*/
                    CORBA::String_var transferStatus;
                    try
                    {
                        transferStatus = aReticle->getTransportState();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getTransportState)

                    if ( 0 == CIMFWStrCmp(transferStatus, SP_TransState_StationOut     )
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_ManualOut      )
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut   )
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_IntermediateOut)
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_ShelfOut       )
                      || 0 == CIMFWStrCmp(transferStatus, SP_TransState_AbnormalOut    )
                      || 0 == CIMFWStrCmp(transferStatus, SP_UNDEFINED_STATE           ) )
                    {
                        PPT_METHODTRACE_V2("", "transferStatus == ", transferStatus);
                    }
                    else
                    {
                        PPT_METHODTRACE_V2("", "transferStatus == ", transferStatus);
                        PPT_SET_MSG_RC_KEY2( strDurable_CheckConditionForOperation_out,
                                             MSG_INVALID_RETICLE_XFER_STAT,
                                             RC_INVALID_RETICLE_XFER_STAT,
                                             strInParm.strStartDurables[durableCnt].durableID.identifier,
                                             transferStatus );
                        return RC_INVALID_RETICLE_XFER_STAT;
                    }
                }
            }
            else if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_PFXDelete) )
            {
                PPT_METHODTRACE_V1("", "operation == SP_Operation_PFXDelete");
                if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
                    /*---------------------------------------*/
                    /*   Get and Check DurableControlJobID   */
                    /*---------------------------------------*/
                    PosDurableControlJob_var aDurableControlJob;
                    try
                    {
                        aDurableControlJob = aCassette->getDurableControlJob();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableControlJob)

                    if ( FALSE == CORBA::is_nil(aDurableControlJob) )
                    {
                        PPT_METHODTRACE_V1("", "aDurableControlJob is not nil");
                        SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                    MSG_DURABLECTRLJOBID_FILLED,
                                    RC_DURABLECTRLJOBID_FILLED );
                        return RC_DURABLECTRLJOBID_FILLED;
                    }
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
                    /*---------------------------------------*/
                    /*   Get and Check DurableControlJobID   */
                    /*---------------------------------------*/
                    PosDurableControlJob_var aDurableControlJob;
                    try
                    {
                        aDurableControlJob = aReticlePod->getDurableControlJob();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableControlJob)

                    if ( FALSE == CORBA::is_nil(aDurableControlJob) )
                    {
                        PPT_METHODTRACE_V1("", "aDurableControlJob is not nil");
                        SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                    MSG_DURABLECTRLJOBID_FILLED,
                                    RC_DURABLECTRLJOBID_FILLED );
                        return RC_DURABLECTRLJOBID_FILLED;
                    }
                }
                else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
                    /*---------------------------------------*/
                    /*   Get and Check DurableControlJobID   */
                    /*---------------------------------------*/
                    PosDurableControlJob_var aDurableControlJob;
                    try
                    {
                        aDurableControlJob = aReticle->getDurableControlJob();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableControlJob)

                    if ( FALSE == CORBA::is_nil(aDurableControlJob) )
                    {
                        PPT_METHODTRACE_V1("", "aDurableControlJob is not nil");
                        SET_MSG_RC( strDurable_CheckConditionForOperation_out,
                                    MSG_DURABLECTRLJOBID_FILLED,
                                    RC_DURABLECTRLJOBID_FILLED );
                        return RC_DURABLECTRLJOBID_FILLED;
                    }
                }

//DSN000096126 Add Start
                //---------------------------------------
                //  Get InPostProcessFlag of Cassette
                //---------------------------------------
                objDurable_inPostProcessFlag_Get_out strDurable_inPostProcessFlag_Get_out;
                objDurable_inPostProcessFlag_Get_in  strDurable_inPostProcessFlag_Get_in;
                strDurable_inPostProcessFlag_Get_in.durableCategory = strInParm.durableCategory;
                strDurable_inPostProcessFlag_Get_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;

                rc = durable_inPostProcessFlag_Get( strDurable_inPostProcessFlag_Get_out,
                                                    strObjCommonIn,
                                                    strDurable_inPostProcessFlag_Get_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Get() != RC_OK");
                    strDurable_CheckConditionForOperation_out.strResult = strDurable_inPostProcessFlag_Get_out.strResult;
                    return( rc );
                }

                if(strDurable_inPostProcessFlag_Get_out.isPostProcessFlagOn == TRUE)
                {
                    PPT_METHODTRACE_V1("", "NOT External Post Process User!");
                    PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out, 
                                        MSG_DURABLE_INPOSTPROCESS, 
                                        RC_DURABLE_INPOSTPROCESS,
                                        strInParm.strStartDurables[durableCnt].durableID.identifier );
                    return RC_DURABLE_INPOSTPROCESS;
                }
//DSN000096126 Add End
            }
        }

        /*-------------------------------------------------------*/
        /*   Check Upper/Lower Limit for RecipeParameterChange   */
        /*-------------------------------------------------------*/
        if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation)
          || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
        {
            PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation || SP_Operation_OpeStart");
            PosMachine_var aMachine;
            PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                             strInParm.equipmentID,
                                             strDurable_CheckConditionForOperation_out,
                                             durable_CheckConditionForOperation );

            PosRecipeParameterSequence_var aRecipeParameters;
            try
            {
                aRecipeParameters = aMachine->getRecipeParameters();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getRecipeParameters)

            for ( CORBA::ULong recipeParameterCnt=0; recipeParameterCnt<aRecipeParameters->length(); recipeParameterCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to aRecipeParameters->length()", recipeParameterCnt);
                if ( 0 == CIMFWStrCmp((*aRecipeParameters)[recipeParameterCnt].dataType, SP_DCDef_Val_String) )
                {
                    PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_String -----> continue !!");
                    continue;
                }

                CORBA::Boolean bRcpParamFound = FALSE;
                CORBA::ULong startRcpParamCnt=0;
                for ( startRcpParamCnt=0; startRcpParamCnt<strInParm.strDurableStartRecipe.strStartRecipeParameter.length(); startRcpParamCnt++ )
                {
                    PPT_METHODTRACE_V2("", "loop to strInParm.strDurableStartRecipe.strStartRecipeParameter.length()", startRcpParamCnt);
                    if ( 0 == CIMFWStrCmp(strInParm.strDurableStartRecipe.strStartRecipeParameter[startRcpParamCnt].parameterName,
                                          (*aRecipeParameters)[recipeParameterCnt].parameterName) )
                    {
                        PPT_METHODTRACE_V2("", "### found ###  Same Parameter Name!!", (*aRecipeParameters)[recipeParameterCnt].parameterName);
                        bRcpParamFound = TRUE;
                        break;
                    }
                }

                if ( TRUE == bRcpParamFound )
                {
                    PPT_METHODTRACE_V1("", "TRUE == bRcpParamFound");
                    if ( TRUE == (*aRecipeParameters)[recipeParameterCnt].useCurrentValueFlag )
                    {
                        PPT_METHODTRACE_V1("", "TRUE == (*aRecipeParameters)[recipeParameterCnt].useCurrentValueFlag");

                        if ( 0 < CIMFWStrLen(strInParm.strDurableStartRecipe.strStartRecipeParameter[startRcpParamCnt].parameterValue) )
                        {
                            PPT_METHODTRACE_V1("", "0 < CIMFWStrLen(parameterValue)");
                            PPT_SET_MSG_RC_KEY( strDurable_CheckConditionForOperation_out,
                                                MSG_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                RC_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                (*aRecipeParameters)[recipeParameterCnt].parameterName );
                            return RC_INVALID_PARAMETERVALUE_MUST_BE_NULL;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "parameterValue = NULL ---> <<<<< Check OK!! >>>>>");
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "FALSE == (*aRecipeParameters)[recipeParameterCnt].useCurrentValueFlag");

                        if ( 0 == CIMFWStrCmp((*aRecipeParameters)[recipeParameterCnt].dataType, SP_DCDef_Val_Integer) )
                        {
                            PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Integer");
                            CORBA::Boolean bIsLong = TRUE;
                            errno = 0;
                            char *endptr;
                            long nResult = strtol(strInParm.strDurableStartRecipe.strStartRecipeParameter[startRcpParamCnt].parameterValue, &endptr, 10);
                            PPT_METHODTRACE_V2("", "nResult", nResult);
                            if ( ERANGE == errno )
                            {
                                // overflow or underflow
                                PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                bIsLong = FALSE;
                            }
                            else if ( strlen(endptr) == 0 )
                            {
                                // The character which can be recognized as a numerical value
                                PPT_METHODTRACE_V1("", "bIsLong = TRUE");
                                bIsLong = TRUE;
                            }
                            else
                            {
                                // // The character which cannot be recognized as a numerical value
                                PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                bIsLong = FALSE;
                            }

                            CORBA::Long parameterValue, lowerLimit, upperLimit;

                            sscanf(strInParm.strDurableStartRecipe.strStartRecipeParameter[startRcpParamCnt].parameterValue, "%d", &parameterValue);
                            sscanf((*aRecipeParameters)[recipeParameterCnt].lowerLimit, "%d", &lowerLimit);
                            sscanf((*aRecipeParameters)[recipeParameterCnt].upperLimit, "%d", &upperLimit);

                            if ( !bIsLong || ((parameterValue < lowerLimit) || (parameterValue > upperLimit)) )
                            {
                                PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                PPT_SET_MSG_RC_KEY3( strDurable_CheckConditionForOperation_out,
                                                     MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                     RC_INVALID_PARAMETER_VALUE_RANGE,
                                                     (*aRecipeParameters)[recipeParameterCnt].parameterName,
                                                     (*aRecipeParameters)[recipeParameterCnt].lowerLimit,
                                                     (*aRecipeParameters)[recipeParameterCnt].upperLimit );
                                return RC_INVALID_PARAMETER_VALUE_RANGE;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                            }
                        }
                        else if ( 0 == CIMFWStrCmp( (*aRecipeParameters)[recipeParameterCnt].dataType, SP_DCDef_Val_Float) )
                        {
                            PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Float");
                            CORBA::Double parameterValue, lowerLimit, upperLimit;
                            sscanf(strInParm.strDurableStartRecipe.strStartRecipeParameter[startRcpParamCnt].parameterValue, "%lf", &parameterValue);
                            sscanf((*aRecipeParameters)[recipeParameterCnt].lowerLimit, "%lf", &lowerLimit);
                            sscanf((*aRecipeParameters)[recipeParameterCnt].upperLimit, "%lf", &upperLimit);
                            if ( (parameterValue < lowerLimit) || (parameterValue > upperLimit) )
                            {
                                PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                PPT_SET_MSG_RC_KEY3( strDurable_CheckConditionForOperation_out,
                                                     MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                     RC_INVALID_PARAMETER_VALUE_RANGE,
                                                     (*aRecipeParameters)[recipeParameterCnt].parameterName,
                                                     (*aRecipeParameters)[recipeParameterCnt].lowerLimit,
                                                     (*aRecipeParameters)[recipeParameterCnt].upperLimit );
                                return RC_INVALID_PARAMETER_VALUE_RANGE;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                            }
                        }
                    }
                }
            }
        }

        /*---------------------------------------------------------------------*/
        /*   Get and Check Entity Inhibition for OpeStart / StartReservation   */
        /*---------------------------------------------------------------------*/
        if ( 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_StartReservation)
          || 0 == CIMFWStrCmp(strInParm.operation, SP_Operation_OpeStart) )
        {
            PPT_METHODTRACE_V1("", "operation == SP_Operation_StartReservation || SP_Operation_OpeStart");
            CORBA::ULong nCnt1 = 0;
            CORBA::ULong nMax1 = SP_CAPACITY_INCREMENT_10;
            objectIdentifierSequence durableIDs;
            durableIDs.length(nMax1);
            for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
                PPT_METHODTRACE_V3("", "# now count and now max is", nCnt1, nMax1);
                if ( nCnt1 >= nMax1 )
                {
                    PPT_METHODTRACE_V1("", "nCnt1>=nMax1, increase the sequence by 10.");
                    nMax1 += SP_CAPACITY_INCREMENT_10;
                    durableIDs.length(nMax1);
                    PPT_METHODTRACE_V2("", "# nMax1", nMax1);
                }
                durableIDs[nCnt1] = strInParm.strStartDurables[durableCnt].durableID;
                nCnt1++;
            }
            durableIDs.length(nMax1);

            objEquipment_CheckInhibitForDurableWithMachineRecipe_out strEquipment_CheckInhibitForDurableWithMachineRecipe_out;
            objEquipment_CheckInhibitForDurableWithMachineRecipe_in  strEquipment_CheckInhibitForDurableWithMachineRecipe_in;
            strEquipment_CheckInhibitForDurableWithMachineRecipe_in.equipmentID           = strInParm.equipmentID;
            strEquipment_CheckInhibitForDurableWithMachineRecipe_in.durableIDs            = durableIDs;
            strEquipment_CheckInhibitForDurableWithMachineRecipe_in.durableCategory       = strInParm.durableCategory;
            strEquipment_CheckInhibitForDurableWithMachineRecipe_in.strDurableStartRecipe = strInParm.strDurableStartRecipe;
            rc = equipment_CheckInhibitForDurableWithMachineRecipe( strEquipment_CheckInhibitForDurableWithMachineRecipe_out,
                                                                    strObjCommonIn,
                                                                    strEquipment_CheckInhibitForDurableWithMachineRecipe_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_CheckInhibitForDurableWithMachineRecipe() != RC_OK" ,rc);
                strDurable_CheckConditionForOperation_out.strResult = strEquipment_CheckInhibitForDurableWithMachineRecipe_out.strResult;
                return rc;
            }
        }

        //--------------------//
        //  Return to Caller  //
        //--------------------//
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::durable_CheckConditionForOperation" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strDurable_CheckConditionForOperation_out, durable_CheckConditionForOperation, methodName );
}
