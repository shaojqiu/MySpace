#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_lot_CheckConditionForLoadingOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:00:55 [ 7/13/07 20:00:56 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: cs_lot_CheckConditionForLoadingOR.cpp
//

#include "cs_pptmgr.hpp"

#include "ppcope.hh"
#include "ppcopsp.hh"
#include "plot.hh"
#include "pmcrc.hh"                //PSN000043994


//Q3000040 extern char* makeInhibitListFromEntityInhibits(const PosEntityInhibitSequence* entityInhibits);

//[Object Function Name]: long   lot_CheckConditionForLoading
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-07-01  0.00      Y.Iwasaki      Initial release
// 2000-08-09  0.01      Y.Iwasaki      Add Bank-In operation check logic
// 2000-08-29  0.02      Y.Iwasaki      Remove controlJob check logic
// 2000/09/15  Q3000040  O.Sugiyama     add try catch for allEntityInhibitsForLot()
// 2000/09/15  Q3000040  Y.Iwasaki      Remove allEntityInhibitsForLot() logic
// 2000/11/10  P2200204  R.Furuta       Initialize local pointers
// 2001/03/15  P3100133  Y.Iwasaki      Bug fix for memory leak
// 2002/09/12  P4200169  K.Matsuei      Recipe Inhibit for DynamicRecipeChange does not work correctly.
// 2006/11/29  D8000024  H.Mutoh        Flexible Process Condition Change (R80)
// 2007/04/20  D9000001  H.Murakami     64bit support.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/31 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2012/11/06 PSN000043994 Sa Guo         Add check for recipe and chamber
// 2014/02/17 DSN000081739 Sa Guo         Equipment Monitor Automation Support
//
//
// Innotron Modification history :
// Date       Defect#        Person               Comments
// ---------- -------------- -------------------- -------------------------------------------
// 2017/10/03 INN-A170007    Sam Hsueh            Lot must be reserved before loading
//
//
//[Function Description]:
//  Check lot's condition for Loading.
//  The following conditions are checked for each specified operation.
//
//0.02 - controlJobID
//  - lot's equipmentID
//  - lot's current operation (must not last Bank-In operation)              //0.01
//  - lotHoldState
//  - lotProcessState
//  - lotInventoryState
//  - entityInhibition
//  - equipment's availability for specified lot
//
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  objectIdentifier            lotID;
//
//[Output Parameters]:
//  out objLot_CheckConditionForLoading_out   strLot_CheckConditionForLoading_out;
//
//  typedef struct objLot_CheckConditionForLoading_out_struct {
//      pptRetCode                  strResult;
//  } objLot_CheckConditionForLoading_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//  RC_DIFF_EQPMONJOB_EQPID     MSG_DIFF_EQPMONJOB_EQPID               DSN000081739
//  RC_INVALID_EQPMONJOBSTATUS  MSG_INVALID_EQPMONJOBSTATUS            DSN000081739
//  RC_MISMATCH_EQPMON_STARTSEQ MSG_MISMATCH_EQPMON_STARTSEQ           DSN000081739
//
//[Pseudo Code]:

CORBA::Long CS_PPTManager_i::lot_CheckConditionForLoading(
                            objLot_CheckConditionForLoading_out& strLot_CheckConditionForLoading_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const objectIdentifier& lotID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_CheckConditionForLoading");

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*------------------------------------------------------------------------------------*/
        /*                                                                                    */
//      /*   Check Condition for controlJobID, equipmentID, lotXxxxState, entityInhibition    */
        /*   Check Condition for equipmentID, lotXxxxState, entityInhibition                  */  //0.02

        /*                                                                                    */
        /*------------------------------------------------------------------------------------*/

        /*--------------------*/
        /*   Get Lot Object   */
        /*--------------------*/
        PPT_METHODTRACE_V2("","Get Lot Object", __LINE__);

        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                     lotID,
                                     strLot_CheckConditionForLoading_out,
                                     lot_CheckConditionForLoading );

//0.02        /*------------------------------*/
//0.02        /*   Get Lot's Countol Job ID   */
//0.02        /*------------------------------*/
//0.02        PosControlJob_var aControlJob;
//0.02        try
//0.02        {
//0.02            aControlJob = aLot->getControlJob();
//0.02        }
//0.02        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlJob)
//0.02
//0.02        if ( CORBA::is_nil(aControlJob) )
//0.02        {
//0.02            PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForLoading_out,
//0.02                                 MSG_LOT_CTLJOBID_FILLED,
//0.02                                 RC_NOT_CANDIDATE_LOT_FOR_OPE_START,
//0.02                                 lotID.identifier,
//0.02                                 "nil" );
//0.02
//0.02            return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
//0.02        }

        /*---------------------------*/
        /*   Check Start Equipment   */
        /*---------------------------*/
        PPT_METHODTRACE_V2("","Check Start Equipment", __LINE__);

        PosMachineSequence* aMachineSeq = NULL; //P2200204
        PosMachineSequence_var aMachineSeqVar;  //P3100133
        try
        {
            aMachineSeq = aLot->getQueuedMachines();
            aMachineSeqVar = aMachineSeq;       //P3100133
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQueuedMachines)

        CORBA::Boolean matchFlag = FALSE;
        CORBA::Long lenMachine = aMachineSeq->length();
        CORBA::Long k;

        for ( k=0; k < lenMachine; k++ )
        {
            objectIdentifier qEquipmentID;
            PPT_SET_OBJECT_IDENTIFIER( qEquipmentID,
                                       (*aMachineSeq)[k],
                                       strLot_CheckConditionForLoading_out,
                                       lot_CheckConditionForLoading,
                                       PosMachine );

            if ( 0 == CIMFWStrCmp(qEquipmentID.identifier, equipmentID.identifier) )
            {
                PPT_METHODTRACE_V1("","qEquipmentID == equipmentID");
                matchFlag = TRUE;
                break;
            }
        }

        if ( matchFlag == FALSE )
        {
            PPT_METHODTRACE_V1("","matchFlag == FALSE");
            SET_MSG_RC( strLot_CheckConditionForLoading_out,
                        MSG_NOT_CORRECT_EQP_FOR_OPESTART,
                        RC_NOT_CANDIDATE_LOT_FOR_OPE_START );

            return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
        }

//0.01 start
        /*--------------------------------------------------------*/
        /*   Check Current Operation is Bank-In Operation or Not  */
        /*--------------------------------------------------------*/
        PPT_METHODTRACE_V2("","Check Current Operation is Bank-In Operation or Not", __LINE__);

        CORBA::Boolean bankInFlag = FALSE;
        try
        {
            bankInFlag = aLot->isBankInRequired();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState)

        if ( bankInFlag == TRUE )
        {
            PPT_METHODTRACE_V1("","bankInFlag == TRUE");
            SET_MSG_RC( strLot_CheckConditionForLoading_out,
                        MSG_BANKIN_OPERATION,
                        RC_BANKIN_OPERATION );

           return RC_BANKIN_OPERATION;
        }
//0.01 end

        /*-------------------------------*/
        /*   Get and Check Lot's State   */
        /*-------------------------------*/
        PPT_METHODTRACE_V2("","Get and Check Lot's State", __LINE__);

        CORBA::String_var holdState;
        try
        {
            holdState = aLot->getLotHoldState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState)


        CORBA::String_var processState;
        try
        {
            processState = aLot->getLotProcessState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotProcessState)


        CORBA::String_var inventoryState;
        try
        {
            inventoryState = aLot->getLotInventoryState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInventoryState)


        if ( 0 != CIMFWStrCmp(holdState, CIMFW_Lot_HoldState_NotOnHold) )
        {
            PPT_METHODTRACE_V1("","holdState != CIMFW_Lot_HoldState_NotOnHold");
            PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForLoading_out,
                                 MSG_INVALID_LOT_HOLDSTAT,
                                 RC_NOT_CANDIDATE_LOT_FOR_OPE_START,
                                 lotID.identifier,
                                 holdState );

            return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
        }

        if ( 0 != CIMFWStrCmp(processState, SP_Lot_ProcState_Waiting) )
        {
            PPT_METHODTRACE_V1("","processState != SP_Lot_ProcState_Waiting");
            PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForLoading_out,
                                 MSG_INVALID_LOT_PROCSTAT,
                                 RC_NOT_CANDIDATE_LOT_FOR_OPE_START,
                                 lotID.identifier,
                                 processState );

            return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
        }

        if ( 0 != CIMFWStrCmp(inventoryState, SP_Lot_InventoryState_OnFloor) )
        {
            PPT_METHODTRACE_V1("","inventoryState != SP_Lot_InventoryState_OnFloor");
            PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForLoading_out,
                                 MSG_INVALID_LOT_INVENTORYSTAT,
                                 RC_NOT_CANDIDATE_LOT_FOR_OPE_START,
                                 lotID.identifier,
                                 inventoryState );

            return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
        }

        /*--------------------------------------------------*/
        /*   Get and Check Equipment Availability for Lot   */
        /*--------------------------------------------------*/
        PPT_METHODTRACE_V2("","Get and Check Equipment Availability for Lot", __LINE__);

        objectIdentifierSequence checkLotIDs(1);
        checkLotIDs.length(1);
        checkLotIDs[0] = lotID;

        objEquipment_CheckAvailForLot_out strEquipment_CheckAvailForLot_out;
        rc = equipment_CheckAvailForLot( strEquipment_CheckAvailForLot_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         checkLotIDs );

        if ( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_CheckAvailForLot=RC_OK")
            rc = RC_OK;
        }
        else if ( rc == RC_EQP_NOT_AVAILSTAT )
        {
            PPT_METHODTRACE_V1("", "rc == RC_EQP_NOT_AVAILSTAT");

            strLot_CheckConditionForLoading_out.strResult = strEquipment_CheckAvailForLot_out.strResult;

            SET_MSG_RC( strLot_CheckConditionForLoading_out,
                        MSG_EQP_NOT_AVAILSTAT,
                        RC_NOT_CANDIDATE_LOT_FOR_OPE_START );
        
            return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
        }
        else if ( rc == RC_EQP_NOT_AVAILSTAT_FOR_LOT )
        {
            PPT_METHODTRACE_V1("", "rc == RC_EQP_NOT_AVAILSTAT_FOR_LOT");

            strLot_CheckConditionForLoading_out.strResult = strEquipment_CheckAvailForLot_out.strResult;

            PPT_SET_MSG_RC_KEY( strLot_CheckConditionForLoading_out,
                                MSG_EQP_NOT_AVAILSTAT_FOR_LOT,
                                RC_NOT_CANDIDATE_LOT_FOR_OPE_START,
                                lotID.identifier );

            return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
        }
        else
        {
            PPT_METHODTRACE_V1("", "ELSE!!");

            strLot_CheckConditionForLoading_out.strResult = strEquipment_CheckAvailForLot_out.strResult;
            return rc;
        }

        /*---------------------------------------------------------------------*/
        /*   Get and Check Entity Inhibition for OpeStart / StartReservation   */
        /*---------------------------------------------------------------------*/
        PPT_METHODTRACE_V2("","Get and Check Entity Inhibition for OpeStart / StartReservation", __LINE__);

//P4200169 start
        objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
        rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, lotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### lot_controlJobID_Get != RC_OK", rc);
            strLot_CheckConditionForLoading_out.strResult = strLot_controlJobID_Get_out.strResult;
            return rc;
        }
        PPT_METHODTRACE_V2("", "controlJobID", strLot_controlJobID_Get_out.controlJobID.identifier);

        if ( 0 != CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) )
        {
            PPT_METHODTRACE_V1("", "call controlJob_startReserveInformation_Get()");
            objControlJob_startReserveInformation_Get_out strControlJob_startReserveInformation_Get_out;
            rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
                                                         strObjCommonIn,
                                                         strLot_controlJobID_Get_out.controlJobID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### controlJob_startReserveInformation_Get != RC_OK", rc);
                strLot_CheckConditionForLoading_out.strResult = strControlJob_startReserveInformation_Get_out.strResult;
                return rc;
            }
//PSN000043994 Add Start
            PosMachine_var aMachine;
            PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                             equipmentID,
                                             strLot_CheckConditionForLoading_out,
                                             lot_CheckConditionForLoading );
            CORBA::Long tmpChamberCheckPolicy = atoi( getenv(SP_CHAMBER_CHECK_POLICY) );

            pptStartCassetteSequence strStartCassette;
            strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;
            CORBA::ULong SCLength = strStartCassette.length();
            for( CORBA::ULong i=0; i < SCLength; i++ )
            {
                PPT_METHODTRACE_V3("", "loop to strStartCassette.length()", SCLength, i);

                CORBA::ULong LICLength = strStartCassette[i].strLotInCassette.length();
                for( CORBA::ULong j=0; j < LICLength; j++ )
                {
                    PPT_METHODTRACE_V3("", "loop to strStartCassette[i].strLotInCassette.length()", LICLength, j);

                    /*--------------------------*/
                    /*   Omit Not Process Lot   */
                    /*--------------------------*/
                    CORBA::Boolean bOperationStartFlag;
                    bOperationStartFlag = strStartCassette[i].strLotInCassette[j].operationStartFlag;
                    if ( FALSE == bOperationStartFlag )
                    {
                        PPT_METHODTRACE_V1("", "bOperationStartFlag == FALSE");
                        continue;
                    }

                    /*--------------------------------------------------------------*/
                    /*   Check if the recipe is available on Eqp.                   */
                    /*   This check is skipped when recipe is overwritten by FPC.   */
                    /*--------------------------------------------------------------*/
                    CORBA::Long tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );
                    CORBA::Boolean bFPCFlag = FALSE;
                    if( 1 == tmpFPCAdoptFlag )
                    {
                        PPT_METHODTRACE_V1("", "Use FPC Infomation.");
                        objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                        rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out,
                                                       strObjCommonIn,
                                                       SP_FPC_ExchangeType_StartReserveInfo,
                                                       equipmentID,
                                                       strStartCassette[i].strLotInCassette[j].lotID );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                            strLot_CheckConditionForLoading_out.strResult = strLot_effectiveFPCInfo_Get_out.strResult;
                            return rc;
                        }

                        if( TRUE == strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired");
                            bFPCFlag = TRUE;
                        }
                    }
                    if( FALSE == bFPCFlag )
                    {
                        PPT_METHODTRACE_V1("", "bFPCFlag == FALSE");
                        PosMachineRecipe_var aMachineRecipe;
                        PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR( aMachineRecipe,
                                                                  strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
                                                                  strLot_CheckConditionForLoading_out,
                                                                  lot_CheckConditionForLoading );
                        CORBA::Boolean bUsedFlag = FALSE;
                        try
                        {
                            bUsedFlag = aMachineRecipe->isUsedBy(aMachine);
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::isUsedBy);

                        if( FALSE == bUsedFlag )
                        {
                            PPT_METHODTRACE_V1("", "bUsedFlag == FALSE");
                            PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForLoading_out,
                                                 MSG_INVALID_RECIPE_FOR_EQP,
                                                 RC_INVALID_RECIPE_FOR_EQP,
                                                 strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier,
                                                 equipmentID.identifier );
                            return RC_INVALID_RECIPE_FOR_EQP;
                        }
                    }

                    /*------------------------------------------*/
                    /*   Check condition for recipe / chamber   */
                    /*------------------------------------------*/
                    if( 1 == tmpChamberCheckPolicy )
                    {
                        PPT_METHODTRACE_V1("", "Check condition for recipe/chamber.");
                        // Check chamber condition for logical recipe and recipe
                        //  - Chamber status
                        //  - Conditional available
                        objLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out;
                        objLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in  strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.lotID            = strStartCassette[i].strLotInCassette[j].lotID;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.equipmentID      = equipmentID;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.logicalRecipeID  = strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.machineRecipeID  = strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.inhibitCheckFlag = FALSE;
                        rc = logicalRecipe_candidateChamberInfo_GetByMachineRecipe( strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out,
                                                                                    strObjCommonIn,
                                                                                    strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "logicalRecipe_candidateChamberInfo_GetByMachineRecipe() != RC_OK", rc);
                            strLot_CheckConditionForLoading_out.strResult = strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out.strResult;
                            return rc;
                        }
                        
                        if ( TRUE == strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out.multiChamberFlag )
                        {
                            // Multi chamber case
                            PPT_METHODTRACE_V1("", "Multi chamber case.");
                            if ( TRUE == strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out.recipeDefinedFlag
                              &&    0 == strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out.strCandidateChamberSeq.length() )
                            {
                                // machine recipe is defined in logical recipe, but there is no available chamber
                                PPT_METHODTRACE_V1("", "machine recipe is defined in logical recipe, but there is no available chamber");
                                PPT_SET_MSG_RC_KEY( strLot_CheckConditionForLoading_out,
                                                    MSG_CHAMBER_NOT_AVAIL_FOR_LOT,
                                                    RC_CHAMBER_NOT_AVAIL_FOR_LOT,
                                                    strStartCassette[i].strLotInCassette[j].lotID.identifier );
                                return RC_CHAMBER_NOT_AVAIL_FOR_LOT;
                            }
                            else
                            {
                                // Following 2 cases
                                // 1. Machine recipe isn't defined in logical recipe.
                                // 2. Machine recipe is defined in logical recipe and chambers are found which meets following condition
                                //     - Chamber Status
                                //     - Conditional available
                                PPT_METHODTRACE_V1("", "recipe/chamber check OK");
                            }
                        }
                        else
                        {
                            // Not multi chamber
                            PPT_METHODTRACE_V1("", "Not multi chamber.");
                        }
                    }
                }
            }
//PSN000043994 Add End
            PPT_METHODTRACE_V1("", "call equipment_CheckInhibitForLotWithMachineRecipe()");
            objEquipment_CheckInhibitForLotWithMachineRecipe_out strEquipment_CheckInhibitForLotWithMachineRecipe_out;
            rc = equipment_CheckInhibitForLotWithMachineRecipe( strEquipment_CheckInhibitForLotWithMachineRecipe_out,
                                                                strObjCommonIn,
                                                                equipmentID,
                                                                checkLotIDs,
                                                                strControlJob_startReserveInformation_Get_out.strStartCassette );
            if ( rc == RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_CheckInhibitForLotWithMachineRecipe() == RC_OK")
                rc = RC_OK;
            }
            else if ( rc == RC_INHIBIT_LOT )
            {
                PPT_METHODTRACE_V1("", "rc == RC_INHIBIT_LOT");
                strLot_CheckConditionForLoading_out.strResult = strEquipment_CheckInhibitForLotWithMachineRecipe_out.strResult;
                return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
            }
            else
            {
                PPT_METHODTRACE_V2("", "##### equipment_CheckInhibitForLotWithMachineRecipe != RC_OK", rc);
                strLot_CheckConditionForLoading_out.strResult = strEquipment_CheckInhibitForLotWithMachineRecipe_out.strResult;
                return rc;
            }
        }
        else
        {
            //INN-A170007 add start
            objEquipment_category_Get_out strEquipment_category_Get_out;
            objEquipment_category_Get_in  strEquipment_category_Get_in;
            strEquipment_category_Get_in.equipmentID = equipmentID;
            rc = equipment_category_Get(strEquipment_category_Get_out, strObjCommonIn, strEquipment_category_Get_in);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_category_Get() != RC_OK", rc);
                strLot_CheckConditionForLoading_out.strResult = strEquipment_category_Get_out.strResult;
                return( rc );
            }
            
            PPT_METHODTRACE_V2("", "equipmentCategory", strEquipment_category_Get_out.category);

            PosMachine_var aMachine;
            PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                             equipmentID,
                                             strLot_CheckConditionForLoading_out,
                                             lot_CheckConditionForLoading );

            stringSequence_var specialControls;
            try
            {
                specialControls = aMachine->getSpecialEquipmentControls();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getSpecialEquipmentControls)

            CORBA::Boolean bDurableFlag = FALSE;
            for (CORBA::ULong iSC=0; iSC < specialControls->length(); iSC++)
            {
                PPT_METHODTRACE_V3("", "specialControl", (*specialControls)[iSC], iSC);

                if ( 0 == CIMFWStrCmp((*specialControls)[iSC], SP_Mc_SpecialEquipmentControl_DurableCarrier)
                    || 0 == CIMFWStrCmp((*specialControls)[iSC], SP_Mc_SpecialEquipmentControl_DurableReticle)
                    || 0 == CIMFWStrCmp((*specialControls)[iSC], SP_Mc_SpecialEquipmentControl_DurableReticlePod) )
                {
                    bDurableFlag = TRUE;
                    break;
                }
            }

            if ( 0 != CIMFWStrCmp(SP_Mc_Category_WaferSorter, strEquipment_category_Get_out.category)
                && FALSE == bDurableFlag )
            {
                PPT_SET_MSG_RC_KEY( strLot_CheckConditionForLoading_out,
                                    MSG_NOT_RESERVED_LOT, RC_NOT_RESERVED_LOT,
                                    lotID.identifier );
                return RC_NOT_RESERVED_LOT;
            }
            //INN-A170007 add end

//D8000024 add start

//D9000001  CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
            CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
            if( 1 == tmpFPCAdoptFlag )
            {
                PPT_METHODTRACE_V2("", "Check lot's FPC definition.", lotID.identifier);
                objLot_currentFPCInfo_Get_out strLot_currentFPCInfo_Get_out;
                rc = lot_currentFPCInfo_Get( strLot_currentFPCInfo_Get_out, strObjCommonIn, lotID,
                                             equipmentID, FALSE, FALSE, FALSE, FALSE );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_currentFPCInfo_Get() != RC_OK", rc);
                    strLot_CheckConditionForLoading_out.strResult = strLot_currentFPCInfo_Get_out.strResult;
                    return( rc );
                }

                CORBA::Long fpcLen = strLot_currentFPCInfo_Get_out.strFPCInfoList.length();
                if( fpcLen > 0 )
                {
                    PPT_METHODTRACE_V2("", "This lot is influenced by FPC.", fpcLen);
                    PPT_SET_MSG_RC_KEY( strLot_CheckConditionForLoading_out,
                                        MSG_FPC_REQUIRE_START_RESERVE, RC_FPC_REQUIRE_START_RESERVE,
                                        lotID.identifier );
                    return RC_FPC_REQUIRE_START_RESERVE;
                }
            }
//D8000024 add end
//P4200169 end
            objEquipment_CheckInhibitForLot_out strEquipment_CheckInhibitForLot_out;
            rc = equipment_CheckInhibitForLot( strEquipment_CheckInhibitForLot_out,
                                               strObjCommonIn,
                                               equipmentID,
                                               checkLotIDs );
            if ( rc == RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_CheckInhibitForLot=RC_OK")
                rc = RC_OK;
            }
            else if ( rc == RC_INHIBIT_LOT )
            {
                PPT_METHODTRACE_V1("", "rc == RC_INHIBIT_LOT");

                strLot_CheckConditionForLoading_out.strResult = strEquipment_CheckInhibitForLot_out.strResult;

//Q3000040 delete start
//            PosMachine_var aMachine;
//            PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
//                                             equipmentID,
//                                             strLot_CheckConditionForLoading_out,
//                                             lot_CheckConditionForLoading );
//
////Q3000040  PosEntityInhibitSequence* entityInhibitSeq = theEntityInhibitManager->allEntityInhibitsForLot(aLot, aMachine);
////Q3000040  PosEntityInhibitSequence_var entityInhibitSeq_var = entityInhibitSeq;
////Q3000040 add start
//            PosEntityInhibitSequence* entityInhibitSeq;
//            PosEntityInhibitSequence_var entityInhibitSeq_var;
//            try
//            {
//                entityInhibitSeq = theEntityInhibitManager->allEntityInhibitsForLot(aLot, aMachine);
//                entityInhibitSeq_var = entityInhibitSeq;
//            }
//            CATCH_AND_RAISE_EXCEPTIONS(PosEntityInhibitManager::allEntityInhibitsForLot);
////Q3000040 add end
//
//            CORBA::String_var inhibitList = makeInhibitListFromEntityInhibits(entityInhibitSeq);
//
//            PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForLoading_out,
//                                 MSG_INHIBIT_LOT,
//                                 RC_NOT_CANDIDATE_LOT_FOR_OPE_START,
//                                 lotID.identifier,
//                                 inhibitList );
//Q3000040 delete end

                return RC_NOT_CANDIDATE_LOT_FOR_OPE_START;
            }
            else
            {
                PPT_METHODTRACE_V1("", "ELSE!!");

                strLot_CheckConditionForLoading_out.strResult = strEquipment_CheckInhibitForLot_out.strResult;
                return rc ;
            }
        }  //P4200169

//DSIV00000214 add start
        //-----------------------------------------------------------
        // Check lot interFabXferState
        //-----------------------------------------------------------
        objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;
        objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
        strLot_interFabXferState_Get_in.lotID = lotID;
        rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,    
                                        strObjCommonIn,
                                        strLot_interFabXferState_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
            strLot_CheckConditionForLoading_out.strResult = strLot_interFabXferState_Get_out.strResult;
            return( rc );
        }

        //-----------------------------------------------------------
        // "Transferring"
        //-----------------------------------------------------------
        if( CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring) == 0 )
        {
             PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
             PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForLoading_out,
                                  MSG_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                  RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                  lotID.identifier,
                                  strLot_interFabXferState_Get_out.interFabXferState );
             return( RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ );
        }
//DSIV00000214 add end

//DSN000081739 Add Start
        if ( 0 == CIMFWStrCmp( getenv(SP_EQPMONITOR_SWITCH), "1" ) )
        {
            PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
            CORBA::String_var strLotType;
            try
            {
                strLotType = aLot->getLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType);

            if ( 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_EquipmentMonitorLot) || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_DummyLot) )
            {
                PPT_METHODTRACE_V1("","Checking EqpMonitor Job.");

                objLot_eqpMonitorSectionInfo_GetForJob_out strLot_eqpMonitorSectionInfo_GetForJob_out;
                objLot_eqpMonitorSectionInfo_GetForJob_in  strLot_eqpMonitorSectionInfo_GetForJob_in;
                strLot_eqpMonitorSectionInfo_GetForJob_in.lotID = lotID;
                rc = lot_eqpMonitorSectionInfo_GetForJob( strLot_eqpMonitorSectionInfo_GetForJob_out,
                                                          strObjCommonIn,
                                                          strLot_eqpMonitorSectionInfo_GetForJob_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_eqpMonitorSectionInfo_GetForJob() != RC_OK", rc);
                    strLot_CheckConditionForLoading_out.strResult = strLot_eqpMonitorSectionInfo_GetForJob_out.strResult;
                    return rc;
                }

                if ( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor) )
                {
                    PPT_METHODTRACE_V1("","operationLabel is Monitor.");
                    objEqpMonitorJob_info_Get_out strEqpMonitorJob_info_Get_out;
                    objEqpMonitorJob_info_Get_in  strEqpMonitorJob_info_Get_in;
                    strEqpMonitorJob_info_Get_in.eqpMonitorID    = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;
                    strEqpMonitorJob_info_Get_in.eqpMonitorJobID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID;
                    rc = eqpMonitorJob_info_Get( strEqpMonitorJob_info_Get_out,
                                                 strObjCommonIn,
                                                 strEqpMonitorJob_info_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "eqpMonitorJob_info_Get() != RC_OK", rc);
                        strLot_CheckConditionForLoading_out.strResult = strEqpMonitorJob_info_Get_out.strResult;
                        return rc;
                    }

                    //Check Equipment Monitor Job status
                    if ( 0 != CIMFWStrCmp(strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].monitorJobStatus, SP_EqpMonitorJob_Status_Ready)
                      && 0 != CIMFWStrCmp(strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].monitorJobStatus, SP_EqpMonitorJob_Status_Executing) )
                    {
                        PPT_METHODTRACE_V1("","monitorJobStatus is not Ready or Executing.")
                        PPT_SET_MSG_RC_KEY( strLot_CheckConditionForLoading_out,
                                            MSG_INVALID_EQPMONJOBSTATUS,
                                            RC_INVALID_EQPMONJOBSTATUS,
                                            strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].monitorJobStatus) ;
                        return RC_INVALID_EQPMONJOBSTATUS;
                    }

                    //Check Equipment
                    if ( 0 != CIMFWStrCmp(strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].equipmentID.identifier, equipmentID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "equipment for loading is not target equipment of EqpMonitor.");
                        PPT_SET_MSG_RC_KEY( strLot_CheckConditionForLoading_out,
                                            MSG_DIFF_EQPMONJOB_EQPID,
                                            RC_DIFF_EQPMONJOB_EQPID,
                                            lotID.identifier );
                        return RC_DIFF_EQPMONJOB_EQPID;
                    }

                    //Check Start Sequence
                    CORBA::Long startSeqNo;
                    for ( CORBA::ULong iCnt=0; iCnt<strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq.length(); iCnt++ )
                    {
                        PPT_METHODTRACE_V2("", "loop to strEqpMonitorLotInfoSeq", iCnt);
                        if ( 0 == CIMFWStrCmp(strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq[iCnt].lotID.identifier, lotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "target lot is found.");
                            startSeqNo = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq[iCnt].startSeqNo;
                            break;
                        }
                    }

                    for ( iCnt=0; iCnt<strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq.length(); iCnt++ )
                    {
                        PPT_METHODTRACE_V2("", "loop to strEqpMonitorLotInfoSeq", iCnt);
                        if ( 0 == CIMFWStrCmp(strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq[iCnt].monitorLotStatus, SP_EqpMonitorJob_Status_Reserved) )
                        {
                            PPT_METHODTRACE_V1("", "monitor lot status is Reserved.");
                            //startSeqNo should be the minimum value
                            if ( startSeqNo > strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq[iCnt].startSeqNo )
                            {
                                PPT_METHODTRACE_V1("", "startSeqNo is not the minimum value.")
                                SET_MSG_RC( strLot_CheckConditionForLoading_out,
                                            MSG_MISMATCH_EQPMON_STARTSEQ,
                                            RC_MISMATCH_EQPMON_STARTSEQ );
                                return RC_MISMATCH_EQPMON_STARTSEQ;
                            }
                        }
                    }
                }
            }
        }
//DSN000081739 Add End

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_CheckConditionForLoading");

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_CheckConditionForLoading_out, lot_CheckConditionForLoading, methodName)
}
