//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_recipe_compareFlag_Get.cpp
//

#include "cs_pptmgr.hpp"
#include "pmcrc.hh"
#include "plot.hh"
#include "pmc.hh"

// Class: CS_PPTManager
//
// Service: cs_recipe_compareFlag_Get()
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//

// Description:
//
// Return:
//     long
//
// Parameter:
//
//    csObjRecipe_compareFlag_Get_out&       strCsObjRecipe_compareFlag_Get
//    const pptObjCommonIn&                  strObjCommonIn
//    const stringSequence&                  machineRecipeIDs
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_recipe_compareFlag_Get(
    csObjRecipe_compareFlag_Get_out&       strCsObjRecipe_compareFlag_Get,
    const pptObjCommonIn&                  strObjCommonIn,
    const stringSequence&                  machineRecipeIDs)
{
  PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_recipe_compareFlag_Get")

  char * methodName = NULL;
  try
  {

    CORBA::Long nLenmachineRecipes = machineRecipeIDs.length();
    PPT_METHODTRACE_V2("","machineRecipeIDs.length() = ",nLenmachineRecipes);

    strCsObjRecipe_compareFlag_Get.machineRecipeInfos.length(nLenmachineRecipes);

    for( CORBA::Long i = 0; i < nLenmachineRecipes; i++ )
    {

        objectIdentifier    machineRecipeID;
        machineRecipeID.identifier = machineRecipeIDs[i];

        PosMachineRecipe_var aMachineRecipe;
        CORBA::Boolean resultFlag = FALSE;

        PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR(aMachineRecipe, machineRecipeID, strCsObjRecipe_compareFlag_Get,cs_recipe_compareFlag_Get);

        /*------------------------------------------------*/
        /*   GetMachine Recipe's RecipeBodyConfirm Flag   */
        /*------------------------------------------------*/
        CORBA::String_var varRecipeBodyConFirmFlag;
        try
        {
            varRecipeBodyConFirmFlag = aMachineRecipe->getUserDataNamed( CS_M_RECIPEBODYCONFIRM_FLAG );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getUserDataNamed)
        
        PPT_METHODTRACE_V2("", "CS_M_RECIPEBODYCONFIRM_FLAG = ", varRecipeBodyConFirmFlag);
        if( 0 == CIMFWStrCmp( varRecipeBodyConFirmFlag , "0" ) )
        {
            strCsObjRecipe_compareFlag_Get.machineRecipeInfos[i].recipeCompareFlag = FALSE;
        }
        else //default
        {
            strCsObjRecipe_compareFlag_Get.machineRecipeInfos[i].recipeCompareFlag = TRUE;
        }

        strCsObjRecipe_compareFlag_Get.machineRecipeInfos[i].machineRecipeID = CIMFWStrDup(machineRecipeID.identifier);

        PPT_METHODTRACE_V2("", "strCsObjRecipe_compareFlag_Get.machineRecipeInfos[i].machineRecipeID = ", strCsObjRecipe_compareFlag_Get.machineRecipeInfos[i].machineRecipeID );

        if( strCsObjRecipe_compareFlag_Get.machineRecipeInfos[i].recipeCompareFlag == TRUE )
        {
            PPT_METHODTRACE_V2("", "strCsObjRecipe_compareFlag_Get.machineRecipeInfos[i].recipeCompareFlag = ", 1);
        }
        else
        {
            PPT_METHODTRACE_V2("", "strCsObjRecipe_compareFlag_Get.machineRecipeInfos[i].recipeCompareFlag = ", 0);
        }
    }// End Of for( CORBA::Long i = 0; i < nLenmachineRecipes; i++ )

    PPT_METHODTRACE_V2("", "strCsObjRecipe_compareFlag_Get.machineRecipeInfos.length = ", strCsObjRecipe_compareFlag_Get.machineRecipeInfos.length() );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_recipe_compareFlag_Get");
    return RC_OK ;
  }
  CATCH_GLOBAL_EXCEPTIONS( strCsObjRecipe_compareFlag_Get, cs_recipe_compareFlag_Get, methodName );
}