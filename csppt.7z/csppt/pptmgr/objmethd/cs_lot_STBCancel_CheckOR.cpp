//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_lot_STBCancel_CheckOR.cpp
//

#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "pcas.hh"
#include "pbank.hh"
#include "pmongrp.hh"
#include "plotfm.hh"
#include "pflwbch.hh"
#include "pwafer.hh"

// Class: CS_PPTManager
//
// Service: lot_STBCancel_Check()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/10 DSIV00000220 M.Ogawa        Initial release
// 2013/05/10 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2017/02/13 DSN000104277 K.Yamaoku      Performance improvement(reference:lot_wafers_GetDR)
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Jun Zhang      New Transfer State PI/PO.
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  const pptObjCommonIn&             strObjCommonIn
//  in  const objLot_STBCancel_Check_in&  strLot_STBCancel_Check_in
//
//  typedef struct objLot_STBCancel_Check_in_struct {
//      objectIdentifier            STBCancelledLotID;
//      objectIdentifier            startBankID;
//      pptSTBCancelInfoSequence    strSTBCancelInfoSeq;
//      any                         siInfo;
//  } objLot_STBCancel_Check_in;
//
//[Output Parameters]:
//  out objLot_STBCancel_Check_out&       strLot_STBCancel_Check_out
//
//  typedef objBase_out objLot_STBCancel_Check_out;
//
//[Require]:
//
//[Ensure]:
//
//[Exception]:
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//
//[Pseudo code]:
//

CORBA::Long CS_PPTManager_i::lot_STBCancel_Check(
    objLot_STBCancel_Check_out&         strLot_STBCancel_Check_out,
    const pptObjCommonIn&               strObjCommonIn,
    const objLot_STBCancel_Check_in&    strLot_STBCancel_Check_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_STBCancel_Check");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        unsigned int i = 0;
        unsigned int j = 0;
        unsigned int k = 0;
        unsigned int l = 0;
        unsigned int nLen = 0;

      
        /*---------------------*/
        /*   Input Parameter   */
        /*---------------------*/
        nLen = strLot_STBCancel_Check_in.strSTBCancelInfoSeq.length() ;
        if( 0 == nLen )
        {
            PPT_METHODTRACE_V1("", "0 == nLen");
            SET_MSG_RC( strLot_STBCancel_Check_out,
                        MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        const objectIdentifier& STBCancelledLotID = strLot_STBCancel_Check_in.STBCancelledLotID;
        const objectIdentifier& startBankID       = strLot_STBCancel_Check_in.startBankID;
        const objectIdentifier& cassetteID        = strLot_STBCancel_Check_in.strSTBCancelInfoSeq[0].strNewLotAttributes.cassetteID;
        const pptSTBCancelInfoSequence strSTBCancelInfoSeq = strLot_STBCancel_Check_in.strSTBCancelInfoSeq;
        PPT_METHODTRACE_V2("", "InParam [STBCancelledLotID] ", STBCancelledLotID.identifier);
        PPT_METHODTRACE_V2("", "InParam [startBankID]       ", startBankID.identifier);


        /*-----------------------------------*/
        /*   Check for STBCancelled lot      */
        /*   1.  Source lot type             */
        /*   2.  Lot Hold                    */
        /*   3.  Future hold                 */
        /*   4.  Lot inventory state         */
        /*   5.  Lot state                   */
        /*   6.  Lot process state           */
        /*   7.  Monitor group existance     */
        /*   8.  PostProcess Flag            */
        /*   9.  Lot family's lot state      */
        /*   10. Next Prodreq existance      */
        /*   11. FlowBatch                   */
        /*-----------------------------------*/

        /*--------------------*/
        /*   Get lot object   */
        /*--------------------*/
        PPT_METHODTRACE_V1("","Check lot process state");
        PosLot_var aPosLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                     STBCancelledLotID,
                                     strLot_STBCancel_Check_out,
                                     lot_STBCancel_Check );

        /*------------------------------*/
        /*   1. Check source lot Type   */
        /*------------------------------*/
        PPT_METHODTRACE_V1("","Check source lot Type");

        CORBA::String_var strLotType;
        try
        {
            strLotType = aPosLot->getLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)

        if ( 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_ProductionLot)
          && 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_EngineeringLot)
          && 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_ProductionMonitorLot)
          && 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_EquipmentMonitorLot)
          && 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_DummyLot)
          && 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_RecycleLot) )
        {
            PPT_METHODTRACE_V1("","Lot State is ");
            PPT_SET_MSG_RC_KEY2( strLot_STBCancel_Check_out,
                                 MSG_INVALID_LOT_TYPE,
                                 RC_INVALID_LOT_TYPE,
                                 strLotType,
                                 STBCancelledLotID.identifier );

            return RC_INVALID_LOT_TYPE;
        }

        /*--------------------------*/
        /*   2. Check lot hold      */
        /*--------------------------*/
        PPT_METHODTRACE_V1("","Check lot hold");
        CORBA::String_var holdState;
        try
        {
            holdState = aPosLot->getLotHoldState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState)

        if ( 0 != CIMFWStrCmp(holdState, CIMFW_Lot_HoldState_NotOnHold) )
        {
            PosHoldRecordSequence_var strHoldRecordSeq;
            try
            {
                strHoldRecordSeq = aPosLot->allHoldRecords();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::allHoldRecords);

            CORBA::Long hrLen = 0;
            hrLen = strHoldRecordSeq->length();
            PPT_METHODTRACE_V2("", "hrLen", hrLen);

            if( hrLen == 0 )
            {
                PPT_METHODTRACE_V1("", "Not found hold record.");
            }
            else
            {
                for( i = 0; i < hrLen; i++ )
                {
                    CORBA::String_var holdType;
                    objectIdentifier  reasonCodeID;
                    holdType     = (*strHoldRecordSeq)[i].holdType;
                    reasonCodeID = (*strHoldRecordSeq)[i].reasonCode;
                    PPT_METHODTRACE_V2("", "This holdType is   ", holdType);
                    PPT_METHODTRACE_V2("", "This holdReason is ", reasonCodeID.identifier);

                    if( ( 0 == CIMFWStrCmp( holdType, SP_HoldType_LotHold ) )
                     && ( 0 == CIMFWStrCmp( reasonCodeID.identifier, SP_Reason_STBCancelHold ) ) )
                    {
                        PPT_METHODTRACE_V1("", "holdReason is 'STBC'. break.");
                        continue;
                    }
                    else
                    {
                        PPT_SET_MSG_RC_KEY2( strLot_STBCancel_Check_out,
                                             MSG_LOT_HOLD_FOR_HOLDTYPE,
                                             RC_LOT_HOLD_FOR_HOLDTYPE,
                                             STBCancelledLotID.identifier,
                                             holdType );
                        return RC_LOT_HOLD_FOR_HOLDTYPE;
                    }
                } //[i]
            }
        }

        /*--------------------------*/
        /*   3. Check future hold   */
        /*--------------------------*/
        PPT_METHODTRACE_V1("","Check future hold") ;
        PosFutureHoldRecordSequence_var strFutureHoldRecordSeq;
        try
        {
            strFutureHoldRecordSeq = aPosLot->allFutureHoldRecords();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::allFutureHoldRecords);

        CORBA::Long fholdLen = 0;
        fholdLen = strFutureHoldRecordSeq->length();
        PPT_METHODTRACE_V2("", "fholdLen", fholdLen);

        if( fholdLen == 0 )
        {
            PPT_METHODTRACE_V1("", "Not found future hold record.");
        }
        else
        {
            for( i = 0; i < fholdLen; i++ )
            {
                CORBA::String_var holdType;
                objectIdentifier reasonCodeID;
                holdType     = (*strFutureHoldRecordSeq)[i].holdType;
                reasonCodeID = (*strFutureHoldRecordSeq)[i].reasonCode;
                PPT_METHODTRACE_V2("", "This holdType is   ", holdType);
                PPT_METHODTRACE_V2("", "This holdReason is ", reasonCodeID.identifier);

                if( 0 == CIMFWStrCmp( holdType, SP_HoldType_FutureHold ) )
                {
                    PPT_METHODTRACE_V1("", "holdType == SP_HoldType_FutureHold");
                    continue;
                }
                else
                {
                    PPT_SET_MSG_RC_KEY2( strLot_STBCancel_Check_out,
                                         MSG_LOT_HOLD_FOR_HOLDTYPE,
                                         RC_LOT_HOLD_FOR_HOLDTYPE,
                                         STBCancelledLotID.identifier,
                                         holdType );
                    return RC_LOT_HOLD_FOR_HOLDTYPE;
                }
            } //[i]
        }

        /*----------------------------------*/
        /*   4. Check lot inventory state   */
        /*----------------------------------*/
        PPT_METHODTRACE_V1("","Check lot inventory state");
        CORBA::String_var inventoryState;
        try
        {
            inventoryState = aPosLot->getLotInventoryState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInventoryState)

        if ( 0 != CIMFWStrCmp(inventoryState, SP_Lot_InventoryState_OnFloor) )
        {
            PPT_METHODTRACE_V1("","inventoryState != SP_Lot_InventoryState_OnFloor");
            PPT_SET_MSG_RC_KEY2( strLot_STBCancel_Check_out,
                                 MSG_INVALID_LOT_INVENTORYSTAT,
                                 RC_INVALID_LOT_INVENTORYSTAT,
                                 STBCancelledLotID.identifier,
                                 inventoryState );

            return RC_INVALID_LOT_INVENTORYSTAT;
        }

        /*--------------------------------------------*/
        /*   5. Check lot state                       */
        /*        Active -> STB cancel is available   */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("","Check lot state");
        CORBA::String_var lotState;
        try
        {
            lotState = aPosLot->getLotState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotState)

        if ( 0 != CIMFWStrCmp( lotState, CIMFW_Lot_State_Active ) )
        {
            PPT_METHODTRACE_V1("","lotState != CIMFW_Lot_State_Active");
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                MSG_INVALID_LOT_STAT,
                                RC_INVALID_LOT_STAT,
                                lotState );
            return RC_INVALID_LOT_STAT ;
        }

        /*--------------------------------*/
        /*   6. Check lot process state   */
        /*--------------------------------*/
        PPT_METHODTRACE_V1("","Check lot process state");
        CORBA::String_var processState;
        try
        {
            processState = aPosLot->getLotProcessState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotProcessState);

        if ( 0 == CIMFWStrCmp(processState, SP_Lot_ProcState_Processing) )
        {
            PPT_METHODTRACE_V1("", "lotState == SP_Lot_ProcState_Processing");
            SET_MSG_RC( strLot_STBCancel_Check_out,
                        MSG_LOT_STATUS_PROCESSING,
                        RC_LOT_STATUS_PROCESSING )
            return RC_LOT_STATUS_PROCESSING;
        }

        /*--------------------------------------*/
        /*   7. Check monitor group existence   */
        /*--------------------------------------*/
        PPT_METHODTRACE_V1("","Check monitor group existence");

        objMonitorGroup_GetDR_out strMonitorGroup_GetDR_out ;
        rc = monitorGroup_GetDR( strMonitorGroup_GetDR_out, strObjCommonIn, STBCancelledLotID ) ;
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "monitorGroup_GetDR() != RC_OK", rc);
            strLot_STBCancel_Check_out.strResult = strMonitorGroup_GetDR_out.strResult;
            return( rc );
        }

        unsigned int monGroupLen = strMonitorGroup_GetDR_out.strMonitorGroups.length() ;
        PPT_METHODTRACE_V2("", "monGroupLen", monGroupLen);
        if( 0 < monGroupLen )
        {
            PPT_METHODTRACE_V1("", "0 < monGroupLen")
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                MSG_ALREADY_EXIST_MONITORGROUP,
                                RC_ALREADY_EXIST_MONITORGROUP,
                                STBCancelledLotID.identifier );
            return RC_ALREADY_EXIST_MONITORGROUP ;
        }

        /*-------------------------------*/
        /*   8. Check PostProcess Flag   */
        /*-------------------------------*/
        PPT_METHODTRACE_V1("","Check PostProcess Flag");
        CORBA::Long bPostProcFlag = FALSE;
        try
        {
            bPostProcFlag = aPosLot->isPostProcessFlagOn();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::isPostProcessFlagOn);

        if( TRUE == bPostProcFlag )
        {
            PPT_METHODTRACE_V1("", "TRUE == bPostProcFlag")
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                MSG_LOT_INPOSTPROCESS,
                                RC_LOT_INPOSTPROCESS,
                                STBCancelledLotID.identifier);
            return RC_LOT_INPOSTPROCESS ;
        }

        /*-------------------------------------------------------------------------*/
        /*   9. Check lot family's lot state if STBCancelled lot is original lot   */
        /*-------------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Check lot family");
        LotFamily_var aLotFamily;
        try
        {
            aLotFamily = aPosLot->getLotFamily();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::getLotFamily)

        if(CORBA::is_nil(aLotFamily))
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(aLotFamily)");
            SET_MSG_RC( strLot_STBCancel_Check_out,
                        MSG_NOT_FOUND_LOTFAMILY, RC_NOT_FOUND_LOTFAMILY );
            return RC_NOT_FOUND_LOTFAMILY ;
        }

        CORBA::String_var lotFamilyStr ;
        try
        {
            lotFamilyStr = aLotFamily->getIdentifier();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::getIdentifier)

        Lot_var aOrgLot ;
        try
        {
            aOrgLot = aLotFamily->originalLot();
        }
        CATCH_AND_RAISE_EXCEPTIONS(LotFamily::originalLot)

        if(CORBA::is_nil(aOrgLot))
        {
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                MSG_NOT_FOUND_LOT,
                                RC_NOT_FOUND_LOT, "****" );
            return RC_NOT_FOUND_LOT ;
        }

        CORBA::String_var strOrgLotID ;

        try
        {
            strOrgLotID = aOrgLot->getIdentifier();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::getIdentifier)

        PPT_METHODTRACE_V2("", "strOrgLotID   ", strOrgLotID);

        if( 0 == CIMFWStrCmp( STBCancelledLotID.identifier, strOrgLotID ) )
        {
            PPT_METHODTRACE_V1("", "strSTBCancelledLotID == OrgLotID");
            LotSequence_var aCurrentLotSeq  ;
            LotSequence_var anArchiveLotSeq ;
            CORBA::String_var familyLotIDStr ;
            CORBA::Boolean bEmptiedFlag = FALSE ;
            try
            {
                aCurrentLotSeq = aLotFamily->currentLots();
            }
            CATCH_AND_RAISE_EXCEPTIONS(LotFamily::currentLots)

            try
            {
                anArchiveLotSeq = aLotFamily->archive();
            }
            CATCH_AND_RAISE_EXCEPTIONS(LotFamily::archive)

            CORBA::Long nLotListLen = aCurrentLotSeq->length();
            for( j = 0; j < nLotListLen; j++ )
            {
                try
                {
                    familyLotIDStr = (*aCurrentLotSeq)[j]->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getIdentifier)
                if( 0 != CIMFWStrCmp( strOrgLotID, familyLotIDStr ) )
                {
                    PPT_METHODTRACE_V1("", "strOrgLotID != strOrgLotID");
                    SET_MSG_RC( strLot_STBCancel_Check_out,
                                MSG_CHILD_LOT_NOT_EMPTIED,
                                RC_CHILD_LOT_NOT_EMPTIED );
                    return RC_CHILD_LOT_NOT_EMPTIED ;
                }
            }

            nLotListLen = anArchiveLotSeq->length();
            for( j = 0; j < nLotListLen; j++ )
            {
                CORBA::String_var strListLotID;
                try
                {
                    bEmptiedFlag = (*anArchiveLotSeq)[j]->isEmptied();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::isEmptiled)
                if( FALSE == bEmptiedFlag )
                {
                    PPT_METHODTRACE_V1("", "FALSE == bEmptiedFlag");
                    SET_MSG_RC( strLot_STBCancel_Check_out,
                                MSG_CHILD_LOT_NOT_EMPTIED,
                                RC_CHILD_LOT_NOT_EMPTIED );
                    return RC_CHILD_LOT_NOT_EMPTIED ;
                }
            }
        }

        /*-----------------------------------------------------------------------------------*/
        /*   10. Check if STB cancelled lot is suchedulled for next lot by product request   */
        /*-----------------------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Check if STB cancelled lot is suchedulled for next lot by product request");
        objSourceLot_productRequest_GetDR_out strSourceLot_productRequest_GetDR_out ;
        objSourceLot_productRequest_GetDR_in  strSourceLot_productRequest_GetDR_in ;
        strSourceLot_productRequest_GetDR_in.sourceLotID = STBCancelledLotID ;
        rc = sourceLot_productRequest_GetDR( strSourceLot_productRequest_GetDR_out,
                                             strObjCommonIn,
                                             strSourceLot_productRequest_GetDR_in ) ;
        if( rc == RC_NOT_FOUND_PRODREQ_FOR_SRCLOT )
        {
            PPT_METHODTRACE_V2("", "Not found productRequest whose source lot = ", STBCancelledLotID.identifier) ;
            //OK
        }
        else if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "sourceLot_productRequest_GetDR() != RC_OK", rc);
            strLot_STBCancel_Check_out.strResult = strSourceLot_productRequest_GetDR_out.strResult;
            return( rc );
        }

        if( 0 < CIMFWStrLen(strSourceLot_productRequest_GetDR_out.prodReqID.identifier) )
        {
            PPT_METHODTRACE_V2("", "ProductRequest using STB cancelled lot is found. prodReqID",
                                   strSourceLot_productRequest_GetDR_out.prodReqID.identifier);
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                MSG_EXIST_PRODUCTREQUEST,
                                RC_EXIST_PRODUCTREQUEST,
                                "" );
            return RC_EXIST_PRODUCTREQUEST;
        }

        /*-------------------------*/
        /*   11. Check lot FlowBatch   */
        /*-------------------------*/
        PPT_METHODTRACE_V1("", "Check lot FlowBatch");
        PosFlowBatch_var aFlowBatch;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aFlowBatch = aPosLot->getFlowBatch();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getFlowBatch)

        if ( !CORBA::is_nil(aFlowBatch) )
        {
            PPT_METHODTRACE_V1("", "aFlowBatch isn't nil");
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                MSG_LOT_REGISTERED_TO_FLOWBATCH,
                                RC_LOT_REGISTERED_TO_FLOWBATCH,
                                STBCancelledLotID.identifier );
            return RC_LOT_REGISTERED_TO_FLOWBATCH;
        }

        /*---------------------------------*/
        /*   STB cancelled lot check End   */
        /*---------------------------------*/
        PPT_METHODTRACE_V1("", "****************************************************");
        PPT_METHODTRACE_V1("", "* This lot's condition is good for STB cancel!!!!! *");
        PPT_METHODTRACE_V1("", "****************************************************");



        /*-------------------------------------*/
        /*   Check for STB cancelled wafers    */
        /*   1. Scrap wafer check              */
        /*   2. Check PSM registration         */
        /*   3. Check lot FPC registration     */
        /*-------------------------------------*/

        /*---------------------------------*/
        /*   Get lot's wafer identifiers   */
        /*---------------------------------*/
        PPT_METHODTRACE_V1("","call lot_wafers_GetDR()");
//DSN000104277//DSN000085698        objLot_wafers_GetDR_out strLot_wafers_GetDR_out ;
//DSN000104277        objLot_wafers_GetDR_out__150 strLot_wafers_GetDR_out ;   //DSN000085698
//DSN000104277        objLot_wafers_GetDR_in  strLot_wafers_GetDR_in ;
//DSN000104277        strLot_wafers_GetDR_in.lotID = STBCancelledLotID ;
//DSN000104277        strLot_wafers_GetDR_in.scrapCheckFlag = FALSE ;
//DSN000104277//DSN000085698        rc = lot_wafers_GetDR( strLot_wafers_GetDR_out,
//DSN000104277        rc = lot_wafers_GetDR__150( strLot_wafers_GetDR_out, //DSN000085698
//DSN000104277                               strObjCommonIn,
//DSN000104277                               strLot_wafers_GetDR_in ) ;
//DSN000104277        if( rc != RC_OK )
//DSN000104277        {
//DSN000104277//DSN000085698            PPT_METHODTRACE_V2("", "lot_wafers_GetDR() != RC_OK", rc);
//DSN000104277            PPT_METHODTRACE_V2("", "lot_wafers_GetDR__150() != RC_OK", rc);  //DSN000085698
//DSN000104277            strLot_STBCancel_Check_out.strResult = strLot_wafers_GetDR_out.strResult;
//DSN000104277            return( rc );
//DSN000104277        }
//DSN000104277 add start
        objLot_waferIDList_GetDR_out strLot_waferIDList_GetDR_out;
        objLot_waferIDList_GetDR_in  strLot_waferIDList_GetDR_in;
        strLot_waferIDList_GetDR_in.lotID          = STBCancelledLotID;
        strLot_waferIDList_GetDR_in.scrapCheckFlag = FALSE;
        rc = lot_waferIDList_GetDR( strLot_waferIDList_GetDR_out, strObjCommonIn, strLot_waferIDList_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### lot_waferIDList_GetDR() != RC_OK", rc);
            strLot_STBCancel_Check_out.strResult = strLot_waferIDList_GetDR_out.strResult;
            return( rc );
        }
//DSN000104277 add end

//DSN000104277        unsigned int lotWaferlen = strLot_wafers_GetDR_out.strLotWaferAttributes.length() ;
        unsigned int lotWaferlen = strLot_waferIDList_GetDR_out.waferIDs.length() ; //DSN000104277
        PPT_METHODTRACE_V2("", "lotWaferlen", lotWaferlen);
        objectIdentifierSequence lotWaferIDs ;
        lotWaferIDs.length(lotWaferlen) ;

        for ( i = 0; i < lotWaferlen; i++ )
        {
//DSN000104277            PPT_METHODTRACE_V3("", "Round i:waferID", i, strLot_wafers_GetDR_out.strLotWaferAttributes[i].waferID.identifier) ;
//DSN000104277            lotWaferIDs[i] = strLot_wafers_GetDR_out.strLotWaferAttributes[i].waferID ;
            PPT_METHODTRACE_V3("", "Round i:waferID", i, strLot_waferIDList_GetDR_out.waferIDs[i].identifier) ; //DSN000104277
            lotWaferIDs[i] = strLot_waferIDList_GetDR_out.waferIDs[i] ;                                         //DSN000104277
        }

        /*-----------------------------------*/
        /*   1. Check if wafer isn't scrap   */
        /*-----------------------------------*/
        PPT_METHODTRACE_V1("", "Check if wafer isn't scrap");
        for ( i = 0; i < lotWaferlen; i++ )
        {
            PosWafer_var aWafer ;
            PPT_CONVERT_WAFERID_TO_WAFER_OR( aWafer,
                                             lotWaferIDs[i],
                                             strLot_STBCancel_Check_out,
                                             lot_STbCancel_Check );

            CORBA::Boolean bScrapFlag = FALSE;
            try
            {
                bScrapFlag = aWafer->isScrap();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::isScrap);

            if ( TRUE == bScrapFlag )
            {
                PPT_METHODTRACE_V1("", "TRUE == bScrapFlag")
                PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                    MSG_FOUND_SCRAP_WAFER,
                                    RC_FOUND_SCRAP_WAFER,
//DSN000104277                                    strLot_wafers_GetDR_out.strLotWaferAttributes[i].waferID.identifier);
                                    strLot_waferIDList_GetDR_out.waferIDs[i].identifier); //DSN000104277
                return RC_LOT_INPOSTPROCESS ;
            }
        }

        /*--------------------------------------------*/
        /*   2. Check experimental lot registration   */
        /*--------------------------------------------*/
        // Get MainPD(mainRouteID) by lotID
        PPT_METHODTRACE_V1("", "Get MainPD by lot. call lot_mainRouteID_Get()");
        objLot_mainRouteID_Get_out strLot_mainRouteID_Get_out;
        rc = lot_mainRouteID_Get( strLot_mainRouteID_Get_out, strObjCommonIn, STBCancelledLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_mainRouteID_Get != RC_OK", rc);
            strLot_STBCancel_Check_out.strResult = strLot_mainRouteID_Get_out.strResult;
            return( rc );
        }
        objectIdentifier mainRouteID = strLot_mainRouteID_Get_out.mainRouteID;
        PPT_METHODTRACE_V2("", "mainRouteID", mainRouteID.identifier);

        // Get PSM definition
        PPT_METHODTRACE_V1("", "Get PSM definition. call experimental_lotList_GetDR()");
        CORBA::String_var  dummyStr;
        objExperimental_lotList_GetDR_out  strExperimental_lotList_GetDR_out;
        rc = experimental_lotList_GetDR( strExperimental_lotList_GetDR_out,
                                         strObjCommonIn,
                                         lotFamilyStr,              // lotFamily
                                         dummyStr,                  // splitRoute
                                         dummyStr,                  // splitOperationNumber
                                         mainRouteID.identifier,    // originalRoute
                                         dummyStr,                  // originalOperationNumber
                                         TRUE,                      // execCheckFlag
                                         TRUE );                    // detailRequireFlag
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "experimental_lotList_GetDR() != RC_OK", rc);
            strLot_STBCancel_Check_out.strResult = strExperimental_lotList_GetDR_out.strResult;
            return( rc );
        }

        // Check if STB cancelled wafer is not registered in PSM
        PPT_METHODTRACE_V1("", "Check if STB cancelled wafer is not registered in PSM");
        CORBA::Long lenPSM = strExperimental_lotList_GetDR_out.strExperimentalLotInfoList.length();
        PPT_METHODTRACE_V2("", "lenPSM", lenPSM);
        unsigned int PSMdetailLen = 0;
        if( 0 < lenPSM )
        {
            PPT_METHODTRACE_V1("", "0 < lenPSM");
            for( i = 0; i < lenPSM; i++ )
            {
                PPT_METHODTRACE_V2("", "Round i", i);
                PSMdetailLen = strExperimental_lotList_GetDR_out.strExperimentalLotInfoList[i].strExperimentalLotDetailInfoSeq.length() ;
                PPT_METHODTRACE_V2("", "PSMdetailLen", PSMdetailLen);
                for( j = 0; j < PSMdetailLen; j++ )
                {
                    PPT_METHODTRACE_V2("", "Round j", j);
                    objectIdentifierSequence PSMWaferIDs ;
                    PSMWaferIDs = strExperimental_lotList_GetDR_out.strExperimentalLotInfoList[i].strExperimentalLotDetailInfoSeq[j].waferIDs ;
                    unsigned int PSMWaferLen = PSMWaferIDs.length() ;
                    PPT_METHODTRACE_V2("", "PSMWaferLen", PSMWaferLen);
                    for( k = 0 ; k < PSMWaferLen ; k++ )
                    {
                        for( l = 0; l < lotWaferlen; l++ )
                        {
                            if( 0 == CIMFWStrCmp( PSMWaferIDs[k].identifier, lotWaferIDs[l].identifier ) )
                            {
                                PPT_METHODTRACE_V2("", "PSMWaferID == lotWaferID", lotWaferIDs[l].identifier);
                                PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                                    MSG_WAFER_PSM_RESERVED,
                                                    RC_WAFER_PSM_RESERVED,
                                                    lotWaferIDs[l].identifier );
                                return RC_WAFER_PSM_RESERVED ;
                            }
                        } //[l]
                    } //[k]
                } //[j]
            } //[i]
        }

        /*----------------------------------*/
        /*   3. Check lot FPC registration  */
        /*----------------------------------*/
        PPT_METHODTRACE_V1("", "Check lot FPC registration")
        // Get FPC definition
        PPT_METHODTRACE_V1("", "Get FPC definition. call FPC_list_GetDR()");
        objectIdentifier dummy ;
        stringSequence   dummyFPC_IDs ;
        dummyFPC_IDs.length(0) ;
        objFPC_list_GetDR_out strFPC_list_GetDR_out;
        objFPC_list_GetDR_in  strFPC_list_GetDR_in;
        strFPC_list_GetDR_in.FPC_IDs               = dummyFPC_IDs ;
        strFPC_list_GetDR_in.lotID                 = STBCancelledLotID ;
        strFPC_list_GetDR_in.lotFamilyID           = dummy ;
        strFPC_list_GetDR_in.mainPDID              = dummy ;
        strFPC_list_GetDR_in.mainOperNo            = CIMFWStrDup("") ;
        strFPC_list_GetDR_in.orgMainPDID           = dummy ;
        strFPC_list_GetDR_in.orgOperNo             = CIMFWStrDup("") ;
        strFPC_list_GetDR_in.subMainPDID           = dummy ;
        strFPC_list_GetDR_in.subOperNo             = CIMFWStrDup("") ;
        strFPC_list_GetDR_in.equipmentID           = dummy ;
        strFPC_list_GetDR_in.waferIDInfoGetFlag    = TRUE ;
        strFPC_list_GetDR_in.recipeParmInfoGetFlag = FALSE ;
        strFPC_list_GetDR_in.reticleInfoGetFlag    = FALSE ;
        strFPC_list_GetDR_in.dcSpecItemInfoGetFlag = FALSE ;
        rc = FPC_list_GetDR( strFPC_list_GetDR_out, strObjCommonIn, strFPC_list_GetDR_in ) ;
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_currentFPCInfo_Get() != RC_OK", rc);
            strLot_STBCancel_Check_out.strResult = strFPC_list_GetDR_out.strResult;
            return( rc );
        }

        // Check if STB cancelled wafer is not registered in FPC
        PPT_METHODTRACE_V1("", "Check if STB cancelled wafer is not registered in FPC");
        CORBA::Long lenFPC = strFPC_list_GetDR_out.strFPCInfoList.length();
        PPT_METHODTRACE_V2("", "lenFPC", lenFPC);
        unsigned int FPCWaferLen = 0;
        if( 0 < lenFPC )
        {
            PPT_METHODTRACE_V1("", "0 < lenFPC");
            for( i = 0; i < lenFPC; i++ )
            {
                PPT_METHODTRACE_V3("", "Round i, FPC_ID", i, strFPC_list_GetDR_out.strFPCInfoList[i].FPC_ID);
                FPCWaferLen = strFPC_list_GetDR_out.strFPCInfoList[i].strLotWaferInfoList.length() ;
                PPT_METHODTRACE_V2("", "FPCWaferLen", FPCWaferLen);
                for( j = 0; j < FPCWaferLen; j++ )
                {
                    PPT_METHODTRACE_V2("", "Round j", j);
                    PPT_METHODTRACE_V2("", "PSMWaferID", strFPC_list_GetDR_out.strFPCInfoList[i].strLotWaferInfoList[j].waferID.identifier);
                    for( k = 0; k < lotWaferlen; k++ )
                    {
                        if( 0 == CIMFWStrCmp( strFPC_list_GetDR_out.strFPCInfoList[i].strLotWaferInfoList[j].waferID.identifier,
                                              lotWaferIDs[k].identifier ) )
                        {
                            PPT_METHODTRACE_V2("", "PSMWaferID == lotWaferID", lotWaferIDs[k].identifier);
                            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                                MSG_WAFER_FPC_REGISTERED,
                                                RC_WAFER_FPC_REGISTERED,
                                                lotWaferIDs[k].identifier );
                            return RC_WAFER_FPC_REGISTERED ;
                        }
                    } //[k]
                } //[j]
            } //[i]
        }


        /*-----------------------------------*/
        /*   STB cancelled wafer check End   */
        /*-----------------------------------*/
        PPT_METHODTRACE_V1("", "**************************************************************");
        PPT_METHODTRACE_V1("", "* This lot's wafers' conditions are good for STB cancel!!!!! *");
        PPT_METHODTRACE_V1("", "**************************************************************");



        /*---------------------------------------------------------*/
        /*   Check for cassette                                    */
        /*   1. Check if lot is in a cassette                      */
        /*   2. Check for transferState                            */
        /*   3. Check available condition of cassette              */
        /*   4. Check carrier has controlJob or not                */
        /*   5. Check SortJob of Cassette                          */
        /*   6. Check PostProcessFlag of cassette                  */
        /*   7. Check dispatch reservation condition of cassette   */
        /*   8. Check SLMReserveEquipmentID of Cassette            */
        /*---------------------------------------------------------*/

        /*--------------------------------------*/
        /*   1. Check if lot is in a cassette   */
        /*--------------------------------------*/
        PPT_METHODTRACE_V1("", "Check if lot is in a cassette");
        if( 0 == CIMFWStrLen(cassetteID.identifier) )
        {
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                MSG_LOT_OUT_OF_CAST,
                                RC_LOT_OUT_OF_CAST,
                                STBCancelledLotID.identifier )
            return RC_LOT_OUT_OF_CAST;
        }

        PosCassette_var aPosCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette,
                                               cassetteID,
                                               strLot_STBCancel_Check_out,
                                               lot_STBCancel_Check );

//DSN000071674 add start
        CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
        if ( 1 == lotOperationEIcheck )
        {
//DSN000071674 add end
            /*--------------------------------*/
            /*   2. Check for transferState   */
            /*--------------------------------*/
            PPT_METHODTRACE_V1("", "Check for transferState");
            CORBA::String_var transferState;
            try
            {
                transferState = aPosCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState);

//INN-R170003 if (0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn))
            if (0 == CIMFWStrCmp(transferState, CS_TRANS_STATE_PORT_IN) ||    //INN-R170003
                0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) || //INN-R170003
                0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut))  //INN-R170003
            {
                PPT_METHODTRACE_V1( "","transferState == CS_TRANS_STATE_PORT_IN || SP_TransState_EquipmentIn || SP_TransState_EquipmentOut");
                PPT_SET_MSG_RC_KEY2(strLot_STBCancel_Check_out, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT, transferState, cassetteID.identifier )
                return(RC_INVALID_CAST_XFERSTAT);
            }
        } //DSN000071674

        /*----------------------------------------------*/
        /*   3. Check available condition of cassette   */
        /*----------------------------------------------*/
        PPT_METHODTRACE_V1("", "Check available condition of cassette");
        CORBA::String_var cassetteState;
        try
        {
            cassetteState = aPosCassette->getDurableState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableState);
        PPT_METHODTRACE_V2("", "cassetteState", cassetteState);

        if ( 0 != CIMFWStrCmp(cassetteState, CIMFW_Durable_Available) )
        {
            PPT_METHODTRACE_V1("", "return RC_INVALID_CAST_STAT");
            PPT_SET_MSG_RC_KEY2( strLot_STBCancel_Check_out,
                                 MSG_INVALID_CAST_STAT, RC_INVALID_CAST_STAT,
                                 cassetteState,
                                 cassetteID.identifier );
            return RC_INVALID_CAST_STAT;
        }

//DSN000071674 add start
        if ( 1 == lotOperationEIcheck )
        {
//DSN000071674 add end
            /*--------------------------------------------*/
            /*   4. Check carrier has controlJob or not   */
            /*--------------------------------------------*/
            PPT_METHODTRACE_V1("","Check carrier has controlJob or not");

            PosControlJob_var aPosControlJob;
            try
            {
                aPosControlJob = aPosCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

            if ( ! CORBA::is_nil(aPosControlJob) )
            {
                SET_MSG_RC( strLot_STBCancel_Check_out,
                            MSG_NOT_CLEARED_CONTROLJOB,
                            RC_NOT_CLEARED_CONTROLJOB )

                return RC_NOT_CLEARED_CONTROLJOB;
            }
        } //DSN000071674

        /*----------------------------------*/
        /*   5. Check SortJob of Cassette   */
        /*----------------------------------*/
        PPT_METHODTRACE_V1("", "Check SortJob of Cassette");
        objSorter_jobList_GetDR_in strSorter_jobList_GetDR_in;
        strSorter_jobList_GetDR_in.carrierID = cassetteID;

        objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;
        rc = sorter_jobList_GetDR( strSorter_jobList_GetDR_out, strObjCommonIn, strSorter_jobList_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "sorter_jobList_GetDR() rc != RC_OK", rc);
            strLot_STBCancel_Check_out.strResult = strSorter_jobList_GetDR_out.strResult;
            return rc;
        }

        CORBA::Long lenSortJob = strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length();
        PPT_METHODTRACE_V2("", "lenSortJob", lenSortJob);
        if ( 0 < lenSortJob )
        {
            PPT_METHODTRACE_V1("", "return RC_EXIST_SORTERJOB_FOR_CASSETTE");
            PPT_SET_MSG_RC_KEY2( strLot_STBCancel_Check_out,
                                 MSG_EXIST_SORTERJOB_FOR_CASSETTE, RC_EXIST_SORTERJOB_FOR_CASSETTE,
                                 cassetteID.identifier,
                                 strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0].sorterJobID.identifier );
            return RC_EXIST_SORTERJOB_FOR_CASSETTE;
        }

        /*------------------------------------------*/
        /*   6. Check PostProcessFlag of cassette   */
        /*------------------------------------------*/
        PPT_METHODTRACE_V1("", "Check PostProcessFlag of cassette");
        bPostProcFlag = FALSE;
        try
        {
            bPostProcFlag = aPosCassette->isPostProcessFlagOn();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isPostProcessFlagOn);
        PPT_METHODTRACE_V2("", "bPostProcFlag", (long)bPostProcFlag);

        if( TRUE == bPostProcFlag )
        {
            PPT_METHODTRACE_V1("", "TRUE == bPostProcFlag");
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out,
                                MSG_CAST_INPOSTPROCESS, RC_CAST_INPOSTPROCESS,
                                cassetteID.identifier );
            return RC_CAST_INPOSTPROCESS;
        }

//DSN000071674 add start
        if ( 1 == lotOperationEIcheck )
        {
//DSN000071674 add end
            /*---------------------------------------------------------*/
            /*   7. Check dispatch reservation condition of cassette   */
            /*---------------------------------------------------------*/
            PPT_METHODTRACE_V1("", "Check dispatch reservation condition of cassette");
            CORBA::Boolean bDispatchReserved = FALSE;
            try
            {
                bDispatchReserved = aPosCassette->isDispatchReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchReserved);
            PPT_METHODTRACE_V2("", "bDispatchReserved", (long)bDispatchReserved);

            if ( TRUE == bDispatchReserved )
            {
                PPT_METHODTRACE_V1("", "return RC_ALREADY_DISPATCH_RESVED_CST");
                SET_MSG_RC( strLot_STBCancel_Check_out,
                            MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST );
                return RC_ALREADY_DISPATCH_RESVED_CST;
            }
        } //DSN000071674

        /*------------------------------------------------*/
        /*   8. Check SLMReserveEquipmentID of Cassette   */
        /*------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Check SLMReserveEquipmentID of Cassette");
        PosMachine_var aSLMReservedMachine;
        try
        {
            aSLMReservedMachine = aPosCassette->getSLMReservedMachine();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getSLMReservedMachine);

        if ( !CORBA::is_nil(aSLMReservedMachine) )
        {
            PPT_METHODTRACE_V2("", " !!!!! Error Because the specified cassette is SLM reserved.", cassetteID.identifier);
            PPT_SET_MSG_RC_KEY( strLot_STBCancel_Check_out, MSG_ALREADY_RESERVED_CAST_SLM, RC_ALREADY_RESERVED_CAST_SLM, cassetteID.identifier );
            return RC_ALREADY_RESERVED_CAST_SLM;
        }

        /*--------------------------------------------*/
        /*   STB cancelled lot's cassette check End   */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("", "***************************************************************");
        PPT_METHODTRACE_V1("", "* This lot's cassette conditions are good for STB cancel!!!!! *");
        PPT_METHODTRACE_V1("", "***************************************************************");



        /*---------------------------------------------*/
        /*   Other checks                              */
        /*   1. Check Reqest type for generating lot   */
        /*---------------------------------------------*/

        /*-------------------------------------*/
        /*   Get Object reference of PosBank   */
        /*-------------------------------------*/
        PPT_METHODTRACE_V1("","Get Object reference of PosBank");

        PosBank_var aBank;
        PPT_CONVERT_BANKID_TO_BANK_OR( aBank,
                                       startBankID,
                                       strLot_STBCancel_Check_out,
                                       lot_STBCancel_Check );

        /*---------------------------------------------*/
        /*   1. Check Reqest type for generating lot   */
        /*---------------------------------------------*/
        PPT_METHODTRACE_V1("","Check Reqest type for generating lot");
        CORBA::Long createdLotLen = strSTBCancelInfoSeq.length() ;
        for( i = 0; i < createdLotLen; i++ )
        {
            CORBA::String_var lotType;
            lotType = strSTBCancelInfoSeq[i].strNewPreparedLotInfo.lotType;
            if ( 0 == CIMFWStrCmp(lotType, SP_Lot_Type_EngineeringLot)
              || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_VendorLot) )
            {
                PPT_METHODTRACE_V1("","lotType == SP_Lot_Type_EngineeringLot or SP_Lot_Type_VendorLot");


                CORBA::Boolean bPrdBank = FALSE;
                try
                {
                    bPrdBank = aBank->isProductionBank();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosBank::isProductionBank)

                if ( bPrdBank == FALSE )
                {
                    PPT_METHODTRACE_V1("","bPrdBank == FALSE");
                    PPT_SET_MSG_RC_KEY2( strLot_STBCancel_Check_out,
                                         MSG_INVALID_BANK_DATA,
                                         RC_INVALID_BANK_DATA,
                                         lotType,
                                         startBankID.identifier );
                    return RC_INVALID_BANK_DATA;
                }
            }
            else if ( 0 == CIMFWStrCmp(lotType, SP_Lot_Type_ProductionMonitorLot)
                   || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_EquipmentMonitorLot)
                   || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_DummyLot)
                   || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_RecycleLot) )
            {
                PPT_METHODTRACE_V1("","lotType = SP_Lot_Type_ProductionMonitorLot or SP_Lot_Type_EquipmentMonitorLot or SP_Lot_Type_DummyLot or SP_Lot_Type_RecycleLot");


                CORBA::Boolean bCtrlWaferBank = FALSE;
                try
                {
                    bCtrlWaferBank = aBank->isControlWaferBank();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosBank::isControlWaferBank)

                if ( bCtrlWaferBank == FALSE )
                {
                    PPT_METHODTRACE_V1("","bCtrlWaferBank == FALSE");
                    PPT_SET_MSG_RC_KEY2( strLot_STBCancel_Check_out,
                                         MSG_INVALID_BANK_DATA,
                                         RC_INVALID_BANK_DATA,
                                         lotType,
                                         startBankID.identifier );
                    return RC_INVALID_BANK_DATA;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","Else!!");
                SET_MSG_RC( strLot_STBCancel_Check_out,
                            MSG_INVALID_INPUT_PARM,
                            RC_INVALID_INPUT_PARM );
                return RC_INVALID_INPUT_PARM;
            }
        }

        /*---------------------*/
        /*   Check logic end   */
        /*---------------------*/
        PPT_METHODTRACE_V1("", "**************************");
        PPT_METHODTRACE_V1("", "* All checks are done !! *");
        PPT_METHODTRACE_V1("", "**************************");

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_STBCancel_Check");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_STBCancel_Check_out, lot_STBCancel_Check, methodName)
}
