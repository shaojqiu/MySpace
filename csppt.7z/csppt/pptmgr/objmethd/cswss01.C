static char sqla_program_id[292] = 
{
 0,172,69,65,81,65,73,65,101,66,69,54,68,74,76,104,48,49,49,49,
 49,32,50,32,32,32,32,32,32,32,32,32,0,8,73,78,83,84,68,69,
 86,49,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,8,67,83,87,83,83,48,49,32,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {' ',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "cswss01.sqx"
#ifndef lint
static char *sccsid =  "@(#) 1.6 superpos/src/spppt/source/posppt/pptmgr/objmethd/cslot01.sqx, mm_srv_90e_ppt, mm_srv_90e_ppt 11/2/07 14:13:19 [ 11/2/07 14:13:20 ]";
#endif
//
// (c) Copyright: IBM Taiwan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cswss01.sqx
//
//
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/07/25 INN-R170084  Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
//                                       

#include "cs_pptmgr.hpp"

#ifdef __toFoolPreCompiler__

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 21 "cswss01.sqx"

    
/*
EXEC SQL INCLUDE 'csfswfrmaprsvdb.h';
*/

#line 1 "/home/instdev1/mm/include/csppt/csfswfrmaprsvdb.h"
//
// (c) Copyright: IBM Taiwan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: csfswfrmaprsvdb.h
//
// Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017/07/25 INN-R170084   Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
//

char hCSFSWFRMAPRSVBANK_ID[65];
char hCSFSWFRMAPRSVLOT_TYPE[21];
char hCSFSWFRMAPRSVSUB_LOT_TYPE[21];
char hCSFSWFRMAPRSVSRC_PROD_ID[65];
char hCSFSWFRMAPRSVCAST_ID[65];
char hCSFSWFRMAPRSVCLAIM_USER[65];
char hCSFSWFRMAPRSVCLAIM_TIME[27];

char hCSFSWFRMAPRSV_DATACAST_ID[65];
char hCSFSWFRMAPRSV_DATANEW_LOT_ID[65];
char hCSFSWFRMAPRSV_DATANEW_WAFER_ID[65];
sqlint32 hCSFSWFRMAPRSV_DATANEW_SLOT_NO;
char hCSFSWFRMAPRSV_DATASRC_LOT_ID[65];
char hCSFSWFRMAPRSV_DATASRC_WAFER_ID[65];

#line 22 "cswss01.sqx"


/*
EXEC SQL END DECLARE SECTION;
*/

#line 23 "cswss01.sqx"

#endif


/*
EXEC SQL INCLUDE 'cs_vendorLotReserve_SelDR.dr';
*/

#line 1 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
//
// (c) Copyright: IBM Taiwan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_vendorLotReserve_SelDR.dr
//

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_vendorLotReserve_SelDR
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/07/25 INN-R170084  Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
//
// Function Description:
//
// Input Parameters:
//
// Output Parameters:
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_vendorLotReserve_SelDR(
    csObjVendorLotReserve_SelDR_out&            strVendorLotReserve_SelDR_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     cassetteID)
{
    CORBA::Long rc = RC_OK;
    CORBA::Long i = 0;

	char * methodName = NULL;
    try
    {
        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_vendorLotReserve_SelDR");
        CORBA::Long rc = RC_OK;
        
        sqlca sqlca;
        #include "csfswfrmaprsvdb.h"

        if( CIMFWStrLen( cassetteID.identifier ) != 0 )
        {
            PPT_METHODTRACE_V1( "", "CIMFWStrLen( cassetteID.identifier ) != 0" );

            memset( hCSFSWFRMAPRSVBANK_ID     , '\0', sizeof(hCSFSWFRMAPRSVBANK_ID));
            memset( hCSFSWFRMAPRSVLOT_TYPE    , '\0', sizeof(hCSFSWFRMAPRSVLOT_TYPE));
            memset( hCSFSWFRMAPRSVSUB_LOT_TYPE, '\0', sizeof(hCSFSWFRMAPRSVSUB_LOT_TYPE));
            memset( hCSFSWFRMAPRSVSRC_PROD_ID , '\0', sizeof(hCSFSWFRMAPRSVSRC_PROD_ID));
            memset( hCSFSWFRMAPRSVCAST_ID     , '\0', sizeof(hCSFSWFRMAPRSVCAST_ID));
            memset( hCSFSWFRMAPRSVCLAIM_USER  , '\0', sizeof(hCSFSWFRMAPRSVCLAIM_USER));
            memset( hCSFSWFRMAPRSVCLAIM_TIME  , '\0', sizeof(hCSFSWFRMAPRSVCLAIM_TIME));

            SP_SET_HOSTVARIABLE( hCSFSWFRMAPRSVCAST_ID, cassetteID.identifier );
            PPT_METHODTRACE_V2( "", "hCSFSWFRMAPRSVCAST_ID", hCSFSWFRMAPRSVCAST_ID );

            //---------------------------------------
            //   Get Vendor Lot Reserve Information
            //---------------------------------------
            
/*
EXEC SQL SELECT 
                    BANK_ID,
                    LOT_TYPE,
                    SUB_LOT_TYPE,
                    SRC_PROD_ID,
                    CAST_ID,
                    CLAIM_USER,
                    CLAIM_TIME
            INTO
                    :hCSFSWFRMAPRSVBANK_ID,
                    :hCSFSWFRMAPRSVLOT_TYPE,
                    :hCSFSWFRMAPRSVSUB_LOT_TYPE,
                    :hCSFSWFRMAPRSVSRC_PROD_ID,
                    :hCSFSWFRMAPRSVCAST_ID,
                    :hCSFSWFRMAPRSVCLAIM_USER,
                    :hCSFSWFRMAPRSVCLAIM_TIME
            FROM
                CSFSWFRMAPRSV
            WHERE
                CAST_ID = :hCSFSWFRMAPRSVCAST_ID
            FOR READ ONLY;
*/

{
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlaaloc(2,1,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSWFRMAPRSVCAST_ID;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlaaloc(3,7,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[7];
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSWFRMAPRSVBANK_ID;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 21;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSWFRMAPRSVLOT_TYPE;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 21;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSWFRMAPRSVSUB_LOT_TYPE;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 65;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSWFRMAPRSVSRC_PROD_ID;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSWFRMAPRSVCAST_ID;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 65;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[5].sqldata = (void*)hCSFSWFRMAPRSVCLAIM_USER;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[5].sqlind = 0L;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 27;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[6].sqldata = (void*)hCSFSWFRMAPRSVCLAIM_TIME;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[6].sqlind = 0L;
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sqlasetdata(3,0,7,sql_setdlist,0L,0L);
    }
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)24,1,2,3,0L);
#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 91 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"

    
            PPT_DR_CHECK_SQL_ERROR_WITHOUT_SQL_NOT_FOUND( strVendorLotReserve_SelDR_out,
                                                          cs_vendorLotReserve_SelDR,
                                                          "SQL SELECT CSFSWFRMAPRSV with carrierID" );

            if(SQLCODE == 100)
            {
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence.length(0);
                PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_vendorLotReserve_SelDR");
                SET_MSG_RC(strVendorLotReserve_SelDR_out,MSG_OK,RC_OK)
                return ( RC_OK );
            }

            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence.length(1);

            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].bankID.identifier = CIMFWStrDup(hCSFSWFRMAPRSVBANK_ID);
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].lotType = CIMFWStrDup(hCSFSWFRMAPRSVLOT_TYPE);
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].subLotType = CIMFWStrDup(hCSFSWFRMAPRSVSUB_LOT_TYPE);
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].sourceProduct = CIMFWStrDup(hCSFSWFRMAPRSVSRC_PROD_ID);
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].claimedUserID = CIMFWStrDup(hCSFSWFRMAPRSVCLAIM_USER);
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].claimedTimeStamp = CIMFWStrDup(hCSFSWFRMAPRSVCLAIM_TIME);

            //---------------------------------------
            //   Get Vendor Lot Reserve - Wafer
            //---------------------------------------
            memset( hCSFSWFRMAPRSV_DATACAST_ID, '\0', sizeof(hCSFSWFRMAPRSV_DATACAST_ID));
            SP_SET_HOSTVARIABLE( hCSFSWFRMAPRSV_DATACAST_ID, cassetteID.identifier );

            
/*
EXEC SQL DECLARE cWfrMap CURSOR FOR
                 SELECT 
                    NEW_LOT_ID,
                    NEW_WAFER_ID,
                    NEW_SLOT_NO,
                    SRC_LOT_ID,
                    SRC_WAFER_ID
                 FROM 
                    CSFSWFRMAPRSV_DATA
                 WHERE
                    CAST_ID = :hCSFSWFRMAPRSV_DATACAST_ID
                 ORDER BY 
                    CAST_ID, NEW_SLOT_NO  
                 FOR READ ONLY;
*/

#line 133 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


            
/*
EXEC SQL OPEN cWfrMap;
*/

{
#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlaaloc(2,1,3,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSWFRMAPRSV_DATACAST_ID;
#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)26,2,2,0,0L);
#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 135 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


            if( SQLCODE != 0 )
            {
                PPT_METHODTRACE_V2("", "SQLCODE != 0", SQLCODE);
                SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR,
                               MSG_SYSTEM_ERROR,RC_SYSTEM_ERROR, SQL OPEN CURSOR (CSFSWFRMAPRSV_DATA), SQLCODE );
            }

            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].strNewLotAttributes.cassetteID.identifier = 
                                        CIMFWStrDup(hCSFSWFRMAPRSV_DATACAST_ID);

            //Default set wafer count as SP_Lot_MaximumWafersInALot(25)
            CORBA::Long lngWfrCnt = 0;
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].strNewLotAttributes.strNewWaferAttributes.length(SP_Lot_MaximumWafersInALot);
            while(1)
            {
                memset( hCSFSWFRMAPRSV_DATANEW_LOT_ID  , '\0', sizeof(hCSFSWFRMAPRSV_DATANEW_LOT_ID));
                memset( hCSFSWFRMAPRSV_DATANEW_WAFER_ID, '\0', sizeof(hCSFSWFRMAPRSV_DATANEW_WAFER_ID));
                hCSFSWFRMAPRSV_DATANEW_SLOT_NO = -1;
                memset( hCSFSWFRMAPRSV_DATASRC_LOT_ID  , '\0', sizeof(hCSFSWFRMAPRSV_DATASRC_LOT_ID));
                memset( hCSFSWFRMAPRSV_DATASRC_WAFER_ID, '\0', sizeof(hCSFSWFRMAPRSV_DATASRC_WAFER_ID));

                
/*
EXEC SQL FETCH cWfrMap
                    INTO 
                        :hCSFSWFRMAPRSV_DATANEW_LOT_ID,
                        :hCSFSWFRMAPRSV_DATANEW_WAFER_ID,
                        :hCSFSWFRMAPRSV_DATANEW_SLOT_NO,
                        :hCSFSWFRMAPRSV_DATASRC_LOT_ID,
                        :hCSFSWFRMAPRSV_DATASRC_WAFER_ID ;
*/

{
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlaaloc(3,5,4,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSWFRMAPRSV_DATANEW_LOT_ID;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSWFRMAPRSV_DATANEW_WAFER_ID;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqldata = (void*)&hCSFSWFRMAPRSV_DATANEW_SLOT_NO;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 65;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSWFRMAPRSV_DATASRC_LOT_ID;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSWFRMAPRSV_DATASRC_WAFER_ID;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sqlasetdata(3,0,5,sql_setdlist,0L,0L);
    }
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)25,2,0,3,0L);
#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 164 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


                if( SQLCODE != 0 )
                {
                    PPT_METHODTRACE_V2("", "SQLCODE != 0", SQLCODE);

                    CORBA::Long retsqlCode = SQLCODE ;
                    
/*
EXEC SQL CLOSE cWfrMap;
*/

{
#line 171 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 171 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)20,2,0,0,0L);
#line 171 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 171 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"

                    SQLCODE = retsqlCode ;

                    if( SQLCODE == SP_SQL_NOT_FOUND )
                    {
                        break;
                    }

                    if( SQLCODE == SP_SQL_BUSY )
                    {
                        PPT_METHODTRACE_V1("", "DeadLock and Timeout occurs");
                        rc = RC_LOCKED_BY_ANOTHER;
                        SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR, MSG_LOCKED_BY_ANOTHER, RC_LOCKED_BY_ANOTHER,SQL SELECT SKILL_ID SQL_BUSY(CSFSWFRMAPRSV_DATA), SQLCODE);
                        return( rc );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "Other SQL error");
                        rc = RC_SYSTEM_ERROR;
                        SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR,SQL SELECT SKILL_ID OTHER ERROE (CSFSWFRMAPRSV_DATA), SQLCODE);
                        return( rc );
                    }
                }

                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].newLotID.identifier
                                            = CIMFWStrDup(hCSFSWFRMAPRSV_DATANEW_LOT_ID);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].newWaferID.identifier
                                            = CIMFWStrDup(hCSFSWFRMAPRSV_DATANEW_WAFER_ID);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].newSlotNumber
                                            = hCSFSWFRMAPRSV_DATANEW_SLOT_NO;
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].sourceLotID.identifier
                                            = CIMFWStrDup(hCSFSWFRMAPRSV_DATASRC_LOT_ID);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].sourceWaferID.identifier
                                            = CIMFWStrDup(hCSFSWFRMAPRSV_DATASRC_WAFER_ID);
                lngWfrCnt++;
            }
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[0].strNewLotAttributes.strNewWaferAttributes.length(lngWfrCnt);
        }
        else
        {
            PPT_METHODTRACE_V1( "", "CIMFWStrLen( cassetteID.identifier ) == 0" );

            //---------------------------------------
            //   Get Vendor Lot Reserve Information
            //---------------------------------------
            
/*
EXEC SQL DECLARE cWfrMap1 CURSOR FOR
                 SELECT 
                    BANK_ID,
                    LOT_TYPE,
                    SUB_LOT_TYPE,
                    SRC_PROD_ID,
                    CAST_ID,
                    CLAIM_USER,
                    CLAIM_TIME
                 FROM 
                    CSFSWFRMAPRSV
                 ORDER BY 
                    CAST_ID  
                 FOR READ ONLY;
*/

#line 229 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


            
/*
EXEC SQL OPEN cWfrMap1;
*/

{
#line 231 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 231 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)26,3,0,0,0L);
#line 231 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 231 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


            if( SQLCODE != 0 )
            {
                PPT_METHODTRACE_V2("", "SQLCODE != 0", SQLCODE);
                SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR,
                               MSG_SYSTEM_ERROR,RC_SYSTEM_ERROR, SQL OPEN CURSOR (CSFSWFRMAPRSV), SQLCODE );
            }


            CORBA::Long lngCastCnt = 0;
            CORBA::Long lngMaxCast = 20;
            PPT_METHODTRACE_V2("","Initial - lngMaxCast", lngMaxCast);
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence.length(lngMaxCast);

            while(1)
            {
                memset( hCSFSWFRMAPRSVBANK_ID     , '\0', sizeof(hCSFSWFRMAPRSVBANK_ID));
                memset( hCSFSWFRMAPRSVLOT_TYPE    , '\0', sizeof(hCSFSWFRMAPRSVLOT_TYPE));
                memset( hCSFSWFRMAPRSVSUB_LOT_TYPE, '\0', sizeof(hCSFSWFRMAPRSVSUB_LOT_TYPE));
                memset( hCSFSWFRMAPRSVSRC_PROD_ID , '\0', sizeof(hCSFSWFRMAPRSVSRC_PROD_ID));
                memset( hCSFSWFRMAPRSVCAST_ID     , '\0', sizeof(hCSFSWFRMAPRSVCAST_ID));
                memset( hCSFSWFRMAPRSVCLAIM_USER  , '\0', sizeof(hCSFSWFRMAPRSVCLAIM_USER));
                memset( hCSFSWFRMAPRSVCLAIM_TIME  , '\0', sizeof(hCSFSWFRMAPRSVCLAIM_TIME));

                
/*
EXEC SQL FETCH cWfrMap1 
                    INTO 
                        :hCSFSWFRMAPRSVBANK_ID,
                        :hCSFSWFRMAPRSVLOT_TYPE,
                        :hCSFSWFRMAPRSVSUB_LOT_TYPE,
                        :hCSFSWFRMAPRSVCAST_ID,
                        :hCSFSWFRMAPRSVCLAIM_USER,
                        :hCSFSWFRMAPRSVCLAIM_TIME ;
*/

{
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlaaloc(3,6,5,0L);
    {
      struct sqla_setdata_list sql_setdlist[6];
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSWFRMAPRSVBANK_ID;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 21;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSWFRMAPRSVLOT_TYPE;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 21;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSWFRMAPRSVSUB_LOT_TYPE;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 65;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSWFRMAPRSVCAST_ID;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSWFRMAPRSVCLAIM_USER;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 27;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[5].sqldata = (void*)hCSFSWFRMAPRSVCLAIM_TIME;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[5].sqlind = 0L;
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sqlasetdata(3,0,6,sql_setdlist,0L,0L);
    }
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)25,3,0,3,0L);
#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 263 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


                if( SQLCODE != 0 )
                {
                    PPT_METHODTRACE_V2("", "SQLCODE != 0", SQLCODE);

                    CORBA::Long retsqlCode = SQLCODE ;
                    
/*
EXEC SQL CLOSE cWfrMap1;
*/

{
#line 270 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 270 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)20,3,0,0,0L);
#line 270 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 270 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"

                    SQLCODE = retsqlCode ;

                    if( SQLCODE == SP_SQL_NOT_FOUND )
                    {
                        break;
                    }

                    if( SQLCODE == SP_SQL_BUSY )
                    {
                        PPT_METHODTRACE_V1("", "DeadLock and Timeout occurs");
                        rc = RC_LOCKED_BY_ANOTHER;
                        SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR, MSG_LOCKED_BY_ANOTHER, RC_LOCKED_BY_ANOTHER,SQL SELECT SKILL_ID SQL_BUSY(CSFSWFRMAPRSV), SQLCODE);
                        return( rc );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "Other SQL error");
                        rc = RC_SYSTEM_ERROR;
                        SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR,SQL SELECT SKILL_ID OTHER ERROE (CSFSWFRMAPRSV), SQLCODE);
                        return( rc );
                    }
                }

                if( lngCastCnt >= lngMaxCast )
                {
                    lngMaxCast = lngMaxCast + 10;
                    PPT_METHODTRACE_V2("","Increae - lngMaxCast", lngMaxCast);
                    strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence.length(lngMaxCast);
                }

                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].bankID.identifier = CIMFWStrDup(hCSFSWFRMAPRSVBANK_ID);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].lotType = CIMFWStrDup(hCSFSWFRMAPRSVLOT_TYPE);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].subLotType = CIMFWStrDup(hCSFSWFRMAPRSVSUB_LOT_TYPE);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].sourceProduct = CIMFWStrDup(hCSFSWFRMAPRSVSRC_PROD_ID);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].claimedUserID = CIMFWStrDup(hCSFSWFRMAPRSVCLAIM_USER);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].claimedTimeStamp = CIMFWStrDup(hCSFSWFRMAPRSVCLAIM_TIME);
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].strNewLotAttributes.cassetteID.identifier = CIMFWStrDup(hCSFSWFRMAPRSVCAST_ID);

                //---------------------------------------
                //   Get Vendor Lot Reserve - Wafer
                //---------------------------------------
                memset( hCSFSWFRMAPRSV_DATACAST_ID, '\0', sizeof(hCSFSWFRMAPRSV_DATACAST_ID));
                SP_SET_HOSTVARIABLE( hCSFSWFRMAPRSV_DATACAST_ID, hCSFSWFRMAPRSVCAST_ID );

                
/*
EXEC SQL DECLARE cWfrMap2 CURSOR FOR
                    SELECT 
                        NEW_LOT_ID,
                        NEW_WAFER_ID,
                        NEW_SLOT_NO,
                        SRC_LOT_ID,
                        SRC_WAFER_ID
                    FROM 
                        CSFSWFRMAPRSV_DATA
                    WHERE
                        CAST_ID = :hCSFSWFRMAPRSV_DATACAST_ID
                    ORDER BY 
                        CAST_ID, NEW_SLOT_NO  
                    FOR READ ONLY;
*/

#line 328 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


                
/*
EXEC SQL OPEN cWfrMap2;
*/

{
#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlaaloc(2,1,6,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSWFRMAPRSV_DATACAST_ID;
#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)26,4,2,0,0L);
#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 330 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


                if( SQLCODE != 0 )
                {
                    PPT_METHODTRACE_V2("", "SQLCODE != 0", SQLCODE);
                    SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR,
                                   MSG_SYSTEM_ERROR,RC_SYSTEM_ERROR, SQL OPEN CURSOR (CSFSWFRMAPRSV_DATA), SQLCODE );
                }

                //Default set wafer count as SP_Lot_MaximumWafersInALot(25)
                CORBA::Long lngWfrCnt = 0;
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].strNewLotAttributes.strNewWaferAttributes.length(SP_Lot_MaximumWafersInALot);
                while(1)
                {
                    memset( hCSFSWFRMAPRSV_DATANEW_LOT_ID  , '\0', sizeof(hCSFSWFRMAPRSV_DATANEW_LOT_ID));
                    memset( hCSFSWFRMAPRSV_DATANEW_WAFER_ID, '\0', sizeof(hCSFSWFRMAPRSV_DATANEW_WAFER_ID));
                    hCSFSWFRMAPRSV_DATANEW_SLOT_NO = -1;
                    memset( hCSFSWFRMAPRSV_DATASRC_LOT_ID  , '\0', sizeof(hCSFSWFRMAPRSV_DATASRC_LOT_ID));
                    memset( hCSFSWFRMAPRSV_DATASRC_WAFER_ID, '\0', sizeof(hCSFSWFRMAPRSV_DATASRC_WAFER_ID));

                    
/*
EXEC SQL FETCH cWfrMap2 
                        INTO 
                            :hCSFSWFRMAPRSV_DATANEW_LOT_ID,
                            :hCSFSWFRMAPRSV_DATANEW_WAFER_ID,
                            :hCSFSWFRMAPRSV_DATANEW_SLOT_NO,
                            :hCSFSWFRMAPRSV_DATASRC_LOT_ID,
                            :hCSFSWFRMAPRSV_DATASRC_WAFER_ID ;
*/

{
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlaaloc(3,5,7,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSWFRMAPRSV_DATANEW_LOT_ID;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSWFRMAPRSV_DATANEW_WAFER_ID;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqldata = (void*)&hCSFSWFRMAPRSV_DATANEW_SLOT_NO;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 65;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSWFRMAPRSV_DATASRC_LOT_ID;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSWFRMAPRSV_DATASRC_WAFER_ID;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
      sqlasetdata(3,0,5,sql_setdlist,0L,0L);
    }
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)25,4,0,3,0L);
#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 356 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"


                    if( SQLCODE != 0 )
                    {
                        PPT_METHODTRACE_V2("", "SQLCODE != 0", SQLCODE);

                        CORBA::Long retsqlCode = SQLCODE ;
                        
/*
EXEC SQL CLOSE cWfrMap2;
*/

{
#line 363 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 363 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlacall((unsigned short)20,4,0,0,0L);
#line 363 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"
  sqlastop(0L);
}

#line 363 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_vendorLotReserve_SelDR.dr"

                        SQLCODE = retsqlCode ;

                        if( SQLCODE == SP_SQL_NOT_FOUND )
                        {
                            break;
                        }

                        if( SQLCODE == SP_SQL_BUSY )
                        {
                            PPT_METHODTRACE_V1("", "DeadLock and Timeout occurs");
                            rc = RC_LOCKED_BY_ANOTHER;
                            SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR, MSG_LOCKED_BY_ANOTHER, RC_LOCKED_BY_ANOTHER,SQL SELECT SKILL_ID SQL_BUSY(CSFSWFRMAPRSV_DATA), SQLCODE);
                            return( rc );
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "Other SQL error");
                            rc = RC_SYSTEM_ERROR;
                            SET_DR_MSG_RC( strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR,SQL SELECT SKILL_ID OTHER ERROE (CSFSWFRMAPRSV_DATA), SQLCODE);
                            return( rc );
                        }
                    }

                    strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].newLotID.identifier
                                                = CIMFWStrDup(hCSFSWFRMAPRSV_DATANEW_LOT_ID);
                    strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].newWaferID.identifier
                                                = CIMFWStrDup(hCSFSWFRMAPRSV_DATANEW_WAFER_ID);
                    strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].newSlotNumber
                                                = hCSFSWFRMAPRSV_DATANEW_SLOT_NO;
                    strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].sourceLotID.identifier
                                                = CIMFWStrDup(hCSFSWFRMAPRSV_DATASRC_LOT_ID);
                    strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].strNewLotAttributes.strNewWaferAttributes[lngWfrCnt].sourceWaferID.identifier
                                                = CIMFWStrDup(hCSFSWFRMAPRSV_DATASRC_WAFER_ID);
                    lngWfrCnt++;
                }
                strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence[lngCastCnt].strNewLotAttributes.strNewWaferAttributes.length(lngWfrCnt);
                lngCastCnt++; 
            }
            strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence.length(lngCastCnt);
        } //end if

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_vendorLotReserve_SelDR");
        SET_MSG_RC(strVendorLotReserve_SelDR_out,MSG_OK,RC_OK)
        return ( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strVendorLotReserve_SelDR_out, cs_vendorLotReserve_SelDR, methodName);
}

#line 26 "cswss01.sqx"

