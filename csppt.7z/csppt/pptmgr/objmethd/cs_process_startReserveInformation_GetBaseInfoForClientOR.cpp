#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/objmethd/cs_process_startReserveInformation_GetBaseInfoForClientOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:22:58 [ 7/13/07 20:22:59 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_process_startReserveInformation_GetBaseInfoForClientOR.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "plcrc.hh"
#include "pmcrc.hh"
#include "ppcope.hh"
#include "pprsp.hh"

//[Object Function Name]: long   cs_process_startReserveInformation_GetBaseInfoForClientOR
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-09-09  0.00      Y.Iwasaki      Initial Release
// 2000-09-20  P3000211  Y.Iwasaki      Add lotType set logic
// 2000-10-13  Q3000297  Y.Iwasaki      Add parameterValue set logic
// 2000/11/10  P2200204  R.Furuta       Initialize local pointers
// 2001/01/09  D3000116  K.Takikita     Change for Structure(ProductID)
// 2001/03/20  P3100131  K.Kido         copy string with CIMFWStrDup
// 2001/05/23  P3100367  H.Adachi       Sub Lot Type used befor set a value
// 2002/03/27  P4100278  Y.Iwasaki      Correct RC, MSG`
// 2005/08/31  D6000415  K.Kido         Call findRecipeParametersForSubLotType() to get correct Recipe Parameter taken into account for Chamber Machine State.
// 2006/02/17  P7000106  K.Matsuei      StartReserve is completed incorrectly.
// 2006/11/23  D8000024  H.Mutoh        When FPC overwrite the machineRecipe, skip the logic of machineRecipe getting from PO.
// 2007/01/23  P8000072  M.Murata       Add comment for DCR number.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/31 INN-R170009  Gary Ke        Add for strStartCassette Process check
//
//[Function Description]:
//
//  This object function fill the return structure's value.
//
//  1. (In) marked item
//      These fields must be filled by using in-parameter's value.
//  2. (MM) marked items
//      These fields must be filled by MM.
//  3. (***) marked item
//      When operationStartFlag is FALSE case, these fields are not required
//      to fill.
//  4. no marked item
//      These fileds are not required to fill.
//
//      sequence <pptStartCassette>   strStartCassette;                  (MM)
//
//      typedef struct pptStartCassette_struct {
//          long                          loadSequenceNumber;            (In)
//          objectIdentifier              cassetteID;                    (In)
//          string                        loadPurposeType;               (In)
//          objectIdentifier              loadPortID;                    (In)
//          objectIdentifier              unloadPortID;
//          sequence <pptLotInCassette>   strLotInCassette;              (In)
//      } pptStartLot;
//
//      typedef struct pptLotInCassette_struct
//          boolean                       operationStartFlag;            (In)
//          boolean                       monitorLotFlag;                (In)
//          objectIdentifier              lotID;                         (In)
//P3000211string                        lotType;                       (In)
//P3000211string                        subLotType;                    (In)
//          string                        lotType;                       (MM)  (***)  //P3000211
//          string                        subLotType;                    (MM)  (***)  //P3000211
//          pptStartRecipe                strStartRecipe;                (MM)  (***)
//          string                        recipeParameterChangeType;     (MM)  (***)
//          sequence <pptLotWafer>        strLotWafer;                   (In)
//          pptStartOperationInfo         strStartOperationInfo;         (MM)  (***)  //P7000106
//      } pptLotInCassette;
//
//      typedef struct pptLotWafer_struct {
//          objectIdentifier              waferID;                       (In)
//          long                          slotNumber;                    (In)
//          boolean                       controlWaferFlag;              (In)
//          sequence <pptStartRecipeParameter> strStartRecipeParameter;  (MM)  (***)
//      } pptLotWafer;
//
//      typedef struct pptStartRecipeParameter_struct {
//          string                        parameterName;                 (MM)  (***)
//          string                        parameterValue;
//          string                        targetValue;                   (MM)  (***)
//          boolean                       useCurrentSettingValueFlag;    (MM)  (***)
//      } pptStartRecipeParameter;
//
//      typedef struct pptStartRecipe_struct {
//          objectIdentifier              logicalRecipeID;               (MM)  (***)
//          objectIdentifier              machineRecipeID;               (MM)  (***)
//          string                        physicalRecipeID;              (MM)  (***)
//          sequence <pptStartReticle>    strStartReticle;
//          sequence <pptStartFixture>    strStartFixture;
//          boolean                       dataCollectioinFlag;
//          sequence <pptDCDef>           strDCDef;
//      } pptStartRecipe;
//
//      typedef struct pptStartOperationInfo_struct {                                 //P7000106
//          objectIdentifier            routeID;                         (MM)  (***)  //P7000106
//          objectIdentifier            operationID;                     (MM)  (***)  //P7000106
//          string                      operationNumber;                 (MM)  (***)  //P7000106
//          long                        passCount;                       (MM)  (***)  //P7000106
//      } pptStartOperationInfo;                                                      //P7000106
//
//[Input Parameters]:
//  in  pptObjCommonIn            strObjCommonIn;
//  in  objectIdentifier          equipmentID;
//  in  pptStartCassetteSequence  strStartCassette;
//
//[Output Parameters]:
//  out objProcess_startReserveInformation_GetBaseInfoForClient_out   strProcess_startReserveInformation_GetBaseInfoForClient_out;
//
//  typedef struct objProcess_startReserveInformation_GetBaseInfoForClient_out_struct {
//      pptRetCode                strResult;
//      objectIdentifier          equipmentID;
//      pptStartCassetteSequence  strStartCassette;
//  } objProcess_startReserveInformation_GetBaseInfoForClient_out;
//
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//

CORBA::Long CS_PPTManager_i::process_startReserveInformation_GetBaseInfoForClient(
                            objProcess_startReserveInformation_GetBaseInfoForClient_out& strProcess_startReserveInformation_GetBaseInfoForClient_out,
                            const pptObjCommonIn&                                        strObjCommonIn,
                            const objectIdentifier&                                      equipmentID,
                            const pptStartCassetteSequence&                              strStartCassette)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::process_startReserveInformation_GetBaseInfoForClient");
        PPT_METHODTRACE_V2( "CS_PPTManager_i::process_startReserveInformation_GetBaseInfoForClient","in-parm's equipmentID", equipmentID.identifier);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        /*--------------------*/
        /*                    */
        /*   Get Eqp Object   */
        /*                    */
        /*--------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine, equipmentID, strProcess_startReserveInformation_GetBaseInfoForClient_out, process_startReserveInformation_GetBaseInfoForClient );

        /*---------------------------------------------*/
        /*                                             */
        /*   Set Retuen Structure's strStartCassette   */
        /*                                             */
        /*---------------------------------------------*/
        PPT_SET_OBJECT_IDENTIFIER( strProcess_startReserveInformation_GetBaseInfoForClient_out.equipmentID,
                                   aMachine,
                                   strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                   process_startReserveInformation_GetBaseInfoForClient,
                                   PosMachine );
        strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette = strStartCassette;
//INN-R170009 Add Start                    
        /*--------------------------------------------------*/
        /*  Get Equipment Process Durable Required Flag     */
        /*--------------------------------------------------*/
        CORBA::Boolean bRequireFlag = FALSE;
        PPT_METHODTRACE_V1("", "bRequireFlag = FALSE");
        PPT_METHODTRACE_V1("", "call equipment_processDurableRequiredFlag_Get()");
        objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
        rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out,
                                                       strObjCommonIn,
                                                       equipmentID );
        if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
        {
            bRequireFlag = TRUE;
            PPT_METHODTRACE_V1("", "rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");
            PPT_METHODTRACE_V1("", "bRequireFlag = TRUE");
            rc = RC_OK;
        }
        else if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
        {
            PPT_METHODTRACE_V1("", "rc == RC_EQP_PROCDRBL_NOT_REQD");
            rc = RC_OK;
        }
        else if ( rc != RC_OK)
        {
            PPT_METHODTRACE_V1("","rc != RC_OK");
            strProcess_startReserveInformation_GetBaseInfoForClient_out.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult;
            return rc;
        }
        else
        {
            PPT_METHODTRACE_V1("", "rc = RC_OK");
            rc = RC_OK;
        }
//INN-R170009 Add End
        /*----------------------------*/
        /*   Loop for StartCassette   */
        /*----------------------------*/
        CORBA::Long castLen = strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette.length();
        for ( CORBA::Long i=0 ; i<castLen ; i++ )
        {

            /*-------------------------*/
            /*   Omit Empty Cassette   */
            /*-------------------------*/
            if ( CIMFWStrCmp(strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0 )
            {
                continue;
            }

            /*----------------------------*/
            /*   Loop for LotInCassette   */
            /*----------------------------*/
            CORBA::Long lotLen = strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette.length();
            for ( CORBA::Long j=0 ; j<lotLen ; j++ )
            {

                /*------------------------*/
                /*   Omit Not Start Lot   */
                /*------------------------*/
                if ( strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                /*----------------------------------*/
                /*    Get / Set Start Recipe Info   */
                /*----------------------------------*/
                /*===== get Lot object =====*/
                PosLot_var aLot;
                PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                             strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].lotID,
                                             strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                             process_startReserveInformation_GetBaseInfoForClient );

//D8000024 add start
                CORBA::Boolean skipFlag = FALSE;
                objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                               SP_FPC_ExchangeType_StartReserveInfo,
                                               equipmentID,
                                               strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].lotID );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                    strProcess_startReserveInformation_GetBaseInfoForClient_out.strResult =
                        strLot_effectiveFPCInfo_Get_out.strResult;
                    return rc;
                }
//D8000024 add end
//P3100367 add start
                /*------------------------------------------*/
                /*    Get / Set Lot Type and Sub Lot Type   */
                /*------------------------------------------*/
                CORBA::String_var lotType;
                try
                {
                     strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].lotType = aLot->getLotType();
                     PPT_METHODTRACE_V2( "","lotType", strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].lotType);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)

                CORBA::String_var subLotType;
                try
                {
                    strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].subLotType = aLot->getSubLotType();
                    PPT_METHODTRACE_V2( "","subLotType", strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].subLotType);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType)
//P3100367 add end

                /*===== get PO object =====*/
                ProcessOperation_var    aPO;
                PosProcessOperation_var aPosPO;

                try
                {
                    aPO    = aLot->getProcessOperation();
                    aPosPO = PosProcessOperation::_narrow(aPO);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

                if ( CORBA::is_nil(aPosPO) == TRUE )
                {
                    PPT_SET_MSG_RC_KEY2( strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                         MSG_NOT_FOUND_PO,
                                         RC_NOT_FOUND_PO,
                                         "*****",
                                         strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].lotID.identifier );
                    return(RC_NOT_FOUND_PO);
                }

                /*===== get ProdSpec object =====*/
                ProductSpecification_var    aProdSpec;
                PosProductSpecification_var aPosProdSpec;

                try
                {
                    aProdSpec    = aLot->getProductSpecification();
                    aPosProdSpec = PosProductSpecification::_narrow(aProdSpec);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

                if ( CORBA::is_nil(aPosProdSpec) == TRUE )
                {
                    SET_MSG_RC( strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                MSG_NOT_FOUND_PRODUCTSPEC,
                                RC_NOT_FOUND_PRODUCTSPEC );
                    return( RC_NOT_FOUND_PRODUCTSPEC );
                }

                /*===== get LogicalRecipe object and set objectIdentifier =====*/
                PosLogicalRecipe_var aLogicalRecipe;

                try
                {
                    aLogicalRecipe = aPosPO->findLogicalRecipeFor(aPosProdSpec);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findLogicalRecipeFor);

                if ( CORBA::is_nil(aLogicalRecipe) == TRUE )
                {
                    SET_MSG_RC( strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                MSG_NOT_FOUND_LCRECIPE,
                                RC_NOT_FOUND_LCRECIPE );
                    return( RC_NOT_FOUND_LCRECIPE );
                }

                PPT_SET_OBJECT_IDENTIFIER( strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                           aLogicalRecipe,
                                           strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                           process_startReserveInformation_GetBaseInfoForClient,
                                           PosLogicalRecipe );

                /*===== get / set MachineRecipe object and set objectIdentifier =====*/
                PosMachineRecipe_var aMachineRecipe;
                if( searchCondition == 1 )                                                       //DSIV00001443
                {                                                                                //DSIV00001443
                    try                                                                          //DSIV00001443
                    {                                                                            //DSIV00001443
                        aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine ); //DSIV00001443
                    }                                                                            //DSIV00001443
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)           //DSIV00001443
                }                                                                                //DSIV00001443
                else                                                                             //DSIV00001443
                {                                                                                //DSIV00001443
                    try
                    {
                        PPT_METHODTRACE_V2( "","subLotType", strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].subLotType);
                        aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType(aMachine,strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].subLotType);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType);
                }                                                                                //DSIV00001443

                if ( CORBA::is_nil(aMachineRecipe) == TRUE )
                {
//P4100278              SET_MSG_RC( strProcess_startReserveInformation_GetBaseInfoForClient_out,
//P4100278                          MSG_NOT_FOUND_LCRECIPE,
//P4100278                          RC_NOT_FOUND_LCRECIPE );
//P4100278              return( RC_NOT_FOUND_LCRECIPE );
//D8000024 add start
                    if( strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "MachineRecipe is overwritten by FPC");
                        skipFlag = TRUE;
                    }
                    else
                    {
//D8000024 add end
                        SET_MSG_RC( strProcess_startReserveInformation_GetBaseInfoForClient_out, //P4100278
                                    MSG_NOT_FOUND_MCRECIPE,                                      //P4100278
                                    RC_NOT_FOUND_MCRECIPE );                                     //P4100278
                        return( RC_NOT_FOUND_MCRECIPE );                                         //P4100278
                    }    //D8000024
                }

                if( skipFlag == FALSE )    //P8000072 This comment should be written by D8000024. 
                {                          //P8000072 This comment should be written by D8000024.
                    PPT_SET_OBJECT_IDENTIFIER( strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
                                               aMachineRecipe,
                                               strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                               process_startReserveInformation_GetBaseInfoForClient,
                                               PosMachineRecipe );

                    /*===== get / set PhysicalRecipeID =====*/
                    try
                    {
                        strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.physicalRecipeID = aMachineRecipe->getPhysicalRecipeId();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getPhysicalRecipeID);


//P3100367 //P3000211 add start
//P3100367                 /*------------------------------------------*/
//P3100367                 /*    Get / Set Lot Type and Sub Lot Type   */
//P3100367                 /*------------------------------------------*/
//P3100367                 CORBA::String_var lotType;
//P3100367                 try
//P3100367                 {
//P3100367                       strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].lotType = aLot->getLotType();
//P3100367                 }
//P3100367                 CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)
//P3100367
//P3100367                 CORBA::String_var subLotType;
//P3100367                 try
//P3100367                 {
//P3100367                     strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].subLotType = aLot->getSubLotType();
//P3100367                 }
//P3100367                 CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType)
//P3100367 //P3000211 add end
                }    //D8000024
                /*--------------------------*/                                                                                           //D3000116
                /*   Get ProductID          */                                                                                           //D3000116
                /*--------------------------*/                                                                                           //D3000116
               PPT_SET_OBJECT_IDENTIFIER( strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].productID,   //D3000116
                                       aPosProdSpec,                                                                                                       //D3000116
                                       strProcess_startReserveInformation_GetBaseInfoForClient_out,                                                        //D3000116
                                       process_startReserveInformation_GetBaseInfoForClient,                                                               //D3000116
                                       PosProductSpecification );                                                                                          //D3000116


                /*------------------------------------------------*/
                /*    Get / Set Wafer and Recipe Parameter Info   */
                /*------------------------------------------------*/
//P3100131                strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].recipeParameterChangeType = SP_Rparm_ChangeType_ByLot;
                strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].recipeParameterChangeType
                                                           = CIMFWStrDup(SP_Rparm_ChangeType_ByLot);    //P3100131

//D8000024 add start
                if( skipFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "RecipeParameter is not overwritten by FPC.");
//D8000024 add end
                    /*--------------------------*/
                    /*   Get Recipe parameter   */
                    /*--------------------------*/
                    PosRecipeParameterSequence*    recipeParameterSeq = NULL; //P2200204
                    PosRecipeParameterSequence_var recipeParameterSeqVar;

                    try
                    {
//D6000415              recipeParameterSeq = aLogicalRecipe->findRecipeParametersFor( aMachine, aMachineRecipe );
                        recipeParameterSeq = aLogicalRecipe->findRecipeParametersForSubLotType( aMachine, aMachineRecipe, strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].subLotType);    //D6000415
                        recipeParameterSeqVar = recipeParameterSeq;
                    }
//D6000415          CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersFor);
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersForSubLotType);    //D6000415

                    if ( recipeParameterSeq == NULL )
                    {
                        CORBA::Long wfrLen = strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                        for ( CORBA::Long k=0 ; k<wfrLen ; k++ )
                        {
                            strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length( 0 );
                        }
                    }
                    else
                    {
                        CORBA::Long rpmCnt = recipeParameterSeq->length();
                        PPT_METHODTRACE_V2("","recipeParameter length = ",rpmCnt);

                        /*-----------------------*/
                        /*   Loop for LotWafer   */
                        /*-----------------------*/
                        CORBA::Long wfrLen = strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                        for ( CORBA::Long k=0 ; k<wfrLen ; k++ )
                        {
                            /*-------------------------------------------------------*/
                            /*   Set Wafer Info and Recipe parameter to Each Wafer   */
                            /*-------------------------------------------------------*/
                            strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length( rpmCnt );
                            for ( CORBA::Long l=0 ; l<rpmCnt ; l++ )
                            {
                                PPT_METHODTRACE_V2("","rpmCnt ",l);
                                strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName              = (*recipeParameterSeq)[l].parameterName;
//Q3000297                      strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue             = (const char*)"";
                                //Q3000297 add start
                                if ( (*recipeParameterSeq)[l].useCurrentValueFlag == TRUE )
                                {
                                    strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue         = (const char*)"";
                                }
                                else
                                {
                                    strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue         = (*recipeParameterSeq)[l].defaultValue;
                                }
                                //Q3000297 add end
                                strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue                = (*recipeParameterSeq)[l].defaultValue;
                                strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag = (*recipeParameterSeq)[l].useCurrentValueFlag;
                            }
                        }
                    }

//P7000106 start
                }    //D8000024
                //--------------------------//
                //   RouteID                //
                //--------------------------//
                PosProcessDefinition_var aMainPD;
                try
                {
                    aMainPD = aLot->getMainProcessDefinition();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getMainProcessDefinition)

                if ( CORBA::is_nil(aMainPD) )
                {
                    PPT_METHODTRACE_V1("", "aMainPD is nil");
                    PPT_SET_MSG_RC_KEY( strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                        MSG_NOT_FOUND_ROUTE, RC_NOT_FOUND_ROUTE,  "" );
                    return RC_NOT_FOUND_ROUTE;
                }

                PPT_SET_OBJECT_IDENTIFIER( strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID,
                                           aMainPD,
                                           strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                           process_startReserveInformation_GetBaseInfoForClient,
                                           PosProcessDefinition );
                PPT_METHODTRACE_V2("", "routeID", strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier);

                //--------------------------//
                //   PDID                   //
                //--------------------------//
                PosProcessDefinition_var aPD;
                try
                {
                    aPD = aPosPO->getProcessDefinition();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessDefinition)

                if ( CORBA::is_nil(aPD) )
                {
                    PPT_METHODTRACE_V1("", "aPD is nil");
                    PPT_SET_MSG_RC_KEY( strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                        MSG_NOT_FOUND_PD, RC_NOT_FOUND_PD, "" );
                    return RC_NOT_FOUND_PD;
                }

                PPT_SET_OBJECT_IDENTIFIER( strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationID,
                                           aPD,
                                           strProcess_startReserveInformation_GetBaseInfoForClient_out,
                                           process_startReserveInformation_GetBaseInfoForClient,
                                           PosProcessDefinition );
                PPT_METHODTRACE_V2("", "operationID", strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationID.identifier);

                //--------------------------//
                //   OperationNumber        //
                //--------------------------//
                try
                {
                    strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber = aLot->getOperationNumber();
                    PPT_METHODTRACE_V2("", "operationNumber", strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getOperationNumber)

                //--------------------------//
                //   PassCount              //
                //--------------------------//
                try
                {
                    strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.passCount = aPosPO->getPassCount();
                    PPT_METHODTRACE_V2("", "passCount", strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.passCount);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getPassCount)
//P7000106 end
//INN-R170009 Add Start                    
                /*----------------------------------------------------*/
                /*   Equipment Process Durable Required Flag Check    */
                /*----------------------------------------------------*/
                if ( bRequireFlag == TRUE )
                {
                    /*--------------------------------------------------*/
                    /*   Check Process Durable Condition for OpeStart   */
                    /*--------------------------------------------------*/
                    PPT_METHODTRACE_V1("", "call processDurable_CheckConditionForOpeStart()");
                    objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                    rc = processDurable_CheckConditionForOpeStart( strProcessDurable_CheckConditionForOpeStart_out,
                                                                   strObjCommonIn,
                                                                   equipmentID,
                                                                   strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                                   strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
                                                                   strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "processDurable_CheckConditionForOpeStart() rc != RC_OK");
                        strProcess_startReserveInformation_GetBaseInfoForClient_out.strResult = strProcessDurable_CheckConditionForOpeStart_out.strResult;
                        return rc;
                    }
                    /*---------------------------------------*/
                    /*   Set Available Reticles / Fixtures   */
                    /*---------------------------------------*/
                    strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle = strProcessDurable_CheckConditionForOpeStart_out.strStartReticle;
                    strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture = strProcessDurable_CheckConditionForOpeStart_out.strStartFixture;
				    
                }
//INN-R170009 Add End           
            }
        }
        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::process_startReserveInformation_GetBaseInfoForClient");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strProcess_startReserveInformation_GetBaseInfoForClient_out, process_startReserveInformation_GetBaseInfoForClient, methodName);
}

