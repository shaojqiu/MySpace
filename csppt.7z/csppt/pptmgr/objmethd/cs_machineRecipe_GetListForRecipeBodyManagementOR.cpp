#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/machineRecipe_GetListForRecipeBodyManagement.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:14:30 [ 7/13/07 20:14:31 ]";
#endif
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_machineRecipe_GetListForRecipeBodyManagementOR.cpp
//

//INN-A170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-A170001 
#include "pmcrc.hh"
#include "plot.hh"   
#include "pprsp.hh"  
#include "ppcope.hh" 
#include "plcrc.hh"  
#include "pmc.hh"    
#include "pmcrc.hh"  

//
// Class: PPTManager
//
// Service : long   machineRecipe_GetListForRecipeBodyManagement
//
// Change history:
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2007/07/03  P9000022  M.Murata       Fix Recipe Body Management
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
// 
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
//[Function Description]:
// This method gets machine recipe list for Recipe Body Confirmation or Recipe Body Down Load.
// 
//[Input Parameters]:
// typedef struct objMachineRecipe_GetListForRecipeBodyManagement_in_struct{
//     pptRetCode                 strResult;
//     objectIdentifier           equipmentID;
//     pptStartCassetteSequence   strStartCassette;
//     any                        siInfo;
// } objMachineRecipe_GetListForRecipeBodyManagement_in;
// 
//[Output Parameters]:
// typedef struct objMachineRecipe_GetListForRecipeBodyManagement_out_struct{
//     pptRetCode                    strResult;
//     pptRecipeBodyManagementSeq    strRecipeBodyManagementSeq;
//     any                           siInfo;
// } objMachineRecipe_GetListForRecipeBodyManagement_out;
// 
// typedef struct pptRecipeBodyManagement_struct{
//     objectIdentifier  machineRecipeID;           //<i>Machine Recipe ID
//     string            physicalRecipeID;          //<i>Physical Recipe ID
//     string            fileLocation;              //<i>File Location
//     string            fileName;                  //<i>File Name
//     boolean           formatFlag;                //<i>Format Flag
//     boolean           forceDownLoadFlag;         //<i>Force Down Load Flag
//     boolean           recipeBodyConfirmFlag;     //<i>Recipe Body Confirm Flag
//     boolean           conditionalDownLoadFlag;   //<i>Conditional Down Load Flag
//     any               siInfo;
// }pptRecipeBodyManagement;
// 
//[Return Value]:
//
// Return Code                        Messsage ID
// ---------------------------------- -----------------------------------------
// RC_OK                              MSG_OK
// RC_INVALID_PARAMETER               MSG_INVALID_PARAMETER
// RC_NOT_FOUND_PRODUCTSPEC           MSG_NOT_FOUND_PRODUCTSPEC
// RC_NOT_FOUND_PO                    MSG_NOT_FOUND_PO
// RC_NOT_FOUND_LCRECIPE              MSG_NOT_FOUND_LCRECIPE
// RC_NOT_FOUND_MCRECIPE              MSG_NOT_FOUND_MCRECIPE
// 
//[Pseudo Code]
//[Exception]
//
CORBA::Long CS_PPTManager_i:: machineRecipe_GetListForRecipeBodyManagement(
    objMachineRecipe_GetListForRecipeBodyManagement_out&       strMachineRecipe_GetListForRecipeBodyManagement_out,
    const pptObjCommonIn&                                      strObjCommonIn,
    const objMachineRecipe_GetListForRecipeBodyManagement_in&  strMachineRecipe_GetListForRecipeBodyManagement_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::machineRecipe_GetListForRecipeBodyManagement");

        //----------------
        //                
        //   Initialize   
        //                
        //----------------
        CORBA::Long rc = RC_OK;
        objectIdentifier equipmentID;
        pptStartCassetteSequence strStartCassette;
        equipmentID      = strMachineRecipe_GetListForRecipeBodyManagement_in.equipmentID;
        strStartCassette = strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette;
        CORBA::Long startCassetteLen = strStartCassette.length();

        PPT_METHODTRACE_V2( "","in-parm's equipmentID     ", strMachineRecipe_GetListForRecipeBodyManagement_in.equipmentID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's strStartCassette", startCassetteLen);

        pptRecipeBodyManagementSeq    strRecipeBodyManagementSeq;
        strRecipeBodyManagementSeq.length(0);
        strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq.length(0);

        if( 0 == startCassetteLen)
        {
            PPT_METHODTRACE_V1( "","in-parm's strStartCassette is no-data.");
            SET_MSG_RC(strMachineRecipe_GetListForRecipeBodyManagement_out, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER);
            return RC_INVALID_PARAMETER;
        }

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        //--------------------------------
        //   Get Equipment's OnlineMode   
        //--------------------------------
        objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
        rc = portResource_currentOperationMode_Get(strPortResource_currentOperationMode_Get_out, strObjCommonIn, equipmentID, strStartCassette[0].loadPortID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get != RC_OK");
            strMachineRecipe_GetListForRecipeBodyManagement_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
            return(rc);
        }

        PPT_METHODTRACE_V2("", "Online Mode Status is ", strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode);
        CORBA::String_var onlineMode = strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode;

        if( 0 != CIMFWStrCmp(onlineMode,SP_Eqp_OnlineMode_Offline ) )
        {
            //-----------------------------------------
            //   Get Equipment's Recipe Manage Flag   
            //-----------------------------------------
            objEquipment_recipeBodyManageFlag_Get_out strEquipment_recipeBodyManageFlag_Get_out;
            rc = equipment_recipeBodyManageFlag_Get(strEquipment_recipeBodyManageFlag_Get_out, strObjCommonIn, equipmentID);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_recipeBodyManageFlag_Get != RC_OK");
                strMachineRecipe_GetListForRecipeBodyManagement_out.strResult = strEquipment_recipeBodyManageFlag_Get_out.strResult;
                return(rc);
            }

            PPT_METHODTRACE_V2("", "The equipment's recipeBodyManageFlag", (strEquipment_recipeBodyManageFlag_Get_out.recipeBodyManageFlag?"True":"False"));
            CORBA::Boolean recipeBodyManageFlag = strEquipment_recipeBodyManageFlag_Get_out.recipeBodyManageFlag;

            if( TRUE == recipeBodyManageFlag )
            {
                 PPT_METHODTRACE_V1("", "recipeBodyManageFlag == TRUE");
                //------------------------------------------------------
                //   Get Machine Recipe List for Recipe Body Management
                //------------------------------------------------------
                CORBA::Long machineRcpCnt = 0;
               
                for ( CORBA::Long i=0 ; i<startCassetteLen ; i++)
                {
                    PPT_METHODTRACE_V3("", "loop to strStartCassette.length()",startCassetteLen,i);
                    CORBA::Long LotInCassetteLength = strStartCassette[i].strLotInCassette.length();
                    for (CORBA::Long j=0 ; j<LotInCassetteLength ; j++)
                    {
                        PPT_METHODTRACE_V3("CS_PPTManager_i::machineRecipe_GetListForRecipeBodyManagement", "loop to trStartCassette[i].strLotInCassette.length()",LotInCassetteLength,j);
                        CORBA::Boolean operationStartFlag = strStartCassette[i].strLotInCassette[j].operationStartFlag;
                        if ( FALSE == operationStartFlag )
                        {
                            PPT_METHODTRACE_V1("", "operationStartFlag == FALSE. continue.");
                            continue;
                        }

                        //------------------------------------------------
                        //   GetMachine Recipe's RecipeBodyConfirm Flag   
                        //------------------------------------------------
                        PosMachineRecipe_var aMachineRecipe;

                        if ( 0 == CIMFWStrLen(strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier))
                        {
                            //===== get Lot Object =====//
                            PosLot_var aLot;
                            PPT_CONVERT_LOTID_TO_LOT_OR(aLot, strStartCassette[i].strLotInCassette[j].lotID, 
                                                        strMachineRecipe_GetListForRecipeBodyManagement_out,machineRecipe_GetListForRecipeBodyManagement);
                            //===== get LotType =====//
                            CORBA::String_var subLotType;
                            try
                            {
                                subLotType = aLot->getSubLotType();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);

                            //===== get ProdSpec =====//
                            ProductSpecification_var    aBaseProdSpec;
                            PosProductSpecification_var aProdSpec;
                            try
                            {
                                aBaseProdSpec = aLot->getProductSpecification();
                                aProdSpec     = PosProductSpecification::_narrow(aBaseProdSpec);
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

                            if ( CORBA::is_nil(aProdSpec) == TRUE )
                            {
                                PPT_METHODTRACE_V1( "", "aProdSpec is nil" );
                                SET_MSG_RC(strMachineRecipe_GetListForRecipeBodyManagement_out, MSG_NOT_FOUND_PRODUCTSPEC, RC_NOT_FOUND_PRODUCTSPEC);
                                return( RC_NOT_FOUND_PRODUCTSPEC );
                            }

                            //===== get PO Object =====//
                            ProcessOperation_var    aBasePO;
                            PosProcessOperation_var aPO;
                            try
                            {
                                aBasePO = aLot->getProcessOperation();
                                aPO     = PosProcessOperation::_narrow(aBasePO);
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

                            if ( CORBA::is_nil(aPO) == TRUE )
                            {
                                PPT_METHODTRACE_V1( "", "aPO is nil" );
                                PPT_SET_MSG_RC_KEY2(strMachineRecipe_GetListForRecipeBodyManagement_out,
                                                    MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "*****", 
                                                    strStartCassette[i].strLotInCassette[j].lotID.identifier);
                                return(RC_NOT_FOUND_PO);
                            }

                            //===== get LogicalRecipe Object =====//
                            PosLogicalRecipe_var aLogicalRecipe;
                            try
                            {
                                aLogicalRecipe = aPO->findLogicalRecipeFor(aProdSpec);
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findLogicalRecipeFor);

                            if ( CORBA::is_nil(aLogicalRecipe) == TRUE )
                            {
                                PPT_METHODTRACE_V1( "", "aLogicalRecipe is nil" );
                                SET_MSG_RC(strMachineRecipe_GetListForRecipeBodyManagement_out, MSG_NOT_FOUND_LCRECIPE, RC_NOT_FOUND_LCRECIPE);
                                return( RC_NOT_FOUND_LCRECIPE );
                            }

                            //===== get Machine Object =====//
                            PosMachine_var aMachine;
                            PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine, equipmentID, strMachineRecipe_GetListForRecipeBodyManagement_out,machineRecipe_GetListForRecipeBodyManagement);

                            //===== get MachineRecipe Object =====//
                            if( searchCondition == 1 )                                                       //DSIV00001443
                            {                                                                                //DSIV00001443
                                try                                                                          //DSIV00001443
                                {                                                                            //DSIV00001443
                                    aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine ); //DSIV00001443
                                }                                                                            //DSIV00001443
                                CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)           //DSIV00001443
                            }                                                                                //DSIV00001443
                            else                                                                             //DSIV00001443
                            {                                                                                //DSIV00001443
                                try
                                {
                                    aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType(aMachine, subLotType);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType);
                            }                                                                                //DSIV00001443

                            if ( CORBA::is_nil(aMachineRecipe) == TRUE )
                            {
                                PPT_METHODTRACE_V1( "", "aMachineRecipe is nil" );
                                SET_MSG_RC(strMachineRecipe_GetListForRecipeBodyManagement_out, MSG_NOT_FOUND_MCRECIPE, RC_NOT_FOUND_MCRECIPE);
                                return( RC_NOT_FOUND_MCRECIPE );
                            }
                        }
                        else
                        {
                            PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR(aMachineRecipe, strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
                                                                     strMachineRecipe_GetListForRecipeBodyManagement_out,machineRecipe_GetListForRecipeBodyManagement);
                        }

                        //------------------------------------
                        // Get Recipe Body Management Info.
                        //------------------------------------
                        PPT_METHODTRACE_V1( "", "Get Recipe Body Management Info." );
                        CORBA::String_var tmpMachineRecipeID;
                        CORBA::String_var physicalRecipeID;
                        CORBA::String_var fileLocation;
                        CORBA::String_var fileName;
                        CORBA::Boolean formatFlag              = FALSE;
                        CORBA::Boolean forceDownLoadFlag       = FALSE;
                        CORBA::Boolean recipeBodyConfirmFlag   = FALSE;
                        CORBA::Boolean conditionalDownLoadFlag = FALSE;
                        tmpMachineRecipeID = CIMFWStrDup("");
                        physicalRecipeID   = CIMFWStrDup("");
                        fileLocation       = CIMFWStrDup("");
                        fileName           = CIMFWStrDup("");

                        try
                        {
                            tmpMachineRecipeID     = aMachineRecipe->getIdentifier();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getIdentifier);

                        try
                        {
                            physicalRecipeID = aMachineRecipe->getPhysicalRecipeId();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getPhysicalRecipeId);

                        try
                        {
                            fileLocation = aMachineRecipe->getRecipeBodyFileLocation();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getRecipeBodyFileLocation);
            
                        try
                        {
                            fileName = aMachineRecipe->getRecipeBodyFileName();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getRecipeBodyFileName);
            
                        try
                        {
                            formatFlag = aMachineRecipe->isFormatFlagOn();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::isFormatFlagOn);

                        try
                        {
                            forceDownLoadFlag     = aMachineRecipe->isForceDownloadFlagOn();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::isForceDownloadFlagOn);

//INN-A170001                        try
//INN-A170001                        {
//INN-A170001                            recipeBodyConfirmFlag = aMachineRecipe->isRecipeBodyConfirmFlagOn();
//INN-A170001                        }
//INN-A170001                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::isRecipeBodyConfirmFlagOn);

                        //INN-A170001 Add Start
                        /*------------------------------------------------*/
                        /*   GetMachine Recipe's RecipeBodyConfirm Flag   */
                        /*------------------------------------------------*/
                        CORBA::String_var varRecipeBodyConFirmFlag;
                        try
                        {
                            varRecipeBodyConFirmFlag = aMachineRecipe->getUserDataNamed( CS_M_RECIPEBODYCONFIRM_FLAG );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getUserDataNamed)
                        
                        PPT_METHODTRACE_V2("", "CS_M_RECIPEBODYCONFIRM_FLAG = ", varRecipeBodyConFirmFlag);
                        if( 0 == CIMFWStrCmp( varRecipeBodyConFirmFlag , "0" ) )
                        {
                            recipeBodyConfirmFlag = FALSE;
                        }
                        else //default
                        {
                            recipeBodyConfirmFlag = TRUE;
                        }
                        //INN-A170001 Add End
        
                        try
                        {
                            conditionalDownLoadFlag = aMachineRecipe->isConditionalDownloadFlagOn();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::isConditionalDownloadFlagOn);


                        PPT_METHODTRACE_V2(""," Machine Recipe ID          ", (const char*)tmpMachineRecipeID);
                        PPT_METHODTRACE_V2(""," Physical Recipe ID         ", (const char*)physicalRecipeID);
                        PPT_METHODTRACE_V2(""," File Location              ", (const char*)fileLocation);
                        PPT_METHODTRACE_V2(""," File Name                  ", (const char*)fileName);
                        PPT_METHODTRACE_V2(""," Format Flag                ", (formatFlag?"True":"False"));
                        PPT_METHODTRACE_V2(""," Force Down Load Flag       ", (forceDownLoadFlag?"True":"False"));
                        PPT_METHODTRACE_V2(""," Recipe Body Confirm Flag   ", (recipeBodyConfirmFlag?"True":"False"));
                        PPT_METHODTRACE_V2(""," Conditional Down Load Flag ", (conditionalDownLoadFlag?"True":"False"));

                        PPT_METHODTRACE_V1("","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                        PPT_METHODTRACE_V1("","Only Machine Recipe needs support are colledted.");
                        if( TRUE == forceDownLoadFlag || TRUE == recipeBodyConfirmFlag )
                        {
                            // Add to machineRecipeID list.
                            CORBA::Boolean foundFlag = FALSE;
                            for(CORBA::Long k = 0; k< machineRcpCnt; k++)
                            {
                                if(0 == CIMFWStrCmp(strRecipeBodyManagementSeq[k].machineRecipeID.identifier, tmpMachineRecipeID) )
                                {
                                    foundFlag = TRUE;
                                    break;
                                }
                            }
                            if( FALSE == foundFlag )
                            {
                                // Add
                                PPT_METHODTRACE_V3("","Add to machineRecipeID list", (const char*)tmpMachineRecipeID, machineRcpCnt);
                                strRecipeBodyManagementSeq.length(machineRcpCnt + 1 );

                                strRecipeBodyManagementSeq[machineRcpCnt].machineRecipeID.identifier    = CIMFWStrDup(tmpMachineRecipeID);
                                strRecipeBodyManagementSeq[machineRcpCnt].physicalRecipeID              = CIMFWStrDup(physicalRecipeID);
                                strRecipeBodyManagementSeq[machineRcpCnt].fileLocation                  = CIMFWStrDup(fileLocation);
                                strRecipeBodyManagementSeq[machineRcpCnt].fileName                      = CIMFWStrDup(fileName);
                                strRecipeBodyManagementSeq[machineRcpCnt].formatFlag                    = formatFlag;
                                strRecipeBodyManagementSeq[machineRcpCnt].forceDownLoadFlag             = forceDownLoadFlag;
                                strRecipeBodyManagementSeq[machineRcpCnt].recipeBodyConfirmFlag         = recipeBodyConfirmFlag;
                                strRecipeBodyManagementSeq[machineRcpCnt++].conditionalDownLoadFlag     = conditionalDownLoadFlag;
                            }
                        }
                    }//Loop of lotInCassette
                }//Loop of strStartCassette
            }//recipeBodyManageFlag
        }//Online Mode Status

        //-------------------------
        // Set to return structure
        //-------------------------
        strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq = strRecipeBodyManagementSeq;

        //----------------------
        //   Return to Caller   
        //----------------------
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::machineRecipe_GetListForRecipeBodyManagement");
        return(rc);

    }
    CATCH_GLOBAL_EXCEPTIONS(strMachineRecipe_GetListForRecipeBodyManagement_out, machineRecipe_GetListForRecipeBodyManagement, methodName);

}
