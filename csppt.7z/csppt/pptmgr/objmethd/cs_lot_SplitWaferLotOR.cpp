#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/objmethd/lot_SplitWaferLot.cpp, mm_srv_120e_ppt, mm_srv_120e_ppt 2/21/08 14:28:22 [ 2/21/08 14:28:24 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: lot_SplitWaferLot.cpp
//

//INN-R170002 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-R170002

#include "pcatgry.hh"
#include "pcode.hh"
#include "pflwbch.hh"
#include "pcas.hh"
#include "pmc.hh"
#include "ppcdf.hh"
#include "ppcflw.hh"
#include "ppcflwx.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "plot.hh"
#include "pmongrp.hh"
//D5000016 #include "ppcgrp.hh"
#include "pprmggl.hh"
#include "pwafer.hh"
#include "pprsp.hh"
#include "ptestsp.hh"
#include "ptesttp.hh"
#include "pperson.hh"
#include "plcrc.hh"
#include "pportrs.hh"
#include "pmcrc.hh"
#include "pemonj.hh"   //DSN000081739
#include "pqtime.hh"   //DSN000085792

//[Object Function Name]: long   lot_SplitWaferLot
//
// Date        Level    Author         Note
// ----------  -------  -------------  -------------------------------------------
// 2000-08-03  0.00     H.Uea          Initial Release     (R30)
// 2000-09-11  0.01     H.Uea          Add addWafer_atPosition();
// 2000/10/18  P3000274 K.Matsuei      Bug fix Scrap Control Lot count
// 2000/11/10  P2200204 R.Furuta       Initialize local pointers
// 2001/05/09  P3100321 K.Kido         Call Lot_controlUseInfo_Change 
// 2001/11/12  P40A0005 K.Kido         Add exception catch logic.
// 2002/01/10  P4100064 M.Ameshita     Fix to set reticle set ID to child lot.
// 2002/02/25  D4100108 C.Tsuchiya     Add LotID assign logic
// 2002/12/17  P4200427 S.Yamamoto     Fix : ObjRef count managed incorrect.
// 2003/05/20  D5000016 K.Kido         Useless class deletion(R5.0).
// 2003/09/09  P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2005/02/22  D6000159 H.Hasegawa     Delete a useless logic which catches FrameworkErrorSignal.
//                                     (The modification by P40A0005 is removed. A handled error code has already been deleted.)
// 2005/09/14  P6000632 H.Hasegawa     Fix the logic which renews the parent lot's queue.
// 2006/03/15  P7000158 F.Masada       Fix to set the cassette's wafer count correctly.
// 2007/06/08  D9000038 D.Tamura       Skip to call the cassette's methods, if the lot is not in a cassette
// 2008/02/21  P9000222 H.Hotta        Control re-queue of parent lot for Split/Partial Rework
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/30 DSIV00000214 K.Kido         Multi Fab Transfer Support
// 2011/09/16 DSN000015229 F.Chen         Copy controlJobID from parent to child when split
// 2011/09/27 DSN000020767 T.Ishida       Auto Dispatch Control Support
// 2013/09/04 DSN000081739 Sa Guo         Equipment Monitor Automation Support
// 2014/10/28 DSN000085792 Shudi Wang     Q-Time Improvements.
// 2016/01/20 DSN000100682 K.Yamaoku      QTime Action Replacement
//
// Innotron Modification history :
// Date        Defect#       Person            Comments
// ----------  ------------  -------------- -------------------------------------------
// 2017/09/06  INN-R170002   Thomas Song    Contamination control

//
//[Function Description]:
//  1) Remove parent lot from queue.
//  2) Create child.
//  3) Add parent lot and child lot to queue.
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  objectIdentifier  parentLotID;
//  in  objectIdentifierSequence childWaferID;
//
//[Output Parameters]:
//
//  out objLot_SplitWaferLot_out  strLot_SplitWaferLot_out;
//
//  typedef struct objLot_SplitWaferLot_out_struct {
//     pptRetCode        strResult;
//     objectIdentifier  childLotID;
//  } objLot_SplitWaferLot_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_LOT          MSG_NOT_FOUND_LOT
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//  RC_PRODUCT_COUNT_ZERO     MSG_PRODUCT_COUNT_ZERO
//  RC_INVALID_DATA_CONTENTS  MSG_INVALID_DATA_CONTENTS
//  RC_NOT_FOUND_WAFER        MSG_NOT_FOUND_WAFER
//  RC_NOT_FOUND              MSG_NOT_FOUND
//
//  other return code may be from other function called from this function.
//
//[Pseudo Code]
//

CORBA::Long CS_PPTManager_i::lot_SplitWaferLot(
                            objLot_SplitWaferLot_out& strLot_SplitWaferLot_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& parentLotID,
                            const objectIdentifierSequence& childWaferID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_SplitWaferLot");

        CORBA::Long rc;                //P3100321

//P9000222 add start
        // Get environment variable
        CORBA::String_var requeueFlag = CIMFWStrDup( getenv(SP_SPLIT_LOT_REQUEUE_FLAG) );
        PPT_METHODTRACE_V2("", "SP_SPLIT_LOT_REQUEUE_FLAG", requeueFlag);
//P9000222 add end

        PosLot_var aParentLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aParentLot,
                                     parentLotID,
                                     strLot_SplitWaferLot_out,
                                     lot_SplitWaferLot );

        //--------------------------------------------
        // Check real lot wafer quantity and
        //  input parameter is consistent or not
        //--------------------------------------------
        PPT_METHODTRACE_V1("","Check real lot wafer quantity and input parameter is consistent or not");

        CORBA::Long parentLotTotalQuantity;
        CORBA::Long parentLotProductQuantity;
        try
        {
            parentLotTotalQuantity = aParentLot->getQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQuantity)
        try
        {
            parentLotProductQuantity = aParentLot->getProductQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductQuantity)
//P3000274 add start
        CORBA::Long parentLotControlQuantity;
        try
        {
            parentLotControlQuantity = aParentLot->getControlQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlQuantity)

        PPT_METHODTRACE_V2("","aParentLot->getQuantity", parentLotTotalQuantity);
        PPT_METHODTRACE_V2("","aParentLot->getProductQuantity", parentLotProductQuantity);
        PPT_METHODTRACE_V2("","aParentLot->getControlQuantity", parentLotControlQuantity);
//P3000274 add end

//P3100321 add start
        CORBA::String_var tmpControlUseState;
        try
        {
            tmpControlUseState = aParentLot->getControlUseState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlUseState);

        CORBA::Long       tmpUsageCount;
        try
        {
            tmpUsageCount = aParentLot->getUsedCount();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getUsedCount);

        PPT_METHODTRACE_V2("","aParentLot->getUsageCount",tmpUsageCount);
        PPT_METHODTRACE_V2("","aParentLot->tmpControlUseState",tmpControlUseState);
//P3100321 add end

        //----------------------------------
        // Check Wafer attributes
        //----------------------------------
        PPT_METHODTRACE_V1("","Check Wafer attributes");

        // Get all wafer information of Parent Lot
        PosWaferInfoSequence* parentLotWaferInfo = NULL; //P2200204
        PosWaferInfoSequence_var parentLotWaferInfoVar;
        try
        {
            PPT_METHODTRACE_V1("", "Get all wafer information of parent lot before split.")
            parentLotWaferInfo = aParentLot->getAllWaferInfo();
            parentLotWaferInfoVar = parentLotWaferInfo;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getAllWaferInfo)

        CORBA::Long parent_wafer_count = parentLotWaferInfo->length();
        PPT_METHODTRACE_V2("","parentLotWaferInfo->length", parent_wafer_count);
        if ( parent_wafer_count == 0 )
        {
            SET_MSG_RC( strLot_SplitWaferLot_out,
                        MSG_PRODUCT_COUNT_ZERO,
                        RC_PRODUCT_COUNT_ZERO );

            return RC_PRODUCT_COUNT_ZERO;
        }

        // Check childWaferID of in-parameter in Wafer Attributes.
        PPT_METHODTRACE_V1("","Check childWaferID of in-parameter in Wafer Attributes");

        CORBA::Boolean foundFlag;
        CORBA::Long lenChildWafer = childWaferID.length();
        CORBA::Long i, j;
        PPT_METHODTRACE_V2("","childWafer length = ", lenChildWafer);
        for( i=0; i < lenChildWafer; i++ )
        {
            PPT_METHODTRACE_V2("","childWaferID", childWaferID[i].identifier);

            foundFlag = FALSE;
            for( j=0; j < parent_wafer_count; j++ )
            {
                PPT_METHODTRACE_V2("","IrrenWaferID", (*parentLotWaferInfo)[j].waferID.identifier);
                if( 0 == CIMFWStrCmp(childWaferID[i].identifier, (*parentLotWaferInfo)[j].waferID.identifier) )
                {
                    PPT_METHODTRACE_V1("","childWaferID[i] == (*parentLotWaferInfo)[j].waferID");

                    foundFlag = TRUE;
                    break;
                }
            }
            if ( foundFlag == FALSE )
            {
                PPT_METHODTRACE_V1("","foundFlag == FALSE");

                SET_MSG_RC( strLot_SplitWaferLot_out,
                            MSG_INVALID_DATA_CONTENTS,
                            RC_INVALID_DATA_CONTENTS );

                return RC_INVALID_DATA_CONTENTS;
            }
        }

        //----------------------------------
        // Parent lot remove from queue
        //----------------------------------
        PPT_METHODTRACE_V1("","Parent lot remove from queue");

        CORBA::String_var aParentLotState;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aParentLotState = aParentLot->getLotState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotState)

        //P6000632 Add Start
        CORBA::String_var  aParentLotHoldState;
        try
        {
            aParentLotHoldState = aParentLot->getLotHoldState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState);
        //P6000632 Add End

        CORBA::Boolean isParentLotStateFinished = TRUE;
        if( CIMFWStrCmp( aParentLotState , CIMFW_Lot_State_Finished ) != 0)
        {
            isParentLotStateFinished = FALSE;
//P6000632            PPT_METHODTRACE_V1("", "isOnHoldFlag");
            if( CIMFWStrCmp( aParentLotHoldState, CIMFW_Lot_HoldState_OnHold ) != 0 )    //P6000632
            {                                                                            //P6000632
//P9000222 add start
                if( 0 == CIMFWStrCmp( requeueFlag, "1" ) )
                {
                    PPT_METHODTRACE_V1("", "SP_SPLIT_LOT_REQUEUE_FLAG is ON.");
//P9000222 add end
                    try
                    {
                        PPT_DISPLAY_RESPONSE_TIME();
                        theDispatchingManager->removeFromQueue( aParentLot );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosDispathingManager::removeFromQueue)

                }  //P9000222
            }                                                                            //P6000632
        }

        //----------------------------------
        // Set wafer to productSequence.
        // In parameter lot is only one.
        //----------------------------------
        PPT_METHODTRACE_V1("","Set wafer to productSequence");

        ProductManager::splitDataSequence productToSplit(1);
        productToSplit.length(1);
        productToSplit[0].splitProducts.length(lenChildWafer);

//P3000274 add start
        CORBA::Long cntChildProductWafer = 0;
        CORBA::Long cntChildControlWafer = 0;
        CORBA::Boolean controlWaferFlag = FALSE;
//P3000274 add end

        for( i=0; i < lenChildWafer; i++ )
        {
            PosWafer_var aWafer;
            PPT_CONVERT_WAFERID_TO_WAFER_OR( aWafer,
                                             childWaferID[i],
                                             strLot_SplitWaferLot_out,
                                             lot_SplitWaferLot );

            productToSplit[0].splitProducts[i] = PosWafer::_duplicate(aWafer);

//P3000274 add start
            try
            {
                 controlWaferFlag = aWafer->isControlWafer() ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosWafer::isControlWafer)
            if ( TRUE == controlWaferFlag )
            {
                PPT_METHODTRACE_V1("","cntChildControlWafer++");
                cntChildControlWafer++;
            }
            else
            {
                PPT_METHODTRACE_V1("","cntChildProductWafer++");
                cntChildProductWafer++;
            }
//P3000274 add end
        }

        //-------------------------------                                                                              //0.01
        // Set length of output structure                                                                              //0.01
        //-------------------------------                                                                              //0.01
        MaterialContainerSequence*    aCassetteSequence = NULL;                                                        //0.01 //P2200204
        MaterialContainerSequence_var aCassetteSequenceVar;                                                            //0.01
        CORBA::Boolean bInCast = TRUE; //D9000038
                                                                                                                       //0.01
        try                                                                                                            //0.01
        {                                                                                                              //0.01
            aCassetteSequence = aParentLot->materialContainers();                                                      //0.01
            aCassetteSequenceVar = aCassetteSequence;                                                                  //0.01
        }                                                                                                              //0.01
        CATCH_AND_RAISE_EXCEPTIONS(ProductManager::materialContainers);                                                //0.01
        if (aCassetteSequence->length() == 0)                                                                          //0.01
        {                                                                                                              //0.01
//P5000145            PPT_SET_MSG_RC_KEY( strLot_SplitWaferLot_out,                                                              //0.01
//P5000145                                MSG_NOT_FOUND_CST,                                                                     //0.01
//P5000145                                RC_NOT_FOUND_CST, "" );
//D9000038            SET_MSG_RC( strLot_SplitWaferLot_out,                 //P5000145
//D9000038                        MSG_NOT_FOUND_CST, RC_NOT_FOUND_CST );    //P5000145
//D9000038            return RC_NOT_FOUND_CST;                                                                                   //0.01
            bInCast = FALSE; //D9000038
        }                                                                                                              //0.01
                                                                                                                       //0.01
//D9000038 add start
        PosCassette_var aCassette;
        if ( bInCast == TRUE )
        {
//D9000038 add end
//D9000038        PosCassette_var aCassette = PosCassette::_narrow((*aCassetteSequence)[0]);                                     //0.01
            aCassette = PosCassette::_narrow((*aCassetteSequence)[0]); //D9000038
//Q3000124 start
            if( CORBA::is_nil(aCassette))
            {
                PPT_SET_MSG_RC_KEY(strLot_SplitWaferLot_out, MSG_NOT_FOUND_CASSETTE , RC_NOT_FOUND_CASSETTE , "");
                return RC_NOT_FOUND_CASSETTE;
            }
//Q3000124 end
                                                                                                                       //0.01
            //  Remove wafer from aCassette tempolary, then add wafer to aParentCassette order by slotNumber of input trx. //0.01
            //P7000158 try                                                                                                            //0.01
            //P7000158 {                                                                                                              //0.01
            //P7000158     aCassette->removeLot(aParentLot);                                                                          //0.01
            //P7000158 }                                                                                                              //0.01
            //P7000158 CATCH_AND_RAISE_EXCEPTIONS(PosCassette::removeLot);                                                            //0.01
            //P7000158 start   
            for (i=0; i<parent_wafer_count; i++)
            {
                // Get obj ref and change state of wafer
                Wafer_var tmpWafer;
                try
                {
                    tmpWafer = aCassette->removeWafer_fromPosition((*parentLotWaferInfo)[i].position); 
                }
                catch(Cassette::PositionInvalidSignal)
                {
                    CORBA::String_var Array = ConvertLongtoString( (*parentLotWaferInfo)[i].position );
                    SET_FW_MSG_RC( strLot_SplitWaferLot_out,
                                   lot_SplitWaferLot,
                                   MSG_INVALID_CAST_POSITION,
                                   RC_INVALID_CAST_POSITION,
                                   Cassette::removeWafer_fromPosition,
                                   Cassette::PositionInvalidSignal,
                                   Array);
                    return (RC_INVALID_CAST_POSITION);
                }
                catch(Cassette::PositionEmptySignal)
                {
                    CORBA::String_var Array = ConvertLongtoString( (*parentLotWaferInfo)[i].position );
                    SET_FW_MSG_RC( strLot_SplitWaferLot_out,
                                   lot_SplitWaferLot,
                                   MSG_INVALID_CAST_POSITION,
                                   RC_INVALID_CAST_POSITION,
                                   Cassette::removeWafer_fromPosition,
                                   Cassette::PositionEmptySignal,
                                   Array);
                    return (RC_INVALID_CAST_POSITION);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::removeWafer_fromPosition)
            }
            //P7000158 end   
//D9000038 add start
        }
        else
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::lot_SplitWaferLot", "The Lot is not in a cassette. Skip Cassette::removeWafer_fromPosition()");
        }
//D9000038 add end

//D4100108 add start
        // Assign lot ID for child
        objLot_ID_Assign_out strLot_ID_Assign_out;
        rc = lot_ID_Assign( strLot_ID_Assign_out, strObjCommonIn, parentLotID );
        if( rc != RC_OK )
        {
            strLot_SplitWaferLot_out.strResult = strLot_ID_Assign_out.strResult;
            return rc;
        }
        else
        {
            // Set lot ID
            productToSplit[0].newLotID = strLot_ID_Assign_out.assignedLotID.identifier;
        }
//D4100108 add end

//DSIV00000214 add start
        //----------------------------------
        // Set wafer to productSequence.
        //----------------------------------
        const char* currentFabID = getenv(SP_SPLIT_FAB_ID);
        if( 0 != CIMFWStrLen(currentFabID) )
        {
            PPT_METHODTRACE_V2("", "Environment variable SP_SPLIT_FAB_ID is set. ==> ",currentFabID);
            //----------------------------------
            //  Seek "." (Ex SN000001.00S_f1)
            //                       ^
            //----------------------------------
            char* suffix = strrchr( (const char*)productToSplit[0].newLotID, '.' ) ;
            if( NULL != suffix )
            {
                suffix++;
            }
            
            //----------------------------------
            //  Seek "_" (Ex 00S_f1)
            //                  ^
            //----------------------------------
            char* suffix2 = strrchr( suffix, SP_InterFab_Split_FabID_Suffix) ;
            if( NULL != suffix2 )
            {
                suffix2[0] = NULL;
                PPT_METHODTRACE_V2("", " #### Base Lot ID. ==> ", productToSplit[0].newLotID );
            }

            ostrstream tmplotID;
            tmplotID << productToSplit[0].newLotID << SP_InterFab_Split_FabID_Suffix << currentFabID << ends;
            productToSplit[0].newLotID = CIMFWStrDup(tmplotID.str());
            PPT_METHODTRACE_V2("", " #### Created new Lot ID. ==> ", productToSplit[0].newLotID );
            tmplotID.rdbuf()->freeze(0);
        }
//DSIV00000214 add end

        // Create new lot(chaild lot)
        // createSplitLotsFrom is overridden in PosProductManager
        LotSequence* aLotSequence = NULL;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLotSequence = theProductManager->createSplitLotsFrom(aParentLot, productToSplit);
        }
//D6000159//P40A0005 add start
//D6000159        catch( FrameworkErrorSignal &fes )
//D6000159        {
//D6000159            if (fes.errorCode == SPFW_SPLITCOUNTREACHEDMAXSIGNAL)
//D6000159            {
//D6000159                PPT_METHODTRACE_V1("","Raise FrameWork Exception SPFW_SPLITCOUNTREACHEDMAXSIGNAL !!");
//D6000159                SET_MSG_RC( strLot_SplitWaferLot_out,
//D6000159                            MSG_REACHED_MAX_SPLIT_COUNT,
//D6000159                            RC_REACHED_MAX_SPLIT_COUNT);
//D6000159                return RC_REACHED_MAX_SPLIT_COUNT;
//D6000159            }
//D6000159        }
//D6000159//P40A0005 add end
        CATCH_AND_RAISE_EXCEPTIONS(ProductManager::createSplitLotsFrom)

        // Return child lot.
        PosLot_var aChildLot;
        LotSequence_var aTmpLotSequence;
        aTmpLotSequence = aLotSequence;

        if( aLotSequence->length() > 0 )
        {
            PPT_METHODTRACE_V1("","aLotSequence->length() > 0");

            aChildLot = PosLot::_narrow((*aLotSequence)[0]);
        }

        if ( CORBA::is_nil(aChildLot) )
        {
            PPT_METHODTRACE_V1("","aChildLot is nil");
            PPT_SET_MSG_RC_KEY( strLot_SplitWaferLot_out,
                                MSG_NOT_FOUND_LOT,
                                RC_NOT_FOUND_LOT, "" );

            return RC_NOT_FOUND_LOT;
        }

//D9000038 add start
        if ( bInCast == TRUE )
        {
//D9000038 add end
            // Start of L0.01
            //  Add parent and child wafers to aCassette in order to create FRCAST_LOT record for both of Lots.
            for (i=0; i<parent_wafer_count; i++)
            {
                // Get obj ref and change state of wafer
//P4200427  PosWafer_ptr aWafer = NULL; //P2200204
                PosWafer_var aWafer;        //P4200427
                PPT_CONVERT_WAFERID_TO_WAFER_OR( aWafer,
                                                 (*parentLotWaferInfo)[i].waferID,
                                                 strLot_SplitWaferLot_out,
                                                 lot_SplitWaferLot );
                try
                {
                    aCassette->addWafer_atPosition( aWafer , (*parentLotWaferInfo)[i].position );
                }
                catch(Cassette::WaferSizeInvalidSignal)
                {
                    SET_FW_MSG_RC( strLot_SplitWaferLot_out,
                                   lot_SplitWaferLot,
                                   MSG_INVALID_WAFER_SIZE,
                                   RC_INVALID_WAFER_SIZE,
                                   Cassette::addWafer_atPosition,
                                   Cassette::WaferSizeInvalidSignal,
                                   "*****" );
                    return (RC_INVALID_WAFER_SIZE);
                }
                catch(Cassette::PositionOccupiedSignal)
                {
                    CORBA::String_var Array = ConvertLongtoString( (*parentLotWaferInfo)[i].position );
                    SET_FW_MSG_RC( strLot_SplitWaferLot_out,
                                   lot_SplitWaferLot,
                                   MSG_DUPLICATE_SLOTNO,
                                   RC_DUPLICATE_SLOTNO,
                                   Cassette::addWafer_atPosition,
                                   Cassette::PositionOccupiedSignal,
                                   Array);
                    return (RC_DUPLICATE_SLOTNO);
                }
                catch(Cassette::PositionInvalidSignal)
                {
                    CORBA::String_var Array = ConvertLongtoString( (*parentLotWaferInfo)[i].position );
                    SET_FW_MSG_RC( strLot_SplitWaferLot_out,
                                   lot_SplitWaferLot,
                                   MSG_INVALID_CAST_POSITION,
                                   RC_INVALID_CAST_POSITION,
                                   Cassette::addWafer_atPosition,
                                   Cassette::PositionInvalidSignal,
                                   Array);
                    return (RC_INVALID_CAST_POSITION);
                }
                CATCH_AND_RAISE_EXCEPTIONS(Cassette::addWafer_atPosition);
            }
            // End of L0.01
//D9000038 add start
        }
        else
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::lot_SplitWaferLot", "The Lot is not in a cassette. Skip Cassette::addWafer_atPosition()");
        }
//D9000038 add end

        //----------------------------------------------------------------------------------------------------
        // change total wafer quantity of both parent lot and child lot.
        //  ParentLot.theQuantity   <= parentLotTotalQuantity - the length of childWaferID sequence of in-parameter.
        //  ChildLot.theQuantity    <= the length of childLotWaferCount of in-parameter.
        //----------------------------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("","change total wafer quantity of both parent lot and child lot");

        CORBA::Long newTotalQuantity = parentLotTotalQuantity - lenChildWafer;
        PPT_METHODTRACE_V2("","newTotalQuantity--->", newTotalQuantity);
        if(newTotalQuantity == 0)
        {
            PPT_METHODTRACE_V1("","If accept this claim, Parent Lot become empty!")
            SET_MSG_RC( strLot_SplitWaferLot_out,
                        MSG_PLOT_EMPTY_SPLIT,
                        RC_PLOT_EMPTY_SPLIT );
            return RC_PLOT_EMPTY_SPLIT;
        }
        try
        {
            aParentLot->setVendorLotQuantity(newTotalQuantity);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setVendorLotQuantity)
        try
        {
            aChildLot->setVendorLotQuantity(lenChildWafer);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setVendorLotQuantity)

        //----------------------------------------------------------------------------------------------------   //P4100064
        // Set reticle set ID                                                                                    //P4100064
        //----------------------------------------------------------------------------------------------------   //P4100064
        PosReticleSet_var aReticleSet ;                                                                          //P4100064
        try                                                                                                      //P4100064
        {                                                                                                        //P4100064
            aReticleSet = aParentLot->getReticleSet();                                                           //P4100064
        }                                                                                                        //P4100064
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getReticleSet)                                                        //P4100064
                                                                                                                 //P4100064
        if( !CORBA::is_nil( aReticleSet ) )                                                                      //P4100064
        {                                                                                                        //P4100064
            try                                                                                                  //P4100064
            {                                                                                                    //P4100064
                PPT_METHODTRACE_V1("","Set reticle set ID into Child Lot.");                                     //P4100064
                aChildLot->setReticleSet( aReticleSet );                                                         //P4100064
            }                                                                                                    //P4100064
            CATCH_AND_RAISE_EXCEPTIONS( PosLot::setReticleSet )                                                  //P4100064
        }                                                                                                        //P4100064
        else                                                                                                     //P4100064
        {                                                                                                        //P4100064
            PPT_METHODTRACE_V1("","Parent lot has no reticle set ID.");                                          //P4100064
        }                                                                                                        //P4100064
//DSN000015229 Add Start
        // Copy controlJobID of parent lot to child lot
        PosControlJob_var aControlJob;
        try
        {
            aControlJob = aParentLot->getControlJob();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlJob)
        try
        {
            aChildLot->setControlJob(aControlJob);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlJob)

        if ( !CORBA::is_nil( aControlJob ) )
        {
            PPT_METHODTRACE_V1("", "!CORBA::is_nil( aControlJob )");
            objectIdentifier aChildLotID;
            PPT_SET_OBJECT_IDENTIFIER( aChildLotID,
                                       aChildLot,
                                       strLot_SplitWaferLot_out,
                                       lot_SplitWaferLot,
                                       PosLot );

            PPT_METHODTRACE_V2("", "Child Lot", aChildLotID.identifier);

            // Get Lot List In ControlJob Object
            PosLotInControlJobInfoSequence_var aPosLotInControlJobInfoSeq;
            try
            {
                aPosLotInControlJobInfoSeq = aControlJob->allControlJobLots();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::allControlJobLots);

            CORBA::ULong lotListLen = aPosLotInControlJobInfoSeq->length();
            PPT_METHODTRACE_V2("", "lotListLen", lotListLen);

            for( CORBA::ULong lotListNum = 0; lotListNum < lotListLen; lotListNum++ )
            {
                PPT_METHODTRACE_V4("", "lotListLen/lotListNum", lotListLen, lotListNum, (*aPosLotInControlJobInfoSeq)[lotListNum].lotID.identifier);
                if ( 0 == CIMFWStrCmp( parentLotID.identifier, (*aPosLotInControlJobInfoSeq)[lotListNum].lotID.identifier ) )
                {
                    PPT_METHODTRACE_V2("", "Add ControlJobLot", aChildLotID.identifier);
                    posLotInControlJobInfo strLotInCJInfo = (*aPosLotInControlJobInfoSeq)[lotListNum];
                    strLotInCJInfo.lotID = aChildLotID;
                    try
                    {
                        aControlJob->addControlJobLot( strLotInCJInfo );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::addControlJobLot);
                }
            }
        }
//DSN000015229 Add End

        //----------------------------------------------------------------------------------------------------
        // change the number of wafer which has waferID in itself.
        //  ParentLot.theProductQuantity <= parentLotTotalQuantity - the length of childWaferID sequence of in-parameter.
        //  ChildLot.theProductQuantity  <= the length of childWaferID of in-parameter.
        //----------------------------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("","change the number of wafer which has waferID in itself");

//P3000274        CORBA::Long newProductQuantity = parentLotProductQuantity - lenChildWafer;
        try
        {
//P3000274  aParentLot->setProductQuantity(newProductQuantity);
            PPT_METHODTRACE_V2("", "aParentLot->setProductQuantity--->", parentLotProductQuantity - cntChildProductWafer);
            aParentLot->setProductQuantity(parentLotProductQuantity - cntChildProductWafer);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setProductQuantity)
//P3000274 add start
        try
        {
            PPT_METHODTRACE_V2("", "aParentLot->setControlQuantity--->", parentLotControlQuantity - cntChildControlWafer);
            aParentLot->setControlQuantity(parentLotControlQuantity - cntChildControlWafer);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setControlQuantity)
//P3000274 add end

        try
        {
            PPT_METHODTRACE_V2("", "aChildLot->setProductQuantity--->", cntChildProductWafer);
//P3000274  aChildLot->setProductQuantity(lenChildWafer);
            aChildLot->setProductQuantity(cntChildProductWafer);   //P3000274
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setProductQuantity)
//P3000274 add start
        try
        {
            PPT_METHODTRACE_V2("", "aChildLot->setControlQuantity--->", cntChildControlWafer);
            aChildLot->setControlQuantity(cntChildControlWafer);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setControlQuantity)
//P3000274 add end

        try
        {
            aParentLot->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedTimeStamp)

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID( aPerson,
                                    strObjCommonIn.strUser.userID,
                                    strLot_SplitWaferLot_out,
                                    lot_SplitWaferLot );

        try
        {
            aParentLot->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setLastClaimedPerson)

        // Set claim information for child lot.
        try
        {
            aChildLot->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedTimeStamp)
        try
        {
            aChildLot->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setLastClaimedPerson)
        try
        {
            aChildLot->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setStateChangedTimeStamp)
        try
        {
            aChildLot->setStateChangedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setStateChangedPerson)
        try
        {
            aChildLot->setInventoryStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setInventoryStateChangedTimeStamp)
        try
        {
            aChildLot->setInventoryStateChangedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setInventoryStateChangedPerson)
        try
        {
            aChildLot->setLastClaimAllWafers(strObjCommonIn.strTimeStamp.reportTimeStamp, aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setLastClaimAllWafers)

//DSIV00000214 add start
        //--------------------------------------------------
        //  Set parent Lot InterFab Xfer Plan  to Child Lot
        //--------------------------------------------------
        objInterFab_xferPlanList_GetDR_out strInterFab_xferPlanList_GetDR_out;

        objInterFab_xferPlanList_GetDR_in  strInterFab_xferPlanList_GetDR_in;
        strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.lotID = parentLotID ;

        rc = interFab_xferPlanList_GetDR( strInterFab_xferPlanList_GetDR_out, strObjCommonIn,
                                          strInterFab_xferPlanList_GetDR_in );

        if( rc != RC_OK && rc != RC_INTERFAB_NOT_FOUND_XFERPLAN )
        {
            PPT_METHODTRACE_V2(""," #### interFab_xferPlanList_GetDR != RC_OK : rc = ", rc );
            strLot_SplitWaferLot_out.strResult = strInterFab_xferPlanList_GetDR_out.strResult;
            return rc;
        }

        if(0 != strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length() )
        {
            PPT_METHODTRACE_V1(""," #### Parent Lot has InterFabXfer plan. Set it to child Lot." );
            CORBA::ULong planLen = strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length();
            for( CORBA::ULong i = 0 ; i < planLen ; i++ )
            {
                objInterFab_xferPlan_InsertDR_out strInterFab_xferPlan_InsertDR_out;

                objInterFab_xferPlan_InsertDR_in  strInterFab_xferPlan_InsertDR_in;
                strInterFab_xferPlan_InsertDR_in.strInterFabLotXferPlanInfo = strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[i];
                PPT_SET_OBJECT_IDENTIFIER( strInterFab_xferPlan_InsertDR_in.strInterFabLotXferPlanInfo.lotID,
                                           aChildLot,
                                           strLot_SplitWaferLot_out,
                                           lot_SplitWaferLot,
                                           PosLot );

                rc = interFab_xferPlan_InsertDR( strInterFab_xferPlan_InsertDR_out,
                                                 strObjCommonIn,
                                                 strInterFab_xferPlan_InsertDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### interFab_xferPlan_InsertDR() != RC_OK", rc);
                    strLot_SplitWaferLot_out.strResult = strInterFab_xferPlan_InsertDR_out.strResult;
                    return( rc );
                }
            }
        }
//DSIV00000214 add end

//P3100321 add start
        objectIdentifier    tmpChildLotID;

        PPT_SET_OBJECT_IDENTIFIER( tmpChildLotID,
                                   aChildLot,
                                   strLot_SplitWaferLot_out,
                                   lot_SplitWaferLot,
                                   PosLot );

//R170002 add start
        //-------------------------------------------------------
        //  Copy Contamination information from Parent Lot to Child Lot
        //-------------------------------------------------------
        csObjLot_udata_CopyToChild_in strLot_udata_CopyToChild_in;
        strLot_udata_CopyToChild_in.parentLotID = parentLotID;
        strLot_udata_CopyToChild_in.childLotID  = tmpChildLotID;

        csObjLot_udata_CopyToChild_out strLot_udata_CopyToChild_out;
        rc = cs_lot_udata_CopyToChild( strLot_udata_CopyToChild_out,
                                       strObjCommonIn,
                                       strLot_udata_CopyToChild_in );
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "cs_lot_udata_CopyToChild() rc != RC_OK", rc);
            strLot_SplitWaferLot_out.strResult = strLot_udata_CopyToChild_out.strResult;
            return( rc );
        }
//R170002 add end

//DSN000020767 Add Start
        //-------------------------------------------------------
        //  Set parent Lot Auto Dispatch Control to Child Lot
        //-------------------------------------------------------
        PosAutoDispatchControlRecordSequence* autoDispatchControlRecordSeq = NULL;
        PosAutoDispatchControlRecordSequence_var autoDispatchControlRecordSeqVar;
        try
        {
            autoDispatchControlRecordSeq    = aParentLot->allAutoDispatchControlRecords();
            autoDispatchControlRecordSeqVar = autoDispatchControlRecordSeq;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::allAutoDispatchControlRecords)

        try
        {
            aChildLot->setAutoDispatchControlRecords( (*autoDispatchControlRecordSeq) );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setAutoDispatchControlRecords)

        CORBA::Long dataCnt = 0;
        CORBA::Long dataLen = 0;

        pptObjCommonIn tmpObjCommonIn;
        tmpObjCommonIn = strObjCommonIn;
        tmpObjCommonIn.transactionID = CIMFWStrDup( "TXDSC021" );

        dataLen = autoDispatchControlRecordSeq->length();

        for( dataCnt = 0; dataCnt < dataLen; dataCnt++ )
        {
            //===================================================================================
            // Make event for Auto Dispatch Control Information Update.
            //===================================================================================
            PPT_METHODTRACE_V1( "", "## Make event for Auto Dispatch Control Information registration. " );
            objAutoDispatchControlEvent_Make_in strAutoDispatchControlEvent_Make_in;
            strAutoDispatchControlEvent_Make_in.lotID                                              = tmpChildLotID;
            strAutoDispatchControlEvent_Make_in.strAutoDispatchControlUpdateInfo.updateMode        = CIMFWStrDup( SP_AutoDispatchControl_Create );
            strAutoDispatchControlEvent_Make_in.strAutoDispatchControlUpdateInfo.routeID           = (*autoDispatchControlRecordSeq)[dataCnt].routeID;
            strAutoDispatchControlEvent_Make_in.strAutoDispatchControlUpdateInfo.operationNumber   = (*autoDispatchControlRecordSeq)[dataCnt].operationNumber;
            strAutoDispatchControlEvent_Make_in.strAutoDispatchControlUpdateInfo.singleTriggerFlag = (*autoDispatchControlRecordSeq)[dataCnt].singleTriggerFlag;
            strAutoDispatchControlEvent_Make_in.strAutoDispatchControlUpdateInfo.description       = (*autoDispatchControlRecordSeq)[dataCnt].description;

            objAutoDispatchControlEvent_Make_out strAutoDispatchControlEvent_Make_out;
            rc = autoDispatchControlEvent_Make( strAutoDispatchControlEvent_Make_out, tmpObjCommonIn, strAutoDispatchControlEvent_Make_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "autoDispatchControlEvent_Make() != RC_OK", rc );
                strLot_SplitWaferLot_out.strResult = strAutoDispatchControlEvent_Make_out.strResult;
                return rc;
            }
        }
//DSN000020767 Add End

//DSN000081739 Add Start
        CORBA::Long eqpMonitorSwitch = atoi( getenv(SP_EQPMONITOR_SWITCH) );
        if ( 1 == eqpMonitorSwitch )
        {
            PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
            CORBA::String_var tmpLotType;
            try
            {
                tmpLotType = aParentLot->getLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType);

            if ( 0 == CIMFWStrCmp(tmpLotType, SP_Lot_Type_EquipmentMonitorLot) || 0 == CIMFWStrCmp(tmpLotType, SP_Lot_Type_DummyLot) )
            {
                PPT_METHODTRACE_V1("", "tmpLotType is Equipment Monitor or Dummy");
                //Acquire EqpMonitor Job Info of Lot
                posEqpMonitorJobLotInfo_var aEqpMonitorJobLotInfo;
                try
                {
                    aEqpMonitorJobLotInfo = aParentLot->getEqpMonitorJobLotInfo();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getEqpMonitorJobLotInfo);

                if ( 0 < CIMFWStrLen( aEqpMonitorJobLotInfo->eqpMonitorJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( aEqpMonitorJobLotInfo->eqpMonitorJobID.identifier )");
                    //Lock EqpMonitor job object
                    objObject_LockForEqpMonitorJob_out strObject_LockForEqpMonitorJob_out;
                    objObject_LockForEqpMonitorJob_in  strObject_LockForEqpMonitorJob_in;
                    strObject_LockForEqpMonitorJob_in.eqpMonitorID    = aEqpMonitorJobLotInfo->eqpMonitorID;
                    strObject_LockForEqpMonitorJob_in.eqpMonitorJobID = aEqpMonitorJobLotInfo->eqpMonitorJobID;
                    rc = object_LockForEqpMonitorJob( strObject_LockForEqpMonitorJob_out,
                                                      strObjCommonIn,
                                                      strObject_LockForEqpMonitorJob_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_LockForEqpMonitorJob() != RC_OK", rc);
                        strLot_SplitWaferLot_out.strResult = strObject_LockForEqpMonitorJob_out.strResult;
                        return rc;
                    }

                    //Add the record of Child Lot to FREQPMONJOB_LOT. (copy parent lot's record)
                    posEqpMonitorLotInfo aEqpMonitorLotInfo;
                    aEqpMonitorLotInfo.lotID            = tmpChildLotID;
                    aEqpMonitorLotInfo.monitorLotStatus = aEqpMonitorJobLotInfo->monitorLotStatus;
                    aEqpMonitorLotInfo.startSeqNo       = aEqpMonitorJobLotInfo->startSeqNo;
                    aEqpMonitorLotInfo.monitorOpeKey    = aEqpMonitorJobLotInfo->monitorOpeKey;
                    aEqpMonitorLotInfo.exitFlag         = aEqpMonitorJobLotInfo->exitFlag;
                    aEqpMonitorLotInfo.result           = aEqpMonitorJobLotInfo->result;

                    PosEqpMonitorJob_var anEqpMonitorJob;
                    PPT_CONVERT_STRING_TO_OBJECT(aEqpMonitorJobLotInfo->eqpMonitorJobID.stringifiedObjectReference,anEqpMonitorJob,PosEqpMonitorJob);

                    try
                    {
                        anEqpMonitorJob->addEqpMonitorLot(aEqpMonitorLotInfo);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosEqpMonitorJob::addEqpMonitorJobLot)

                    //Create EqpMonitor Job History Event
                    objEqpMonitorJobChangeEvent_Make_out strEqpMonitorJobChangeEvent_Make_out;
                    objEqpMonitorJobChangeEvent_Make_in  strEqpMonitorJobChangeEvent_Make_in;
                    strEqpMonitorJobChangeEvent_Make_in.opeCategory                = CIMFWStrDup(SP_EqpMonitorJob_OpeCategory_EQPMonStart);
                    strEqpMonitorJobChangeEvent_Make_in.eqpMonitorID               = aEqpMonitorJobLotInfo->eqpMonitorID;
                    strEqpMonitorJobChangeEvent_Make_in.eqpMonitorJobID            = aEqpMonitorJobLotInfo->eqpMonitorJobID;
                    strEqpMonitorJobChangeEvent_Make_in.strEqpMonitorLotInfoSeq.length(1);
                    pptEqpMonitorLotInfo strEqpMonitorLotInfo;
                    strEqpMonitorLotInfo.lotID      = tmpChildLotID;
                    strEqpMonitorLotInfo.startSeqNo = aEqpMonitorJobLotInfo->startSeqNo;
                    strEqpMonitorJobChangeEvent_Make_in.strEqpMonitorLotInfoSeq[0] = strEqpMonitorLotInfo;
                    rc = eqpMonitorJobChangeEvent_Make( strEqpMonitorJobChangeEvent_Make_out,
                                                        strObjCommonIn,
                                                        strEqpMonitorJobChangeEvent_Make_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "eqpMonitorJobChangeEvent_Make() != RC_OK", rc);
                        strLot_SplitWaferLot_out.strResult = strEqpMonitorJobChangeEvent_Make_out.strResult;
                        return rc;
                    }
                }
            }
        }
//DSN000081739 Add End

        objLot_controlUseInfo_Change_out strLot_controlUseInfo_Change_out;
        rc = lot_controlUseInfo_Change(strLot_controlUseInfo_Change_out, strObjCommonIn, tmpChildLotID, tmpControlUseState, tmpUsageCount);
        if ( rc != RC_OK )
        {
            strLot_SplitWaferLot_out.strResult = strLot_controlUseInfo_Change_out.strResult ;
            return( rc );
        }      
//P3100321 add end
//DSN000085792 Add Start
        PosQTimeRestrictionSequence_var  aChildQTimeSeq;
        try
        {
            aChildQTimeSeq = aChildLot->allQTimeRestrictions();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::allQTimeRestrictions)
        for(CORBA::ULong q =0; q<aChildQTimeSeq->length(); q++)
        {
            PPT_METHODTRACE_V2("", "loop through child lot QTimeSeq",q);
            /*----------------------------*/
            /*   Get Q-Time information   */
            /*----------------------------*/
            PosQTimeRestriction_ptr  aChildQTime = aChildQTimeSeq[q];
            posQTimeRestrictionInfo_var  aChildQTimeInfo;
            try
            {
                aChildQTimeInfo = aChildQTime->getQTimeRestrictionInfo();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosQTimeRestriction::getQTimeRestrictionInfo)
            //----------------------------------------------------------------
            // Make event
            //----------------------------------------------------------------
//DSN000100682            pptQtimeInfo__150 strQtimeInfo;
            pptQtimeInfo__160 strQtimeInfo;  //DSN000100682
            strQtimeInfo.originalQTime                      = aChildQTimeInfo->originalQTime;
            strQtimeInfo.processDefinitionLevel             = aChildQTimeInfo->processDefinitionLevel;
            strQtimeInfo.qrestrictionTriggerRouteID         = aChildQTimeInfo->triggerMainProcessDefinition;
            strQtimeInfo.qrestrictionTriggerOperationNumber = aChildQTimeInfo->triggerOperationNumber;
            strQtimeInfo.qrestrictionTriggerBranchInfo      = aChildQTimeInfo->triggerBranchInfo;
            strQtimeInfo.qrestrictionTriggerReturnInfo      = aChildQTimeInfo->triggerReturnInfo;
            strQtimeInfo.qrestrictionTriggerTimeStamp       = aChildQTimeInfo->triggerTimeStamp;
            strQtimeInfo.qrestrictionTargetRouteID          = aChildQTimeInfo->targetMainProcessDefinition;
            strQtimeInfo.qrestrictionTargetOperationNumber  = aChildQTimeInfo->targetOperationNumber;
            strQtimeInfo.qrestrictionTargetBranchInfo       = aChildQTimeInfo->targetBranchInfo;
            strQtimeInfo.qrestrictionTargetReturnInfo       = aChildQTimeInfo->targetReturnInfo;
            strQtimeInfo.qrestrictionTargetTimeStamp        = aChildQTimeInfo->targetTimeStamp;
            strQtimeInfo.previousTargetInfo                 = aChildQTimeInfo->previousTargetInfo;
            strQtimeInfo.specificControl                    = aChildQTimeInfo->control;
            if ( TRUE == aChildQTimeInfo->watchdogRequired )
            {
                PPT_METHODTRACE_V1("", "TRUE == aChildQTimeInfo->watchdogRequired");
                strQtimeInfo.watchDogRequired = CIMFWStrDup("Y");
            }
            else if ( FALSE == aChildQTimeInfo->watchdogRequired )
            {
                PPT_METHODTRACE_V1("", "FALSE == aChildQTimeInfo->watchdogRequired");
                strQtimeInfo.watchDogRequired = CIMFWStrDup("N");
            }
            if ( TRUE == aChildQTimeInfo->actionDone )
            {
                PPT_METHODTRACE_V1("", "TRUE == aChildQTimeInfo->actionDone");
                strQtimeInfo.actionDoneFlag = CIMFWStrDup("Y");
            }
            else if ( FALSE == aChildQTimeInfo->actionDone )
            {
                PPT_METHODTRACE_V1("", "FALSE == aChildQTimeInfo->actionDone");
                strQtimeInfo.actionDoneFlag = CIMFWStrDup("N");
            }
            strQtimeInfo.manualCreated                      = aChildQTimeInfo->manualCreated;
            CORBA::ULong actionLength = aChildQTimeInfo->actions.length();
            PPT_METHODTRACE_V2("", "aChildQTimeInfo->actions.length()", actionLength);
            if ( actionLength != 0 )
            {
                PPT_METHODTRACE_V1("", "actionLength != 0");
                strQtimeInfo.strQtimeActionInfo.length(actionLength);
                for ( CORBA::ULong iCnt3=0; iCnt3<actionLength; iCnt3++ )
                {
                    PPT_METHODTRACE_V2("", "loop to aChildQTimeInfo->actions.length()", iCnt3);
                    strQtimeInfo.strQtimeActionInfo[iCnt3].qrestrictionTargetTimeStamp = aChildQTimeInfo->actions[iCnt3].targetTimeStamp;
                    strQtimeInfo.strQtimeActionInfo[iCnt3].qrestrictionAction          = aChildQTimeInfo->actions[iCnt3].action;
                    strQtimeInfo.strQtimeActionInfo[iCnt3].reasonCodeID                = aChildQTimeInfo->actions[iCnt3].reasonCode;
                    strQtimeInfo.strQtimeActionInfo[iCnt3].actionRouteID               = aChildQTimeInfo->actions[iCnt3].actionRouteID;  //DSN000100682
                    strQtimeInfo.strQtimeActionInfo[iCnt3].actionOperationNumber       = aChildQTimeInfo->actions[iCnt3].operationNumber;
                    strQtimeInfo.strQtimeActionInfo[iCnt3].futureHoldTiming            = aChildQTimeInfo->actions[iCnt3].timing;
                    strQtimeInfo.strQtimeActionInfo[iCnt3].reworkRouteID               = aChildQTimeInfo->actions[iCnt3].mainProcessDefinition;
                    strQtimeInfo.strQtimeActionInfo[iCnt3].messageID                   = aChildQTimeInfo->actions[iCnt3].messageDefinition;
                    strQtimeInfo.strQtimeActionInfo[iCnt3].customField                 = aChildQTimeInfo->actions[iCnt3].customField;
                    if ( TRUE == aChildQTimeInfo->actions[iCnt3].watchdogRequired )
                    {
                        PPT_METHODTRACE_V1("", "TRUE == aChildQTimeInfo->actions[iCnt3].watchdogRequired");
                        strQtimeInfo.strQtimeActionInfo[iCnt3].watchDogRequired = CIMFWStrDup("Y");
                    }
                    else if ( FALSE == aChildQTimeInfo->actions[iCnt3].watchdogRequired )
                    {
                        PPT_METHODTRACE_V1("", "FALSE == aChildQTimeInfo->actions[iCnt3].watchdogRequired");
                        strQtimeInfo.strQtimeActionInfo[iCnt3].watchDogRequired = CIMFWStrDup("N");
                    }
                    if ( TRUE == aChildQTimeInfo->actions[iCnt3].actionDone )
                    {
                        PPT_METHODTRACE_V1("", "TRUE == aChildQTimeInfo->actions[iCnt3].actionDone");
                        strQtimeInfo.strQtimeActionInfo[iCnt3].actionDoneFlag = CIMFWStrDup("Y");
                    }
                    else if ( FALSE == aChildQTimeInfo->actions[iCnt3].actionDone )
                    {
                        PPT_METHODTRACE_V1("", "FALSE == aChildQTimeInfo->actions[iCnt3].actionDone");
                        strQtimeInfo.strQtimeActionInfo[iCnt3].actionDoneFlag = CIMFWStrDup("N");
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "actionLength == 0");
                strQtimeInfo.strQtimeActionInfo.length(0);
            }
            objQTimeChangeEvent_Make_out strQTimeChangeEvent_Make_out;
//DSN000100682            objQTimeChangeEvent_Make_in  strQTimeChangeEvent_Make_in;
            objQTimeChangeEvent_Make_in__160  strQTimeChangeEvent_Make_in;  //DSN000100682
            strQTimeChangeEvent_Make_in.updateMode   = SP_QrestTime_OpeCategory_Create;
            strQTimeChangeEvent_Make_in.lotID        = tmpChildLotID;
            strQTimeChangeEvent_Make_in.strQtimeInfo = strQtimeInfo;
            strQTimeChangeEvent_Make_in.claimMemo    = CIMFWStrDup("");
//DSN000100682            rc = qTimeChangeEvent_Make( strQTimeChangeEvent_Make_out,
            rc = qTimeChangeEvent_Make__160( strQTimeChangeEvent_Make_out,  //DSN000100682
                                        strObjCommonIn,
                                        strQTimeChangeEvent_Make_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "qTimeChangeEvent_Make() != RC_OK", rc);
                strLot_SplitWaferLot_out.strResult = strQTimeChangeEvent_Make_out.strResult;
                return rc;
            }
        }
//DSN000085792 Add End
        //  Add aParentLot and aChildLot to the queue.
        PPT_METHODTRACE_V1("","Add aParentLot and aChildLot to the queue");

        if( isParentLotStateFinished == FALSE )
        {
            PPT_METHODTRACE_V1("","isParentLotStateFinished == FALSE");

            if( CIMFWStrCmp( aParentLotHoldState, CIMFW_Lot_HoldState_OnHold ) != 0 )    //P6000632
            {                                                                            //P6000632
//P9000222 add start
                if( 0 == CIMFWStrCmp( requeueFlag, "1" ) )
                {
                    PPT_METHODTRACE_V1("", "SP_SPLIT_LOT_REQUEUE_FLAG is ON.");
//P9000222 add end
                    try
                    {
                        theDispatchingManager->addToQueue( aParentLot );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosDispathingManager::addToQueue)

                }  //P9000222
            }                                                                            //P6000632
            try
            {
                theDispatchingManager->addToQueue( aChildLot );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosDispathingManager::addToQueue)
        }

        // Set child lot id to out parameter
//P3100321        PPT_SET_OBJECT_IDENTIFIER( strLot_SplitWaferLot_out.childLotID,
//P3100321                                   aChildLot,
//P3100321                                   strLot_SplitWaferLot_out,
//P3100321                                   lot_SplitWaferLot,
//P3100321                                   PosLot );

        strLot_SplitWaferLot_out.childLotID = tmpChildLotID;             //P3100321

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_SplitWaferLot");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_SplitWaferLot_out, lot_SplitWaferLot, methodName)
}
