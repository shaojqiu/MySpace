//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: lot_MergeWaferLot.cpp
//

#include "cs_pptmgr.hpp"

#include "pcatgry.hh"
#include "pcode.hh"
#include "pflwbch.hh"
#include "pcas.hh"
#include "pmc.hh"
#include "ppcdf.hh"
#include "ppcflw.hh"
#include "ppcflwx.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "plot.hh"
#include "pmongrp.hh"
//D5000016 #include "ppcgrp.hh"
#include "pprmggl.hh"
#include "pwafer.hh"
#include "pprsp.hh"
#include "ptestsp.hh"
#include "ptesttp.hh"
#include "pperson.hh"
#include "plcrc.hh"
#include "pportrs.hh"
#include "pmcrc.hh"

//[Object Function Name]: long   lot_MergeWaferLot
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-08-07  0.00      H.Ueda         Initial Release                (R30)
// 2000/08/15  0.01      H.Katoh        Add Cassette Verify logic
// 2000/09/21  Q3000124  K.Matsuei      Nil Check
// 2000-10-17  P3000266  S.Kawabe       Bug fix Contol Lot Count 
// 2000/11/14  P2200204  R.Furuta       Initialize local pointers
// 2002/01/08  P4100053  M.Shimizu      SlotNumbrer invalid error message text update 
// 2002/05/13  P4100425  K.Matsuei      The number of Parameters to assemble Message in PPT_SET_MSG_RC_KEY*** mistakes it.
// 2002/10/29  D4200164  F.Masada       Remove lot from queue and add lot to queue.
// 2002/12/10  P4200445  S.Yamamoto     fix : The variable to refer to is wrong.
// 2003/04/11  D5000023  K.Kido         Wafer level control for ReworkCount(Rel5.0).
// 2003/05/20  D5000016  K.Kido         Useless class deletion(R5.0).
// 2005/09/14  P6000632  H.Hasegawa     Fix the logic which renews the parent lot's queue.
// 2006/03/18  P7000158  F.Masada       Fix to set the cassette's wafer count correctly.
// 2006/12/07  P7000415  H.Hasegawa     Add the logic which removes the held lot from queues.
// 2007/06/12  D9000038  H.Murakami     Remove In-Cassette Limitation.
//
// Date        Level         Author         Note
// ----------  ------------  -------------  -------------------------------------------
// 2010/04/23  DSIV00001830  R.Okano        Wafer Stacking Operation Support. (R101)
// 2010/10/15  DSIV00002270  K.Yamaoku      PO Maintenance Improvement
// 2011/01/12  DSIV00002757  K.Yamaoku      Improvement of PO Maintenance Program
// 2012/04/18  DSN000041192  T.Ishida       LagTime Lot Merge Improvement
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/12 INN-R170002  JJ.Zhang       Contamination Control
//
//[Function Description]:
//  1) Update parentLot's material quantity information.
//  2) Update childLot's lotFinishedState to CIMFW_Product_FinishedState_Emptied,
//     and update childLot's material quantity to zero.
//
//  3) Remove childLot from its waiting queue.
//
//  4) Update both lot's responsible timeStamp and user information.
//  5) Rework count of the parent lot is updated if merged childLot has rework
//     count information at the merged point and it is more than parent lot's one.
//  6) Remove lot from queue and add it to queue to apply new equipment list for dispatching. //D4200164  
//
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  objectIdentifier  parentLotID;
//  in  objectIdentifier  childLotID;
//
//[Output Parameters]:
//
//  out objLot_MergeWaferLot_out  strLot_MergeWaferLot_out;
//
//  typedef struct objLot_MergeWaferLot_out_struct {
//     pptRetCode        strResult;
//     string            childLotOldObjrefPOS;
//  } objLot_MergeWaferLot_out;
//
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_LOT            MSG_NOT_FOUND_LOT
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_INVALID_DATA_CONTENTS    MSG_INVALID_DATA_CONTENTS
//  RC_INVALID_STATE_TRANS      MSG_INVALID_STATE_TRANS
//
//[Pseudo Code]:
//

//INN-R170002 CORBA::Long PPTManager_i::lot_MergeWaferLot(
CORBA::Long CS_PPTManager_i::lot_MergeWaferLot(    //INN-R170002
                            objLot_MergeWaferLot_out& strLot_MergeWaferLot_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& parentLotID,
                            const objectIdentifier& childLotID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_MergeWaferLot");

        CORBA::Long rc = RC_OK;

        CORBA::Boolean bInParentCast = TRUE; //D9000038
        CORBA::Boolean bInChildCast  = TRUE; //D9000038
        CORBA::Boolean bInCast       = TRUE; //D9000038

        PosLot_var aParentLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aParentLot,
                                     parentLotID,
                                     strLot_MergeWaferLot_out,
                                     lot_MergeWaferLot );

        PosLot_var aChildLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aChildLot,
                                     childLotID,
                                     strLot_MergeWaferLot_out,
                                     lot_MergeWaferLot );

        //--------------------------------------------------------------------
        // Check Wafer attributes
        //--------------------------------------------------------------------
        //------------------------------------------------------
        // Get all wafer information of Parent Lot
        //------------------------------------------------------
        PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","Get all wafer information of Parent Lot", __LINE__);

        PosWaferInfoSequence* parentLotWaferInfo = NULL; //P2200204
        PosWaferInfoSequence_var parentLotWaferInfoVar;
        try
        {
            parentLotWaferInfo = aParentLot->getAllWaferInfo();
            parentLotWaferInfoVar = parentLotWaferInfo;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getAllWaferInfo)
        
        if(parentLotWaferInfo == NULL)
        {
            SET_MSG_RC( strLot_MergeWaferLot_out,
                        MSG_PRODUCT_COUNT_ZERO,
                        RC_PRODUCT_COUNT_ZERO );
        
            return RC_PRODUCT_COUNT_ZERO;
        }
        
        CORBA::Long parent_wafer_count = parentLotWaferInfo->length();

        if ( parent_wafer_count == 0 )
        {
            SET_MSG_RC( strLot_MergeWaferLot_out,
                        MSG_PRODUCT_COUNT_ZERO,
                        RC_PRODUCT_COUNT_ZERO );

            return RC_PRODUCT_COUNT_ZERO;
        }

        //------------------------------------------------------
        // Get all wafer information of Child Lot
        //------------------------------------------------------
        PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","Get all wafer information of Child Lot", __LINE__);

        PosWaferInfoSequence* childLotWaferInfo = NULL; //P2200204
        PosWaferInfoSequence_var childLotWaferInfoVar;
        try
        {
            childLotWaferInfo = aChildLot->getAllWaferInfo();
            childLotWaferInfoVar = childLotWaferInfo;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getAllWaferInfo)

        if(childLotWaferInfo == NULL)
        {
            SET_MSG_RC( strLot_MergeWaferLot_out,
                        MSG_PRODUCT_COUNT_ZERO,
                        RC_PRODUCT_COUNT_ZERO );

            return RC_PRODUCT_COUNT_ZERO;
        }

        CORBA::Long child_wafer_count = childLotWaferInfo->length();

        if ( child_wafer_count == 0 )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","child_wafer_count==0");
            SET_MSG_RC( strLot_MergeWaferLot_out,
                        MSG_PRODUCT_COUNT_ZERO,
                        RC_PRODUCT_COUNT_ZERO );

            return RC_PRODUCT_COUNT_ZERO;
        }
//DSIV00001830 add start
        //-------------------------------------------------------------------
        // Check Stacked Wafer Information
        // If it is different from Parent Lot and Child Lot, not allow merge
        //-------------------------------------------------------------------
        CORBA::Boolean bInvalidStkWfr = FALSE;
        CORBA::Long parent_stkwafer_count = 0;
        CORBA::Long child_stkwafer_count = 0;
        
        if ( parent_wafer_count > 0)
        {
        	parent_stkwafer_count = (*parentLotWaferInfo)[0].stackedWafers.length();
        }
        if ( child_wafer_count > 0)
        {
        	child_stkwafer_count = (*childLotWaferInfo)[0].stackedWafers.length();
        }
        
        if ( parent_stkwafer_count != child_stkwafer_count)
        {
            PPT_METHODTRACE_V3("","parent_stkwafer_count != child_stkwafer_count", parent_stkwafer_count, child_stkwafer_count);

            SET_MSG_RC( strLot_MergeWaferLot_out,
                        MSG_STACKED_WAFER_DIFFERENT_FOR_MERGE,
                        RC_STACKED_WAFER_DIFFERENT_FOR_MERGE )

            return RC_STACKED_WAFER_DIFFERENT_FOR_MERGE;
        }
//DSIV00001830 add end
        //------------------------------------------------------
        // Get Carrier object reference of Parent Lot
        //------------------------------------------------------
        MaterialContainerSequence* aMaterialContainerSequence = NULL;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aMaterialContainerSequence = aParentLot->materialContainers();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::materialContainers)

        MaterialContainerSequence_var aTmpMaterialContainerSequence;
        aTmpMaterialContainerSequence = aMaterialContainerSequence;

        PosCassette_var aParentCassette;
        if( aMaterialContainerSequence->length() == 1 )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","aMaterialContainerSequence->length() == 1");

            aParentCassette = PosCassette::_narrow((*aMaterialContainerSequence)[0]);
        }
//D9000038 Add Start
        else if( aMaterialContainerSequence->length() == 0 )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","aMaterialContainerSequence->length() == 0");

            bInParentCast = FALSE;
        }
//D9000038 Add End
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","return RC_CASSETTE_DIFFERENT_FOR_MERGE!!");

            SET_MSG_RC( strLot_MergeWaferLot_out,
                        MSG_CASSETTE_DIFFERENT_FOR_MERGE,
                        RC_CASSETTE_DIFFERENT_FOR_MERGE )

            return RC_CASSETTE_DIFFERENT_FOR_MERGE;
        }

        if ( CORBA::is_nil(aParentCassette) )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","aParentCassette is nil");
//D9000038 Add Start
            if( bInParentCast )
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","bInParentCast is true");
//D9000038 Add End
                PPT_SET_MSG_RC_KEY( strLot_MergeWaferLot_out,
                                    MSG_NOT_FOUND_CASSETTE,
                                    RC_NOT_FOUND_CASSETTE,
                                    "" );

                return RC_NOT_FOUND_CASSETTE;
//D9000038 Add Start
            }
            else
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","bInParentCast is false");
            }
//D9000038 Add End
        }

//INN-R170002 Add Start
        //compare lotContamiFlag
        CORBA::String_var strParentContamiFlag;
        CORBA::String_var strChildContamiFlag;
        SI_PPT_USERDATA_GET_STRING( aParentLot, CS_M_LOT_Contamination_Flag, strParentContamiFlag );
        SI_PPT_USERDATA_GET_STRING( aChildLot,  CS_M_LOT_Contamination_Flag, strChildContamiFlag );
        if( 0 != CIMFWStrCmp(strParentContamiFlag, strChildContamiFlag) )
        {
            PPT_METHODTRACE_V3("","contamination flags are different", strParentContamiFlag, strChildContamiFlag);
            CS_SET_MSG_RC( strLot_MergeWaferLot_out,
                         CS_MSG_DIFFERENT_CONTAMINATION_FOR_MERGE,
                         CS_RC_DIFFERENT_CONTAMINATION_FOR_MERGE );
            return CS_RC_DIFFERENT_CONTAMINATION_FOR_MERGE;
        }

        //lotPRFlag
        CORBA::String_var strParentPRFlag;
        CORBA::String_var strChildPRFlag;
        SI_PPT_USERDATA_GET_STRING( aParentLot, CS_M_LOT_PR_Flag, strParentPRFlag );
        SI_PPT_USERDATA_GET_STRING( aChildLot,  CS_M_LOT_PR_Flag, strChildPRFlag );
        if( 0 != CIMFWStrCmp(strParentPRFlag, strChildPRFlag) )
        {
            PPT_METHODTRACE_V3("","PR flags are different", strParentPRFlag, strChildPRFlag);
            CS_SET_MSG_RC( strLot_MergeWaferLot_out,
                         CS_MSG_DIFFERENT_PRFLAG_FOR_MERGE,
                         CS_RC_DIFFERENT_PRFLAG_FOR_MERGE );
            return CS_RC_DIFFERENT_PRFLAG_FOR_MERGE;
        }
//INN-R170002 Add End

        //------------------------------------------------------
        // Get Carrier object reference of Child Lot
        //------------------------------------------------------
        MaterialContainerSequence* aChildMaterialContainerSequence = NULL;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aChildMaterialContainerSequence = aChildLot->materialContainers();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::materialContainers)

        MaterialContainerSequence_var aTmpChildMaterialContainerSequence;
        aTmpChildMaterialContainerSequence = aChildMaterialContainerSequence;

        PosCassette_var aChildCassette;
        if (aChildMaterialContainerSequence->length() == 1)
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","aChildMaterialContainerSequence->length() == 1");

            aChildCassette = PosCassette::_narrow((*aChildMaterialContainerSequence)[0]);
        }
//D9000038 Add Start
        else if( aMaterialContainerSequence->length() == 0 )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","aMaterialContainerSequence->length() == 0");

            bInChildCast = FALSE;
        }
//D9000038 Add End
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","return RC_CASSETTE_DIFFERENT_FOR_MERGE!!");

            SET_MSG_RC( strLot_MergeWaferLot_out,
                        MSG_CASSETTE_DIFFERENT_FOR_MERGE,
                        RC_CASSETTE_DIFFERENT_FOR_MERGE )

            return RC_CASSETTE_DIFFERENT_FOR_MERGE;
        }

        if ( CORBA::is_nil(aChildCassette) )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","aChildCassette is nil");
//D9000038 Add Start
            if( bInChildCast )
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","aParentCassette is true");
//D9000038 Add End
                PPT_SET_MSG_RC_KEY( strLot_MergeWaferLot_out,
                                    MSG_NOT_FOUND_CASSETTE,
                                    RC_NOT_FOUND_CASSETTE,
                                    "" );

                return RC_NOT_FOUND_CASSETTE;
//D9000038 Add Start
            }
            else
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","bInChildCast is false");
            }
//D9000038 Add End
        }

//D9000038 Add Start
        if( bInParentCast == FALSE && bInChildCast == FALSE )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","Both ChildLot and ParentLot are not in the cassette.");
            bInCast = FALSE;
        }
        else if( bInParentCast == TRUE && bInChildCast == TRUE )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","Both ChildLot and ParentLot are in the cassette.");
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","Either ChildLot or ParentLot is in the cassette. Another lot is not in the cassette.");

            SET_MSG_RC( strLot_MergeWaferLot_out,
                        MSG_MEARGE_LOT_IN_AND_NOT_IN_CAST,
                        RC_MEARGE_LOT_IN_AND_NOT_IN_CAST )

            return RC_MEARGE_LOT_IN_AND_NOT_IN_CAST;
        }

        CORBA::ULong i = 0;

        if( bInCast )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","if( bInCast == TRUE)");
//D9000038 Add End

  // 0.01 start
            CORBA::String_var strParentCassetteID;
            try
            {
                strParentCassetteID = aParentCassette->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)

            CORBA::String_var strChildCassetteID;
            try
            {
                strChildCassetteID = aChildCassette->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)

            if ( 0 != CIMFWStrCmp(strParentCassetteID, strChildCassetteID) )
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","strParentCassetteID != strChildCassetteID");
                SET_MSG_RC( strLot_MergeWaferLot_out,
                            MSG_CASSETTE_DIFFERENT_FOR_MERGE,
                            RC_CASSETTE_DIFFERENT_FOR_MERGE );

                return RC_CASSETTE_DIFFERENT_FOR_MERGE;
            }
  // 0.01 end

            //------------------------------------------------------
            // Remove Lots from Carrier
            //------------------------------------------------------
            PPT_METHODTRACE_V1( "PPTManager_i::lot_MergeWaferLot","Remove Lots from Carrier" );
            //P7000158 try
            //P7000158 {
            //P7000158     PPT_DISPLAY_RESPONSE_TIME();
            //P7000158     aParentCassette->removeLot(aChildLot);
            //P7000158 }
            //P7000158 CATCH_AND_RAISE_EXCEPTIONS(PosCassette::removeLot)
            //P7000158 
            //P7000158 try
            //P7000158 {
            //P7000158     PPT_DISPLAY_RESPONSE_TIME();
            //P7000158     aParentCassette->removeLot(aParentLot);
            //P7000158 }
            //P7000158 CATCH_AND_RAISE_EXCEPTIONS(PosCassette::removeLot)
            //P7000158 start   
//D9000038            CORBA::ULong i;
            for( i=0; i<child_wafer_count; i++ )
            {
                // Get obj ref and change state of wafer
                Wafer_var tmpWafer;
                try
                {
                    tmpWafer = aParentCassette->removeWafer_fromPosition((*childLotWaferInfo)[i].position); 
                }
                catch(Cassette::PositionInvalidSignal)
                {
                    CORBA::String_var Array = ConvertLongtoString( (*childLotWaferInfo)[i].position );
                    SET_FW_MSG_RC( strLot_MergeWaferLot_out,
                                   lot_MergeWaferLot,
                                   MSG_INVALID_CAST_POSITION,
                                   RC_INVALID_CAST_POSITION,
                                   Cassette::removeWafer_fromPosition,
                                   Cassette::PositionInvalidSignal,
                                   Array);
                    return (RC_INVALID_CAST_POSITION);
                }
                catch(Cassette::PositionEmptySignal)
                {
                    CORBA::String_var Array = ConvertLongtoString( (*childLotWaferInfo)[i].position );
                    SET_FW_MSG_RC( strLot_MergeWaferLot_out,
                                   lot_MergeWaferLot,
                                   MSG_INVALID_CAST_POSITION,
                                   RC_INVALID_CAST_POSITION,
                                   Cassette::removeWafer_fromPosition,
                                   Cassette::PositionEmptySignal,
                                   Array);
                    return (RC_INVALID_CAST_POSITION);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::removeWafer_fromPosition)
            }
            //P7000158 end   


            //------------------------------------------------------
            // Remove from queue
            //------------------------------------------------------
            PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","Remove child lot from queue", __LINE__);

            CORBA::String_var aChildLotState ;
            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aChildLotState = aChildLot->getLotState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotState)

            if( CIMFWStrCmp(aChildLotState, CIMFW_Lot_State_Finished) != 0 )
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","aChildLotState != CIMFW_Lot_State_Finished");

                //P7000415 Add Start
                CORBA::String_var  childLotHoldState;
                try
                {
                    childLotHoldState = aChildLot->getLotHoldState();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState)

                if( CIMFWStrCmp( childLotHoldState, CIMFW_Lot_HoldState_OnHold ) == 0 )
                {
                    try
                    {
                        theDispatchingManager->removeFromHoldQueue( aChildLot );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(DispatchingManager::removeFromHoldQueue)
                }
                else
                {
                //P7000415 Add End
                    try
                    {
                        PPT_DISPLAY_RESPONSE_TIME();
                        theDispatchingManager->removeFromQueue(aChildLot);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(DispatchingManager::removeFromQueue)
                }    //P7000415 : The above lines' indention is adjusted.
            }

            //D4200164 start 
            //--------------------------------------------------
            // Remove parent Lot from queue and add to queue  
            //----------------------------------------------------
            PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","Remove parent lot from queue and add it to queue", __LINE__);

            CORBA::String_var aParentLotState;
            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aParentLotState = aParentLot->getLotState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotState)

            //P6000632 Add Start
            CORBA::String_var  aParentLotHoldState;
            try
            {
                aParentLotHoldState = aParentLot->getLotHoldState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState);
            //P6000632 Add End

//P6000632        if( CIMFWStrCmp( aParentLotState , CIMFW_Lot_State_Finished ) != 0)
            if( CIMFWStrCmp( aParentLotState,     CIMFW_Lot_State_Finished )   != 0 &&     //P6000632
                CIMFWStrCmp( aParentLotHoldState, CIMFW_Lot_HoldState_OnHold ) != 0   )    //P6000632
            {
                PPT_METHODTRACE_V1("", "Parent Lot's State != CIMFW_Lot_State_Finished");
                try
                {
                    theDispatchingManager->removeFromQueue( aParentLot );
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosDispathingManager::removeFromQueue)

                try
                {
                    theDispatchingManager->addToQueue( aParentLot );
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosDispathingManager::addToQueue)
            }
            //D4200164 end 
//D9000038 Add Start
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","bInCast is false. And skip the functions related with Cassette.");
        }
//D9000038 Add End

        //---------------------------------------
        // Get theQuantity and theProductQuantity
        //---------------------------------------
        PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","Get theQuantity and theProductQuantity", __LINE__);

        CORBA::Long aParentLotQuantity;
        try
        {
            aParentLotQuantity = aParentLot->getQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQuantity)

        CORBA::Long aChildLotQuantity;
        try
        {
            aChildLotQuantity = aChildLot->getQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQuantity)

        CORBA::Long aParentLotProductQuantity;
        try
        {
            aParentLotProductQuantity = aParentLot->getProductQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductQuantity)

        CORBA::Long aChildLotProductQuantity;
        try
        {
            aChildLotProductQuantity = aChildLot->getProductQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductQuantity)

//P3000266 add start
        CORBA::Long aParentLotControlQuantity;
        CORBA::Long aChildLotControlQuantity;
        try
        {
            aParentLotControlQuantity = aParentLot->getControlQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlQuantity)
        try
        {
            aChildLotControlQuantity  = aChildLot->getControlQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlQuantity)
//P3000266 add end


        CORBA::Long totalQuantity = aParentLotQuantity + aChildLotQuantity;
        CORBA::Long totalProductQuantity = aParentLotProductQuantity + aChildLotProductQuantity;
        CORBA::Long totalControlQuantity = aParentLotControlQuantity + aChildLotControlQuantity; //P3000266

        //------------------------------------------------------
        // Call lot merge method of F/W.
        //------------------------------------------------------
        PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","Call lot merge method of F/W.", __LINE__);

        try
        {
            theProductManager->joinAll_into(aChildLot, aParentLot);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductManager::joinAll_into)

//DSIV00002270 add start
        CORBA::Long envEventCreateType = atoi( getenv( SP_POMAINT_EVENT_CREATE_TYPE ) );
        if ( envEventCreateType == SP_POMaintEventCreateType_InactiveLotEnabled ||
             envEventCreateType == SP_POMaintEventCreateType_Enabled )
        {
//DSIV00002757 add start
            ProcessOperation_var aCurrentPO;
            try
            {
                aCurrentPO = aChildLot->getProcessOperation();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

            if ( !CORBA::is_nil( aCurrentPO ) )
            {
//DSIV00002757 add end
                objPoDelQueue_PutDR_out strPoDelQueue_PutDR_out;
                objPoDelQueue_PutDR_in  strPoDelQueue_PutDR_in;
                strPoDelQueue_PutDR_in.lotID = childLotID;
                rc = poDelQueue_PutDR( strPoDelQueue_PutDR_out,
                                                   strObjCommonIn,
                                                   strPoDelQueue_PutDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "poDelQueue_PutDR() != RC_OK", rc);
                }
//DSIV00002757 add start
            }
//DSIV00002757 add end
        }
//DSIV00002270 add end

        //------------------------------------------------------
        // Add Lots to Carrier
        //------------------------------------------------------

//D9000038 Add Start
        if( bInCast )
        {
//D9000038 Add End
            PPT_METHODTRACE_V1( "PPTManager_i::lot_MergeWaferLot","Add Lots to Carrier" );

            //P7000158 CORBA::Long i;
            //P7000158 for( i=0; i<parent_wafer_count; i++ )
            //P7000158 {
            //P7000158     PosWafer_var aTmpWafer;
            //P7000158     PPT_CONVERT_WAFERID_TO_WAFER_OR( aTmpWafer,
            //P7000158                                      (*parentLotWaferInfo)[i].waferID,
            //P7000158                                      strLot_MergeWaferLot_out,
            //P7000158                                      lot_MergeWaferLot );
            //P7000158 
            //P7000158     try
            //P7000158     {
            //P7000158         aParentCassette->addWafer_atPosition( aTmpWafer, (*parentLotWaferInfo)[i].position );
            //P7000158     }
//P4100053 Add Start
            //P7000158     catch(Cassette::PositionOccupiedSignal)
            //P7000158     {
            //P7000158         CORBA::String_var Array = ConvertLongtoString( (*parentLotWaferInfo)[i].position );
            //P7000158         SET_FW_MSG_RC( strLot_MergeWaferLot_out,
            //P7000158                        lot_MergeWaferLot,
            //P7000158                        MSG_DUPLICATE_SLOTNO,
            //P7000158                        RC_DUPLICATE_SLOTNO,
            //P7000158                        Cassette::addWafer_atPosition,
            //P7000158                        Cassette::PositionOccupiedSignal,
            //P7000158                        Array);
            //P7000158         return (RC_DUPLICATE_SLOTNO);
            //P7000158     }
            //P7000158     catch(Cassette::PositionInvalidSignal)
            //P7000158     {
            //P7000158         CORBA::String_var Array = ConvertLongtoString( (*parentLotWaferInfo)[i].position );
            //P7000158         SET_FW_MSG_RC( strLot_MergeWaferLot_out,
            //P7000158                        lot_MergeWaferLot,
            //P7000158                        MSG_INVALID_CAST_POSITION,
            //P7000158                        RC_INVALID_CAST_POSITION,
            //P7000158                        Cassette::addWafer_atPosition,
            //P7000158                        Cassette::PositionInvalidSignal,
            //P7000158                        Array);
            //P7000158         return (RC_INVALID_CAST_POSITION);
            //P7000158     }
//P4100053 Add End
            //P7000158     CATCH_AND_RAISE_EXCEPTIONS(PosCassette::addWafer_atPosition)
            //P7000158 }

            for( i=0; i<child_wafer_count; i++ )
            {
                PosWafer_var aTmpWafer;
                PPT_CONVERT_WAFERID_TO_WAFER_OR( aTmpWafer,
                                                 (*childLotWaferInfo)[i].waferID,
                                                 strLot_MergeWaferLot_out,
                                                 lot_MergeWaferLot );

                try
                {
                    aParentCassette->addWafer_atPosition( aTmpWafer, (*childLotWaferInfo)[i].position );
                }
//P4100053 Add Start
                catch(Cassette::PositionOccupiedSignal)
                {
                    CORBA::String_var Array = ConvertLongtoString( (*childLotWaferInfo)[i].position ); //P4200445
//P4200445                CORBA::String_var Array = ConvertLongtoString( (*parentLotWaferInfo)[i].position );
                    SET_FW_MSG_RC( strLot_MergeWaferLot_out,
                                   lot_MergeWaferLot,
                                   MSG_DUPLICATE_SLOTNO,
                                   RC_DUPLICATE_SLOTNO,
                                   Cassette::addWafer_atPosition,
                                   Cassette::PositionOccupiedSignal,
                                   Array);
                    return (RC_DUPLICATE_SLOTNO);
                }
                catch(Cassette::PositionInvalidSignal)
                {
                    CORBA::String_var Array = ConvertLongtoString( (*childLotWaferInfo)[i].position ); //P4200445
//P4200445                CORBA::String_var Array = ConvertLongtoString( (*parentLotWaferInfo)[i].position );
                    SET_FW_MSG_RC( strLot_MergeWaferLot_out,
                                   lot_MergeWaferLot,
                                   MSG_INVALID_CAST_POSITION,
                                   RC_INVALID_CAST_POSITION,
                                   Cassette::addWafer_atPosition,
                                   Cassette::PositionInvalidSignal,
                                   Array);
                    return (RC_INVALID_CAST_POSITION);
                }
//P4100053 Add End
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::addWafer_atPosition)
            }
//D9000038 Add Start
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","bInCast is false. And skip addWafer_atPosition");
        }
//D9000038 Add End

        //---------------------------------------------------------------------
        // change total wafer quantity of both parent lot and child lot.
        //  ParentLot.theQuantity   <= aParentLotQuantity + aChildLotQuantity
        //  ChildLot.theQuantity    <= 0
        //---------------------------------------------------------------------
        PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","change total wafer quantity of both parent lot and child lot", __LINE__);

        try
        {
            aParentLot->setVendorLotQuantity(totalQuantity);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setVendorLotQuantity)

        try
        {
            aChildLot->setVendorLotQuantity(0);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setVendorLotQuantity)

        //-------------------------------------------------------------------------------------------
        // change the number of wafer which has waferID in itself.
        //  ParentLot.theProductQuantity   <= aParentLotProductQuantity + aChildProductLotQuantity
        //  ChildLot.theProductQuantity    <= 0
        //  ParentLot.theControlQuantity   <= aParentLotControlQuantity + aChildControlLotQuantity //P3000266
        //  ChildLot.theControlQuantity    <= 0                                                    //P3000266
        //-------------------------------------------------------------------------------------------
        PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","change the number of wafer which has waferID in itself", __LINE__);

        try
        {
            aParentLot->setProductQuantity(totalProductQuantity);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setProductQuantity)

        try
        {
            aChildLot->setProductQuantity(0);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setProductQuantity)

//P3000266 add start
        try
        {
            aParentLot->setControlQuantity(totalControlQuantity);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setControlQuantity)
        try
        {
            aChildLot->setControlQuantity(0);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setConrolQuantity)
//P3000266 add end

        //DSN000041192 Add Start
        CORBA::String_var lagTimeMergeRule = CIMFWStrDup( getenv( SP_LAGTIMEINFO_MERGE_RULE ) );
        PPT_METHODTRACE_V2( "", "lagTimeMergeRule = ", lagTimeMergeRule );

        if( 0 == CIMFWStrCmp( lagTimeMergeRule, "1" ) )
        {
            PPT_METHODTRACE_V1( "", "lagTimeMergeRule = 1" );

            /*-----------------------------------------------------------*/
            /*   Check PosLot and related CLASS                          */
            /*-----------------------------------------------------------*/

            objLot_FillInTxTRQ005DR_out strLot_FillInTxTRQ005DR_out;
            rc = lot_FillInTxTRQ005DR( strLot_FillInTxTRQ005DR_out, strObjCommonIn, childLotID );
            if( rc == RC_OK )
            {
                CORBA::Long holdLen = 0;
                CORBA::Long holdCnt = 0;
                CORBA::Boolean bLagTimeHoldFlag = FALSE;

                holdLen = strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length();

                for( holdCnt = 0; holdCnt < holdLen; holdCnt++ )
                {
                    if( CIMFWStrCmp( strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].reasonCodeID.identifier, SP_Reason_ProcessLagTimeHold ) == 0 )
                    {
                        PPT_METHODTRACE_V1( "", "LagTimeHold record is exist!" );
                        bLagTimeHoldFlag = TRUE;
                        break;
                    }
                }

                if( bLagTimeHoldFlag == TRUE )
                {
                    CORBA::String_var parentProcessLagTime;
                    CORBA::String_var childProcessLagTime;

                    try
                    {
                        parentProcessLagTime = aParentLot->getProcessLagTime();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessLagTime)

                    PPT_METHODTRACE_V2( "", "Parent Process Lag Time = ", parentProcessLagTime );

                    try
                    {
                        childProcessLagTime = aChildLot->getProcessLagTime();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessLagTime)

                    PPT_METHODTRACE_V2( "", "Child Process Lag Time = ", childProcessLagTime );

                    if( ( CIMFWStrCmp( parentProcessLagTime, SP_TIMESTAMP_NIL_OBJECT_STRING ) != 0 ) &&
                        ( CIMFWStrCmp( childProcessLagTime,  SP_TIMESTAMP_NIL_OBJECT_STRING ) != 0 ) )
                    {
                        if( CIMFWStrCmp( parentProcessLagTime, childProcessLagTime ) < 0 )
                        {
                            PPT_METHODTRACE_V1( "", "CIMFWStrCmp( parentProcessLagTime, childProcessLagTime ) < 0" );

                            try
                            {
                                aParentLot->setProcessLagTime( childProcessLagTime );
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::setProcessLagTime)
                        }
                        else
                        {
                            PPT_METHODTRACE_V1( "", "CIMFWStrCmp( parentProcessLagTime, childProcessLagTime ) >= 0" );

                            try
                            {
                                aParentLot->setProcessLagTime( parentProcessLagTime );
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::setProcessLagTime)
                        }
                    }
                }
            }
            else if( rc != RC_NOT_FOUND_ENTRY )
            {
                strLot_MergeWaferLot_out.strResult = strLot_FillInTxTRQ005DR_out.strResult;
                return( rc );
            }
        }
        //DSN000041192 Add End

        // For partial rework cancel operation (START)
        CORBA::Boolean isInProduction, isInRework;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            isInProduction = aParentLot->isInProduction();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::isInProduction)

        if ( isInProduction == TRUE )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","isInProduction == TRUE");

            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                isInRework = aChildLot->isInRework();
            }
            CATCH_AND_RAISE_EXCEPTIONS(Lot::isInRework)

            if ( isInRework == TRUE )
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","isInRework == TRUE");

                try
                {
                    PPT_DISPLAY_RESPONSE_TIME();
                    aChildLot->makeInProduction();
                }
                catch(PosLot::LotStateInvalidSignal)
                {
                    PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","return RC_INVALID_STATE_TRANS");
                    SET_FW_MSG_RC_KEY2( strLot_MergeWaferLot_out,
                                        lot_MergeWaferLot,
                                        MSG_INVALID_STATE_TRANS,
                                        RC_INVALID_STATE_TRANS,
                                        PosLot::makeNotOnHold,
                                        PosLot::LotStateInvalidSignal,
                                        "*****",
                                        CIMFW_Lot_ProductionState_InProduction );

                    return RC_INVALID_STATE_TRANS;
                }
                CATCH_AND_RAISE_EXCEPTIONS(Lot::makeInProduction)
            }
        }
        //------------------------------------------------------
        // For partial rework cancel operation (END)
        //------------------------------------------------------
        PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","For partial rework cancel operation (END)", __LINE__);

        ProcessOperation_var aProcessOperation;
        PosProcessOperation_var aChildPO;
        try
        {
            aProcessOperation = aChildLot->getProcessOperation();
            aChildPO = PosProcessOperation::_narrow(aProcessOperation);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);
//Q3000124 start
        if ( CORBA::is_nil(aChildPO) )
        {
//P4100425 start
            PPT_SET_MSG_RC_KEY2( strLot_MergeWaferLot_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "", childLotID.identifier );
//P4100425 end
//P4100425            PPT_SET_MSG_RC_KEY( strLot_MergeWaferLot_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "" );
            return( RC_NOT_FOUND_PO );
        }
//Q3000124 end

        ProcessOperationSpecification_var aProcessOperationSpecification;
        try
        {
            aProcessOperationSpecification = aChildPO->getProcessOperationSpecification();
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProcessOperation::getProcessOperationSpecificaiton)

        strLot_MergeWaferLot_out.childLotOldObjrefPOS = SP_OBJECT_TO_STRING(aProcessOperationSpecification);

//D5000023        //------------------------------------------------------
//D5000023        // Copy the reworkCount from child lot to parent lot
//D5000023        //------------------------------------------------------
//D5000023        PPT_METHODTRACE_V2("PPTManager_i::lot_MergeWaferLot","Copy the reworkCount from child lot to parent lot", __LINE__);
//D5000023
//D5000023        PosProcessFlowContext_var aChildPFX;
//D5000023        try
//D5000023        {
//D5000023            aChildPFX = aChildLot->getProcessFlowContext();
//D5000023        }
//D5000023        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext)
//D5000023//Q3000124 start
//D5000023        if(CORBA::is_nil(aChildPFX))
//D5000023        {
//D5000023            PPT_SET_MSG_RC_KEY( strLot_MergeWaferLot_out,
//D5000023                                MSG_NOT_FOUND_PFX,
//D5000023                                RC_NOT_FOUND_PFX, "" );
//D5000023            return RC_NOT_FOUND_PFX ;
//D5000023        }
//D5000023//Q3000124 end
//D5000023
//D5000023        PosProcessFlowContext_var aParentPFX;
//D5000023        try
//D5000023        {
//D5000023            aParentPFX = aParentLot->getProcessFlowContext();
//D5000023        }
//D5000023        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext)
//D5000023//Q3000124 start
//D5000023        if(CORBA::is_nil(aParentPFX))
//D5000023        {
//D5000023            PPT_SET_MSG_RC_KEY( strLot_MergeWaferLot_out,
//D5000023                                MSG_NOT_FOUND_PFX,
//D5000023                                RC_NOT_FOUND_PFX, "" );
//D5000023            return RC_NOT_FOUND_PFX ;
//D5000023        }
//D5000023//Q3000124 end
//D5000023
//D5000023        PosReworkCountSequence* aChildReworkCountSeq = NULL;
//D5000023        PosReworkCountSequence_var aChildReworkCountSeq_var;
//D5000023        try
//D5000023        {
//D5000023            aChildReworkCountSeq = aChildPFX->allReworkCounts();
//D5000023            aChildReworkCountSeq_var = aChildReworkCountSeq;
//D5000023        }
//D5000023        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::allReworkCounts)
//D5000023
//D5000023        CORBA::Long lenChildRewk = aChildReworkCountSeq->length();
//D5000023        for ( i=0; i < lenChildRewk; i++ )
//D5000023        {
//D5000023            CORBA::Long parentReworkCount;
//D5000023            try
//D5000023            {
//D5000023                parentReworkCount = aParentPFX->getReworkCount( (*aChildReworkCountSeq)[i].key );
//D5000023            }
//D5000023            CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getReworkCount)
//D5000023
//D5000023            if ( parentReworkCount < (*aChildReworkCountSeq)[i].reworkCount )
//D5000023            {
//D5000023                PPT_METHODTRACE_V1("PPTManager_i::lot_MergeWaferLot","parentReworkCount < (*aChildReworkCountSeq)[i].reworkCount");
//D5000023
//D5000023                try
//D5000023                {
//D5000023                    aParentPFX->setReworkCount( (*aChildReworkCountSeq)[i].key , (*aChildReworkCountSeq)[i].reworkCount );
//D5000023                }
//D5000023                CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::setReworkCount)
//D5000023            }
//D5000023        }

        try
        {
            aChildLot->setLastClaimedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedTimeStamp)

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID( aPerson,
                                    strObjCommonIn.strUser.userID,
                                    strLot_MergeWaferLot_out,
                                    lot_MergeWaferLot );

        try
        {
            aChildLot->setLastClaimedPerson( aPerson );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedPerson)
        try
        {
            aChildLot->setStateChangedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setStateChangedTimeStamp)
        try
        {
            aChildLot->setStateChangedPerson( aPerson );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setStateChangedPerson)


        try
        {
            aParentLot->setLastClaimedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedTimeStamp)
        try
        {
            aParentLot->setLastClaimedPerson( aPerson );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedPerson)
        try
        {
            aParentLot->setStateChangedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setStateChangedTimeStamp)
        try
        {
            aParentLot->setStateChangedPerson( aPerson );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setStateChangedPerson)
        try
        {
            aParentLot->setLastClaimAllWafers( strObjCommonIn.strTimeStamp.reportTimeStamp, aPerson );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimAllWafers)


        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_MergeWaferLot");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_MergeWaferLot_out, lot_MergeWaferLot, methodName)
}
