#ifndef lint
static char *sccsid =  "%Z% %I% %W% %G% %U% [ %H% %T% ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2009. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2009. All rights reserved.
//
// SiView
// Name: startLot_actionList_EffectSPCCheck__101.cpp
//

//INN-R170020#include "pptmgr.hpp"
#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "pmongrp.hh"
#include "ppcope.hh"
#include "ppcdf.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "pcas.hh"
#include "pmc.hh"
#include "pmcrc.hh"
#include "prdctspc.hh"  //P3000383
#include "ppcopsp.hh"   //D5000147

//Q3000284 (move to posconst.hpp) #define TIMESTAMP_NIL_OBJECT_STRING     "1901-01-01-00.00.00.000000"

// Class: PPTManager
//
//[Object Function Name]: long   startLot_actionList_EffectSPCCheck__101
//
// Change history:
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-08-24  0.00      H.Ueda         Initial Release                 (R30)
// 2000-09-21  Q3000124  K.Matsuei      Nil Check
// 2000-09-25  P3000219  R.Furuta       Change parameter for sprintf
// 2000-10-06  Q3000284  M.Ameshita     Fix assignment of endTimeStamp.
// 2000-10-10  Q3000284  Y.Iwasaki      Fix assignment of endTimeStamp.
// 2000-10-10  Q3000284  Y.Iwasaki      Bug fix
//                                       - TimeStamp set logic
//                                       - Entity inhibit list make logic
// 2000-12-18  P3000383  Y.Iwasaki      Bug fix for making E-mail
// 2001-01-24  P3000434  M.Ameshita     Fix no to skip spcCheckResult check logic when action
//                                      code is not set.
// 2001/03/16  P3100131  Y.Iwasaki      Bug fix for = operator usage
// 2002/01/08  P4100051  M.Shimizu      Entity Inhibit Owner Change
// 2002/07/29  P4200069  H.Adahci       Add LotID Length Check
// 2002/09/21  P4200133  M.Ameshita     Fix the case route hold and process hold are skipped.
// 2002/10/09  D4200115  C.Tsuchiya     Add "BankMove", "SendMail" and  "ReworkBranch"
// 2003/01/16  P4200517  H.Adachi       Fix missing of className for route_hold_inhibition and process_hold_inhibition.
// 2003/02/24  P4200215  C.Tsuchiya     Change SPC Chart Mail to use MessageDistribution
// 2003/06/30  P5000150  M.Ameshita     Fix not to set SPC action list when sub chart owner's user ID is not specified.
// 2003/07/04  D5000147  M.Ameshita     Add inhibitions for Equipment+Recipe and Process+Equipment.
// 2003/09/05  P5000282  M.Ameshita     Fix not to create message request when a chart owner is not specified.
// 2003/09/09  P5000145  H.Adachi       Fix Message and Message Macro mismatch.
// 2004/04/22  D5100227  H.Adachi       Add Chamber Inhibit SPC I/F.
// 2006/02/06  D7000178  M.Murata       Add reference condition for PO.
// 2006/04/11  P7000126  H.Mutoh        Fix number of cases of Mail and same Contents.
//
// Date        Level         Author         Note
// ----------  ------------  -------------  -------------------------------------------
// 2008/10/20  DSIV00000214  H.Mutoh        Multi Fab Transfer Support
// 2009/09/09  DSIV00001021  H.Nonaka       Multiple Corresponding Operations Support (R101)
// 2009/10/30  DSIV00001365  R.Okano        Entity Inhibit Improvement. (R101)
// 2009-11-16  PSIV00001581  R.Iriguchi     Fix uninitialized memory read
// 2010-01-20  PSIV00001648  R.Iriguchi     Fix bug around lot_countForMailOtherFab.
//
// Date        Level         Author         Note
// ----------  ------------  -------------  -------------------------------------------
// 2017/10/25  INN-R170020   liu Xinxin     SPC Add Action Code
//
//[Function Description]:
//  Check if actions of each strSpcCheckLot.
//  Then return the out-parameter data sequence as bellows;
//  If, the lot which is required to do action of SPC check result is Monitor-Lot,
//  and, some production lots are connected to its monitor, all of production lots are
//  effected the same action.
//
//  <1. strMessageList>
//     If actionCode is SP_ActionCode_Mail,
//        set message record to output parameter.
//
//  <2. strEntityInhibitions>
//     If actionCode is SP_ActionCode_Equipment,
//     If actionCode is SP_ActionCode_Recipe,
//     If actionCode is SP_ActionCode_Route,
//     If actionCode is SP_ActionCode_ProcessHold,
//
//     If actionCode has "ProcessHold", set the process hold record.
//     If the processed lot is monitored lot, set the monitored operation to output parameter.
//     If the processed lot is not monitored lot and it has a corresponding process operation, set it to output parameter.
//     If the processed lot is not monitored lot and it doesn't have a corresponding process operation,
//        set the current operation to output parameter.
//
//  <3. strBankMoveList>     //Added by D4200115
//     If actionCode is SP_ActionCode_BankMove,
//        set lot id and bank id.
//
//  <4. strMailSendList>    //Added by D4200115
//     If actionCode is SP_ActionCode_MailSend,
//        set mail addresses and message text.
//
//  <5. strReworkBranchList>     //Added by D4200115
//     If actionCode is SP_ActionCode_ReworkBranch,
//        set lot id and rework route id.
//
//[Input Parameters]:
//  in  pptObjCommonIn           strObjCommonIn;
//  in  pptSpcCheckLotSequence   strSpcCheckLot;
//  in  objectIdentifier         equipmentID;
//
//[Output Parameters]:
//  out objStartLot_actionList_EffectSPCCheck_out__101   strStartLot_actionList_EffectSPCCheck_out;
//
//  typedef struct objStartLot_actionList_EffectSPCCheck_out__101_struct{
//       pptRetCode            strResult;
//       sequence <pptMessageAttributes>        strMessageList;
//       sequence <pptEntityInhibitDetailAttributes>  strEntityInhibitions;
//       sequence <pptBankMove>                       strBankMoveList;        //D4200115 add
//       sequence <pptMailSend>                       strMailSendList;        //D4200115 add
//       sequence <pptReworkBranch>                   strReworkBranchList;    //D4200115 add
//       sequence <pptMessageAttributesWithFabInfo>            strMessageListWithFabInfo;
//       sequence <pptEntityInhibitAttributesWithFabInfo__101> strEntityInhibitionsWithFabInfo;
//       sequence <pptMailSendWithFabInfo>                     strMainSendListWithFabInfo;
//       sequence <pptDCActionLotResult>                       strDCActionLotResult;    //DSIV00001021
//  } objStartLot_actionList_EffectSPCCheck_out__101 ;
//
//  //
//  // 1)    typedef struct pptEntityInhibitDetailAttributes_struct
//  //       {
//  //           pptEntityIdentifierSequence entities;
//  //           stringSequence              subLotTypes;
//  //           string                      startTimeStamp;
//  //           string                      endTimeStamp;
//  //           string                      reasonCode;
//  //           string                      reasonDesc;
//  //           string                      memo;
//  //           objectIdentifier            ownerID;
//  //           string                      claimedTimeStamp;
//  //           pptEntityInhibitReasonDetailInfoSequence  strEntityInhibitReasonDetailInfos;
//  //       } pptEntityInhibitDetailAttributes;
//  //       typedef struct pptEntityIdentifier_struct
//  //       {
//  //           string           className;
//  //           objectIdentifier objectID;
//  //           string           attrib;
//  //       } pptEntityIdentifier;
//  //       typedef struct pptEntityInhibitReasonDetailInfo_struct
//  //       {
//  //           string                relatedLotID;
//  //           string                relatedControlJobID;
//  //           string                relatedFabID;
//  //           string                relatedRouteID;
//  //           string                relatedProcessDefinitionID;
//  //           string                relatedOperationNumber;
//  //           string                relatedOperationPassCount;
//  //           pptEntityInhibitSpcChartInfoSequence  strEntityInhibitSpcChartInfos;
//  //       } pptEntityInhibitReasonDetailInfo_struct;
//  //       typedef pptEntityInhibitSpcChartInfo_struct
//  //       {
//  //           string                relatedSpcDcType;
//  //           string                relatedSpcChartGroupID;
//  //           string                relatedSpcChartID;
//  //           string                relatedSpcChartType;
//  //           string                relatedSpcChartUrl;
//  //       } pptEntityInhibitSpcChartInfo;
//  //
//  // 2)    typedef struct pptMessageAttributes_struct
//  //       {
//  //           objectIdentifier      messageID;
//  //           objectIdentifier      lotID;
//  //           string                lotStatus;
//  //           objectIdentifier      equipmentID;
//  //           objectIdentifier      routeID;
//  //           string                operationNumber;
//  //           string                reasonCode;
//  //           string                messageText;
//  //       } pptMessageAttributes;
//  //
//  // 3)    typedef struct pptMailSend_struct
//  //       {
//  //           //D4200215 string              messageText;
//  //           //D4200215 stringSequence      chartMailAddress;
//  //           pptMessageAttributes           messageAttributes;    //D4200215
//  //           string                         chartMailAdderess;    //D4200215
//  //       } pptMailSend;
//  //
//  // 4)    typedef struct pptReworkBranch_struct
//  //       {
//  //           objectIdentifier    lotID;
//  //           objectIdentifier    reworkRouteID;
//  //           string              returnOperationNumber;
//  //       } pptReworkBranch;
//  //
//  // 5)    typedef struct pptBankMove_struct
//  //       {
//  //           objectIdentifier    lotID;
//  //           objectIdentifier    bankID;
//  //       } pptBankMove;
//  //
//  // 6)    typedef struct pptEntityInhibitAttributesWithFabInfo__101_struct
//  //       {
//  //           string                                   fabID;
//  //           pptEntityInhibitAttributes               strEntityInhibition;
//  //           pptEntityInhibitReasonDetailInfoSequence strEntityInhibitReasonDetailInfos;
//  //           any siInfo;
//  //       } pptEntityInhibitAttributesWithFabInfo__101;
//  //
//  // 7)    typedef struct pptMessageAttributesWithFabInfo_struct
//  //       {
//  //           string               fabID;
//  //           pptMessageAttributes strMessage;
//  //           any siInfo;
//  //       } pptMessageAttributesWithFabInfo;
//  //
//  // 3)    typedef struct pptMailSendWithFabInfo_struct
//  //       {
//  //           string       fabID;
//  //           pptMailSend  strMailSend;
//  //           any siInfo;
//  //       } pptMailSendWithFabInfo;
//  //
//  // 9)    typedef struct pptDCActionLotResult_struct     //DSIV00001021
//  //       {
//  //           objectIdentifier               measurementLotID;
//  //           pptDCActionResultInfoSequence  strDCActionResultInfo;
//  //           any                            siInfo;
//  //       } pptDCActionLotResult;
//
//[Return Value]:
//
//  Return Code                 Message ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_LOT            MSG_NOT_FOUND_LOT
//  RC_NOT_FOUND_PO             MSG_NOT_FOUND_PO
//  RC_NOT_FOUND_ROUTE          MSG_NOT_FOUND_ROUTE
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//
//[Pseudo Code]
//

CORBA::Long CS_PPTManager_i::startLot_actionList_EffectSPCCheck__101(
         objStartLot_actionList_EffectSPCCheck_out__101& strStartLot_actionList_EffectSPCCheck_out,
         const pptObjCommonIn& strObjCommonIn,
         const objStartLot_actionList_EffectSPCCheck_in__101& strStartLot_actionList_EffectSPCCheck_in )

{
    CORBA::Long rc = RC_OK;    //D4200115
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::startLot_actionList_EffectSPCCheck__101");

//DSIV00000214 add start
//DSIV00001021        const pptSpcCheckLotSequence& strSpcCheckLot = strStartLot_actionList_EffectSPCCheck_in.strSpcCheckLot;
        const pptSpcCheckLotSequence__101& strSpcCheckLot = strStartLot_actionList_EffectSPCCheck_in.strSpcCheckLot;//DSIV00001021
        const pptSpcIFParmSequence&   strSpcIFParm   = strStartLot_actionList_EffectSPCCheck_in.strSpcIFParm;
        const objectIdentifier&       equipmentID    = strStartLot_actionList_EffectSPCCheck_in.equipmentID;
        pptInterFabMonitorGroupActionInfoSequence strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSPCCheck_in.strInterFabMonitorGroupActionInfoSequence;
        CORBA::Long rel_mong_count = strInterFabMonitorGroupActionInfoSequence.length();
        PPT_METHODTRACE_V2("", "rel_mong_count", rel_mong_count);
//DSIV00000214 add end
//DSIV00001021 add start
        pptDCActionLotResultSequence strDCActionLotResult;
        strDCActionLotResult = strStartLot_actionList_EffectSPCCheck_in.strDCActionLotResult;
        CORBA::Long dcActionLot_count = strDCActionLotResult.length();
        PPT_METHODTRACE_V2("", "dcActionLot_count", dcActionLot_count);
//DSIV00001021 add end

        CORBA::Long i, k, m, n;
        CORBA::Long j, l, nItem, nChart, nRoute;    //D4200115
        CORBA::Long slLen = strSpcCheckLot.length();
        PPT_METHODTRACE_V2("", "strSpcCheckLot.length", slLen);

        PosMonitoredLotSequence effectedLots;

        CORBA::Boolean findFlag;
        CORBA::Long entity_count = 0;
        CORBA::Long msg_count = 0;
        CORBA::Long bank_move_count = 0;         //D4200115
        CORBA::Long rework_branch_count = 0;     //D4200115
        CORBA::Long mail_send_count = 0;         //D4200115
        CORBA::Long entity_countForOtherFab  = 0;     //DSIV00000214
//PSIV00001648        CORBA::Long lot_countForMailOtherFab = 0;     //DSIV00000214
        CORBA::Long p, msg_countPerMonLot    = 0;     //DSIV00000214
        CORBA::Boolean findLotFlag = FALSE;           //DSIV00000214
        CORBA::Boolean findMsgFlag = FALSE;           //DSIV00000214
        CORBA::Boolean findMonitoringLotFlag = FALSE; //DSIV00000214
        CORBA::Boolean requestOtherFabFlag   = FALSE; //DSIV00000214

        CORBA::Long eCnt = 0;                          //DSIV00001365
        CORBA::Long entity_count_keep = 0;             //DSIV00001365
        CORBA::Long entity_countForOtherFab_keep  = 0; //DSIV00001365

        for ( i = 0; i < slLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop counter [i]", i);

            /*---------------------------*/
            /*   Omit Non-DataCollection */
            /*---------------------------*/
            CORBA::Long lenActionCode = strSpcCheckLot[i].spcActionCode.length();
            PPT_METHODTRACE_V2("", "strSpcCheckLot[i].spcActionCode.length--->", lenActionCode);

            if ( 0 == lenActionCode )
            {
                PPT_METHODTRACE_V1("", "lenActionCode.length = 0");
//P3000434      continue;
            }

            //-----------------------------------------
            //  Get Lot ojbect
            //-----------------------------------------
//P4200069 Add Start
            PPT_METHODTRACE_V2("","strSpcCheckLot[i].lotID", strSpcCheckLot[i].lotID.identifier);
            if ( 0 >= CIMFWStrLen(strSpcCheckLot[i].lotID.identifier) )
            {
                PPT_METHODTRACE_V1("","lotID is 0 Length: CONTINUE");
                continue;
            }
//P4200069 Add End

            PPT_METHODTRACE_V1("", "Get Lot ojbect");

            PosLot_var aPosLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                         strSpcCheckLot[i].lotID,
                                         strStartLot_actionList_EffectSPCCheck_out,
                                         startLot_actionList_EffectSPCCheck__101 );

            ProcessOperation_var aTmpProcessOperation;
            PosProcessOperation_var aPO;
//D7000178            try
//D7000178            {
//D7000178                aTmpProcessOperation = aPosLot->getProcessOperation();
//D7000178                aPO = PosProcessOperation::_narrow( aTmpProcessOperation );
//D7000178            }
//D7000178            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)
//D7000178 add start
            //------------------------------------------
            // Current PO or Previous PO ?
            //------------------------------------------
            objLot_CheckConditionForPO_out strLot_CheckConditionForPO_out;
            rc = lot_CheckConditionForPO( strLot_CheckConditionForPO_out, strObjCommonIn,strSpcCheckLot[i].lotID);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_CheckConditionForPO() != RC_OK ") ;
                strStartLot_actionList_EffectSPCCheck_out.strResult = strLot_CheckConditionForPO_out.strResult;
                return( rc );
            }

            if ( strLot_CheckConditionForPO_out.currentPOFlag  == TRUE )
            {
                //--------------------------------------------------------------------------
                // Get PO from Current Operation.
                //--------------------------------------------------------------------------
                PPT_METHODTRACE_V1("", "Get PO from the current Operation.")

                try
                {
                    aTmpProcessOperation = aPosLot->getProcessOperation();
                    aPO = PosProcessOperation::_narrow( aTmpProcessOperation );
                }
                CATCH_AND_RAISE_EXCEPTIONS(Lot::getProcessOperation);
            }
            else
            {
                //--------------------------------------------------------------------------
                // Get PO from Previous Operation.
                //--------------------------------------------------------------------------
                PPT_METHODTRACE_V1("", "Get PO from the previous Operation.")
                try
                {
                    aTmpProcessOperation = aPosLot->getPreviousProcessOperation();
                    aPO = PosProcessOperation::_narrow( aTmpProcessOperation );
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getPreviousProcessOperation);
            }
//D7000178 add end

            if ( CORBA::is_nil( aPO ) )
            {
                PPT_METHODTRACE_V1("", "aPO is nil");
                PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
                                    MSG_NOT_FOUND_OPERATION,
                                    RC_NOT_FOUND_OPERATION,
                                    "" );

                return RC_NOT_FOUND_OPERATION;
            }

//DSIV00001365 add start
            CORBA::String_var currentFabID;
            try
            {
                currentFabID = aPO->getFabID();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessOperationLocation);

            PPT_METHODTRACE_V2("", "currentFabID", currentFabID);
            if( CIMFWStrLen(currentFabID) == 0 )
            {
                PPT_METHODTRACE_V1("", "currentFabID is null");
            }
//DSIV00001365 add end

            //-------------------------------------------------------
            //  Set always the input Lot to effectedLots[0]
            //  even if lot is monitor lot or not.
            //-------------------------------------------------------
            PPT_METHODTRACE_V1("", "Set always the input Lot to effectedLots[0]");

            effectedLots.length(1);
            effectedLots[0].lotID = strSpcCheckLot[i].lotID;
            effectedLots[0].processOperation = SP_OBJECT_TO_STRING( aPO );

//DSIV00001021 add start
            CORBA::String_var correspondingFabID;
            correspondingFabID  = strSpcCheckLot[i].processFabID;
            requestOtherFabFlag = strSpcCheckLot[i].requestOtherFabFlag;
//DSIV00001021 add end

            CORBA::Long interFabMonIdx;                 //PSIV00001648
            CORBA::Long lot_countForMailOtherFab;       //PSIV00001648

//DSIV00000214 add start
//DSIV00001021 delete start
//DSIV00001021            CORBA::String_var currentFabID;
//DSIV00001021            try
//DSIV00001021            {
//DSIV00001021                currentFabID = aPO->getFabID();
//DSIV00001021            }
//DSIV00001021            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getFabID);
//DSIV00001021
//DSIV00001021            PPT_METHODTRACE_V2("", "current FabID", currentFabID);
//DSIV00001021            if( CIMFWStrLen(currentFabID) == 0 )
//DSIV00001021            {
//DSIV00001021                PPT_METHODTRACE_V1("", "currentFabID is null");
//DSIV00001021            }
//DSIV00001021
//DSIV00001021            PosProcessFlowContext_var aPFX;
//DSIV00001021            try
//DSIV00001021            {
//DSIV00001021                aPFX = aPosLot->getProcessFlowContext();
//DSIV00001021            }
//DSIV00001021            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);
//DSIV00001021
//DSIV00001021            if ( CORBA::is_nil(aPFX) )
//DSIV00001021            {
//DSIV00001021                PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
//DSIV00001021                                    MSG_NOT_FOUND_PFX,
//DSIV00001021                                    RC_NOT_FOUND_PFX,
//DSIV00001021                                    "" );
//DSIV00001021
//DSIV00001021                return RC_NOT_FOUND_PFX;
//DSIV00001021            }
//DSIV00001021
//DSIV00001021            // Get the corresponding processOperation
//DSIV00001021            PPT_METHODTRACE_V1("", "Get the corresponding processOperation");
//DSIV00001021            PosProcessOperation_var aCorrespondingProcessOperation;
//DSIV00001021            CORBA::String_var correspondingFabID;
//DSIV00001021
//DSIV00001021            try
//DSIV00001021            {
//DSIV00001021                aCorrespondingProcessOperation = aPFX->getCorrespondingProcessOperationFor(aPO);
//DSIV00001021            }
//DSIV00001021            CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getCorrespondingProcessOperation);
//DSIV00001021
//DSIV00001021            if( CORBA::is_nil(aCorrespondingProcessOperation) != TRUE )
//DSIV00001021            {
//DSIV00001021                try
//DSIV00001021                {
//DSIV00001021                    correspondingFabID = aCorrespondingProcessOperation->getFabID();
//DSIV00001021                }
//DSIV00001021                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getFabID);
//DSIV00001021
//DSIV00001021                PPT_METHODTRACE_V2("", "corresponding FabID", correspondingFabID);
//DSIV00001021                if( CIMFWStrLen(correspondingFabID) == 0 )
//DSIV00001021                {
//DSIV00001021                    PPT_METHODTRACE_V1("", "correspondingFabID is null");
//DSIV00001021                }
//DSIV00001021
//DSIV00001021                if( CIMFWStrLen(currentFabID) != 0 && CIMFWStrLen(correspondingFabID) != 0 &&
//DSIV00001021                    CIMFWStrCmp(currentFabID, correspondingFabID) != 0 )
//DSIV00001021                {
//DSIV00001021                    PPT_METHODTRACE_V1("", "correspondingPO's Fab is not same the current.");
//DSIV00001021                    requestOtherFabFlag = TRUE;
//DSIV00001021                }
//DSIV00001021            }
//DSIV00001021            else
//DSIV00001021            {
//DSIV00001021                // correspondingPO is null.
//DSIV00001021            }
//DSIV00001021
//DSIV00001021 delete end

            objProcessOperation_Info_GetDR_out strProcessOperation_Info_GetDR_out;
            pptProcessOperationInfo strProcessOperationInfo;
            if ( requestOtherFabFlag == TRUE )
            {
                findMonitoringLotFlag = FALSE;
                PPT_METHODTRACE_V2("", "this lot has monitoredLots.", effectedLots[0].lotID.identifier);
                if( rel_mong_count > 0 )
                {
                    // if monitoringLot already checked, no add
                    for ( p = 0; p < rel_mong_count; p++ )
                    {
                        if( CIMFWStrCmp( effectedLots[0].lotID.identifier,
                                         strInterFabMonitorGroupActionInfoSequence[p].monitoringLotID.identifier ) == 0 )
                        {
                            PPT_METHODTRACE_V1("", "this monitoringLot already checked.");
                            interFabMonIdx = p;                                                                                             //PSIV00001648
                            lot_countForMailOtherFab = strInterFabMonitorGroupActionInfoSequence[p].strMonitoredLotMailInfoSeq.length();    //PSIV00001648
                            findMonitoringLotFlag = TRUE;
                            break;
                        }
                    }
                }

                if ( findMonitoringLotFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "this lot(monitoring) has not been checked");
                    //-------------------------------------------//
                    // create data for mailSend of monitoredLots //
                    //-------------------------------------------//
                    strInterFabMonitorGroupActionInfoSequence.length( rel_mong_count + 1 );
                    strInterFabMonitorGroupActionInfoSequence[rel_mong_count].fabID = CIMFWStrDup(correspondingFabID);
                    strInterFabMonitorGroupActionInfoSequence[rel_mong_count].monitoringLotID = effectedLots[0].lotID;
                    //initialize
                    strInterFabMonitorGroupActionInfoSequence[rel_mong_count].strMonitorGroupReleaseInfo.groupReleaseFlag = FALSE;
                    interFabMonIdx = rel_mong_count;        //PSIV00001648
                    lot_countForMailOtherFab = 0;           //PSIV00001648
                    rel_mong_count++;
                }

                //---------------------------------//
                // Get correspondingPO information //
                //---------------------------------//
                objProcessOperation_Info_GetDR_in  strProcessOperation_Info_GetDR_in;
                strProcessOperation_Info_GetDR_in.poObj = strSpcCheckLot[i].processObjrefPO;     //DSIV00000214
//DSIV00000214                strProcessOperation_Info_GetDR_in.poObj = SP_OBJECT_TO_STRING(aCorrespondingProcessOperation);
                rc = processOperation_Info_GetDR( strProcessOperation_Info_GetDR_out, strObjCommonIn,
                                                  strProcessOperation_Info_GetDR_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "processOperation_info_GetDR() != RC_OK", rc);
                    strStartLot_actionList_EffectSPCCheck_out.strResult = strProcessOperation_Info_GetDR_out.strResult;
                    return rc;
                }
                strProcessOperationInfo = strProcessOperation_Info_GetDR_out.strProcessOperationInfo;
            }
//DSIV00000214 add end

            //-----------------------------------------------------------
            //  Check Monitor Grouping existnce
            //  If not existed, the input lot is not monitor lot.
            //  If existed, the input lot is monitor lot.
            //-----------------------------------------------------------
//DSIV00001021 add start
            CORBA::Boolean requestOtherFabFlagForMonitor = FALSE;
            CORBA::String_var generatedFabID;
//DSIV00001021 add end
            //-----------------------------------------
            //  Check Monitor Grouping existnce
            //-----------------------------------------
            PPT_METHODTRACE_V1("", "Check Monitor Grouping existnce");

            PosMonitorGroup_var aMonitorGroup;
            try
            {
                aMonitorGroup = aPosLot->getControlMonitorGroup();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlMonitorGroup)

            if ( CORBA::is_nil(aMonitorGroup) )
            {
//Q3000284 delete start
//                PPT_METHODTRACE_V1("", "aMonitorGroup is nil");
//                // if current process is measurement, find corresponding process operation for action.
//                // else current process is process operation for action.
//
//                PosProcessDefinition_var aProcessDefinition;
//                try
//                {
//                    aProcessDefinition = aPO->getProcessDefinition();
//                }
//                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessDefinition);
//
//                if ( CORBA::is_nil(aProcessDefinition) )
//                {
//                    PPT_METHODTRACE_V1("", "aProcessDefinition is nil");
//                    PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
//                                        MSG_NOT_FOUND_PD,
//                                        RC_NOT_FOUND_PD,
//                                        "" );
//
//                    return RC_NOT_FOUND_PD;
//                }
//
//                CORBA::String_var pdType;
//                try
//                {
//                    pdType = aProcessDefinition->getProcessDefinitionType();
//                }
//                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getProcessDefinitionType)
//
//                PosProcessOperation_var aCorrespondingProcessOperation;
//
//                if ( 0 == CIMFWStrCmp(pdType, SP_OPEPDTYPE_MEASUREMENT) )
//                {
//                    PPT_METHODTRACE_V1("", "pdType == SP_OPEPDTYPE_MEASUREMENT");
//
//                    PosProcessFlowContext_var aPFX;
//                    try
//                    {
//                        aPFX = aPosLot->getProcessFlowContext();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);
//
//                    if ( CORBA::is_nil(aPFX) )
//                    {
//                        PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
//                                            MSG_NOT_FOUND_PFX,
//                                            RC_NOT_FOUND_PFX,
//                                            "" );
//
//                        return RC_NOT_FOUND_PFX;
//                    }
//                    //-------------------------------------------------
//                    //  Get the corresponding processOperation
//                    //-------------------------------------------------
//                    PPT_METHODTRACE_V1("", "Get the corresponding processOperation");
//
//                    try
//                    {
//                        aCorrespondingProcessOperation = aPFX->getCorrespondingProcessOperation();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getCorrespondingProcessOperation);
//                }
//
//                //   Override processOperation aPO of the input lot.
//                PPT_CONVERT_STRING_TO_OBJECT(effectedLots[0].processOperation, aCorrespondingProcessOperation, PosProcessOperation);
//Q3000284 delete end
            }
            //----------------------------------------------------------------
            //  When Monitor Grouping is existed get get all related lots.
            //----------------------------------------------------------------
            else
            {
                PPT_METHODTRACE_V1("", "When Monitor Grouping is existed get all related lots");

                PosMonitoredLotSequence*    monitoredLots = NULL;
                PosMonitoredLotSequence_var monitoredLots_var;
                try
                {
                    monitoredLots = aMonitorGroup->allLots();
                    monitoredLots_var = monitoredLots;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots)

                CORBA::Long nLenMonitoredLots = monitoredLots->length();
                effectedLots.length( nLenMonitoredLots + 1 );
                PPT_METHODTRACE_V2("", "effectedLots.length--->", nLenMonitoredLots + 1);

                for ( k = 0; k < nLenMonitoredLots; k++ )
                {
                    effectedLots[k+1].lotID            = (*monitoredLots)[k].lotID;
                    effectedLots[k+1].processOperation = (*monitoredLots)[k].processOperation;
                }
//DSIV00001021 add start
                //-------------------------------------------------
                //  Get GeneratedFabID
                //-------------------------------------------------
                try
                {
                    generatedFabID = aMonitorGroup->getGeneratedFabID();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosMonitorGroup::getGeneratedFabID);

                PPT_METHODTRACE_V2("", "generatedFabID", generatedFabID);
                if( CIMFWStrLen(generatedFabID) == 0 )
                {
                    PPT_METHODTRACE_V1("", "generatedFabID is null");
                }

                if( CIMFWStrLen(generatedFabID) != 0 && CIMFWStrLen(currentFabID) != 0 &&
                    CIMFWStrCmp(generatedFabID, currentFabID) != 0 )
                {
                    PPT_METHODTRACE_V1("", "currentFabID and generatedFabID is not same");
                    requestOtherFabFlagForMonitor = TRUE;
                }
//DSIV00001021 add end
            }

            CORBA::Boolean equipment_hold_flag = FALSE;
            CORBA::Boolean recipe_hold_flag    = FALSE;
            CORBA::Boolean route_hold_flag     = FALSE;
            CORBA::Boolean process_hold_flag   = FALSE;
            CORBA::Boolean mail_flag           = FALSE;
            CORBA::Boolean bank_move_flag      = FALSE;    //D4200115
//P7000126            CORBA::Boolean mail_send_flag      = FALSE;    //D4200115
            CORBA::Boolean rework_branch_flag  = FALSE;    //D4200115
            CORBA::Boolean equipment_and_recipe_hold_flag  = FALSE;    //D5000147
            CORBA::Boolean process_and_equipment_hold_flag = FALSE;    //D5000147
            CORBA::Boolean chamber_hold_flag        = FALSE;           //D5100227
            CORBA::Boolean chamber_recipe_hold_flag = FALSE;           //D5100227
            
            //INN-R170020 Add Start
            CORBA::Boolean product_hold_flag              = FALSE;
            CORBA::Boolean reticle_hold_flag              = FALSE;
            CORBA::Boolean reticlegroup_hold_flag         = FALSE;
            CORBA::Boolean module_hold_flag               = FALSE;
            CORBA::Boolean route_openo_product_hold_flag  = FALSE;
            CORBA::Boolean eqpt_openo_hold_flag           = FALSE;
            CORBA::Boolean eqpt_reticle_hold_flag         = FALSE;
            CORBA::Boolean eqpt_process_hold_flag         = FALSE;
            CORBA::Boolean eqpt_chamber_recipe_hold_flag  = FALSE;
            CORBA::Boolean eqpt_product_recipe_hold_flag  = FALSE;
            CORBA::Boolean route_openo_hold_flag          = FALSE;
            CORBA::Boolean eqpt_chamber_hold_flag         = FALSE;
            //INN-R170020 Add End
            
            CORBA::Boolean findMeasurementLotFlag = FALSE;      //DSIV00001021
            CORBA::Long dcActionLot_idx = 0;                    //DSIV00001021
            CORBA::Long dcActionInfo_count = 0;                 //DSIV00001021

            //=========================================================================================
            // Check actionCode
            //=========================================================================================
            for ( n = 0; n < lenActionCode; n++ )
            {
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_EquipmentHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_EquipmentHold");
                    equipment_hold_flag = TRUE;
                    mail_flag = TRUE;             //P3000383
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_RecipeHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_RecipeHold");
                    recipe_hold_flag = TRUE;
                    mail_flag = TRUE;             //P3000383
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_RouteHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_RouteHold");
                    route_hold_flag = TRUE;
                    mail_flag = TRUE;             //P3000383
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_ProcessHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_ProcessHold");
                    process_hold_flag = TRUE;
                    mail_flag = TRUE;             //P3000383
                }
//P3000383      if ( 0 == CIMFWStrCmp(strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_Mail) )
//P3000383      {
//P3000383          PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_Mail");
//P3000383          mail_flag = TRUE;
//P3000383      }
//D4200115 add start
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_BankMove ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_BankMove");
                    bank_move_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_MailSend ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_MailSend");
//P7000126                    mail_send_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_ReworkBranch ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_ReworkBranch");
                    rework_branch_flag = TRUE;
                    mail_flag = TRUE;
                }
//D4200115 add end
                if ( 0 == CIMFWStrCmp(strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_Equipment_and_RecipeHold ) )   //D5000147
                {                                                                                                      //D5000147
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_Equipment_and_RecipeHold");                    //D5000147
                    equipment_and_recipe_hold_flag = TRUE;                                                             //D5000147
                    mail_flag = TRUE;                                                                                  //D5000147
                }                                                                                                      //D5000147
                if ( 0 == CIMFWStrCmp(strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_Process_and_EquipmentHold ) )  //D5000147
                {                                                                                                      //D5000147
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_Process_and_EquipmentHold");                   //D5000147
                    process_and_equipment_hold_flag = TRUE;                                                            //D5000147
                    mail_flag = TRUE;                                                                                  //D5000147
                }                                                                                                      //D5000147
//D5100227 Add Start
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_ChamberHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_ChamberHold");
                    chamber_hold_flag = TRUE;
                    mail_flag = TRUE;
                }

                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], SP_ActionCode_ChamberAndRecipeHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_ChamberAndRecipeHold");
                    chamber_recipe_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
//D5100227 Add End

//INN-R170020 Add Start
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_ProductHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_ProductHold");
                    product_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_ReticleHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_ReticleHold");
                    reticle_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_ReticleGroupHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_ReticleGroupHold");
                    reticlegroup_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_ModuleHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_ModuleHold");
                    module_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_RouteOpeNoProductHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_RouteOpeNoProductHold");
                    route_openo_product_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_EqptOpeNoHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_EqptOpeNoHold");
                    eqpt_openo_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_EqptReticleHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_EqptReticleHold");
                    eqpt_reticle_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_EqptProcessHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_EqptProcessHold");
                    eqpt_process_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_EqptChamberRecipeHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_EqptChamberRecipeHold");
                    eqpt_chamber_recipe_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_EqptProductRecipeHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_EqptProductRecipeHold");
                    eqpt_product_recipe_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_RouteOpeNoHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_RouteOpeNoHold");
                    route_openo_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
                if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcActionCode[n], CS_SP_ActionCode_EqptChamberHold ) )
                {
                    PPT_METHODTRACE_V1("", "actionCode == CS_SP_ActionCode_EqptChamberHold");
                    eqpt_chamber_hold_flag = TRUE;
                    mail_flag = TRUE;
                }
//INN-R170020 Add End
            }

            //=========================================================================================
            //   Check spcCheckResult and set messageID
            //=========================================================================================
            CORBA::String_var messageID;

            if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcCheckResult, SP_SPCCheck_HoldLimitOff ) )
            {
                PPT_METHODTRACE_V1("", "messageID = CIMFWStrDup(SP_MessageID_SPCCheckOver)");
                messageID = CIMFWStrDup( SP_MessageID_SPCCheckOver );
                mail_flag = TRUE;             //P3000383
            }
//P3000383  else
            else if ( 0 == CIMFWStrCmp( strSpcCheckLot[i].spcCheckResult, SP_SPCCheck_WarningLimitOff ) ) //P3000383
            {
                PPT_METHODTRACE_V1("", "messageID = CIMFWStrDup(SP_MessageID_SPCCheckWarning)");
                messageID = CIMFWStrDup( SP_MessageID_SPCCheckWarning );
                mail_flag = TRUE;             //P3000383
            }

            //------------------------------------------------------------------------------------------------
            //  Make strEntityInhibitions of out parameter with SP_Reason_SpecOverInhibit reasonCode.
            //
            //    check actionCode of strSpcCheckLot.lot.
            //    ( actionCode are filled only when spcCheckResult is out of spec. )
            //       If actionCode is SP_ActionCode_Equipment,
            //       If actionCode is SP_ActionCode_Recipe,
            //       If actionCode is SP_ActionCode_Route,
            //       If actionCode is SP_ActionCode_ProcessHold,
            //       If actionCode is SP_ActionCode_Equipment_and_RecipeHold,                                          //D5000147
            //       If actionCode is SP_ActionCode_Process_and_EquipmentHold,                                         //D5000147
            //
            //       if actionCode has "ProcessHold", set the process hold record.
            //       If the processed lot is monitored lot, set the monitored operation to output parameter.
            //       If the processed lot is not monitored lot and it has a corresponding process operation,
            //          set it to output parameter.
            //       If the processed lot is not monitored lot and it doesn't have a corresponding process operation,
            //          set the current operation to output parameter.
            //
            //------------------------------------------------------------------------------------------------
            if ( equipment_hold_flag              == FALSE &&
                 recipe_hold_flag                 == FALSE &&
                 route_hold_flag                  == FALSE &&
                 process_hold_flag                == FALSE &&
                 equipment_and_recipe_hold_flag   == FALSE &&                                                          //D5000147
                 process_and_equipment_hold_flag  == FALSE &&                                                          //D5000147
                 chamber_hold_flag                == FALSE &&                                                          //D5100227
                 chamber_recipe_hold_flag         == FALSE &&                                                          //D5100227
//INN-R170020 Add Start
                 product_hold_flag                == FALSE &&                                                          
                 reticle_hold_flag                == FALSE &&                                                          
                 reticlegroup_hold_flag           == FALSE &&                                                          
                 module_hold_flag                 == FALSE &&                                                          
                 route_openo_product_hold_flag    == FALSE &&                                                          
                 eqpt_openo_hold_flag             == FALSE &&                                                          
                 eqpt_reticle_hold_flag           == FALSE &&                                                          
                 eqpt_process_hold_flag           == FALSE &&                                                          
                 eqpt_chamber_recipe_hold_flag    == FALSE &&                                                          
                 eqpt_product_recipe_hold_flag    == FALSE &&                                                          
                 route_openo_hold_flag            == FALSE &&                                                          
                 eqpt_chamber_hold_flag           == FALSE &&                                                          
//INN-R170020 Add End
                 mail_flag           == FALSE )
            {
                PPT_METHODTRACE_V1("", "Flag all FALSE");
                continue;
            }

//DSIV00001021 add start
            //------------------------------------------//
            // Get index of dcActionLot                 //
            //------------------------------------------//
            if ( findMeasurementLotFlag == FALSE )
            {
                for ( CORBA::Long q = 0; q < dcActionLot_count; q++ )
                {
                    if ( CIMFWStrCmp( effectedLots[0].lotID.identifier, strDCActionLotResult[q].measurementLotID.identifier ) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "this measurementLot already checked for Action Result.");
                        dcActionLot_idx = q;
                        dcActionInfo_count = strDCActionLotResult[q].strDCActionResultInfo.length();
                        findMeasurementLotFlag = TRUE;
                        break;
                    }
                }

                if ( findMeasurementLotFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "this lot(measurement) has not been checked for Action Result.");
                    //------------------------------------------//
                    // create data for DCActionLotResults       //
                    //------------------------------------------//
                    strDCActionLotResult.length( dcActionLot_count + 1 );
                    strDCActionLotResult[dcActionLot_count].measurementLotID = effectedLots[0].lotID;
                    dcActionLot_idx = dcActionLot_count;
                    dcActionLot_count++;
                    findMeasurementLotFlag = TRUE;
                }
                PPT_METHODTRACE_V3("", "strDCActionLotResult[dcActionLot_idx].measurementLotID", dcActionLot_idx, strDCActionLotResult[dcActionLot_idx].measurementLotID.identifier);
                PPT_METHODTRACE_V3("", "strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length start", dcActionLot_idx , dcActionInfo_count);
            }
//DSIV00001021 add end

//Q3000284 add start
            /*-----------------------------*/
            /*    For Representative Lot   */
            /*-----------------------------*/
            entity_count_keep = entity_count;                          //DSIV00001365
            entity_countForOtherFab_keep = entity_countForOtherFab;    //DSIV00001365
            if ( equipment_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "equipment_hold_flag == TRUE");

//DSIV00000214 add start
                if ( requestOtherFabFlag == FALSE )
                {
//DSIV00000214 add end
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check equipment_hold_inhibition is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_count; n++ )
                    {
                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                          && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier ) )
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
//P4100051                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier    = CIMFWStrDup("PPTSvcMgr");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID    = strObjCommonIn.strUser.userID;    //P4100051
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_EquipmentHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    //-------------------------------------------------------------------
                    //  Check equipment_hold_inhibition is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    PPT_METHODTRACE_V1("", "Check equipment_hold_inhibition is already registed or not");

                    findFlag = FALSE;   //PSIV00001581
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                          && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier ) )
                        {
                            PPT_METHODTRACE_V1("", "break!!");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]", strSpcCheckLot[i].processEquipmentID.identifier);
                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID    = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "break!!");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]", strSpcCheckLot[i].processEquipmentID.identifier);
                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_EquipmentHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
                }
//DSIV00000214 add end
            }
            if ( recipe_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "recipe_hold_flag == TRUE");

//DSIV00000214 add start
                if ( requestOtherFabFlag == FALSE )
                {
//DSIV00000214 add end
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check recipe_hold_inhibition is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_count; n++ )
                    {
                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_MachineRecipe )
                          && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier ) )
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
//P4100051                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier    = CIMFWStrDup("PPTSvcMgr");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID    = strObjCommonIn.strUser.userID;    //P4100051
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");
                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check recipe_hold_inhibition is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_MachineRecipe )
                          && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier ) )
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID    = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
                }
//DSIV00000214 add end
            }
            if ( route_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "route_hold_flag == TRUE");

//DSIV00000214 add start
                if ( requestOtherFabFlag == FALSE )
                {
//DSIV00000214 add end
                    findFlag = FALSE;                   //P4200133

                    for ( n = 0; n < entity_count; n++ )
                    {
//P4200517              if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
//P4200517                && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processRouteID.identifier) )

                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className,
                                               SP_InhibitClassID_Operation ) &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier,
                                               strSpcCheckLot[i].processRouteID.identifier ) )                                                     //P4200517
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processRouteID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
//P4100051                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier    = CIMFWStrDup("PPTSvcMgr");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID    = strObjCommonIn.strUser.userID;    //P4100051
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Route)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processRouteID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RouteHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processRouteID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;

                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className,
                                               SP_InhibitClassID_Operation ) &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier,
                                               strSpcCheckLot[i].processRouteID.identifier ) )                                                     //P4200517
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processRouteID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID    = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Route)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processRouteID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RouteHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processRouteID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
                }
//DSIV00000214 add end
            }
            if ( process_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "process_hold_flag == TRUE");

//DSIV00000214 add start
                if ( requestOtherFabFlag == FALSE )
                {
//DSIV00000214 add end
                    findFlag = FALSE;                   //P4200133

                    for ( n = 0; n < entity_count; n++ )
                    {
//P4200517              if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
//P4200517                && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processRouteID.identifier)
//4200517                 && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].attrib, strSpcCheckLot[i].processOperationNumber) )

                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className,
                                               SP_InhibitClassID_Operation )                 &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier,
                                               strSpcCheckLot[i].processRouteID.identifier ) &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].attrib,
                                               strSpcCheckLot[i].processOperationNumber ) )                                              //P4200517
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processRouteID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = strSpcCheckLot[i].processOperationNumber;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
//P4100051                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier    = CIMFWStrDup("PPTSvcMgr");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID    = strObjCommonIn.strUser.userID;    //P4100051
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Operation)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processRouteID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strSpcCheckLot[i].processOperationNumber)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ProcessHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processRouteID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = strSpcCheckLot[i].processOperationNumber;

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;

                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className,
                                               SP_InhibitClassID_Operation )                 &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier,
                                               strSpcCheckLot[i].processRouteID.identifier ) &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib,
                                               strSpcCheckLot[i].processOperationNumber ) )
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processRouteID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = strSpcCheckLot[i].processOperationNumber;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID    = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Operation)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processRouteID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strSpcCheckLot[i].processOperationNumber)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ProcessHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processRouteID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = strSpcCheckLot[i].processOperationNumber;

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
                }
//DSIV00000214 add end
            }

//D5000147 start ------------------------------------------------------------------------------------------------------------------------------------------------------//D5000147
            //---------------------------------------------------------------------------------------------                                                                        //D5000147
            // Inhibit Equipment and Recipe                                                                                                                                        //D5000147
            //---------------------------------------------------------------------------------------------                                                                        //D5000147
            if ( equipment_and_recipe_hold_flag == TRUE )                                                                                                                          //D5000147
            {                                                                                                                                                                      //D5000147
                PPT_METHODTRACE_V1("", "equipment_and_recipe_hold_flag == TRUE");                                                                                                  //D5000147
                                                                                                                                                                                   //D5000147
//DSIV00000214 add start
                if ( requestOtherFabFlag == FALSE )
                {
//DSIV00000214 add end
                    findFlag = FALSE;                                                                                                                                                  //D5000147
                    //-------------------------------------------------------------------                                                                                              //D5000147
                    //  Check equipment_and_recipe_hold_inhibition is already registed or not.                                                                                         //D5000147
                    //  If only not existed, entry new inhibition.                                                                                                                     //D5000147
                    //-------------------------------------------------------------------                                                                                              //D5000147
                    for ( n=0; n < entity_count; n++ )                                                                                                                                 //D5000147
                    {                                                                                                                                                                  //D5000147
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )                                                                 //D5000147
                        {                                                                                                                                                              //D5000147
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )              //D5000147
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )         //D5000147
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )          //D5000147
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )    //D5000147
                            {                                                                                                                                                          //D5000147
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");                                                                                                         //D5000147
                                findFlag = TRUE;                                                                                                                                       //D5000147
                                break;                                                                                                                                                 //D5000147
                            }                                                                                                                                                          //D5000147
                        }                                                                                                                                                              //D5000147
                    }                                                                                                                                                                  //D5000147
                                                                                                                                                                                   //D5000147
                    if ( findFlag == FALSE )                                                                                                                                           //D5000147
                    {                                                                                                                                                                  //D5000147
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");                                                                                                                   //D5000147
                                                                                                                                                                                   //D5000147
                        entity_count++;                                                                                                                                                //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);                                                                           //D5000147
                                                                                                                                                                                   //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);                                                             //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);               //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;                   //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");                                        //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);           //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;               //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");                                        //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);                                                          //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;            //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);            //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);            //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;                          //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;            //D5000147
                    }                                                                                                                                                                  //D5000147
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Equipment_and_RecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }                                                                                                                                                                  //D5000147
//DSIV00001021 add end
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check equipment_and_recipe_hold_inhibition is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Equipment_and_RecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
                }
//DSIV00000214 add end
            }                                                                                                                                                                      //D5000147
                                                                                                                                                                                   //D5000147
                                                                                                                                                                                   //D5000147
            //---------------------------------------------------------------------------------------------                                                                        //D5000147
            // Inhibit Process Definition and Equipment                                                                                                                            //D5000147
            //---------------------------------------------------------------------------------------------                                                                        //D5000147
            if ( process_and_equipment_hold_flag == TRUE )                                                                                                                         //D5000147
            {                                                                                                                                                                      //D5000147
                PPT_METHODTRACE_V1("", "process_and_equipment_hold_flag == TRUE");                                                                                                 //D5000147
                PPT_METHODTRACE_V2("", "strSpcCheckLot[i].processRouteID.identifier", strSpcCheckLot[i].processRouteID.identifier                 );                               //D5000147
                PPT_METHODTRACE_V2("", "strSpcCheckLot[i].processRouteID.strObjRef ", strSpcCheckLot[i].processRouteID.stringifiedObjectReference );                               //D5000147
                PPT_METHODTRACE_V2("", "strSpcCheckLot[i].processOperationNumber   ", strSpcCheckLot[i].processOperationNumber                    );                               //D5000147
                                                                                                                                                                                   //D5000147
//DSIV00000214 add start
                if( requestOtherFabFlag == FALSE )
                {
//DSIV00000214 add end
//DSIV00001021 indent move start
                    PosProcessDefinition_var  aMainProcessDefinition ;                                                                                                                 //D5000147
                    PosProcessDefinition_var  aProcessDefinition ;                                                                                                                     //D5000147
                                                                                                                                                                                       //D5000147
                    PPT_CONVERT_ROUTEID_TO_PROCESSDEFINITION_OR( aMainProcessDefinition,                                                                                               //D5000147
                                                                 strSpcCheckLot[i].processRouteID,                                                                                     //D5000147
                                                                 strStartLot_actionList_EffectSPCCheck_out,                                                                            //D5000147
                                                                 startLot_actionList_EffectSPCCheck__101 )                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    if( CORBA::is_nil( aMainProcessDefinition ) )                                                                                                                      //D5000147
                    {                                                                                                                                                                  //D5000147
                        PPT_METHODTRACE_V1("PPTManager_i::startLot_actionList_EffectSPCCheck", "CORBA::is_nil( aMainProcessDefinition )")                                              //D5000147
                        PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PD, RC_NOT_FOUND_PD, "" );                                                        //D5000147
                        return( RC_NOT_FOUND_PD );                                                                                                                                     //D5000147
                    }                                                                                                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    PosProcessFlow_var aProcessFlow;                                                                                                                                   //D5000147
                                                                                                                                                                                       //D5000147
                    try                                                                                                                                                                //D5000147
                    {                                                                                                                                                                  //D5000147
                        aProcessFlow = aMainProcessDefinition -> getActiveMainProcessFlow();                                                                                           //D5000147
                    }                                                                                                                                                                  //D5000147
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition_var::getActiveMainProcessFlow)                                                                                     //D5000147
                                                                                                                                                                                       //D5000147
                    if( CORBA::is_nil( aProcessFlow ) )                                                                                                                                //D5000147
                    {                                                                                                                                                                  //D5000147
                        PPT_METHODTRACE_V1("PPTManager_i::startLot_actionList_EffectSPCCheck", "CORBA::is_nil( aProcessFlow )")                                                        //D5000147
                        PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PF, RC_NOT_FOUND_PF, "" )                                                         //D5000147
                        return RC_NOT_FOUND_PF ;                                                                                                                                       //D5000147
                    }                                                                                                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    if( aProcessFlow->isNewlyCreated() )                                                                                                                               //D5000147
                    {                                                                                                                                                                  //D5000147
                        PPT_METHODTRACE_V1("","aProcessFlow->isNewlyCreated() is TRUE")                                                                                                //D5000147
                        if( !CORBA::is_nil( aPosLot ) )                                                                                                                                //D5000147
                        {                                                                                                                                                              //D5000147
                            PPT_METHODTRACE_V1("","aLot is not nil");                                                                                                                  //D5000147
                            ProcessFlow_var aPF;                                                                                                                                       //D5000147
                            try                                                                                                                                                        //D5000147
                            {                                                                                                                                                          //D5000147
                                aPF = aPosLot->getProcessFlow();                                                                                                                       //D5000147
                            }                                                                                                                                                          //D5000147
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlow);                                                                                                        //D5000147
                                                                                                                                                                                       //D5000147
                            aProcessFlow = PosProcessFlow::_narrow(aPF);                                                                                                               //D5000147
                            if( CORBA::is_nil( aProcessFlow ) )                                                                                                                        //D5000147
                            {                                                                                                                                                          //D5000147
                                PPT_METHODTRACE_V1("PPTManager_i::startLot_actionList_EffectSPCCheck", "CORBA::is_nil( aProcessFlow )")                                                //D5000147
                                PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PF, RC_NOT_FOUND_PF, "" )                                                 //D5000147
                                return RC_NOT_FOUND_PF ;                                                                                                                               //D5000147
                            }                                                                                                                                                          //D5000147
                        }                                                                                                                                                              //D5000147
                        else                                                                                                                                                           //D5000147
                        {                                                                                                                                                              //D5000147
                            PPT_METHODTRACE_V1("PPTManager_i::startLot_actionList_EffectSPCCheck", "CORBA::is_nil( aProcessFlow )")                                                    //D5000147
                            PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PF, RC_NOT_FOUND_PF, "" )                                                     //D5000147
                            return RC_NOT_FOUND_PF ;                                                                                                                                   //D5000147
                        }                                                                                                                                                              //D5000147
                    }                                                                                                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    PosProcessOperationSpecification_var aPOS;                                                                                                                         //D5000147
                                                                                                                                                                                       //D5000147
                    PosProcessFlow_var aOutMainPF, aOutModulePF;                                                                                                                       //D5000147
                    try                                                                                                                                                                //D5000147
                    {                                                                                                                                                                  //D5000147
                        aPOS = aProcessFlow->getProcessOperationSpecificationFor( strSpcCheckLot[i].processOperationNumber, aOutMainPF, aOutModulePF );                                //D5000147
                    }                                                                                                                                                                  //D5000147
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlow_var::getProcessOperationSpecificationFor)                                                                                //D5000147
                                                                                                                                                                                       //D5000147
                    PosProcessDefinition_var aPosPD ;                                                                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    if( ! CORBA::is_nil(aPOS) )                                                                                                                                        //D5000147
                    {                                                                                                                                                                  //D5000147
                        PPT_METHODTRACE_V1("","aPOS is not nil")                                                                                                                       //D5000147
                                                                                                                                                                                       //D5000147
                        ProcessDefinitionSequence* aProcessDefSeq = NULL;                                                                                                              //D5000147
                        ProcessDefinitionSequence_var aProcessDefSeqVar ;                                                                                                              //D5000147
                        try                                                                                                                                                            //D5000147
                        {                                                                                                                                                              //D5000147
                            aProcessDefSeq = aPOS -> getProcessDefinitions();                                                                                                          //D5000147
                            aProcessDefSeqVar = aProcessDefSeq ;                                                                                                                       //D5000147
                        }                                                                                                                                                              //D5000147
                        CATCH_AND_RAISE_EXCEPTIONS(ProcessOperationSpecification_var::getProcessDefinitions)                                                                           //D5000147
                                                                                                                                                                                       //D5000147
                        aPosPD = PosProcessDefinition::_narrow( (*aProcessDefSeq)[0] ) ;                                                                                               //D5000147
                                                                                                                                                                                       //D5000147
                        if( CORBA::is_nil(aPosPD) )                                                                                                                                    //D5000147
                        {                                                                                                                                                              //D5000147
                            PPT_METHODTRACE_V1("PPTManager_i::startLot_actionList_EffectSPCCheck", "CORBA::is_nil( aMainProcessDefinition )")                                          //D5000147
                            PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PD, RC_NOT_FOUND_PD, "" );                                                    //D5000147
                            return RC_NOT_FOUND_PD ;                                                                                                                                   //D5000147
                        }                                                                                                                                                              //D5000147
                    }                                                                                                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    objectIdentifier processPDID;                                                                                                                                      //D5000147
                    PPT_SET_OBJECT_IDENTIFIER( processPDID, aPosPD, strStartLot_actionList_EffectSPCCheck_out, strStartLot_actionList_EffectSPCCheck, PosProcessDefinition);           //D5000147
                                                                                                                                                                                       //D5000147
                    PPT_METHODTRACE_V1("", processPDID.identifier );                                                                                                                   //D5000147
                                                                                                                                                                                       //D5000147
                    findFlag = FALSE;                                                                                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    //-------------------------------------------------------------------                                                                                              //D5000147
                    //  Check process_and_equipment_hold_inhibition is already registed or not.                                                                                        //D5000147
                    //  If only not existed, entry new inhibition.                                                                                                                     //D5000147
                    //-------------------------------------------------------------------                                                                                              //D5000147

                    for ( n=0; n < entity_count; n++ )                                                                                                                                 //D5000147
                    {                                                                                                                                                                  //D5000147
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )                                                                 //D5000147
                        {                                                                                                                                                              //D5000147
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Operation )              //D5000147
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, processPDID.identifier )         //D5000147
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_Equipment )              //D5000147
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier ) )       //D5000147
                            {                                                                                                                                                          //D5000147
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");                                                                                                         //D5000147
                                findFlag = TRUE;                                                                                                                                       //D5000147
                                break;                                                                                                                                                 //D5000147
                            }                                                                                                                                                          //D5000147
                        }                                                                                                                                                              //D5000147
                    }                                                                                                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    if ( findFlag == FALSE )                                                                                                                                           //D5000147
                    {                                                                                                                                                                  //D5000147
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");                                                                                                                   //D5000147
                                                                                                                                                                                       //D5000147
                        entity_count++;                                                                                                                                                //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);                                                                           //D5000147
                                                                                                                                                                                       //D5000147
                                                                                                                                                                                       //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);                                                             //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);                 //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = processPDID;                                            //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");                                        //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);               //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processEquipmentID;                   //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");                                        //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);                                                          //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;            //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);            //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);            //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;                          //D5000147
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;            //D5000147
                    }                                                                                                                                                                  //D5000147
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Process)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, processPDID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Process_and_EquipmentHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = processPDID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
//DSIV00001021 indent move end
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");

                    findFlag = FALSE;

                    //-------------------------------------------------------------------
                    //  Check process_and_equipment_hold_inhibition is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Operation )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.pdID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier ) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strProcessOperationInfo.pdID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Process)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.pdID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Process_and_EquipmentHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.pdID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
                }
//DSIV00000214 add end
            }                                                                                                                                                                      //D5000147
//D5000147 end --------------------------------------------------------------------------------------------------------------------------------------------------------//D5000147

//D5100227 Add Start
            //----------------------------
            // Inhibit Chamber
            //----------------------------
            if ( chamber_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "chamber_hold_flag == TRUE");

//DSIV00000214 add start
                if ( requestOtherFabFlag == FALSE )
                {
//DSIV00000214 add end
                    findFlag = FALSE;

                    for ( n = 0; n < entity_count; n++ )
                    {
                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className,
                                               SP_InhibitClassID_Chamber                       )   &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier,
                                               strSpcCheckLot[i].processEquipmentID.identifier )   &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].attrib,
                                               strSpcCheckLot[i].processChamberID.identifier ))
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID    = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;

                        PPT_METHODTRACE_V3("","***Inhibit Chamber: ChamberID",strSpcCheckLot[i].processChamberID.identifier,i);
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Chamber)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strSpcCheckLot[i].processChamberID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ChamberHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;

                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className,
                                               SP_InhibitClassID_Chamber                       )   &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier,
                                               strSpcCheckLot[i].processEquipmentID.identifier )   &&
                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib,
                                               strSpcCheckLot[i].processChamberID.identifier ))
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                            break;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID    = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;

                        PPT_METHODTRACE_V3("","***Inhibit Chamber: ChamberID",strSpcCheckLot[i].processChamberID.identifier,i);
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Chamber)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strSpcCheckLot[i].processChamberID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ChamberHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
                }
//DSIV00000214 add end
            }

            //---------------------------
            // Inhibit Chamber And Recipe
            //---------------------------
            if ( chamber_recipe_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "chamber_recipe_hold_flag == TRUE");

//DSIV00000214 add start
                if ( requestOtherFabFlag == FALSE )
                {
//DSIV00000214 add end
                    findFlag = FALSE;

                    for ( n = 0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className,
                                                   SP_InhibitClassID_Chamber )                       &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier,
                                                   strSpcCheckLot[i].processEquipmentID.identifier ) &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].attrib,
                                                   strSpcCheckLot[i].processChamberID.identifier )   &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className,
                                                   SP_InhibitClassID_MachineRecipe )                 &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier,
                                                   strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID    = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;

                        PPT_METHODTRACE_V3("","***Inhibit Chamber+Recipe: ChamberID",strSpcCheckLot[i].processChamberID.identifier,i);
                    }

//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Chamber)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strSpcCheckLot[i].processChamberID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ChamberAndRecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;

                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className,
                                                   SP_InhibitClassID_Chamber )                       &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier,
                                                   strSpcCheckLot[i].processEquipmentID.identifier ) &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib,
                                                   strSpcCheckLot[i].processChamberID.identifier )   &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className,
                                                   SP_InhibitClassID_MachineRecipe )                 &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier,
                                                   strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID    = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;

                        PPT_METHODTRACE_V3("","***Inhibit Chamber+Recipe: ChamberID",strSpcCheckLot[i].processChamberID.identifier,i);
                    }
//DSIV00001021 add start
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Chamber)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strSpcCheckLot[i].processChamberID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ChamberAndRecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
//DSIV00001021 add end
                }
//DSIV00000214 add end
            }
            
//INN-R170020 Add start
            //---------------------------------------------------------------------------------------------
            // Product Inhibit
            //---------------------------------------------------------------------------------------------
            if ( product_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "product_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Product Inhibit is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_ProductHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Product is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_ProductHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Reticle Inhibit
            //---------------------------------------------------------------------------------------------
            if ( reticle_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "reticle_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Reticle Inhibit is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_ReticleHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Reticle is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_ReticleHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Reticle Group Inhibit
            //---------------------------------------------------------------------------------------------
            if ( reticlegroup_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "reticlegroup_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Reticle Group Inhibit is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_ReticleGroupHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Reticle Group is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_ReticleGroupHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Module Def. Inhibit
            //---------------------------------------------------------------------------------------------
            if ( module_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "module_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Module Def. Inhibit is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_ModuleHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Module Def. is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_ModuleHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Route Ope No. and Product Inhibit
            //---------------------------------------------------------------------------------------------
            if ( route_openo_product_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "route_openo_product_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Route Ope No. and Product Inhibit is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_RouteOpeNoProductHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Route Ope No. and Product is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_RouteOpeNoProductHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Equipment and Ope No. Inhibit
            //---------------------------------------------------------------------------------------------
            if ( eqpt_openo_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "eqpt_openo_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Ope No. Inhibit is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_EqptOpeNoHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Ope No. is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_EqptOpeNoHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Equipment and Reticle Inhibit
            //---------------------------------------------------------------------------------------------
            if ( eqpt_reticle_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "eqpt_reticle_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Reticle Inhibit is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_EqptReticleHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Reticle is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_EqptReticleHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Equipment and Process Hold
            //---------------------------------------------------------------------------------------------
            if ( eqpt_process_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "eqpt_process_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Process Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_EqptProcessHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Process Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_EqptProcessHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Equipment and Chamber and Recipe Hold
            //---------------------------------------------------------------------------------------------
            if ( eqpt_chamber_recipe_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "eqpt_chamber_recipe_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Chamber and Recipe Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_EqptChamberRecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Chamber and Recipe Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_EqptChamberRecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Equipment and Product and Recipe Hold
            //---------------------------------------------------------------------------------------------
            if ( eqpt_product_recipe_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "eqpt_product_recipe_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Product and Recipe Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_EqptProductRecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Product and Recipe Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_EqptProductRecipeHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Route and Ope No. Hold
            //---------------------------------------------------------------------------------------------
            if ( route_openo_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "route_openo_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Route and Ope No. Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_RouteOpeNoHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Route and Ope No. Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_RouteOpeNoHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
            //---------------------------------------------------------------------------------------------
            // Equipment and Chamber Hold
            //---------------------------------------------------------------------------------------------
            if ( eqpt_chamber_hold_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "eqpt_chamber_hold_flag == TRUE");
                if ( requestOtherFabFlag == FALSE )
                {
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Chamber Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n=0; n < entity_count; n++ )
                    {
                        if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }

                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                 = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag        = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID               = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID              = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType             = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode            = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode            = CIMFWStrDup( CS_SP_ActionCode_EqptChamberHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID         = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    findFlag = FALSE;
                    //-------------------------------------------------------------------
                    //  Check Equipment and Chamber Hold is already registed or not.
                    //  If only not existed, entry new inhibition.
                    //-------------------------------------------------------------------
                    for ( n = 0; n < entity_countForOtherFab; n++ )
                    {
                        if ( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        entity_countForOtherFab++;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);

                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                        strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    }
                    findFlag = FALSE;
                    for ( n = 0; n < dcActionInfo_count; n++ )
                    {
                        if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                        {
                            if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strSpcCheckLot[i].processEquipmentID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strSpcCheckLot[i].processMachineRecipeID.identifier)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                              && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                findFlag = TRUE;
                                break;
                            }
                        }
                    }

                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( CS_SP_ActionCode_EqptChamberHold );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strSpcCheckLot[i].processEquipmentID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strSpcCheckLot[i].processMachineRecipeID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                        dcActionInfo_count++;
                    }
                }
            }
//INN-R1170020 Add End
//DSIV00001365 add start
            //-----------------------------------------------------------------------------
            // Set Entity Inhibit Reason Detail Information
            //-----------------------------------------------------------------------------
            // For Representive Lot
            for ( eCnt = entity_count_keep; eCnt < entity_count; eCnt++ )
            {
                PPT_SET_ENTITYINHIBITREASONDETAILINFO_FROM_PPTSPCRESULT_AND_DCTYPE(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[eCnt],strSpcCheckLot[i].strSpcResult,strSpcIFParm[0].spcInput.collectionType)
            }
            // For Other Fab
            for ( eCnt = entity_countForOtherFab_keep; eCnt < entity_countForOtherFab; eCnt++ )
            {
                PPT_SET_ENTITYINHIBITREASONDETAILINFO_FROM_PPTSPCRESULT_AND_DCTYPE(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[eCnt],strSpcCheckLot[i].strSpcResult,strSpcIFParm[0].spcInput.collectionType)
                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedFabID = CIMFWStrDup( currentFabID );
            }
//DSIV00001365 add end

//D5100227 Add End

            //------------------------------------------------------------------------------------------------
            //  Make strMessageAttributes of out parameter.
            //
            //    ( actionCode are filled only when spcCheckResult is SP_ActionCode_Mail. )
            //------------------------------------------------------------------------------------------------
            if ( mail_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "mail_flag == TRUE");

                if ( 0 == CIMFWStrCmp(strSpcCheckLot[i].spcCheckResult, SP_SPCCheck_HoldLimitOff)
                  || 0 == CIMFWStrCmp(strSpcCheckLot[i].spcCheckResult, SP_SPCCheck_WarningLimitOff) )
                {
//P3000383          CORBA::String_var messageText;
                    char              tmpMsg[1024];      //P3000383
                    PPT_METHODTRACE_V1("", "strSpcCheckLot[i].spcCheckResult == SP_SPCCheck_HoldLimitOff or SP_SPCCheck_WarningLimitOff");

//P3000383 delete start
//                    sprintf(messageText, "ProductID:                  %s \n"\
//                                         "ProcessRouteID:             %s \n"\
//                                         "ProcessOperationNumber:     %s \n"\
//                                         "ProcessEquipmentID:         %s \n"\
//                                         "ProcessMachineRecipeID:     %s \n"\
////Q3000284                               "DataCollectionDefinitionID: %s",
//                                         "DataCollectionDefinitionID: ",                //Q3000284
//                                         strSpcCheckLot[i].productID.identifier,
//                                         strSpcCheckLot[i].processRouteID.identifier,
//                                         strSpcCheckLot[i].processOperationNumber,
//                                         strSpcCheckLot[i].processEquipmentID.identifier,
//                                         strSpcCheckLot[i].processMachineRecipeID.identifier);
//P3000383 delete end

//P3000383 add start
                    memset( tmpMsg, '\0', sizeof(tmpMsg) );

                    sprintf( tmpMsg, "=============================================\n"\
                                     "===       SPC Violation Information       ===\n"\
                                     "=============================================\n"\
                                     "LotID                  : %s \n"\
                                     "ProductID              : %s \n"\
                                     "ProcessRouteID         : %s \n"\
                                     "ProcessOperationNumber : %s \n"\
                                     "ProcessEquipmentID     : %s \n"\
                                     "ProcessChamberID       : %s \n"\
                                     "ProcessMachineRecipeID : %s ",
                             (const char *)(strSpcCheckLot[i].lotID.identifier                 ),
                             (const char *)(strSpcCheckLot[i].productID.identifier             ),
                             (const char *)(strSpcCheckLot[i].processRouteID.identifier        ),
                             (const char *)(strSpcCheckLot[i].processOperationNumber           ),
                             (const char *)(strSpcCheckLot[i].processEquipmentID.identifier    ),
                             (const char *)(strSpcCheckLot[i].processChamberID.identifier      ),                 //D5100227
                             (const char *)(strSpcCheckLot[i].processMachineRecipeID.identifier) );
//P3000383 add end

                    findFlag = FALSE;
                    //--------------------------------------------------------------------------------------------------
                    //  Check if strMessageAttributes is already registed with the same lotID & reasonCode or not.
                    //  If only not existed, entry new inhibition.
                    //
                    //--------------------------------------------------------------------------------------------------
                    for ( n = 0; n < msg_count; n++ )
                    {
//DSIV00001021                        if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].reasonCode, strSpcCheckLot[i].spcCheckResult)
//DSIV00001021                          && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier) )
//DSIV00001021 add start
                        if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].reasonCode, strSpcCheckLot[i].spcCheckResult)
                          && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].lotID.identifier, strSpcCheckLot[i].lotID.identifier)
                          && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].routeID.identifier, strSpcCheckLot[i].processRouteID.identifier)
                          && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].operationNumber, strSpcCheckLot[i].processOperationNumber) )
//DSIV00001021 add end
                        {
                            PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                            findFlag = TRUE;
                        }
                    }
                    if ( findFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "findFlag == FALSE");

                        msg_count++;
                        strStartLot_actionList_EffectSPCCheck_out.strMessageList.length(msg_count);

                        strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].messageID.identifier = messageID;
                        strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].lotID                = strSpcCheckLot[i].lotID;
//P3000131              strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].lotStatus            = "";
                        strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].lotStatus            = CIMFWStrDup("");  //P3100131
//DSIV00000214                        strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].equipmentID          = strSpcCheckLot[i].processEquipmentID;
                        strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].routeID              = strSpcCheckLot[i].processRouteID;
                        strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].operationNumber      = strSpcCheckLot[i].processOperationNumber;
                        strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].reasonCode           = strSpcCheckLot[i].spcCheckResult;
//P3000383              strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].messageText          = messageText;
                        strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].messageText          = CIMFWStrDup( tmpMsg ); //P3000383

//DSIV00001021 add start
                        //-----------------------------------------------------------------------------
                        // Add ActionResultInfo
                        //-----------------------------------------------------------------------------
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_MailSend );
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                        strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(0);
                        dcActionInfo_count++;
//DSIV00001021 add end

                    }
                }
            }
//Q3000284 add end
//D4200115 add start
            //------------------------------------------------------------------------------------------------
            //  Make strBankMoveList of out parameter. (DCR4200115)
            //
            //    ( actionCode are filled only when spcCheckResult is SP_ActionCode_BankMove. )
            //------------------------------------------------------------------------------------------------
            if ( bank_move_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "bankMoveFlag == TRUE");
                PPT_METHODTRACE_V2("", "strSpcCheckLot[i].strSpcResult.bankID", strSpcCheckLot[i].strSpcResult.bankID);

                bank_move_count = strStartLot_actionList_EffectSPCCheck_out.strBankMoveList.length();
                PPT_METHODTRACE_V2("", "strBankMoveList.length", bank_move_count);

                strStartLot_actionList_EffectSPCCheck_out.strBankMoveList.length(bank_move_count+1);
                strStartLot_actionList_EffectSPCCheck_out.strBankMoveList[bank_move_count].lotID
                    = strSpcCheckLot[i].lotID;
                strStartLot_actionList_EffectSPCCheck_out.strBankMoveList[bank_move_count].bankID.identifier
                    = strSpcCheckLot[i].strSpcResult.bankID;

//DSIV00001021 add start
                //-----------------------------------------------------------------------------
                // Add ActionResultInfo
                //-----------------------------------------------------------------------------
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_BankMove );
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = strSpcCheckLot[i].strSpcResult.bankID;
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(0);

                dcActionInfo_count++;
//DSIV00001021 add end

            }

            //------------------------------------------------------------------------------------------------
            //  Make strReworkBranchList of out parameter. (DCR4200115)
            //
            //    ( actionCode are filled only when spcCheckResult is SP_ActionCode_ReworkBranch. )
            //------------------------------------------------------------------------------------------------
            if ( rework_branch_flag == TRUE )
            {
                PPT_METHODTRACE_V1("", "reworkBranchFlag == TRUE");
                PPT_METHODTRACE_V2("", "strSpcCheckLot[i].strSpcResult.reworkRouteID", strSpcCheckLot[i].strSpcResult.reworkRouteID);

                objProcess_connectedRouteList_out strProcess_connectedRouteList_out ;
                rc = process_connectedRouteList( strProcess_connectedRouteList_out,
                                                 strObjCommonIn,
                                                 SP_MAINPDTYPE_REWORK,
                                                 strSpcCheckLot[i].lotID ) ;

                if ( rc == RC_OK )
                {
                    PPT_METHODTRACE_V1("", "process_connectedRouteList == RC_OK");

                    nRoute = strProcess_connectedRouteList_out.strConnectedRouteList.length();
                    PPT_METHODTRACE_V2("", "strConnectedRouteList.length", nRoute);

                    CORBA::Long rework_route_found = 0;

                    for ( j = 0; j < nRoute; j++ )
                    {
                        PPT_METHODTRACE_V3("", "strConnectedRouteList[j].routeID", strProcess_connectedRouteList_out.strConnectedRouteList[j].routeID.identifier, j);
                        if ( 0 == CIMFWStrCmp(strSpcCheckLot[i].strSpcResult.reworkRouteID,
                                              strProcess_connectedRouteList_out.strConnectedRouteList[j].routeID.identifier))
                        {
                            PPT_METHODTRACE_V1("", "processRouteID == routeID");

                            rework_branch_count = strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList.length();
                            PPT_METHODTRACE_V2("", "strReworkBranchList.length", rework_branch_count);

                            strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList.length(rework_branch_count+1);

                            strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList[rework_branch_count].lotID
                                = strSpcCheckLot[i].lotID;
                            strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList[rework_branch_count].reworkRouteID.identifier
                                = strSpcCheckLot[i].strSpcResult.reworkRouteID;
                            strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList[rework_branch_count].returnOperationNumber
                                = strProcess_connectedRouteList_out.strConnectedRouteList[j].returnOperationNumber;
                            rework_route_found = 1;
//DSIV00001021 add start
                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = strSpcCheckLot[i].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = false;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ReworkBranch );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = strSpcCheckLot[i].strSpcResult.reworkRouteID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(0);

                            dcActionInfo_count++;
//DSIV00001021 add end

                        }
                    }
                    if ( rework_route_found == 0 )
                    {
                        PPT_METHODTRACE_V2("", "ReworkRoute is not found ", strSpcCheckLot[i].strSpcResult.reworkRouteID);
                        PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
                                            MSG_NOT_FOUND_ROUTE,
                                            RC_NOT_FOUND_ROUTE,
                                            strSpcCheckLot[i].strSpcResult.reworkRouteID );
                        return RC_NOT_FOUND_ROUTE;
                    }
                }
                else if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","process_connectedRouteList() rc != RC_OK");
                    strStartLot_actionList_EffectSPCCheck_out.strResult = strProcess_connectedRouteList_out.strResult;
                    return( rc );
                }
            }

            //------------------------------------------------------------------------------------------------
            //  Make strMailSendList of out parameter. (DCR4200115)
            //
            //    ( actionCode are filled only when spcCheckResult is SP_ActionCode_MailSend. )
            //------------------------------------------------------------------------------------------------
//P7000126            if ( mail_send_flag == TRUE )
//P7000126            {
//P7000126                PPT_METHODTRACE_V1("", "mailSendFlag == TRUE");
//P7000126
//P7000126                char              tmpMsg[1024];
//P7000126
//P7000126                mail_send_count = strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length();
//P7000126                PPT_METHODTRACE_V2("", "strMailSendList.length()", mail_send_count);
//P7000126
//P7000126                nItem = strSpcCheckLot[i].strSpcResult.strSpcDcItem.length();
//P7000126                for ( j=0; j < nItem; j++ )
//P7000126                {
//P7000126                    nChart = strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart.length();
//P7000126                    PPT_METHODTRACE_V2("", "strSpcChart.length()", nChart);
//P7000126
//P7000126                    for ( k=0; k < nChart; k++ )
//P7000126                    {
//P7000126                        CORBA::Long nMailAddress
//P7000126                            = strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses.length();
//P7000126
//P7000126                        PPT_METHODTRACE_V3("", "chartSubOwnerMailAddresses.length()", nMailAddress, k);
//P7000126
//P7000126                        //D4200215 mail_send_count++;
//P7000126
//P7000126                        //D4200215 strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length(mail_send_count);
//P7000126                        //D4200215 strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].chartMailAddress.length(nMailAddress+1);
//P7000126
//P7000126                        //D4200215 strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].chartMailAddress[0]
//P7000126                        //D4200215    = strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartOwnerMailAddress;
//P7000126
//P7000126                        //D4200215 PPT_METHODTRACE_V2("", "chartOwnerMailAddress", strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartOwnerMailAddress);
//P7000126
//P7000126                        //D4200215 for ( l=0; l < nMailAddress; l++ )
//P7000126                        //D4200215 {
//P7000126                        //D4200215    strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].chartMailAddress[l+1]
//P7000126                        //D4200215        = strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses[l];
//P7000126                        //D4200215
//P7000126                        //D4200215    PPT_METHODTRACE_V3("", "chartSubOwnerMailAddresses[]", strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses[l], l);
//P7000126                        //D4200215 }
//P7000126
//P7000126                        //D4200215 CORBA::Long nChartMailAddress
//P7000126                        //D4200215    = strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].chartMailAddress.length();
//P7000126
//P7000126                        //D4200215 for ( m=0; m < nChartMailAddress; m++ )
//P7000126                        //D4200215 {
//P7000126                        //D4200215    PPT_METHODTRACE_V3("", "chartMailAddress[]", m, strStartLot_actionList_EffectSPCCheck_out.strMailSendList[entity_count-1].chartMailAddress[m]);
//P7000126                        //D4200215 }
//P7000126
//P7000126
//P7000126                        memset( tmpMsg, '\0', sizeof(tmpMsg) );
//P7000126                        sprintf( tmpMsg, "SPC Violation Notice <%s> \n\n"         //comment string 'const' add for skip grep
//P7000126                                         "Violation Timestamp               : %s \n"
//P7000126                                         "SPC Result                        : %s \n"
//P7000126                                         "Action Taken                      : %s \n"
//P7000126                                         "Lot ID                            : %s \n"
//P7000126                                         "Product ID                        : %s \n"
//P7000126                                         "Route ID                          : %s \n"
//P7000126                                         "Operation Number                  : %s \n"
//P7000126                                         "Process Equipment ID              : %s \n"
//P7000126                                         "Process Chamber ID                : %s \n"
//P7000126                                         "Process Recipe ID                 : %s \n"
//P7000126                                         "Chart Group ID                    : %s \n"
//P7000126                                         "Chart Type                        : %s \n"
//P7000126                                         "Chart ID                          : %s \n"
//P7000126                                         "Item Name                         : %s ",
//P7000126                                 (const char *)(strSpcCheckLot[i].lotID.identifier                 ),
//P7000126                                 (const char *)(strObjCommonIn.strTimeStamp.reportTimeStamp        ),
//P7000126                                 (const char *)(strSpcCheckLot[i].spcCheckResult                   ),
//P7000126                                 //D4200215 CIMFWStrDup( SP_ActionCode_MailSend ),
//P7000126                                 SP_ActionCode_MailSend,                                                                   //D4200215
//P7000126                                 (const char *)(strSpcCheckLot[i].lotID.identifier                 ),
//P7000126                                 (const char *)(strSpcCheckLot[i].productID.identifier             ),
//P7000126                                 (const char *)(strSpcCheckLot[i].processRouteID.identifier        ),
//P7000126                                 (const char *)(strSpcCheckLot[i].processOperationNumber           ),
//P7000126                                 (const char *)(strSpcCheckLot[i].processEquipmentID.identifier    ),
//P7000126                                 (const char *)(strSpcCheckLot[i].processChamberID.identifier      ),                      //D5100227
//P7000126                                 (const char *)(strSpcCheckLot[i].processMachineRecipeID.identifier),
//P7000126                                 (const char *)(strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartGroupID),
//P7000126                                 (const char *)(strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartType),    //D4200215
//P7000126                                 (const char *)(strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartID),
//P7000126                                 (const char *)(strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].dataCollectionItemName) );
//P7000126
//P7000126                        //D4200215 strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageText
//P7000126                        //D4200215    = CIMFWStrDup( tmpMsg );
//P7000126
//P7000126                        //D4200215 PPT_METHODTRACE_V2("", "messageText", strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageText);
//P7000126//P5000282 //D4200215 add start
//P7000126//P5000282              for ( l=0; l < nMailAddress + 1 ; l++ )
//P7000126//P5000282              {
//P7000126//P5000282                  PPT_METHODTRACE_V3("", "chartSubOwnerMailAddresses[] [", strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses[l-1] , "]" );
//P7000126//P5000282                  if( l == 0 || CIMFWStrLen( strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses[l-1] ) > 0 )         //P5000150
//P7000126//P5000282                  {                                                                                                                                        //P5000150
//P7000126//P5000282                      mail_send_count++;
//P7000126//P5000282
//P7000126//P5000282                      PPT_METHODTRACE_V2("", "strMailSendList.length()", mail_send_count);
//P7000126//P5000282
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length(mail_send_count);
//P7000126//P5000282
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageAttributes.messageID.identifier  = CIMFWStrDup( SP_MessageID_SPCChartOver );
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageAttributes.lotID                 = strSpcCheckLot[i].lotID ;
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageAttributes.lotStatus             = CIMFWStrDup("");
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageAttributes.equipmentID           = strSpcCheckLot[i].processEquipmentID ;
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageAttributes.routeID               = strSpcCheckLot[i].processRouteID ;
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageAttributes.operationNumber       = strSpcCheckLot[i].processOperationNumber ;
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageAttributes.reasonCode            = CIMFWStrDup("");
//P7000126//P5000282                      strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].messageAttributes.messageText           = CIMFWStrDup( tmpMsg );
//P7000126//P5000282
//P7000126//P5000282                      if ( l == 0 )
//P7000126//P5000282                      {
//P7000126//P5000282                          strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].chartMailAdderess
//P7000126//P5000282                              = strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartOwnerMailAddress;
//P7000126//P5000282                      }
//P7000126//P5000282                      else
//P7000126//P5000282                      {
//P7000126//P5000282                          strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].chartMailAdderess
//P7000126//P5000282                              = strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses[l-1];
//P7000126//P5000282                      }
//P7000126//P5000282                  }                                                                                                                                        //P5000150
//P7000126//P5000282              }
//P7000126//P5000282 //D4200215 add end
//P7000126
//P7000126                        //P5000282 add start                                                                                                                                                //P5000282
//P7000126                        //--------------------------------------------------------------------------                                                                                        //P5000282
//P7000126                        // for Chart Owner                                                                                                                                                  //P5000282
//P7000126                        //--------------------------------------------------------------------------                                                                                        //P5000282
//P7000126                        if( CIMFWStrLen( strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartOwnerMailAddress ) > 0 )                                                        //P5000282
//P7000126                        {                                                                                                                                                                   //P5000282
//P7000126                            mail_send_count++;                                                                                                                                              //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length( mail_send_count );                                                                            //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[ mail_send_count-1 ].chartMailAdderess                                                                //P5000282
//P7000126                                = strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartOwnerMailAddress;                                                                      //P5000282
//P7000126                            PPT_METHODTRACE_V2("", "chartOwnerMailAddress", strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartOwnerMailAddress );                          //P5000282
//P7000126                        }                                                                                                                                                                   //P5000282
//P7000126                                                                                                                                                                                            //P5000282
//P7000126                        //--------------------------------------------------------------------------                                                                                        //P5000282
//P7000126                        // for Sub Chart Owner                                                                                                                                              //P5000282
//P7000126                        //--------------------------------------------------------------------------                                                                                        //P5000282
//P7000126                        for ( int subOwnerCnt = 0; subOwnerCnt < nMailAddress ; subOwnerCnt++ )                                                                                             //P5000282
//P7000126                        {                                                                                                                                                                   //P5000282
//P7000126                            if( CIMFWStrLen( strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses[subOwnerCnt] ) > 0 )                                  //P5000282
//P7000126                            {                                                                                                                                                               //P5000282
//P7000126                                mail_send_count++;                                                                                                                                          //P5000282
//P7000126                                strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length( mail_send_count );                                                                        //P5000282
//P7000126                                strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count-1].chartMailAdderess                                                              //P5000282
//P7000126                                    = strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses[subOwnerCnt];                                                //P5000282
//P7000126                                PPT_METHODTRACE_V2("", "chartSubOwnerMailAddress", strSpcCheckLot[i].strSpcResult.strSpcDcItem[j].strSpcChart[k].chartSubOwnerMailAddresses[subOwnerCnt] ); //P5000282
//P7000126                            }                                                                                                                                                               //P5000282
//P7000126                        }                                                                                                                                                                   //P5000282
//P7000126                                                                                                                                                                                            //P5000282
//P7000126                        //--------------------------------------------------------------------------                                                                                        //P5000282
//P7000126                        // Common message information for Chart Owner and Sub Chart Owners                                                                                                  //P5000282
//P7000126                        //--------------------------------------------------------------------------                                                                                        //P5000282
//P7000126                        PPT_METHODTRACE_V2("", "mail_send_count", mail_send_count );                                                                                                        //P5000282
//P7000126                        for ( int msgCnt = 0 ; msgCnt < mail_send_count ; msgCnt++ )                                                                                                        //P5000282
//P7000126                        {                                                                                                                                                                   //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[msgCnt].messageAttributes.messageID.identifier  = CIMFWStrDup( SP_MessageID_SPCChartOver );           //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[msgCnt].messageAttributes.lotID                 = strSpcCheckLot[i].lotID ;                           //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[msgCnt].messageAttributes.lotStatus             = CIMFWStrDup("");                                    //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[msgCnt].messageAttributes.equipmentID           = strSpcCheckLot[i].processEquipmentID ;              //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[msgCnt].messageAttributes.routeID               = strSpcCheckLot[i].processRouteID ;                  //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[msgCnt].messageAttributes.operationNumber       = strSpcCheckLot[i].processOperationNumber ;          //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[msgCnt].messageAttributes.reasonCode            = CIMFWStrDup("");                                    //P5000282
//P7000126                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[msgCnt].messageAttributes.messageText           = CIMFWStrDup( tmpMsg );                              //P5000282
//P7000126                        }                                                                                                                                                                   //P5000282
//P7000126                        //P5000282 add end                                                                                                                                                  //P5000282
//P7000126
//P7000126                    }
//P7000126                }
//P7000126            }

//D4200115 add end

            CORBA::Long lenEffectedLots = effectedLots.length();
            PPT_METHODTRACE_V2("", "effectedLots.length--->", lenEffectedLots);

            /*------------------------*/            //Q3000284
            /*   For Monitored Lots   */            //Q3000284
            /*------------------------*/            //Q3000284
            entity_count_keep = entity_count;                          //DSIV00001365
            entity_countForOtherFab_keep = entity_countForOtherFab;    //DSIV00001365
//Q3000284  for ( m=0; m < lenEffectedLots; m++ )
            for ( m = 1; m < lenEffectedLots; m++ )   //Q3000284
            {

//DSIV00000214 add start
                if ( requestOtherFabFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is current Fab");
//DSIV00000214 add end
//DSIV00000214 add start
                    if( requestOtherFabFlagForMonitor == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "Monitored Lots are in another Fab");
                        break;
                    }
//DSIV00000214 add end
                    //==============================
                    //===   P3000383 add start   ===
                    //==============================
                    PosLot_var aLot;
                    PPT_CONVERT_LOTID_TO_LOT_OR( aLot, effectedLots[m].lotID, strStartLot_actionList_EffectSPCCheck_out, startLot_actionList_EffectSpecCheck__101 );

                    PosProcessOperation_var aPOtmp;
                    PPT_CONVERT_STRING_TO_OBJECT( effectedLots[m].processOperation ,aPOtmp, PosProcessOperation );
                    if ( CORBA::is_nil( aPOtmp ) )
                    {
//P5000145                    SET_MSG_RC( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
                        PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PO,     //P5000145
                                             RC_NOT_FOUND_PO, effectedLots[m].processOperation,               //P5000145
                                             effectedLots[m].lotID.identifier );                              //P5000145

                        return RC_NOT_FOUND_PO;
                    }

                    PosMachine_var aMachine;
                    try
                    {
                        aMachine  = aPOtmp->getAssignedMachine();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachine)

                    PosMachineRecipe_var aRecipe;
                    try
                    {
                        aRecipe = aPOtmp->getAssignedMachineRecipe();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachineRecipe)

                    PosProcessDefinition_var aMainPD;
                    try
                    {
                        aMainPD = aPOtmp->getMainProcessDefinition();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

                    CORBA::String_var operationNo;
                    try
                    {
                        operationNo = aPOtmp->getOperationNumber();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber)
                    //==============================
                    //===   P3000383 add end     ===
                    //==============================

                    if ( equipment_hold_flag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "equipment_hold_flag == TRUE");

//P3000383 delete start
//                    PosProcessOperation_var aPOtmp;
//                    PPT_CONVERT_STRING_TO_OBJECT( effectedLots[m].processOperation ,aPOtmp, PosProcessOperation );
////Q3000124 start
//                    if ( CORBA::is_nil( aPOtmp ) )
//                    {
//                        SET_MSG_RC( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
//                        return RC_NOT_FOUND_PO;
//                    }
////Q3000124 end
//
//                    PosMachine_var aMachine;
//                    try
//                    {
//                        aMachine  = aPOtmp->getAssignedMachine();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachine)
//P3000383 delete end

                        if ( ! CORBA::is_nil(aMachine) )
                        {
                            PPT_METHODTRACE_V1("", "aMachine is not nil");

                            CORBA::String_var machineID;
                            try
                            {
                                machineID = aMachine->getIdentifier();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getIdentifier)

                            findFlag = FALSE;
                            //-------------------------------------------------------------------
                            //  Check equipment_hold_inhibition is already registed or not.
                            //  If only not existed, entry new inhibition.
                            //-------------------------------------------------------------------
                            PPT_METHODTRACE_V1("", "Check equipment_hold_inhibition is already registed or not");

                            for ( n = 0; n < entity_count; n++ )
                            {
                                if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment)
                                  && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, machineID) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]", machineID);

                                entity_count++;
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID,
                                                           aMachine,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           Machine );
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib = CIMFWStrDup("");
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup("TIMESTAMP_NIL_OBJECT_STRING");
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( TIMESTAMP_NIL_OBJECT_STRING );      //Q3000284
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );   //Q3000284
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );     //Q3000284
//P4100051                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier = CIMFWStrDup("PPTSvcMgr");
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;    //P4100051
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            }
//DSIV00001021 add start
                            findFlag = FALSE;
                            for ( n = 0; n < dcActionInfo_count; n++ )
                            {
                                if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                {
                                    if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, machineID)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[m].processOperation)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                    {
                                        PPT_METHODTRACE_V1("", "break!!");
                                        findFlag = TRUE;
                                        break;
                                    }
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]", machineID);

                                //-----------------------------------------------------------------------------
                                // Add ActionResultInfo
                                //-----------------------------------------------------------------------------
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_EquipmentHold );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                PPT_SET_OBJECT_IDENTIFIER( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID,
                                                           aMachine,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           Machine );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                                dcActionInfo_count++;
                            }
//DSIV00001021 add end
                        }
                    }

                    if ( recipe_hold_flag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "recipe_hold_flag == TRUE");

//P3000383 delete start
//                    PosProcessOperation_var aPOtmp;
//                    PPT_CONVERT_STRING_TO_OBJECT( effectedLots[m].processOperation ,aPOtmp, PosProcessOperation );
////Q3000124 start
//                    if ( CORBA::is_nil( aPOtmp ) )
//                    {
//                        SET_MSG_RC( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
//                        return RC_NOT_FOUND_PO;
//                    }
////Q3000124 end
//
//                    PosMachineRecipe_var aRecipe;
//                    try
//                    {
//                        aRecipe = aPOtmp->getAssignedMachineRecipe();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachineRecipe)
//P3000383 delete end

                        if ( !CORBA::is_nil( aRecipe ) )
                        {
                            PPT_METHODTRACE_V1("", "aRecipe is not nil");

                            CORBA::String_var recipeID;
                            try
                            {
                                recipeID = aRecipe->getIdentifier();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getIdentifier)

                            findFlag = FALSE;
                            //-------------------------------------------------------------------
                            //  Check recipe_hold_inhibition is already registed or not.
                            //  If only not existed, entry new inhibition.
                            //-------------------------------------------------------------------
                            for ( n = 0; n < entity_count; n++ )
                            {
                                if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
                                  && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, recipeID) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");

                                    findFlag = TRUE;
                                    break;
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "findFlag == FALSE [recipeID]", recipeID);

                                entity_count++;
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID,
                                                           aRecipe,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           MachineRecipe );
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib = CIMFWStrDup("");
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup("TIMESTAMP_NIL_OBJECT_STRING");
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( TIMESTAMP_NIL_OBJECT_STRING );      //Q3000284
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );   //Q3000284
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );     //Q3000284
//P4100051                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier = CIMFWStrDup("PPTSvcMgr");
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;    //P4100051
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            }
//DSIV00001021 add start
                            findFlag = FALSE;
                            for ( n = 0; n < dcActionInfo_count; n++ )
                            {
                                if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                {
                                    if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, recipeID)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[m].processOperation)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                    {
                                        PPT_METHODTRACE_V1("", "break!!");
                                        findFlag = TRUE;
                                        break;
                                    }
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "findFlag == FALSE [recipeID]", recipeID);

                                //-----------------------------------------------------------------------------
                                // Add ActionResultInfo
                                //-----------------------------------------------------------------------------
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RecipeHold );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                PPT_SET_OBJECT_IDENTIFIER( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID,
                                                           aRecipe,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           MachineRecipe );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                                dcActionInfo_count++;
                            }
//DSIV00001021 add end
                        }
                    }

                    if ( route_hold_flag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "route_hold_flag == TRUE");

//P3000383 delete start
//                    PosProcessOperation_var aPOtmp;
//                    PPT_CONVERT_STRING_TO_OBJECT( effectedLots[m].processOperation ,aPOtmp, PosProcessOperation );
//Q3000124 start
//                    if ( CORBA::is_nil( aPOtmp ) )
//                    {
//                        SET_MSG_RC( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
//                        return RC_NOT_FOUND_PO;
//                    }
////Q3000124 end
//
//                    PosProcessDefinition_var aMainPD;
//                    try
//                    {
//                        aMainPD = aPOtmp->getMainProcessDefinition();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)
//P3000383 delete end

                        if ( !CORBA::is_nil( aMainPD ) )
                        {
                            PPT_METHODTRACE_V1("", "aMainPD is not nil");

                            CORBA::String_var mainPDID;
                            try
                            {
                                mainPDID = aMainPD->getIdentifier();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(ProcessDefinition::getIdentifier)

                            findFlag = FALSE;
                            //-------------------------------------------------------------------
                            //  Check route_hold_inhibition is already registed or not.
                            //  If only not existed, entry new inhibition.
                            //-------------------------------------------------------------------
                            for ( n = 0; n < entity_count; n++ )
                            {
                                if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Route )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, mainPDID )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].attrib, "" ) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");

                                    findFlag = TRUE;
                                    break;
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]", mainPDID);

                                entity_count++;
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                                PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID,
                                                           aMainPD,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           ProcessDefinition );
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib = CIMFWStrDup("");
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup("TIMESTAMP_NIL_OBJECT_STRING");
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( TIMESTAMP_NIL_OBJECT_STRING );      //Q3000284
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );   //Q3000284
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );     //Q3000284
//P4100051                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier = CIMFWStrDup("PPTSvcMgr");
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;    //P4100051
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            }
//DSIV00001021 add start
                            findFlag = FALSE;
                            for ( n = 0; n < dcActionInfo_count; n++ )
                            {
                                if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                {
                                    if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Route)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, mainPDID)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, "")
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[m].processOperation)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                    {
                                        PPT_METHODTRACE_V1("", "break!!");
                                        findFlag = TRUE;
                                        break;
                                    }
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]", mainPDID);

                                //-----------------------------------------------------------------------------
                                // Add ActionResultInfo
                                //-----------------------------------------------------------------------------
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RouteHold );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                                PPT_SET_OBJECT_IDENTIFIER( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID,
                                                           aMainPD,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           ProcessDefinition );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                                dcActionInfo_count++;
                            }
//DSIV00001021 add end
                        }
                    }

                    if ( process_hold_flag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "process_hold_flag == TRUE");

//P3000383 delete start
//                    PosProcessOperation_var aPOtmp;
//
//                    PPT_CONVERT_STRING_TO_OBJECT( effectedLots[m].processOperation ,aPOtmp, PosProcessOperation );
////Q3000124 start
//                    if ( CORBA::is_nil( aPOtmp ) )
//                    {
//                        SET_MSG_RC( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
//                        return RC_NOT_FOUND_PO;
//                    }
////Q3000124 end
//
//                    PosProcessDefinition_var aMainPD;
//                    try
//                    {
//                        aMainPD = aPOtmp->getMainProcessDefinition();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)
//
//                    CORBA::String_var operationNo;
//                    try
//                    {
//                        operationNo = aPOtmp->getOperationNumber();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber)
//P3000383 delete end

                        if ( !CORBA::is_nil( aMainPD ) )
                        {
                            PPT_METHODTRACE_V1("", "aMainPD is not nil");

                            CORBA::String_var mainPDID;
                            try
                            {
                                mainPDID = aMainPD->getIdentifier();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(ProcessDefinition::getIdentifier)

                            CORBA::Boolean findFlag = FALSE;
                            //-------------------------------------------------------------------
                            //  Check process_hold_inhibition is already registed or not.
                            //  If only not existed, entry new inhibition.
                            //-------------------------------------------------------------------
                            for ( n = 0; n < entity_count; n++ )
                            {
                                if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Operation )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, mainPDID )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].attrib, operationNo ) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");

                                    findFlag = TRUE;
                                    break;
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]", mainPDID);

                                entity_count++;
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                                PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID,
                                                           aMainPD,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           ProcessDefinition );
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib = CIMFWStrDup(operationNo);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup("TIMESTAMP_NIL_OBJECT_STRING");
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( TIMESTAMP_NIL_OBJECT_STRING );      //Q3000284
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );   //Q3000284
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );     //Q3000284
//P4100051                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier = CIMFWStrDup("PPTSvcMgr");
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;    //P4100051
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            }
//DSIV00001021 add start
                            findFlag = FALSE;
                            for ( n = 0; n < dcActionInfo_count; n++ )
                            {
                                if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                {
                                    if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Operation)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, mainPDID)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, operationNo )
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[m].processOperation)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                    {
                                        PPT_METHODTRACE_V1("", "break!!");
                                        findFlag = TRUE;
                                        break;
                                    }
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]", mainPDID);

                                //-----------------------------------------------------------------------------
                                // Add ActionResultInfo
                                //-----------------------------------------------------------------------------
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ProcessHold );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                                PPT_SET_OBJECT_IDENTIFIER( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID,
                                                           aMainPD,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           ProcessDefinition );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup(operationNo);

                                dcActionInfo_count++;
                            }
//DSIV00001021 add end
                        }
                    }

//D5000147 start --------------------------------------------------------------------------------------------------------------------------------------------------//D5000147
                    //----------------------------------------------------------------------------                                                                                     //D5000147
                    // Inhibit Equipment and Recipe                                                                                                                                    //D5000147
                    //----------------------------------------------------------------------------                                                                                     //D5000147
                    if ( equipment_and_recipe_hold_flag == TRUE )                                                                                                                      //D5000147
                    {                                                                                                                                                                  //D5000147
                        PPT_METHODTRACE_V1("", "equipment_and_recipe_hold_flag == TRUE");                                                                                              //D5000147
                                                                                                                                                                                       //D5000147
                        if ( ! CORBA::is_nil(aMachine) && ! CORBA::is_nil(aRecipe) )                                                                                                   //D5000147
                        {                                                                                                                                                              //D5000147
                            PPT_METHODTRACE_V1("", "aMachine and aRecipe is not nil");                                                                                                 //D5000147
                                                                                                                                                                                       //D5000147
                            objectIdentifier processEquipmentID;                                                                                                                       //D5000147
                            objectIdentifier processMachineRecipeID;                                                                                                                   //D5000147
                                                                                                                                                                                       //D5000147
                            PPT_SET_OBJECT_IDENTIFIER( processEquipmentID,                                                                                                             //D5000147
                                                       aMachine,                                                                                                                       //D5000147
                                                       strStartLot_actionList_EffectSPCCheck_out,                                                                                      //D5000147
                                                       startLot_actionList_EffectSPCCheck,                                                                                             //D5000147
                                                       Machine );                                                                                                                      //D5000147
                                                                                                                                                                                       //D5000147
                            PPT_SET_OBJECT_IDENTIFIER( processMachineRecipeID,                                                                                                         //D5000147
                                                       aRecipe,                                                                                                                        //D5000147
                                                       strStartLot_actionList_EffectSPCCheck_out,                                                                                      //D5000147
                                                       startLot_actionList_EffectSPCCheck,                                                                                             //D5000147
                                                       MachineRecipe );                                                                                                                //D5000147
                                                                                                                                                                                       //D5000147
                            findFlag = FALSE;                                                                                                                                          //D5000147
                            //-------------------------------------------------------------------                                                                                      //D5000147
                            //  Check equipment_and_recipe_hold_inhibition is already registed or not.                                                                                 //D5000147
                            //  If only not existed, entry new inhibition.                                                                                                             //D5000147
                            //-------------------------------------------------------------------                                                                                      //D5000147
                            for ( n=0; n < entity_count; n++ )                                                                                                                         //D5000147
                            {                                                                                                                                                          //D5000147
                                if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )                                                         //D5000147
                                {                                                                                                                                                      //D5000147
                                    if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment )                //D5000147
                                      && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, processEquipmentID.identifier )    //D5000147
                                      && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_MachineRecipe )            //D5000147
                                      && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, processMachineRecipeID.identifier))//D5000147
                                    {                                                                                                                                                  //D5000147
                                        PPT_METHODTRACE_V1("", "set findFlag = TRUE");                                                                                                 //D5000147
                                        findFlag = TRUE;                                                                                                                               //D5000147
                                        break;                                                                                                                                         //D5000147
                                    }                                                                                                                                                  //D5000147
                                }                                                                                                                                                      //D5000147
                            }                                                                                                                                                          //D5000147
                                                                                                                                                                                       //D5000147
                            if ( findFlag == FALSE )                                                                                                                                   //D5000147
                            {                                                                                                                                                          //D5000147
                                PPT_METHODTRACE_V1("", "findFlag == FALSE");                                                                                                           //D5000147
                                                                                                                                                                                       //D5000147
                                entity_count++;                                                                                                                                        //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);                                                                   //D5000147
                                                                                                                                                                                       //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);                                                     //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);       //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = processEquipmentID;                             //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");                                //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);   //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = processMachineRecipeID;                         //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");                                //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);                                                  //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;    //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);    //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);    //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;                  //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;    //D5000147
                            }                                                                                                                                                          //D5000147
//DSIV00001021 add start
                            findFlag = FALSE;                                                                                                                                          //D5000147
                            for ( n=0; n < dcActionInfo_count; n++ )
                            {
                                if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                                {
                                    if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, processEquipmentID.identifier)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, processMachineRecipeID.identifier)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[m].processOperation)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                    {                                                                                                                                                  //D5000147
                                        PPT_METHODTRACE_V1("", "set findFlag = TRUE");                                                                                                 //D5000147
                                        findFlag = TRUE;                                                                                                                               //D5000147
                                        break;                                                                                                                                         //D5000147
                                    }                                                                                                                                                  //D5000147
                                }                                                                                                                                                      //D5000147
                            }                                                                                                                                                          //D5000147
                                                                                                                                                                                       //D5000147
                            if ( findFlag == FALSE )                                                                                                                                   //D5000147
                            {                                                                                                                                                          //D5000147
                                PPT_METHODTRACE_V1("", "findFlag == FALSE");                                                                                                           //D5000147

                                //-----------------------------------------------------------------------------
                                // Add ActionResultInfo
                                //-----------------------------------------------------------------------------
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Equipment_and_RecipeHold );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = processEquipmentID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = processMachineRecipeID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                                dcActionInfo_count++;
                            }
//DSIV00001021 add end
                        }                                                                                                                                                              //D5000147
                    }                                                                                                                                                                  //D5000147
                                                                                                                                                                                       //D5000147
                    //----------------------------------------------------------------------------                                                                                     //D5000147
                    // Inhibit Process Definition and Equipment                                                                                                                        //D5000147
                    //----------------------------------------------------------------------------                                                                                     //D5000147
                    if ( process_and_equipment_hold_flag == TRUE )                                                                                                                     //D5000147
                    {                                                                                                                                                                  //D5000147
                        PPT_METHODTRACE_V1("", "process_and_equipment_hold_flag == TRUE");                                                                                             //D5000147
                                                                                                                                                                                       //D5000147
                        if ( ! CORBA::is_nil(aMachine)  )                                                                                                                              //D5000147
                        {                                                                                                                                                              //D5000147
                            PPT_METHODTRACE_V1("", "aMachine and aRecipe is not nil");                                                                                                 //D5000147
                                                                                                                                                                                       //D5000147
                            objectIdentifier processEquipmentID;                                                                                                                       //D5000147
                                                                                                                                                                                       //D5000147
                            PPT_SET_OBJECT_IDENTIFIER( processEquipmentID,                                                                                                             //D5000147
                                                       aMachine,                                                                                                                       //D5000147
                                                       strStartLot_actionList_EffectSPCCheck_out,                                                                                      //D5000147
                                                       startLot_actionList_EffectSPCCheck,                                                                                             //D5000147
                                                       Machine );                                                                                                                      //D5000147
                                                                                                                                                                                       //D5000147
                            objectIdentifier processPDID;                                                                                                                              //D5000147
                                                                                                                                                                                       //D5000147
                            PosProcessDefinition_var aProcessPD;                                                                                                                       //D5000147
                            try                                                                                                                                                        //D5000147
                            {                                                                                                                                                          //D5000147
                                aProcessPD = aPOtmp->getProcessDefinition();                                                                                                           //D5000147
                            }                                                                                                                                                          //D5000147
                            CATCH_AND_RAISE_EXCEPTIONS( PosProcessOperation::getProcessDefinition );                                                                                   //D5000147
                                                                                                                                                                                       //D5000147
                            if( CORBA::is_nil( aProcessPD ) == TRUE )                                                                                                                  //D5000147
                            {                                                                                                                                                          //D5000147
                                PPT_METHODTRACE_V1("PPTManager_i::startLot_actionList_EffectSPCCheck", "CORBA::is_nil(aPFX)")                                                          //D5000147
                                PPT_SET_MSG_RC_KEY(strStartLot_actionList_EffectSPCCheck_out,                                                                                          //D5000147
                                                   MSG_NOT_FOUND_PFX, RC_NOT_FOUND_PFX,                                                                                                //D5000147
                                                   "");                                                                                                                                //D5000147
                                return( RC_NOT_FOUND_PD );                                                                                                                             //D5000147
                            }                                                                                                                                                          //D5000147
                                                                                                                                                                                       //D5000147
                            PPT_SET_OBJECT_IDENTIFIER( processPDID,                                                                                                                    //D5000147
                                                       aProcessPD,                                                                                                                     //D5000147
                                                       strStartLot_actionList_EffectSPCCheck_out,                                                                                      //D5000147
                                                       strStartLot_actionList_EffectSPCCheck,                                                                                          //D5000147
                                                       PosProcessDefinition );                                                                                                         //D5000147
                                                                                                                                                                                       //D5000147
                            PPT_METHODTRACE_V1("", processPDID.identifier );                                                                                                           //D5000147
                                                                                                                                                                                       //D5000147
                            findFlag = FALSE;                                                                                                                                          //D5000147
                            //-------------------------------------------------------------------                                                                                      //D5000147
                            //  Check process_and_equipment_hold_inhibition is already registed or not.                                                                                //D5000147
                            //  If only not existed, entry new inhibition.                                                                                                             //D5000147
                            //-------------------------------------------------------------------                                                                                      //D5000147
                            for ( n=0; n < entity_count; n++ )                                                                                                                         //D5000147
                            {                                                                                                                                                          //D5000147
                                if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )                                                         //D5000147
                                {                                                                                                                                                      //D5000147
                                    if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Operation )      //D5000147
                                      && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, processPDID.identifier ) //D5000147
                                      && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className, SP_InhibitClassID_Equipment )      //D5000147
                                      && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier, processEquipmentID.identifier ) )  //D5000147
                                    {                                                                                                                                                  //D5000147
                                        PPT_METHODTRACE_V1("", "set findFlag = TRUE");                                                                                                 //D5000147
                                        findFlag = TRUE;                                                                                                                               //D5000147
                                        break;                                                                                                                                         //D5000147
                                    }                                                                                                                                                  //D5000147
                                }                                                                                                                                                      //D5000147
                            }                                                                                                                                                          //D5000147
                                                                                                                                                                                       //D5000147
                            if ( findFlag == FALSE )                                                                                                                                   //D5000147
                            {                                                                                                                                                          //D5000147
                                PPT_METHODTRACE_V1("", "findFlag == FALSE");                                                                                                           //D5000147
                                                                                                                                                                                       //D5000147
                                entity_count++;                                                                                                                                        //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);                                                                   //D5000147
                                                                                                                                                                                       //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);                                                     //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);         //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = processPDID;                                    //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = CIMFWStrDup("");                                //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);       //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = processEquipmentID;                             //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");                                //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);                                                  //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;    //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);    //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);    //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID               = strObjCommonIn.strUser.userID;                  //D5000147
                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;    //D5000147
                            }                                                                                                                                                          //D5000147
//DSIV00001021 add start
                            findFlag = FALSE;                                                                                                                                          //D5000147
                            for ( n = 0; n < dcActionInfo_count; n++ )
                            {
                                if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                                {
                                    if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Process)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, processPDID.identifier)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_Equipment )
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, processEquipmentID.identifier)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[m].processOperation)
                                      && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                    {
                                        PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                        findFlag = TRUE;
                                        break;
                                    }
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V1("", "findFlag == FALSE");

                                //-----------------------------------------------------------------------------
                                // Add ActionResultInfo
                                //-----------------------------------------------------------------------------
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Process_and_EquipmentHold );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = processPDID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = processEquipmentID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                                dcActionInfo_count++;
                            }
//DSIV00001021 add end
                        }                                                                                                                                                              //D5000147
                    }                                                                                                                                                                  //D5000147
//D5000147 end ----------------------------------------------------------------------------------------------------------------------------------------------------//D5000147

//D5100227 Add Start
                    //-------------------------------
                    // Chamber Inhibition
                    //-------------------------------
                    if ( chamber_hold_flag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "chamber_hold_flag == TRUE");

                        objectIdentifier processEquipmentID;

                        PPT_SET_OBJECT_IDENTIFIER( processEquipmentID,
                                                   aMachine,
                                                   strStartLot_actionList_EffectSPCCheck_out,
                                                   startLot_actionList_EffectSPCCheck,
                                                   Machine );

                        PosProcessResourceInfoGroupByProcessResourceSequence*    aPosProcResrcInfoByResrcs = NULL;
                        PosProcessResourceInfoGroupByProcessResourceSequence_var aPosProcResrcInfoByResrcs_var;
                        try
                        {
                            aPosProcResrcInfoByResrcs     = aPOtmp->allAssignedProcessResourceInfoGroupByProcessResource();
                            aPosProcResrcInfoByResrcs_var = aPosProcResrcInfoByResrcs;
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::allAssignedProcessResourceInfoGroupByProcessResource);

                        CORBA::Long   chamberLen = aPosProcResrcInfoByResrcs->length();
                        CORBA::Long   kk = 0;

                        for ( kk = 0; kk < chamberLen; kk++ )
                        {
                            if ( CIMFWStrLen( (*aPosProcResrcInfoByResrcs)[kk].processResourceID.identifier ) > 0 )
                            {
                                CORBA::String_var strProcessChamberID = CIMFWStrDup( (*aPosProcResrcInfoByResrcs)[kk].processResourceID.identifier );

                                PPT_METHODTRACE_V2("", "strProcessChamberID is not Blank", strProcessChamberID );

                                findFlag = FALSE;
                                //-------------------------------------------------------------------
                                //  Check chamber_hold_inhibition is already registed or not.
                                //  If only not existed, entry new inhibition.
                                //-------------------------------------------------------------------
                                for ( n = 0; n < entity_count; n++ )
                                {
                                    if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className,
                                                           SP_InhibitClassID_Chamber     ) &&
                                         0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier,
                                                           processEquipmentID.identifier ) &&
                                         0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].attrib,
                                                           strProcessChamberID ))
                                    {
                                        PPT_METHODTRACE_V1("", "break!!");

                                        findFlag = TRUE;
                                        break;
                                    }
                                }
                                if ( findFlag == FALSE )
                                {
                                    PPT_METHODTRACE_V2("", "findFlag == FALSE [Chamber]", strProcessChamberID);

                                    entity_count++;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = processEquipmentID;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = strProcessChamberID;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID    = strObjCommonIn.strUser.userID;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                }
//DSIV00001021 add start
                                findFlag = FALSE;
                                for ( n = 0; n < dcActionInfo_count; n++ )
                                {
                                    if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                    {
                                        if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Chamber)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, processEquipmentID.identifier)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strProcessChamberID )
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[m].processOperation)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                        {
                                            PPT_METHODTRACE_V1("", "break!!");
                                            findFlag = TRUE;
                                            break;
                                        }
                                    }
                                }
                                if ( findFlag == FALSE )
                                {
                                    PPT_METHODTRACE_V2("", "findFlag == FALSE [Chamber]", strProcessChamberID);

                                    //-----------------------------------------------------------------------------
                                    // Add ActionResultInfo
                                    //-----------------------------------------------------------------------------
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ChamberHold );
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = processEquipmentID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = strProcessChamberID;

                                    dcActionInfo_count++;
                                }
//DSIV00001021 add end
                            }
                        }
                    }

                    //-------------------------------
                    // Chamber and Recipe Inhibition
                    //-------------------------------
                    if ( chamber_recipe_hold_flag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "chamber_recipe_hold_flag == TRUE");

                        objectIdentifier processEquipmentID;
                        objectIdentifier processMachineRecipeID;

                        PPT_SET_OBJECT_IDENTIFIER( processEquipmentID,
                                                   aMachine,
                                                   strStartLot_actionList_EffectSPCCheck_out,
                                                   startLot_actionList_EffectSPCCheck,
                                                   Machine );

                        PPT_SET_OBJECT_IDENTIFIER( processMachineRecipeID,
                                                   aRecipe,
                                                   strStartLot_actionList_EffectSPCCheck_out,
                                                   startLot_actionList_EffectSPCCheck,
                                                   MachineRecipe );

                        PosProcessResourceInfoGroupByProcessResourceSequence*    aPosProcResrcInfoByResrcs = NULL;
                        PosProcessResourceInfoGroupByProcessResourceSequence_var aPosProcResrcInfoByResrcs_var;
                        try
                        {
                            aPosProcResrcInfoByResrcs     = aPOtmp->allAssignedProcessResourceInfoGroupByProcessResource();
                            aPosProcResrcInfoByResrcs_var = aPosProcResrcInfoByResrcs;
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::allAssignedProcessResourceInfoGroupByProcessResource);

                        CORBA::Long   chamberLen = aPosProcResrcInfoByResrcs->length();
                        CORBA::Long   kk = 0;

                        for ( kk = 0; kk < chamberLen; kk++ )
                        {
                            if ( CIMFWStrLen( (*aPosProcResrcInfoByResrcs)[kk].processResourceID.identifier ) > 0 )
                            {
                                CORBA::String_var strProcessChamberID = CIMFWStrDup( (*aPosProcResrcInfoByResrcs)[kk].processResourceID.identifier );

                                PPT_METHODTRACE_V2("", "strProcessChamberID is not Blank", strProcessChamberID );

                                findFlag = FALSE;
                                //-------------------------------------------------------------------
                                //  Check chamber_recipe_hold_inhibition is already registed or not.
                                //  If only not existed, entry new inhibition.
                                //-------------------------------------------------------------------
                                for ( n = 0; n < entity_count; n++ )
                                {
                                    if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities.length() == 2 )
                                    {
                                        if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].className,
                                                               SP_InhibitClassID_Chamber         ) &&
                                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier,
                                                               processEquipmentID.identifier     ) &&
                                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[0].attrib,
                                                               strProcessChamberID               ) &&
                                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].className,
                                                               SP_InhibitClassID_MachineRecipe   ) &&
                                             0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[n].entities[1].objectID.identifier,
                                                               processMachineRecipeID.identifier ))
                                        {
                                            PPT_METHODTRACE_V1("", "break!!");

                                            findFlag = TRUE;
                                            break;
                                        }
                                    }
                                }
                                if ( findFlag == FALSE )
                                {
                                    PPT_METHODTRACE_V2("", "findFlag == FALSE [Chamber and Recipe]", strProcessChamberID);

                                    entity_count++;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length(entity_count);

                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities.length(2);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID  = processEquipmentID;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib    = strProcessChamberID;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].objectID  = processMachineRecipeID;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].entities[1].attrib    = CIMFWStrDup("");
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;
                                    strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                }
//DSIV00001021 add start
                                findFlag = FALSE;
                                for ( n = 0; n < dcActionInfo_count; n++ )
                                {
                                    if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                                    {
                                        if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Chamber)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, processEquipmentID.identifier)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strProcessChamberID )
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier,  processMachineRecipeID.identifier )
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[m].processOperation)
                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                        {
                                            PPT_METHODTRACE_V1("", "break!!");
                                            findFlag = TRUE;
                                            break;
                                        }
                                    }
                                }
                                if ( findFlag == FALSE )
                                {
                                    PPT_METHODTRACE_V2("", "findFlag == FALSE [Chamber and Recipe]", strProcessChamberID);

                                    //-----------------------------------------------------------------------------
                                    // Add ActionResultInfo
                                    //-----------------------------------------------------------------------------
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ChamberAndRecipeHold );
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = processEquipmentID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = strProcessChamberID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = processMachineRecipeID;
                                    strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                                    dcActionInfo_count++;
                                }
//DSIV00001021 add end
                            }
                        }
                    }
//D5100227 Add End

                    //------------------------------------------------------------------------------------------------
                    //  Make strMessageAttributes of out parameter.
                    //
                    //    ( actionCode are filled only when spcCheckResult is SP_ActionCode_Mail. )
                    //------------------------------------------------------------------------------------------------
                    if ( mail_flag == TRUE )
                    {
//P3000383          CORBA::String_var messageText;
                        char tmpMsg[1024];

                        if ( 0 == CIMFWStrCmp(strSpcCheckLot[i].spcCheckResult, SP_SPCCheck_HoldLimitOff)
                          || 0 == CIMFWStrCmp(strSpcCheckLot[i].spcCheckResult, SP_SPCCheck_WarningLimitOff) )
                        {
//P3000383 delete start
//                        sprintf(messageText, "ProductID:                  %s \n"
//                                             "ProcessRouteID:             %s \n"
//                                             "ProcessOperationNumber:     %s \n"
//                                             "ProcessEquipmentID:         %s \n"
//                                             "ProcessMachineRecipeID:     %s \n"
////Q300284                                    "DataCollectionDefinitionID: %s",                   //0.01
//                                             "DataCollectionDefinitionID: ",                     //0.01 //Q3000284
//
////P300219                       strSpcCheckLot[i].productID.identifier,
//                                (const char *)strSpcCheckLot[i].productID.identifier,            //P300219
////P300219                       strSpcCheckLot[i].processRouteID.identifier,
//                                (const char *)strSpcCheckLot[i].processRouteID.identifier,       //P300219
//                                strSpcCheckLot[i].processOperationNumber,
////P300219                       strSpcCheckLot[i].processEquipmentID.identifier,
//                                (const char *)strSpcCheckLot[i].processEquipmentID.identifier,   //P300219
////P300219                       strSpcCheckLot[i].processMachineRecipeID.identifier );
//                                (const char *)strSpcCheckLot[i].processMachineRecipeID.identifier ); //P300219
//
////P3000383              messageText = CIMFWStrDup(tmpMsg);
//P3000383 delete end

                            //==============================
                            //===   P3000383 add start   ===
                            //==============================
                            /*----- get Lot Object -----*/
                            PosLot_var aLot;
                            PPT_CONVERT_LOTID_TO_LOT_OR( aLot, effectedLots[m].lotID, strStartLot_actionList_EffectSPCCheck_out, startLot_actionList_EffectSpecCheck__101 );

                            /*----- get Product ID -----*/
                            ProductSpecification_var aProductSpec;
                            CORBA::String_var productID;
                            try
                            {
                                aProductSpec = aLot->getProductSpecification();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification)
                            if ( CORBA::is_nil(aProductSpec) == FALSE )
                            {
                                try
                                {
                                    productID = aProductSpec->getIdentifier();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(ProductSpecification::getIdentifier)
                            }

                            /*----- get equipment ID -----*/
                            CORBA::String_var machineID;
                            if ( CORBA::is_nil(aMachine) == FALSE )
                            {
                                try
                                {
                                    machineID = aMachine->getIdentifier();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getIdentifier)
                            }

                            /*----- get machine recipe ID -----*/
                            CORBA::String_var recipeID;
                            if ( CORBA::is_nil(aRecipe) == FALSE )
                            {
                                try
                                {
                                    recipeID = aRecipe->getIdentifier();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getIdentifier)
                            }

                            /*----- get route ID -----*/
                            CORBA::String_var mainPDID;
                            if ( CORBA::is_nil(aMainPD) == FALSE )
                            {
                                try
                                {
                                    mainPDID = aMainPD->getIdentifier();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(ProcessDefinition::getIdentifier)
                            }

                            /*----- make e-mail text -----*/
                            memset( tmpMsg, '\0', sizeof(tmpMsg) );
                            sprintf( tmpMsg, "=============================================\n"\
                                             "===       SPC Violation Information       ===\n"\
                                             "===                                       ===\n"\
                                             "===       - This violation is raised      ===\n"\
                                             "===         by related monitor lot.       ===\n"\
                                             "=============================================\n"\
                                             "Monitor LotID          : %s \n"\
                                             "LotID                  : %s \n"\
                                             "ProductID              : %s \n"\
                                             "ProcessRouteID         : %s \n"\
                                             "ProcessOperationNumber : %s \n"\
                                             "ProcessEquipmentID     : %s \n"\
                                             "ProcessMachineRecipeID : %s ",
                                     (const char *)(effectedLots[0].lotID.identifier),
                                     (const char *)(effectedLots[m].lotID.identifier),
                                     (const char *)(productID                       ),
                                     (const char *)(mainPDID                        ),
                                     (const char *)(operationNo                     ),
                                     (const char *)(machineID                       ),
                                     (const char *)(recipeID                        ) );
                            //==============================
                            //===   P3000383 add end     ===
                            //==============================

                            findFlag = FALSE;
                            //-----------------------------------------------------------------------------------------
                            //  Check if strMessageAttributes is already registed with the same lotID & reasonCode or not.
                            //  If only not existed, entry new inhibition.
                            //
                            //-----------------------------------------------------------------------------------------
                            for ( n=0; n < msg_count; n++ )
                            {
//DSIV00001021                                if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].reasonCode, strSpcCheckLot[i].spcCheckResult)
//DSIV00001021                                  && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].lotID.identifier, effectedLots[m].lotID.identifier) )
//DSIV00001021 add start
                                if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].reasonCode, strSpcCheckLot[i].spcCheckResult)
                                  && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].lotID.identifier, effectedLots[m].lotID.identifier)
                                  && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].routeID.identifier, strSpcCheckLot[i].processRouteID.identifier)
                                  && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strMessageList[n].operationNumber, strSpcCheckLot[i].processOperationNumber) )
//DSIV00001021 add end

                                {
                                    PPT_METHODTRACE_V1("", "set!! findFlag = TRUE");

                                    findFlag = TRUE;
                                }
                            }
                            if ( findFlag == FALSE )
                            {
                                PPT_METHODTRACE_V1("", "findFlag == FALSE");

                                //-----------------------------------------
                                //  Get Main PD ID
                                //-----------------------------------------
//Q3000284                  PosLot_var aLot;
//Q3000284                  PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
//Q3000284                                               effectedLots[m].lotID,
//Q3000284                                               strStartLot_actionList_EffectSPCCheck_out,
//Q3000284                                               startLot_actionList_EffectSpecCheck );
//Q3000284
//Q3000284                  PosProcessDefinition_var mainPD;
//Q3000284                  try
//Q3000284                  {
//Q3000284                      mainPD = aLot->getMainProcessDefinition();
//Q3000284                  }
//Q3000284                  CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

//Q3000284 add start
                                PosProcessOperation_var aPOtmp;
                                PPT_CONVERT_STRING_TO_OBJECT( effectedLots[m].processOperation ,aPOtmp, PosProcessOperation );

                                if ( CORBA::is_nil( aPOtmp ) )
                                {
//P5000145                                SET_MSG_RC( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
                                    PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSPCCheck_out, MSG_NOT_FOUND_PO,    //P5000145
                                                     RC_NOT_FOUND_PO, effectedLots[m].processOperation,              //P5000145
                                                     effectedLots[m].lotID.identifier );                             //P5000145

                                    return RC_NOT_FOUND_PO;
                                }

                                PosMachine_var aMachine;
                                try
                                {
                                    aMachine  = aPOtmp->getAssignedMachine();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachine)

                                PosProcessDefinition_var aMainPD;
                                try
                                {
                                    aMainPD = aPOtmp->getMainProcessDefinition();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

                                CORBA::String_var operationNo;
                                try
                                {
                                    operationNo = aPOtmp->getOperationNumber();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber)

                                objectIdentifier eqpID;
                                PPT_SET_OBJECT_IDENTIFIER( eqpID,
                                                           aMachine,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           PosMachine );
                                objectIdentifier routeID;
                                PPT_SET_OBJECT_IDENTIFIER( routeID,
                                                           aMainPD,
                                                           strStartLot_actionList_EffectSPCCheck_out,
                                                           startLot_actionList_EffectSPCCheck,
                                                           PosProcessDefinition );
//Q3000284 add end

                                msg_count++;
                                strStartLot_actionList_EffectSPCCheck_out.strMessageList.length(msg_count);

                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].messageID.identifier  = messageID;
                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].lotID                 = effectedLots[m].lotID;
                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].lotStatus             = CIMFWStrDup("");
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].equipmentID           = equipmentID;
//Q3000284                      PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].routeID,
//Q3000284                                                 mainPD,
//Q3000284                                                 strStartLot_actionList_EffectSPCCheck_out,
//Q3000284                                                 startLot_actionList_EffectSPCCheck,
//Q3000284                                                 PosProcessDefinition );
//Q3000284                      strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].operationNumber       = CIMFWStrDup("");
//Q3000284 add start
                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].equipmentID           = eqpID;
                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].routeID               = routeID;
                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].operationNumber       = operationNo;
//Q3000284 add end
                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].reasonCode            = strSpcCheckLot[i].spcCheckResult;
//P3000383                      strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].messageText           = messageText;
                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[msg_count-1].messageText           = CIMFWStrDup( tmpMsg ); //P3000383
//DSIV00001021 add start
                                //-----------------------------------------------------------------------------
                                // Add ActionResultInfo
                                //-----------------------------------------------------------------------------
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_MailSend );
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[m].processOperation;
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(0);

                                dcActionInfo_count++;
//DSIV00001021 add end

                            }
                        }
                    }
//DSIV00000214 add start
                }
                else
                {
                    PPT_METHODTRACE_V1("", "correspondingPO is other Fab");
                    if ( equipment_hold_flag == TRUE )
                    {
                        findFlag = FALSE;   //DSIV00001021
                        //-------------------------------------------------------------------
                        //  Check equipment_hold_inhibition is already registed or not.
                        //  If only not existed, entry new inhibition.
                        //-------------------------------------------------------------------
                        PPT_METHODTRACE_V1("", "Check equipment_hold_inhibition is already registed or not");

                        for ( n = 0; n < entity_countForOtherFab; n++ )
                        {
                            if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment)
                              && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "break!!");

                                findFlag = TRUE;
                                break;
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]",
                                               strProcessOperationInfo.asgnEqpID.identifier);

                            entity_countForOtherFab++;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strProcessOperationInfo.asgnEqpID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID = strObjCommonIn.strUser.userID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        }
//DSIV00001021 add start
                        findFlag = FALSE;
                        for ( n = 0; n < dcActionInfo_count; n++ )
                        {
                            if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                            {
                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]",
                                               strProcessOperationInfo.asgnEqpID.identifier);

                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_EquipmentHold );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.asgnEqpID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                            dcActionInfo_count++;
                        }
//DSIV00001021 add end
                    }

                    if ( recipe_hold_flag == TRUE )
                    {
                        findFlag = FALSE;   //DSIV00001021
                        //-------------------------------------------------------------------
                        //  Check recipe_hold_inhibition is already registed or not.
                        //  If only not existed, entry new inhibition.
                        //-------------------------------------------------------------------
                        for ( n=0; n < entity_countForOtherFab; n++)
                        {
                            if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_MachineRecipe)
                              && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.asgnRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "break!!");

                                findFlag = TRUE;
                                break;
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [recipeID]",
                                               strProcessOperationInfo.asgnRecipeID.identifier);

                            entity_countForOtherFab++;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strProcessOperationInfo.asgnRecipeID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID = strObjCommonIn.strUser.userID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        }
//DSIV00001021 add start
                        findFlag = FALSE;
                        for ( n = 0; n < dcActionInfo_count; n++ )
                        {
                            if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                            {
                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.asgnRecipeID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [recipeID]",
                                               strProcessOperationInfo.asgnRecipeID.identifier);

                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RecipeHold );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.asgnRecipeID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                            dcActionInfo_count++;
                        }
//DSIV00001021 add end
                    }

                    if ( route_hold_flag == TRUE )
                    {
                        findFlag = FALSE;   //DSIV00001021
                        //-------------------------------------------------------------------
                        //  Check route_hold_inhibition is already registed or not.
                        //  If only not existed, entry new inhibition.
                        //-------------------------------------------------------------------
                        for ( n=0; n < entity_countForOtherFab; n++ )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Route )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.mainPDID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib, "" ) )
                            {
                                PPT_METHODTRACE_V1("", "break!!");

                                findFlag = TRUE;
                                break;
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]",
                                               strProcessOperationInfo.mainPDID.identifier);

                            entity_countForOtherFab++;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strProcessOperationInfo.mainPDID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID = strObjCommonIn.strUser.userID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        }
//DSIV00001021 add start
                        findFlag = FALSE;
                        for ( n = 0; n < dcActionInfo_count; n++ )
                        {
                            if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                            {
                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Route)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.mainPDID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, "" )
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]",
                                               strProcessOperationInfo.mainPDID.identifier);
                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RouteHold );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.mainPDID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");

                            dcActionInfo_count++;
                        }
//DSIV00001021 add end
                    }

                    if ( process_hold_flag == TRUE )
                    {
                        findFlag = FALSE;   //DSIV00001021
                        //-------------------------------------------------------------------
                        //  Check process_hold_inhibition is already registed or not.
                        //  If only not existed, entry new inhibition.
                        //-------------------------------------------------------------------
                        for ( n = 0; n < entity_countForOtherFab; n++ )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Operation )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.mainPDID.identifier )
                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib, strProcessOperationInfo.opeNo ) )
                            {
                                PPT_METHODTRACE_V1("", "break!!");

                                findFlag = TRUE;
                                break;
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]",
                                               strProcessOperationInfo.mainPDID.identifier);

                            entity_countForOtherFab++;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strProcessOperationInfo.mainPDID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = strProcessOperationInfo.opeNo;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp = CIMFWStrDup( SP_TIMESTAMP_NIL_OBJECT_STRING );
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID = strObjCommonIn.strUser.userID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        }
//DSIV00001021 add start
                        findFlag = FALSE;
                        for ( n = 0; n < dcActionInfo_count; n++ )
                        {
                            if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                            {
                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Operation)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.mainPDID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strProcessOperationInfo.opeNo )
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]",
                                               strProcessOperationInfo.mainPDID.identifier);

                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ProcessHold );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.mainPDID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = strProcessOperationInfo.opeNo;

                            dcActionInfo_count++;
                        }
//DSIV00001021 add end
                    }

                    if ( equipment_and_recipe_hold_flag == TRUE )
                    {
                        findFlag = FALSE;   //DSIV00001021
                        //-------------------------------------------------------------------
                        //  Check equipment_and_recipe_hold_inhibition is already registed or not.
                        //  If only not existed, entry new inhibition.
                        //-------------------------------------------------------------------
                        for ( n = 0; n < entity_countForOtherFab; n++ )
                        {
                            if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                            {
                                if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_MachineRecipe )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strProcessOperationInfo.asgnRecipeID.identifier))
                                {
                                    PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }

                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "findFlag == FALSE");

                            entity_countForOtherFab++;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strProcessOperationInfo.asgnEqpID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strProcessOperationInfo.asgnRecipeID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        }
//DSIV00001021 add start
                        findFlag = FALSE;
                        for ( n = 0; n < dcActionInfo_count; n++ )
                        {
                            if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                            {
                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strProcessOperationInfo.asgnRecipeID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }

                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "findFlag == FALSE");

                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Equipment_and_RecipeHold );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.asgnEqpID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strProcessOperationInfo.asgnRecipeID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                            dcActionInfo_count++;
                        }
//DSIV00001021 add end
                    }

                    if ( process_and_equipment_hold_flag == TRUE )
                    {
                        findFlag = FALSE;   //DSIV00001021
                        //-------------------------------------------------------------------
                        //  Check process_and_equipment_hold_inhibition is already registed or not.
                        //  If only not existed, entry new inhibition.
                        //-------------------------------------------------------------------
                        for ( n = 0; n < entity_countForOtherFab; n++ )
                        {
                            if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                            {
                                if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Operation )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.pdID.identifier )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className, SP_InhibitClassID_Equipment )
                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier ) )
                                {
                                    PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }

                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "findFlag == FALSE");

                            entity_countForOtherFab++;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strProcessOperationInfo.pdID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strProcessOperationInfo.asgnEqpID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].attrib    = CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID               = strObjCommonIn.strUser.userID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        }
//DSIV00001021 add start
                        findFlag = FALSE;
                        for ( n = 0; n < dcActionInfo_count; n++ )
                        {
                            if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                            {
                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Process)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.pdID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_Equipment )
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "set findFlag = TRUE");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }

                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "findFlag == FALSE");

                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Process_and_EquipmentHold );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Process);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.pdID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strProcessOperationInfo.asgnEqpID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                            dcActionInfo_count++;
                        }
//DSIV00001021 add end
                    }

                    if ( chamber_hold_flag == TRUE )
                    {
                        // for (strProcessOperationinfo.
                        findFlag = FALSE;   //DSIV00001021
                        //-------------------------------------------------------------------
                        //  Check chamber_hold_inhibition is already registed or not.
                        //  If only not existed, entry new inhibition.
                        //-------------------------------------------------------------------
                        for ( n = 0; n < entity_countForOtherFab; n++ )
                        {
                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className,
                                                   SP_InhibitClassID_Chamber     ) &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier,
                                                   strProcessOperationInfo.asgnEqpID.identifier ) &&
                                 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib,
                                                   strSpcCheckLot[i].processChamberID.identifier ))
                            {
                                PPT_METHODTRACE_V1("", "break!!");

                                findFlag = TRUE;
                                break;
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [Chamber]",
                                               strSpcCheckLot[i].processChamberID.identifier);

                            entity_countForOtherFab++;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strProcessOperationInfo.asgnEqpID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID    = strObjCommonIn.strUser.userID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        }
//DSIV00001021 add start
                        findFlag = FALSE;
                        for ( n = 0; n < dcActionInfo_count; n++ )
                        {
                            if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                            {
                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Chamber)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strSpcCheckLot[i].processChamberID.identifier )
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [Chamber]",
                                               strSpcCheckLot[i].processChamberID.identifier);
                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ChamberHold );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.asgnEqpID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);

                            dcActionInfo_count++;
                        }
//DSIV00001021 add end
                    }

                    if ( chamber_recipe_hold_flag == TRUE )
                    {
                        findFlag = FALSE;   //DSIV00001021
                        //-------------------------------------------------------------------
                        //  Check chamber_recipe_hold_inhibition is already registed or not.
                        //  If only not existed, entry new inhibition.
                        //-------------------------------------------------------------------
                        for ( n = 0; n < entity_countForOtherFab; n++ )
                        {
                            if( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities.length() == 2 )
                            {
                                if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className,
                                                       SP_InhibitClassID_Chamber         ) &&
                                     0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier,
                                                       strProcessOperationInfo.asgnEqpID.identifier     ) &&
                                     0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib,
                                                       strSpcCheckLot[i].processChamberID.identifier    ) &&
                                     0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].className,
                                                       SP_InhibitClassID_MachineRecipe   ) &&
                                     0 == CIMFWStrCmp( strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[1].objectID.identifier,
                                                       strProcessOperationInfo.asgnRecipeID.identifier ))
                                {
                                    PPT_METHODTRACE_V1("", "break!!");

                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [Chamber and Recipe]",
                                               strSpcCheckLot[i].processChamberID.identifier);

                            entity_countForOtherFab++;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(correspondingFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(2);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID  = strProcessOperationInfo.asgnEqpID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[1].objectID  = strProcessOperationInfo.asgnRecipeID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib    = CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp        = strObjCommonIn.strTimeStamp.reportTimeStamp;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp          = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode            = CIMFWStrDup(SP_Reason_SPCOutOfRangeInhibit);
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID    = strObjCommonIn.strUser.userID;
                            strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp      = strObjCommonIn.strTimeStamp.reportTimeStamp;
                        }
//DSIV00001021 add start
                        findFlag = FALSE;
                        for ( n = 0; n < dcActionInfo_count; n++ )
                        {
                            if( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 2 )
                            {
                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Chamber)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strSpcCheckLot[i].processChamberID.identifier )
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].className, SP_InhibitClassID_MachineRecipe )
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[1].objectID.identifier, strProcessOperationInfo.asgnRecipeID.identifier)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SPCOutOfRangeInhibit)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, strSpcCheckLot[i].processObjrefPO)
                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[m].lotID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "break!!");
                                    findFlag = TRUE;
                                    break;
                                }
                            }
                        }
                        if ( findFlag == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "findFlag == FALSE [Chamber and Recipe]",
                                               strSpcCheckLot[i].processChamberID.identifier);

                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ChamberAndRecipeHold );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(2);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Chamber);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID  = strProcessOperationInfo.asgnEqpID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib    = CIMFWStrDup(strSpcCheckLot[i].processChamberID.identifier);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].objectID  = strProcessOperationInfo.asgnRecipeID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[1].attrib    = CIMFWStrDup("");

                            dcActionInfo_count++;
                        }
//DSIV00001021 add end
                    }

                    if ( mail_flag == TRUE )
                    {
                        findLotFlag = FALSE;
                        findMsgFlag = FALSE;
                        msg_countPerMonLot = 0;
                        CORBA::ULong mailIdx;   //PSIV00001648

                        //-----------------------------------------------------------------------------------------
                        //  Check if strMessageAttributes is already registed with the same lotID & reasonCode or not.
                        //  If only not existed, entry new inhibition.
                        //
                        //-----------------------------------------------------------------------------------------
                        for ( n = 0; n < lot_countForMailOtherFab; n++ )
                        {
//DSIV00001021                            if( 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].lotID.identifier, effectedLots[m].lotID.identifier) )
//PSIV00001648//DSIV00001021 add start
//PSIV00001648                            if( 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].lotID.identifier, effectedLots[m].lotID.identifier)
//PSIV00001648                              && 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].routeID.identifier, strProcessOperationInfo.mainPDID.identifier)
//PSIV00001648                              && 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].opeNo, strProcessOperationInfo.opeNo) )
//PSIV00001648//DSIV00001021 add end
                            if ( 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[n].lotID.identifier,   effectedLots[m].lotID.identifier )               //PSIV00001648
                              && 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[n].routeID.identifier, strProcessOperationInfo.mainPDID.identifier )    //PSIV00001648
                              && 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[n].opeNo,              strProcessOperationInfo.opeNo ) )                //PSIV00001648
                            {
                                PPT_METHODTRACE_V1("", "set!! findFlag = TRUE");
                                mailIdx = n;                                                                                                                            //PSIV00001648
                                msg_countPerMonLot = strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[n].reasonCodeSeq.length();    //PSIV00001648
                                findLotFlag = TRUE;
                                break;
                            }
                        }
                        if ( findLotFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "findLotFlag == FALSE");

//PSIV00001648                            lot_countForMailOtherFab++;
//PSIV00001648
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq.length(lot_countForMailOtherFab);
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].lotID = effectedLots[m].lotID;
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].equipmentID = strProcessOperationInfo.asgnEqpID;
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].routeID = strProcessOperationInfo.mainPDID;
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].opeNo = CIMFWStrDup(strProcessOperationInfo.opeNo);
//PSIV00001648
//PSIV00001648                            msg_countPerMonLot++;
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].messageIDSeq.length( msg_countPerMonLot );
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].messageIDSeq[msg_countPerMonLot-1].identifier = messageID;
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].reasonCodeSeq.length( msg_countPerMonLot );
//PSIV00001648                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].reasonCodeSeq[msg_countPerMonLot-1] = strSpcCheckLot[i].spcCheckResult;
//PSIV00001648 Add Start
                            mailIdx = lot_countForMailOtherFab++;
                            msg_countPerMonLot = 0;
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq.length( lot_countForMailOtherFab );
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].lotID       = effectedLots[m].lotID;
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].equipmentID = strProcessOperationInfo.asgnEqpID;
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].routeID     = strProcessOperationInfo.mainPDID;
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].opeNo       = strProcessOperationInfo.opeNo;
//PSIV00001648 Add End
//DSIV00001021 add start
                            //-----------------------------------------------------------------------------
                            // Add ActionResultInfo
                            //-----------------------------------------------------------------------------
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[m].lotID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = true;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strSpcCheckLot[i].dcDefID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strSpcCheckLot[i].dcSpecID;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPC );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SPCOutOfRangeInhibit );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_MailSend );
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = strSpcCheckLot[i].processObjrefPO;
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(0);

                            dcActionInfo_count++;
//DSIV00001021 add end

                        }
//PSIV00001648                        else    //findLogFlag == TRUE
//PSIV00001648                        {
//PSIV00001648                            //keep current msg count
//PSIV00001648                            msg_countPerMonLot = strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].reasonCodeSeq.length();
//PSIV00001648
//PSIV00001648                            //check same message exist?
//PSIV00001648                            for( p=0; p<msg_countPerMonLot; p++ )
//PSIV00001648                            {
//PSIV00001648                                if( 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].reasonCodeSeq[p], strSpcCheckLot[i].spcCheckResult) )
//PSIV00001648                                {
//PSIV00001648                                    findMsgFlag = TRUE;
//PSIV00001648                                    break;
//PSIV00001648                                }
//PSIV00001648                            }
//PSIV00001648
//PSIV00001648                            if( findMsgFlag == FALSE )
//PSIV00001648                            {
//PSIV00001648                                PPT_METHODTRACE_V1("", "findMsgFlag == FALSE");
//PSIV00001648                                msg_countPerMonLot++;
//PSIV00001648                                strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].messageIDSeq.length( msg_countPerMonLot );
//PSIV00001648                                strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].messageIDSeq[msg_countPerMonLot-1].identifier = messageID;
//PSIV00001648                                strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].reasonCodeSeq.length( msg_countPerMonLot );
//PSIV00001648                                strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].reasonCodeSeq[msg_countPerMonLot-1] = strSpcCheckLot[i].spcCheckResult;
//PSIV00001648                            }
//PSIV00001648                        }
//PSIV00001648 Add Start
                        //check same message exist?
                        for ( p = 0; p < msg_countPerMonLot; p++ )
                        {
                            if ( 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].reasonCodeSeq[p], strSpcCheckLot[i].spcCheckResult ) )
                            {
                                findMsgFlag = TRUE;
                                break;
                            }
                        }

                        if ( findMsgFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "findMsgFlag == FALSE");
                            msg_countPerMonLot++;
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].messageIDSeq.length( msg_countPerMonLot );
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].messageIDSeq[msg_countPerMonLot-1].identifier =  messageID;
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].reasonCodeSeq.length( msg_countPerMonLot );
                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].reasonCodeSeq[msg_countPerMonLot-1] = strSpcCheckLot[i].spcCheckResult;
                        }
//PSIV00001648 Add End
                    }
                }
//DSIV00000214 add end
            }
//DSIV00001365 add start
            //-----------------------------------------------------------------------------
            // Set Entity Inhibit Reason Detail Information
            //-----------------------------------------------------------------------------
            // For Monitored Lot
            for ( eCnt = entity_count_keep; eCnt < entity_count; eCnt++ )
            {
                PPT_SET_ENTITYINHIBITREASONDETAILINFO_FROM_PPTSPCRESULT_AND_DCTYPE(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[eCnt],strSpcCheckLot[i].strSpcResult,strSpcIFParm[0].spcInput.collectionType)
                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos[0].relatedLotID = CIMFWStrDup( strSpcCheckLot[i].lotID.identifier );
            }
            // For Other Fab
            for ( eCnt = entity_countForOtherFab_keep; eCnt < entity_countForOtherFab; eCnt++ )
            {
                PPT_SET_ENTITYINHIBITREASONDETAILINFO_FROM_PPTSPCRESULT_AND_DCTYPE(strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[eCnt],strSpcCheckLot[i].strSpcResult,strSpcIFParm[0].spcInput.collectionType)
                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedLotID = CIMFWStrDup( strSpcCheckLot[i].lotID.identifier );
                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedFabID = CIMFWStrDup( currentFabID );
            }
//DSIV00001365 add end

            PPT_METHODTRACE_V3("", "strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length end", dcActionLot_idx , dcActionInfo_count);    //DSIV00001021
        }

        // reset requestOtherFabFlag for chart owner mail.
        requestOtherFabFlag = FALSE;

//P7000126 add start
        //--------------------------
        // Set e-mail data for chart
        //--------------------------
        CORBA::Long nSpcOutputLen = strSpcIFParm.length();
        CORBA::Long iSpcOutputCnt = 0;
        CORBA::Long mCount = 0;         //DSIV00000214
        stringSequence  tmpChartMailAdderess;    //DSIV00001021

        PPT_METHODTRACE_V2("", "nSpcOutputLen", nSpcOutputLen);
        for ( iSpcOutputCnt = 0; iSpcOutputCnt < nSpcOutputLen; iSpcOutputCnt++ )
        {
//DSIV00001021 add start
            //-----------------------------------
            // Get requestOtherFabFlag
            //-----------------------------------
            int i = 0;
            CORBA::String_var corrFabID;
            for ( i = 0; i < iSpcOutputCnt; i++ )
            {
                if ( CIMFWStrCmp(strSpcIFParm[iSpcOutputCnt].spcOutput.lotID.identifier, strSpcCheckLot[i].lotID.identifier) == 0 &&
                     CIMFWStrCmp(strSpcIFParm[iSpcOutputCnt].spcInput.processMainProcessDefinitionID.identifier, strSpcCheckLot[i].processRouteID.identifier) == 0 &&
                     CIMFWStrCmp(strSpcIFParm[iSpcOutputCnt].spcInput.processOperationNumber, strSpcCheckLot[i].processOperationNumber) == 0 )
                {
                    requestOtherFabFlag = strSpcCheckLot[i].requestOtherFabFlag;
                    corrFabID           = strSpcCheckLot[i].processFabID;
                    PPT_METHODTRACE_V2("", "corrFabID", corrFabID);
                    break;
                }
            }
//DSIV00001021 add end

            stringSequence  tmpItemNam, tmpChartGr, tmpChartId; //Temp data to Check Chart is duplicate or not
            nItem = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults.length();
            CORBA::Long jItemCnt = 0;
            for ( jItemCnt = 0; jItemCnt < nItem; jItemCnt++ )
            {
                nChart = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults.length();
                PPT_METHODTRACE_V3("", "Item", strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].dataItemName, nChart);
                CORBA::Long kChartCnt = 0;
                for ( kChartCnt = 0; kChartCnt < nChart; kChartCnt++ )
                {
                    PPT_METHODTRACE_V2("", strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartGroupID,
                                           strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartID);
                    //-----------------------------------
                    // Duplicate Check
                    //-----------------------------------
                    CORBA::Boolean bDupricateFlag = FALSE;
                    CORBA::Long nTmpChart = tmpChartGr.length();
                    CORBA::Long mTempChartCnt = 0;
                    for ( mTempChartCnt = 0; mTempChartCnt < nTmpChart; mTempChartCnt++ )
                    {
                        if(CIMFWStrCmp(strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].dataItemName,                 tmpItemNam[mTempChartCnt]) == 0 &&
                           CIMFWStrCmp(strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartGroupID, tmpChartGr[mTempChartCnt]) == 0 &&
                           CIMFWStrCmp(strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartID,      tmpChartId[mTempChartCnt]) == 0   )
                        {
                            bDupricateFlag = TRUE;
                            break;
                        }
                    }
                    if ( bDupricateFlag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "chart is duplicate -> continue");
                        continue;
                    }

//DSIV00001021                    CORBA::Long nMailOrg = strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length();
                    CORBA::Long nMailOrg = tmpChartMailAdderess.length();   //DSIV00001021
                    if ( CIMFWStrLen( strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartOwnerMailAddress ) > 0 )
                    {
                        PPT_METHODTRACE_V3( "", "OwnerMailAddress", strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartID,
                                            strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartOwnerMailAddress );

//DSIV00001021                        strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length(mail_send_count + 1);
//DSIV00001021                        strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count].chartMailAdderess =
//DSIV00001021                                                            strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartOwnerMailAddress;
//DSIV00001021 add start
                        tmpChartMailAdderess.length( mail_send_count + 1 );
                        tmpChartMailAdderess[mail_send_count] = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartOwnerMailAddress;
//DSIV00001021 add end
                        mail_send_count++;

                        tmpItemNam.length( nTmpChart + 1 );
                        tmpChartGr.length( nTmpChart + 1 );
                        tmpChartId.length( nTmpChart + 1 );
                        tmpItemNam[nTmpChart] = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].dataItemName;
                        tmpChartGr[nTmpChart] = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartGroupID;
                        tmpChartId[nTmpChart] = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartID;
                        nTmpChart++;
                    }

                    CORBA::Long nSubOwner = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartSubOwnerMailAddresses.length();
                    CORBA::Long mSubOwnerCnt = 0;
                    for ( mSubOwnerCnt = 0; mSubOwnerCnt < nSubOwner; mSubOwnerCnt++ )
                    {
                        if ( CIMFWStrLen( strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartSubOwnerMailAddresses[mSubOwnerCnt] ) > 0 )
                        {
                            PPT_METHODTRACE_V3("", "SubMailAddress", strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartID,
                                                             strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartSubOwnerMailAddresses[mSubOwnerCnt]);
//DSIV00001021                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length(mail_send_count + 1);
//DSIV00001021                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mail_send_count].chartMailAdderess =
//DSIV00001021                                                                strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartSubOwnerMailAddresses[mSubOwnerCnt];
//DSIV00001021 add start
                            tmpChartMailAdderess.length(mail_send_count+1);
                            tmpChartMailAdderess[mail_send_count] = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartSubOwnerMailAddresses[mSubOwnerCnt];
//DSIV00001021 add end
                            mail_send_count++;

                            tmpItemNam.length(nTmpChart+1);
                            tmpChartGr.length(nTmpChart+1);
                            tmpChartId.length(nTmpChart+1);
                            tmpItemNam[nTmpChart] = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].dataItemName;
                            tmpChartGr[nTmpChart] = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartGroupID;
                            tmpChartId[nTmpChart] = strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartID;
                            nTmpChart++;
                        }
                    }

                    if ( nMailOrg == mail_send_count )
                    {
                        PPT_METHODTRACE_V2("", "Not Found MailAddress", strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartID);
                        continue;
                    }


                    //-----------------------------------
                    // Set Process ChamberID
                    //-----------------------------------
                    ostrstream tmpChamberID;
                    int nTmpChamber = 0;
                    int nWaferChamber = strSpcIFParm[iSpcOutputCnt].spcInput.waferIDByChambers.length();
                    CORBA::Long mWaferChamberCnt = 0;
                    for ( mWaferChamberCnt = 0; mWaferChamberCnt < nWaferChamber; mWaferChamberCnt++ )
                    {
                        if ( strSpcIFParm[iSpcOutputCnt].spcInput.waferIDByChambers[mWaferChamberCnt].waferIDs.length() == 0 )
                        {
                            continue;
                        }

                        if ( nTmpChamber == 6 ) //Max ChamberID to write out is 6
                        {
                            tmpChamberID << "...";
                            break;
                        }
                        if ( nTmpChamber > 0 )
                        {
                            tmpChamberID << ",";
                        }
                        tmpChamberID << (const char*)(strSpcIFParm[iSpcOutputCnt].spcInput.waferIDByChambers[mWaferChamberCnt].procChamber);
                        nTmpChamber++;
                    }
                    tmpChamberID << ends;

                    //-----------------------------------
                    // Set e-mail Message
                    //-----------------------------------
                    ostrstream  tmpMsg;
                    tmpMsg << "SPC Violation Notice <" << (const char *)(strSpcIFParm[iSpcOutputCnt].spcOutput.lotID.identifier)             << "> \n\n"
;
                    tmpMsg << "Violation Timestamp               : "
                                                       << (const char *)(strObjCommonIn.strTimeStamp.reportTimeStamp)            << " \n";
                    tmpMsg << "SPC Result                        : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcOutput.lotRC)                        << " \n";
                    tmpMsg << "Action Taken                      : "
                                                       << SP_ActionCode_MailSend                                                 << " \n";
                    tmpMsg << "Lot ID                            : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcOutput.lotID.identifier)             << " \n";
                    tmpMsg << "Product ID                        : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcInput.productID.identifier)          << " \n";
                    tmpMsg << "Route ID                          : " <<
                                                       (const char *)(strSpcIFParm[iSpcOutputCnt].spcInput.processMainProcessDefinitionID.identifier) << " \n";
                    tmpMsg << "Operation Number                  : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcInput.processOperationNumber)        << " \n";
                    tmpMsg << "Process Equipment ID              : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcInput.processEquipmentID.identifier) << " \n";
                    tmpMsg << "Process Chamber ID                : "
                                                       << (const char *)(tmpChamberID.str())                                     << " \n";
                    tmpMsg << "Process Recipe ID                 : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcInput.processRecipeID.identifier)    << " \n";
                    tmpMsg << "Chart Group ID                    : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartGroupID) << " \n";
                    tmpMsg << "Chart Type                        : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartType) << " \n";
                    tmpMsg << "Chart ID                          : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].chartResults[kChartCnt].chartID) << " \n";
                    tmpMsg << "Item Name                         : "
                                                       << (const char *)(strSpcIFParm[iSpcOutputCnt].spcOutput.itemResults[jItemCnt].dataItemName);
                    tmpMsg << ends;

                    CORBA::Long mMailOrgCnt;
                    for ( mMailOrgCnt = nMailOrg; mMailOrgCnt < mail_send_count; mMailOrgCnt++ )
                    {
//DSIV00000214 add start
//DSIV00001021                        // Get Lot's PO
//DSIV00001021                        PosLot_var aPosLot;
//DSIV00001021                        PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
//DSIV00001021                                                     strSpcIFParm[iSpcOutputCnt].spcOutput.lotID,
//DSIV00001021                                                     strStartLot_actionList_EffectSPCCheck_out,
//DSIV00001021                                                     startLot_actionList_EffectSPCCheck__101 );
//DSIV00001021
//DSIV00001021                        ProcessOperation_var aTmpProcessOperation;
//DSIV00001021                        PosProcessOperation_var aPO;
//DSIV00001021
//DSIV00001021                        //------------------------------------------
//DSIV00001021                        // Current PO or Previous PO ?
//DSIV00001021                        //------------------------------------------
//DSIV00001021                        objLot_CheckConditionForPO_out  strLot_CheckConditionForPO_out;
//DSIV00001021                        rc = lot_CheckConditionForPO( strLot_CheckConditionForPO_out,
//DSIV00001021                                                      strObjCommonIn,
//DSIV00001021                                                      strSpcIFParm[iSpcOutputCnt].spcOutput.lotID );
//DSIV00001021                        if ( rc != RC_OK )
//DSIV00001021                        {
//DSIV00001021                            PPT_METHODTRACE_V1("", "lot_CheckConditionForPO() != RC_OK");
//DSIV00001021                            strStartLot_actionList_EffectSPCCheck_out.strResult = strLot_CheckConditionForPO_out.strResult;
//DSIV00001021                            return( rc );
//DSIV00001021                        }
//DSIV00001021
//DSIV00001021                        if ( strLot_CheckConditionForPO_out.currentPOFlag == TRUE )
//DSIV00001021                        {
//DSIV00001021                            //--------------------------------------------------------------------------
//DSIV00001021                            // Get PO from Current Operation.
//DSIV00001021                            //--------------------------------------------------------------------------
//DSIV00001021                            PPT_METHODTRACE_V1("", "Get PO from the current Operation.")
//DSIV00001021
//DSIV00001021                            try
//DSIV00001021                            {
//DSIV00001021                                aTmpProcessOperation = aPosLot->getProcessOperation();
//DSIV00001021                                aPO = PosProcessOperation::_narrow( aTmpProcessOperation );
//DSIV00001021                            }
//DSIV00001021                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)
//DSIV00001021                        }
//DSIV00001021                        else
//DSIV00001021                        {
//DSIV00001021                            //--------------------------------------------------------------------------
//DSIV00001021                            // Get PO from Previous Operation.
//DSIV00001021                            //--------------------------------------------------------------------------
//DSIV00001021                            PPT_METHODTRACE_V1("", "Get PO from the previous Operation.")
//DSIV00001021
//DSIV00001021                            try
//DSIV00001021                            {
//DSIV00001021                                aTmpProcessOperation = aPosLot->getPreviousProcessOperation();
//DSIV00001021                                aPO = PosProcessOperation::_narrow( aTmpProcessOperation );
//DSIV00001021                            }
//DSIV00001021                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getPreviousProcessOperation);
//DSIV00001021                        }
//DSIV00001021
//DSIV00001021                        if ( CORBA::is_nil(aPO) )
//DSIV00001021                        {
//DSIV00001021                            PPT_METHODTRACE_V1("", "aPO is nil");
//DSIV00001021                            PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
//DSIV00001021                                                MSG_NOT_FOUND_OPERATION,
//DSIV00001021                                                RC_NOT_FOUND_OPERATION,
//DSIV00001021                                                "" );
//DSIV00001021
//DSIV00001021                            return RC_NOT_FOUND_OPERATION;
//DSIV00001021                        }
//DSIV00001021
//DSIV00001021                        CORBA::String_var currentFabID;
//DSIV00001021                        try
//DSIV00001021                        {
//DSIV00001021                            currentFabID = aPO->getFabID();
//DSIV00001021                        }
//DSIV00001021                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessOperationLocation);
//DSIV00001021
//DSIV00001021                        PPT_METHODTRACE_V2("", "currentFabID", currentFabID);
//DSIV00001021                        if( CIMFWStrLen(currentFabID) == 0 )
//DSIV00001021                        {
//DSIV00001021                            PPT_METHODTRACE_V1("", "currentFabID is null");
//DSIV00001021                            PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
//DSIV00001021                                                MSG_INTERFAB_NOT_FOUND_FAB_ID, RC_INTERFAB_NOT_FOUND_FAB_ID, "");
//DSIV00001021                            return RC_INTERFAB_NOT_FOUND_FAB_ID;
//DSIV00001021                        }
//DSIV00001021
//DSIV00001021                        //-------------------------------------------------
//DSIV00001021                        //  Get the corresponding processOperation
//DSIV00001021                        //-------------------------------------------------
//DSIV00001021                        PPT_METHODTRACE_V1("", "Get the corresponding processOperation");
//DSIV00001021                        PosProcessFlowContext_var aPFX;
//DSIV00001021                        try
//DSIV00001021                        {
//DSIV00001021                            aPFX = aPosLot->getProcessFlowContext();
//DSIV00001021                        }
//DSIV00001021                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext)
//DSIV00001021
//DSIV00001021                        if ( CORBA::is_nil(aPFX) )
//DSIV00001021                        {
//DSIV00001021                              PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
//DSIV00001021                                                  MSG_NOT_FOUND_PFX,
//DSIV00001021                                                  RC_NOT_FOUND_PFX,
//DSIV00001021                                                  "" );
//DSIV00001021
//DSIV00001021                              return RC_NOT_FOUND_PFX;
//DSIV00001021                        }
//DSIV00001021
//DSIV00001021                        PosProcessOperation_var aCorrPO;
//DSIV00001021
//DSIV00001021                        try
//DSIV00001021                        {
//DSIV00001021                            aCorrPO = aPFX->getCorrespondingProcessOperationFor( aPO );
//DSIV00001021                        }
//DSIV00001021                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getCorrespondingProcessOperationFor);
//DSIV00001021
//DSIV00001021                        CORBA::String_var corrFabID;
//DSIV00001021
//DSIV00001021                        if ( CORBA::is_nil(aCorrPO) != TRUE )
//DSIV00001021                        {
//DSIV00001021                            //------------------------------------------------
//DSIV00001021                            //   Corresponding operation is Specified and
//DSIV00001021                            //   that operation was processed.
//DSIV00001021                            //------------------------------------------------
//DSIV00001021                            try
//DSIV00001021                            {
//DSIV00001021                                corrFabID = aCorrPO->getFabID();
//DSIV00001021                            }
//DSIV00001021                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessOperationLocation);
//DSIV00001021
//DSIV00001021                            PPT_METHODTRACE_V2("", "corrFabID", corrFabID);
//DSIV00001021                            if( CIMFWStrLen(corrFabID) == 0 )
//DSIV00001021                            {
//DSIV00001021                                PPT_METHODTRACE_V1("", "corresponding FabID is null");
//DSIV00001021                                PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSPCCheck_out,
//DSIV00001021                                                    MSG_INTERFAB_NOT_FOUND_FAB_ID, RC_INTERFAB_NOT_FOUND_FAB_ID, "");
//DSIV00001021                                return RC_INTERFAB_NOT_FOUND_FAB_ID;
//DSIV00001021                            }
//DSIV00001021
//DSIV00001021                            if( CIMFWStrCmp(currentFabID, corrFabID) != 0 )
//DSIV00001021                            {
//DSIV00001021                                requestOtherFabFlag = TRUE;
//DSIV00001021                            }
//DSIV00001021                        }

                        if ( requestOtherFabFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "correspondingPO is current Fab");
//DSIV00000214 add end
//DSIV00001021 add start
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length(mMailOrgCnt + 1);
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].chartMailAdderess = tmpChartMailAdderess[mMailOrgCnt];
//DSIV00001021 add end
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].messageAttributes.messageID.identifier =
                                                                      CIMFWStrDup( SP_MessageID_SPCChartOver );
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].messageAttributes.lotID =
                                                                      strSpcIFParm[iSpcOutputCnt].spcOutput.lotID;
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].messageAttributes.lotStatus =
                                                                      CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].messageAttributes.equipmentID =
                                                                      strSpcIFParm[iSpcOutputCnt].spcInput.processEquipmentID;
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].messageAttributes.routeID =
                                                                      strSpcIFParm[iSpcOutputCnt].spcInput.processMainProcessDefinitionID;
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].messageAttributes.operationNumber =
                                                                      strSpcIFParm[iSpcOutputCnt].spcInput.processOperationNumber;
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].messageAttributes.reasonCode =
                                                                      CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mMailOrgCnt].messageAttributes.messageText =
                                                                      CIMFWStrDup( tmpMsg.str() );
//DSIV00000214 add start
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "correspondingPO is other Fab. MailSend request to other Fab");
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo.length(mCount+1);
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].fabID = CIMFWStrDup(corrFabID);
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].strMailSend.messageAttributes.messageID.identifier =
                                                                      CIMFWStrDup( SP_MessageID_SPCChartOver );
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].strMailSend.messageAttributes.lotID =
                                                                      strSpcIFParm[iSpcOutputCnt].spcOutput.lotID;
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].strMailSend.messageAttributes.lotStatus =
                                                                      CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].strMailSend.messageAttributes.equipmentID =
                                                                      strSpcIFParm[iSpcOutputCnt].spcInput.processEquipmentID;
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].strMailSend.messageAttributes.routeID =
                                                                      strSpcIFParm[iSpcOutputCnt].spcInput.processMainProcessDefinitionID;
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].strMailSend.messageAttributes.operationNumber =
                                                                      strSpcIFParm[iSpcOutputCnt].spcInput.processOperationNumber;
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].strMailSend.messageAttributes.reasonCode =
                                                                      CIMFWStrDup("");
                            strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[mCount].strMailSend.messageAttributes.messageText =
                                                                      CIMFWStrDup( tmpMsg.str() );
                            mCount++;
                        }
//DSIV00001021 add start
                        PPT_METHODTRACE_V2("", "To", tmpChartMailAdderess[mMailOrgCnt]);
                        PPT_METHODTRACE_V2("", "To", tmpMsg.str() );
//DSIV00001021 add end
//DSIV00000214 add end
                    }
                    tmpChamberID.rdbuf()->freeze(0);
                    tmpMsg.rdbuf()->freeze(0);
                } //nChart
            } //nItem
        } //nSpcOutputLen

//DSIV00001021        CORBA::Long mailSendCnt = 0;
//DSIV00001021        for ( mailSendCnt = 0; mailSendCnt < mail_send_count; mailSendCnt++ )
//DSIV00001021        {
//DSIV00001021            PPT_METHODTRACE_V2("", "To", strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mailSendCnt].chartMailAdderess);
//DSIV00001021            PPT_METHODTRACE_V2("", "To", strStartLot_actionList_EffectSPCCheck_out.strMailSendList[mailSendCnt].messageAttributes.messageText);
//DSIV00001021        }
//P7000126 add end

//DSIV00000214 add start
//DSIV00001021        if( requestOtherFabFlag == TRUE )
//DSIV00001021        {
//DSIV00001021            PPT_METHODTRACE_V1("", "If requestOtherFabFlag is TRUE, delete strMailSendList.");
//DSIV00001021            strStartLot_actionList_EffectSPCCheck_out.strMailSendList.length(0);
//DSIV00001021        }

        // set data for vaiolation mail
        strStartLot_actionList_EffectSPCCheck_out.strInterFabMonitorGroupActionInfoSequence = strInterFabMonitorGroupActionInfoSequence;
//DSIV00000214 add end
        strStartLot_actionList_EffectSPCCheck_out.strDCActionLotResult                      = strDCActionLotResult;                         //DSIV00001021
        PPT_METHODTRACE_V2("", "dcActionLot_count", dcActionLot_count);                                                                     //DSIV00001021

        PPT_METHODTRACE_EXIT("PPTManager_i::startLot_actionList_EffectSPCCheck__101");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strStartLot_actionList_EffectSPCCheck_out,
                            startLot_actionList_EffectSPCCheck__101, methodName)
}
