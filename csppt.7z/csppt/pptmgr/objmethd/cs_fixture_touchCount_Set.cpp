//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_fixture_touchCount_Set.cpp
//


#include "cs_pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"
#include "ppcdr.hh"
#include "ppcdrcp.hh"
#include "pperson.hh"
#include "pmc.hh"
#include "pstmc.hh"
#include "pperson.hh"
#include "pbufrs.hh"
#include "pdrmggl.hh"
#include "mtrllctn.hh"

// Class: CS_PPTManager
//
// Service: cs_fixture_touchCount_Set()
//
// Change history:
// Date       Defect#       Person        Comments
// ---------- --------      ------------- -------------------------------------------
//
// Innotron Modification history :
// Date       Defect#       Person        Comments
// ---------- ------------- ------------- -------------------------------------------
// 2017/09/11 INN-R170006   YangXigang    For fixture
// 2017/09/28 INN-R17000601 Sam Hsueh     Not allow -1 as input parameter of touch count
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    csObjFixture_touchCount_Set_out&       strFixture_touchCount_Set_out,
//    pptObjCommonIn&                        strObjCommonIn,
//    csObjFixture_touchCount_Set_in&        strFixture_touchCount_Set_in
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_fixture_touchCount_Set(
    csObjFixture_touchCount_Set_out&       strFixture_touchCount_Set_out,
    const pptObjCommonIn&                  strObjCommonIn,
    const csObjFixture_touchCount_Set_in&  strFixture_touchCount_Set_in) 
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_fixture_touchCount_Set");

        PosProcessDurable_var aFixture;
        PPT_CONVERT_FIXTUREID_TO_FIXTURE_OR( aFixture, 
                                             strFixture_touchCount_Set_in.fixtureID,
                                             strFixture_touchCount_Set_out,
                                             cs_fixture_touchCount_Set);
                                            
        //INN-R17000601(delete) CORBA::Long IngCurrentTouchCount = 0;
        //INN-R17000601(delete) CORBA::Long IngAccumulatedTouchCount = 0;
        //INN-R17000601(delete) 
        //INN-R17000601(delete) try
        //INN-R17000601(delete) {
        //INN-R17000601(delete)      IngCurrentTouchCount = aFixture->getCurrentTouchCount();
        //INN-R17000601(delete) }
        //INN-R17000601(delete) CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getCurrentTouchCount);
        //INN-R17000601(delete) 
        //INN-R17000601(delete) try
        //INN-R17000601(delete) {
        //INN-R17000601(delete)      SI_PPT_USERDATA_GET_INTEGER( aFixture,
        //INN-R17000601(delete)                                   CS_M_Fixture_CumulativeTouchCount,
        //INN-R17000601(delete)                                   IngAccumulatedTouchCount);
        //INN-R17000601(delete) }
        //INN-R17000601(delete) CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getUserDataNamed);   

        CORBA::Long IngNewTouchCount = strFixture_touchCount_Set_in.strFixtureTouchCountInfo.touchCount;
        CORBA::Long IngNewAccumulatedTouchCount = strFixture_touchCount_Set_in.strFixtureTouchCountInfo.accumTouchCount;
        //INN-R17000601 CORBA::Boolean bUpdateAccumulatedFlag = FALSE;
        
        if ( IngNewTouchCount < 0 )
        {
             //INN-R17000601 IngNewTouchCount = IngCurrentTouchCount + 1 ;
             //INN-R17000601 IngNewAccumulatedTouchCount = IngAccumulatedTouchCount + 1;         
             //INN-R17000601 bUpdateAccumulatedFlag = TRUE;
             //INN-R17000601 add start
             SET_MSG_RC(strFixture_touchCount_Set_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
             return RC_INVALID_INPUT_PARM;
             //INN-R17000601 add end
        }
        //INN-R17000601(delete) else
        //INN-R17000601(delete) {
        //INN-R17000601(delete)     if ( IngNewAccumulatedTouchCount >= 0 )
        //INN-R17000601(delete)     {
        //INN-R17000601(delete)          bUpdateAccumulatedFlag = TRUE;  
        //INN-R17000601(delete)     }
        //INN-R17000601(delete) }
        // Update touch count
        try
        {
             aFixture->setCurrentTouchCount(IngNewTouchCount);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setCurrentTouchCount);
        
        //INN-R17000601 if ( bUpdateAccumulatedFlag )
        if ( IngNewAccumulatedTouchCount >= 0 ) //INN-R17000601
        {
             try
             {
                 SI_PPT_USERDATA_SET_INTEGER( aFixture,
                                              CS_M_Fixture_CumulativeTouchCount,
                                              IngNewAccumulatedTouchCount);
             }
             CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed); 
        }
        
        // Check touch count control required, and change touch count state
        //
        // *** please add try catch
        CORBA::Boolean bTchCntCtrlFlag = aFixture->isTouchCountRequired();
        PPT_METHODTRACE_V2("","aFixture->isTouchCountRequired:", bTchCntCtrlFlag);
        
        if ( bTchCntCtrlFlag )
        {
            CORBA::Long IngMaintTouchCnt = 0 ;
            CORBA::Long IngMaxTouchCnt = 0 ;
            IngMaintTouchCnt = aFixture->getMaintTouchCount();
            IngMaxTouchCnt = aFixture->getMaxTouchCount();
            PPT_METHODTRACE_V2("","aFixture->getMaintTouchCount:", IngMaintTouchCnt);
            PPT_METHODTRACE_V2("","aFixture->getMaxTouchCount:", IngMaxTouchCnt);
            PPT_METHODTRACE_V2("","IngNewTouchCount:", IngNewTouchCount);
            
            if ( IngNewTouchCount < IngMaintTouchCnt )
            {
                aFixture->setTouchCountState(SP_BIBTouchCountState_Available);  
                PPT_METHODTRACE_V2("","1,change aFixture->setTouchCountState to ", SP_BIBTouchCountState_Available);
            }
            else if ( IngNewTouchCount < IngMaxTouchCnt )
            {
                 aFixture->setTouchCountState(SP_BIBTouchCountState_MaintenanceWarning);
                 PPT_METHODTRACE_V2("","2,change aFixture->setTouchCountState to ", SP_BIBTouchCountState_MaintenanceWarning);
            }
            else
            {
                 aFixture->setTouchCountState(SP_BIBTouchCountState_NotAvailable);
                 PPT_METHODTRACE_V2("","3,change aFixture->setTouchCountState to ", SP_BIBTouchCountState_NotAvailable);
            }
        }
        
        //Set return structure
        strFixture_touchCount_Set_out.strFixtureTouchCountInfo.touchCount = IngNewTouchCount ;
        strFixture_touchCount_Set_out.strFixtureTouchCountInfo.accumTouchCount = IngNewAccumulatedTouchCount ;

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_fixture_touchCount_Set");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strFixture_touchCount_Set_out, cs_fixture_touchCount_Set, methodName);
}
