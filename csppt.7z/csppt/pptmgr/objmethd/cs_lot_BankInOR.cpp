//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_lot_BankInOR.cpp
//

#include "cs_pptmgr.hpp"

#include "timstamp.hpp"
#include "duration.hpp"

#include "pbank.hh"
#include "pcas.hh"
#include "pcatgry.hh"
#include "pcode.hh"
#include "pdp.hh"
#include "pdpgl.hh"
#include "pdpmg.hh"
#include "pe10st.hh"  //QA193 (R20)
#include "pflwbch.hh"
#include "plcrc.hh"
#include "plot.hh"
#include "plotfm.hh"
#include "pltnt.hh"
#include "pltopnt.hh"
#include "pmaloc.hh"
#include "pmc.hh"
#include "pmcrc.hh"
#include "ppcdf.hh"
#include "ppcdr.hh"
#include "ppcflw.hh"
#include "ppcflwx.hh"
//D5000016 #include "ppcgrp.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "pperson.hh"
#include "pprrq.hh"
#include "pprsp.hh"
#include "pprspg.hh"
#include "pprstch.hh"
#include "pqtime.hh"
#include "prcssctv.hh"
#include "pstmc.hh"   //QA193 (R20)
#include "pwafer.hh"


#include "pptdefs.h"

// Class: CS_PPTManager
//
// Service: lot_BankIn()
//
// Change history:
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 1999-07-16  1.03      Y.Iwasaki      Add makeNotBankInRequired() call (DCR9900097) (R20b)
// 1999-12-08            R.Furuta       "setLastClaimAllWafers()" Comment out (DCR9900054)
// 2000/02/22  D2200115  R.Furuta       Add NIL Check
// 2001-08-03  D4000016  M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2003/05/19 D5000016 K.Kido         Useless class deletion.
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017/10/28 INN-R170016   JJ.Zhang       Equipment Monitor ehnancement
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//    objLot_BankIn_out& strLot_BankIn
//    const pptObjCommonIn& strObjCommonIn
//    const objectIdentifier& lotID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170016 CORBA::Long PPTManager_i::lot_BankIn(objLot_BankIn_out& strLot_BankIn, const pptObjCommonIn& strObjCommonIn,  const objectIdentifier& lotID)
CORBA::Long CS_PPTManager_i::lot_BankIn(objLot_BankIn_out& strLot_BankIn, const pptObjCommonIn& strObjCommonIn,  const objectIdentifier& lotID) //INN-R170016
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_BankIn");

        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR(aLot,lotID,strLot_BankIn,lot_BankIn);

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID(aPerson,strObjCommonIn.strUser.userID,strLot_BankIn,lot_BankIn);

        ProcessOperation_var aProcessOperation;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aProcessOperation = aLot->getProcessOperation();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::getProcessOperation);

        PosProcessOperation_var aPosProcessOperation;
        aPosProcessOperation = PosProcessOperation::_narrow(aProcessOperation);

        //D2200115 start
        if(CORBA::is_nil(aPosProcessOperation))
        {
            PPT_SET_MSG_RC_KEY( strLot_BankIn,
                                MSG_NOT_FOUND_OPERATION,
                                RC_NOT_FOUND_OPERATION, "" );
            return RC_NOT_FOUND_OPERATION ;
        }
        //D2200115 end

        PosProcessDefinition_var aMainProcessDefinition;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aMainProcessDefinition = aPosProcessOperation->getMainProcessDefinition();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

        //D2200115 start
        if(CORBA::is_nil(aMainProcessDefinition))
        {
            PPT_SET_MSG_RC_KEY( strLot_BankIn,
                                MSG_NOT_FOUND_PD,
                                RC_NOT_FOUND_PD, "" );
            return RC_NOT_FOUND_PD ;
        }
        //D2200115 end

        PosBank_var anEndBank;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            anEndBank = aMainProcessDefinition->getEndBank();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getEndBank)

//INN-R170016 Add Start
        // Check whether the wafer is downgraded NPW wafer and has specific endBank
        CORBA::Long rc = RC_OK;

        csObjLot_NPWProduct_Change_in strObjLot_NPWProduct_Change_in;
        //--------------------------------
        // Get lot type
        //--------------------------------
        objLot_lotType_Get_out strLot_lotType_Get_out;
        objLot_lotType_Get_in  strLot_lotType_Get_in;
        strLot_lotType_Get_in.lotID = lotID;
        rc = lot_lotType_Get( strLot_lotType_Get_out,
                              strObjCommonIn,
                              strLot_lotType_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
            strLot_BankIn.strResult = strLot_lotType_Get_out.strResult;
            return rc;
        }
        PPT_METHODTRACE_V2("", "strLot_lotType_Get_out.lotType", strLot_lotType_Get_out.lotType);

        if ( 0 != CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_ProductionLot) )
        {
            //--------------------------------
            // Get lot product
            //--------------------------------
            objLot_productID_Get_out strLot_productID_Get_out;
            rc = lot_productID_Get( strLot_productID_Get_out,
                                    strObjCommonIn,
                                    lotID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","lot_productID_Get != RC_OK", rc );
                strLot_BankIn.strResult = strLot_productID_Get_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "productID", strLot_productID_Get_out.productID.identifier);

            //check product is defined as Recycle or not
            csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
            strEqpMonitorInventory_ListGetDR_in.npwType = CS_EqpMonitor_NPW_Type_Recycle; //Recycle
            strEqpMonitorInventory_ListGetDR_in.productID = strLot_productID_Get_out.productID.identifier;

            csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
            rc = cs_eqpMonitorInventory_ListGetDR(strEqpMonitorInventory_ListGetDR_out,
                                         strObjCommonIn,
                                         strEqpMonitorInventory_ListGetDR_in) ;
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_ListGetDR() rc != RC_OK")
                strLot_BankIn.strResult = strEqpMonitorInventory_ListGetDR_out.strResult ;
                return rc ;
            }
            //product is defined as NPW Recycle
            if( strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length() > 0 )
            {
                PPT_METHODTRACE_V1("", "NPW Recycle Product");

                objLot_waferMap_Get_out strLot_waferMap_Get_out;
                rc = lot_waferMap_Get(strLot_waferMap_Get_out, strObjCommonIn, lotID);
                if(rc!= RC_OK)
                {
                    PPT_METHODTRACE_V2("", "lot_waferMap_Get() != RC_OK ", rc );
                    strLot_BankIn.strResult = strLot_waferMap_Get_out.strResult;
                    return( rc );
                }
                CORBA::Long waferLen = strLot_waferMap_Get_out.strLotWaferMap.length();
                
                if( waferLen > 0 )
                {
                    CORBA::String_var dwgBankId;
                    CORBA::String_var dwgProductId;

                    PosWafer_var aPosWafer;
                    PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
                                                     strLot_waferMap_Get_out.strLotWaferMap[0].waferID,
                                                     strLot_BankIn,
                                                     lot_BankIn );
                    SI_PPT_USERDATA_GET_STRING(aPosWafer, CS_M_WFR_Downgrade_BankID, dwgBankId);
                    PPT_METHODTRACE_V2("", "CS_M_WFR_Downgrade_BankID", dwgBankId );

                    SI_PPT_USERDATA_GET_STRING(aPosWafer, CS_M_WFR_Downgrade_Product, dwgProductId);
                    PPT_METHODTRACE_V2("", "CS_M_WFR_Downgrade_Product", dwgProductId );

                    if( 0 < CIMFWStrLen(dwgBankId) )
                    {
                        PPT_METHODTRACE_V2("", "dwgBankId", dwgBankId );
                        objectIdentifier bankID;
                        bankID.identifier = dwgBankId;

                        PPT_CONVERT_BANKID_TO_BANK_OR( anEndBank,
                                               bankID,
                                               strLot_BankIn,
                                               lot_BankIn );
                        PPT_METHODTRACE_V2("", "bankID", bankID.identifier );
                    }
                    if( 0 < CIMFWStrLen(dwgProductId) && 0 != CIMFWStrCmp(dwgProductId,strLot_productID_Get_out.productID.identifier) )
                    {
                        PPT_METHODTRACE_V2("", "dwgProductId == productID", dwgProductId );
                        //same target, reset downgrade productId
                        strObjLot_NPWProduct_Change_in.orgProductID = strLot_productID_Get_out.productID;
                        strObjLot_NPWProduct_Change_in.productID.identifier = dwgProductId;
                    }
                }
                PPT_METHODTRACE_V2("", "waferLen", waferLen );
            }
        }
//INN-R170016 Add End

        //D2200115 start
        if(CORBA::is_nil(anEndBank))
        {
            PPT_SET_MSG_RC_KEY( strLot_BankIn,
                                MSG_NOT_FOUND_BANK,
                                RC_NOT_FOUND_BANK, "" );
            return RC_NOT_FOUND_BANK ;
        }
        //D2200115 end

        // DCR738.
        CORBA::Boolean isBankInBank;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            isBankInBank = anEndBank->isBankInBank();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Bank::isBankInBank)

        if( isBankInBank == FALSE )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_BankIn", "isBankInBank == FALSE ");
            SET_MSG_RC(strLot_BankIn,MSG_INVALID_BANK_TYPE,RC_INVALID_BANK_TYPE);
            return RC_INVALID_BANK_TYPE;
        }

        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->setBank(anEndBank);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setBank)

        // by Hattori DCR 501 start
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->makeProcessing();
        }
        catch(InvalidStateTransitionSignal)
        {
            SET_FW_MSG_RC_KEY2(strLot_BankIn,lot_BankIn,
                               MSG_INVALID_STATE_TRANS,RC_INVALID_STATE_TRANS,
                               PosLot::makeProcessing,InvalidStateTransitionSignal,
                               "*****",SP_Lot_ProcState_Processing)
            return RC_INVALID_STATE_TRANS;
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::makeProcessing)
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->makeProcessed();
        }
        catch(InvalidStateTransitionSignal)
        {
            SET_FW_MSG_RC_KEY2(strLot_BankIn,lot_BankIn,
                               MSG_INVALID_STATE_TRANS,RC_INVALID_STATE_TRANS,
                               PosLot::makeProcessed,InvalidStateTransitionSignal,
                               "*****",SP_Lot_ProcState_Processed)
            return RC_INVALID_STATE_TRANS;
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::makeProcessed)
        // by Hattori DCR 501 end

        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->makeCompleted();
        }
        catch(InvalidStateTransitionSignal)
        {
            SET_FW_MSG_RC_KEY2(strLot_BankIn,lot_BankIn,
                               MSG_INVALID_STATE_TRANS,RC_INVALID_STATE_TRANS,
                               PosLot::makeCompleted,InvalidStateTransitionSignal,
                               "*****",CIMFW_Lot_FinishedState_Completed)
            return RC_INVALID_STATE_TRANS;
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::makeCompleted)

        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->makeInBank();
        }
        catch(InvalidStateTransitionSignal)
        {
            SET_FW_MSG_RC_KEY2(strLot_BankIn,lot_BankIn,
                               MSG_INVALID_STATE_TRANS,RC_INVALID_STATE_TRANS,
                               PosLot::makeInBank,InvalidStateTransitionSignal,
                               "*****",SP_Lot_InventoryState_InBank)
            return RC_INVALID_STATE_TRANS;
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::makeInBank)

        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setLastClaimedTimeStamp)

        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setLastClaimedPerson)

        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setStateChangedTimeStamp)

        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLot->setStateChangedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setStateChangedPerson)

//D2200054   try
//D2200054   {
//D2200054       PPT_DISPLAY_RESPONSE_TIME();
//D2200054       aLot->setLastClaimAllWafers(strObjCommonIn.strTimeStamp.reportTimeStamp, aPerson);
//D2200054   }
//D2200054   CATCH_AND_RAISE_EXCEPTIONS(Lot::setLastClaimAllWafers);

        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            theDispatchingManager->removeFromQueue(aLot);
        }
        CATCH_AND_RAISE_EXCEPTIONS(DispatchingManager::removeFromQueue)

        CORBA::Boolean isRecycleBank = FALSE ;
        CORBA::Boolean isControlWaferBank = FALSE ;

        try
        {
            isRecycleBank = anEndBank->isRecycleBank() ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosBank::isRecycleBank)
        try
        {
            isControlWaferBank = anEndBank->isControlWaferBank() ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosBank::isControlWaferBank)

        if(isRecycleBank)
        {
            try
            {
                aLot->makeWaitRecycle();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeWaitRecycle)
        }
        else if ( isControlWaferBank )
        {
            try
            {
                aLot->makeWaitUse();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeWaitUse)
        }

        try                                                        //1.03 (DCR9900097) (R20b)
        {                                                          //1.03 (DCR9900097) (R20b)
            aLot->makeNotBankInRequired() ;                        //1.03 (DCR9900097) (R20b)
        }                                                          //1.03 (DCR9900097) (R20b)
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeNotBankInRequired)  //1.03 (DCR9900097) (R20b)

//D4000016 Add Start
        //---------------------------------------------
        // blank is set on setRequiredCassetteCategory.
        //--------------------------------------------- 
        try
        {
            aLot->setRequiredCassetteCategory("");
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setRequiredCassetteCategory)
//D4000016 Add End

//INN-R170016 Add Start
        //------------------------------------------------------
        //  change to Downgrade target productID
        //------------------------------------------------------
        if( 0 < CIMFWStrLen(strObjLot_NPWProduct_Change_in.productID.identifier) )
        {
            PPT_METHODTRACE_V2("", "change to productID", strObjLot_NPWProduct_Change_in.productID.identifier);

            strObjLot_NPWProduct_Change_in.lotID = lotID;

            csObjLot_NPWProduct_Change_out strObjLot_NPWProduct_Change_out;
            rc = cs_lot_NPWProduct_Change( strObjLot_NPWProduct_Change_out,
                                           strObjCommonIn,
                                           strObjLot_NPWProduct_Change_in);
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("","cs_lot_NPWProduct_Change() != RC_OK");
                strLot_BankIn.strResult = strObjLot_NPWProduct_Change_out.strResult ;
                return(rc);    
            }
        }
//INN-R170016 Add End

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_BankIn");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_BankIn, lot_BankIn, methodName)
}

