#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/lotFamily_splitNo_Create.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:56:32 [ 7/13/07 19:56:33 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: lotFamily_splitNo_Create
//

//INN-R170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-R170001
#include "plot.hh"
#include "plotfm.hh"

//
//[Object Function Name]: long lotFamily_splitNo_Create
//
// Date       PTR/DCR  Author         Note
// ---------- -------- -------------  -------------------------------------------
// 2003/09/02 D5000178 K.Kido         Initial release.  (R5.0)
// 2004/04/16 P5100179 K.Kido         Change Prohibit Character Check. 
//
//[Function Description]:
//   **** Exchange Suffix Number,and set lastSuffixNumber at LotFamily.
//  Conversion table:
//      100 ~ 109 : A0 ~ A9
//      110 ~ 119 : B0 ~ B9
//      120 ~ 129 : C0 ~ C9
//      130 ~ 139 : D0 ~ D9
//       .
//       .
//       .
//
//   **** And considers a prohibit character. These are given by environment value.
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            lotID;
//
//[Output Parameters]:
//  out objLotFamily_splitNo_Create_out strLotFamily_splitNo_Create_out;
//
//  typedef struct objLotFamily_splitNo_Create_out_struct {
//      pptRetCode      strResult;
//      string          splitNumber;
//      any siInfo;
//  } objLotFamily_splitNo_Create_out ;
//
//[Return Value]:
//------------------------------   --------------------------------
//   RC_NOT_FOUND_LOTFAMILY        MSG_NOT_FOUND_LOTFAMILY
//   RC_NOT_FOUND_LOT              MSG_NOT_FOUND_LOT
//   RC_REACHED_MAX_SPLIT_COUNT    MSG_REACHED_MAX_SPLIT_COUNT
//
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/09/12 INN-R170001 Vera Chen      Initial release
//
//INN-R170001 CORBA::Long CS_PPTManager_i::lotFamily_splitNo_Create(
CORBA::Long CS_PPTManager_i::lotFamily_splitNo_Create(//INN-R170001
                                objLotFamily_splitNo_Create_out& strLotFamily_splitNo_Create_out,
                                const pptObjCommonIn&                strObjCommonIn,
                                const objectIdentifier&              lotID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lotFamily_splitNo_Create")

        //---------------------------------
        //   Get LotFamily SuffixNumber
        //---------------------------------
        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR(aLot,lotID,strLotFamily_splitNo_Create_out,lotFamily_splitNo_Create);

        LotFamily_var aLotFamily;
        try
        {
           aLotFamily = aLot->getLotFamily();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::getLotFamily);

        PosLotFamily_var aPosLotFamily;
        aPosLotFamily = PosLotFamily::_narrow(aLotFamily);
        if(CORBA::is_nil(aPosLotFamily))
        {
            SET_MSG_RC( strLotFamily_splitNo_Create_out,
                        MSG_NOT_FOUND_LOTFAMILY,
                        RC_NOT_FOUND_LOTFAMILY );
            return RC_NOT_FOUND_LOTFAMILY ;
        }

        CORBA::Long suffix = 0 ;
        try
        {
            suffix = aPosLotFamily->newSplitNumber();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLotFamily::newSplitNumber);

        PPT_METHODTRACE_V2(""," ##### suffix = ", suffix );

        /**********************************************************/
        /*   Keep table.                                          */
        /*   If you want to change SplitSuffix generating rule,   */
        /*   You have to change following definition.             */
        /*                                                        */
        /****** precondition                                      */
        /*  1.Prohibit character is surely alphabet(not number)   */
        /*  2.firstFigure is " 0 to 9 + A to Z"                   */
        /*  3.secondFigure doesn't have alphabet surely.          */
        /**********************************************************/
//INN-R170001        CORBA::Long figureGrade = 10 ;
//INN-R170001        CORBA::Long incrementalGrade = 10 ;
//INN-R170001        char firstFigureTable[]  = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//INN-R170001        char secondFigureTable[] = "0123456789";
        //INN-R170001 Add start
        // Exclude :B,I,O,U,V,Z
        CORBA::Long figureGrade = 30 ;
        CORBA::Long incrementalGrade = 30 ;
        char firstFigureTable[]   = "0123456789ACDEFGHJKLMNPQRSTWXY";
        char secondFigureTable[]  = "0123456789ACDEFGHJKLMNPQRSTWXY";
        //INN-R170001 Add end
        //----------------------------------
        //   Prohibit character check
        //----------------------------------
        char* prohibitChar = getenv(SP_PROHIBIT_CHARACTER);

        for(CORBA::Long j = 0 ; j < CIMFWStrLen(prohibitChar) ; j++)
        {
            CORBA::Long currentFigure = suffix / figureGrade ;
            if( currentFigure < CIMFWStrLen(firstFigureTable))
            {
                PPT_METHODTRACE_V3(""," ##### currentFigure : prohibitChar[j] = ", firstFigureTable[currentFigure], prohibitChar[j]);
                if(firstFigureTable[currentFigure] == prohibitChar[j] )
                {
                    suffix = ((suffix + incrementalGrade) / figureGrade) * figureGrade;
                    j = -1 ;    //P5100179
                }
            }
        }

        PPT_METHODTRACE_V2(""," ##### After Prohibit check : suffix = ", suffix );

        //--------------------------
        //   The first figure.
        //--------------------------
        CORBA::Long firstFigure = suffix / figureGrade ;

        if(firstFigure >= CIMFWStrLen(firstFigureTable))
        {
            SET_MSG_RC( strLotFamily_splitNo_Create_out,
                        MSG_REACHED_MAX_SPLIT_COUNT,
                        RC_REACHED_MAX_SPLIT_COUNT);
            return RC_REACHED_MAX_SPLIT_COUNT;
        }

        PPT_METHODTRACE_V2(""," ##### firstFigure = ", firstFigure) ;

        //--------------------------
        //   The second figure.
        //--------------------------
        CORBA::Long secondFigure = suffix % figureGrade ;

        if(secondFigure >= CIMFWStrLen(secondFigureTable))
        {
            SET_MSG_RC( strLotFamily_splitNo_Create_out,
                        MSG_REACHED_MAX_SPLIT_COUNT,
                        RC_REACHED_MAX_SPLIT_COUNT);
            return RC_REACHED_MAX_SPLIT_COUNT;
        }

        PPT_METHODTRACE_V2(""," ##### secondFigure = ", secondFigure) ;

        //---------------------------
        //   Generate SplitNumber
        //---------------------------
        char buf[3];
        sprintf(buf, "%c%c\0", firstFigureTable[firstFigure],secondFigureTable[secondFigure]) ;
        strLotFamily_splitNo_Create_out.splitNumber = CIMFWStrDup(buf) ;

        PPT_METHODTRACE_V2(""," ##### Created splitNumber = ", strLotFamily_splitNo_Create_out.splitNumber ) ;

        //--------------------------------------------
        //   Set latest split Number to LotFamily
        //--------------------------------------------
        try
        {
            aPosLotFamily->setLastSplitNumber(suffix);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLotFamily::setLastSplitNumber);

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lotFamily_splitNo_Create");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLotFamily_splitNo_Create_out, lotFamily_splitNo_Create, methodName)
}
