#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassetteDelivery_SearchEmptyCassetteAssignPort.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:30:43 [ 7/13/07 19:30:45 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_cassetteDelivery_SearchEmptyCassetteAssignPortOR.cpp
//

#include "cs_pptmgr.hpp"

//[Object Function Name]: long   cs_cassetteDelivery_SearchEmptyCassetteAssignPort
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2001/09/21  D4000184     K.Matsuei      Initial Release.
// 2003/02/18  D4200302     K.Matsuei      Assign EmptyCassette to AnyPort by CassetteDelivery.
//
// Innotron Modification history :
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/09/30 INN-R170002 JJ.Zhang       Contamination Control
//
//[Function Description]:
//
//[Input Parameters]:
//  const pptObjCommonIn&               strObjCommonIn
//  const objectIdentifier&             lotID
//  const pptPortIDSequence&            portIDSeq
//  const pptFoundCassetteSequence&     emptyCassetteSeq
//  const objectIdentifierSequence&     omitCassetteSeq
//  const objectIdentifierSequence&     omitPortIDSeq
//
//[Output Parameters]:
//  out objCassetteDelivery_SearchEmptyCassetteAssignPort_out   strCassetteDelivery_SearchEmptyCassetteAssignPort_out;
//
//  typedef struct objCassetteDelivery_SearchEmptyCassetteAssignPort_out_struct {
//      pptRetCode          strResult;
//      pptPortID           strFoundPort;
//      objectIdentifier    foundEmptyCassetteID;
//  } objCassetteDelivery_SearchEmptyCassetteAssignPort_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_ENOUGH_EMPTYCAST     MSG_NOT_ENOUGH_EMPTYCAST
//
//[Pseudo Code]:
//

//INN-R170002 CORBA::Long PPTManager_i::cassetteDelivery_SearchEmptyCassetteAssignPort(
CORBA::Long CS_PPTManager_i::cs_cassetteDelivery_SearchEmptyCassetteAssignPort(    //INN-R170002
        objCassetteDelivery_SearchEmptyCassetteAssignPort_out&  strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
        const pptObjCommonIn&               strObjCommonIn,
        const objectIdentifier&             lotID,
        const pptPortIDSequence&            portIDSeq,
        const char*                         strReqUsageType,    //INN-R170002
        const pptFoundCassetteSequence&     emptyCassetteSeq,
        const objectIdentifierSequence&     omitCassetteSeq,
        const objectIdentifierSequence&     omitPortIDSeq )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cassetteDelivery_SearchEmptyCassetteAssignPort");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        CORBA::Long i, j, k;


PPT_METHODTRACE_V1("", "// Input Parameter");
PPT_METHODTRACE_V1("", "//*************************************************************************");
PPT_METHODTRACE_V2("", "LotID................................", lotID.identifier);
PPT_METHODTRACE_V2("", "portIDSeq.length()...................", portIDSeq.length());
for (i=0; i < portIDSeq.length(); i++)
{
PPT_METHODTRACE_V2("", "  portID.............................", portIDSeq[i].portID.identifier);
PPT_METHODTRACE_V2("", "  loadSequenceNoInPortGroup..........", portIDSeq[i].loadSequenceNoInPortGroup);
PPT_METHODTRACE_V2("", "  loadPurposeType....................", portIDSeq[i].loadPurposeType);
PPT_METHODTRACE_V2("", "  portState..........................", portIDSeq[i].portState);
PPT_METHODTRACE_V2("", "  categoryCapability.length()........", portIDSeq[i].categoryCapability.length());
for (j=0; j < portIDSeq[i].categoryCapability.length(); j++)
{
PPT_METHODTRACE_V3("", "    categoryCapability[j]............", j, portIDSeq[i].categoryCapability[j]);
}
}
PPT_METHODTRACE_V2("", "emptyCassetteSeq.length()............", emptyCassetteSeq.length());
PPT_METHODTRACE_V2("", "omitCassetteSeq.length().............", omitCassetteSeq.length());
for (i=0; i < omitCassetteSeq.length(); i++)
{
PPT_METHODTRACE_V3("", "  CassetteID[i]......................", i, omitCassetteSeq[i].identifier);
}
PPT_METHODTRACE_V2("", "omitPortIDSeq.length()...............", omitPortIDSeq.length());
for (i=0; i < omitPortIDSeq.length(); i++)
{
PPT_METHODTRACE_V3("", "  PortID[i]..........................", i, omitPortIDSeq[i].identifier);
}
PPT_METHODTRACE_V1("", "//*************************************************************************");



        /**********************************************************************************/
        /*                                                                                */
        /*   Acquire CassetteCategory if there is designation of Lot                      */
        /*                                                                                */
        /**********************************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Acquire CassetteCategory if there is designation of Lot");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        CORBA::String_var limitCategory;
        if ( 0 < CIMFWStrLen(lotID.identifier) )
        {
            /*----------------------------------------------------------*/
            /*   Get EmptyCassette which should be necessary Lot next   */
            /*----------------------------------------------------------*/
            PPT_METHODTRACE_V1("", "/*------------------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   lot_requiredCassetteCategory_GetForNextOperation   */");
            PPT_METHODTRACE_V1("", "/*------------------------------------------------------*/");
            objLot_requiredCassetteCategory_GetForNextOperation_out strLot_requiredCassetteCategory_GetForNextOperation_out;
            rc = lot_requiredCassetteCategory_GetForNextOperation(
                            strLot_requiredCassetteCategory_GetForNextOperation_out,
                            strObjCommonIn,
                            lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_requiredCassetteCategory_GetForNextOperation() rc != RC_OK");
                strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strResult = strLot_requiredCassetteCategory_GetForNextOperation_out.strResult;
                return( rc );
            }

            limitCategory = CIMFWStrDup( strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory );
            PPT_METHODTRACE_V2("", "limitCategory----->", limitCategory);
        }
        else
        {
            PPT_METHODTRACE_V1("", "No Check Limit Category");
        }


        /**********************************************************************************/
        /*                                                                                */
        /*   Look for EmptyCassette that LoadPurposeType is suitable for EmptyCassette    */
        /*                                                                                */
        /**********************************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Look for EmptyCassette that LoadPurposeType is suitable for EmptyCassette");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        CORBA::Boolean bFoundAssignPort = FALSE;
        CORBA::Long lenPortID = portIDSeq.length();
        CORBA::Long lenOmitCassette = omitCassetteSeq.length();
        CORBA::Long lenOmitPort = omitPortIDSeq.length();

        CORBA::Long lenEmptyCassette = emptyCassetteSeq.length();
        PPT_METHODTRACE_V2("", "emptyCassetteSeq.lenght", lenEmptyCassette);
        for ( i=0; i < lenEmptyCassette; i++ )
        {
            PPT_METHODTRACE_V2("", "--------------------------------round[i]", i);
            PPT_METHODTRACE_V2("", "  EmptyCassetteID----->", emptyCassetteSeq[i].cassetteID.identifier);
            PPT_METHODTRACE_V2("", "  cassetteCategory---->", emptyCassetteSeq[i].cassetteCategory);

            /*------------------------------------*/
            /*   Omit Cassette of limitCategory   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1("", "Omit Cassette of limitCategory");
            if ( 0 < CIMFWStrLen(limitCategory) && 0 != CIMFWStrCmp(limitCategory, emptyCassetteSeq[i].cassetteCategory) )
            {
                PPT_METHODTRACE_V1("", "Omit Cassette of limitCategory   ...<<continue>>");
                continue; //[i]
            }
//INN-R170002 Add Start
            if ( 0 < CIMFWStrLen(strReqUsageType) )
            {
                csFoundCassette_siInfo* strFoundCassette_siInfo;
                if( emptyCassetteSeq[i].siInfo >>= strFoundCassette_siInfo )
                {
                    PPT_METHODTRACE_V2("", "strReqUsageType", strReqUsageType);
                    if( 0 < CIMFWStrLen(strFoundCassette_siInfo->usageType) && 0 != CIMFWStrCmp(strReqUsageType, strFoundCassette_siInfo->usageType) )
                    {
                        PPT_METHODTRACE_V2("", "strFoundCassette_siInfo.usageType not matched", strFoundCassette_siInfo->usageType);
                        continue; //[i]
                    }
                }
            }
//INN-R170002 Add End

            /*--------------------------------------*/
            /*   Omit Cassette of omitCassetteSeq   */
            /*--------------------------------------*/
            PPT_METHODTRACE_V1("", "Omit Cassette of omitCassetteSeq");
            CORBA::Boolean bOmitCassette = FALSE;
            for ( j=0; j < lenOmitCassette; j++ )
            {
                if ( 0 == CIMFWStrLen(omitCassetteSeq[j].identifier) )
                {
                    continue; //[j]
                }

                if ( 0 == CIMFWStrCmp(omitCassetteSeq[j].identifier, emptyCassetteSeq[i].cassetteID.identifier) )
                {
                    bOmitCassette = TRUE;
                    break; //[j]
                }
            } //end of [j]
            if ( TRUE == bOmitCassette )
            {
                PPT_METHODTRACE_V1("", "Omit Cassette of omitCassetteSeq   ...<<continue>>");
                continue; //[i]
            }

            /*---------------------------------------------------------------------------------------------------------*/
            /*   Look for Port which categoryCapability of Port and CassetteCategory of EmptyCassttte corresponds to   */
            /*---------------------------------------------------------------------------------------------------------*/
            PPT_METHODTRACE_V1("", "Look for Port which categoryCapability of Port and CassetteCategory of EmptyCassttte corresponds to");
            for ( j=0; j < lenPortID; j++ )
            {
                PPT_METHODTRACE_V2("", "----------------------------------round[j]", j);
                PPT_METHODTRACE_V2("", "  portID------------>", portIDSeq[j].portID.identifier);
                PPT_METHODTRACE_V2("", "  loadPurposeType--->", portIDSeq[j].loadPurposeType);

                /*--------------------------------*/
                /*   Omit Port of omitPortIDSeq   */
                /*--------------------------------*/
                PPT_METHODTRACE_V1("", "Omit Port of omitPortIDSeq");
                CORBA::Boolean bOmitPort = FALSE;
                for ( k=0; k < lenOmitPort; k++ )
                {
                    if ( 0 == CIMFWStrLen(portIDSeq[j].portID.identifier) )
                    {
                        continue; //[k]
                    }

                    if ( 0 == CIMFWStrCmp(portIDSeq[j].portID.identifier, omitPortIDSeq[k].identifier) )
                    {
                        bOmitPort = TRUE;
                        break; //[k]
                    }
                } //end of [k]
                if ( TRUE == bOmitPort )
                {
                    PPT_METHODTRACE_V1("", "Omit Port of omitPortIDSeq   ...<<continue>>");
                    continue; //[j]
                }

                /*------------------------------------------------*/
                /*   Omit Port LoadPurposeType is EmptyCassette   */
                /*------------------------------------------------*/
                PPT_METHODTRACE_V1("", "Omit Port LoadPurposeType is EmptyCassette");
                if ( 0 != CIMFWStrCmp(portIDSeq[j].loadPurposeType, SP_LoadPurposeType_EmptyCassette)
                  && 0 != CIMFWStrCmp(portIDSeq[j].loadPurposeType, SP_LoadPurposeType_Any)  //D4200302
                  && 0 != CIMFWStrCmp(portIDSeq[j].loadPurposeType, SP_LoadPurposeType_InternalBuffer) )
                {
//D4200302                    PPT_METHODTRACE_V1("", "Omit Port LoadPurposeType is not [EmptyCassette] and [InternalBuffer]   ...<<continue>>");
                    PPT_METHODTRACE_V1("", "Omit Port LoadPurposeType is not [EmptyCassette] and [InternalBuffer] and [Any]   ...<<continue>>");  //D4200302
                    continue; //[j]
                }

                /*------------------------------------------------*/
                /*   Look for Port of the same cassetteCategory   */
                /*------------------------------------------------*/
                PPT_METHODTRACE_V1("", "Look for Port of the same cassetteCategory");
                CORBA::Long lenCategoryCapability = portIDSeq[j].categoryCapability.length();
                PPT_METHODTRACE_V2("","portIDSeq[j].categoryCapability.length", lenCategoryCapability);
                if ( 0 < lenCategoryCapability )
                {
                    for ( k=0; k < lenCategoryCapability; k++ )
                    {
                        if ( 0 == CIMFWStrCmp(portIDSeq[j].categoryCapability[k], emptyCassetteSeq[i].cassetteCategory) )
                        {
                            PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                            PPT_METHODTRACE_V1("", "Found!! Good Condition Port and EmptyCasstte!!");
                            PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                            PPT_METHODTRACE_V2("", "  PortID------------>", portIDSeq[j].portID.identifier);
                            PPT_METHODTRACE_V2("", "  EmptyCassetteID--->", emptyCassetteSeq[i].cassetteID.identifier);
                            strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort = portIDSeq[j];
                            strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID = emptyCassetteSeq[i].cassetteID;
                            bFoundAssignPort = TRUE;
                            break; //[k]
                        }
                    }
                }
                else
                {
                    // Assign EmptyCassttte found first because it doesn't have categoryCapability
                    PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    PPT_METHODTRACE_V1("", "Assign EmptyCassttte found first because it doesn't have categoryCapability");
                    PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    PPT_METHODTRACE_V2("", "  PortID------------>", portIDSeq[j].portID.identifier);
                    PPT_METHODTRACE_V2("", "  EmptyCassetteID--->", emptyCassetteSeq[i].cassetteID.identifier);
                    strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort = portIDSeq[j];
                    strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID = emptyCassetteSeq[i].cassetteID;
                    bFoundAssignPort = TRUE;
                }

                if ( TRUE == bFoundAssignPort )
                {
                    PPT_METHODTRACE_V1("", "break; [j]");
                    break; //[j]
                }
            } //end of [j]

            if ( TRUE == bFoundAssignPort )
            {
                PPT_METHODTRACE_V1("", "break; [i]");
                break; //[i]
            }
        } //end of [i]


        PPT_METHODTRACE_V1("", "Check Normal End ???");
        if ( FALSE == bFoundAssignPort )
        {
            PPT_METHODTRACE_V1("","##### return RC_NOT_ENOUGH_EMPTYCAST!!");
            SET_MSG_RC( strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
                        MSG_NOT_ENOUGH_EMPTYCAST,
                        RC_NOT_ENOUGH_EMPTYCAST );
            return RC_NOT_ENOUGH_EMPTYCAST;
        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassetteDelivery_SearchEmptyCassetteAssignPort");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassetteDelivery_SearchEmptyCassetteAssignPort_out, cassetteDelivery_SearchEmptyCassetteAssignPort, methodName)
}
