//
// (c) Copyright: IBM Services Company Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// Name: cs_eqpMonitorLot_prepareIDSet.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "pemon.hh"
#include "pcas.hh"

// Class: CS_PPTManager
//
// Service: cs_eqpMonitorLot_prepareIDSet()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/27 INN-R170016 JJ.Zhang       Initial Release
//
//[Function Description]
//  set same prepare ID for all monitor lot
//
//[Input Parameters]
//  const pptObjCommonIn&             strObjCommonIn
//  const csObjEqpMonitorLot_prepareIDSet_in&  strEqpMonitorLot_prepareIDSet_in
//
//  typedef struct csObjEqpMonitorLot_prepareIDSset_in_struct
//  {
//    objectIdentifier          eqpMonitorID;
//    objectIdentifier          carrierID;
//    objectIdentifierSequence  lotIDs;
//      any              siInfo;
//  }csObjEqpMonitorLot_prepareIDSet_in;
//
//[Output Parameters]
//  csObjEqpMonitorLot_prepareIDSet_out&   strEqpMonitorLot_prepareIDSet_out
//
//  typedef objBase_out csObjEqpMonitorLot_prepareIDSet_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//

CORBA::Long CS_PPTManager_i::cs_eqpMonitorLot_prepareIDSet (
    csObjEqpMonitorLot_prepareIDSet_out& strEqpMonitorLot_prepareIDSet_out,
    const pptObjCommonIn&                strObjCommonIn,
    const csObjEqpMonitorLot_prepareIDSet_in&  strEqpMonitorLot_prepareIDSet_in  )
{
    char* methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cs_eqpMonitorLot_prepareIDSet");

        //-----------------------------------------
        //  Initialize
        //-----------------------------------------
        CORBA::Long rc = RC_OK;
        CORBA::ULong i = 0;

        //----------------------------------------------
        // Lock EqpMonitor object
        //----------------------------------------------
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, strEqpMonitorLot_prepareIDSet_in.eqpMonitorID, SP_ClassName_PosEqpMonitor );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strEqpMonitorLot_prepareIDSet_out.strResult = strObject_Lock_out.strResult;
            return rc;
        }

        //----------------------------------------------
        // Generate new monitor prepare ID
        //----------------------------------------------
        PosEqpMonitor_var aPosEqpMonitor;
        PPT_CONVERT_EQPMONITORID_TO_EQPMONITOR_OR( aPosEqpMonitor,
                                                   strEqpMonitorLot_prepareIDSet_in.eqpMonitorID,
                                                   strEqpMonitorLot_prepareIDSet_out,
                                                   cs_eqpMonitorLot_prepareIDSet );
        CORBA::String_var strDate;
        SI_PPT_USERDATA_GET_STRING( aPosEqpMonitor, CS_M_EQPM_LastPrepDate, strDate );
        PPT_METHODTRACE_V2("", "CS_M_EQPM_LastPrepDate", strDate);

        //Get date today ex:20171031
        struct timeb t;
        t.time = time(0);
        struct tm  currentTime;
        localtime_r( &t.time, &currentTime );

        char workbuf[128];
        memset(workbuf,'\0', sizeof(workbuf));
        sprintf( workbuf, "%04d%02d%02d", // YYYYMMDD
                        currentTime.tm_year + 1900,
                        currentTime.tm_mon + 1,
                        currentTime.tm_mday );

        CORBA::Long seqNo = 1;
        CORBA::String_var strSeqNo;
        if( 0 == CIMFWStrCmp(strDate, workbuf) )
        {
            SI_PPT_USERDATA_GET_STRING( aPosEqpMonitor, CS_M_EQPM_LastPrepSeqNo, strSeqNo );
            PPT_METHODTRACE_V2("", "CS_M_EQPM_LastPrepSeqNo", strSeqNo);
            seqNo= atol(strSeqNo) + 1;
        }
        else
        {
            strDate = CIMFWStrDup(workbuf);
            SI_PPT_USERDATA_SET_STRING( aPosEqpMonitor, CS_M_EQPM_LastPrepDate, strDate );
            seqNo = 1;
        }

        sprintf(workbuf, "%02ld", seqNo);
        strSeqNo = CIMFWStrDup(workbuf);
        SI_PPT_USERDATA_SET_STRING( aPosEqpMonitor, CS_M_EQPM_LastPrepSeqNo, strSeqNo );

        //ex: EQPMON01-20171031-01
        CORBA::String_var strPrepareID;
        sprintf(workbuf, "%s-%s-%02ld", (const char*)strEqpMonitorLot_prepareIDSet_in.eqpMonitorID.identifier, (const char*)strDate, seqNo);
        strPrepareID = CIMFWStrDup(workbuf);
        PPT_METHODTRACE_V2("", "strPrepareID", strPrepareID);

        //----------------------------------------------
        // Set prepareID in udata for all lots
        //----------------------------------------------
        PPT_METHODTRACE_V2("", "get Cassette object", strEqpMonitorLot_prepareIDSet_in.carrierID.identifier );
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                           strEqpMonitorLot_prepareIDSet_in.carrierID,
                                           strEqpMonitorLot_prepareIDSet_out,
                                           cs_eqpMonitorLot_prepareIDSet );

        LotSequence* aLotSequence = NULL;
        LotSequence_var aTmpSeq;
        try
        {
            aLotSequence = aCassette->allLots();
            aTmpSeq = aLotSequence;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

        CORBA::Long nLotLen = aLotSequence->length();
        PPT_METHODTRACE_V2("", "aLotSequence->length()",nLotLen);

        for( i =0; i<nLotLen; i++)
        {
            PPT_METHODTRACE_V2("", "set PrePID for",i);

            PosLot_var aPosLot;
            aPosLot = PosLot::_narrow((*aLotSequence)[i]);

            if(CORBA::is_nil(aPosLot))
            {
                PPT_SET_MSG_RC_KEY( strEqpMonitorLot_prepareIDSet_out,
                                    MSG_NOT_FOUND_LOT,
                                    RC_NOT_FOUND_LOT, "****" );
                return RC_NOT_FOUND_LOT ;
            }
            SI_PPT_USERDATA_SET_STRING( aPosLot, CS_M_LOT_Monitor_PrepID, strPrepareID );
        }

        //----------------------------------------
        //  Return to caller
        //----------------------------------------		
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_eqpMonitorLot_prepareIDSet");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strEqpMonitorLot_prepareIDSet_out, cs_eqpMonitorLot_prepareIDSet, methodName );
}
