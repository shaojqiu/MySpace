//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: lot_previousOperation_DataCollectionInformation_Get.cpp
//

//INN-R170009 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"   //INN-R170009
#include "plot.hh"
#include "ppcope.hh"
#include "pctrlj.hh"

//[Object Function Name]: long   lot_previousOperation_DataCollectionInformation_Get
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/02 DSIV00000201 M.Ishino       Improvement of Post-Processing.
// 2009/11/26 DSIV00001471 F.Chen         Collected Data Value validation check
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2017/02/13 DSN000104277 K.Yamaoku      Performance improvement(reference:lot_wafers_GetDR)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/11/01 INN-R170009  Qufd           Add APC Queue
//
//[Function Description]:
//
//  This object function fill the return structure's value by accessing DataCollectionInformation
//  and related objects.
//
//  typedef struct pptStartCassette_struct {
//      long                          loadSequenceNumber;           <== This information is not set.
//      objectIdentifier              cassetteID;                   <== This information is not set.
//      string                        loadPurposeType;              <== This information is not set.
//      objectIdentifier              loadPortID;                   <== This information is not set.
//      objectIdentifier              unloadPortID;                 <== This information is not set.
//      sequence <pptLotInCassette>   strLotInCassette;
//  } pptStartLot;
//
//  typedef struct pptLotInCassette_struct
//      boolean                       operationStartFlag;           <== As for a value, "TRUE" is always set. 
//      boolean                       monitorLotFlag;               <== This information is not set.
//      objectIdentifier              lotID;
//      string                        lotType;
//      string                        subLotType;
//      pptStartRecipe                strStartRecipe;
//      string                        recipeParameterChangeType;
//      sequence <pptLotWafer>        strLotWafer;
//  } pptLotInCassette;
//
//  typedef struct pptLotWafer_struct {
//      objectIdentifier              waferID;
//      long                          slotNumber;
//      boolean                       controlWaferFlag;
//      sequence <pptStartRecipeParameter> strStartRecipeParameter;
//  } pptLotWafer;
//
//  typedef struct pptStartRecipeParameter_struct {
//      string                        parameterName;
//      string                        parameterValue;
//      string                        targetValue;
//      boolean                       useCurrentSettingValueFlag;
//  } pptStartRecipeParameter;
//
//  typedef struct pptStartRecipe_struct {
//      objectIdentifier              logicalRecipeID;
//      objectIdentifier              machineRecipeID;
//      string                        physicalRecipeID;
//      sequence <pptStartReticle>    strStartReticle;
//      sequence <pptStartFixture>    strStartFixture;
//      boolean                       dataCollectioinFlag;
//      sequence <pptDCDef>           strDCDef;
//  } pptStartRecipe;
//
//  typedef struct pptStartReticle_struct {
//     long                           sequenceNumber;
//     objectIdentifier               reticleID;
//  } pptStartReticle;
//
//  typedef struct pptStartFixture_struct {
//     objectIdentifier               fixtureID;
//     string                         fixtureCategory;
//  } pptStartFixture;
//
//  typedef struct pptDCDef_struct {
//      objectIdentifier              dataCollectionDefinitionID;
//      string                        description;
//      string                        dataCollectionType;
//      sequence <pptDCItem>          strDCItem;
//      boolean                       calculationRequiredFlag;
//      boolean                       specCheckRequiredFlag;
//      objectIdentifier              dataCollectionSpecificationID;
//      objectIdentifier              previousDataCollectionDefinitionID;
//      objectIdentifier              previousOperationID;
//      string                        previousOperationNumber;
//  } pptDCDef;
//
//  typedef struct pptDCItem_struct {
//      string                        dataCollectionItemName;
//      string                        dataCollectionMode;
//      string                        dataCollectionUnit;
//      string                        dataType;
//      string                        itemType;
//      string                        measurementType;
//      objectIdentifier              waferID;
//      string                        waferPosition;
//      string                        sitePosition;
//      boolean                       historyRequiredFlag;
//      string                        calculationType;
//      string                        calculationExpression;
//      string                        dataValue;
//      string                        targetValue;
//      string                        specCheckResult;
//      stringSequence                actionCode;
//  } pptDCItem;
//
//
//[Input Parameters]:
//  in  pptObjCommonIn                                              strObjCommonIn;
//  in  objLot_previousOperation_DataCollectionInformation_Get_in   strLot_previousOperation_DataCollectionInformation_Get_in;
//
//  typedef struct objLot_previousOperation_DataCollectionInformation_Get_in_struct {
//      objectIdentifier          equipmentID;
//      objectIdentifierSequence  lotIDs;
//      any siInfo;
//  } objLot_previousOperation_DataCollectionInformation_Get_in;
//
//
//[Output Parameters]:
//  out objLot_previousOperation_DataCollectionInformation_Get_out  strLot_previousOperation_DataCollectionInformation_Get_out;
//
//  typedef struct objLot_previousOperation_DataCollectionInformation_Get_out_struct {
//      pptRetCode                strResult;
//      objectIdentifier          equipmentID;
//      pptStartCassetteSequence  strStartCassette;
//      any siInfo;
//  } objLot_previousOperation_DataCollectionInformation_Get_out;
//
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_PO             MSG_NOT_FOUND_PO
//  RC_NOT_FOUND_LOT            MSG_NOT_FOUND_LOT
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//  RC_NOT_FOUND_MCRECIPE       MSG_NOT_FOUND_MCRECIPE
//  RC_NOT_FOUND_LCRECIPE       MSG_NOT_FOUND_LCRECIPE
//  RC_NOT_FOUND_RETICLE        MSG_NOT_FOUND_RETICLE
//  RC_NOT_FOUND_FIXTURE        MSG_NOT_FOUND_FIXTURE
//  RC_NOT_FOUND_DCDEF          MSG_NOT_FOUND_DCDEF
//  RC_NOT_FOUND_PROCGRP        MSG_NOT_FOUND_PROCGRP



//INN-R170009 CORBA::Long CS_PPTManager_i::lot_previousOperation_DataCollectionInformation_Get(
CORBA::Long CS_PPTManager_i::lot_previousOperation_DataCollectionInformation_Get(
    objLot_previousOperation_DataCollectionInformation_Get_out&      strLot_previousOperation_DataCollectionInformation_Get_out,
    const pptObjCommonIn&                                            strObjCommonIn,
    const objLot_previousOperation_DataCollectionInformation_Get_in& strLot_previousOperation_DataCollectionInformation_Get_in)
{
    char * methodName = NULL;
    try
    {
        //INN-R170009 PPT_METHODTRACE_ENTRY("PPTManager_i::lot_previousOperation_DataCollectionInformation_Get");
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_previousOperation_DataCollectionInformation_Get"); //INN-R170009

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*----------------------------------------------*/
        /*   Set Return Structure                       */
        /*----------------------------------------------*/
        // Start Cassette Length
        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette.length(1);
 
        // Equipment ID
        strLot_previousOperation_DataCollectionInformation_Get_out.equipmentID
            = strLot_previousOperation_DataCollectionInformation_Get_in.equipmentID;
 
        //--------------------------------------------------
        // Set target Items.
        //--------------------------------------------------
        objectIdentifierSequence lotIDs = strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs ;
 
        // Lot In Cassette Length
        CORBA::Long lotLen;
        lotLen = lotIDs.length();
        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette.length(lotLen);
 
        
        /*-------------------------*/
        /*   Set Lot Information   */
        /*-------------------------*/
        for (CORBA::Long j=0 ; j<lotLen ; j++)
        {
            PPT_METHODTRACE_V3("", "loop to (*startCassetteInfoSeq)[0].lotInCassetteInfo.length()",lotLen,j);
            PPT_METHODTRACE_V2( "","lotID", lotIDs[j].identifier);
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].operationStartFlag = TRUE;
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].lotID              = lotIDs[j];
 
            /*--------------------*/
            /*   Get Wafer Info   */
            /*--------------------*/
//DSN000104277//DSN000085698            objLot_wafers_GetDR_out strLot_wafers_GetDR_out;
//DSN000104277            objLot_wafers_GetDR_out__150 strLot_wafers_GetDR_out;    //DSN000085698
//DSN000104277            objLot_wafers_GetDR_in  strInParm ;
//DSN000104277            strInParm.lotID          = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].lotID;
//DSN000104277            strInParm.scrapCheckFlag = TRUE;   //omit scrapped wafer
//DSN000104277 
//DSN000104277//DSN000085698            rc = lot_wafers_GetDR(strLot_wafers_GetDR_out,strObjCommonIn,strInParm);
//DSN000104277            rc = lot_wafers_GetDR__150(strLot_wafers_GetDR_out,strObjCommonIn,strInParm);    //DSN000085698
//DSN000104277            if(rc != RC_OK)
//DSN000104277            {
//DSN000104277//DSN000085698                PPT_METHODTRACE_V1("", "lot_wafers_GetDR() != RC_OK");
//DSN000104277                PPT_METHODTRACE_V1("", "lot_wafers_GetDR__150() != RC_OK");  //DSN000085698
//DSN000104277                strLot_previousOperation_DataCollectionInformation_Get_out.strResult = strLot_wafers_GetDR_out.strResult;
//DSN000104277                return(rc);
//DSN000104277            }
//DSN000104277 add start
            objLot_waferInfoList_GetDR_out strLot_waferInfoList_GetDR_out;
            objLot_waferInfoList_GetDR_in  strLot_waferInfoList_GetDR_in;
            strLot_waferInfoList_GetDR_in.lotID          = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].lotID;
            strLot_waferInfoList_GetDR_in.scrapCheckFlag = TRUE; //omit scrapped wafer
            rc = lot_waferInfoList_GetDR( strLot_waferInfoList_GetDR_out, strObjCommonIn, strLot_waferInfoList_GetDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### lot_waferInfoList_GetDR() != RC_OK", rc);
                strLot_previousOperation_DataCollectionInformation_Get_out.strResult = strLot_waferInfoList_GetDR_out.strResult;
                return( rc );
            }
//DSN000104277 add end

            CORBA::Long wfrLen;
//DSN000104277            wfrLen = strLot_wafers_GetDR_out.strLotWaferAttributes.length();
            wfrLen = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes.length(); //DSN000104277
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer.length(wfrLen);
 
            if ( wfrLen > 0 )
            {
                for (CORBA::Long w=0 ; w<wfrLen ; w++ )
                {
//DSN000104277                    PPT_METHODTRACE_V3("", "loop to strLot_wafers_GetDR_out.strLotWaferAttributes.length()",wfrLen,w);
//DSN000104277                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].waferID          = strLot_wafers_GetDR_out.strLotWaferAttributes[w].waferID;
//DSN000104277                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].slotNumber       = strLot_wafers_GetDR_out.strLotWaferAttributes[w].slotNumber;
//DSN000104277                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].controlWaferFlag = strLot_wafers_GetDR_out.strLotWaferAttributes[w].controlWaferFlag;
//DSN000104277 add start
                    PPT_METHODTRACE_V3("", "loop to strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes.length()",wfrLen,w);
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].waferID          = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[w].waferID;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].slotNumber       = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[w].slotNumber;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].controlWaferFlag = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[w].controlWaferFlag;
//DSN000104277 add end
                }

                /*------------------------------------------*/
                /*   Get ProductID from LotWaferAttributs   */
                /*------------------------------------------*/
                PPT_METHODTRACE_V1("", "Set ProductID");
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].productID
//DSN000104277                                                = strLot_wafers_GetDR_out.strLotWaferAttributes[0].productID;
                                                = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[0].productID; //DSN000104277
 
                PPT_METHODTRACE_V2( "",
                                    "ProductID",
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].productID.identifier);
            }
 
            /*--------------------------*/
            /*   Get Lot Related Info   */
            /*--------------------------*/
            PosLot_var aLot;
            PPT_CONVERT_LOTID_TO_LOT_OR(aLot, 
                                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].lotID,
                                        strLot_previousOperation_DataCollectionInformation_Get_out,
                                        lot_previousOperation_DataCollectionInformation_Get);
 
            ProcessOperation_var aPO;
            PosProcessOperation_var aPosPO;
 
            //--------------------------------------------------------------------------
            // Get PO from Previous Operation.
            //--------------------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Get PO from the previous Operation.")
 
            try
            {
                aPO = aLot->getPreviousProcessOperation();
                aPosPO = PosProcessOperation::_narrow(aPO);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getPreviousProcessOperation);
 
            if ( CORBA::is_nil(aPosPO) )
            {
                PPT_SET_MSG_RC_KEY2( strLot_previousOperation_DataCollectionInformation_Get_out,
                                     MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO,
                                     "", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].lotID.identifier );
                return( RC_NOT_FOUND_PO );
            }
 
            posActualStartInformationForPO_var actualStartInfo;
            try
            {
                actualStartInfo = aPosPO->getActualStartInfo();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getActualStartInfo);
 
            /*===== set Lot Info =====*/
            try
            {
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].lotType = aLot->getLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType);
            try
            {
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].subLotType = aLot->getSubLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
 
            /*===== set Recipe Info =====*/
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].recipeParameterChangeType         = actualStartInfo->assignedRecipeParameterChangeType;
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID    = actualStartInfo->assignedLogicalRecipe;
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID    = actualStartInfo->assignedMachineRecipe;
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.physicalRecipeID   = actualStartInfo->assignedPhysicalRecipe;
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.dataCollectionFlag = actualStartInfo->assignedDataCollectionFlag;
 
            /*===== set Reticle Info =====*/
            CORBA::Long rtclLen;
            rtclLen = actualStartInfo->assignedReticles.length();
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strStartReticle.length(rtclLen);
 
            for (CORBA::Long rr=0 ; rr<rtclLen ; rr++)
            {
                PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedReticles.length()",rtclLen,rr);
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strStartReticle[rr].sequenceNumber = actualStartInfo->assignedReticles[rr].sequenceNumber;
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strStartReticle[rr].reticleID      = actualStartInfo->assignedReticles[rr].reticleID;
            }
 
            /*===== set Fixture Info =====*/
            CORBA::Long fixtLen;
            fixtLen = actualStartInfo->assignedFixtures.length();
            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strStartFixture.length(fixtLen);
 
            for (CORBA::Long ff=0 ; ff<fixtLen ; ff++)
            {
                PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedFixtures.length()",fixtLen,ff);
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strStartFixture[ff].fixtureID       = actualStartInfo->assignedFixtures[ff].fixtureID;
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strStartFixture[ff].fixtureCategory = actualStartInfo->assignedFixtures[ff].fixtureCategory;
            }
 
            /*===== set Recipe Parameter Info =====*/
            CORBA::Long rpsetLen;
            rpsetLen = actualStartInfo->assignedRecipeParameterSets.length();
 
            CORBA::Long rparmLen;
 
            if ( rpsetLen == 1 )
            {
                PPT_METHODTRACE_V1("", "rpsetLen == 1");
                rparmLen = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length();
                PPT_METHODTRACE_V2("", "actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length--->", rparmLen);
 
                if ( rparmLen == 1 )
                {
                    PPT_METHODTRACE_V1("", "rparmLen == 1");
 
                    if ( CIMFWStrLen(actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[0].parameterName ) == 0 &&
                         CIMFWStrLen(actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[0].parameterValue) == 0 &&
                         CIMFWStrLen(actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[0].targetValue   ) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "set rpsetLen = 0");
                        rpsetLen = 0;
                    }
                }
            }
 
            if (rpsetLen > 0)
            {
                PPT_METHODTRACE_V1("", "actualStartInfo->assignedRecipeParameterSets.length() > 0");
                rparmLen = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length();
 
               for (CORBA::Long w=0 ; w<wfrLen ; w++)
               {
//DSN000104277                    PPT_METHODTRACE_V3("", "loop to strLot_wafers_GetDR_out.strLotWaferAttributes.length()",wfrLen,w);
                    PPT_METHODTRACE_V3("", "loop to strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes.length()",wfrLen,w); //DSN000104277
                    if (CIMFWStrCmp(actualStartInfo->assignedRecipeParameterChangeType,SP_Rparm_ChangeType_ByLot) == 0)
                    {
                        PPT_METHODTRACE_V1("", "actualStartInfo->recipeParameterChangeType == SP_Rparm_ChangeType_ByLot");
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter.length(rparmLen);
                        for (CORBA::Long rp=0 ; rp<rparmLen ; rp++ )
                        {
                            PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length()",rparmLen,rp);
                            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].parameterName              
                                    = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[rp].parameterName;
                            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].parameterValue             
                                    = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[rp].parameterValue;
                            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].targetValue                
                                    = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[rp].targetValue;
                            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].useCurrentSettingValueFlag 
                                    = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[rp].useCurrentSettingValueFlag;
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "actualStartInfo->recipeParameterChangeType != SP_Rparm_ChangeType_ByLot");
                        for (CORBA::Long rs=0 ; rs<rpsetLen ; rs++ )
                        {
                            PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedRecipeParameterSets.length()",rpsetLen,rs);
                            if (CIMFWStrCmp(strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].waferID.identifier,
                                            actualStartInfo->assignedRecipeParameterSets[rs].applyWafers[0].waferID.identifier) == 0)
                            {
                                PPT_METHODTRACE_V1("", "strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].waferID.identifier == actualStartInfo->assignedRecipeParameterSets[rs].applyWafers[0].waferID");
                                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter.length(rparmLen);
                                for (CORBA::Long rp=0 ; rp<rparmLen ; rp++ )
                                {
                                    PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length()",rparmLen,rp);
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].parameterName              
                                            = actualStartInfo->assignedRecipeParameterSets[rs].recipeParameters[rp].parameterName;
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].parameterValue             
                                            = actualStartInfo->assignedRecipeParameterSets[rs].recipeParameters[rp].parameterValue;
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].targetValue                
                                            = actualStartInfo->assignedRecipeParameterSets[rs].recipeParameters[rp].targetValue;
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].useCurrentSettingValueFlag 
                                            = actualStartInfo->assignedRecipeParameterSets[rs].recipeParameters[rp].useCurrentSettingValueFlag;
                                }
                                break;
                            }
                        }
                    }
                }
            }
 
            /*===== set Data Collection Info =====*/
            if (actualStartInfo->assignedDataCollectionFlag == TRUE)
            {
                PPT_METHODTRACE_V1("", "actualStartInfo->assignedDataCollectionFlag == TRUE");
                CORBA::Long dcLen;
                dcLen = actualStartInfo->assignedDataCollections.length();
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef.length(dcLen);
 
                for (CORBA::Long dc=0 ; dc<dcLen ; dc++)
                {
                    PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedDataCollections.length()",dcLen,dc);
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].dataCollectionDefinitionID         
                                = actualStartInfo->assignedDataCollections[dc].dataCollectionDefinitionID;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].description                        
                                = actualStartInfo->assignedDataCollections[dc].description;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].dataCollectionType                 
                                = actualStartInfo->assignedDataCollections[dc].dataCollectionType;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].calculationRequiredFlag            
                                = actualStartInfo->assignedDataCollections[dc].calculationRequiredFlag;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].specCheckRequiredFlag              
                                = actualStartInfo->assignedDataCollections[dc].specCheckRequiredFlag;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].dataCollectionSpecificationID      
                                = actualStartInfo->assignedDataCollections[dc].dataCollectionSpecificationID;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].dcSpecDescription                  
                                = actualStartInfo->assignedDataCollections[dc].dcSpecDescription;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].previousDataCollectionDefinitionID 
                                = actualStartInfo->assignedDataCollections[dc].previousDataCollectionDefinitionID;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].previousOperationID                
                                = actualStartInfo->assignedDataCollections[dc].previousOperationID;
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].previousOperationNumber            
                                = actualStartInfo->assignedDataCollections[dc].previousOperationNumber;
 
                    CORBA::Long itemLen;
                    itemLen = actualStartInfo->assignedDataCollections[dc].dcItems.length();
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem.length(itemLen);
 
                    for (CORBA::Long it=0 ; it<itemLen ; it++)
                    {
                        PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedDataCollections[dc].dcItems.length()",itemLen,it);
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataCollectionItemName 
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataCollectionItemName;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataCollectionMode     
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataCollectionMode;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataCollectionUnit     
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataCollectionUnit;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataType               
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataType;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].itemType               
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].itemType;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].measurementType        
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].measurementType;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].waferID                
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].waferID;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].waferPosition          
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].waferPosition;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].sitePosition           
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].sitePosition;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].historyRequiredFlag    
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].historyRequiredFlag;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].calculationType        
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].calculationType;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].calculationExpression  
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].calculationExpression;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataValue              
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataValue;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].targetValue            
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].targetValue;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].specCheckResult        
                                    = actualStartInfo->assignedDataCollections[dc].dcItems[it].specCheckResult;
 
                        /*---------------------*/
                        /*   Set actionCodes   */
                        /*---------------------*/
                        CORBA::Long actCodesBuffSize = CIMFWStrLen(actualStartInfo->assignedDataCollections[dc].dcItems[it].actionCodes);
                        if (actCodesBuffSize == 0)
                        {
                            PPT_METHODTRACE_V1( "","CIMFWStrLen(actualStartInfo.assignedDataCollections[dc].dcItems[it].actionCodes) == 0");
                            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode.length(0);
                        }
                        else
                        {
                            PPT_METHODTRACE_V1( "","CIMFWStrLen(actualStartInfo.assignedDataCollections[dc].dcItems[it].actionCodes) != 0");
 
                            char tmpActCodes[1024];
                            CIMFWStrCpy(&tmpActCodes[0],actualStartInfo->assignedDataCollections[dc].dcItems[it].actionCodes);
 
                            char *startPos = &tmpActCodes[0];
                            char *endPos   = &tmpActCodes[0];
 
                            CORBA::Long ActCodeDataNum;
                            for(ActCodeDataNum=0 ; endPos!=NULL ; ActCodeDataNum++)
                            {
                                PPT_METHODTRACE_V2( "","loop to search ActionCodesDataNum", (ActCodeDataNum+1));
                                endPos = strstr(startPos,SP_PosDataCollection_String_Seperator_Char);
                                if (endPos != NULL)
                                {
                                    PPT_METHODTRACE_V1( "","SP_PosDataCollection_String_Seperator_Char == actionCodes");
                                   *endPos = '\0';
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode.length(ActCodeDataNum+1);
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode[ActCodeDataNum] = CIMFWStrDup(startPos);
                                    startPos = endPos+1;
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1( "","SP_PosDataCollection_String_Seperator_Char != actionCodes");
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode.length(ActCodeDataNum+1);
                                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode[ActCodeDataNum] = CIMFWStrDup(startPos);
                                }
                            }
                        }
                    }
 
                    CORBA::Long specLen = actualStartInfo->assignedDataCollections[dc].dcSpecs.length();
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec.length(specLen);
 
                    for (CORBA::Long sp=0 ; sp<specLen ; sp++)
                    {
                        PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedDataCollections[dc].dcSpecs.length()", specLen, sp);
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].dataItemName              
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].dataItemName;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].screenLimitUpperRequired  
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].screenLimitUpperRequired;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].screenLimitUpper          
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].screenLimitUpper;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_uscrn         
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_uscrn;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].screenLimitLowerRequired  
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].screenLimitLowerRequired;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].screenLimitLower          
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].screenLimitLower;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_lscrn         
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_lscrn;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].specLimitUpperRequired    
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].specLimitUpperRequired;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].specLimitUpper            
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].specLimitUpper;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_usl           
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_usl;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].specLimitLowerRequired    
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].specLimitLowerRequired;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].specLimitLower            
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].specLimitLower;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_lsl           
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_lsl;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].controlLimitUpperRequired 
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].controlLimitUpperRequired;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].controlLimitUpper         
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].controlLimitUpper;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_ucl           
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_ucl;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].controlLimitLowerRequired 
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].controlLimitLowerRequired;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].controlLimitLower         
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].controlLimitLower;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_lcl           
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_lcl;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].target                    
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].target;
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].tag                       
                                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].tag;
                    }
                }
            }
            
//DSIV00001471 add start
            //------------------------------------------
            // Get sampled waferIDs on PO
            //------------------------------------------
            PPT_METHODTRACE_V1("", "Get sampled waferIDs on PO.");
            stringSequence assignedSamplingWafers;
            assignedSamplingWafers = actualStartInfo->assignedSamplingWafers;
            
            CORBA::ULong assignedSamplingWafersLen = assignedSamplingWafers.length();
            PPT_METHODTRACE_V2("", " assignedSamplingWafersLen", assignedSamplingWafersLen);
            /*===== set processJobExecFlag Info =====*/
            CORBA::ULong strLotWaferLen = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer.length();
            PPT_METHODTRACE_V2("", " strLotWaferLen", strLotWaferLen);
            
            CORBA::ULong nCnt1 = 0;
            CORBA::ULong nCnt2 = 0;
            
            if (assignedSamplingWafersLen > 0)
            {
                PPT_METHODTRACE_V1("", "assignedSamplingWafersLen > 0");
                for(nCnt1 = 0; nCnt1 < strLotWaferLen; nCnt1++)
                {
                    PPT_METHODTRACE_V3("", "nCnt1, Wafer", nCnt1, strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[nCnt1].waferID.identifier);
                    for (nCnt2 = 0; nCnt2 < assignedSamplingWafersLen; nCnt2++)
                    {
                        PPT_METHODTRACE_V3("", "nCnt2, Sampled Wafer", nCnt2, assignedSamplingWafers[nCnt2]);
                        if( 0 == CIMFWStrCmp(assignedSamplingWafers[nCnt2],
                                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[nCnt1].waferID.identifier))
                        {
                            PPT_METHODTRACE_V2("", "Found Sampled Wafer ", assignedSamplingWafers[nCnt2]);
                            strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[nCnt1].processJobExecFlag = TRUE;
                            break;
                        }
                        
                    }
                    if( nCnt2 == assignedSamplingWafersLen)
                    {
                        PPT_METHODTRACE_V2("", "Not Sampled wafer", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[nCnt1].waferID.identifier);
                        strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[nCnt1].processJobExecFlag = FALSE;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "assignedSamplingWafersLen = 0, No wafer sampling set up");
                for(nCnt1 = 0; nCnt1 < strLotWaferLen; nCnt1++)
                {
                    PPT_METHODTRACE_V3("", "nCnt1, Wafer", nCnt1, strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[nCnt1].waferID.identifier);
                    strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strLotWafer[nCnt1].processJobExecFlag = TRUE;
                }
            }
//DSIV00001471 add end

//INN-R170009 Add Start 
            //--------------------------//
            //   RouteID                //
            //--------------------------//
            PosProcessDefinition_var aMainPD;
            try
            {
                aMainPD = aPosPO->getMainProcessDefinition();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition);

            if ( CORBA::is_nil(aMainPD) )
            {
                PPT_METHODTRACE_V1("", "aMainPD is nil");
                PPT_SET_MSG_RC_KEY( strLot_previousOperation_DataCollectionInformation_Get_out,
                                    MSG_NOT_FOUND_ROUTE, RC_NOT_FOUND_ROUTE,  "" );
                return RC_NOT_FOUND_ROUTE;
            }

            PPT_SET_OBJECT_IDENTIFIER( strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartOperationInfo.routeID,
                                       aMainPD,
                                       strLot_previousOperation_DataCollectionInformation_Get_out,
                                       lot_previousOperation_DataCollectionInformation_Get,
                                       PosProcessDefinition );
            PPT_METHODTRACE_V2("", "routeID", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartOperationInfo.routeID.identifier);

            //--------------------------//
            //   OperationNumber        //
            //--------------------------//
            try
            {
                strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationNumber = aPosPO->getOperationNumber();
                PPT_METHODTRACE_V2("", "operationNumber", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationNumber);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getOperationNumber) 
//INN-R170009 Add End 
            
        }   // Loop end : lotIDs
 
 
        /*----------------------------------------------*/
        /*   Disp Return Structure                      */
        /*----------------------------------------------*/
        CORBA::Long SCLength;
        SCLength = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette.length();
        for (CORBA::Long sc=0 ; sc<SCLength ; sc++)
        {
            PPT_METHODTRACE_V3("", "strStartCassette[sc].loadSequenceNumber...", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[sc].loadSequenceNumber, sc);
            PPT_METHODTRACE_V3("", "strStartCassette[sc].cassetteID...........", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[sc].cassetteID.identifier, sc);
            PPT_METHODTRACE_V3("", "strStartCassette[sc].loadPurposeType......", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[sc].loadPurposeType, sc);
            PPT_METHODTRACE_V3("", "strStartCassette[sc].loadPortID...........", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[sc].loadPortID.identifier, sc);
            PPT_METHODTRACE_V3("", "strStartCassette[sc].unloadPortID.........", strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[sc].unloadPortID.identifier, sc);
 
            CORBA::Long LICLength;
            LICLength = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[sc].strLotInCassette.length();
            for (CORBA::Long sl=0 ; sl<LICLength ; sl++)
            {
                pptLotInCassette strLotInCassette;
                strLotInCassette = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette[sc].strLotInCassette[sl];
 
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].operationStartFlag..................", (strLotInCassette.operationStartFlag ? "True" : "False"), sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].monitorLotFlag......................", (strLotInCassette.monitorLotFlag ? "True" : "False"), sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].lotID...............................", strLotInCassette.lotID.identifier, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].lotType.............................", strLotInCassette.lotType, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].subLotType..........................", strLotInCassette.subLotType, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].recipeParameterChangeType...........", strLotInCassette.recipeParameterChangeType, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].strStartRecipe.logicalRecipeID......", strLotInCassette.strStartRecipe.logicalRecipeID.identifier, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].strStartRecipe.machineRecipeID......", strLotInCassette.strStartRecipe.machineRecipeID.identifier, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].strStartRecipe.physicalRecipeID.....", strLotInCassette.strStartRecipe.physicalRecipeID, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].strStartRecipe.dataCollectionFlag...", (strLotInCassette.strStartRecipe.dataCollectionFlag ? "True" : "False"), sl);
 
                CORBA::Long LWLength;
                LWLength = strLotInCassette.strLotWafer.length();
                for (CORBA::Long sw=0 ; sw<LWLength ; sw++ )
                {
                    PPT_METHODTRACE_V3("", "strLotInCassette.strLotWafer[sw].waferID............", strLotInCassette.strLotWafer[sw].waferID.identifier, sw);
                    PPT_METHODTRACE_V3("", "strLotInCassette.strLotWafer[sw].slotNumber.........", strLotInCassette.strLotWafer[sw].slotNumber, sw);
                    PPT_METHODTRACE_V3("", "strLotInCassette.strLotWafer[sw].controlWaferFlag...", (strLotInCassette.strLotWafer[sw].controlWaferFlag ? "True" : "False"), sw);
 
 
                    CORBA::Long SRPLength;
                    SRPLength = strLotInCassette.strLotWafer[sw].strStartRecipeParameter.length();
                    for (CORBA::Long srp=0 ; srp<SRPLength ; srp++ )
                    {
                        PPT_METHODTRACE_V3("", "strStartRecipeParameter[srp].parameterName................",strLotInCassette.strLotWafer[sw].strStartRecipeParameter[srp].parameterName, srp);
                        PPT_METHODTRACE_V3("", "strStartRecipeParameter[srp].parameterValue...............",strLotInCassette.strLotWafer[sw].strStartRecipeParameter[srp].parameterValue, srp);
                        PPT_METHODTRACE_V3("", "strStartRecipeParameter[srp].targetValue..................",strLotInCassette.strLotWafer[sw].strStartRecipeParameter[srp].targetValue, srp);
                        PPT_METHODTRACE_V3("", "strStartRecipeParameter[srp].useCurrentSettingValueFlag...", (strLotInCassette.strLotWafer[sw].strStartRecipeParameter[srp].useCurrentSettingValueFlag ? "True" : "False"), srp);
                    }
 
                }
 
                CORBA::Long SRLength;
                SRLength = strLotInCassette.strStartRecipe.strStartReticle.length();
                for (CORBA::Long sr=0 ; sr<SRLength ; sr++)
                {
                    PPT_METHODTRACE_V3("", "strStartReticle[sr].sequenceNumber....", strLotInCassette.strStartRecipe.strStartReticle[sr].sequenceNumber, sr);
                    PPT_METHODTRACE_V3("", "strStartReticle[sr].reticleID.........", strLotInCassette.strStartRecipe.strStartReticle[sr].reticleID.identifier, sr);
                }
 
                CORBA::Long SFLength;
                SFLength = strLotInCassette.strStartRecipe.strStartFixture.length();
                for (CORBA::Long sf=0 ; sf<SFLength ; sf++)
                {
                    PPT_METHODTRACE_V3("", "strStartFixture[sf].fixtureID.........", strLotInCassette.strStartRecipe.strStartFixture[sf].fixtureID.identifier, sf);
                    PPT_METHODTRACE_V3("", "strStartFixture[sf].fixtureCategory...", strLotInCassette.strStartRecipe.strStartFixture[sf].fixtureCategory, sf);
                }
 
 
                pptDCDef strDCDef;
                CORBA::Long DCLength;
                DCLength = strLotInCassette.strStartRecipe.strDCDef.length();
                for (CORBA::Long sdc=0 ; sdc<DCLength ; sdc++)
                {
                    strDCDef = strLotInCassette.strStartRecipe.strDCDef[sdc];
 
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].dataCollectionDefinitionID..........", strDCDef.dataCollectionDefinitionID.identifier, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].description.........................", strDCDef.description, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].dataCollectionType..................", strDCDef.dataCollectionType, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].calculationRequiredFlag.............", (strDCDef.calculationRequiredFlag ? "True" : "False"), sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].specCheckRequiredFlag...............", (strDCDef.specCheckRequiredFlag ? "True" : "False"), sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].dataCollectionSpecificationID.......", strDCDef.dataCollectionSpecificationID.identifier, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].dcSpecDescription...................", strDCDef.dcSpecDescription, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].previousDataCollectionDefinitionID..", strDCDef.previousDataCollectionDefinitionID.identifier, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].previousOperationID.................", strDCDef.previousOperationID.identifier, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].previousOperationNumber.............", strDCDef.previousOperationNumber, sdc);
 
                    CORBA::Long DCLength;
                    DCLength = strDCDef.strDCItem.length();
                    for (CORBA::Long sdi=0 ; sdi<DCLength ; sdi++)
                    {
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataCollectionItemName...", strDCDef.strDCItem[sdi].dataCollectionItemName, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataCollectionMode.......", strDCDef.strDCItem[sdi].dataCollectionMode, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataCollectionUnit.......", strDCDef.strDCItem[sdi].dataCollectionUnit, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataType.................", strDCDef.strDCItem[sdi].dataType, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].itemType.................", strDCDef.strDCItem[sdi].itemType, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].measurementType..........", strDCDef.strDCItem[sdi].measurementType, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].waferID..................", strDCDef.strDCItem[sdi].waferID.identifier, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].waferPosition............", strDCDef.strDCItem[sdi].waferPosition, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].sitePosition.............", strDCDef.strDCItem[sdi].sitePosition, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].historyRequiredFlag......", (strDCDef.strDCItem[sdi].historyRequiredFlag ? "True" : "False"), sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].calculationType..........", strDCDef.strDCItem[sdi].calculationType, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].calculationExpression....", strDCDef.strDCItem[sdi].calculationExpression, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataValue................", strDCDef.strDCItem[sdi].dataValue, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].targetValue..............", strDCDef.strDCItem[sdi].targetValue, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].specCheckResult..........", strDCDef.strDCItem[sdi].specCheckResult, sdi);
 
                        CORBA::Long ActCodeLength;
                        ActCodeLength = strDCDef.strDCItem[sdi].actionCode.length();
                        for(CORBA::Long acd=0 ; acd<ActCodeLength ; acd++)
                        {
                            PPT_METHODTRACE_V3("", "strDCItem[sdi].actionCode[acd]..........", strDCDef.strDCItem[sdi].actionCode[acd], acd);
                        }
                    }
 
                    CORBA::Long DCSLength = strDCDef.strDCSpec.length();
                    for (CORBA::Long sds=0 ; sds<DCSLength ; sds++)
                    {
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].dataItemName................", strDCDef.strDCSpec[sds].dataItemName, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].screenLimitUpperRequired....", (strDCDef.strDCSpec[sds].screenLimitUpperRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].screenLimitUpper............", strDCDef.strDCSpec[sds].screenLimitUpper, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_uscrn...........", strDCDef.strDCSpec[sds].actionCodes_uscrn, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].screenLimitLowerRequired....", (strDCDef.strDCSpec[sds].screenLimitLowerRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].screenLimitLower............", strDCDef.strDCSpec[sds].screenLimitLower, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_lscrn...........", strDCDef.strDCSpec[sds].actionCodes_lscrn, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].specLimitUpperRequired......", (strDCDef.strDCSpec[sds].specLimitUpperRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].specLimitUpper..............", strDCDef.strDCSpec[sds].specLimitUpper, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_usl.............", strDCDef.strDCSpec[sds].actionCodes_usl, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].specLimitLowerRequired......", (strDCDef.strDCSpec[sds].specLimitLowerRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].specLimitLower..............", strDCDef.strDCSpec[sds].specLimitLower, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_lsl.............", strDCDef.strDCSpec[sds].actionCodes_lsl, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].controlLimitUpperRequired...", (strDCDef.strDCSpec[sds].controlLimitUpperRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].controlLimitUpper...........", strDCDef.strDCSpec[sds].controlLimitUpper, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_ucl.............", strDCDef.strDCSpec[sds].actionCodes_ucl, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].controlLimitLowerRequired...", (strDCDef.strDCSpec[sds].controlLimitLowerRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].controlLimitLower...........", strDCDef.strDCSpec[sds].controlLimitLower, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_lcl.............", strDCDef.strDCSpec[sds].actionCodes_lcl, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].target......................", strDCDef.strDCSpec[sds].target, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].tag.........................", strDCDef.strDCSpec[sds].tag, sds);
                    }
                }
                //INN-R170009 Add Start
                PPT_METHODTRACE_V2("", "routeID............", strLotInCassette.strStartOperationInfo.routeID.identifier);
                PPT_METHODTRACE_V2("", "operationNumber....", strLotInCassette.strStartOperationInfo.operationNumber);
                //INN-R170009 Add End
            }
        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        //INN-R170009 PPT_METHODTRACE_EXIT("PPTManager_i::lot_previousOperation_DataCollectionInformation_Get");
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_previousOperation_DataCollectionInformation_Get"); //INN-R170009
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_previousOperation_DataCollectionInformation_Get_out, lot_previousOperation_DataCollectionInformation_Get, methodName);
}
