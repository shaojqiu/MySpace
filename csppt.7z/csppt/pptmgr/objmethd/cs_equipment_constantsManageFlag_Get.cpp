#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_equipment_constantsManageFlag_Get.cpp, mm_srv_5_0_ppt, mm_srv_5_0_ppt 5/26/03 20:05:37 [ 5/26/03 20:05:38 ]";
#endif
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_equipment_constantsManageFlag_Get.cpp
//

#include "cs_pptmgr.hpp"

//[Object Function Name]: long   cs_equipment_constantsManageFlag_Get
//
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
//
//
//[Function Description]:
//  Get constantsManageFlag of equipment, and set to out parameter.
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      equipmentID;
//
//[Output Parameters]:
//  out csObjEquipment_constantsManageFlag_Get_out  strObjEquipment_constantsManageFlag_Get_out
//
//  typedef struct csObjEquipment_constantsManageFlag_Get_out_struct {
//     pptRetCode                      strResult;                     
//     boolean                         equipmentConstantsManageFlag;  
//     any siInfo;                                                    
//  } csObjEquipment_constantsManageFlag_Get_out;                     
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_EQP          MSG_NOT_FOUND_EQP
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR
//
//
CORBA::Long CS_PPTManager_i::cs_equipment_constantsManageFlag_Get(
                          csObjEquipment_constantsManageFlag_Get_out&   strObjEquipment_constantsManageFlag_Get_out,
                          const pptObjCommonIn&                        strObjCommonIn,
                          const objectIdentifier&                      equipmentID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "CS_PPTManager_i::cs_equipment_constantsManageFlag_Get" );

        /*----------------*/
        /*   Initialize   */
        /*----------------*/

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         equipmentID,
                                         strObjEquipment_constantsManageFlag_Get_out,
                                         cs_equipment_constantsManageFlag_Get );

        /*--------------------------------------*/
        /*    Get equipment's RMS Const flag    */
        /*--------------------------------------*/
        PPT_METHODTRACE_V1("", "DEBUG_Get equipment's RMS Const flag");
        CORBA::String_var varEqpRMSConstFlag;
        try
        {
            varEqpRMSConstFlag = aMachine->getUserDataNamed( CS_M_RMS_CONST_FLAG );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getUserDataNamed)
        
        PPT_METHODTRACE_V2("", "CS_M_RMS_CONST_FLAG = ", varEqpRMSConstFlag);
        if( 0 == CIMFWStrCmp( varEqpRMSConstFlag , "1" ) )
        {
            strObjEquipment_constantsManageFlag_Get_out.equipmentConstantsManageFlag = TRUE;
        }            
        else
        {
            strObjEquipment_constantsManageFlag_Get_out.equipmentConstantsManageFlag = FALSE;
        }

        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_equipment_constantsManageFlag_Get" );
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS( strObjEquipment_constantsManageFlag_Get_out, cs_equipment_constantsManageFlag_Get, methodName );
}
