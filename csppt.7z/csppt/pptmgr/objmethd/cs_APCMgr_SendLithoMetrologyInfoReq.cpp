//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APCMgr_SendLithoMetrologyInfoReq.cpp
//

#include "cs_apcsm.hh"
#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APCMgr_SendLithoMetrologyInfoReq.cpp
//
//
// Innotron Modification History:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009 Nick Tsai      Send Data Collection to APC
//
// Function Description:
//
// Input Parameters:
//    csObjAPCMgr_SendLithoMetrologyInfoReq_out&        strObjAPCMgr_SendLithoMetrologyInfoReq_out,
//    const pptObjCommonIn&                             strObjCommonIn,
//    const csObjAPCMgr_SendLithoMetrologyInfoReq_in&   strObjAPCMgr_SendLithoMetrologyInfoReq_in
//
//typedef struct csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct {
//    objectIdentifier            equipmentID;
//    pptStartCassetteSequence    strStartCassette;
//    any                         siInfo;
//}csObjAPCMgr_SendLithoMetrologyInfoReq_in;
//
//
// Output Parameters:
//
//typedef struct csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct {
//    pptRetCode                      strResult;
//    any                             siInfo;
//}csObjAPCMgr_SendLithoMetrologyInfoReq_out;
//
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//


CORBA::Long CS_PPTManager_i::cs_APCMgr_SendLithoMetrologyInfoReq (
    csObjAPCMgr_SendLithoMetrologyInfoReq_out&       strObjAPCMgr_SendLithoMetrologyInfoReq_out,
    const pptObjCommonIn&                            strObjCommonIn,
    const csObjAPCMgr_SendLithoMetrologyInfoReq_in&  strObjAPCMgr_SendLithoMetrologyInfoReq_in
)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APCMgr_SendLithoMetrologyInfoReq");

        //================================================================//
        //   Print input parameters                                       //
        //================================================================//
        PPT_METHODTRACE_V2("", "equipmentID ",  strObjAPCMgr_SendLithoMetrologyInfoReq_in.equipmentID.identifier);

        //================================================================//
        //   Check input parameters                                       //
        //================================================================//
        if ( CIMFWStrLen ( strObjAPCMgr_SendLithoMetrologyInfoReq_in.equipmentID.identifier) == 0 )
        {
            PPT_METHODTRACE_V1("","CIMFWStrLen ( strObjAPCMgr_SendLithoMetrologyInfoReq_in.equipmentID.identifier) == 0");
            PPT_SET_MSG_RC_KEY( strObjAPCMgr_SendLithoMetrologyInfoReq_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, "*******" );
            return RC_NOT_FOUND_EQP;
        }

        if ( strObjAPCMgr_SendLithoMetrologyInfoReq_in.strStartCassette.length() == 0 )
        {
            PPT_METHODTRACE_V1("","strObjAPCMgr_SendLithoMetrologyInfoReq_in.strStartCassette.length() == 0");
            SET_MSG_RC( strObjAPCMgr_SendLithoMetrologyInfoReq_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        //=======================================================================//
        //   1. Prepare APC ( Context & Reticle) data                            //
        //   2. Send data collection to APC I/F                                  //
        //=======================================================================//
        pptStartCassetteSequence strStartCassette = strObjAPCMgr_SendLithoMetrologyInfoReq_in.strStartCassette;

        CORBA::Long scLen = strStartCassette.length();
        PPT_METHODTRACE_V2("", "strStartCassette.length()", scLen) ;
        for ( CORBA::Long i = 0 ; i < scLen ; i ++ )
        {
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()", nLen) ;

            for ( CORBA::Long j = 0 ; j < nLen ; j ++ )
            {
                //================================================================//
                //   Omit Not-OpeStart Lot                                        //
                //================================================================//
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }
                PPT_METHODTRACE_V2("", "lotID",             strStartCassette[i].strLotInCassette[j].lotID.identifier) ;
                PPT_METHODTRACE_V2("", "routeID",           strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier) ;
                PPT_METHODTRACE_V2("", "operationNumber",   strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber) ;

                //================================================================//
                //   Omit Recommend Flag is FALSE                                 //
                //================================================================//
                csObjAPC_LithoAvailable_CheckCondition_out strAPC_LithoAvailable_CheckCondition_out;
                csObjAPC_LithoAvailable_CheckCondition_in  strAPC_LithoAvailable_CheckCondition_in;
                strAPC_LithoAvailable_CheckCondition_in.equipmentID       = strObjAPCMgr_SendLithoMetrologyInfoReq_in.equipmentID;
                strAPC_LithoAvailable_CheckCondition_in.routeID           = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                strAPC_LithoAvailable_CheckCondition_in.operationNumber   = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;

                rc = cs_APC_LithoAvailable_CheckCondition( strAPC_LithoAvailable_CheckCondition_out,
                                                           strObjCommonIn,
                                                           strAPC_LithoAvailable_CheckCondition_in ) ;
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "cs_APC_LithoAvailable_CheckCondition() != RC_OK", rc) ;
                    strObjAPCMgr_SendLithoMetrologyInfoReq_out.strResult = strAPC_LithoAvailable_CheckCondition_out.strResult ;
                    return(rc);
                }

                PPT_METHODTRACE_V2("", "usedFlag",   strAPC_LithoAvailable_CheckCondition_out.usedFlag) ;

                if ( strAPC_LithoAvailable_CheckCondition_out.metrologyFlag == TRUE )
                {
                    //================================================================//
                    //   Declare APC structure                                        //
                    //================================================================//
                    Innotron_Met_Request  strAPCMetrologyRequest;

                    //================================================================//
                    //   Prepare APC Context Info                                     //
                    //================================================================//
                    csObjAPC_LithoContextInfo_Get_out strObjAPC_LithoContextInfo_Get_out;
                    csObjAPC_LithoContextInfo_Get_in  strObjAPC_LithoContextInfo_Get_in ;
                    strObjAPC_LithoContextInfo_Get_in.lotID                        = strStartCassette[i].strLotInCassette[j].lotID;
                    strObjAPC_LithoContextInfo_Get_in.routeID                      = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                    strObjAPC_LithoContextInfo_Get_in.operationNumber              = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;
                    strObjAPC_LithoContextInfo_Get_in.equipmentID                  = strObjAPCMgr_SendLithoMetrologyInfoReq_in.equipmentID;
                    strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq           = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle;
                    strObjAPC_LithoContextInfo_Get_in.action                       = CIMFWStrDup ( CS_APC_COMBINE_FLAG_ACTION_METROLOGY );

                    if ( strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0 )
                    {
                        PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0") ;
                        strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq   = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter;
                    }

                    rc = cs_APC_LithoContextInfo_Get( strObjAPC_LithoContextInfo_Get_out,
                                                      strObjCommonIn,
                                                      strObjAPC_LithoContextInfo_Get_in ) ;
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "cs_APC_LithoContextInfo_Get() != RC_OK", rc) ;
                        strObjAPCMgr_SendLithoMetrologyInfoReq_out.strResult = strObjAPC_LithoContextInfo_Get_out.strResult ;
                        return(rc);
                    }

                    PPT_METHODTRACE_V2("", "controlJobType",         strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.controlJobType);
                    PPT_METHODTRACE_V2("", "transactionID",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.transactionID);
                    PPT_METHODTRACE_V2("", "usedTransactionID",      strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.usedTransactionID);
                    PPT_METHODTRACE_V2("", "lotID",                  strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotID);
                    PPT_METHODTRACE_V2("", "partID",                 strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.partID);
                    PPT_METHODTRACE_V2("", "layer",                  strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.layer);
                    PPT_METHODTRACE_V2("", "routeID",                strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeID);
                    PPT_METHODTRACE_V2("", "routeGroup",             strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeGroup);
                    PPT_METHODTRACE_V2("", "operationNumber",        strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.operationNumber);
                    PPT_METHODTRACE_V2("", "reticleID",              strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reticleID);
                    PPT_METHODTRACE_V2("", "metrologyEquipmentType", strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.metrologyEquipmentType);
                    PPT_METHODTRACE_V2("", "metrologyEquipmentID",   strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.metrologyEquipmentID);
                    PPT_METHODTRACE_V2("", "processEquipmentType",   strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentType);
                    PPT_METHODTRACE_V2("", "processEquipmentID",     strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentID);

                    strAPCMetrologyRequest.APC_CONTEXT.CONTROLJOBTYPE[0]     = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.controlJobType;
                    strAPCMetrologyRequest.APC_CONTEXT.TRANSACTIONID[0]      = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.transactionID;
                    strAPCMetrologyRequest.APC_CONTEXT.USED_TRANSACTIONID[0] = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.usedTransactionID;
                    strAPCMetrologyRequest.APC_CONTEXT.LOTID[0]              = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotID;
                    strAPCMetrologyRequest.APC_CONTEXT.PARTID[0]             = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.partID;
                    strAPCMetrologyRequest.APC_CONTEXT.LAYER[0]              = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.layer;
                    strAPCMetrologyRequest.APC_CONTEXT.ROUTE[0]              = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeID;
                    strAPCMetrologyRequest.APC_CONTEXT.ROUTEGROUP[0]         = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeGroup;
                    strAPCMetrologyRequest.APC_CONTEXT.OPERATION[0]          = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.operationNumber;
                    strAPCMetrologyRequest.APC_CONTEXT.RETICLEID[0]          = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reticleID;
                    strAPCMetrologyRequest.APC_CONTEXT.METROLOGYEQUIPTYPE[0] = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.metrologyEquipmentType;
                    strAPCMetrologyRequest.APC_CONTEXT.METROLOGYEQUIPID[0]   = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.metrologyEquipmentID;
                    strAPCMetrologyRequest.APC_CONTEXT.PROCESSEQUIPTYPE[0]   = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentType;
                    strAPCMetrologyRequest.APC_CONTEXT.PROCESSEQUIPID[0]     = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentID;

                    //================================================================//
                    //   Prepare APC Reticle Info                                     //
                    //================================================================//



                    //================================================================//
                    //   Send recommend request to APC I/F                            //
                    //================================================================//
                    // Get APC Server Name
                    PPT_METHODTRACE_V1("", "Get Server Name");
                    CORBA::String_var tmpAPCServerName = CIMFWStrDup( getenv(SP_APC_SERVER_NAME) );
                    char* APCServerName = CORBA::string_alloc( (CORBA::ULong) CIMFWStrLen(tmpAPCServerName)+1 );
                    CORBA::String_var tmpStr = APCServerName;
                    if ( NULL != APCServerName )
                    {
                        APCServerName[0] = NULL;
                    }

                    if ( strstr(tmpAPCServerName, ":") == NULL )
                    {
                        CIMFWStrCpy( APCServerName , ":" );
                        CIMFWStrCat( APCServerName , tmpAPCServerName );
                    }
                    else
                    {
                        CIMFWStrCpy( APCServerName , tmpAPCServerName );
                    }

                    // Get APC Host Name
                    PPT_METHODTRACE_V1("", "Get Host Name");
                    CORBA::String_var APCHostName;
                    APCHostName = CIMFWStrDup( getenv(SP_APC_HOST_NAME) );

                    LithoR2RWebServiceSoap_var APCSvcMgr;

                    PPT_METHODTRACE_V1("", "call APCMgr_GetServiceManager");
                    objAPCMgr_GetServiceManager_out strAPCMgr_GetServiceManager_out;
                    rc = APCMgr_GetServiceManager( strAPCMgr_GetServiceManager_out,
                                                   strObjCommonIn,
                                                   APCServerName,
                                                   APCHostName);

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "APCMgr_GetServiceManager() != RC_OK", rc);
                        strObjAPCMgr_SendLithoMetrologyInfoReq_out.strResult = strAPCMgr_GetServiceManager_out.strResult;
                        return( rc );
                    }

#ifdef EBROKER
                    CORBA::Object_var anObject = SP_STRING_TO_OBJECT(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#else
                    CORBA::Object_var anObject = CORBA::Orbix.string_to_object(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#endif
                    APCSvcMgr = LithoR2RWebServiceSoap::_narrow(anObject);
                    if ( CORBA::is_nil(APCSvcMgr) )
                    {
                        SET_MSG_RC(strObjAPCMgr_SendLithoMetrologyInfoReq_out, MSG_APC_SERVER_NIL_OBJ, RC_APC_SERVER_NIL_OBJ);
                        return( RC_APC_SERVER_NIL_OBJ );
                    }

                    CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;
                    CORBA::String_var timeOutValue;
                    timeOutValue = CIMFWStrDup( getenv(SP_TX_Timeout_APC) );
                    if ( 0 < CIMFWStrLen(timeOutValue) )
                    {
                        envTimeOut.timeout(atol(timeOutValue) * 1000);
                    }

                    // Get Environment for GenIOR
#ifdef EBROKER
                    tmpAPCServerName = CIMFWStrDup(APCServerName);
#else
                    tmpAPCServerName = CIMFWStrDup(getenv(SP_APCServerName_ForGenIOR));
#endif

                    PPT_METHODTRACE_V1("", "Send Request to APC");

                    // External System Interface Security Control
                    pptUser tmpRequestUser = strObjCommonIn.strUser;

                    CORBA::String_var configFlag = CIMFWStrDup( getenv(SP_USER_ID_PASSWORD_CONFIGRATION) );
                    PPT_METHODTRACE_V2("","SP_USER_ID_PASSWORD_CONFIGRATION ", configFlag);

                    if( 0 == CIMFWStrCmp( configFlag, "1" ) )
                    {
                        PPT_METHODTRACE_V1("","SP_USER_ID_PASSWORD_CONFIGRATION=1");

                        tmpRequestUser.userID.identifier = CIMFWStrDup( getenv(SP_APC_USER_ID) );
                        tmpRequestUser.password          = CIMFWStrDup( getenv(SP_APC_USER_PASSWORD) );
                    }

                    PPT_METHODTRACE_V2("","userID   ", tmpRequestUser.userID.identifier);
                    PPT_METHODTRACE_V2("","password ", tmpRequestUser.password);

                    Innotron_Met_Result*     apcResult = NULL;
                    Innotron_Met_Result_var  apcResultVar;
                    try
                    {
                        apcResult = APCSvcMgr->Metrology_Request( strAPCMetrologyRequest );
                        apcResultVar = apcResult;
                    }
                    catch(const CORBA::SystemException &SysEx)
                    {
                        PPT_METHODTRACE_V1("", "CORBA::SystemException caught");
                        APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                        SET_MSG_RC( strObjAPCMgr_SendLithoMetrologyInfoReq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                        try
                        {
                            PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);
                            externalServerList.remove((char *)tmpAPCServerName);
                        }
                        catch( ... )
                        {
                            PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                        }
                        //Nick return( RC_NO_RESPONSE_APC );
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "Unknown exception caught");
                        APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ( );
                        SET_MSG_RC( strObjAPCMgr_SendLithoMetrologyInfoReq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                        try
                        {
                            PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);
                            externalServerList.remove((char *)tmpAPCServerName);
                        }
                        catch( ... )
                        {
                            PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                        }
                        //Nick return( RC_NO_RESPONSE_APC );
                    }

                    // Check APC return error or not
                    PPT_METHODTRACE_V2("", "APC STATUSCODE", apcResult->APC_STATUS.STATUSCODE) ;  //APC only replies 0 or 1. 0:OK, 1:NG
                    if (apcResult->APC_STATUS.STATUSCODE != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "Metrology_Request() != RC_OK, Error") ;
                        strObjAPCMgr_SendLithoMetrologyInfoReq_out.strResult.transactionID  = strObjCommonIn.transactionID ;
                        strObjAPCMgr_SendLithoMetrologyInfoReq_out.strResult.returnCode     = ConvertLongtoString(RC_APC_RECIPEPARAMETERREQ_ERROR) ;
                        if ( apcResult->APC_STATUS.STATUSSTRING.length() > 0 )
                        {
                            strObjAPCMgr_SendLithoMetrologyInfoReq_out.strResult.messageText    = apcResult->APC_STATUS.STATUSSTRING[0] ;
                        }
                        //Nick return(RC_APC_RECIPEPARAMETERREQ_ERROR);
                    }
                }
            }
        }

        //================================================================//
        //   Return value                                                 //
        //================================================================//
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APCMgr_SendLithoMetrologyInfoReq");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjAPCMgr_SendLithoMetrologyInfoReq_out, cs_APCMgr_SendLithoMetrologyInfoReq, methodName)
}
