#ifndef lint
static char *sccsid =  "@(#) 1.9 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_BWS_sorter_CheckConditionForJobCreate.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 12/3/07 18:56:16 [ 12/3/07 18:56:17 ]";
#endif

//
//
// SiView
// Name: cs_BWS_sorter_CheckConditionForJobCreate.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"
#include "plot.hh"

// Class: CS_PPTManager
//
// Service: cs_BWS_sorter_CheckConditionForJobCreate()
//
// Change history:
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2007/06/29 D9000005  M.Murata       Initia ( R9.0 )
// 2007/08/22 D9000056  H.Hotta        Add check logic for InPostProcessFlag.
// 2007/10/23 D9000098  M.Murata       Divided Library
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/14 DSIV00000099 M.Ogawa        Add check logic for the reserved cassette.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/11/20 DSIV00000214 K.Kido         Multi Fab support.
// 2009/04/17 PSIV00000956 F.Chen         Fix to support parallel sort job creation
//
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/26 INN-R170017  Evie Su        Initial Release, copy from sorter_CheckConditionForJobCreate.cpp
//
// Description:
// This method checks whether the specified information fulfills condition as Sorter Job information.
//
// Return:
//      long
//
// Parameter:
//  [Inparameter]
//  const pptObjCommonIn&                                  strObjCommonIn
//  const csObjBWSSorter_CheckConditionForJobCreate_in&    strBWSSorter_CheckConditionForJobCreate_in
//
//  typedef struct csObjBWSSorter_CheckConditionForJobCreate_in_in_struct{
//      pptSorterComponentJobListAttributesSequence  strSorterComponentJobListAttributesSequence;
//      objectIdentifier                             equipmentID;
//      string                                       portGroupID;
//      any                                          siInfo;
//  }csObjBWSSorter_CheckConditionForJobCreate_in;
//
//  [Outparameter]
//  csObjBWSSorter_CheckConditionForJobCreate_out&          strBWSSorter_CheckConditionForJobCreate_out
//
//  typedef pptBaseResult csObjBWSSorter_CheckConditionForJobCreate_out;
//
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i:: cs_BWS_sorter_CheckConditionForJobCreate(
    csObjBWSSorter_CheckConditionForJobCreate_out&       strBWSSorter_CheckConditionForJobCreate_out,
    const pptObjCommonIn&                                strObjCommonIn,
    const csObjBWSSorter_CheckConditionForJobCreate_in&  strBWSSorter_CheckConditionForJobCreate_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_BWS_sorter_CheckConditionForJobCreate");

        //--------------------------------------------------------------
        //  Initialize
        //--------------------------------------------------------------
        CORBA::Long rc = 0;

        csObjBWSSorter_CheckConditionForJobCreate_in Inpara;
        Inpara = strBWSSorter_CheckConditionForJobCreate_in;

        if( 0 != CIMFWStrCmp( strObjCommonIn.strUser.userID.identifier, "evie" ) )
        {
            return RC_OK;
        }

        PPT_METHODTRACE_V2( "", "in para : userID      ", strObjCommonIn.strUser.userID.identifier );
        PPT_METHODTRACE_V2( "", "in para : equipmentID ", Inpara.equipmentID.identifier );
        PPT_METHODTRACE_V2( "", "in para : portGroupID ", Inpara.portGroupID            );

        //==============================================================
        //
        // Check Inparameter consistency
        //
        //==============================================================
        CORBA::Long srtCmpLen  = Inpara.strSorterComponentJobListAttributesSequence.length();
        CORBA::Long srtCmpCnt  = 0;
        CORBA::Long srtCmpLen2 = 0;
        CORBA::Long srtCmpCnt2 = 0;

        CORBA::Long slotMapLen  = 0;
        CORBA::Long slotMapCnt  = 0;
        CORBA::Long slotMapLen2 = 0;
        CORBA::Long slotMapCnt2 = 0;

        //INN-R170017 add start
        char buff[1024];
        CORBA::Long ix = 0;
        CORBA::Long jx = 0;
        CORBA::Long kx = 0;
        CORBA::Long ind = 0;
        CORBA::Long lnLenCast = 0;
        CORBA::Long lnLenZone = 0;
        CORBA::Long lnLenLot = 0;
        CORBA::Long lnLenSlotMap = 0;
        CORBA::Long nLenAttr = Inpara.strSorterComponentJobListAttributesSequence.length();
        CORBA::Boolean bFound = FALSE;
        CORBA::Boolean bCheckSuccess = FALSE;
        stringSequence           strZoneIDs;
        objectIdentifierSequence strCassetteIDs;
        pptProcessWaferSequence  strLotWaferSeq;

        for( ix=0; ix<nLenAttr; ix++ )
        {
            PPT_METHODTRACE_V3( "", ix, "in para : sorterComponentJobID ",          Inpara.strSorterComponentJobListAttributesSequence[ix].sorterComponentJobID.identifier );

            PPT_METHODTRACE_V3( "", ix, "in para : originalCarrierID ",             Inpara.strSorterComponentJobListAttributesSequence[ix].originalCarrierID.identifier );
            PPT_METHODTRACE_V3( "", ix, "in para : originalPortID ",                Inpara.strSorterComponentJobListAttributesSequence[ix].originalPortID.identifier );
            PPT_METHODTRACE_V3( "", ix, "in para : originalCarrierXferStatus ",     Inpara.strSorterComponentJobListAttributesSequence[ix].originalCarrierXferStatus );
            PPT_METHODTRACE_V3( "", ix, "in para : originalCarrierEquipmentID ",    Inpara.strSorterComponentJobListAttributesSequence[ix].originalCarrierEquipmentID.identifier );
            PPT_METHODTRACE_V3( "", ix, "in para : originalCarrierStockerID ",      Inpara.strSorterComponentJobListAttributesSequence[ix].originalCarrierStockerID.identifier );

            PPT_METHODTRACE_V3( "", ix, "in para : destinationCarrierID ",          Inpara.strSorterComponentJobListAttributesSequence[ix].destinationCarrierID.identifier );
            PPT_METHODTRACE_V3( "", ix, "in para : destinationPortID ",             Inpara.strSorterComponentJobListAttributesSequence[ix].destinationPortID.identifier );
            PPT_METHODTRACE_V3( "", ix, "in para : destinationCarrierXferStatus ",  Inpara.strSorterComponentJobListAttributesSequence[ix].destinationCarrierXferStatus );
            PPT_METHODTRACE_V3( "", ix, "in para : destinationCarrierEquipmentID ", Inpara.strSorterComponentJobListAttributesSequence[ix].destinationCarrierEquipmentID.identifier );
            PPT_METHODTRACE_V3( "", ix, "in para : destinationCarrierStockerID ",   Inpara.strSorterComponentJobListAttributesSequence[ix].destinationCarrierStockerID.identifier );

            PPT_METHODTRACE_V3( "", ix, "in para : componentSorterJobStatus ",      Inpara.strSorterComponentJobListAttributesSequence[ix].componentSorterJobStatus );
            PPT_METHODTRACE_V3( "", ix, "in para : preSorterComponentJobID ",       Inpara.strSorterComponentJobListAttributesSequence[ix].preSorterComponentJobID.identifier );

            CORBA::Long lnLenMap = Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence.length();
            PPT_METHODTRACE_V3( "", ix, "lnLenMap", lnLenMap );
            for( jx=0; jx<lnLenMap; jx++ )
            {
                PPT_METHODTRACE_V4( "", ix, jx, "in para : portGroup ",                           Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].portGroup );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : equipmentID ",                         Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].equipmentID.identifier );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : actionCode ",                          Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].actionCode );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : waferID ",                             Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : lotID ",                               Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID.identifier );

                PPT_METHODTRACE_V4( "", ix, jx, "in para : destinationCassetteID ",               Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].destinationCassetteID.identifier );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : destinationPortID ",                   Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].destinationPortID.identifier );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : bDestinationCassetteManagedBySiView ", Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].bDestinationCassetteManagedBySiView );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : destinationSlotNumber ",               Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].destinationSlotNumber );

                PPT_METHODTRACE_V4( "", ix, jx, "in para : originalCassetteID ",                  Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].originalCassetteID.identifier );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : originalPortID ",                      Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].originalPortID.identifier );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : bOriginalCassetteManagedBySiView ",    Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].bOriginalCassetteManagedBySiView );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : originalSlotNumber ",                  Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].originalSlotNumber );

                PPT_METHODTRACE_V4( "", ix, jx, "in para : sorterStatus ",                        Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].sorterStatus );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : slotMapCompareStatus ",                Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].slotMapCompareStatus );
                PPT_METHODTRACE_V4( "", ix, jx, "in para : mmCompareStatus ",                     Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].mmCompareStatus );
            }
        }

        //-------------------------------------------------------------------
        // Pre-check and Get action of BWS
        //-------------------------------------------------------------------
        CORBA::String_var actionCode = CIMFWStrDup("");
        for( ix=0; ix<nLenAttr; ix++ )
        {
            lnLenSlotMap = Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence.length();
            PPT_METHODTRACE_V2( "", "lnLenSlotMap", lnLenSlotMap )
            for( jx=0; jx<lnLenSlotMap; jx++ )
            {
                PPT_METHODTRACE_V4( "", ix, jx, "bDestinationCassetteManagedBySiView", ((Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].bDestinationCassetteManagedBySiView)?"TRUE":"FALSE") )
                PPT_METHODTRACE_V4( "", ix, jx, "bOriginalCassetteManagedBySiView",    ((Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].bOriginalCassetteManagedBySiView)?"TRUE":"FALSE") )

                if( 0 == CIMFWStrLen(actionCode) )
                {
                    actionCode = CIMFWStrDup(Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].actionCode);
                }
                else
                {
                    if( 0 != CIMFWStrCmp( actionCode,
                                          Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].actionCode ) )
                    {
                        PPT_METHODTRACE_V2( strTrace, "##### BWS Action is inconsistency. ", actionCode );

                        ostrstream errorMsg;
                        errorMsg << " BWS Action is inconsistency. lotID=" << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID.identifier << "; waferID=" << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier;
                        errorMsg << ends;

                        CS_PPT_SET_MSG_RC_KEY1( strBWSSorter_CheckConditionForJobCreate_out,
                                                CS_MSG_BWS_NOT_ALLOWED_SORTER_ACTION_INCONSISTENCY,
                                                CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION_INCONSISTENCY,
                                                errorMsg.str() );

                        errorMsg.rdbuf()->freeze(0);
                        return ( CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION_INCONSISTENCY );
                    }
                }

                if( 0 == CIMFWStrCmp( actionCode, CS_WaferTransfer_BWSIn ) )
                {
                    if( FALSE != Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].bDestinationCassetteManagedBySiView )
                    {

                        PPT_METHODTRACE_V1( strTrace, "##### BWSIn bDestinationCassetteManagedBySiView should be FALSE. " );

                        PPT_METHODTRACE_V2( "", " BWSIn : bDestinationCassetteManagedBySiView is invalid (should be FALSE). lotID   =", Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID.identifier );
                        PPT_METHODTRACE_V2( "", " BWSIn : bDestinationCassetteManagedBySiView is invalid (should be FALSE). waferID =", Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier );

                        ostrstream errorMsg;
                        errorMsg << " BWSIn : bDestinationCassetteManagedBySiView is invalid (should be FALSE). lotID=" << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID.identifier << "; waferID=" << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier;
                        errorMsg << ends;

                        PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                            MSG_SORTER_INVALID_PARAMETER,
                                            RC_SORTER_INVALID_PARAMETER,
                                            errorMsg.str() );

                        errorMsg.rdbuf()->freeze(0);
                        return ( RC_SORTER_INVALID_PARAMETER );
                    }
                }
                else if( 0 == CIMFWStrCmp( actionCode, CS_WaferTransfer_BWSOut ) )
                {
                    if( FALSE != Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].bOriginalCassetteManagedBySiView )
                    {
                        PPT_METHODTRACE_V1( strTrace, "##### BWSIn bDestinationCassetteManagedBySiView should be FALSE. " );

                        PPT_METHODTRACE_V2( "", " BWSOut : bOriginalCassetteManagedBySiView is invalid (should be FALSE). lotID   =", Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID.identifier );
                        PPT_METHODTRACE_V2( "", " BWSOut : bOriginalCassetteManagedBySiView is invalid (should be FALSE). waferID =", Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier );

                        ostrstream errorMsg;
                        errorMsg << " BWSOut : bOriginalCassetteManagedBySiView is invalid (should be FALSE). lotID=" << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID.identifier << "; waferID=" << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier;
                        errorMsg << ends;

                        PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                            MSG_SORTER_INVALID_PARAMETER,
                                            RC_SORTER_INVALID_PARAMETER,
                                            errorMsg.str() );

                        errorMsg.rdbuf()->freeze(0);
                        return ( RC_SORTER_INVALID_PARAMETER );
                    }
                }
                else
                {
                    PPT_METHODTRACE_V2( strTrace, "##### BWS Action is invalid. ", actionCode );

                    ostrstream errorMsg;
                    errorMsg << " BWS Action is invalid. " << actionCode << ", lotID=" << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID.identifier << "; waferID=" << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return( RC_SORTER_INVALID_PARAMETER );
                }
            }
        }
        PPT_METHODTRACE_V2( "", "actionCode", actionCode );

        //-------------------------------------------------------------------
        // BWSJob check (BWSIn & BWSOut)
        //-------------------------------------------------------------------
        nLenAttr = Inpara.strSorterComponentJobListAttributesSequence.length();
        PPT_METHODTRACE_V2( "", "strSorterComponentJobListAttributesSequence.length()", Inpara.strSorterComponentJobListAttributesSequence.length() )

        for( ix=0; ix<nLenAttr; ix++ )
        {
            //---------------------------------------------------------------
            // 1. collect cassetteID (originalCarrier = destinationCarrier)
            //---------------------------------------------------------------
            bFound = FALSE;
            lnLenCast = strCassetteIDs.length();
            PPT_METHODTRACE_V2( "", "##--- lnLenCast", lnLenCast );
            for( ind=0; ind<lnLenCast; ind++ )
            {
                if( 0 == CIMFWStrCmp( strCassetteIDs[ind].identifier, Inpara.strSorterComponentJobListAttributesSequence[ix].originalCarrierID.identifier ) )
                {
                    bFound = TRUE;
                    break;
                }
            }

            if( bFound == FALSE )
            {
                strCassetteIDs.length(lnLenCast+1);
                strCassetteIDs[lnLenCast] = Inpara.strSorterComponentJobListAttributesSequence[ix].originalCarrierID;

                PPT_METHODTRACE_V2( "", "##--- add cassetteID", strCassetteIDs[lnLenCast].identifier );
            }

            //---------------------------------------------------------------
            // 2. collect lotID & waferID & zoneID
            //---------------------------------------------------------------
            lnLenSlotMap = Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence.length();
            for( jx=0; jx<lnLenSlotMap; jx++ )
            {
                // 2-1 collect lotID & waferID
                lnLenLot = strLotWaferSeq.length();
                PPT_METHODTRACE_V2( "", "##--- lnLenLot", lnLenLot );
                for( ind=0; ind<lnLenLot; ind++ )
                {
                    if( 0 == CIMFWStrCmp( strLotWaferSeq[ind].lotID.identifier,
                             Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID.identifier ) ||
                        0 == CIMFWStrCmp( strLotWaferSeq[ind].waferID.identifier,
                             Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier ) )
                    {
                        bFound = TRUE;
                        break;
                    }
                }

                if( bFound == FALSE )
                {
                    strLotWaferSeq.length(lnLenLot+1);
                    strLotWaferSeq[lnLenLot].lotID   = Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].lotID;
                    strLotWaferSeq[lnLenLot].waferID = Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID;
                    
                    PPT_METHODTRACE_V2( "", "##--- add lotID",   strLotWaferSeq[lnLenLot].lotID.identifier );
                    PPT_METHODTRACE_V2( "", "##--- add waferID", strLotWaferSeq[lnLenLot].waferID.identifier );
                }

                // 2-2 collect zoneID
                CORBA::String_var zoneID = CIMFWStrDup("");

                csWaferSorterSlotMap_siInfo* strWaferSorterSlotMap_siInfo;
                if( Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].siInfo >>= strWaferSorterSlotMap_siInfo )
                {
                    zoneID = CIMFWStrDup(strWaferSorterSlotMap_siInfo->zoneID);
                }
                else
                {
                    PPT_METHODTRACE_V1( "", "##### zoneID is not set in siInfo. " );

                    ostrstream errorMsg;
                    errorMsg << " WaferID " << Inpara.strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier << " has not set zoneID in siInfo";
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }
                PPT_METHODTRACE_V2( "", "zoneID", zoneID );

                bFound = FALSE;
                lnLenZone = strZoneIDs.length();
                PPT_METHODTRACE_V2( "", "##--- lnLenZone", lnLenZone );
                for( ind=0; ind<lnLenZone; ind++ )
                {
                    if( 0 == CIMFWStrCmp( strZoneIDs[ind], zoneID ) )
                    {
                        bFound = TRUE;
                        break;
                    }
                }

                if( bFound == FALSE )
                {
                    strZoneIDs.length(lnLenZone+1);
                    strZoneIDs[lnLenZone] = zoneID;

                    PPT_METHODTRACE_V2( "", "##--- add zoneID", strZoneIDs[lnLenZone] );
                }
            }
        }

        if( 0 == CIMFWStrCmp( actionCode, CS_WaferTransfer_BWSIn ) )
        {
            PPT_METHODTRACE_V1( strTrace, "##### BWS Action is [BWSIn]" );

            //-----------------------------------------------------------
            // BWSIn check item :
            // . zone exist
            // . zone available capacity
            // . BWS is defined in Bank(zone) UData  ==> skip
            // . foup category ==> exist logic
            // . 1-wafer lot
            // . lot is in bank
            // . specific subLotType
            //-----------------------------------------------------------
            //-----------------------------------------------------------
            //  Zone Check
            //-----------------------------------------------------------
            PPT_METHODTRACE_V1( "", "  --- BWSIn check item : (1) zoneID  -- " );

            if( 1 != strZoneIDs.length() )
            {
                PPT_METHODTRACE_V1( "", "##### zoneID is different. " );

                ostrstream errorMsg;
                errorMsg << " BWSIn should be with one ZoneID only. ";
                errorMsg << ends;

                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                    MSG_SORTER_INVALID_PARAMETER,
                                    RC_SORTER_INVALID_PARAMETER,
                                    errorMsg.str() );

                errorMsg.rdbuf()->freeze(0);
                return ( RC_SORTER_INVALID_PARAMETER );
            }

            // zoneID in BWS Config ? availableCapacity is enough ?
            PPT_METHODTRACE_V1( "", "   (1) zoneID check -- [2] zoneID in BWS Config ? " );
            CORBA::Long availableCapacity = 0;

            csObjBWS_Config_GetDR_in strBWS_Config_GetDR_in;
            strBWS_Config_GetDR_in.BWSID  = Inpara.equipmentID;
            strBWS_Config_GetDR_in.zoneID = strZoneIDs[0];

            csObjBWS_Config_GetDR_out strBWS_Config_GetDR_out;
            rc = cs_BWS_Config_GetDR( strBWS_Config_GetDR_out,
                                      strObjCommonIn,
                                      strBWS_Config_GetDR_in );

            if( rc != RC_OK && rc != CS_RC_BWS_CONFIG_NOT_FOUND_BWS )
            {
                PPT_METHODTRACE_V2( "", "cs_BWS_Config_GetDR() != RC_OK, rc=", rc );
                strBWSSorter_CheckConditionForJobCreate_out.strResult = strBWS_Config_GetDR_out.strResult;
                return(rc);
            }

            bCheckSuccess = FALSE;
            if( 0 <  strBWS_Config_GetDR_out.strBWSConfigInfoSeq.length() &&
                0 == CIMFWStrCmp( Inpara.equipmentID.identifier,
                                  strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].BWSID.identifier ) )
            {
                PPT_METHODTRACE_V2( "", "BWS maxCapacity      ", strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].maxCapacity );
                PPT_METHODTRACE_V2( "", "BWS availableCapacity", strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].availableCapacity );

                if( 0 <  strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq.length()  &&
                    0 == CIMFWStrCmp( strZoneIDs[0],
                                      strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[0].zoneID ) )
                {
                    PPT_METHODTRACE_V2( "", "zone maxCapacity      ", strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[0].maxCapacity );
                    PPT_METHODTRACE_V2( "", "zone availableCapacity", strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[0].availableCapacity );

                    // get wafer count
                    csObjBWS_WaferCount_GetDR_in strBWS_WaferCount_GetDR_in;
                    strBWS_WaferCount_GetDR_in.BWSID  = Inpara.equipmentID;
                    strBWS_WaferCount_GetDR_in.zoneID = strZoneIDs[0];

                    csObjBWS_WaferCount_GetDR_out strBWS_WaferCount_GetDR_out;
                    rc = cs_BWS_WaferCount_GetDR( strBWS_WaferCount_GetDR_out,
                                                  strObjCommonIn,
                                                  strBWS_WaferCount_GetDR_in );

                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "", "cs_BWS_WaferCount_GetDR() != RC_OK, rc=", rc );
                        strBWSSorter_CheckConditionForJobCreate_out.strResult = strBWS_WaferCount_GetDR_out.strResult;
                        return(rc);
                    }

                    availableCapacity = strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[0].maxCapacity;
                    PPT_METHODTRACE_V2( "", "availableCapacity", availableCapacity );

                    if( 0 < CIMFWStrLen(strBWS_WaferCount_GetDR_out.strBWSWaferCount.BWSID.identifier) &&
                        0 < strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq.length() &&
                        0 == CIMFWStrCmp( strZoneIDs[0], strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq[0].zoneID ) )
                    {
                        PPT_METHODTRACE_V2( "", "zone waferCount", strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq[0].waferCount );

                        availableCapacity -= strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq[0].waferCount;
                        PPT_METHODTRACE_V2( "", "calcul. ==> availableCapacity", availableCapacity );
                    }
                    PPT_METHODTRACE_V2( "", "##-- availableCapacity", availableCapacity );

                    lnLenLot = strLotWaferSeq.length();

                    PPT_METHODTRACE_V2( "", "Input wafer count", lnLenLot );

                    if( availableCapacity > lnLenLot )
                    {
                        PPT_METHODTRACE_V1( "", "zone availableCapacity is enough !!!" );
                        bCheckSuccess = TRUE;
                    }
                }
            }

            if( bCheckSuccess == FALSE )
            {
                PPT_METHODTRACE_V1( "", "zone availableCapacity is not enough. " );

                ostrstream errorMsg;
                errorMsg << "Zone " << strZoneIDs[0] << " availableCapacity " << availableCapacity << "is not enough for wafer count " << lnLenLot;
                errorMsg << ends;

                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                    MSG_SORTER_INVALID_PARAMETER,
                                    RC_SORTER_INVALID_PARAMETER,
                                    errorMsg.str() );

                errorMsg.rdbuf()->freeze(0);
                return ( RC_SORTER_INVALID_PARAMETER );
            }

            //-----------------------------------------------------------
            //  lot check
            //-----------------------------------------------------------
            PPT_METHODTRACE_V1( "", "  --- BWSIn check item : (2) lot check -- " );
            lnLenLot = strLotWaferSeq.length();
            for( jx=0; jx<lnLenLot; jx++ )
            {
                PPT_METHODTRACE_V4( "", ix, jx, "      lotID", strLotWaferSeq[jx].lotID.identifier );

                objLot_detailInfo_GetDR_out__160 strLot_detailInfo_GetDR_out;
                rc = lot_detailInfo_GetDR__160( strLot_detailInfo_GetDR_out,
                                                strObjCommonIn,
                                                strLotWaferSeq[jx].lotID,
                                                TRUE,       //lotBasicInfoFlag
                                                FALSE,      //lotControlUseInfoFlag
                                                FALSE,      //lotFlowBatchInfoFlag
                                                FALSE,      //lotNoteFlagInfoFlag
                                                FALSE,      //lotOperationInfoFlag
                                                FALSE,      //lotOrderInfoFlag
                                                FALSE,      //lotControlJobInfoFlag
                                                TRUE,       //lotProductInfoFlag
                                                FALSE,      //lotRecipeInfoFlag
                                                FALSE,      //lotLocationInfoFlag
                                                FALSE,      //lotWipOperationInfoFlag
                                                FALSE,      //lotWaferAttributesFlag
                                                FALSE );    //lotBackupInfoFlag
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2( "", "lot_detailInfo_GetDR() != RC_OK, rc=", rc );
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strLot_detailInfo_GetDR_out.strResult ;
                    return(rc);
                }

                PPT_METHODTRACE_V2( "", "totalWaferCount = ", strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.totalWaferCount );
                PPT_METHODTRACE_V2( "", "bankID          = ", strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.bankID.identifier );
                PPT_METHODTRACE_V2( "", "subLotType      = ", strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.subLotType );
                PPT_METHODTRACE_V2( "", "productID       = ", strLot_detailInfo_GetDR_out.strLotInfo.strLotProductInfo.productID.identifier );

                //-------------------------------------------------------
                //  1-wafer lot check
                //-------------------------------------------------------
                PPT_METHODTRACE_V1( "", "  --- BWSIn check item : (2) lot check -- 1-wafer lot" );
                if( 1 != strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.totalWaferCount )
                {
                    PPT_METHODTRACE_V2( "", "Not allowed if not 1-wafer lot. totalWaferCount =", strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.totalWaferCount );

                    ostrstream errorMsg;
                    errorMsg << "Not allowed if not 1-wafer lot. Lot " << strLotWaferSeq[jx].lotID.identifier << ". wafer count is " << strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.totalWaferCount;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }

                //-------------------------------------------------------
                //  lot in bank check
                //-------------------------------------------------------
                PPT_METHODTRACE_V1( "", "  --- BWSIn check item : (2) lot check -- lot in bank" );

                bCheckSuccess = FALSE;
                CORBA::Long lnLenLotStatus = strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.strLotStatusList.length();
                for( kx=0; kx<lnLenLotStatus; kx++ )
                {
                    if( 0 == CIMFWStrCmp( SP_LotStateCat_InventoryState, strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.strLotStatusList[kx].stateName ) &&
                        0 == CIMFWStrCmp( SP_Lot_InventoryState_InBank,  strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.strLotStatusList[kx].stateValue ) )
                    {
                        bCheckSuccess = TRUE;
                        break;
                    }
                }

                if( bCheckSuccess == FALSE )
                {
                    PPT_METHODTRACE_V1( "", "Not allowed if lot is not in bank. " );

                    ostrstream errorMsg;
                    errorMsg << "Not allowed if lot is not in bank. LotID " << strLotWaferSeq[jx].lotID.identifier;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }

                //-------------------------------------------------------
                //  bLotType check
                //  not allow : vender / scrap /
                //-------------------------------------------------------
                PPT_METHODTRACE_V1( "", "  --- BWSIn check item : (2) lot check -- lot type & lot status" );

                bCheckSuccess = FALSE;
                PPT_METHODTRACE_V2( "", "lotType",   strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.lotType );
                PPT_METHODTRACE_V2( "", "lotStatus", strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.lotStatus );
                if( 0 != CIMFWStrCmp( SP_Lot_Type_VendorLot, strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.lotType ) &&
                    0 != CIMFWStrCmp( SP_LOT_FINISHED_STATE_SCRAPPED, strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.lotStatus ) )
                {
                    bCheckSuccess = TRUE;
                    break;
                }

                if( bCheckSuccess == FALSE )
                {
                    PPT_METHODTRACE_V1( "", "Not allowed if lotType 'Vendor' or lotStatus 'SCRAPPED'. " );

                    ostrstream errorMsg;
                    errorMsg << "Not allowed if lotType 'Vendor' or lotStatus 'SCRAPPED'. LotID " << strLotWaferSeq[jx].lotID.identifier;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }

                //-------------------------------------------------------
                //  specific subLotType check by productID
                //-------------------------------------------------------
                PPT_METHODTRACE_V1( "", "  --- BWSIn check item : (2) lot check -- subLotType" );

                PPT_METHODTRACE_V2( "", "subLotType", strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.subLotType );
                csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
                strEqpMonitorInventory_ListGetDR_in.npwType   = CIMFWStrDup( "" );
                strEqpMonitorInventory_ListGetDR_in.productID = CIMFWStrDup( strLot_detailInfo_GetDR_out.strLotInfo.strLotProductInfo.productID.identifier );

                csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
                rc = cs_eqpMonitorInventory_ListGetDR( strEqpMonitorInventory_ListGetDR_out,
                                                       strObjCommonIn,
                                                       strEqpMonitorInventory_ListGetDR_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "", "cs_eqpMonitorInventory_ListGetDR() != RC_OK, rc=", rc );
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strEqpMonitorInventory_ListGetDR_out.strResult ;
                    return(rc);
                }

                bCheckSuccess = FALSE;
                CORBA::Long lnLenEqpMon = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length();
                for( kx=0; kx<lnLenEqpMon; kx++ )
                {
                    PPT_METHODTRACE_V2( "", "specific subLotType", strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq[kx].subLotType );
                    if( 0 == CIMFWStrCmp( strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.subLotType,
                                          strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq[kx].subLotType ) )
                    {
                        PPT_METHODTRACE_V1( "", "specific subLotType by ProductID match. bCheckSuccess = TRUE. " );

                        bCheckSuccess = TRUE;
                        break;
                    }
                }

                if( lnLenEqpMon == 0 )
                {
                    PPT_METHODTRACE_V1( "", "No specific subLotType from Product, bCheckSuccess = TRUE. " );
                    bCheckSuccess = TRUE;
                }

                if( bCheckSuccess == FALSE )
                {
                    PPT_METHODTRACE_V1( "", "Specific subLotType by ProductID NOT match !!! " );

                    ostrstream errorMsg;
                    errorMsg << "LotID " << strLotWaferSeq[jx].lotID.identifier << ", subLotType " << strLot_detailInfo_GetDR_out.strLotInfo.strLotBasicInfo.subLotType << "not match. The Specific subLotType from ProductID : " << strLot_detailInfo_GetDR_out.strLotInfo.strLotProductInfo.productID.identifier;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }
            }
        }
        else if( 0 == CIMFWStrCmp( actionCode, CS_WaferTransfer_BWSOut ) )
        {
            PPT_METHODTRACE_V1( strTrace, "##### BWS Action is [BWSOut]" );

            //-----------------------------------------------------------
            // BWSOut check item :
            // . zone exist
            // . BWS is defined in Bank(zone) UData
            // . foup available space for wafers
            // . foup category
            // . foup UsageType = BWS UsageType
            // . foup contamination
            //-----------------------------------------------------------
            //-----------------------------------------------------------
            //  Zone Check
            //-----------------------------------------------------------
            PPT_METHODTRACE_V1( "", "  --- BWSIn check item : (1) zoneID  -- " );

            // zoneID in BWS Config ? availableCapacity is enough ?
            PPT_METHODTRACE_V1( "", "   (1) zoneID check -- [2] zoneID in BWS Config ? " );

            for( ix=0; ix<lnLenZone; ix++ )
            {
                csObjBWS_Config_GetDR_in strBWS_Config_GetDR_in;
                strBWS_Config_GetDR_in.BWSID  = Inpara.equipmentID;
                strBWS_Config_GetDR_in.zoneID = strZoneIDs[ix];

                csObjBWS_Config_GetDR_out strBWS_Config_GetDR_out;
                rc = cs_BWS_Config_GetDR( strBWS_Config_GetDR_out,
                                          strObjCommonIn,
                                          strBWS_Config_GetDR_in );

                if( rc != RC_OK && rc != CS_RC_BWS_CONFIG_NOT_FOUND_BWS )
                {
                    PPT_METHODTRACE_V2( "", "cs_BWS_Config_GetDR() != RC_OK, rc=", rc );
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strBWS_Config_GetDR_out.strResult;
                    return(rc);
                }

                CORBA::Long availableCapacity = 0;
                bCheckSuccess = FALSE;
                if( 0 <  strBWS_Config_GetDR_out.strBWSConfigInfoSeq.length() &&
                    0 == CIMFWStrCmp( Inpara.equipmentID.identifier,
                                      strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].BWSID.identifier ) )
                {
                    if( 0 <  strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq.length()  &&
                        0 == CIMFWStrCmp( strZoneIDs[ix],
                                          strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[0].zoneID ) )
                    {
                        PPT_METHODTRACE_V1( "", "Found zoneID definition." );
                        bCheckSuccess = TRUE;
                    }
                }

                if( bCheckSuccess == FALSE )
                {
                    PPT_METHODTRACE_V1( "", "Zone not define in BWS Configuration. " );

                    ostrstream errorMsg;
                    errorMsg << "Zone " << strZoneIDs[ix] << " not define in BWS Configuration. ";
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }
            }

            //-----------------------------------------------------------
            //  Cassette Check
            //-----------------------------------------------------------
            lnLenLot = strLotWaferSeq.length();
            PPT_METHODTRACE_V2( "", "##--- lnLenLot", lnLenLot );

            lnLenCast = strCassetteIDs.length();
            PPT_METHODTRACE_V2( "", "##--- lnLenCast", lnLenCast );
            for( ix=0; ix<lnLenCast; ix++ )
            {
                objCassette_DBInfo_GetDR_in__160  strCassette_DBInfo_GetDR_in;
                strCassette_DBInfo_GetDR_in.cassetteID                  = strCassetteIDs[ix];
                strCassette_DBInfo_GetDR_in.durableOperationInfoFlag    = TRUE;
                strCassette_DBInfo_GetDR_in.durableWipOperationInfoFlag = TRUE;

                objCassette_DBInfo_GetDR_out__170 strCassette_DBInfo_GetDR_out;
                rc = cassette_DBInfo_GetDR__170( strCassette_DBInfo_GetDR_out,
                                                 strObjCommonIn,
                                                 strCassette_DBInfo_GetDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "", "cassette_DBInfo_GetDR__170() != RC_OK, rc=", rc );
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strCassette_DBInfo_GetDR_out.strResult ;
                    return( rc );
                }

                // get waferCount of a cassette
                PosCassette_var aCassette;
                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                       strCassetteIDs[ix],
                                                       strBWSSorter_CheckConditionForJobCreate_out,
                                                       cs_BWS_sorter_CheckConditionForJobCreate );

                LotSequence* aLotSequence = NULL;
                try
                {
                    PPT_DISPLAY_RESPONSE_TIME();
                    aLotSequence = aCassette->allLots();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

                MaterialSequence * materialSeq = NULL;
                MaterialSequence_var materialSeqVar;
                try
                {
                    materialSeq = aCassette->containedMaterial();
                    materialSeqVar = materialSeq;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::containedMaterial)

                CORBA::Long  waferLen;

                waferLen = materialSeq->length();
                PPT_METHODTRACE_V2( "", "waferLen", waferLen );

                PPT_METHODTRACE_V3( "", ix, "capacity",         strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteBRInfo.capacity );
                PPT_METHODTRACE_V3( "", ix, "cassetteCategory", strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteBRInfo.cassetteCategory );

                PPT_METHODTRACE_V2( "", "lnLenLot", lnLenLot );
                if( lnLenLot > (strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteBRInfo.capacity - waferLen ) )
                {
                    PPT_METHODTRACE_V1( "", "Carrier available size is not enough. " );

                    ostrstream errorMsg;
                    errorMsg << "CarrierID " << strCassetteIDs[ix].identifier << " available size is not enough. ";
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }

                PPT_METHODTRACE_V1( "", "Check CarrierCategory of cassette" );
                CORBA::String_var castCategory;
                try
                {
                    castCategory = aCassette->getCassetteCategory();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCassetteCategory)
                PPT_METHODTRACE_V2( "", "castCategory", castCategory );

                // foup UsageType match with BWS's udata S_EQP_BWSUsageType
                // get cassette UsageType
                CORBA::String_var carrierUsageType;
                SI_PPT_USERDATA_GET_STRING( aCassette, CS_M_CAST_UsageType, carrierUsageType );
                PPT_METHODTRACE_V2( "", "carrierUsageType", carrierUsageType );

                // get Eqp udata
                PosMachine_var aMachine;
                PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                                 Inpara.equipmentID,
                                                 strBWSSorter_CheckConditionForJobCreate_out,
                                                 cs_BWS_sorter_CheckConditionForJobCreate );

                CORBA::String_var eqpBWSUsageType;
                SI_PPT_USERDATA_GET_STRING( aMachine, CS_S_EQP_BWSUsageType, eqpBWSUsageType );
                PPT_METHODTRACE_V2( "", "eqpBWSUsageType", eqpBWSUsageType );

                if( 0 != CIMFWStrCmp( carrierUsageType, eqpBWSUsageType ) )
                {
                    PPT_METHODTRACE_V1( "", "Carrier usageType is not the same with BWS UData UsageType. " );

                    ostrstream errorMsg;
                    errorMsg << "Carrier usageType " << carrierUsageType << " is not the same with BWS UData UsageType " << eqpBWSUsageType ;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                        MSG_SORTER_INVALID_PARAMETER,
                                        RC_SORTER_INVALID_PARAMETER,
                                        errorMsg.str() );

                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V2( strTrace, "##### BWS Action is invalid. ", actionCode );

            CS_PPT_SET_MSG_RC_KEY1( strBWSSorter_CheckConditionForJobCreate_out,
                                    CS_MSG_BWS_NOT_ALLOWED_SORTER_ACTION,
                                    CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION,
                                    Inpara.equipmentID.identifier );

            return( CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION );
        }
        //INN-R170017 add end

        //----------------------
        // Component vs Slotmap
        //----------------------
        for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
        {
            //1 Component
            if( 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier,  Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier )
             && 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier,     Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier    ))
            {
                if( srtCmpCnt > 0 )
                {
                    PPT_METHODTRACE_V2("", "Some Component Jobs exist despite being Original the same as Destination.", srtCmpCnt );
                    ostrstream errorMsg;
                    errorMsg << "Some Component Jobs exist despite being Original the same as Destination." << srtCmpCnt;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str() );
                    errorMsg.rdbuf()->freeze(0);

                    return ( RC_SORTER_INVALID_PARAMETER );
                }
            }
            else if( 0 != CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier,  Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier )
                  && 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier,     Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier    ))
            {
                PPT_METHODTRACE_V1("", "Each Port ID is the same despite being Original different from Destination." );
                ostrstream errorMsg;
                errorMsg << "Each Port ID is the same despite being Original different from Destination." ;
                errorMsg << ends;

                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                errorMsg.rdbuf()->freeze(0);

                return ( RC_SORTER_INVALID_PARAMETER );
            }
            else if( 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier,  Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier )
                  && 0 != CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier,     Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier    ))
            {
                PPT_METHODTRACE_V1("", "Each Port ID differs despite being Original the same as Destination." );
                ostrstream errorMsg;
                errorMsg << "Each Port ID differs despite being Original the same as Destination." ;
                errorMsg << ends;

                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                errorMsg.rdbuf()->freeze(0);

                return ( RC_SORTER_INVALID_PARAMETER );
            }
            else
            {
                //OK
            }

            //INN-R170017 add start
            // if( 0 != CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier,  Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier ) )
            // {
            //     PPT_METHODTRACE_V1( "", "For BWS, Original Carrier and Destination Carrier should be the same." );
            //     ostrstream errorMsg;
            //     errorMsg << "For BWS, Original Carrier and Destination Carrier should be the same." ;
            //     errorMsg << ends;
            //
            //     PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
            //     errorMsg.rdbuf()->freeze(0);
            //
            //     return ( RC_SORTER_INVALID_PARAMETER );
            // }
            //
            // if( 0 != CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier ) )
            // {
            //     PPT_METHODTRACE_V1("", "Port ID should be the same." );
            //     ostrstream errorMsg;
            //     errorMsg << "Port ID should be the same." ;
            //     errorMsg << ends;
            //
            //     PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
            //     errorMsg.rdbuf()->freeze(0);
            //
            //     return ( RC_SORTER_INVALID_PARAMETER );
            // }
            //INN-R170017 add end

            slotMapLen = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence.length();
            for(slotMapCnt = 0; slotMapCnt<slotMapLen; slotMapCnt++)    //SlotMap
            {
                PPT_METHODTRACE_V3("", "Component Job info Original CarrierID    ", srtCmpCnt, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier   );
                PPT_METHODTRACE_V3("", "Component Job info Original PortID       ", srtCmpCnt, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier      );
                PPT_METHODTRACE_V3("", "Component Job info Destination CarrierID ", srtCmpCnt, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier);
                PPT_METHODTRACE_V3("", "Component Job info Destination PortID    ", srtCmpCnt, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier   );
                //Component.equipment == SlotMap.equipment
                if( 0 != CIMFWStrCmp( Inpara.equipmentID.identifier,
                                      Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].equipmentID.identifier) )
                {
                    PPT_METHODTRACE_V3("", "EquipmentID is different.",
                                          Inpara.equipmentID.identifier,
                                          Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].equipmentID.identifier);

                    ostrstream errorMsg;
                    errorMsg << "EquipmentID is different." << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].equipmentID.identifier ;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str() );
                    errorMsg.rdbuf()->freeze(0);

                    return ( RC_SORTER_INVALID_PARAMETER );
                }

                //Component.original/destination == SlotMap.original/destination
                if( 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier,    Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].originalCassetteID.identifier    )
                 && 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier,       Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].originalPortID.identifier        )
                 && 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].destinationCassetteID.identifier )
                 && 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier,    Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].destinationPortID.identifier     ))
                {
                    PPT_METHODTRACE_V1("", "Slot Map informaion is also same. OK." );
                }
                else
                {
                    PPT_METHODTRACE_V3("", "SlotMap Job info Original CarrierID    ", slotMapCnt, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].originalCassetteID.identifier    );
                    PPT_METHODTRACE_V3("", "SlotMap Job info Original PortID       ", slotMapCnt, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].originalPortID.identifier        );
                    PPT_METHODTRACE_V3("", "SlotMap Job info Destination CarrierID ", slotMapCnt, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].destinationCassetteID.identifier );
                    PPT_METHODTRACE_V3("", "SlotMap Job info Destination PortID    ", slotMapCnt, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].destinationPortID.identifier     );
                    SET_MSG_RC( strBWSSorter_CheckConditionForJobCreate_out, MSG_INPUT_SORTER_JOB_INFORMATION_DUPLICATE, RC_INPUT_SORTER_JOB_INFORMATION_DUPLICATE );
                    return ( RC_INPUT_SORTER_JOB_INFORMATION_DUPLICATE );
                }

                //------------------------------------------
                //SlotMap Number duplicate ?
                //------------------------------------------
                CORBA::Long orgSlotNum = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].originalSlotNumber;
                CORBA::Long dstSlotNum = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].destinationSlotNumber;
                CORBA::Boolean orgSlotDuplicateFlag = FALSE;
                CORBA::Boolean dstSlotDuplicateFlag = FALSE;
                for( slotMapCnt2 = slotMapCnt + 1 ; slotMapCnt2 < slotMapLen; slotMapCnt2++ )
                {
                    PPT_METHODTRACE_V3("", "Original    SlotMap Number.", orgSlotNum, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt2].originalSlotNumber );
                    PPT_METHODTRACE_V3("", "Destination SlotMap Number.", dstSlotNum, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt2].destinationSlotNumber  );
                    //original
                    if( orgSlotNum == Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt2].originalSlotNumber )
                    {
                        orgSlotDuplicateFlag = TRUE;
                    }
                    //destination
                    if( dstSlotNum == Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt2].destinationSlotNumber )
                    {
                        dstSlotDuplicateFlag = TRUE;
                    }
                }
                if( TRUE== orgSlotDuplicateFlag || TRUE== dstSlotDuplicateFlag )
                {
                    PPT_METHODTRACE_V3("", "Slot Number is duplicated. original/destination ", (orgSlotDuplicateFlag? "True":"False"), (dstSlotDuplicateFlag? "True":"False") )
                    ostrstream errorMsg;
                    errorMsg << "Slot Number is duplicated. original/destination." << (orgSlotDuplicateFlag? "True":"False") << (dstSlotDuplicateFlag? "True":"False") ;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }
            }//Loop of SlotMap
        }//Loop of Component

        //-------------------------
        // Component vs Component
        //-------------------------
        for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
        {
            for( srtCmpCnt2 = srtCmpCnt + 1 ; srtCmpCnt2 < srtCmpLen; srtCmpCnt2++ )    //Component2
            {
                //Component1.originalPortID - Component2.destinationPortID
                if( 0 == CIMFWStrCmp(Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].originalPortID.identifier,
                                     Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].destinationPortID.identifier))
                {
                    PPT_METHODTRACE_V3("", "The Same Port is specified between OriginalPort and DestinationPort in different Component Job. Org/Dst ",
                                           Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].originalPortID.identifier,
                                           Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].destinationPortID.identifier);
                    ostrstream errorMsg;
                    errorMsg << " The Same Port is specified between OriginalPort and DestinationPort in different Component Job." ;
                    errorMsg << " OriginalPortID    " << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].originalPortID.identifier    ;
                    errorMsg << " DestinationPortID " << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].destinationPortID.identifier ;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );
                }

                //Component1.originalCarrierID - Component2.destinationCarrierID
                if( 0 == CIMFWStrCmp(Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].originalCarrierID.identifier,
                                     Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].destinationCarrierID.identifier))
                {
                    PPT_METHODTRACE_V3("", "The Same Carrier is specified between OriginalCarrier and DestinationCarrier in different Component Job. Org/Dst ",
                                           Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].originalPortID.identifier,
                                           Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].destinationPortID.identifier);
                    ostrstream errorMsg;
                    errorMsg << " The Same Carrier is specified between OriginalCarrier and DestinationCarrier in different Component Job."  ;
                    errorMsg << " OriginalPortID    " << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].originalCarrierID.identifier    ;
                    errorMsg << " DestinationPortID " << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].destinationCarrierID.identifier ;
                    errorMsg << ends;

                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                    errorMsg.rdbuf()->freeze(0);
                    return ( RC_SORTER_INVALID_PARAMETER );

                }

                //Component1.SlotMap.lotID  - Component2.SlotMap.lotID
                if( 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXEQC015" )) //Check it when SortJobCreate.
                {
                    slotMapLen  = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].strWaferSorterSlotMapSequence.length();
                    slotMapLen2 = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].strWaferSorterSlotMapSequence.length();
                    for(slotMapCnt = 0; slotMapCnt<slotMapLen; slotMapCnt++)                //Component1.SlotMap
                    {
                        objectIdentifier tmpLotID = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].strWaferSorterSlotMapSequence[slotMapCnt].lotID;
                        CORBA::Boolean lotDuplicateFlag = FALSE;
                        for( slotMapCnt2 = 0  ; slotMapCnt2 < slotMapLen2; slotMapCnt2++ )  //Component2.SlotMap
                        {
                            if( 0 == CIMFWStrCmp(tmpLotID.identifier, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].strWaferSorterSlotMapSequence[slotMapCnt2].lotID.identifier))
                            {
                                lotDuplicateFlag = TRUE;
                                break;
                            }
                        }
                        if( TRUE == lotDuplicateFlag )
                        {
                            PPT_METHODTRACE_V2("", "The Same Lot is specified in different Component Job. LotID ", tmpLotID.identifier);
                            ostrstream errorMsg;
                            errorMsg << " The Same Lot is specified in different Component Job. "  ;
                            errorMsg << " LotID    " << tmpLotID.identifier  ;
                            errorMsg << ends;

                            PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                            errorMsg.rdbuf()->freeze(0);

                            return ( RC_SORTER_INVALID_PARAMETER );
                        }
                    }
                }

                //Component1.destinationCarrierID == Component2.destinationCarrierID
                //Component1.SlotMap.destinationSlotNumber - Component2.SlotMap.destinationSlotNumber
                if( 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].destinationCarrierID.identifier,
                                      Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].destinationCarrierID.identifier ))
                {
                    slotMapLen  = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].strWaferSorterSlotMapSequence.length();
                    slotMapLen2 = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].strWaferSorterSlotMapSequence.length();
                    for(slotMapCnt = 0; slotMapCnt<slotMapLen; slotMapCnt++)    //Component1.SlotMap
                    {
                        CORBA::Long    dstSlotNum           = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].strWaferSorterSlotMapSequence[slotMapCnt].destinationSlotNumber;
                        CORBA::Boolean slotMapDuplicateFlag = FALSE;
                        for( slotMapCnt2 = 0  ; slotMapCnt2 < slotMapLen2; slotMapCnt2++ )  //Component2.SlotMap
                        {
                            if( dstSlotNum == Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].strWaferSorterSlotMapSequence[slotMapCnt2].destinationSlotNumber )
                            {
                                slotMapDuplicateFlag = TRUE;
                                break;
                            }
                        }
                        if( TRUE == slotMapDuplicateFlag )
                        {
                            PPT_METHODTRACE_V2("", "The Destination SlotMap is dupulicated. ", dstSlotNum);
                            ostrstream errorMsg;
                            errorMsg << " The Destination SlotMap is dupulicated. " << dstSlotNum ;
                            errorMsg << ends;

                            PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                            errorMsg.rdbuf()->freeze(0);

                            return ( RC_SORTER_INVALID_PARAMETER );
                        }
                    }
                }
            }//Loop of Component2
        }//Loop of Component

        //------------------------------------------
        // Check MaximumWaferInALot
        //------------------------------------------
        CORBA::Long maxWaferInLot = atoi(getenv(SP_EnvName_MaximumWafersInALot));
        PPT_METHODTRACE_V2("", "Maximum Wafers In A Lot. ", maxWaferInLot );
        CORBA::Long waferCount = 0;
        for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
        {
            waferCount = 0;
            for( srtCmpCnt2 = srtCmpCnt ; srtCmpCnt2 < srtCmpLen; srtCmpCnt2++ )    //Component2
            {
                if( 0 == CIMFWStrCmp( Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].destinationCarrierID.identifier,
                                      Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].destinationCarrierID.identifier ))
                {
                    waferCount = waferCount + Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt2].strWaferSorterSlotMapSequence.length();
                }
            }
            if( waferCount > maxWaferInLot )
            {
                PPT_METHODTRACE_V2("", "Some wafers were specified to the destination slot more than Maximum Wafer In A Lot. ", waferCount);
                ostrstream errorMsg;
                errorMsg << " Some wafers were specified to the destination slot more than Maximum Wafer In A Lot. " ;
                errorMsg << " The count of wafer :" << waferCount << " Maximum Wafer In A Lot :" << maxWaferInLot    ;
                errorMsg << ends;

                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                errorMsg.rdbuf()->freeze(0);
                return ( RC_SORTER_INVALID_PARAMETER );
            }
        }

        //Number of Carrier
        objectIdentifierSequence orgCarrierIDs;
        objectIdentifierSequence dstCarrierIDs;
        orgCarrierIDs.length(0);
        dstCarrierIDs.length(0);
        CORBA::Long orgCarrierCnt = 0 ;
        CORBA::Long dstCarrierCnt = 0 ;
        CORBA::Long i = 0;
        for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
        {
            //originalCarrier
            CORBA::Boolean orgFoundFlag = FALSE;
            for( i = 0; i<orgCarrierCnt; i++)
            {
                if( 0 == CIMFWStrCmp(Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].originalCarrierID.identifier, orgCarrierIDs[i].identifier ))
                {
                    orgFoundFlag = TRUE;
                    break;
                }
            }
            if( FALSE == orgFoundFlag )
            {
                orgCarrierIDs.length( orgCarrierCnt + 1 );
                orgCarrierIDs[orgCarrierCnt] = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].originalCarrierID;
                PPT_METHODTRACE_V3("", "Original Carrier    ", orgCarrierCnt, orgCarrierIDs[orgCarrierCnt].identifier );
                orgCarrierCnt++;
            }

            //destinationCarrier
            CORBA::Boolean dstFoundFlag = FALSE;
            for( i = 0; i<dstCarrierCnt; i++)
            {
                if( 0 == CIMFWStrCmp(Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].destinationCarrierID.identifier, dstCarrierIDs[i].identifier ))
                {
                    dstFoundFlag = TRUE;
                    break;
                }
            }
            if( FALSE == dstFoundFlag )
            {
                dstCarrierIDs.length( dstCarrierCnt + 1 );
                dstCarrierIDs[dstCarrierCnt] = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt ].destinationCarrierID;
                PPT_METHODTRACE_V3("", "Destination Carrier ", dstCarrierCnt, dstCarrierIDs[dstCarrierCnt].identifier );
                dstCarrierCnt++;
            }
        }

        PPT_METHODTRACE_V2( "", "orgCarrierCnt", orgCarrierCnt );
        PPT_METHODTRACE_V2( "", "dstCarrierCnt", dstCarrierCnt );
        if( orgCarrierCnt > 1 && dstCarrierCnt > 1 )
        {
            PPT_METHODTRACE_V3("", " Can not sort in between any OriginalCarriers and any DestinationCarriers.  ", orgCarrierCnt, dstCarrierCnt);
            ostrstream errorMsg;
            errorMsg << " Can not sort in between any OriginalCarriers and any DestinationCarriers. " ;
            errorMsg << " Original Carrier Count :" << orgCarrierCnt << "Destination Carrier Count :" << dstCarrierCnt ;
            errorMsg << ends;

            PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
            errorMsg.rdbuf()->freeze(0);
            return ( RC_SORTER_INVALID_PARAMETER );
        }

        //==============================================================
        //
        // Check the availability Equipment, Port, Carrier, Lot.
        //
        //==============================================================
        PPT_METHODTRACE_V1("", "##### Check Equipment, Port information.");
        //----------------------------------------
        // Equipment and Port
        //----------------------------------------
        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
        rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, Inpara.equipmentID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_portInfo_Get() != RC_OK", rc );
            strBWSSorter_CheckConditionForJobCreate_out.strResult = strEquipment_portInfo_Get_out.strResult;
            return ( rc );
        }

        CORBA::Long portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        CORBA::Long portCnt = 0;
        if(portLen == 0)
        {
            PPT_METHODTRACE_V1("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length() == 0.");
            PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_NOT_FOUND_PORT, RC_NOT_FOUND_PORT, Inpara.portGroupID );
            return ( RC_NOT_FOUND_PORT );
        }

        //----------------------------------------
        // Gather Port Group no-duplicated.
        //----------------------------------------
        CORBA::Long    portGPCnt = 0;
        CORBA::Long    portGPLen = 0;
        stringSequence portGPs;
        portGPs.length(portGPCnt);
        for(portCnt =0; portCnt<portLen; portCnt++)     //Equipment Port
        {
            CORBA::Boolean GPFoundFlag = FALSE;
            portGPLen = portGPs.length();
            for(i=0; i<portGPLen; i++)      //Gathering Port Group
            {
                if( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup, portGPs[i]))
                {
                    GPFoundFlag = TRUE;
                    break;
                }
            }
            if( FALSE == GPFoundFlag )
            {
                PPT_METHODTRACE_V2("", "Port Group ...", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup );
                portGPs.length(portGPCnt + 1 );
                portGPs[portGPCnt++] = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup;
            }
        }

        //------------------------------------------------------------
        //Check the number of port , Inpara.PortGroup existence.
        //------------------------------------------------------------
        CORBA::Long CS_BWS_Sorter_PortCountInPortGroup = 1;  //INN-R170017
        CORBA::Boolean portGPFoundFlag = FALSE;
        portGPLen = portGPs.length();
        CORBA::String_var operationMode;
        for(i=0; i<portGPLen; i++)              //Gathered Port Group
        {
            //------------------------------------------
            // PortGroup ?
            //------------------------------------------
            if( 0 != CIMFWStrCmp( Inpara.portGroupID, portGPs[i] ) )
            {
                PPT_METHODTRACE_V2("", "Port Group is not match. continue...", portGPs[i] );
                continue;
            }
            else
            {
                PPT_METHODTRACE_V2("", "Port Group is found!!", portGPs[i] );
                portGPFoundFlag = TRUE;
            }

            CORBA::Long portCntInPG = 0;
            for(portCnt =0; portCnt<portLen; portCnt++)     //Equipment Port
            {
                if( 0 == CIMFWStrCmp(portGPs[i], strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup ) )
                {
                    //------------------------------------------
                    // Port Load Purpose Type
                    //------------------------------------------
                    if( 0 != CIMFWStrCmp(SP_LoadPurposeType_Other, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].loadPurposeType))
                    {
                        PPT_METHODTRACE_V2("","Port LoadPurposeType is invalid.", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].loadPurposeType);
                        PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_PURPOSE_TYPE_FOR_SORTER, RC_INVALID_PURPOSE_TYPE_FOR_SORTER, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].loadPurposeType);
                        return ( RC_INVALID_PURPOSE_TYPE_FOR_SORTER );
                    }
                    //------------------------------------------
                    // Auto-1, Auto-2
                    //------------------------------------------
                    operationMode = CIMFWStrDup(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].operationMode );
                    PPT_METHODTRACE_V2("", "Equipment operation mode ...", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].operationMode );
                    if( 0 != CIMFWStrCmp( SP_Eqp_Port_OperationMode_Auto_1, operationMode )
                     && 0 != CIMFWStrCmp( SP_Eqp_Port_OperationMode_Auto_2, operationMode ))
                    {
                        PPT_METHODTRACE_V1("", "Equipment operation mode should be Auto-1 or Auto-2." );
                        PPT_SET_MSG_RC_KEY2( strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_EQP_MODE, RC_INVALID_EQP_MODE, Inpara.equipmentID.identifier, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].operationMode );
                        return ( RC_INVALID_EQP_MODE );
                    }
                    portCntInPG++;
                }
            }

            //INN-R170017 //---------------------------------------------
            //INN-R170017 //The number of Port in portGroup should be 2.
            //INN-R170017 //---------------------------------------------
            //INN-R170017 if( portCntInPG > SP_Sorter_PortCountInPortGroup )
            //INN-R170017 {
            //INN-R170017     PPT_METHODTRACE_V3("", "The number of Port in Port Group is more than 3", SP_Sorter_PortCountInPortGroup, portCntInPG );
            //INN-R170017     char strTmpCount[128];
            //INN-R170017     strTmpCount[0] = '\0';
            //INN-R170017     snprintf(strTmpCount,sizeof(strTmpCount),"%d",SP_Sorter_PortCountInPortGroup);
            //INN-R170017     PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_PORT_COUNT_IN_PORTGOUP, RC_INVALID_PORT_COUNT_IN_PORTGOUP, strTmpCount);
            //INN-R170017     return( RC_INVALID_PORT_COUNT_IN_PORTGOUP );
            //INN-R170017 }

            //INN-R170017 add start
            //---------------------------------------------
            //The number of Port in portGroup should be 1 for BWS
            //---------------------------------------------
            if( portCntInPG > CS_BWS_Sorter_PortCountInPortGroup )
            {
                PPT_METHODTRACE_V3("", "The number of Port in Port Group should be 1", CS_BWS_Sorter_PortCountInPortGroup, portCntInPG );
                char strTmpCount[128];
                strTmpCount[0] = '\0';
                snprintf(strTmpCount,sizeof(strTmpCount),"%d",CS_BWS_Sorter_PortCountInPortGroup);
                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_PORT_COUNT_IN_PORTGOUP, RC_INVALID_PORT_COUNT_IN_PORTGOUP, strTmpCount);
                return( RC_INVALID_PORT_COUNT_IN_PORTGOUP );
            }
            //INN-R170017 add end
        }
        if( FALSE == portGPFoundFlag )
        {
            PPT_METHODTRACE_V2("", "Port Group is not exist.", Inpara.portGroupID);
            PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_NOT_FOUND_PORTGROUP, RC_NOT_FOUND_PORTGROUP , Inpara.portGroupID);
            return ( RC_NOT_FOUND_PORTGROUP );
        }

        //------------------------------------------
        // Port , Port Load Sequence Number
        //------------------------------------------
        for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
        {

            PPT_METHODTRACE_V2("", "Original Port    :", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier );
            PPT_METHODTRACE_V2("", "Destination Port :", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier );
            CORBA::Boolean orgPortFoundFlag = FALSE;
            CORBA::Boolean dstPortFoundFlag = FALSE;
            CORBA::Boolean bLoadSeqFlag = FALSE;
            for(portCnt =0; portCnt<portLen; portCnt++)     //Equipment Port
            {
                //---------------
                // Original Port
                //---------------
                if( 0 == CIMFWStrCmp(Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier,
                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier))
                {
                    //Port in Inpara.PortGroup ?
                    if( 0 != CIMFWStrCmp( Inpara.portGroupID, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup) )
                    {
                        PPT_METHODTRACE_V1("", "Original Port ID is not in Port Group.");
                        SET_MSG_RC( strBWSSorter_CheckConditionForJobCreate_out, MSG_PORT_PORTGROUP_UNMATCH, RC_PORT_PORTGROUP_UNMATCH );
                        return RC_PORT_PORTGROUP_UNMATCH;
                    }

                    PPT_METHODTRACE_V2("", "Original Port ID is found.", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier );
                    orgPortFoundFlag = TRUE;

                    //LoadSequence is 1 ?
                    if(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].loadSequenceNumber == 1)
                    {
                        PPT_METHODTRACE_V1("", "originalPort loadSequence is 1 " );
                        bLoadSeqFlag = TRUE;
                    }

                    //Equipment has the Carrier Category ?
                    if( 0 == CIMFWStrCmp( actionCode, CS_WaferTransfer_BWSIn ) )
                    {
                        PPT_METHODTRACE_V2( "", "actionCode is BWSIn  ==> check Eqp carrier Category, originalCarrierID=", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier );

                        objCassetteCategory_portCapability_CheckForContaminationControl_out strCassetteCategory_portCapability_CheckForContaminationControl_out;

                        rc = cassetteCategory_portCapability_CheckForContaminationControl(strCassetteCategory_portCapability_CheckForContaminationControl_out,
                                                                                          strObjCommonIn,
                                                                                          Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID,
                                                                                          Inpara.equipmentID,
                                                                                          Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "cassetteCategory_portCapability_CheckForContaminationControl() != RC_OK" );
                            strBWSSorter_CheckConditionForJobCreate_out.strResult = strCassetteCategory_portCapability_CheckForContaminationControl_out.strResult;
                            return( rc );
                        }
                    }
                }

                //-------------------
                // Destination Port
                //-------------------
                if( 0 == CIMFWStrCmp(Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier,
                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier))
                {
                    //Port in Inpara.PortGroup ?
                    if( 0 != CIMFWStrCmp( Inpara.portGroupID, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup) )
                    {
                        PPT_METHODTRACE_V1("", "Desination Port ID is not in Port Group.");
                        SET_MSG_RC( strBWSSorter_CheckConditionForJobCreate_out, MSG_PORT_PORTGROUP_UNMATCH, RC_PORT_PORTGROUP_UNMATCH );
                        return ( RC_PORT_PORTGROUP_UNMATCH );
                    }

                    PPT_METHODTRACE_V2("", "Original Port ID is found.", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier );
                    dstPortFoundFlag = TRUE;

                    if(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].loadSequenceNumber == 1)
                    {
                        PPT_METHODTRACE_V1("", "destinationPort loadSequence is 1 " );
                        bLoadSeqFlag = TRUE;
                    }

                    //Equipment has the Carrier Category ?
                    if( 0 == CIMFWStrCmp( actionCode, CS_WaferTransfer_BWSOut ) )
                    {
                        PPT_METHODTRACE_V2( "", "actionCode is BWSOut  ==> check Eqp carrier Category, destinationCarrierID=", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier );

                        objCassetteCategory_portCapability_CheckForContaminationControl_out strCassetteCategory_portCapability_CheckForContaminationControl_out;

                        rc = cassetteCategory_portCapability_CheckForContaminationControl(strCassetteCategory_portCapability_CheckForContaminationControl_out,
                                                                                          strObjCommonIn,
                                                                                          Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID,
                                                                                          Inpara.equipmentID,
                                                                                          Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "cassetteCategory_portCapability_CheckForContaminationControl() != RC_OK" );
                            strBWSSorter_CheckConditionForJobCreate_out.strResult = strCassetteCategory_portCapability_CheckForContaminationControl_out.strResult;
                            return( rc );
                        }
                    }
                }
            }// Loop of Equipment Port

            //------------------------------------------
            // Port ?
            //------------------------------------------
            if( FALSE == orgPortFoundFlag || FALSE == dstPortFoundFlag )
            {
                PPT_METHODTRACE_V1("", "Original/Destination Port is not found.");
                ostrstream errorMsg;
                if( FALSE == orgPortFoundFlag )
                {
                    errorMsg << " Original Port:"    << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalPortID.identifier ;
                }
                if( FALSE == dstPortFoundFlag )
                {
                    errorMsg << " Destination Port:" << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationPortID.identifier;
                }
                errorMsg << ends;

                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_NOT_FOUND_PORT, RC_NOT_FOUND_PORT, errorMsg.str());
                errorMsg.rdbuf()->freeze(0);
                return ( RC_NOT_FOUND_PORT );
            }

            //------------------------------------------
            // Load Sequence is 1?
            //------------------------------------------
            if( FALSE == bLoadSeqFlag )
            {
                PPT_METHODTRACE_V1("", "Port LoadSequnece is not correct.");
                ostrstream errorMsg;
                errorMsg << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier <<  "," ;
                errorMsg << Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier;
                errorMsg << ends;

                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_LOADING_SEQ, RC_INVALID_LOADING_SEQ, errorMsg.str());
                errorMsg.rdbuf()->freeze(0);
                return ( RC_INVALID_LOADING_SEQ );
            }
        }//Loop of Component

        //-------------------------------------------------------
        // Operation Mode Auto-1 (Original:Destination / 1 : 1)
        //-------------------------------------------------------
        //INN-R170017 if( 0 == CIMFWStrCmp( operationMode, SP_Eqp_Port_OperationMode_Auto_1 ) )
        //INN-R170017 {
            if( orgCarrierCnt > 1 || dstCarrierCnt > 1 )
            {
                //for BWS PPT_METHODTRACE_V3("", " Can not create Sort Job when Port Operation Mode is 'Auto-1'. ", orgCarrierCnt, dstCarrierCnt);
                PPT_METHODTRACE_V3("", " Can not create Sort Job when processing BWS. ", orgCarrierCnt, dstCarrierCnt);
                ostrstream errorMsg;
                //for BWS errorMsg << " Can not create Sort Job when Port Operation Mode is 'Auto-1'." ;
                errorMsg << " Can not create Sort Job when processing BWS. " ;
                errorMsg << " Original Carrier Count :" << orgCarrierCnt << "Destination Carrier Count :" << dstCarrierCnt ;
                errorMsg << ends;

                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                errorMsg.rdbuf()->freeze(0);
                return ( RC_SORTER_INVALID_PARAMETER );
            }
        //INN-R170017 }


        //------------------------------------------
        // Equipment Category "WaferSorter" ?
        //------------------------------------------
        PPT_METHODTRACE_V1("", "Check Equipment Category" );
        PosMachine_var aPosMachine;
        CORBA::String_var equipmentCategory;
        PPT_CONVERT_EQPID_TO_MACHINE_OR(aPosMachine, Inpara.equipmentID, strBWSSorter_CheckConditionForJobCreate_out, sorter_CheckConditionForJobCreate);
        try
        {
            equipmentCategory = aPosMachine->getCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory)
        PPT_METHODTRACE_V2("","aPosMachine->getCategory()", equipmentCategory);

        if( 0 != CIMFWStrCmp(equipmentCategory, SP_Mc_Category_WaferSorter) )
        {
            PPT_METHODTRACE_V2("", "Machine Category is not WaferSorter ",equipmentCategory);
            PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_MACHINE_TYPE_NOT_SORTER, RC_MACHINE_TYPE_NOT_SORTER, equipmentCategory);

            return ( RC_MACHINE_TYPE_NOT_SORTER );
        }

        //------------------------------------------
        // Equipment is available ??
        //------------------------------------------
        PPT_METHODTRACE_V1("", "Check Equipment Availability" );
        objEquipment_CheckAvail_out strEquipment_CheckAvail_out;
        rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn, Inpara.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_CheckAvail() rc != RC_OK", rc);
            strBWSSorter_CheckConditionForJobCreate_out.strResult = strEquipment_CheckAvail_out.strResult;
            return rc;
        }

        //------------------------------------------
        // Equipment has the some inhibitions?
        //------------------------------------------
        pptEntityInhibitAttributes entityInhibitAttributes;
        entityInhibitAttributes.entities.length(1);
        entityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
        entityInhibitAttributes.entities[0].objectID  = Inpara.equipmentID;

        objEntityInhibit_CheckForEntities_out strEntityInhibit_CheckForEntities_out;
        rc = entityInhibit_CheckForEntities( strEntityInhibit_CheckForEntities_out,  strObjCommonIn, entityInhibitAttributes );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "entityInhibit_CheckForEntities() != RC_OK", rc);
            strBWSSorter_CheckConditionForJobCreate_out.strResult = strEntityInhibit_CheckForEntities_out.strResult;
            return rc;
        }

        PPT_METHODTRACE_V2("", "The number of entity inhibition .. ", strEntityInhibit_CheckForEntities_out.entityInhibitInfo.length() );
        if (strEntityInhibit_CheckForEntities_out.entityInhibitInfo.length() > 0)
        {
            PPT_SET_MSG_RC_KEY2( strBWSSorter_CheckConditionForJobCreate_out, MSG_INHIBIT_ENTITY, RC_INHIBIT_ENTITY, Inpara.equipmentID.identifier, SP_InhibitClassID_Equipment )
            return ( RC_INHIBIT_ENTITY );
        }

        //-------------------------------------
        // Carrier has had already Sort Job ?
        //-------------------------------------
        PPT_METHODTRACE_V1("", "Carrier has had already Sort Job ? ");

        CORBA::Long orgCarrierLen = orgCarrierIDs.length();
        CORBA::Long dstCarrierLen = dstCarrierIDs.length();

        CORBA::Long allCarrierLen = orgCarrierIDs.length() + dstCarrierIDs.length();
        CORBA::Long allCarrierCnt = 0 ;

        objectIdentifierSequence allCarrierIDs;
        allCarrierIDs.length(allCarrierLen);

        for(i=0; i<orgCarrierLen; i++)    allCarrierIDs[allCarrierCnt++] = orgCarrierIDs[i];
        for(i=0; i<dstCarrierLen; i++)    allCarrierIDs[allCarrierCnt++] = dstCarrierIDs[i];

        for(i=0; i<allCarrierLen; i++)
        {
            objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;
            objSorter_jobList_GetDR_in  strSorter_jobList_GetDR_in;
            strSorter_jobList_GetDR_in.carrierID = allCarrierIDs[i];
            PPT_METHODTRACE_V2("", "Get Sort job information by Carrier ID ..", allCarrierIDs[i].identifier );

            rc = sorter_jobList_GetDR( strSorter_jobList_GetDR_out, strObjCommonIn, strSorter_jobList_GetDR_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "sorter_jobList_GetDR() != RC_OK", rc);
                strBWSSorter_CheckConditionForJobCreate_out.strResult = strSorter_jobList_GetDR_out.strResult;
                return rc;
            }
            if( 0 < strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length() )
            {
                PPT_METHODTRACE_V2("", "The specified Carrier has had already Sort Job.", allCarrierIDs[i].identifier );
                PPT_SET_MSG_RC_KEY2( strBWSSorter_CheckConditionForJobCreate_out, MSG_EXIST_SORTERJOB_FOR_CASSETTE, RC_EXIST_SORTERJOB_FOR_CASSETTE,
                                     allCarrierIDs[i].identifier, strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0].sorterJobID.identifier );
                return ( RC_EXIST_SORTERJOB_FOR_CASSETTE );
            }
        }

//DSIV00000099 add start
        //-------------------------------------------------------------------
        // Check if carrier is reserved for retrieving lot on SLM operation
        //-------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check if carrier is reserved for retrieving lot on SLM operation.");

        for( i=0; i < allCarrierLen; i++ )
        {
            /*-------------------------*/
            /*   Get Cassette Object   */
            /*-------------------------*/
            PosCassette_var tempCast = PosCassette::_nil();
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( tempCast,
                                                   allCarrierIDs[i],
                                                   strBWSSorter_CheckConditionForJobCreate_out,
                                                   sorter_CheckConditionForJobCreate );

            /*-----------------------------*/
            /*   Get SLMReserved Machine   */
            /*-----------------------------*/
            PPT_METHODTRACE_V1("", "Try to get SLM reserved equipment.");
            PosMachine_var aSLMRsvMachine = PosMachine::_nil();
            try
            {
                aSLMRsvMachine = tempCast->getSLMReservedMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosCassette::getSLMReservedMachine );

            if( ! CORBA::is_nil(aSLMRsvMachine) )
            {
                PPT_METHODTRACE_V2("", "The specified Carrier is reserved for SLM operation.", allCarrierIDs[i].identifier );
                PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_ALREADY_RESERVED_CAST_SLM, RC_ALREADY_RESERVED_CAST_SLM,
                                    allCarrierIDs[i].identifier );
                return ( RC_ALREADY_RESERVED_CAST_SLM );
            }
        }
//DSIV00000099 add End

        //------------------------------------------------------------------------------
        // If Operation Mode is Auto-1, the portGroup can have only one Sort Job.
        //------------------------------------------------------------------------------
//PSIV00000956         PPT_METHODTRACE_V2("", "If Operation Mode is Auto-1, the equipment can have only one Sort Job." ,operationMode );
//PSIV00000956 Add Start
        PPT_METHODTRACE_V2("", "If Operation Mode is Auto-1, the equipment can have only one Sort Job." ,operationMode );
        if( 0 == CIMFWStrCmp(operationMode, SP_Eqp_Port_OperationMode_Auto_1) )
        {
            PPT_METHODTRACE_V1("", "operationMode = Auto-1");
//PSIV00000956 Add End
            objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;
            objSorter_jobList_GetDR_in  strSorter_jobList_GetDR_in;
            strSorter_jobList_GetDR_in.equipmentID = Inpara.equipmentID;
            PPT_METHODTRACE_V2("", "Get Sort job information by Equipment ID ..", Inpara.equipmentID.identifier );

            rc = sorter_jobList_GetDR( strSorter_jobList_GetDR_out, strObjCommonIn, strSorter_jobList_GetDR_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "sorter_jobList_GetDR() != RC_OK", rc);
                strBWSSorter_CheckConditionForJobCreate_out.strResult = strSorter_jobList_GetDR_out.strResult;
                return rc;
            }
//PSIV00000956 Add Start
            CORBA::ULong strSortJobListAttributesSeqLen = strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length();
            PPT_METHODTRACE_V2("", "strSortJobListAttributesSeqLen = ", strSortJobListAttributesSeqLen);
            if (strSortJobListAttributesSeqLen > 0)
            {
                PPT_METHODTRACE_V1("", "strSortJobListAttributesSeqLen > 0 ");

                CORBA::ULong nCnt = 0;
                for (nCnt = 0; nCnt < strSortJobListAttributesSeqLen; nCnt++)
                {
                    PPT_METHODTRACE_V3("", "SortJob on Port Group",
                                        strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[nCnt].sorterJobID.identifier,
                                        strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[nCnt].portGroupID.identifier);

                    if ( 0 == CIMFWStrCmp( Inpara.portGroupID, strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[nCnt].portGroupID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "Existing sort job on the same port group.");
                        PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_ALREADY_EXIST_SORTER_JOB_INFORMATION, RC_ALREADY_EXIST_SORTER_JOB_INFORMATION,
                                            strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[nCnt].sorterJobID.identifier );
                        return ( RC_ALREADY_EXIST_SORTER_JOB_INFORMATION );
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "No sort jobs for the equipment");
            }
//PSIV00000956 Add End
//PSIV00000956             if( 0 == CIMFWStrCmp(operationMode, SP_Eqp_Port_OperationMode_Auto_1) )
//PSIV00000956             {
//PSIV00000956                 if( 0 < strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length() )
//PSIV00000956                 {
//PSIV00000956                     PPT_METHODTRACE_V1("", "Operation Mode The specified Carrier has had already Sort Job." );
//PSIV00000956                     PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_ALREADY_EXIST_SORTER_JOB_INFORMATION, RC_ALREADY_EXIST_SORTER_JOB_INFORMATION,
//PSIV00000956                                         strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0].sorterJobID.identifier );
//PSIV00000956                     return ( RC_ALREADY_EXIST_SORTER_JOB_INFORMATION );
//PSIV00000956                 }
//PSIV00000956             }
        }       //PSIV0000095

        //----------------------------------------
        // Carrier
        //----------------------------------------
        PPT_METHODTRACE_V1("", "##### Check Carrier Information. ");
        orgCarrierLen = orgCarrierIDs.length();
        dstCarrierLen = dstCarrierIDs.length();

        if( 0 == CIMFWStrCmp( actionCode, CS_WaferTransfer_BWSIn ) ) //INN-R170017
        {                                                            //INN-R170017
        //-----------------------
        // Original Carrier
        //-----------------------
        for(i=0; i<orgCarrierLen; i++)
        {
            //-------------------------------------------
            // Slot Map position is correct?
            //-------------------------------------------
            //------------------------------
            // Get slot map information
            //------------------------------
            objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
            rc = cassette_GetWaferMapDR(strCassette_GetWaferMapDR_out, strObjCommonIn, orgCarrierIDs[i]);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK", rc);
                strBWSSorter_CheckConditionForJobCreate_out.strResult = strCassette_GetWaferMapDR_out.strResult;
                return rc;
            }

            for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
            {
                if( 0 == CIMFWStrCmp( orgCarrierIDs[i].identifier, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier ))
                {
                    PPT_METHODTRACE_V2("","Inpara.Original Carrier ID ", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].originalCarrierID.identifier );
                    slotMapLen = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence.length();
                    for(slotMapCnt = 0; slotMapCnt<slotMapLen; slotMapCnt++)    //SlotMap
                    {
                        objectIdentifier InWaferID;
                        objectIdentifier InLotID;
                        InWaferID.identifier  = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].waferID.identifier;
                        InLotID.identifier    = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID.identifier;
                        CORBA::Long InSlotNum = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].originalSlotNumber;

                        CORBA::Boolean waferSlotMapFoundFlag = FALSE;
                        CORBA::Long    mapInCassetteLen = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();
                        CORBA::Long    mapInCassetteCnt = 0;
                        for(mapInCassetteCnt = 0; mapInCassetteCnt < mapInCassetteLen; mapInCassetteCnt++)   //Get map information
                        {
                            if( 0 == CIMFWStrCmp( InLotID.identifier,   strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[mapInCassetteCnt].lotID.identifier   )
                             && 0 == CIMFWStrCmp( InWaferID.identifier, strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[mapInCassetteCnt].waferID.identifier )
                             && (                 InSlotNum          == strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[mapInCassetteCnt].slotNumber         ))
                            {
                                PPT_METHODTRACE_V4("","Found in the Carrier. LotID / WaferID / SlotNumber", InLotID.identifier,  InWaferID.identifier, InSlotNum);
                                waferSlotMapFoundFlag = TRUE;
                                break;
                            }
                        }//Loop of mapInCassetteLen
                        if( FALSE == waferSlotMapFoundFlag )
                        {
                            PPT_METHODTRACE_V4("","NOT Found in the Carrier. LotID / WaferID / SlotNumber", InLotID.identifier,  InWaferID.identifier, InSlotNum);
                            char strInSlotNum[128];
                            strInSlotNum[0] = '\0';
                            snprintf(strInSlotNum,sizeof(strInSlotNum),"%d",InSlotNum);
                            PPT_SET_MSG_RC_KEY3(strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_ORG_WAFER_POSITION, RC_INVALID_ORG_WAFER_POSITION,
                                                InWaferID.identifier, orgCarrierIDs[i].identifier, strInSlotNum);
                            return ( RC_INVALID_ORG_WAFER_POSITION );
                        }
                    }//Loop of slotMapLen
                }
            }//Loop of srtCmpLen
        }//Loop of original Carrier
        }//INN-R170017

        if( 0 == CIMFWStrCmp( actionCode, CS_WaferTransfer_BWSOut ) ) //INN-R170017
        {                                                             //INN-R170017
        //----------------------
        // Destination Carrier
        //----------------------
        for(i=0; i<dstCarrierLen; i++)
        {
            //--------------------------------
            // Get Empty Slot of Carrier
            //--------------------------------
            longSequence*    nEmptyPositions = NULL;
            longSequence_var nTmpEmptyPositions;

            PosCassette_var aPosDestCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosDestCassette, dstCarrierIDs[i], strBWSSorter_CheckConditionForJobCreate_out, sorter_CheckConditionForJobCreate);
            try
            {
                nEmptyPositions = aPosDestCassette->emptyPositions();
                nTmpEmptyPositions = nEmptyPositions;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::emptyPositions)

            CORBA::Long lenEmptyPos          = nEmptyPositions->length();

            for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
            {
                if( 0 == CIMFWStrCmp( dstCarrierIDs[i].identifier, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier ))
                {
                    PPT_METHODTRACE_V2("","Inpara.Destination Carrier ID ", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].destinationCarrierID.identifier );
                    slotMapLen = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence.length();
                    for(slotMapCnt = 0; slotMapCnt<slotMapLen; slotMapCnt++)    //SlotMap
                    {
                        CORBA::Boolean emptySlotFindFlag = FALSE;
                        PPT_METHODTRACE_V2("","Inpara.Destination Slot Map Number ", Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].destinationSlotNumber);
                        CORBA::Long IndstSlotNum = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].destinationSlotNumber;
                        for ( CORBA::Long empSlotCnt = 0; empSlotCnt < lenEmptyPos; empSlotCnt++ )    //empty position
                        {
                            PPT_METHODTRACE_V2("","# check destinationCassette Move Wafer condition -----------------------------", empSlotCnt);
                            PPT_METHODTRACE_V2("","input destinationSlotNumber =", IndstSlotNum);
                            PPT_METHODTRACE_V2("","destCast emptySlotNumber    =", (*nEmptyPositions)[empSlotCnt]);

                            if ( IndstSlotNum == (*nEmptyPositions)[empSlotCnt] )
                            {
                                PPT_METHODTRACE_V1("","input destinationSlotNumber == (*nEmptyPositions)[empSlotCnt], destinationSlot is empty.");
                                emptySlotFindFlag = TRUE;
                                break;
                            }
                        }
                        if( FALSE == emptySlotFindFlag )
                        {
                            PPT_METHODTRACE_V1("","destinationCassette Move Wafer Info is invalid! error.");
                            char strIndstSlotNum[128];
                            strIndstSlotNum[0] = '\0';
                            snprintf(strIndstSlotNum,sizeof(strIndstSlotNum),"%d",IndstSlotNum);
                            PPT_SET_MSG_RC_KEY3( strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_DEST_WAFER_POSITION, RC_INVALID_DEST_WAFER_POSITION,
                                                 Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].waferID.identifier,
                                                 dstCarrierIDs[i].identifier, strIndstSlotNum );
                            return( RC_INVALID_DEST_WAFER_POSITION );
                        }
                    }//Loop of slotMapLen
                }
            }//Loop of srtCmpLen

            //------------------------
            // Status is available ?
            //------------------------
            PPT_METHODTRACE_V1("", "### Check Destination Carrier Status");
            PPT_METHODTRACE_V2("", "  carrierID ", dstCarrierIDs[i].identifier);

            PosCassette_var aCassette = PosCassette::_nil();
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, dstCarrierIDs[i], strBWSSorter_CheckConditionForJobCreate_out, sorter_CheckConditionForJobCreate);

            CORBA::String_var cassetteState = CIMFWStrDup("");
            try
            {
                cassetteState = aCassette->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableState);

            //INN-R170017 if (CIMFWStrCmp(cassetteState, CIMFW_Durable_Available) == 0)
            if (CIMFWStrCmp(cassetteState, CIMFW_Durable_Available) == 0 || CIMFWStrCmp(cassetteState, CIMFW_Durable_InUse) == 0)//INN-R170017
            {
                PPT_METHODTRACE_V1("", "Carrier Status OK. ");
            }
            else
            {
                PPT_METHODTRACE_V2("", "Carrier Status is 'NOTAVAILABLE'. ", cassetteState);
                try
                {
                    CORBA::String_var cassetteIdent;
                    cassetteIdent = aCassette->getIdentifier();
                    PPT_SET_MSG_RC_KEY2(strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_CAST_STAT, RC_INVALID_CAST_STAT, cassetteState, cassetteIdent);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier);
                return ( RC_INVALID_CAST_STAT );
            }
        }//Loop of Destination Carrier
        }//INN-R170017
        //----------------------------------
        // Original/Destination Carrier
        //----------------------------------
        PPT_METHODTRACE_V1("","Original / Destination Carrier ");
        allCarrierLen = allCarrierIDs.length();
        for(allCarrierCnt = 0; allCarrierCnt< allCarrierLen; allCarrierCnt++)
        {
            PPT_METHODTRACE_V2("","Carrier ID ",allCarrierIDs[allCarrierCnt].identifier );
            //------------------------------------
            // Lot in Carrier has control Job ?
            //------------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out, strObjCommonIn, allCarrierIDs[allCarrierCnt] );
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() rc != RC_OK");
                strBWSSorter_CheckConditionForJobCreate_out.strResult = strCassette_controlJobID_Get_out.strResult;
                return rc;
            }

            if ( 0 != CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier))
            {
                PPT_METHODTRACE_V2("", "Carrier has controlJob", allCarrierIDs[allCarrierCnt].identifier);
                SET_MSG_RC( strBWSSorter_CheckConditionForJobCreate_out, MSG_CAST_CTRLJOBID_FILLED, RC_CAST_CTRLJOBID_FILLED );
                return ( RC_CAST_CTRLJOBID_FILLED );
            }
            PPT_METHODTRACE_V2("", "Carrier does NOT have controlJob. OK.", allCarrierIDs[allCarrierCnt].identifier);

            //------------------------------------
            // Carrier Xfer status is EI ?
            //------------------------------------
            objCassette_transferState_Get_out strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out, strObjCommonIn, allCarrierIDs[allCarrierCnt] );
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "cassette_transferState_Get() rc != RC_OK");
                strBWSSorter_CheckConditionForJobCreate_out.strResult = strCassette_transferState_Get_out.strResult;
                return rc;
            }

            PPT_METHODTRACE_V2("", "Carrier Xfer Status.. ", strCassette_transferState_Get_out.transferState);
            if( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ))
            {
                PPT_METHODTRACE_V2("", "Can not create sort job with Carrier Xfer Status EquipmentIn. ", strCassette_transferState_Get_out.transferState);
                PPT_SET_MSG_RC_KEY2( strBWSSorter_CheckConditionForJobCreate_out, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                     strCassette_transferState_Get_out.transferState, allCarrierIDs[allCarrierCnt].identifier );
                return ( RC_INVALID_CAST_XFERSTAT );
            }
            PPT_METHODTRACE_V1("", "Carrier Xfer Status. OK. ");

            //---------------------------------------
            // Carrier is reserved for dispatching?
            //---------------------------------------
            objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
            strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE;         //Initialize.
            rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn, allCarrierIDs[allCarrierCnt] );
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "cassette_dispatchState_Get() rc != RC_OK");
                strBWSSorter_CheckConditionForJobCreate_out.strResult = strCassette_dispatchState_Get_out.strResult;
                return rc;
            }

            PPT_METHODTRACE_V2("", "Carrier is reserved for dispatching ?", (strCassette_dispatchState_Get_out.dispatchReservedFlag? "True":"False") );
            if( TRUE == strCassette_dispatchState_Get_out.dispatchReservedFlag )
            {
                PPT_METHODTRACE_V1("", "cassette_dispatchState_Get cassette is reserved");
                SET_MSG_RC(strBWSSorter_CheckConditionForJobCreate_out, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST);
                return( RC_ALREADY_DISPATCH_RESVED_CST );
            }
            PPT_METHODTRACE_V1("", "Carrier is NOT reserved for dispatching. OK");

        }//Loop of allCarrier


        //----------------------------------------
        // Lot
        //----------------------------------------
        PPT_METHODTRACE_V1("", "##### Check Lot Information.");
        allCarrierLen = allCarrierIDs.length();
        for(allCarrierCnt = 0; allCarrierCnt< allCarrierLen; allCarrierCnt++)
        {
            objCassette_lotList_GetDR_out strCassette_lotList_GetDR_out;
            rc = cassette_lotList_GetDR( strCassette_lotList_GetDR_out, strObjCommonIn, allCarrierIDs[allCarrierCnt] );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2(strTrace, "cassette_lotList_GetDR() rc != RC_OK", rc);
                strBWSSorter_CheckConditionForJobCreate_out.strResult = strCassette_lotList_GetDR_out.strResult;
                return( rc );
            }

            CORBA::Long lotLen = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID.length();
            CORBA::Long lotCnt = 0;
            for(lotCnt =0; lotCnt<lotLen; lotCnt++)
            {
                PPT_METHODTRACE_V2("", "Check Lot condition in Carrier.", strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt].identifier );
                //----------------------------
                // Flow Batching ?
                //----------------------------
                PPT_METHODTRACE_V1("", "Flow Batched Lot ? " );
                objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
                rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt] );

                if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK || rc == RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_flowBatchID_GetDR() == RC_LOT_FLOW_BATCH_ID_BLANK or RC_OK, check OK!");
                }
                else if( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
                {
                    PPT_METHODTRACE_V1("", "lot_flowBatchID_GetDR() == RC_LOT_FLOW_BATCH_ID_FILLED, check NG");
                    SET_MSG_RC(strBWSSorter_CheckConditionForJobCreate_out, MSG_LOT_FLOW_BATCH_ID_FILLED, RC_LOT_FLOW_BATCH_ID_FILLED );
                    return( RC_LOT_FLOW_BATCH_ID_FILLED );
                }
                else
                {
                    PPT_METHODTRACE_V2("", "lot_flowBatchID_GetDR() != RC_OK, rc =", rc);
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strLot_flowBatchID_Get_out.strResult;
                    return( rc );
                }

                //----------------------------
                // In Back Up Site ?
                //----------------------------
                PPT_METHODTRACE_V1("", "Lot locates in Back Up Site ?" );
                objLot_backupInfo_Get_out strLot_backupInfo_Get_out;
                rc = lot_backupInfo_Get( strLot_backupInfo_Get_out, strObjCommonIn, strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt] );
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", " lot_backupInfo_Get() rc != RC_OK");
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strLot_backupInfo_Get_out.strResult ;
                    return( rc );
                }

                if ( FALSE == strLot_backupInfo_Get_out.strLotBackupInfo.currentLocationFlag ||
                     TRUE  == strLot_backupInfo_Get_out.strLotBackupInfo.transferFlag  )
                {
                    PPT_METHODTRACE_V1("", "##### backup condition is invalid.");
                    PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_LOT_IN_OTHERSITE,  RC_LOT_IN_OTHERSITE, strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt].identifier );
                    return( RC_LOT_IN_OTHERSITE );
                }
            }

            if( 0 != strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID.length() )
            {
                //-----------------------------
                // In PostProcessing ?
                //-----------------------------
//DSIV00000214  objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
//DSIV00000214  rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID );
//DSIV00000214  if( rc != RC_OK )
//DSIV00000214  {
//DSIV00000214      PPT_METHODTRACE_V1("", "lot_CheckLockHoldConditionForOperation rc != RC_OK");
//DSIV00000214      strBWSSorter_CheckConditionForJobCreate_out.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
//DSIV00000214      return ( rc );
//DSIV00000214  }
//DSIV00000214 add start
                //------------------------------------
                // Check LOCK Hold.
                //------------------------------------
                PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
                for( CORBA::ULong count = 0 ; count < lotLen ; count++ )
                {
                    //----------------------------------
                    //  Check lot InterFabXfer state
                    //----------------------------------
                    objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

                    objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
                    strLot_interFabXferState_Get_in.lotID = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[count];

                    rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                                    strObjCommonIn,
                                                    strLot_interFabXferState_Get_in );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", " #### lot_interFabXferState_Get() != RC_OK");
                        strBWSSorter_CheckConditionForJobCreate_out.strResult = strLot_interFabXferState_Get_out.strResult;
                        return (rc);
                    }

                    if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required ))
                    {
                        PPT_METHODTRACE_V1("", " #### The Lot interFabXfer state is required... No need to check LOCK Hold. ");
                        continue;
                    }

                    objectIdentifierSequence ckLotIDSeq;
                    ckLotIDSeq.length(1);
                    ckLotIDSeq[0] = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[count];

                    objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
                    rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, ckLotIDSeq );

                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", ckLotIDSeq[0].identifier );
                        strBWSSorter_CheckConditionForJobCreate_out.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
                        return ( rc );
                    }
                }
//DSIV00000214 add end

                //--------------------------------------
                // Equipment is available for LOT ?
                //--------------------------------------
                PPT_METHODTRACE_V1(" ", "call equipment_CheckAvailForLot()");
                objEquipment_CheckAvailForLot_out  strEquipment_CheckAvailForLot_out;
                rc = equipment_CheckAvailForLot( strEquipment_CheckAvailForLot_out, strObjCommonIn, Inpara.equipmentID, strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2(" ", "equipment_CheckAvailForLot() != RC_OK", rc);
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strEquipment_CheckAvailForLot_out.strResult;
                    return( rc );
                }
            }

//D9000056 add start
            PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
//DSIV00000201 Add Start
            objectIdentifierSequence userGroupIDs;
            userGroupIDs.length(0);
            CORBA::ULong userGroupIDsLen = userGroupIDs.length();

//DSIV00000201 Add End
            for( lotCnt = 0; lotCnt < lotLen; lotCnt++ )
            {
                //----------------------------------
                //  Get InPostProcessFlag of Lot
                //----------------------------------
                objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
                objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
                strLot_inPostProcessFlag_Get_in.lotID = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt];

                rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Get_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strLot_inPostProcessFlag_Get_out.strResult;
                    return( rc );
                }

//DSIV00000214 add start
                //----------------------------------
                //  Check lot InterFabXfer state
                //----------------------------------
                objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

                objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
                strLot_interFabXferState_Get_in.lotID = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt];

                rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                                strObjCommonIn,
                                                strLot_interFabXferState_Get_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", " #### lot_interFabXferState_Get() != RC_OK");
                    strBWSSorter_CheckConditionForJobCreate_out.strResult = strLot_interFabXferState_Get_out.strResult;
                    return (rc);
                }
//DSIV00000214 add end

                //----------------------------------------------
                //  If Lot is in post process, returns error
                //----------------------------------------------
                if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
                {
                    PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000214 add start
                    if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required ))
                    {
                        PPT_METHODTRACE_V1("", " #### The Lot interFabXfer state is required... No need to check post process flag. ");
                        continue;
                    }
//DSIV00000214 add end
//DSIV00000201 Add Start
                    if (userGroupIDsLen == 0)
                    {
                        /*---------------------------*/
                        /* Get UserGroupID By UserID */
                        /*---------------------------*/
                        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
                        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                                         strObjCommonIn,
                                                         strObjCommonIn.strUser.userID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                            strBWSSorter_CheckConditionForJobCreate_out.strResult = strPerson_userGroupList_GetDR_out.strResult;
                            return( rc );
                        }
                        userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
                        userGroupIDsLen = userGroupIDs.length();
                        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
                    }
                    CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
                    PPT_METHODTRACE_V2("", "extPostProc", extPostProc);

                    CORBA::ULong nCnt = 0;
                    for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
                    {
                        PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                        if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                        {
                            PPT_METHODTRACE_V1("", "# External Post Process User!");
                            break;
                        }

                    }
                    if (nCnt == userGroupIDsLen)
                    {
                        PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                        PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out,
                                            MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                            strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt].identifier );
                        return( RC_LOT_INPOSTPROCESS );
                    }
                }   //DSIV00000201
            }
//D9000056 add end
        }

        if( 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXEQC015" ) &&  //Check it when SortJobCreate.
            (1 == dstCarrierLen && 1 == orgCarrierLen)  &&
            0 != CIMFWStrCmp(dstCarrierIDs[0].identifier, orgCarrierIDs[0].identifier)
          )
        {
            //-----------------------------------------
            //  Check existence of all wafer in Lot.
            //-----------------------------------------
            PPT_METHODTRACE_V1("", "##### Check existence of all wafer in Lot.(check for creation.)");
            for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
            {
                slotMapLen = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence.length();
                for(slotMapCnt = 0; slotMapCnt<slotMapLen; slotMapCnt++)                //Component.SlotMap
                {
                    objectIdentifier tmpLotID  = Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID;

                    PosLot_var aLot;
                    PPT_CONVERT_LOTID_TO_LOT_OR( aLot, tmpLotID, strBWSSorter_CheckConditionForJobCreate_out, sorter_CheckConditionForJobCreate);

                    //------------------------------------------------------
                    // Get all wafer information of  Lot
                    //------------------------------------------------------
                    PPT_METHODTRACE_V2("","Get all wafer information of  Lot", tmpLotID.identifier );
                    PosWaferInfoSequence*    lotWaferInfo = NULL;
                    PosWaferInfoSequence_var lotWaferInfoVar;
                    try
                    {
                        lotWaferInfo    = aLot->getAllWaferInfo();
                        lotWaferInfoVar = lotWaferInfo;
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getAllWaferInfo)

                    if(lotWaferInfo == NULL)
                    {
                        PPT_METHODTRACE_V1("","lotWaferInfo == NULL");
                        SET_MSG_RC( strBWSSorter_CheckConditionForJobCreate_out, MSG_PRODUCT_COUNT_ZERO, RC_PRODUCT_COUNT_ZERO );
                        return RC_PRODUCT_COUNT_ZERO;
                    }

                    CORBA::Long lotWaferCount = lotWaferInfo->length();
                    PPT_METHODTRACE_V2("","lotWaferInfo->length()",lotWaferCount );
                    if ( 0 == lotWaferCount )
                    {
                        PPT_METHODTRACE_V1("","0 == lotWaferCount" );
                        SET_MSG_RC( strBWSSorter_CheckConditionForJobCreate_out, MSG_PRODUCT_COUNT_ZERO, RC_PRODUCT_COUNT_ZERO );
                        return RC_PRODUCT_COUNT_ZERO;
                    }

                    CORBA::Long inparaLotWaferCount = 0;
                    for( slotMapCnt2 = 0  ; slotMapCnt2 < slotMapLen; slotMapCnt2++ )  //Component.SlotMap
                    {
                        if( 0 == CIMFWStrCmp(tmpLotID.identifier, Inpara.strSorterComponentJobListAttributesSequence[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt2].lotID.identifier))
                        {
                            inparaLotWaferCount++;
                        }
                    }
                    PPT_METHODTRACE_V3("","Inpara Lot/WaferCount", tmpLotID.identifier, inparaLotWaferCount );

                    if( inparaLotWaferCount != lotWaferCount )
                    {
                        PPT_METHODTRACE_V3("", "All wafers do NOT exist in the requested Lot of Sort Job Information. Inpara/Actual", inparaLotWaferCount, lotWaferCount );
                        ostrstream errorMsg;
                        errorMsg << " All wafers do NOT exist in the requested Lot of Sort Job Information. ( Lot ID:" << tmpLotID.identifier;
                        errorMsg << " Inputed Lot Wafer count :" << inparaLotWaferCount   ;
                        errorMsg << " Actual  Lot Wafer count :" << lotWaferCount  << " )" ;
                        errorMsg << ends;

                        PPT_SET_MSG_RC_KEY( strBWSSorter_CheckConditionForJobCreate_out, MSG_SORTER_INVALID_PARAMETER, RC_SORTER_INVALID_PARAMETER, errorMsg.str());
                        errorMsg.rdbuf()->freeze(0);

                        return ( RC_SORTER_INVALID_PARAMETER );
                    }
                }
            }
        }

        //--------------------------------------------------------------
        //  Return to Caller
        //--------------------------------------------------------------
        PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_BWS_sorter_CheckConditionForJobCreate");
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strBWSSorter_CheckConditionForJobCreate_out, cs_BWS_sorter_CheckConditionForJobCreate, methodName)
}
