static char sqla_program_id[292] = 
{
 0,172,69,65,81,65,73,65,56,65,107,84,77,79,76,104,48,49,49,49,
 49,32,50,32,32,32,32,32,32,32,32,32,0,8,73,78,83,84,68,69,
 86,49,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,8,67,83,66,87,83,85,48,49,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {' ',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "csbwsu01.sqx"
// (c) Copyright: IBM Japan Services Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: csbws01s.sqx
//

// [History]
// Date       Defect       Name         Description
// ---------- ------------ ------------ ----------------------------------------------
// 2017/10/18 INN-R170017  LiHejing     BWS WaferList, Config
// 2017/10/20 INN-R170017  Cheng Li     Add csfsbwscfgdb.h, csfsbwscfg_zonedb.h
// 2017/10/30 INN-R170017  Cheng Li     Add declare of totalcount
//

#include "cs_pptmgr.hpp"
#include "private/txnadmin.hpp"

#ifdef __toFoolPreCompiler__

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 20 "csbwsu01.sqx"

    
/*
EXEC SQL INCLUDE 'csfsbws_zonedb.h';
*/

#line 1 "/home/instdev1/mm/include/csppt/csfsbws_zonedb.h"
//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  LiHejing       INN-R170017          Initial Release
//
char             hCSFSBWS_ZONEBWS_ID[65];
char             hCSFSBWS_ZONEZONE_ID[65];
sqlint32         hCSFSBWS_ZONEWAFER_COUNT;

#line 21 "csbwsu01.sqx"

    
/*
EXEC SQL INCLUDE 'csfsbwsdb.h';
*/

#line 1 "/home/instdev1/mm/include/csppt/csfsbwsdb.h"
//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  LiHejing       INN-R170017          Initial Release
//
char             hCSFSBWSBWS_ID[65];
sqlint32         hCSFSBWSWAFER_COUNT;
char             hCSFSBWSCLAIM_TIME[27];
char             hCSFSBWSCLAIM_USER_ID[65];
char             hCSFSBWSCLAIM_MEMO[257];

#line 22 "csbwsu01.sqx"

    
/*
EXEC SQL INCLUDE 'csfsbws_waferdb.h';
*/

#line 1 "/home/instdev1/mm/include/csppt/csfsbws_waferdb.h"
//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  LiHejing       INN-R170017          Initial Release
//
char             hCSFSBWS_WAFERBWS_ID[65];
char             hCSFSBWS_WAFERZONE_ID[65];
char             hCSFSBWS_WAFERWAFER_ID[65];
char             hCSFSBWS_WAFERWAFERGRADE_ID[65];
char             hCSFSBWS_WAFERLOT_ID[65];
char             hCSFSBWS_WAFERBANK_ID[65];

#line 23 "csbwsu01.sqx"

    
/*
EXEC SQL INCLUDE 'csfsbwscfgdb.h';
*/

#line 1 "/home/instdev1/mm/include/csppt/csfsbwscfgdb.h"
//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  Cheng Li       INN-R170017          Initial Release
//
char             hCSFSBWSCFGBWS_ID[65];
sqlint32         hCSFSBWSCFGMAX_CAPACITY;
char             hCSFSBWSCFGCLAIM_TIME[27];
char             hCSFSBWSCFGCLAIM_USER_ID[65];
char             hCSFSBWSCFGCLAIM_MEMO[257];

#line 24 "csbwsu01.sqx"

    
/*
EXEC SQL INCLUDE 'csfsbwscfg_zonedb.h';
*/

#line 1 "/home/instdev1/mm/include/csppt/csfsbwscfg_zonedb.h"
//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  Cheng Li       INN-R170017          Initial Release
//
char             hCSFSBWSCFG_ZONEBWS_ID[65];
char             hCSFSBWSCFG_ZONEZONE_ID[65];
sqlint32         hCSFSBWSCFG_ZONEMAX_CAPACITY;
char             hCSFSBWSCFG_ZONECLAIM_TIME[27];
char             hCSFSBWSCFG_ZONECLAIM_USER_ID[65];
char             hCSFSBWSCFG_ZONECLAIM_MEMO[257];

#line 25 "csbwsu01.sqx"

    sqlint32 totalcount;


/*
EXEC SQL END DECLARE SECTION;
*/

#line 28 "csbwsu01.sqx"

#endif

#define PPT_PUSH_ACCESS_CONTROL(function)\
{\
    IM_PUSH_ACCESS_CONTROL("CSFSBWS", function);\
    IM_PUSH_ACCESS_CONTROL("CSFSBWS_ZONE", function);\
    IM_PUSH_ACCESS_CONTROL("CSFSBWS_WAFER", function);\
    IM_PUSH_ACCESS_CONTROL("CSFSBWSCFG", function);\
    IM_PUSH_ACCESS_CONTROL("CSFSBWSCFG_ZONE", function);\
}


/*
EXEC SQL INCLUDE 'cs_BWS_Config_AddDR.dr';
*/

#line 1 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_BWS_Config_AddDR.dr
//
// Class: CS_PPTManager
//
// Service: cs_BWS_Config_AddDR()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/16 INN-R170017 Cheng Li       Bare Wafer Stocker BWS Config Add
//
//[Function Description]:
//  Add BWS Configuration Information
//
// [Input Parameters]:
//  const pptObjCommonIn&                 strObjCommonIn
//  const csObjBWS_Config_AddDR_in&       strBWS_Config_AddDR_in
//  const char *                          claimMemo
//
//typedef struct csObjBWS_Config_AddDR_in_struct {
//    csBWSConfigInfo                     strBWSConfigInfo
//    any                                 siInfo;
//} csObjBWS_Config_AddDR_in;
//
//typedef struct csBWSConfigInfo_struct {
//    objectIdentifier           BWSID;                    //BWS ID
//    long                       maxCapacity;              //Maximum capacity of BWS
//    long                       availableCapacity;         //Available capacity of BWS
//    csZoneConfigInfoSequence   strZoneConfigInfoSeq;      //BWSZoneInfo
//    string                     claimTime;
//    objectIdentifier           claimUserID;
//    string                     claimMemo;
//    any siInfo;                                           //<i>Reserved for SI customization
//} csBWSConfigInfo;
//
//typedef struct csZoneConfigInfo_struct {
//   string                  zoneID;                       //zoneID
//    long                    maxCapacity;                  //Maximum capacity of Zone
//    long                    availableCapacity;            //Available capacity of Zone
//    string                  claimTime;
//    objectIdentifier        claimUserID;
//   string                  claimMemo;
//    any                     siInfo;                       //<i>Reserved for SI customization
//}csZoneConfigInfo;
//
//tpedef sequence <csZoneConfigInfo> csZoneConfigInfoSequence;
//
//[Output Parameters]:
//  csObjBWS_Config_AddDR_out&       strBWS_Config_AddDR_out
//
//  typedef objBase_out csObjBWS_Config_AddDR_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_LOCKED_BY_ANOTHER               MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//
CORBA::Long CS_PPTManager_i::cs_BWS_Config_AddDR(
        csObjBWS_Config_AddDR_out&        strBWS_Config_AddDR_out,
        const pptObjCommonIn&             strObjCommonIn,
        const csObjBWS_Config_AddDR_in&   strBWS_Config_AddDR_in,
        const char *                      claimMemo)
{
    char*    methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_BWS_Config_AddDR");
        PPT_PUSH_ACCESS_CONTROL("cs_BWS_Config_AddDR");

        //---------------------------------------
        //  Initialize
        // ---------------------------------------
        sqlca sqlca;
        CORBA::ULong totalcount;

        #include "csfsbwscfgdb.h"
        #include "csfsbwscfg_zonedb.h"

        //---------------------------------------
        //  Check BWS ID
        //---------------------------------------
        PPT_METHODTRACE_V2("", "in-para BWSID ", strBWS_Config_AddDR_in.strBWSConfigInfo.BWSID.identifier);
        PPT_METHODTRACE_V2("", "in-para maxCapacity ", strBWS_Config_AddDR_in.strBWSConfigInfo.maxCapacity);
        if (0 == CIMFWStrLen(strBWS_Config_AddDR_in.strBWSConfigInfo.BWSID.identifier))
        {
            PPT_METHODTRACE_V1("", "INVALID_INPUT_PARM!!");
            SET_MSG_RC(strBWS_Config_AddDR_out,
                       MSG_INVALID_INPUT_PARM,
                       RC_INVALID_INPUT_PARM);
            return (RC_INVALID_INPUT_PARM);
        }

        //---------------------------------------
        //  Initialize
        //---------------------------------------
        memset(hCSFSBWSCFGBWS_ID,        '\0', sizeof(hCSFSBWSCFGBWS_ID) );
        hCSFSBWSCFGMAX_CAPACITY = 0;
        memset(hCSFSBWSCFGCLAIM_TIME,    '\0', sizeof(hCSFSBWSCFGCLAIM_TIME));
        memset(hCSFSBWSCFGCLAIM_USER_ID, '\0', sizeof(hCSFSBWSCFGCLAIM_USER_ID));
        memset(hCSFSBWSCFGCLAIM_MEMO,    '\0', sizeof(hCSFSBWSCFGCLAIM_MEMO));

        SP_SET_HOSTVARIABLE(hCSFSBWSCFGBWS_ID, strBWS_Config_AddDR_in.strBWSConfigInfo.BWSID.identifier);
        hCSFSBWSCFGMAX_CAPACITY = strBWS_Config_AddDR_in.strBWSConfigInfo.maxCapacity;
        SP_SET_HOSTVARIABLE(hCSFSBWSCFGCLAIM_TIME, strObjCommonIn.strTimeStamp.reportTimeStamp);
        SP_SET_HOSTVARIABLE(hCSFSBWSCFGCLAIM_USER_ID, strObjCommonIn.strUser.userID.identifier);
        SP_SET_HOSTVARIABLE(hCSFSBWSCFGCLAIM_MEMO, claimMemo);

        //---------------------------------------
        //  Insert CSFSBWSCFG
        //---------------------------------------
        PPT_METHODTRACE_V1("", "Get BWS to check whether in BWS CFG");
        totalcount = 0;

        
/*
EXEC SQL SELECT COUNT(BWS_ID)
                 INTO :totalcount
                 FROM CSFSBWSCFG
                 WHERE BWS_ID = :hCSFSBWSCFGBWS_ID;
*/

{
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlaaloc(2,1,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSCFGBWS_ID;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlaaloc(3,1,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)&totalcount;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlacall((unsigned short)24,1,2,3,0L);
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlastop(0L);
}

#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"


        if (SQLCODE != 0)
        {
            SET_DR_MSG_RC(strBWS_Config_AddDR_out,
                              cs_BWS_Config_AddDR,
                              MSG_SYSTEM_ERROR, 
                              RC_SYSTEM_ERROR,
                              SQL SELECT COUNT (CSFSBWSCFG), SQLCODE ) ;
            return (RC_SYSTEM_ERROR);           
        }

            
        PPT_METHODTRACE_V2("", "SQL SELECT COUNT(*) FROM CSFSBWSCFG", totalcount);
        
        if (totalcount == 0)
        {
            PPT_METHODTRACE_V1("", "Insert into CSFSBWSCFG");
        
            
/*
EXEC SQL
            INSERT INTO CSFSBWSCFG
            (
                BWS_ID, 
                MAX_CAPACITY, 
                CLAIM_TIME, 
                CLAIM_USER_ID, 
                CLAIM_MEMO
                )VALUES (  
                      :hCSFSBWSCFGBWS_ID,
                      :hCSFSBWSCFGMAX_CAPACITY,
                      :hCSFSBWSCFGCLAIM_TIME,
                      :hCSFSBWSCFGCLAIM_USER_ID,
                      :hCSFSBWSCFGCLAIM_MEMO 
                );
*/

{
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlaaloc(2,5,3,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSCFGBWS_ID;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[1].sqltype = 496; sql_setdlist[1].sqllen = 4;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[1].sqldata = (void*)&hCSFSBWSCFGMAX_CAPACITY;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 27;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWSCFGCLAIM_TIME;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 65;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWSCFGCLAIM_USER_ID;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 257;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSBWSCFGCLAIM_MEMO;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlacall((unsigned short)24,2,2,0,0L);
#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlastop(0L);
}

#line 159 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"

        
            if (SQLCODE != 0)
            {
                if ( SQLCODE == -803 )
                {
                    PPT_METHODTRACE_V1("", "SQL INSERT INTO CSFSBWSCFG -- -803");
                    CS_PPT_SET_MSG_RC_KEY1( strBWS_Config_AddDR_out,
                                    CS_MSG_BWS_CONFIG_DUPLICATE_BWSID,
                                    CS_RC_BWS_CONFIG_DUPLICATE_BWSID,
                                    strBWS_Config_AddDR_in.strBWSConfigInfo.BWSID.identifier);
                    return (CS_RC_BWS_CONFIG_DUPLICATE_BWSID);
                }
                if (SQLCODE == SP_SQL_BUSY)
                {
                    PPT_METHODTRACE_V1("", "SQL INSERT INTO CSFSBWSCFG -- SP_SQL_BUSY");
                    SET_DR_MSG_RC(strBWS_Config_AddDR_out,
                                  cs_BWS_Config_AddDR,
                                  MSG_LOCKED_BY_ANOTHER,
                                  RC_LOCKED_BY_ANOTHER,
                                  SQL INSERT (CSFSBWSCFG),
                            SQLCODE );
                    return (RC_LOCKED_BY_ANOTHER);
                }
                else
                {
                    PPT_METHODTRACE_V1("", "SQL INSERT INTO CSFSBWSCFG -- SYSTEM ERROR");
        
                    SET_DR_MSG_RC(strBWS_Config_AddDR_out,
                                  cs_BWS_Config_AddDR,
                                  MSG_SYSTEM_ERROR,
                                  RC_SYSTEM_ERROR,
                                  SQL INSERT (CSFSBWSCFG),
                            SQLCODE );
                    return (RC_SYSTEM_ERROR);
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "Insert into CSFSBWSCFG OK");
                rc = RC_OK;
            }
        }


        //---------------------------------------
        //  Insert CSFSBWSCFG_ZONE
        //---------------------------------------
        CORBA::Long lnLenZone = strBWS_Config_AddDR_in.strBWSConfigInfo.strZoneConfigInfoSeq.length();
        PPT_METHODTRACE_V1("", "Go Insert into CSFSBWSCFG_ZONE");
        PPT_METHODTRACE_V2("", "lnLenZone", lnLenZone);
        for (CORBA::Long ix = 0; ix < lnLenZone; ix++)
        {
            PPT_METHODTRACE_V3("", ix, "in-para zoneID ",
                               strBWS_Config_AddDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID);
            PPT_METHODTRACE_V3("", ix, "in-para maxCapacity ",
                               strBWS_Config_AddDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].maxCapacity);


            memset(hCSFSBWSCFG_ZONEBWS_ID, '\0', sizeof(hCSFSBWSCFG_ZONEBWS_ID));
            memset(hCSFSBWSCFG_ZONEZONE_ID, '\0', sizeof(hCSFSBWSCFG_ZONEZONE_ID));
            hCSFSBWSCFG_ZONEMAX_CAPACITY = 0;
            memset(hCSFSBWSCFG_ZONECLAIM_TIME, '\0', sizeof(hCSFSBWSCFG_ZONECLAIM_TIME));
            memset(hCSFSBWSCFG_ZONECLAIM_USER_ID, '\0', sizeof(hCSFSBWSCFG_ZONECLAIM_USER_ID));
            memset(hCSFSBWSCFG_ZONECLAIM_MEMO, '\0', sizeof(hCSFSBWSCFG_ZONECLAIM_MEMO));

            SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONEBWS_ID, strBWS_Config_AddDR_in.strBWSConfigInfo.BWSID.identifier);
            SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONEZONE_ID, strBWS_Config_AddDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID);

            hCSFSBWSCFG_ZONEMAX_CAPACITY = strBWS_Config_AddDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].maxCapacity;

            SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONECLAIM_TIME, strObjCommonIn.strTimeStamp.reportTimeStamp);
            SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONECLAIM_USER_ID, strObjCommonIn.strUser.userID.identifier);
            SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONECLAIM_MEMO, claimMemo);

            
/*
EXEC SQL
            INSERT INTO CSFSBWSCFG_ZONE
                    (
                        BWS_ID,
                        ZONE_ID,
                        MAX_CAPACITY,
                        CLAIM_TIME,
                        CLAIM_USER_ID,
                        CLAIM_MEMO
                    ) VALUES (
                              :hCSFSBWSCFG_ZONEBWS_ID,
                              :hCSFSBWSCFG_ZONEZONE_ID,
                              :hCSFSBWSCFG_ZONEMAX_CAPACITY,
                              :hCSFSBWSCFG_ZONECLAIM_TIME,
                              :hCSFSBWSCFG_ZONECLAIM_USER_ID,
                              :hCSFSBWSCFG_ZONECLAIM_MEMO
                    );
*/

{
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlaaloc(2,6,4,0L);
    {
      struct sqla_setdata_list sql_setdlist[6];
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSCFG_ZONEBWS_ID;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWSCFG_ZONEZONE_ID;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[2].sqldata = (void*)&hCSFSBWSCFG_ZONEMAX_CAPACITY;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 27;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_TIME;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_USER_ID;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 257;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[5].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_MEMO;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sql_setdlist[5].sqlind = 0L;
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
      sqlasetdata(2,0,6,sql_setdlist,0L,0L);
    }
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlacall((unsigned short)24,3,2,0,0L);
#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"
  sqlastop(0L);
}

#line 250 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_AddDR.dr"


            if (SQLCODE != 0)
            {
                if ( SQLCODE == -803 )
                {
                    PPT_METHODTRACE_V1("", "SQL INSERT INTO CSFSBWSCFG_ZONE -- -803");
                    CS_PPT_SET_MSG_RC_KEY1( strBWS_Config_AddDR_out,
                                    CS_MSG_BWS_CONFIG_DUPLICATE_ZONEID,
                                    CS_RC_BWS_CONFIG_DUPLICATE_ZONEID,
                                    strBWS_Config_AddDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID);
                    return (CS_RC_BWS_CONFIG_DUPLICATE_ZONEID);
                }
                if (SQLCODE == SP_SQL_BUSY)
                {
                    PPT_METHODTRACE_V1("", "SQLCODE == SP_SQL_BUSY");
                    SET_DR_MSG_RC(strBWS_Config_AddDR_out,
                                  cs_BWS_Config_AddDR,
                                  MSG_LOCKED_BY_ANOTHER,
                                  RC_LOCKED_BY_ANOTHER,
                                  SQL INSERT (CSFSBWSCFG_ZONE),
                            SQLCODE );
                    return (RC_LOCKED_BY_ANOTHER);
                }
                else
                {
                    PPT_METHODTRACE_V1("", "SQL INSERT INTO CSFSBWSCFG_ZONE--SYSTEM ERROR");
                    SET_DR_MSG_RC(strBWS_Config_AddDR_out,
                                  cs_BWS_Config_AddDR,
                                  MSG_SYSTEM_ERROR,
                                  RC_SYSTEM_ERROR,
                                  SQL INSERT (CSFSBWSCFG_ZONE),
                            SQLCODE );

                    return (RC_SYSTEM_ERROR);
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "Do Insert into CSFSBWSCFG_ZONE");
                rc = RC_OK;
            }
        }
        PPT_METHODTRACE_V1("", "Insert into CSFSBWSCFG_ZONE OK");

        //---------------------------------------
        //  Return
        //---------------------------------------
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_BWS_Config_AddDR");
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBWS_Config_AddDR_out, cs_BWS_Config_AddDR, methodName);
}
#line 40 "csbwsu01.sqx"


/*
EXEC SQL INCLUDE 'cs_BWS_Config_UpdateDR.dr';
*/

#line 1 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
//
//
// SiView
// Name: cs_BWS_Config_UpdateDR.dr
//
// Class: CS_PPTManager
//
// Service: cs_BWS_Config_UpdateDR()
//
// Change history:
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2017/10/19 R170017   Cheng Li       Bare wafer Stocker BWS Config Update
//
//[Function Description]:
//  Get BWS Configuration Information
//
// [Input Parameters]:
//  const pptObjCommonIn&                 strObjCommonIn
//  const csObjBWS_Config_UpdateDR_in&    strBWS_Config_UpdateDR_in
//  const char *                          claimMemo
//
//[Output Parameters]:
//  csObjBWS_Config_UpdateDR_out&       strBWS_Config_UpdateDR_out
//
// [Return Value]:
//
//
CORBA::Long CS_PPTManager_i::cs_BWS_Config_UpdateDR(
        csObjBWS_Config_UpdateDR_out&         strBWS_Config_UpdateDR_out,
        const pptObjCommonIn&                 strObjCommonIn,
        const csObjBWS_Config_UpdateDR_in&    strBWS_Config_UpdateDR_in,
        const char *                          claimMemo)
{
    char*    methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_BWS_Config_UpdateDR");
        PPT_PUSH_ACCESS_CONTROL("cs_BWS_Config_UpdateDR");
        //---------------------------------------
        //  Initialize
        //---------------------------------------

        sqlca sqlca;
        CORBA::Long totalcount;
        #include "csfsbwscfgdb.h"
        #include "csfsbwscfg_zonedb.h"

        //---------------------------------------
        //  Check BWS ID
        //---------------------------------------

        PPT_METHODTRACE_V2("", "in-para BWSID ", strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier);
        if (0 == CIMFWStrLen(strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier))
        {
            PPT_METHODTRACE_V1("", "INVALID_INPUT_PARM!!");

            SET_MSG_RC(strBWS_Config_UpdateDR_out, 
                       MSG_INVALID_INPUT_PARM, 
                       RC_INVALID_INPUT_PARM);
            return (RC_INVALID_INPUT_PARM);

        }

        //---------------------------------------
        //  Update CSFSBWSCFG
        //---------------------------------------

        //csBWSConfigInfo strBWSConfigInfo;

        memset(hCSFSBWSCFGBWS_ID, '\0', sizeof(hCSFSBWSCFGBWS_ID));
        SP_SET_HOSTVARIABLE(hCSFSBWSCFGBWS_ID, strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier)
        hCSFSBWSCFGMAX_CAPACITY = 0;
        memset(hCSFSBWSCFGCLAIM_TIME, '\0', sizeof(hCSFSBWSCFGCLAIM_TIME));
        memset(hCSFSBWSCFGCLAIM_USER_ID, '\0', sizeof(hCSFSBWSCFGCLAIM_USER_ID));
        memset(hCSFSBWSCFGCLAIM_MEMO, '\0', sizeof(hCSFSBWSCFGCLAIM_MEMO));


        
/*
EXEC SQL
        SELECT MAX_CAPACITY, CLAIM_TIME, CLAIM_USER_ID, CLAIM_MEMO
        INTO   :hCSFSBWSCFGMAX_CAPACITY,
               :hCSFSBWSCFGCLAIM_TIME,
               :hCSFSBWSCFGCLAIM_USER_ID,
               :hCSFSBWSCFGCLAIM_MEMO
        FROM CSFSBWSCFG
        WHERE BWS_ID = :hCSFSBWSCFGBWS_ID
        FOR READ ONLY;
*/

{
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlaaloc(2,1,5,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSCFGBWS_ID;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlaaloc(3,4,6,0L);
    {
      struct sqla_setdata_list sql_setdlist[4];
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqldata = (void*)&hCSFSBWSCFGMAX_CAPACITY;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 27;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWSCFGCLAIM_TIME;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 65;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWSCFGCLAIM_USER_ID;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 257;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWSCFGCLAIM_MEMO;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sqlasetdata(3,0,4,sql_setdlist,0L,0L);
    }
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlacall((unsigned short)24,4,2,3,0L);
#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlastop(0L);
}

#line 87 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"


        if (SQLCODE != 0)
        {
            if (SQLCODE == SP_SQL_NOT_FOUND)
            {
                PPT_METHODTRACE_V1("", "SQLCODE == SP_SQL_NOT_FOUND");
                CS_PPT_SET_MSG_RC_KEY1(strBWS_Config_UpdateDR_out,
                              CS_MSG_BWS_CONFIG_NOT_FOUND_BWS,
                              CS_RC_BWS_CONFIG_NOT_FOUND_BWS,
                              strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier);
                return (CS_RC_BWS_CONFIG_NOT_FOUND_BWS);
            }
            else if (SQLCODE == SP_SQL_BUSY)
            {
                PPT_METHODTRACE_V1("", "SQLCODE == SP_SQL_BUSY");

                SET_DR_MSG_RC(strBWS_Config_UpdateDR_out,
                              cs_BWS_Config_UpdateDR,
                              MSG_LOCKED_BY_ANOTHER,
                              RC_LOCKED_BY_ANOTHER,
                              SQL FETCH (CSFSBWSCFG) LOCKED_BY_ANOTHER,
                        SQLCODE );
                return (RC_LOCKED_BY_ANOTHER);
            }
            else
            {
                PPT_METHODTRACE_V2("", "SELECT SQL FROM CSFSBWS -- SYSTEM_ERROR ", SQLCODE);

                SET_DR_MSG_RC(strBWS_Config_UpdateDR_out,
                              cs_BWS_Config_UpdateDR,
                              MSG_SYSTEM_ERROR,
                              RC_SYSTEM_ERROR,
                              SQL FETCH (CSFSBWSCFG) SYSTEM_ERROR,
                        SQLCODE );
                return (RC_SYSTEM_ERROR);
            }
        }
        else
        {
            //strBWSConfigInfo.BWSID.identifier = CIMFWStrDup(hCSFSBWSCFGBWS_ID);
            //strBWSConfigInfo.BWSID.stringifiedObjectReference = CIMFWStrDup("");
            //strBWSConfigInfo.maxCapacity = hCSFSBWSCFGMAX_CAPACITY;
            //strBWSConfigInfo.availableCapacity = 0;
            //strBWSConfigInfo.claimTime = CIMFWStrDup(hCSFSBWSCFGCLAIM_TIME);
            //strBWSConfigInfo.claimUserID.identifier = CIMFWStrDup(hCSFSBWSCFGCLAIM_USER_ID);
            //strBWSConfigInfo.claimUserID.stringifiedObjectReference = CIMFWStrDup("");
            //strBWSConfigInfo.claimMemo = CIMFWStrDup(hCSFSBWSCFGCLAIM_MEMO);

            //---------------------------------------
            //  Update CSFSBWSCFG
            //---------------------------------------

            if (strBWS_Config_UpdateDR_in.strBWSConfigInfo.maxCapacity > 0)
            {
                PPT_METHODTRACE_V2("", "Update CSFSBWSCFG. BWS_ID ",
                strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier);

                hCSFSBWSCFGMAX_CAPACITY = 0;
                memset(hCSFSBWSCFGCLAIM_TIME, '\0', sizeof(hCSFSBWSCFGCLAIM_TIME));
                memset(hCSFSBWSCFGCLAIM_USER_ID, '\0', sizeof(hCSFSBWSCFGCLAIM_USER_ID));
                memset(hCSFSBWSCFGCLAIM_MEMO, '\0', sizeof(hCSFSBWSCFGCLAIM_MEMO));

                hCSFSBWSCFGMAX_CAPACITY = strBWS_Config_UpdateDR_in.strBWSConfigInfo.maxCapacity;
                SP_SET_HOSTVARIABLE(hCSFSBWSCFGCLAIM_TIME, strObjCommonIn.strTimeStamp.reportTimeStamp);
                SP_SET_HOSTVARIABLE(hCSFSBWSCFGCLAIM_USER_ID, strObjCommonIn.strUser.userID.identifier);
                SP_SET_HOSTVARIABLE(hCSFSBWSCFGCLAIM_MEMO, claimMemo);

                
/*
EXEC SQL
                UPDATE CSFSBWSCFG
                SET     MAX_CAPACITY = :hCSFSBWSCFGMAX_CAPACITY,
                        CLAIM_TIME = :hCSFSBWSCFGCLAIM_TIME,
                        CLAIM_USER_ID = :hCSFSBWSCFGCLAIM_USER_ID,
                        CLAIM_MEMO = :hCSFSBWSCFGCLAIM_MEMO
                WHERE BWS_ID = :hCSFSBWSCFGBWS_ID;
*/

{
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlaaloc(2,5,7,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqldata = (void*)&hCSFSBWSCFGMAX_CAPACITY;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 27;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWSCFGCLAIM_TIME;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 65;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWSCFGCLAIM_USER_ID;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 257;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWSCFGCLAIM_MEMO;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSBWSCFGBWS_ID;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlacall((unsigned short)24,5,2,0,0L);
#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlastop(0L);
}

#line 161 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"


                PPT_DR_CHECK_SQL_ERROR_WITHOUT_SQL_NOT_FOUND(strBWS_Config_UpdateDR_out,
                                                             cs_BWS_Config_UpdateDR,
                                                             SQL UPDATE (CSFSBWSCFG));
                                    
            }
            else
            {
                PPT_METHODTRACE_V1("", "BWS Config Max Capacity is not big than zero!");
            }
        }

        //---------------------------------------
        //    Update CSFSBWSCFG_ZONE
        //---------------------------------------

        CORBA::Long lnLenZone = strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq.length();
        PPT_METHODTRACE_V2("", "BWS Zone Config Length ", lnLenZone);
        if (0 == lnLenZone)
        {
            PPT_METHODTRACE_V1("", "INVALID_INPUT_PARM!!");

            SET_MSG_RC(strBWS_Config_UpdateDR_out, 
                       MSG_INVALID_INPUT_PARM, 
                       RC_INVALID_INPUT_PARM);
            return (RC_INVALID_INPUT_PARM);

        }
        for (CORBA::Long ix = 0; ix < lnLenZone; ix++)
        {
            //---------------------------------------
            //  Check BWS ID
            //---------------------------------------
            PPT_METHODTRACE_V2("", "in-para zoneID ",
                               strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID);
            PPT_METHODTRACE_V2("", "in-para zone maxCapacity ",
                               strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].maxCapacity);

            if( 0 == CIMFWStrLen(strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID) ||
                0 >=  strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].maxCapacity        ||
                hCSFSBWSCFGMAX_CAPACITY < strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].maxCapacity )
            {
                PPT_METHODTRACE_V1("", "INVALID_INPUT_PARM!!");
                SET_MSG_RC(strBWS_Config_UpdateDR_out,
                           MSG_INVALID_INPUT_PARM,
                           RC_INVALID_INPUT_PARM);
                return (RC_INVALID_INPUT_PARM);
            }
            
            memset(hCSFSBWSCFG_ZONEBWS_ID, '\0', sizeof(hCSFSBWSCFG_ZONEBWS_ID));
            memset(hCSFSBWSCFG_ZONEZONE_ID, '\0', sizeof(hCSFSBWSCFG_ZONEZONE_ID));
            
            SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONEBWS_ID,
                                    strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier);
            SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONEZONE_ID,
                                    strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID);

            
/*
EXEC SQL SELECT MAX_CAPACITY,
                     CLAIM_TIME,
                     CLAIM_USER_ID,
                     CLAIM_MEMO
            INTO :hCSFSBWSCFG_ZONEMAX_CAPACITY,
                 :hCSFSBWSCFG_ZONECLAIM_TIME,
                 :hCSFSBWSCFG_ZONECLAIM_USER_ID,
                 :hCSFSBWSCFG_ZONECLAIM_MEMO
            FROM CSFSBWSCFG_ZONE
            WHERE BWS_ID  = :hCSFSBWSCFG_ZONEBWS_ID
            AND   ZONE_ID = :hCSFSBWSCFG_ZONEZONE_ID
            FOR READ ONLY;
*/

{
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlaaloc(2,2,8,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSCFG_ZONEBWS_ID;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWSCFG_ZONEZONE_ID;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlaaloc(3,4,9,0L);
    {
      struct sqla_setdata_list sql_setdlist[4];
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqldata = (void*)&hCSFSBWSCFG_ZONEMAX_CAPACITY;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 27;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_TIME;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 65;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_USER_ID;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 257;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_MEMO;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sqlasetdata(3,0,4,sql_setdlist,0L,0L);
    }
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlacall((unsigned short)24,6,2,3,0L);
#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlastop(0L);
}

#line 230 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"


            if( SQLCODE != 0 )
            {
                if( SQLCODE == SP_SQL_NOT_FOUND )
                {
                    PPT_METHODTRACE_V1("", "SQLCODE == SP_SQL_NOT_FOUND");
                    CS_PPT_SET_MSG_RC_KEY2(strBWS_Config_UpdateDR_out,
                                  CS_MSG_BWS_CONFIG_NOT_FOUND_ZONE,
                                  CS_RC_BWS_CONFIG_NOT_FOUND_ZONE,
                                  strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID,
                                  strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier);
                    return (CS_RC_BWS_CONFIG_NOT_FOUND_ZONE);
                }
                else if (SQLCODE == SP_SQL_BUSY)
                {
                    PPT_METHODTRACE_V1("", "SQLCODE == SP_SQL_BUSY");

                    SET_DR_MSG_RC(strBWS_Config_UpdateDR_out,
                                  cs_BWS_Config_UpdateDR,
                                  MSG_LOCKED_BY_ANOTHER,
                                  RC_LOCKED_BY_ANOTHER,
                                  SQL FETCH (CSFSBWSCFG_ZONE) LOCKED_BY_ANOTHER,
                            SQLCODE );
                    return (RC_LOCKED_BY_ANOTHER);
                }
                else
                {
                    PPT_METHODTRACE_V2("", "SELECT SQL FROM CSFSBWSCFG_ZONE -- SYSTEM_ERROR ", SQLCODE);

                    SET_DR_MSG_RC(strBWS_Config_UpdateDR_out,
                                  cs_BWS_Config_UpdateDR,
                                  MSG_SYSTEM_ERROR,
                                  RC_SYSTEM_ERROR,
                                  SQL FETCH (CSFSBWSCFG_ZONE) SYSTEM_ERROR,
                            SQLCODE );
                    return (RC_SYSTEM_ERROR);
                }
            }
            else
            {
                PPT_METHODTRACE_V3("", "Update CSFSBWSCFG_ZONE. BWS_ID, Zone_ID is ", 
                strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier,
                strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID);
                
                memset(hCSFSBWSCFG_ZONEBWS_ID, '\0', sizeof(hCSFSBWSCFG_ZONEBWS_ID));
                memset(hCSFSBWSCFG_ZONEZONE_ID, '\0', sizeof(hCSFSBWSCFG_ZONEZONE_ID));
                hCSFSBWSCFG_ZONEMAX_CAPACITY = 0;

                memset(hCSFSBWSCFG_ZONECLAIM_TIME, '\0', sizeof(hCSFSBWSCFG_ZONECLAIM_TIME));
                memset(hCSFSBWSCFG_ZONECLAIM_USER_ID, '\0', sizeof(hCSFSBWSCFG_ZONECLAIM_USER_ID));
                memset(hCSFSBWSCFG_ZONECLAIM_MEMO, '\0', sizeof(hCSFSBWSCFG_ZONECLAIM_MEMO));

                SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONEBWS_ID,
                                    strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID.identifier);

                SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONEZONE_ID,
                                    strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].zoneID);

                hCSFSBWSCFG_ZONEMAX_CAPACITY =
                        strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq[ix].maxCapacity;

                SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONECLAIM_TIME, strObjCommonIn.strTimeStamp.reportTimeStamp);
                SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONECLAIM_USER_ID, strObjCommonIn.strUser.userID.identifier);
                SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONECLAIM_MEMO, claimMemo);


                
/*
EXEC SQL
                UPDATE CSFSBWSCFG_ZONE
                SET     MAX_CAPACITY = :hCSFSBWSCFG_ZONEMAX_CAPACITY,
                        CLAIM_TIME = :hCSFSBWSCFG_ZONECLAIM_TIME,
                        CLAIM_USER_ID = :hCSFSBWSCFG_ZONECLAIM_USER_ID,
                        CLAIM_MEMO = :hCSFSBWSCFG_ZONECLAIM_MEMO
                        WHERE BWS_ID = :hCSFSBWSCFG_ZONEBWS_ID
                        AND ZONE_ID = :hCSFSBWSCFG_ZONEZONE_ID;
*/

{
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlaaloc(2,6,10,0L);
    {
      struct sqla_setdata_list sql_setdlist[6];
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqldata = (void*)&hCSFSBWSCFG_ZONEMAX_CAPACITY;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 27;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_TIME;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 65;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_USER_ID;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 257;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWSCFG_ZONECLAIM_MEMO;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSBWSCFG_ZONEBWS_ID;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 65;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[5].sqldata = (void*)hCSFSBWSCFG_ZONEZONE_ID;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sql_setdlist[5].sqlind = 0L;
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
      sqlasetdata(2,0,6,sql_setdlist,0L,0L);
    }
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlacall((unsigned short)24,7,2,0,0L);
#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"
  sqlastop(0L);
}

#line 304 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_UpdateDR.dr"


                PPT_DR_CHECK_SQL_ERROR_WITHOUT_SQL_NOT_FOUND(strBWS_Config_UpdateDR_out,
                                                             cs_BWS_Config_UpdateDR,
                                                             SQL UPDATE (CSFSBWSCFG_ZONE));
                
            }

        }

        //---------------------------------------
        //  Return
        //---------------------------------------

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_BWS_Config_UpdateDR");
        return RC_OK;
    }

    CATCH_GLOBAL_EXCEPTIONS(strBWS_Config_UpdateDR_out, cs_BWS_Config_UpdateDR, methodName);
}

#line 41 "csbwsu01.sqx"


/*
EXEC SQL INCLUDE 'cs_BWS_Config_DeleteDR.dr';
*/

#line 1 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_BWS_Config_DeleteDR.dr
//
// Class: CS_PPTManager
//
// Service: cs_BWS_Config_DeleteDR()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/16 INN-R170017 Cheng Li       Bare Wafer Stocker BWS Config Delete
//
//[Function Description]:
//  Delete BWS Configuration Information
//
//[Input Parameters]:
//  const pptObjCommonIn&                 strObjCommonIn
//  const csObjBWS_Config_DeleteDR_in&    strBWS_Config_DeleteDR_in
//  const char *                          claimMemo
//
//  typedef struct csObjBWS_Config_DeleteDR_in_struct {
//      objectIdentifier                    BWSID;
//      string                              zoneID;
//      any                                 siInfo;
//  } csObjBWS_Config_DeleteDR_in;
//
//[Output Parameters]:
//  csObjBWS_Config_DeleteDR_out&       strBWS_Config_DeleteDR_out
//
//  typedef objBase_out csObjBWS_Config_DeleteDR_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_LOCKED_BY_ANOTHER               MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//

CORBA::Long CS_PPTManager_i::cs_BWS_Config_DeleteDR(
        csObjBWS_Config_DeleteDR_out&        strBWS_Config_DeleteDR_out,
        const pptObjCommonIn&                strObjCommonIn,
        const csObjBWS_Config_DeleteDR_in&   strBWS_Config_DeleteDR_in,
        const char *                         claimMemo)
{
    char*  methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_BWS_Config_DeleteDR");
        PPT_PUSH_ACCESS_CONTROL("cs_BWS_Config_DeleteDR");
        //---------------------------------------
        //  Initialize
        //---------------------------------------
        sqlca sqlca;
        CORBA::Long totalcount;

        #include "csfsbwscfgdb.h"
        #include "csfsbwscfg_zonedb.h"
        //---------------------------------------
        //  Check BWS ID
        //---------------------------------------
        PPT_METHODTRACE_V2("", "in-para BWSID ", strBWS_Config_DeleteDR_in.BWSID.identifier);
        PPT_METHODTRACE_V2("", "in-para zoneID ", strBWS_Config_DeleteDR_in.zoneID);

        if (0 == CIMFWStrLen(strBWS_Config_DeleteDR_in.BWSID.identifier))
        {
            PPT_METHODTRACE_V1("", "INVALID_INPUT_PARM!!");
            SET_MSG_RC(strBWS_Config_DeleteDR_out,
                       MSG_INVALID_INPUT_PARM,
                       RC_INVALID_INPUT_PARM);
            return (RC_INVALID_INPUT_PARM);
        }

        if (0 == CIMFWStrLen(strBWS_Config_DeleteDR_in.zoneID))
        {
            PPT_METHODTRACE_V1("", "INVALID_INPUT_PARM!!");
            SET_MSG_RC(strBWS_Config_DeleteDR_out,
                       MSG_INVALID_INPUT_PARM,
                       RC_INVALID_INPUT_PARM);
            return (RC_INVALID_INPUT_PARM);
        }

        //---------------------------------------
        //  Initialize
        //---------------------------------------

        memset(hCSFSBWSCFGBWS_ID,             '\0', sizeof(hCSFSBWSCFG_ZONEBWS_ID));
        memset(hCSFSBWSCFG_ZONEZONE_ID,       '\0', sizeof(hCSFSBWSCFG_ZONEZONE_ID));
        SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONEBWS_ID, strBWS_Config_DeleteDR_in.BWSID.identifier);
        SP_SET_HOSTVARIABLE(hCSFSBWSCFG_ZONEZONE_ID, strBWS_Config_DeleteDR_in.zoneID);

        //---------------------------------------
        //  Delete
        //---------------------------------------
        totalcount = 0;

        
/*
EXEC SQL
        SELECT COUNT(BWS_ID)
        INTO :totalcount
        FROM CSFSBWSCFG_ZONE
        WHERE BWS_ID = :hCSFSBWSCFG_ZONEBWS_ID;
*/

{
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlaaloc(2,1,11,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSCFG_ZONEBWS_ID;
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlaaloc(3,1,12,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)&totalcount;
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlacall((unsigned short)24,8,2,3,0L);
#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlastop(0L);
}

#line 106 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"

        //AND ZONE_ID = :hCSFSBWSCFG_ZONEZONE_ID;

        if (SQLCODE != 0)
        {
            PPT_DR_CHECK_SQL_ERROR(strBWS_Config_DeleteDR_out,
                                   cs_BWS_Config_DeleteDR,
                                   MSG_SYSTEM_ERROR,
                                   RC_SYSTEM_ERROR,
                                   "SQL SELECT COUNT FROM CSFSBWSCFG");
        }
        PPT_METHODTRACE_V2("", "SQL SELECT COUNT(*) FROM CSFSBWSCFG", totalcount);
        //---------------------------------------
        //  Delete CSFSBWSCFG
        //---------------------------------------
        if (totalcount == 1)
        {
            PPT_METHODTRACE_V1("", "Delete CSFSBWSCFG");

            
/*
EXEC SQL
            DELETE FROM CSFSBWSCFG
            WHERE BWS_ID = :hCSFSBWSCFG_ZONEBWS_ID;
*/

{
#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlaaloc(2,1,13,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSCFG_ZONEBWS_ID;
#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlacall((unsigned short)24,9,2,0,0L);
#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlastop(0L);
}

#line 127 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"


            PPT_DR_CHECK_SQL_ERROR_WITHOUT_SQL_NOT_FOUND(strBWS_Config_DeleteDR_out,
                                                         cs_BWS_Config_DeleteDR,
                                                         SQL DELETE (CSFSBWSCFG));
        }
        //---------------------------------------
        //  Delete CSFSBWSCFG_ZONE
        //---------------------------------------
        
/*
EXEC SQL
        DELETE FROM CSFSBWSCFG_ZONE
        WHERE BWS_ID = :hCSFSBWSCFG_ZONEBWS_ID
        AND ZONE_ID = :hCSFSBWSCFG_ZONEZONE_ID;
*/

{
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlaaloc(2,2,14,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSCFG_ZONEBWS_ID;
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWSCFG_ZONEZONE_ID;
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlacall((unsigned short)24,10,2,0,0L);
#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"
  sqlastop(0L);
}

#line 139 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_Config_DeleteDR.dr"


        PPT_DR_CHECK_SQL_ERROR_WITHOUT_SQL_NOT_FOUND(strBWS_Config_DeleteDR_out,
                                                     cs_BWS_Config_DeleteDR,
                                                     SQL DELETE (CSFSBWSCFG_ZONE));

        //---------------------------------------
        //  Return
        //---------------------------------------

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_BWS_Config_DeleteDR");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBWS_Config_DeleteDR_out, cs_BWS_Config_DeleteDR, methodName);
}
#line 42 "csbwsu01.sqx"


/*
EXEC SQL INCLUDE 'cs_BWS_WaferList_AddDR.dr';
*/

#line 1 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
// SiView 
// Name : cs_BWS_WaferList_GetDR.dr

// Class: PPTManager
//
// Service: cs_BWS_WaferList_GetDR()

// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/18 INN-R170017  LiHejing       BWS WaferListAdd

// Description:
//    Get BWS Wafer Information
//
// Return:
//     Long
//
//[Input Parameters]:
//  in  pptObjCommonIn                   strObjCommonIn
//  in  csObjBWS_WaferList_GetDR_in&     strObjBWS_WaferList_GetDR_in
//
//[Output Parameters]:
//  out csObjBWS_WaferList_GetDR_out&    strObjBWS_WaferList_GetDR_out
//
//[Return Value]
//Return Code                           Message ID
//--------------------------------------------------------------------------------
//RC_OK                                 MSG_OK
//RC_LOCKED_BY_ANOTHER                  MSG_LOCKED_BY_ANOTHER
//RC_STSTEM_ERROR                       MSG_SYSTEM_ERROR
//

#include "cs_pptmgr.hpp"


CORBA::Long CS_PPTManager_i::cs_BWS_WaferList_AddDR(
        csObjBWS_WaferList_AddDR_out&          strBWS_WaferList_AddDR_out,
        const pptObjCommonIn&                  strObjCommonIn,
        const csObjBWS_WaferList_AddDR_in&     strBWS_WaferList_AddDR_in,
        const char*                            claimMemo )
{
    char* methodName = NULL;
    CORBA::Long rc = RC_OK;

    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_BWS_WaferList_AddDR");
        PPT_PUSH_ACCESS_CONTROL("cs_BWS_WaferList_AddDR");
        
        //----------------------------------------------
        //initialize
        //----------------------------------------------
        sqlca sqlca;
        CORBA::Long totalcount;
        #include "csfsbwsdb.h"
        #include "csfsbws_zonedb.h"
        #include "csfsbws_waferdb.h"
        
        
        //-------------------------------------------------
        //  Check BWS ID
        //-------------------------------------------------
        PPT_METHODTRACE_V2( "", "IN-PARA BWSID ",        strBWS_WaferList_AddDR_in.BWSID.identifier );
        PPT_METHODTRACE_V2( "", "IN-PARA zoneID ",       strBWS_WaferList_AddDR_in.zoneID );

        if( 0 == CIMFWStrLen( strBWS_WaferList_AddDR_in.BWSID.identifier ))
        {
            PPT_METHODTRACE_V1( "", "INVALID_INPUT_PARM!! " );
            
            SET_MSG_RC( strBWS_WaferList_AddDR_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );
            return( RC_INVALID_INPUT_PARM );
        }

        //-------------------------------------------------
        //  Check Zone ID
        //-------------------------------------------------
        if( 0 == CIMFWStrLen( strBWS_WaferList_AddDR_in.zoneID ))
        {
            PPT_METHODTRACE_V1( "", "INVALID_INPUT_PARM!! " );
            
            SET_MSG_RC( strBWS_WaferList_AddDR_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );
            return( RC_INVALID_INPUT_PARM );
        }

        CORBA::Long InLenWafer = strBWS_WaferList_AddDR_in.strBWSWaferDataSeq.length();
        PPT_METHODTRACE_V2( "", "InLenWafer", InLenWafer );

        //--------------------------------------
        //  Insert CSFSBWS
        //--------------------------------------
        memset( hCSFSBWSBWS_ID,             '\0', sizeof(hCSFSBWSBWS_ID));
        hCSFSBWSWAFER_COUNT = 0;
        memset( hCSFSBWSCLAIM_TIME,         '\0', sizeof(hCSFSBWSCLAIM_TIME));
        memset( hCSFSBWSCLAIM_USER_ID,      '\0', sizeof(hCSFSBWSCLAIM_USER_ID));
        memset( hCSFSBWSCLAIM_MEMO,         '\0', sizeof(hCSFSBWSCLAIM_MEMO));

        SP_SET_HOSTVARIABLE(hCSFSBWSBWS_ID,          strBWS_WaferList_AddDR_in.BWSID.identifier);
        hCSFSBWSWAFER_COUNT = InLenWafer;
        SP_SET_HOSTVARIABLE( hCSFSBWSCLAIM_TIME,     strObjCommonIn.strTimeStamp.reportTimeStamp );
        SP_SET_HOSTVARIABLE( hCSFSBWSCLAIM_USER_ID,  strObjCommonIn.strUser.userID.identifier );
        SP_SET_HOSTVARIABLE( hCSFSBWSCLAIM_MEMO,     claimMemo );

        //Update
        PPT_METHODTRACE_V1( "", "Update CSFSBWS" );

        
/*
EXEC SQL UPDATE CSFSBWS
                 SET WAFER_COUNT      = WAFER_COUNT + :hCSFSBWSWAFER_COUNT,
                     CLAIM_TIME       = :hCSFSBWSCLAIM_TIME,
                     CLAIM_USER_ID    = :hCSFSBWSCLAIM_USER_ID,
                     CLAIM_MEMO       = :hCSFSBWSCLAIM_MEMO
                 WHERE BWS_ID     = :hCSFSBWSBWS_ID;
*/

{
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlaaloc(2,5,15,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)&hCSFSBWSWAFER_COUNT;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 27;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWSCLAIM_TIME;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 65;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWSCLAIM_USER_ID;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 257;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWSCLAIM_MEMO;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSBWSBWS_ID;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlacall((unsigned short)24,11,2,0,0L);
#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastop(0L);
}

#line 116 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"


        if( SQLCODE == SP_SQL_NOT_FOUND )
        {
            // Insert
            PPT_METHODTRACE_V1( "", "Insert into CSFSBWS" );

            
/*
EXEC SQL INSERT INTO CSFSBWS
                 ( BWS_ID, WAFER_COUNT, CLAIM_TIME, CLAIM_USER_ID, CLAIM_MEMO )
                 VALUES
                 ( :hCSFSBWSBWS_ID, :hCSFSBWSWAFER_COUNT, :hCSFSBWSCLAIM_TIME, :hCSFSBWSCLAIM_USER_ID, :hCSFSBWSCLAIM_MEMO );
*/

{
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlaaloc(2,5,16,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSBWS_ID;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqltype = 496; sql_setdlist[1].sqllen = 4;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqldata = (void*)&hCSFSBWSWAFER_COUNT;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 27;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWSCLAIM_TIME;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 65;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWSCLAIM_USER_ID;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 257;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSBWSCLAIM_MEMO;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlacall((unsigned short)24,12,2,0,0L);
#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastop(0L);
}

#line 126 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"

 
            if( SQLCODE != 0 )
            {
                if( SQLCODE == SP_SQL_BUSY )
                {
                    PPT_METHODTRACE_V1( "", "SQL INSERT INTO CSFSBWS -- SP_SQL_BUSY " );

                    SET_DR_MSG_RC( strBWS_WaferList_AddDR_out,
                                    cs_BWS_WaferList_AddDR,
                                    MSG_LOCKED_BY_ANOTHER,
                                    RC_LOCKED_BY_ANOTHER,
                                    SQL INSERT (CSFSBWS),
                                    SQLCODE );
                    
                    return( RC_LOCKED_BY_ANOTHER );
                }
                else
                {
                    PPT_METHODTRACE_V1( "", "SQL INSERT INTO CSFSBWS -- SYSTEM_ERROR" );
                    
                    SET_DR_MSG_RC( strBWS_WaferList_AddDR_out,
                                    cs_BWS_WaferList_AddDR,
                                    MSG_LOCKED_BY_ANOTHER,
                                    RC_LOCKED_BY_ANOTHER,
                                    SQL INSERT (CSFSBWS),
                                    SQLCODE );

                    return( RC_SYSTEM_ERROR );
                }
            }
            else
            {
                rc = RC_OK;
            }
        }

        //--------------------------------------
        //  Update CSFSBWS_ZONE
        //--------------------------------------
        memset( hCSFSBWS_ZONEBWS_ID,        '\0', sizeof(hCSFSBWS_ZONEBWS_ID));
        memset( hCSFSBWS_ZONEZONE_ID,       '\0', sizeof(hCSFSBWS_ZONEZONE_ID));
        hCSFSBWS_ZONEWAFER_COUNT = 0;
        hCSFSBWS_ZONEWAFER_COUNT = InLenWafer;

        SP_SET_HOSTVARIABLE( hCSFSBWS_ZONEBWS_ID,  strBWS_WaferList_AddDR_in.BWSID.identifier );
        SP_SET_HOSTVARIABLE( hCSFSBWS_ZONEZONE_ID, strBWS_WaferList_AddDR_in.zoneID );

        //update
        PPT_METHODTRACE_V1( "", "Update CSFSBWS_ZONE" );

        
/*
EXEC SQL UPDATE CSFSBWS_ZONE
                 SET   WAFER_COUNT      = WAFER_COUNT + :hCSFSBWS_ZONEWAFER_COUNT
                 WHERE BWS_ID           = :hCSFSBWS_ZONEBWS_ID
                 AND   ZONE_ID          = :hCSFSBWS_ZONEZONE_ID;
*/

{
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlaaloc(2,3,17,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)&hCSFSBWS_ZONEWAFER_COUNT;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWS_ZONEBWS_ID;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 65;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWS_ZONEZONE_ID;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sqlasetdata(2,0,3,sql_setdlist,0L,0L);
    }
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlacall((unsigned short)24,13,2,0,0L);
#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastop(0L);
}

#line 180 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"


        if( SQLCODE == SP_SQL_NOT_FOUND )
        {
            // Insert
            PPT_METHODTRACE_V1( "", "Insert into CSFSBWS_ZONE" );

            
/*
EXEC SQL INSERT INTO CSFSBWS_ZONE
                 ( BWS_ID, ZONE_ID, WAFER_COUNT )
                 VALUES
                 ( :hCSFSBWS_ZONEBWS_ID, :hCSFSBWS_ZONEZONE_ID, :hCSFSBWS_ZONEWAFER_COUNT );
*/

{
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlaaloc(2,3,18,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWS_ZONEBWS_ID;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWS_ZONEZONE_ID;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqldata = (void*)&hCSFSBWS_ZONEWAFER_COUNT;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sqlasetdata(2,0,3,sql_setdlist,0L,0L);
    }
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlacall((unsigned short)24,14,2,0,0L);
#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastop(0L);
}

#line 190 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"


            if( SQLCODE != 0 )
            {
                if( SQLCODE == SP_SQL_BUSY )
                {
                    PPT_METHODTRACE_V1( "", "SQL INSERT INTO CSFSBWS_ZONE -- SP_SQL_BUSY " );
                    
                    SET_DR_MSG_RC( strBWS_WaferList_AddDR_out,
                                    cs_BWS_WaferList_AddDR,
                                    MSG_LOCKED_BY_ANOTHER,
                                    RC_LOCKED_BY_ANOTHER,
                                    SQL INSERT (CSFSBWS_ZONE),
                                    SQLCODE );
                    
                    return( RC_LOCKED_BY_ANOTHER );
                }
                else
                {
                    PPT_METHODTRACE_V1( "", "SQL INSERT INTO CSFSBWS_ZONE -- SYSTEM_ERROR" );
                    
                    SET_DR_MSG_RC( strBWS_WaferList_AddDR_out,
                                    cs_BWS_WaferList_AddDR,
                                    MSG_SYSTEM_ERROR,
                                    RC_SYSTEM_ERROR,
                                    SQL INSERT (CSFSBWS_ZONE),
                                    SQLCODE );
                    
                    return( RC_SYSTEM_ERROR );
                }
            }
            else
            {
                rc = RC_OK;
            }
        }

        //--------------------------------------
        //  Insert CSFSBWS_WAFER
        //--------------------------------------
        for( CORBA::Long ix=0; ix<InLenWafer; ix++ )
        {
            PPT_METHODTRACE_V3( "", ix, " IN-PARA waferID ",      strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[ix].waferID.identifier );
            PPT_METHODTRACE_V3( "", ix, " IN-PARA waferGradeID ", strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[ix].waferGradeID );
            PPT_METHODTRACE_V3( "", ix, " IN-PARA lotID ",        strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[ix].lotID.identifier );
            PPT_METHODTRACE_V3( "", ix, " IN-PARA bankID ",       strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[ix].bankID.identifier );

            memset( hCSFSBWS_WAFERBWS_ID,             '\0', sizeof(hCSFSBWS_WAFERBWS_ID));
            memset( hCSFSBWS_WAFERZONE_ID,            '\0', sizeof(hCSFSBWS_WAFERZONE_ID));
            memset( hCSFSBWS_WAFERWAFER_ID,           '\0', sizeof(hCSFSBWS_WAFERWAFER_ID));
            memset( hCSFSBWS_WAFERWAFERGRADE_ID,      '\0', sizeof(hCSFSBWS_WAFERWAFERGRADE_ID));
            memset( hCSFSBWS_WAFERLOT_ID,             '\0', sizeof(hCSFSBWS_WAFERLOT_ID));
            memset( hCSFSBWS_WAFERBANK_ID,            '\0', sizeof(hCSFSBWS_WAFERBANK_ID));

            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERBWS_ID,        strBWS_WaferList_AddDR_in.BWSID.identifier );
            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERZONE_ID,       strBWS_WaferList_AddDR_in.zoneID );
            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERWAFER_ID,      strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[ix].waferID.identifier );
            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERWAFERGRADE_ID, strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[ix].waferGradeID );
            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERLOT_ID,        strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[ix].lotID.identifier );
            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERBANK_ID,       strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[ix].bankID.identifier );

            
/*
EXEC SQL INSERT INTO CSFSBWS_WAFER
                 ( BWS_ID, ZONE_ID, WAFER_ID, WAFERGRADE_ID, LOT_ID, BANK_ID )
                 VALUES
                 ( :hCSFSBWS_WAFERBWS_ID, :hCSFSBWS_WAFERZONE_ID, :hCSFSBWS_WAFERWAFER_ID, :hCSFSBWS_WAFERWAFERGRADE_ID, 
                 :hCSFSBWS_WAFERLOT_ID, :hCSFSBWS_WAFERBANK_ID );
*/

{
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlaaloc(2,6,19,0L);
    {
      struct sqla_setdata_list sql_setdlist[6];
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWS_WAFERBWS_ID;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWS_WAFERZONE_ID;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 65;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWS_WAFERWAFER_ID;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 65;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqldata = (void*)hCSFSBWS_WAFERWAFERGRADE_ID;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[3].sqlind = 0L;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 65;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqldata = (void*)hCSFSBWS_WAFERLOT_ID;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[4].sqlind = 0L;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 65;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[5].sqldata = (void*)hCSFSBWS_WAFERBANK_ID;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sql_setdlist[5].sqlind = 0L;
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
      sqlasetdata(2,0,6,sql_setdlist,0L,0L);
    }
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlacall((unsigned short)24,15,2,0,0L);
#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"
  sqlastop(0L);
}

#line 255 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_AddDR.dr"


            if( SQLCODE != 0 )
            {
                if( SQLCODE == SP_SQL_BUSY )
                {
                    PPT_METHODTRACE_V1( "", "SQL INSERT CSFSBWS_ZONE SQLCODE =-- SP_SQL_BUSY " );
                    
                    SET_DR_MSG_RC( strBWS_WaferList_AddDR_out,
                                    cs_BWS_WaferList_AddDR,
                                    MSG_LOCKED_BY_ANOTHER,
                                    RC_LOCKED_BY_ANOTHER,
                                    SQL INSERT (CSFSBWS_WAFER),
                                    SQLCODE );
                    
                    return( RC_LOCKED_BY_ANOTHER );
                }
                else
                {
                    PPT_METHODTRACE_V1( "", "SQL INSERT INTO CSFSBWS_ZONE -- SYSTEM_ERROR" );
                    
                    SET_DR_MSG_RC( strBWS_WaferList_AddDR_out,
                                    cs_BWS_WaferList_AddDR,
                                    MSG_SYSTEM_ERROR,
                                    RC_SYSTEM_ERROR,
                                    SQL INSERT (CSFSBWS_WAFER),
                                    SQLCODE );
                    
                    return( RC_SYSTEM_ERROR );
                }
            }
        }

        //--------------------------------------------
        //  Return 
        //--------------------------------------------
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_BWS_WaferList_AddDR" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strBWS_WaferList_AddDR_out, cs_BWS_WaferList_AddDR, methodName );
}

#line 43 "csbwsu01.sqx"


/*
EXEC SQL INCLUDE 'cs_BWS_WaferList_DeleteDR.dr';
*/

#line 1 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
// SiView 
// Name : cs_BWS_WaferList_GetDR.dr

// Class: PPTManager
//
// Service: cs_BWS_WaferList_GetDR()

// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/20 INN-R170017  LiHejing       BWS WaferListDelete

// Description:
//    Delete BWS Wafer Information
//
// Return:
//     Long
//
//[Input Parameters]:
//  in  pptObjCommonIn                      strObjCommonIn
//  in  csObjBWS_WaferList_DeleteDR_in&     BWS_WaferList_DeleteDR_in
//
//[Output Parameters]:
//  out csObjBWS_WaferList_DeleteDR_out&    strBWS_WaferList_DeleteDR_out
//
//[Return Value]
//Return Code                           Message ID
//--------------------------------------------------------------------------------
//RC_OK                                 MSG_OK
//RC_LOCKED_BY_ANOTHER                  MSG_LOCKED_BY_ANOTHER
//RC_STSTEM_ERROR                       MSG_SYSTEM_ERROR
//

#include "cs_pptmgr.hpp"


CORBA::Long CS_PPTManager_i::cs_BWS_WaferList_DeleteDR(
        csObjBWS_WaferList_DeleteDR_out&          strBWS_WaferList_DeleteDR_out,
        const pptObjCommonIn&                     strObjCommonIn,
        const csObjBWS_WaferList_DeleteDR_in&     strBWS_WaferList_DeleteDR_in,
        const char*                               claimMemo )
{
    char* methodName = NULL;
    CORBA::Long rc = RC_OK;

    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_BWS_WaferList_DeleteDR");
        PPT_PUSH_ACCESS_CONTROL("cs_BWS_WaferList_DeleteDR");
        
        //----------------------------------------------
        //initialize
        //----------------------------------------------
        sqlca sqlca;
        CORBA::Long totalcount;
        #include "csfsbwsdb.h"
        #include "csfsbws_zonedb.h"
        #include "csfsbws_waferdb.h"
        
        CORBA::Long InLenWafer = strBWS_WaferList_DeleteDR_in.waferIDs.length();

        PPT_METHODTRACE_V2( "", "IN-PARA InLenWafer ", InLenWafer );
        
        //-------------------------------------------------
        //  Check Input Parameters
        //-------------------------------------------------
        PPT_METHODTRACE_V2( "", "IN-PARA BWSID ",        strBWS_WaferList_DeleteDR_in.BWSID.identifier );
        PPT_METHODTRACE_V2( "", "IN-PARA zoneID ",       strBWS_WaferList_DeleteDR_in.zoneID );

        if( 0 == CIMFWStrLen( strBWS_WaferList_DeleteDR_in.BWSID.identifier ) ||
            0 == CIMFWStrLen( strBWS_WaferList_DeleteDR_in.zoneID ) ||
            0 == InLenWafer )
        {
            PPT_METHODTRACE_V1( "", "INVALID_INPUT_PARM!! " );
            
            SET_MSG_RC( strBWS_WaferList_DeleteDR_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );
            return( RC_INVALID_INPUT_PARM );
        }

        for( CORBA::Long ix=0; ix<InLenWafer; ix++ )
        {
            if( 0 == CIMFWStrLen( strBWS_WaferList_DeleteDR_in.waferIDs[ix].identifier ))
            {
                PPT_METHODTRACE_V1( "", "INVALID_INPUT_PARM!! " );

                SET_MSG_RC( strBWS_WaferList_DeleteDR_out,
                            MSG_INVALID_INPUT_PARM,
                            RC_INVALID_INPUT_PARM );
                return( RC_INVALID_INPUT_PARM );
            }
        }
        
        //-------------------------------------------------
        //  Get and Check wafer count of BWS/zone
        //-------------------------------------------------
        
        memset( hCSFSBWSBWS_ID,             '\0', sizeof(hCSFSBWSBWS_ID));
        SP_SET_HOSTVARIABLE( hCSFSBWSBWS_ID, strBWS_WaferList_DeleteDR_in.BWSID.identifier);

        hCSFSBWSWAFER_COUNT = 0;

        PPT_METHODTRACE_V1( "", "Select WaferCount From CSFSBWS" );

        
/*
EXEC SQL SELECT WAFER_COUNT
                 INTO     :hCSFSBWSWAFER_COUNT
                 FROM     CSFSBWS
                 WHERE    CSFSBWS.BWS_ID = :hCSFSBWSBWS_ID
                 FOR READ ONLY;
*/

{
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlaaloc(2,1,20,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSBWS_ID;
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlaaloc(3,1,21,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)&hCSFSBWSWAFER_COUNT;
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlacall((unsigned short)24,16,2,3,0L);
#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastop(0L);
}

#line 110 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"


        if(( SQLCODE != 0 ))
        {
            PPT_METHODTRACE_V2( "", "SQL SELECT WAFER_COUNT FROM CSFSBWS, SQLCODE ", SQLCODE );
            
            SET_DR_MSG_RC( strBWS_WaferList_DeleteDR_out,
                            cs_BWS_WaferList_DeleteDR,
                            MSG_SYSTEM_ERROR,
                            RC_SYSTEM_ERROR,
                            "SQL SELECT WAFER_COUNT(CSFSBWS)",
                            SQLCODE );
            
            return( RC_SYSTEM_ERROR );
        }

        PPT_METHODTRACE_V2( "", "### hCSFSBWSWAFER_COUNT = ", hCSFSBWSWAFER_COUNT );
        
        //wafer count of zone
        memset( hCSFSBWS_ZONEBWS_ID,             '\0', sizeof(hCSFSBWS_ZONEBWS_ID));
        memset( hCSFSBWS_ZONEZONE_ID,             '\0', sizeof(hCSFSBWS_ZONEZONE_ID));
        SP_SET_HOSTVARIABLE( hCSFSBWS_ZONEBWS_ID, strBWS_WaferList_DeleteDR_in.BWSID.identifier);
        SP_SET_HOSTVARIABLE( hCSFSBWS_ZONEZONE_ID, strBWS_WaferList_DeleteDR_in.zoneID);

        hCSFSBWS_ZONEWAFER_COUNT = 0;

        PPT_METHODTRACE_V1( "", "Select WaferCount From CSFSBWS" );

        
/*
EXEC SQL SELECT WAFER_COUNT
                 INTO     :hCSFSBWS_ZONEWAFER_COUNT
                 FROM     CSFSBWS_ZONE
                 WHERE    CSFSBWS_ZONE.BWS_ID = :hCSFSBWS_ZONEBWS_ID
                 AND      CSFSBWS_ZONE.ZONE_ID = :hCSFSBWS_ZONEZONE_ID
                 FOR READ ONLY;
*/

{
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlaaloc(2,2,22,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWS_ZONEBWS_ID;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWS_ZONEZONE_ID;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlaaloc(3,1,23,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)&hCSFSBWS_ZONEWAFER_COUNT;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlacall((unsigned short)24,17,2,3,0L);
#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastop(0L);
}

#line 143 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"


        if(( SQLCODE != 0 ))
        {
            PPT_METHODTRACE_V2( "", "SQL SELECT WAFER_COUNT FROM CSFSBWS_ZONE, SQLCODE ", SQLCODE );
            
            SET_DR_MSG_RC( strBWS_WaferList_DeleteDR_out,
                            cs_BWS_WaferList_DeleteDR,
                            MSG_SYSTEM_ERROR,
                            RC_SYSTEM_ERROR,
                            "SQL SELECT WAFER_COUNT(CSFSBWS_ZONE)",
                            SQLCODE );
            
            return( RC_SYSTEM_ERROR );
        }

        PPT_METHODTRACE_V2( "", "### hCSFSBWS_ZONEWAFER_COUNT = ", hCSFSBWS_ZONEWAFER_COUNT );

        if( InLenWafer > hCSFSBWSWAFER_COUNT || InLenWafer > hCSFSBWS_ZONEWAFER_COUNT )
        {
            PPT_METHODTRACE_V2( "", "SQL DELETE ZONE FROM CSFSBWS_ZONE Not Found, SQLCODE = ", SQLCODE );

            CS_PPT_SET_MSG_RC_KEY2( strBWS_WaferList_DeleteDR_out,
                                CS_MSG_BWS_WAFERLIST_NOT_FOUND_ZONE,
                                CS_RC_BWS_WAFERLIST_NOT_FOUND_ZONE,
                                strBWS_WaferList_DeleteDR_in.zoneID,
                                strBWS_WaferList_DeleteDR_in.BWSID.identifier );
            
            return ( CS_RC_BWS_WAFERLIST_NOT_FOUND_ZONE );
        }

        //---------------------------------------
        // Delete
        //---------------------------------------
        // Delete CSFSBWS_WAFER
        for( ix = 0; ix < InLenWafer; ix++ )
        {
            memset( hCSFSBWS_WAFERBWS_ID,         '\0', sizeof(hCSFSBWS_WAFERBWS_ID));
            memset( hCSFSBWS_WAFERZONE_ID,        '\0', sizeof(hCSFSBWS_WAFERZONE_ID));
            memset( hCSFSBWS_WAFERWAFER_ID,       '\0', sizeof(hCSFSBWS_WAFERWAFER_ID));

            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERBWS_ID, strBWS_WaferList_DeleteDR_in.BWSID.identifier);
            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERZONE_ID, strBWS_WaferList_DeleteDR_in.zoneID);
            SP_SET_HOSTVARIABLE( hCSFSBWS_WAFERWAFER_ID, strBWS_WaferList_DeleteDR_in.waferIDs[ix].identifier);
            
            
/*
EXEC SQL DELETE
                     FROM     CSFSBWS_WAFER
                     WHERE    BWS_ID = :hCSFSBWS_WAFERBWS_ID
                     AND      ZONE_ID = :hCSFSBWS_WAFERZONE_ID
                     AND      WAFER_ID = :hCSFSBWS_WAFERWAFER_ID;
*/

{
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlaaloc(2,3,24,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWS_WAFERBWS_ID;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWS_WAFERZONE_ID;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 65;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[2].sqldata = (void*)hCSFSBWS_WAFERWAFER_ID;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[2].sqlind = 0L;
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sqlasetdata(2,0,3,sql_setdlist,0L,0L);
    }
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlacall((unsigned short)24,18,2,0,0L);
#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastop(0L);
}

#line 192 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"

            
            if(( SQLCODE != 0 ))
            {
                if( SQLCODE == SP_SQL_NOT_FOUND )
                {
                    PPT_METHODTRACE_V2( "", "SQL DELETE WAFER FROM CSFSBWS_WAFER Not Found, SQLCODE = ", SQLCODE );

                    CS_PPT_SET_MSG_RC_KEY3( strBWS_WaferList_DeleteDR_out,
                                        CS_MSG_BWS_WAFERLIST_NOT_FOUND_WAFER,
                                        CS_RC_BWS_WAFERLIST_NOT_FOUND_WAFER,
                                        strBWS_WaferList_DeleteDR_in.waferIDs[ix].identifier,
                                        strBWS_WaferList_DeleteDR_in.zoneID,
                                        strBWS_WaferList_DeleteDR_in.BWSID.identifier );
            
                    return( CS_RC_BWS_WAFERLIST_NOT_FOUND_WAFER );
                }
                else
                {
                    PPT_METHODTRACE_V2( "", "SQL DELETE WAFER FROM CSFSBWS_WAFER, SQLCODE ", SQLCODE );
            
                    SET_DR_MSG_RC( strBWS_WaferList_DeleteDR_out,
                                    cs_BWS_WaferList_DeleteDR,
                                    MSG_SYSTEM_ERROR,
                                    RC_SYSTEM_ERROR,
                                    SQL DELETE (CSFSBWS_WAFER),
                                    SQLCODE );
            
                    return( RC_SYSTEM_ERROR );
                }
            }
        }

        // Delete CSFSBWS_ZONE
        if( InLenWafer == hCSFSBWS_ZONEWAFER_COUNT )
        {
            PPT_METHODTRACE_V1( "", "Delete CSFSBWS_ZONE..." );

            memset( hCSFSBWS_ZONEBWS_ID,         '\0', sizeof(hCSFSBWS_ZONEBWS_ID));
            memset( hCSFSBWS_ZONEZONE_ID,        '\0', sizeof(hCSFSBWS_ZONEZONE_ID));

            SP_SET_HOSTVARIABLE( hCSFSBWS_ZONEBWS_ID, strBWS_WaferList_DeleteDR_in.BWSID.identifier);
            SP_SET_HOSTVARIABLE( hCSFSBWS_ZONEZONE_ID, strBWS_WaferList_DeleteDR_in.zoneID);
            
            
/*
EXEC SQL DELETE
                     FROM     CSFSBWS_ZONE
                     WHERE    BWS_ID = :hCSFSBWS_ZONEBWS_ID
                     AND      ZONE_ID = :hCSFSBWS_ZONEZONE_ID;
*/

{
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlaaloc(2,2,25,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWS_ZONEBWS_ID;
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWS_ZONEZONE_ID;
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlacall((unsigned short)24,19,2,0,0L);
#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastop(0L);
}

#line 239 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"

            
            if(( SQLCODE != 0 ))
            {
                if( SQLCODE == SP_SQL_NOT_FOUND )
                {
                    PPT_METHODTRACE_V2( "", "SQL DELETE ZONE FROM CSFSBWS_ZONE Not Found, SQLCODE = ", SQLCODE );

                    CS_PPT_SET_MSG_RC_KEY2( strBWS_WaferList_DeleteDR_out,
                                        CS_MSG_BWS_WAFERLIST_NOT_FOUND_ZONE,
                                        CS_RC_BWS_WAFERLIST_NOT_FOUND_ZONE,
                                        strBWS_WaferList_DeleteDR_in.zoneID,
                                        strBWS_WaferList_DeleteDR_in.BWSID.identifier );
            
                    return( CS_RC_BWS_WAFERLIST_NOT_FOUND_ZONE );
                }
                else
                {
                    PPT_METHODTRACE_V2( "", "SQL DELETE ZONE FROM CSFSBWS_ZONE, SQLCODE ", SQLCODE );
            
                    SET_DR_MSG_RC( strBWS_WaferList_DeleteDR_out,
                                    cs_BWS_WaferList_DeleteDR,
                                    MSG_SYSTEM_ERROR,
                                    RC_SYSTEM_ERROR,
                                    SQL DELETE (CSFSBWS_ZONE),
                                    SQLCODE );
            
                    return( RC_SYSTEM_ERROR );
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V1( "", "Update CSFSBWS_ZONE..." );

            memset( hCSFSBWS_ZONEBWS_ID,         '\0', sizeof(hCSFSBWS_ZONEBWS_ID));
            memset( hCSFSBWS_ZONEZONE_ID,        '\0', sizeof(hCSFSBWS_ZONEZONE_ID));

            SP_SET_HOSTVARIABLE( hCSFSBWS_ZONEBWS_ID, strBWS_WaferList_DeleteDR_in.BWSID.identifier);
            SP_SET_HOSTVARIABLE( hCSFSBWS_ZONEZONE_ID, strBWS_WaferList_DeleteDR_in.zoneID);
            
            
/*
EXEC SQL UPDATE CSFSBWS_ZONE
                        SET WAFER_COUNT  = WAFER_COUNT - 1
                        WHERE    BWS_ID  = :hCSFSBWS_ZONEBWS_ID
                        AND      ZONE_ID = :hCSFSBWS_ZONEZONE_ID;
*/

{
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlaaloc(2,2,26,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWS_ZONEBWS_ID;
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 65;
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqldata = (void*)hCSFSBWS_ZONEZONE_ID;
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[1].sqlind = 0L;
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlacall((unsigned short)24,20,2,0,0L);
#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastop(0L);
}

#line 283 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"

            
            if(( SQLCODE != 0 ))
            {
                if( SQLCODE == SP_SQL_NOT_FOUND )
                {
                    PPT_METHODTRACE_V2( "", "SQL UPDATE WAFER_COUNT FROM CSFSBWS_ZONE Not Found, SQLCODE = ", SQLCODE );

                    CS_PPT_SET_MSG_RC_KEY2( strBWS_WaferList_DeleteDR_out,
                                        CS_MSG_BWS_WAFERLIST_NOT_FOUND_ZONE,
                                        CS_RC_BWS_WAFERLIST_NOT_FOUND_ZONE,
                                        strBWS_WaferList_DeleteDR_in.zoneID,
                                        strBWS_WaferList_DeleteDR_in.BWSID.identifier );
            
                    return( CS_RC_BWS_WAFERLIST_NOT_FOUND_ZONE );
                }
                else
                {
                    PPT_METHODTRACE_V2( "", "SQL UPDATE ZONE FROM CSFSBWS_ZONE, SQLCODE ", SQLCODE );

                    SET_DR_MSG_RC( strBWS_WaferList_DeleteDR_out,
                                    cs_BWS_WaferList_DeleteDR,
                                    MSG_SYSTEM_ERROR,
                                    RC_SYSTEM_ERROR,
                                    SQL DELETE (CSFSBWS_ZONE),
                                    SQLCODE );
            
                    return( RC_SYSTEM_ERROR );
                }
            }
        }

        // Delete CSFSBWS
        if( InLenWafer == hCSFSBWSWAFER_COUNT )
        {
            PPT_METHODTRACE_V1( "", "Delete CSFSBWS..." );

            memset( hCSFSBWSBWS_ID,         '\0', sizeof(hCSFSBWSBWS_ID));

            SP_SET_HOSTVARIABLE( hCSFSBWSBWS_ID, strBWS_WaferList_DeleteDR_in.BWSID.identifier);
            
            
/*
EXEC SQL DELETE
                     FROM     CSFSBWS
                     WHERE    BWS_ID = :hCSFSBWSBWS_ID;
*/

{
#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlaaloc(2,1,27,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 65;
#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqldata = (void*)hCSFSBWSBWS_ID;
#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sql_setdlist[0].sqlind = 0L;
#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlacall((unsigned short)24,21,2,0,0L);
#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"
  sqlastop(0L);
}

#line 326 "/home/instdev1/views/MMS.vws/vobs/MMS/csppt/source/posppt/pptmgr/objmethd/cs_BWS_WaferList_DeleteDR.dr"

            
            if(( SQLCODE != 0 ))
            {
                if( SQLCODE == SP_SQL_NOT_FOUND )
                {
                    PPT_METHODTRACE_V2( "", "SQL DELETE BWS FROM CSFSBWS Not Found, SQLCODE = ", SQLCODE );

                    CS_PPT_SET_MSG_RC_KEY1( strBWS_WaferList_DeleteDR_out,
                                        CS_MSG_BWS_WAFERLIST_NOT_FOUND_BWS,
                                        CS_RC_BWS_WAFERLIST_NOT_FOUND_BWS,
                                        strBWS_WaferList_DeleteDR_in.BWSID.identifier );
            
                    return( CS_RC_BWS_WAFERLIST_NOT_FOUND_BWS );
                }
                else
                {
                    PPT_METHODTRACE_V2( "", "SQL DELETE BWS FROM CSFSBWS, SQLCODE ", SQLCODE );

                    SET_DR_MSG_RC( strBWS_WaferList_DeleteDR_out,
                                    cs_BWS_WaferList_DeleteDR,
                                    MSG_SYSTEM_ERROR,
                                    RC_SYSTEM_ERROR,
                                    SQL DELETE (CSFSBWS),
                                    SQLCODE );
            
                    return( RC_SYSTEM_ERROR );
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V1( "", "Update CSFSBWS..." );

            memset( hCSFSBWSBWS_ID,             '\0', sizeof(hCSFSBWSBWS_ID));
            memset( hCSFSBWSCLAIM_TIME,         '\0', sizeof(hCSFSBWSCLAIM_TIME));
            memset( hCSFSBWSCLAIM_USER_ID,      '\0', sizeof(hCSFSBWSCLAIM_USER_ID));
            memset( hCSFSBWSCLAIM_MEMO,         '\0', sizeof(hCSFSBWSCLAIM_MEMO));
            hCSFSBWSWAFER_COUNT = InLenWafer;
            SP_SET_HOSTVARIABLE( hCSFSBWSCLAIM_TIME,     strObjCommonIn.strTimeStamp.reportTimeStamp );
            SP_SET_HOSTVARIABLE( hCSFSBWSCLAIM_USER_ID,  strObjCommonIn.strUser.userID.identifier );
            SP_SET_HOSTVARIABLE( hCSFSBWSCLAIM_MEMO,     claimMemo );
        
            SP_SET_HOSTVARIABLE( hCSFSBWSBWS_ID, strBWS_WaferList_DeleteDR_in.BWSID.identifier);
            
            
/*
EXEC SQL UPDATE CSFSBWS
                        SET WAFER_COUNT  = WAFER_COUNT - :hCSFSBWSWAFER_COUNT
                        CLAIM_TIME       = :hCSFSBWSCLAIM_TIME,
                        CLAIM_USER_ID    = :hCSFSBWSCLAIM_USER_ID,
                        CLAIM_MEMO       = :hCSFSBWSCLAIM_MEMO
                        WHERE    BWS_ID  = :hCSFSBWSBWS_ID;
*/

/*
SQL0104N  An unexpected token "CLAIM_TIME" was found 
following "AFER_COUNT - :hCSFSBWSWAFER_COUNT".  Expected 
tokens may include:  ",".  SQLSTATE=42601

*/

            
            if(( SQLCODE != 0 ))
            {
                if( SQLCODE == SP_SQL_NOT_FOUND )
                {
                    PPT_METHODTRACE_V2( "", "SQL UPDATE WAFER_COUNT FROM CSFSBWS Not Found, SQLCODE = ", SQLCODE );

                    CS_PPT_SET_MSG_RC_KEY1( strBWS_WaferList_DeleteDR_out,
                                        CS_MSG_BWS_WAFERLIST_NOT_FOUND_BWS,
                                        CS_RC_BWS_WAFERLIST_NOT_FOUND_BWS,
                                        strBWS_WaferList_DeleteDR_in.BWSID.identifier );
            
                    return( CS_RC_BWS_WAFERLIST_NOT_FOUND_BWS );
                }
                else
                {
                    PPT_METHODTRACE_V2( "", "SQL UPDATE WAFER_COUNT FROM CSFSBWS, SQLCODE ", SQLCODE );

                    SET_DR_MSG_RC( strBWS_WaferList_DeleteDR_out,
                                    cs_BWS_WaferList_DeleteDR,
                                    MSG_SYSTEM_ERROR,
                                    RC_SYSTEM_ERROR,
                                    SQL DELETE (CSFSBWS),
                                    SQLCODE );
            
                    return( RC_SYSTEM_ERROR );
                }
            }
        }

        //--------------------------------------------
        //  Return 
        //--------------------------------------------
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_BWS_WaferList_DeleteDR" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strBWS_WaferList_DeleteDR_out, cs_BWS_WaferList_DeleteDR, methodName );
}

#line 44 "csbwsu01.sqx"

