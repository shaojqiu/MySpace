// @(#) 1.3 superpos/src/csppt/source/posppt/pptmgr/objmethd/cs_sample_Obj.cpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:22:32 [ 6/9/03 14:22:33 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// File : cs_sampleObj.cpp
// Description : Definition of Customized Tx
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
//
// Modeficaiton History:
// Date       Defect   Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya       Initial Release for R5.0
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/09/09 DSIV00002336 T.Ishida       Get rid of warnig message during compilation.
//

#include "cs_pptmgr.hpp"
#include "cs_posconst.hpp"


CORBA::Long CS_PPTManager_i::cs_sample_Obj(
                                objSample_Obj_out& strSample_Obj_out,
                                const pptObjCommonIn& strObjCommonIn )
{
    return 0;   //DSIV00002336
}
