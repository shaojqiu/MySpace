//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_lot_ContaminationInfo_Set.cpp
//
#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
//
// Class: CS_PPTManager
//
// Service: cs_lot_ContaminationInfo_Set()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-04 INN-R170002   JJ.Zhang       Contamination control 
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn      strObjCommonIn;
//  in  csObjLot_ContaminationInfo_Set_in    strLot_ContaminationInfo_Set_in
//
//[Output Parameters]:
//
//  out csObjLot_ContaminationInfo_Set_out  strLot_ContaminationInfo_Set_out;
//
//  typedef objBase_out csObjLot_ContaminationInfo_Set_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_lot_ContaminationInfo_Set(
    csObjLot_ContaminationInfo_Set_out&      strLot_ContaminationInfo_Set_out, 
    const pptObjCommonIn&                    strObjCommonIn, 
    const csObjLot_ContaminationInfo_Set_in& strLot_ContaminationInfo_Set_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_lot_ContaminationInfo_Set");
        CORBA::Long rc = RC_OK;

        //----------------------------------------------
        // Set Lot and POS current contamination flag
        //----------------------------------------------
        objectIdentifier lotID = strLot_ContaminationInfo_Set_in.lotID;
        PPT_METHODTRACE_V2("","lotID--->", lotID.identifier);

        PosLot_var aPosLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot, lotID, strLot_ContaminationInfo_Set_out, cs_lot_ContaminationInfo_Set );

        csObjLot_ContaminationInfo_Get_out strLot_ContaminationInfo_Get_out;
        csObjLot_ContaminationInfo_Get_in  strLot_ContaminationInfo_Get_in;
        strLot_ContaminationInfo_Get_in.lotID = lotID;
        rc = cs_lot_ContaminationInfo_Get(strLot_ContaminationInfo_Get_out,
                                          strObjCommonIn,
                                          strLot_ContaminationInfo_Get_in);

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cs_lot_ContaminationInfo_Get() != RC_OK") ;
            strLot_ContaminationInfo_Set_out.strResult = strLot_ContaminationInfo_Get_out.strResult;
            return(rc);
        }

        csLotContaminationInfo& strLotContaminationInfo = strLot_ContaminationInfo_Get_out.strLotContaminationInfo;

        PPT_METHODTRACE_V2("","CS_S_MAINPD_OpeContamiOutLevel --->", strLotContaminationInfo.opeContamiOutLevel );
        PPT_METHODTRACE_V2("","CS_S_MAINPD_OpePRControl       --->", strLotContaminationInfo.opePRControl );

        //----------------------------------------------
        // Set contamination flag
        //----------------------------------------------
        if( 0 <  CIMFWStrLen(strLotContaminationInfo.opeContamiOutLevel) 
         && 0 != CIMFWStrCmp(strLotContaminationInfo.opeContamiOutLevel, strLotContaminationInfo.lotContamiFlag) )
        {
            SI_PPT_USERDATA_SET_STRING( aPosLot, CS_M_LOT_Contamination_Flag, strLotContaminationInfo.opeContamiOutLevel );
        }

        //----------------------------------------------
        // Set PR flag
        //----------------------------------------------
        if( 0 == CIMFWStrCmp(strLotContaminationInfo.opePRControl, CS_PRControl_Action_SetPR) 
          & 0 != CIMFWStrCmp(strLotContaminationInfo.lotPRFlag, CS_M_LOT_PR_Flag_Yes) )
        {
            PPT_METHODTRACE_V1("","CS_S_MAINPD_OpePRControl==SetPR" );
            SI_PPT_USERDATA_SET_STRING( aPosLot, CS_M_LOT_PR_Flag, CS_M_LOT_PR_Flag_Yes );
        }
        else if( 0 == CIMFWStrCmp(strLotContaminationInfo.opePRControl, CS_PRControl_Action_RemovePR) 
          & 0 != CIMFWStrCmp(strLotContaminationInfo.lotPRFlag, CS_M_LOT_PR_Flag_No) )
        {
            PPT_METHODTRACE_V1("","CS_S_MAINPD_OpePRControl==RemovePR" );
            SI_PPT_USERDATA_SET_STRING( aPosLot, CS_M_LOT_PR_Flag, CS_M_LOT_PR_Flag_No );
        }
        else
        {
            PPT_METHODTRACE_V2("","lotPRFlag is not updated", strLotContaminationInfo.opePRControl );
        }

        //----------------------------
        //  Return to Caller
        //----------------------------
        SET_MSG_RC(strLot_ContaminationInfo_Set_out, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_lot_ContaminationInfo_Set");
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_ContaminationInfo_Set_out, cs_lot_ContaminationInfo_Set, methodName)
}
