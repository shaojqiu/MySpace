//
// (c) Copyright: IBM Services Company Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// Name: cs_NPW_CheckCoditionForBWSOut.cpp
//
#include "cs_pptmgr.hpp"

#include "pcas.hh"
#include "pctrlj.hh"
//
// Class: CS_PPTManager
//
// Service: cs_NPW_CheckCoditionForBWSOut()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/23 INN-R170016 JJ.Zhang       Initial Release
//
//[Function Description]
//  Check BWS /Carrier condition for BWSOut operation
//
//[Input Parameters]
//  const pptObjCommonIn&             strObjCommonIn
//  const csObjNPW_CheckCoditionForBWSOut_in&  strNPW_CheckCoditionForBWSOut_in
//
//  typedef struct csbjNPW_CheckCoditionForBWSOut_in_struct
//  {
//      objectIdentifier   BWSID;
//      objectIdentifier   emptyCarrierID;
//      pptEqpPortStatus   strEqpPortStatus
//      any                siInfo;
//  }csbjNPW_CheckCoditionForBWSOut_in;
//
//[Output Parameters]
//  csbjNPW_CheckCoditionForBWSOut_out&   strNPW_CheckCoditionForBWSOut_out
//
// typedef objBase_out strNPW_CheckCoditionForBWSOut_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//
CORBA::Long CS_PPTManager_i::cs_NPW_CheckCoditionForBWSOut (
    csObjNPW_CheckCoditionForBWSOut_out&       strNPW_CheckCoditionForBWSOut_out,
    const pptObjCommonIn&                      strObjCommon,
    const csObjNPW_CheckCoditionForBWSOut_in&  strNPW_CheckCoditionForBWSOut_in )
{
    char* methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cs_NPW_CheckCoditionForBWSOut");
        PPT_METHODTRACE_V2("", "BWS ID ", strNPW_CheckCoditionForBWSOut_in.BWSID.identifier);
        PPT_METHODTRACE_V2("", "Carrier ID ", strNPW_CheckCoditionForBWSOut_in.emptyCarrierID.identifier);
        PPT_METHODTRACE_V2("", "BWS Port ID ", strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.portID.identifier);

        //Check BWS /Carrier condition for BWSOut operation
        //----------------------------------------------
        // Check BWS Usage type
        //----------------------------------------------
        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         strNPW_CheckCoditionForBWSOut_in.BWSID,
                                         strNPW_CheckCoditionForBWSOut_out,
                                         cs_NPW_CheckCoditionForBWSOut );

        CORBA::String_var bwsUsageType;
        SI_PPT_USERDATA_GET_STRING( aPosMachine, CS_S_EQP_BWSUsageType, bwsUsageType );
        PPT_METHODTRACE_V2("", "CS_S_EQP_BWSUsageType", bwsUsageType);
        if( 0 == CIMFWStrCmp(bwsUsageType, CS_ProductCategory_Production) )
        {
            PPT_METHODTRACE_V1("", "bwsUsageType != NonProduction");
            CS_PPT_SET_MSG_RC_KEY1( strNPW_CheckCoditionForBWSOut_out,
                                    CS_MSG_INVALID_BWS_USAGETYPE,
                                    CS_RC_INVALID_BWS_USAGETYPE,
                                    bwsUsageType );
            return CS_RC_INVALID_BWS_USAGETYPE;
        }

        /*--------------------------------------*/
        /*   Check Cassette Category            */
        /*--------------------------------------*/
        PosCassette_var aPosCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, strNPW_CheckCoditionForBWSOut_in.emptyCarrierID,
                                               strNPW_CheckCoditionForBWSOut_out,
                                               cs_NPW_CheckCoditionForBWSOut );

        CORBA::String_var castUsageType;
        SI_PPT_USERDATA_GET_STRING( aPosCassette, CS_M_CAST_UsageType, castUsageType );

        if( 0 != CIMFWStrCmp(CS_CarrierUsageType_NonProduction, castUsageType) )
        {
            PPT_METHODTRACE_V1("", "castUsageType != NonProduction");
            CS_PPT_SET_MSG_RC_KEY1(strNPW_CheckCoditionForBWSOut_out,
                                   CS_MSG_INVALID_CARRIER_USAGETYPE,
                                   CS_RC_INVALID_CARRIER_USAGETYPE,
                                   castUsageType );
            return CS_RC_INVALID_CARRIER_USAGETYPE;
        }

        /*--------------------------------*/
        /*   Check Cassette is Empty      */
        /*--------------------------------*/
        CORBA::Boolean emptyFlag = FALSE;
        try
        {
            emptyFlag = aPosCassette->isEmpty();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isEmpty)

        if ( emptyFlag == FALSE )
        {
            PPT_METHODTRACE_V2("", "carrier is not empty", strNPW_CheckCoditionForBWSOut_in.emptyCarrierID.identifier);
            PPT_SET_MSG_RC_KEY( strNPW_CheckCoditionForBWSOut_out,
                                MSG_CAST_NOT_EMPTY,
                                RC_CAST_NOT_EMPTY,
                                strNPW_CheckCoditionForBWSOut_in.emptyCarrierID.identifier );
            return RC_CAST_NOT_EMPTY;
        }

        /*---------------------------------*/
        /* Check Cassette transferReserved */
        /*---------------------------------*/
        CORBA::Boolean transferReserved;
        try
        {
            transferReserved = aPosCassette->isReserved();
        }
        CATCH_AND_RAISE_EXCEPTIONS( PosCassette::isReserved );

        PPT_METHODTRACE_V2( "", "transferReserved", ( transferReserved ? "TRUE" : "FALSE" ) );
        if ( transferReserved )
        {
            PPT_METHODTRACE_V2("", "carrier is xferreserved", strNPW_CheckCoditionForBWSOut_in.emptyCarrierID.identifier);
            PPT_SET_MSG_RC_KEY2( strNPW_CheckCoditionForBWSOut_out,
                                 MSG_ALREADY_XFER_RESERVED_CST, RC_ALREADY_XFER_RESERVED_CST,
                                 strNPW_CheckCoditionForBWSOut_in.emptyCarrierID.identifier,
                                 "****" );
            return RC_ALREADY_XFER_RESERVED_CST;
        }

        /*----------------------------------------------*/
        /*   Get and Check Cassette's Dispatch Status   */
        /*----------------------------------------------*/
        PPT_METHODTRACE_V1("", "Get Cassette's Dispatch Status");

        CORBA::Boolean dispatchReserved;
        try
        {
            dispatchReserved = aPosCassette->isDispatchReserved();
        }
        CATCH_AND_RAISE_EXCEPTIONS( PosCassette::isDispatchtReserved );

        if ( dispatchReserved )
        {
            PPT_METHODTRACE_V1( "", "Cassette is dispatchReserved." );
            SET_MSG_RC( strNPW_CheckCoditionForBWSOut_out,
                        MSG_ALREADY_DISPATCH_RESVED_CST,
                        RC_ALREADY_DISPATCH_RESVED_CST );
            return RC_ALREADY_DISPATCH_RESVED_CST;
        }

        PosControlJob_var aControlJob;
        try
        {
            aControlJob = aPosCassette->getControlJob();
        }
        CATCH_AND_RAISE_EXCEPTIONS( PosCassette::getControlJob );

        if ( !CORBA::is_nil( aControlJob ) )
        {
            PPT_METHODTRACE_V1( "", "!CORBA::is_nil( aControlJob )" );
            SET_MSG_RC( strNPW_CheckCoditionForBWSOut_out,
                        MSG_CAST_CTRLJOBID_FILLED,
                        RC_CAST_CTRLJOBID_FILLED );
            return RC_CAST_CTRLJOBID_FILLED;
        }

        /*-------------------------------------*/
        /*   Get and Check Cassette's Status   */
        /*-------------------------------------*/
        CORBA::String_var cassetteState;
        try
        {
            cassetteState = aPosCassette->getDurableState();
        }
        CATCH_AND_RAISE_EXCEPTIONS( PosCassette::getCurrentState );

        PPT_METHODTRACE_V2( "", "cassetteState", cassetteState );
        if ( 0 == CIMFWStrCmp( cassetteState, CIMFW_Durable_Available ) ||
             0 == CIMFWStrCmp( cassetteState, CIMFW_Durable_InUse ) )
        {
            PPT_METHODTRACE_V1( "", "cassetteState = CIMFW_Durable_Available or CIMFW_Durable_InUse" );
        }
        else
        {
            PPT_METHODTRACE_V1( "","return RC_INVALID_CAST_STAT" );
            PPT_SET_MSG_RC_KEY2( strNPW_CheckCoditionForBWSOut_out,
                                 MSG_INVALID_CAST_STAT, RC_INVALID_CAST_STAT,
                                 cassetteState,
                                 strNPW_CheckCoditionForBWSOut_in.emptyCarrierID.identifier);
            return RC_INVALID_CAST_STAT;
        }

        /*--------------------------------------*/
        /*   Check Cassette's Transfer Status   */
        /*--------------------------------------*/
        PPT_METHODTRACE_V1("", "Get TransferState");

        CORBA::String_var transferState;
        try
        {
            transferState = aPosCassette->getTransportState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

        if ( (0 == CIMFWStrCmp(strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.accessMode, SP_Eqp_AccessMode_Auto))
          && (0 != CIMFWStrCmp(transferState, SP_TransState_StationIn))
          && (0 != CIMFWStrCmp(transferState, SP_TransState_BayIn))
          && (0 != CIMFWStrCmp(transferState, SP_TransState_ManualIn))
          || (0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn)) )
        {
            PPT_METHODTRACE_V1("", "The Carrier is not transfering. Return error...");
            PPT_SET_MSG_RC_KEY2( strNPW_CheckCoditionForBWSOut_out,
                                 MSG_INVALID_CAST_XFERSTAT,
                                 RC_INVALID_CAST_XFERSTAT,
                                 transferState,
                                 strNPW_CheckCoditionForBWSOut_in.emptyCarrierID.identifier );
            return RC_INVALID_CAST_XFERSTAT;
        }

        /*--------------------------------------*/
        /*   Check loadedCassetteID             */
        /*--------------------------------------*/
        if( CIMFWStrLen(strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.loadedCassetteID.identifier) > 0 )
        {
            PPT_METHODTRACE_V1("", "The Carrier is already loaded on the equipment. Return error...");
            PPT_SET_MSG_RC_KEY( strNPW_CheckCoditionForBWSOut_out,
                                MSG_CST_ALREADY_LOADED,
                                RC_CST_ALREADY_LOADED,
                                strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.loadedCassetteID.identifier );
            return RC_CST_ALREADY_LOADED;
        }

        /*--------------------------------------*/
        /*   Check loadResrvedCassetteID        */
        /*--------------------------------------*/
        if( CIMFWStrLen(strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.loadResrvedCassetteID.identifier) > 0 )
        {
            PPT_METHODTRACE_V1("", "LoadPort already been reserved for carrier. Return error...");
            PPT_SET_MSG_RC_KEY2( strNPW_CheckCoditionForBWSOut_out,
                                 MSG_ALREADY_RESERVED_LOADPORT,
                                 RC_ALREADY_RESERVED_LOADPORT,
                                 strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.portID.identifier,
                                 strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.loadedCassetteID.identifier );
            return MSG_ALREADY_RESERVED_LOADPORT;
        }

        /*--------------------------------------*/
        /*   Check portState                    */
        /*--------------------------------------*/
        if ( 0 != CIMFWStrCmp(strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.portState, SP_PortRsc_PortState_LoadReq)
          && 0 != CIMFWStrCmp(strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.onlineMode,SP_Eqp_OnlineMode_Offline) )
        {
            PPT_METHODTRACE_V1("", "The Equipment portState is not LoadReq. Return error...");
            PPT_SET_MSG_RC_KEY2( strNPW_CheckCoditionForBWSOut_out,
                                 MSG_INVALID_PORT_STATE, RC_INVALID_PORT_STATE,
                                 strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.portID.identifier,
                                 strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.portState );
            return RC_INVALID_PORT_STATE;
        }

        //----------------------------------------
        //  Return to caller
        //----------------------------------------
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_NPW_CheckCoditionForBWSOut");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strNPW_CheckCoditionForBWSOut_out, cs_NPW_CheckCoditionForBWSOut, methodName );
}
