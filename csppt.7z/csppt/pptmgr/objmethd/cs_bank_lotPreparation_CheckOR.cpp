#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/bank_lotPreparation_Check.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:29:56 [ 7/13/07 19:29:57 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: bank_lotPreparation_Check.cpp
//

#include "cs_pptmgr.hpp"

#include "ppcope.hh"
#include "plot.hh"
#include "pbank.hh"
#include "ppcopsp.hh"
#include "pprsp.hh"
#include "pwafer.hh"
#include "pcas.hh"


//[Object Function Name]: long   bank_lotPreparation_Check
//
// Date        Level       Author         Note
// ----------  ----------  -------------  -------------------------------------------
// 2000/08/09              H.Katoh        Initial Release
// 2000/09/21  QTR3000124  K.Matsuei      Nil Check
// 2000/09/22  PTR3000153  H.Katoh        Add check logic of carrier control Job
// 2000/09/22  PTR3000213  H.Katoh        Add check logic of carrier location
// 2000/11/09  P2200204    R.Furuta       Initialize local pointers
// 2001-08-29  D4000056    H.Adachi       Does not Check carrier is on equipment or not When SORTER
// 2002/04/03  P4100313    K.Kimura       "cout" is changed into Method Trace 
// 2003/03/13  P5000003    H.Adachi       MM Server Down at narrow to PosMachineObject.
// 2004/01/15  P5100093    H.Adachi       Fix Source Production Check does not work.
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/18 INN-R170003  LiHejing       Durable Management Enhancement.
//
//[Function Description]
//  * Check preparation lot type and Bank property combination
//  * Check source lot's hold state (might not be ONHOLD)
//  * Check source lot's inventory state (might be InBank)
//  * Check source lot's lot type (might be 'Vendor lot')
//  * Check source lot's bank ID (might be the same as input bank ID)
//  * Check source lot's product specification ID.
//    (all source lots' product ID must be the same)
//  * Check source wafer is allocated for STB or not
//  * Check carrier has control job or not                //PTR3000153
//  * Check carrier is on equipment or not                //PTR3000213
//
//
//
//[Input Parameters]:
//  in  pptObjCommonIn          strObjCommonIn;
//  in  objectIdentifier        bankID;
//  in  string                  lotType;
//  in  string                  subLotType;
//  in  pptNewLotAttributes     strNewLotAttributes,
//
//[Output Parameters]:
//
//  out objBank_lotPreparation_Check_out  strBank_lotPreparation_Check_out;
//
//  typedef struct objBank_lotPreparation_Check_out_struct {
//     pptRetCode         strResult;
//  } objBank_lotPreparation_Check_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//
//[Pseudo Code]:
//

CORBA::Long CS_PPTManager_i::bank_lotPreparation_Check(
                            objBank_lotPreparation_Check_out& strBank_lotPreparation_Check_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& bankID,
                            const char* lotType,
                            const char* subLotType,
                            const pptNewLotAttributes& strNewLotAttributes )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::bank_lotPreparation_Check");

        //------------------------------------------
        // Get Object reference of PosBank
        //------------------------------------------
        PPT_METHODTRACE_V1("","Get Object reference of PosBank");

        PosBank_var aBank;
        PPT_CONVERT_BANKID_TO_BANK_OR( aBank,
                                       bankID,
                                       strBank_lotPreparation_Check_out,
                                       bank_lotPreparation_Check );

        //------------------------------------------
        // Check Reqest type for generating lot
        //------------------------------------------
        PPT_METHODTRACE_V1("","Check Reqest type for generating lot");

        if ( 0 == CIMFWStrCmp(lotType, SP_Lot_Type_ProductionLot)
          || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_EngineeringLot)
          || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_VendorLot) )
        {
            PPT_METHODTRACE_V1("","lotType == SP_Lot_Type_ProductionLot or SP_Lot_Type_EngineeringLot or SP_Lot_Type_VendorLot");

            CORBA::Boolean bPrdBank;
            try
            {
                bPrdBank = aBank->isProductionBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::isProductionBank)

            if ( bPrdBank == FALSE )
            {
                PPT_METHODTRACE_V1("","bPrdBank == FALSE");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_Check_out,
                                     MSG_INVALID_BANK_DATA,
                                     RC_INVALID_BANK_DATA,
                                     "",
                                     bankID.identifier );

                return RC_INVALID_BANK_DATA;
            }
        }
        else if ( 0 == CIMFWStrCmp(lotType, SP_Lot_Type_ProductionMonitorLot)
               || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_EquipmentMonitorLot)
               || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_DummyLot)
               || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_RecycleLot) )
        {
            PPT_METHODTRACE_V1("","lotType = SP_Lot_Type_ProductionMonitorLot or SP_Lot_Type_EquipmentMonitorLot or SP_Lot_Type_DummyLot or SP_Lot_Type_RecycleLot");

            CORBA::Boolean bCtrlWaferBank;
            try
            {
                bCtrlWaferBank = aBank->isControlWaferBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::isControlWaferBank)

            if ( bCtrlWaferBank == FALSE )
            {
                PPT_METHODTRACE_V1("","bCtrlWaferBank == FALSE");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_Check_out,
                                     MSG_INVALID_BANK_DATA,
                                     RC_INVALID_BANK_DATA,
                                     "",
                                     bankID.identifier );

                return RC_INVALID_BANK_DATA;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("","Else!!");
            SET_MSG_RC( strBank_lotPreparation_Check_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );

            return RC_INVALID_INPUT_PARM;
        }

        //PTR3000154 Start
        //------------------------------------------
        // Check carrier has controlJob or not
        //------------------------------------------
        PPT_METHODTRACE_V1("","Check carrier has controlJob or not");

        PosCassette_var aPosCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette,
                                               strNewLotAttributes.cassetteID,
                                               strBank_lotPreparation_Check_out,
                                               bank_lotPreparation_Check );

        PosControlJob_var aPosControlJob;
        try
        {
            aPosControlJob = aPosCassette->getControlJob();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

        if ( ! CORBA::is_nil(aPosControlJob) )
        {
            objectIdentifier ctrlJobID;
            PPT_SET_OBJECT_IDENTIFIER( ctrlJobID,
                                       aPosControlJob,
                                       strBank_lotPreparation_Check_out,
                                       bank_lotPreparation_Check,
                                       PosControlJob );

            PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_Check_out,
                                 MSG_STB_CASSETTE_HAS_CTRLJOB,
                                 RC_STB_CASSETTE_HAS_CTRLJOB,
                                 strNewLotAttributes.cassetteID.identifier,
                                 ctrlJobID.identifier );
            return RC_STB_CASSETTE_HAS_CTRLJOB;
        }
        //PTR3000154 End

        //D4000056 Start
        //------------------------------------------
        // Check source wafer loaded equipment
        //------------------------------------------
        CORBA::String_var tmpCarrierID;
        try
        {
            tmpCarrierID = aPosCassette->getIdentifier();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)

        Machine_var aMachine;                                             //P5000003
        PosMachine_var aPosMachine;
        try
        {
            aMachine = aPosCassette->currentAssignedMachine();            //P5000003

//P5000003            Machine_var aMachine = aPosCassette->currentAssignedMachine();
//P5000003            aPosMachine = PosMachine::_narrow(aMachine);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)

        //P5000003 Add Start
        if ( TRUE != CORBA::is_nil(aMachine) )
        {
            CORBA::Boolean isStorageBool = FALSE;
            try
            {
                isStorageBool = aMachine->isStorageMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(Machine::isStorageMachine)  

            if ( isStorageBool == TRUE )
            {
                PPT_METHODTRACE_V1( "", "isStorageBool is TRUE: Storage" );
            }
            else
            {
                aPosMachine = PosMachine::_narrow(aMachine);
                PPT_METHODTRACE_V1( "", "isStorageBool is not TRUE: Equipment. So narrow to PosMachine" );
            }
        }
        else
        {
            PPT_METHODTRACE_V1( "", "aMachine is Nill" );
        }
        //P5000003 Add End

        if( ! CORBA::is_nil(aPosMachine) )
        {
            //--------------------------------------------------
            // Get Equipment attributes
            //--------------------------------------------------
            PPT_METHODTRACE_V1("", "Get Equipment attributes");

            CORBA::String_var strMachineCategory;
            try
            {
                strMachineCategory = aPosMachine->getCategory();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory);

            //--------------------------------------------------
            // Check Equipment Type
            //--------------------------------------------------
            PPT_METHODTRACE_V2("", "Check Equipment Type: Category = ", strMachineCategory);

            if ( 0 != CIMFWStrCmp(strMachineCategory, SP_Mc_Category_WaferSorter) )
            {   //D4000056 End AND Follows Nested 
                //PTR3000214 Start
                //------------------------------------------
                // Check carrier is on equipment or not
                //------------------------------------------
                PPT_METHODTRACE_V1("","Check carrier is on equipment or not");

                CORBA::String_var strCassetteXferState;
                try
                {
                    strCassetteXferState = aPosCassette->getTransportState();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

//INN-R170003 add start
//                if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
                if( 0 == CIMFWStrCmp(strCassetteXferState, CS_TRANS_STATE_PORT_IN) || 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentOut) || 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
//INN-R170003 add end
                {
                    PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_Check_out,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         strCassetteXferState,
                                         strNewLotAttributes.cassetteID.identifier );

                    return RC_INVALID_CAST_XFERSTAT;
                }
                //PTR3000214 End
            }
        }   //D4000056  Nested
        else                                                    //P5000003
        {                                                       //P5000003
            PPT_METHODTRACE_V1( "", "aPosMachine is Nill" );    //P5000003
        }                                                       //P5000003
        //------------------------------------------
        // Check source lot condition
        //------------------------------------------
        PPT_METHODTRACE_V1("","Check source lot condition");

        CORBA::Long nSourceWaferlen = 0;
//P5100093        CORBA::String strSourceLotProduct;
        CORBA::String_var    strSourceLotProduct;        //P5100093
        PosProductSpecification_var aPosProdSpec;
        CORBA::Long i;
        CORBA::Long lenLotAttr = strNewLotAttributes.strNewWaferAttributes.length();

//P5100093        strSourceLotProduct = NULL;

        for ( i=0; i < lenLotAttr; i++ )
        {
            if ( i > 0 )
            {
                PPT_METHODTRACE_V2("","Check source lot condition. Round", i);

                if ( 0 == CIMFWStrCmp(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                      strNewLotAttributes.strNewWaferAttributes[i-1].sourceLotID.identifier) )
                {
                    continue;
                }
            }

            PosLot_var aPosLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                         strNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                                         strBank_lotPreparation_Check_out,
                                         bank_lotPreparation_Check );

            CORBA::String_var strlotID;
            try
            {
                strlotID = aPosLot->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getIdentifier)

            //------------------------------------------
            // Check source lot Hold Status
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot Hold Status");

            CORBA::String_var strLotHoldState;
            try
            {
                strLotHoldState = aPosLot->getLotHoldState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState)

            if ( 0 == CIMFWStrCmp(strLotHoldState, CIMFW_Lot_HoldState_OnHold) )
            {
                PPT_METHODTRACE_V1("","strLotHoldState == CIMFW_Lot_HoldState_OnHold");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_Check_out,
                                     MSG_INVALID_LOT_HOLDSTAT,
                                     RC_INVALID_LOT_HOLDSTAT,
                                     strlotID,
                                     strLotHoldState );

                return RC_INVALID_LOT_HOLDSTAT;
            }

            //------------------------------------------
            // Check source lot Inventory Status
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot Inventory Status");

            CORBA::String_var strLotInventoryState;
            try
            {
                strLotInventoryState = aPosLot->getLotInventoryState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInventoryState)

            if ( 0 != CIMFWStrCmp(strLotInventoryState, SP_Lot_InventoryState_InBank) )
            {
                PPT_METHODTRACE_V1("","strLotInventoryState == SP_Lot_InventoryState_InBank");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_Check_out,
                                     MSG_INVALID_LOT_INVENTORYSTAT,
                                     RC_INVALID_LOT_INVENTORYSTAT,
                                     strlotID,
                                     strLotInventoryState );

                return RC_INVALID_LOT_INVENTORYSTAT;
            }

            //------------------------------------------
            // Check source lot Type
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot Type");

            CORBA::String_var strLotType;
            try
            {
                strLotType = aPosLot->getLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)

            if ( 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_VendorLot) )
            {
                PPT_METHODTRACE_V1("","strLotType == SP_Lot_Type_VendorLot");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_Check_out,
                                     MSG_INVALID_LOT_TYPE,
                                     RC_INVALID_LOT_TYPE,
                                     strLotType,
                                     strlotID );

                return RC_INVALID_LOT_TYPE;
            }

            //------------------------------------------
            // Check source lot bank
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot bank");

            PosBank_var aPosBank;
            try
            {
                aPosBank = aPosLot->getBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getBank)

//Q3000124 start
            if(CORBA::is_nil(aPosBank))
            {
                PPT_SET_MSG_RC_KEY( strBank_lotPreparation_Check_out,
                                    MSG_NOT_FOUND_BANK,
                                    RC_NOT_FOUND_BANK, "" );
                return RC_NOT_FOUND_BANK ;
            }
//Q3000124 end

            CORBA::String_var strLotBankID;
            try
            {
                strLotBankID = aPosBank->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::getIdentifier)

            if ( 0 != CIMFWStrCmp(strLotBankID, bankID.identifier) )
            {
                PPT_METHODTRACE_V1("","strLotBankID = bankID.identifier");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_Check_out,
                                     MSG_LOT_BANK_DIFFERENT,
                                     RC_LOT_BANK_DIFFERENT,
                                     strLotBankID,
                                     bankID.identifier );

                return RC_INVALID_LOT_INVENTORYSTAT;                                 
            }

            //------------------------------------------
            // Check source lot Product Spec
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot Product Spec");

            ProductSpecification_var aProductSpec;
            PosProductSpecification_var aPosProdSpec;
            try
            {
                aProductSpec = aPosLot->getProductSpecification();
                aPosProdSpec = PosProductSpecification::_narrow(aProductSpec);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

//Q3000124 start
            if ( CORBA::is_nil(aPosProdSpec) )
            {
                SET_MSG_RC( strBank_lotPreparation_Check_out,
                            MSG_NOT_FOUND_PRODUCTSPEC,
                            RC_NOT_FOUND_PRODUCTSPEC );

                return RC_NOT_FOUND_PRODUCTSPEC;
            }
//Q3000124 end

            CORBA::String_var tmpSourceLotProduct;
            try
            {
                tmpSourceLotProduct = aPosProdSpec->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecification::getIdentifier)

//P4100313            cout << "#### length of strSourceLotProduct [" << CIMFWStrLen(strSourceLotProduct) << "]" << endl;
            PPT_METHODTRACE_V2("","#### length of strSourceLotProduct ....",CIMFWStrLen(strSourceLotProduct)); //P4100313

            if ( 0 == CIMFWStrLen(strSourceLotProduct) )
            {
                PPT_METHODTRACE_V1("","0 == CIMFWStrLen(strSourceLotProduct)");

                strSourceLotProduct = CIMFWStrDup( tmpSourceLotProduct );        //P5100093
//P5100093                strSourceLotProduct = tmpSourceLotProduct;
            }
            else
            {
                PPT_METHODTRACE_V1("","0 != CIMFWStrLen(strSourceLotProduct)");

//P4100313                cout << "#### strSourceLotProduct [" << strSourceLotProduct << "]" << endl;
//P4100313                cout << "#### tmpSourceLotProduct [" << tmpSourceLotProduct << "]" << endl;
                PPT_METHODTRACE_V2("","#### strSourceLotProduct .....",strSourceLotProduct); //P4100313
                PPT_METHODTRACE_V2("","#### tmpSourceLotProduct .....",tmpSourceLotProduct); //P4100313

                if ( 0 != CIMFWStrCmp(strSourceLotProduct, tmpSourceLotProduct) )
                {
                    PPT_METHODTRACE_V1("","strSourceLotProduct != tmpSourceLotProduct");
                    SET_MSG_RC( strBank_lotPreparation_Check_out,
                                MSG_INVALID_SOURCELOT_COMBINATION,
                                RC_INVALID_SOURCELOT_COMBINATION );

                    return RC_INVALID_SOURCELOT_COMBINATION;
                }
            }
        }

        //------------------------------------------
        // Check source lot Wafer Contents
        //------------------------------------------
        lenLotAttr = strNewLotAttributes.strNewWaferAttributes.length();

        PPT_METHODTRACE_V2("","Check source lot Wafer Contents  lenLotAttr", lenLotAttr);

        for ( i=0; i < lenLotAttr; i++ )
        {
            // check requested wafer existance and
            // STB Allocated Flag of each wafer
            PosWafer_var aPosWafer;
            PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
                                             strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID,
                                             strBank_lotPreparation_Check_out,
                                             bank_lotPreparation_Check );

            CORBA::Boolean bWaferFoundFlag;
            try
            {
                bWaferFoundFlag = aPosWafer->isSTBAllocated();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosWafer::isSTBAllocated)

            if ( bWaferFoundFlag == TRUE )
            {
                PPT_METHODTRACE_V1("","bWaferFoundFlag == TRUE");

                CORBA::String_var strWaferID;
                try
                {
                    strWaferID = aPosWafer->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getIdentifier)

                PPT_SET_MSG_RC_KEY( strBank_lotPreparation_Check_out,
                                    MSG_WAFER_ALLOCATED,
                                    RC_WAFER_ALLOCATED,
                                    strWaferID );

                return RC_WAFER_ALLOCATED;
            }

            // Check wafer is in target cassette or not
            MaterialContainer* aMaterialContainer = NULL;  //P2200204
            MaterialContainer_var aMaterialContainerVar;
            try
            {
                aMaterialContainer = aPosWafer->getMaterialContainer();
                aMaterialContainerVar = aMaterialContainer; 
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getMaterialContainer)
  
            CORBA::String_var tmpMaterialContainer;
            if ( ! CORBA::is_nil(aMaterialContainerVar) )    // Q3000124
            {                                                // Q3000124
                try
                {
                    tmpMaterialContainer = aMaterialContainer->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(MaterialContainer::getIdentifier)
            }                                                // Q3000124

            if ( 0 != CIMFWStrCmp(tmpMaterialContainer, strNewLotAttributes.cassetteID.identifier) )
            {
                PPT_METHODTRACE_V1("","tmpMaterialContainer != strNewLotAttributes.cassetteID.identifier");
                SET_MSG_RC( strBank_lotPreparation_Check_out,
                            MSG_WAFER_NOT_PREPARED,
                            RC_WAFER_NOT_PREPARED );

                return RC_WAFER_NOT_PREPARED;
            }
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::bank_lotPreparation_Check");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBank_lotPreparation_Check_out, bank_lotPreparation_Check, methodName)
}
