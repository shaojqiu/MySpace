#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/objmethd/cs_process_dataCollectionDefinition_GetOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:21:30 [ 7/13/07 20:21:31 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_process_dataCollectionDefinition_GetOR.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "plcrc.hh"
#include "pmcrc.hh"
#include "prcssprt.hh"
#include "ppcope.hh"
#include "prdctspc.hh"
#include "pprsp.hh"
#include "ppcflwx.hh"
#include "pdcdf.hh"
#include "ppcdf.hh"
#include "ppcopsp.hh"

//[Object Function Name]: long   process_dataCollectionDefinition_Get
//
// Date        Level  Author         Note
// ----------  -----  -------------  -------------------------------------------
// 2000-09-05  P3000041  Y.Iwasaki      Change how to get DCDef, DCSpec, DeltaXxxx
// 2000/11/10  P2200204  R.Furuta       Initialize local pointers
// 2001/05/14  P3100342  K.Kido         add select Format routin
// 2002-01-09  D4100020  K.Matsuei      Change for Effective Module Process Release(Rel4.1).
// 2002/02/27  D4100157  T.Semba        Pre-measured waferID guildance for delta calculation.
// 2002/03/08  D4100126  M.Ameshita     Common DC Specification for DC Definition.
// 2002/06/12  P4100543  C.Tsuchiya     Source Check: Wrong reference to Dimension and Add nil check
// 2002/07/15  P4200057  M.Ameshita     Fix memory leak after calling convertFromCalculationExpression().
// 2002/09/25  P4200192  H.Adachi       Add Nil Check
// 2003/10/30  D5100004  K.Kido         Add logic for ItemType "UserFunction".
//                                      **** If ItemType is the 'UserFunction', it doesn't ensure the format of 'CalculateExpression'.
//                                           So, it is necessary that 'CalculateExpression' length check.
// 2005/08/30  D6000415  K.Kido         Call findDataCollectionDefinitionForSubLotType() to get correct DCDef taken into account for Chamber Machine State.
// 2005/08/31  D6000398  M.Kase         Change action by the result of consistency check for DCDef and DCSpec
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- ----------------------------------------------------
// 2013/10/28 DSN000076129 T.Itou         Get DCSpec from POS when SP_DCSPEC_FOR_PROCESS is 1.
// 2016/11/08 PSN000103711 Y.Zhuang       Fixed problem that the same waferID retrieved for different wafer position
//
//
// Innotron Modification history :
// Date       Defect#        Person               Comments
// ---------- -------------- -------------------- -------------------------------------------
// 2017/11/06 INN-R170022    Sam Hsueh            Get delta DC for both process and measurement type
//
//
//[Function Description]:
//
//  This object function gets the data collection information.
//  The following items except (null) mark will be filled.
//
//  typedef struct pptDCDef_struct {
//      objectIdentifier              dataCollectionDefinitionID;
//      string                        description;
//      string                        dataCollectionType;
//      sequence <pptDCItem>          strDCItem;
//      boolean                       calculationRequiredFlag;
//      boolean                       specCheckRequiredFlag;
//      objectIdentifier              dataCollectionSpecificationID;
//      objectIdentifier              previousDataCollectionDefinitionID;
//      objectIdentifier              previousOperationID;
//      string                        previousOperationNumber;
//  } pptDCDef;
//
//  typedef struct pptDCItem_struct {
//      string                        dataCollectionItemName;
//      string                        dataCollectionMode;
//      string                        dataCollectionUnit;
//      string                        dataType;
//      string                        itemType;
//      string                        measurementType;
//      objectIdentifier              waferID;                       (null)
//      string                        waferPosition;
//      string                        sitePosition;
//      boolean                       historyRequiredFlag;
//      string                        calculationType;
//      string                        calculationExpression;
//      string                        dataValue;                     (null)
//      string                        targetValue;
//      string                        specCheckResult;               (null)
//      stringSequence                actionCode;                    (null)
//  } pptDCItem;
//
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      equipmentID;
//  in  objectIdentifier      lotID;
//  in  objectIdentifier      logicalRecipeID;
//  in  objectIdentifier      machineRecipeID;
//
//[Output Parameters]:
//  out objProcess_dataCollectionDefinition_Get_out   strProcess_dataCollectionDefinition_Get_out;
//
//  typedef struct objProcess_dataCollectionDefinition_Get_out_struct {
//      pptRetCode            strResult;
//      boolean               dataCollectionFlag;
//      pptDCDefSequence      strDCDef;
//  } objProcess_dataCollectionDefinition_Get_out;
//
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NO_NEED_TO_DATA_COLLECT  MSG_NO_NEED_TO_DATA_COLLECT
//  RC_NOT_FOUND_LOT            MSG_NOT_FOUND_LOT
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//  RC_NOT_FOUND_PRODUCTSPEC    MSG_NOT_FOUND_PRODUCTSPEC
//  RC_NOT_FOUND_PO             MSG_NOT_FOUND_PO
//  RC_NOT_FOUND_POS            MSG_NOT_FOUND_POS
//  RC_NOT_FOUND_DCDEF          MSG_NOT_FOUND_DCDEF
//  RC_NOT_FOUND_OPERATION      MSG_NOT_FOUND_OPERATION
//  RC_NOT_FOUND_PREVPD         MSG_NOT_FOUND_PREVPD
//  RC_NOT_FOUND_PREVDCDE       MSG_NOT_FOUND_PREVDCDEF
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR

CORBA::Long CS_PPTManager_i::process_dataCollectionDefinition_Get(
                            objProcess_dataCollectionDefinition_Get_out& strProcess_dataCollectionDefinition_Get_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const objectIdentifier& lotID,
                            const objectIdentifier& logicalRecipeID,
                            const objectIdentifier& machineRecipeID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::process_dataCollectionDefinition_Get");
        PPT_METHODTRACE_V2( "","in-parm's equipmentID", equipmentID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's lotID", lotID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's logicalRecipeID", logicalRecipeID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's machineRecipeID", machineRecipeID.identifier);


        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*--------------------------------------------------------------*/
        /*                                                              */
        /*   Get Machine / Lot / LogicalRecipe / MachineRecipe Object   */
        /*                                                              */
        /*--------------------------------------------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine,equipmentID,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get);

        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR(aLot,lotID,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get);

        PosLogicalRecipe_var aLogicalRecipe;
        PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR(aLogicalRecipe,logicalRecipeID,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get);

        PosMachineRecipe_var aMachineRecipe;
        PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR(aMachineRecipe,machineRecipeID,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get);

        /*----------------------------------*/
        /*                                  */
//      /*   Get PO / ProdSpec / PFX        */
        /*   Get PO / ProdSpec / PFX / POS  */  //P3000041
        /*                                  */
        /*----------------------------------*/
        ProcessOperation_var aPO;
        PosProcessOperation_var aPosPO;
        try
        {
            aPO = aLot->getProcessOperation();
            aPosPO = PosProcessOperation::_narrow(aPO);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

        if (CORBA::is_nil(aPosPO) == TRUE)
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(aPosPO) == TRUE");
            PPT_SET_MSG_RC_KEY2(strProcess_dataCollectionDefinition_Get_out,MSG_NOT_FOUND_PO,RC_NOT_FOUND_PO,"*****",lotID.identifier);
            return(RC_NOT_FOUND_PO);
        }

        ProductSpecification_var aProdSpec;
        PosProductSpecification_var aPosProdSpec;
        try
        {
            aProdSpec = aLot->getProductSpecification();
            aPosProdSpec = PosProductSpecification::_narrow(aProdSpec);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

        if (CORBA::is_nil(aPosProdSpec) == TRUE)
        {
            PPT_METHODTRACE_V1("","CORBA::is_nil(aPosProdSpec) == TRUE");
            SET_MSG_RC(strProcess_dataCollectionDefinition_Get_out, MSG_NOT_FOUND_PRODUCTSPEC, RC_NOT_FOUND_PRODUCTSPEC);
            return(RC_NOT_FOUND_PRODUCTSPEC);
        }

        PosProcessFlowContext_var aPFX;
        try
        {
            aPFX = aLot->getProcessFlowContext();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);

        if (CORBA::is_nil(aPFX) == TRUE)
        {
            PPT_METHODTRACE_V1("","CORBA::is_nil(aPFX) == TRUE");
            PPT_SET_MSG_RC_KEY(strProcess_dataCollectionDefinition_Get_out,MSG_NOT_FOUND_PFX,RC_NOT_FOUND_PFX,"" );
            return(RC_NOT_FOUND_PFX);
        }

        //P3000041 add start
//D4100020        ProcessOperationSpecification_var aPOS;
//D4100020        PosProcessOperationSpecification_var aPosPOS;
//D4100020        try
//D4100020        {
//D4100020            aPOS = aPosPO->getProcessOperationSpecification();
//D4100020            aPosPOS = PosProcessOperationSpecification::_narrow(aPOS);
//D4100020        }
//D4100020        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessOperationSpecification);
//D4100020        if (CORBA::is_nil(aPosPOS) == TRUE)
//D4100020        {
//D4100020            PPT_METHODTRACE_V1("","CORBA::is_nil(aPosPOS) == TRUE");
//D4100020            PPT_SET_MSG_RC_KEY(strProcess_dataCollectionDefinition_Get_out,MSG_NOT_FOUND_POS,RC_NOT_FOUND_POS,lotID.identifier)
//D4100020            return(RC_NOT_FOUND_POS);
//D4100020        }
        //P3000041 add end

        /*----------------------*/
        /*                      */
        /*   Get DCDefinition   */
        /*                      */
        /*----------------------*/
//D6000415 add start
        /************************/
        /*   Get subLotType     */
        /************************/
        CORBA::String_var subLotType;
        try
        {
            subLotType = aLot->getSubLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
//D6000415 add end
        PosDataCollectionDefinition_var aDCDef;
        try
        {
//P3000041  aDCDef = aPosPO->findDCDefinition();
//D6000415  aDCDef = aLogicalRecipe->findDataCollectionDefinitionFor(aMachine, aMachineRecipe); //P3000041
            aDCDef = aLogicalRecipe->findDataCollectionDefinitionForSubLotType( aMachine, aMachineRecipe, subLotType ); //D6000415
        }
//D6000415        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findDataCollectionDefinitionFor);
        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findDataCollectionDefinitionForSubLotType);    //D6000415

        if (CORBA::is_nil(aDCDef) == TRUE)
        {
            PPT_METHODTRACE_V1("","CORBA::is_nil(aDCDef) == TRUE");
            strProcess_dataCollectionDefinition_Get_out.dataCollectionFlag = FALSE;
            strProcess_dataCollectionDefinition_Get_out.strDCDef.length(0);
            PPT_METHODTRACE_EXIT("CS_PPTManager_i::process_dataCollectionDefinition_Get");
            return(RC_OK);
        }

        strProcess_dataCollectionDefinition_Get_out.dataCollectionFlag = TRUE;

        /*-------------------------*/
        /*                         */
        /*   Get DCSpecification   */
        /*                         */
        /*-------------------------*/
//P3000041        PosDataCollectionSpecification_var aDCSpec;
//P3000041        try
//P3000041        {
//P3000041            aDCSpec = aPosPO->findDCSpecification(aPosProdSpec);
//P3000041        }
//P3000041        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findDCSpecification);

        //P3000041 add start
        /*===== get Recipe Type =====*/
        PosDataCollectionSpecification_var aDCSpec;
        CORBA::String_var recipeType;
        try
        {
            recipeType = aLogicalRecipe->getRecipeType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::getRecipeType);

        if (CIMFWStrCmp(recipeType,SP_Recipe_Measurement) != 0)
        {
            PPT_METHODTRACE_V1("","CIMFWStrCmp(recipeType,SP_Recipe_Measurement) != 0");
            /*===== for Process Operation =====*/

//DSN000076129 add start
            //------------------------------------------------------
            // Get SP_DCSPEC_FOR_PROCESS
            //------------------------------------------------------
            CORBA::String_var isDCSpecForProcess = CIMFWStrDup(getenv(SP_DCSPEC_FOR_PROCESS));
            CORBA::Boolean bFoundFlag = FALSE;
            if( CIMFWStrCmp(isDCSpecForProcess, "1") == 0 )
            {
                PPT_METHODTRACE_V1("", "SP_DCSPEC_FOR_PROCESS=1");
                try
                {
                    aDCSpec = aPosPO->findMeasurementDCSpecification( aPosProdSpec );
                    if( !CORBA::is_nil( aDCSpec ) )
                    {
                        PPT_METHODTRACE_V1("","CORBA::is_nil(aDCSpec) == FALSE");
                        bFoundFlag = TRUE;
                    }
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findMeasurementDCSpecification);

                if (!bFoundFlag)
                {
                    PPT_METHODTRACE_V1("", "!bFoundFlag");
                    try
                    {
                        aDCSpec = aLogicalRecipe->findProcessDCSpecificationForSubLotType( aMachine, aMachineRecipe, subLotType );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findProcessDCSpecificationForSubLotType);
                }
            }
            else
            {
//DSN000076129 indent start
                try
                {
    //D6000415      aDCSpec = aLogicalRecipe->findProcessDCSpecificationFor( aMachine, aMachineRecipe );
                    aDCSpec = aLogicalRecipe->findProcessDCSpecificationForSubLotType( aMachine, aMachineRecipe, subLotType );    //D6000415
                }
    //D6000415  CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findProcessDCSpecificationFor);
                CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findProcessDCSpecificationForSubLotType);    //D6000415
//DSN000076129 indent end
            }
//DSN000076129 add End
        }
        else
        {
            PPT_METHODTRACE_V1("","CIMFWStrCmp(recipeType,SP_Recipe_Measurement) == 0");
            /*===== for Measurement Operation =====*/
//D4100020 start
            try
            {
                aDCSpec = aPosPO->findMeasurementDCSpecification( aPosProdSpec );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findMeasurementDCSpecification);
//D4100020 end
//D4100020            try
//D4100020            {
//D4100020                aDCSpec = aPosPOS->findMeasurementDCSpecification( aPosProdSpec );
//D4100020            }
//D4100020            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::findMeasurementDCSpecification);
        }
        //P3000041 add end

        //-----------------------------------------------------------------------------------------------------   //D4100126
        // Confirm that DC spec is same between Logical Recipe and DC Specification.                              //D4100126
        //-----------------------------------------------------------------------------------------------------   //D4100126
        if( !CORBA::is_nil( aDCSpec ) )                                                                           //D4100126
        {                                                                                                         //D4100126
            //--- Get DC definition ID defined for Logical Recipe. ---//                                          //D4100126
            PosDataCollectionDefinition_var anAssignedDCDef;                                                      //D4100126
            CORBA::String_var anAssignedDCDefId;                                                                  //D4100126
                                                                                                                  //D4100126
            try                                                                                                   //D4100126
            {                                                                                                     //D4100126
//D6000415      anAssignedDCDef = aLogicalRecipe->findDataCollectionDefinitionFor( aMachine, aMachineRecipe );    //D4100126
                anAssignedDCDef = aLogicalRecipe->findDataCollectionDefinitionForSubLotType( aMachine, aMachineRecipe, subLotType );    //D6000415
            }                                                                                                     //D4100126
//D6000415  CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findDataCollectionDefinitionFor);
            CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findDataCollectionDefinitionForSubLotType);    //D6000415
                                                                                                                  //D4100126
            if( !CORBA::is_nil( anAssignedDCDef ) )                                                               //D4100126
            {                                                                                                     //D4100126
                anAssignedDCDefId = anAssignedDCDef->getIdentifier() ;                                            //D4100126
                PPT_METHODTRACE_V2( "",                                                                           //D4100126
                                    "DC Definition for Logical Recipe  ",                                         //D4100126
                                    anAssignedDCDefId );                                                          //D4100126
            }                                                                                                     //D4100126
                                                                                                                  //D4100126
            //--- Get DC definition ID defined for DC Specification. ---//                                        //D4100126
            PosDataCollectionDefinitionSequence_var aDCDefSeq;                                                    //D4100126
            DataCollectionDefinition_var aDCDefInDCSpec;                                                          //D4100126
            CORBA::String_var aDCDefInDCSpecId;                                                                   //D4100126
            CORBA::Long dcDefSeqLen  = 0;                                                                         //D4100126
            CORBA::Boolean foundFlag = FALSE;                                                                     //D4100126
                                                                                                                  //D4100126
            aDCDefSeq = aDCSpec->allDataCollectionDefinitions();                                                  //D4100126
            dcDefSeqLen = aDCDefSeq->length();                                                                    //D4100126
                                                                                                                  //D4100126
            for( CORBA::Long i = 0 ; i < dcDefSeqLen ; i++ )                                                      //D4100126
            {                                                                                                     //D4100126
                if( !CORBA::is_nil((*aDCDefSeq)[i]) )                                                             //D4100126
                {                                                                                                 //D4100126
                    SPFW_TRACE_VERBOSE() ;                                                                        //D4100126
                    aDCDefInDCSpecId = (*aDCDefSeq)[i]->getIdentifier() ;                                         //D4100126
                                                                                                                  //D4100126
                    PPT_METHODTRACE_V2( "",                                                                       //D4100126
                                        "DC Definition for DC specificaiton",                                     //D4100126
                                        aDCDefInDCSpecId );                                                       //D4100126
                                                                                                                  //D4100126
                    if(CIMFWStrCmp( aDCDefInDCSpecId, anAssignedDCDefId ) == 0 )                                  //D4100126
                    {                                                                                             //D4100126
                        foundFlag = TRUE;                                                                         //D4100126
                        break;                                                                                    //D4100126
                    }                                                                                             //D4100126
                }                                                                                                 //D4100126
            }                                                                                                     //D4100126
                                                                                                                  //D4100126
            if( foundFlag == FALSE )                                                                              //D4100126
            {                                                                                                     //D4100126
                PPT_METHODTRACE_V1( "",                                                                           //D4100126
                                    "DC Definition is not same between Logical Recipe and DC specification." );   //D4100126
//D6000398                aDCSpec = PosDataCollectionSpecification::_nil() ;                                                //D4100126
//D6000398 add start
                CORBA::String_var dcRelationCheckFlag = CIMFWStrDup(getenv(SP_DCDEFDCSPEC_RELATION_CHECK_FLAG));
                if( CIMFWStrCmp(dcRelationCheckFlag, "1") == 0 )
                {
                    PPT_METHODTRACE_V1("", "SP_DCDEFDCSPEC_RELATION_CHECK_FLAG == '1'");
                    CORBA::String_var aDCSpecId;
                    try
                    {
                        aDCSpecId = aDCSpec->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosDataCollectionSpecification::getIdentifier);
                    PPT_SET_MSG_RC_KEY3(strProcess_dataCollectionDefinition_Get_out,
                                        MSG_DCDEF_DCSPEC_MISMATCH,
                                        RC_DCDEF_DCSPEC_MISMATCH,
                                        anAssignedDCDefId,
                                        aDCSpecId,
                                        lotID.identifier);
                    return(RC_DCDEF_DCSPEC_MISMATCH);
                }
                else
                {
                    PPT_METHODTRACE_V1("", "SP_DCDEFDCSPEC_RELATION_CHECK_FLAG != '1'");
                    aDCSpec = PosDataCollectionSpecification::_nil() ;
                }
//D6000398 add end
            }                                                                                                     //D4100126
            else                                                                                                  //D4100126
            {                                                                                                     //D4100126
                PPT_METHODTRACE_V1( "",                                                                           //D4100126
                                    "DC Definition is same between Logical Recipe and DC specification." );       //D4100126
            }                                                                                                     //D4100126
        }                                                                                                         //D4100126

        /*---------------------------------------------*/
        /*                                             */
        /*   Get Delta-DCDefinition                    */
        /*                                             */
        /*   posDeltaDCDefInfo includes ...            */
        /*    - string             processOperation    */
        /*    - objectIdentifier   deltaDCDefinition   */
        /*                                             */
        /*---------------------------------------------*/
        //INN-R170022 PosDeltaDCDefInfoSequence*    deltaDCDefInfoSeq = NULL; //P2200204
        PosDeltaDCDefInfoSequence_var deltaDCDefInfoSeqVar;

        //INN-R170022(delete) try
        //INN-R170022(delete) {
        //INN-R170022(delete)     deltaDCDefInfoSeq = aPFX->findDeltaDCDefinitions(aDCDef);
        //INN-R170022(delete)     deltaDCDefInfoSeqVar = deltaDCDefInfoSeq;
        //INN-R170022(delete) }
        //INN-R170022(delete) CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::findDeltaDCDefinition);

        CORBA::Long deltaDCDefInfoLen;
        //INN-R170022 deltaDCDefInfoLen = (*deltaDCDefInfoSeq).length();

        //INN-R170022 add start
        PosDeltaDCDefinitionSequence* pDeltaDCSeq = NULL;
        PosDeltaDCDefinitionSequence_var varDeltaDCSeq;
        try
        {
            pDeltaDCSeq = aPosPO->allDeltaDCDefinitions();
            varDeltaDCSeq = pDeltaDCSeq;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::allDeltaDCDefinitions);

        CORBA::String_var dcDef_var;
        try
        {
            dcDef_var = aDCDef->getIdentifier();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosDataCollectionDefinition::getIdentifier);
        PPT_METHODTRACE_V2("", "dcDef_var", dcDef_var);

        CORBA::ULong nDeltaDCLen = pDeltaDCSeq->length();
        deltaDCDefInfoLen = 0;
        PPT_METHODTRACE_V2("", "nDeltaDCLen", nDeltaDCLen);

        PosDeltaDCDefInfoSequence*  deltaDCDefInfoSeq = new PosDeltaDCDefInfoSequence(0);
        (*deltaDCDefInfoSeq).length( nDeltaDCLen );
        deltaDCDefInfoSeqVar = deltaDCDefInfoSeq;

        for (CORBA::ULong iDDC = 0; iDDC < nDeltaDCLen; iDDC++)
        {
            PPT_METHODTRACE_V3("", "previousDCDefinition ", (*pDeltaDCSeq)[iDDC].previousDCDefinition.identifier, iDDC);
            PPT_METHODTRACE_V2("", "currentDCDefinition  ", (*pDeltaDCSeq)[iDDC].currentDCDefinition.identifier);
            PPT_METHODTRACE_V2("", "deltaDCDefinition    ", (*pDeltaDCSeq)[iDDC].deltaDCDefinition.identifier);

            if ( 0 != CIMFWStrCmp(dcDef_var, (*pDeltaDCSeq)[iDDC].currentDCDefinition.identifier) )
            {
                PPT_METHODTRACE_V2("", "DC definition not match", dcDef_var);
                continue;
            }

            PosProcessOperation_var aPrePO;
            try
            {
                aPrePO = aPFX->findProcessOperationForOperationNumberBefore( (*pDeltaDCSeq)[iDDC].previousOperationNumber ) ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::findProcessOperationForOperationNumberBefore);

            if ( CORBA::is_nil(aPrePO) )
            {
                PPT_METHODTRACE_V1("", "aPrePO is not found");
                continue;
            }

            PPT_METHODTRACE("");
            PosDataCollectionDefinition_var aPreDCDef;
            try
            {
                aPreDCDef = aPrePO->getAssignedDCDef();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedDCDef);

            posActualStartInformationForPO_struct_var preActualStartInfo = NULL;

            try
            {
                preActualStartInfo = aPrePO->getActualStartInfo();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getActualStartInfo);

            if ( preActualStartInfo != NULL )
            {
                PPT_METHODTRACE("");
                PosDataCollectionInfoSequence preDataCollectionInfo = preActualStartInfo->assignedDataCollections ;

                PPT_METHODTRACE_V2("", "number of preDataCollectionInfo", preDataCollectionInfo.length());
                if ( 0 < preDataCollectionInfo.length() )
                {
                    PPT_METHODTRACE_V2("", "Comparing preDataCollectionInfo[0].dataCollectionDefinitionID.identifier", preDataCollectionInfo[0].dataCollectionDefinitionID.identifier);
                    if ( 0 == CIMFWStrCmp((*pDeltaDCSeq)[iDDC].previousDCDefinition.identifier, preDataCollectionInfo[0].dataCollectionDefinitionID.identifier) )
                    {
                        PPT_METHODTRACE_V3("", "deltaDCDefinition is found", (*pDeltaDCSeq)[iDDC].deltaDCDefinition.identifier, deltaDCDefInfoLen);

                        (*deltaDCDefInfoSeq)[deltaDCDefInfoLen].deltaDCDefinition = (*pDeltaDCSeq)[iDDC].deltaDCDefinition ;
                        (*deltaDCDefInfoSeq)[deltaDCDefInfoLen].processOperation  = SP_OBJECT_TO_STRING( aPrePO );
                        deltaDCDefInfoLen++;
                    }
                }
            }
        }

        PPT_METHODTRACE_V2("", "deltaDCDefInfoLen", deltaDCDefInfoLen);
        (*deltaDCDefInfoSeq).length( deltaDCDefInfoLen );
        //INN-R170022 add end

        /*------------------------------------------------*/
        /*                                                */
        /*   Get Delta-DCSpecification                    */
        /*                                                */
        /*   posDeltaDCSpecInfo includes ...              */
        /*    - objectIdentifier   deltaDCDefinition      */
        /*    - objectIdentifier   deltaDCSpecification   */
        /*                                                */
        /*------------------------------------------------*/
//P3000041        PosDeltaDCSpecInfoSequence*    deltaDCSpecInfoSeq;
//P3000041        PosDeltaDCSpecInfoSequence_var deltaDCSpecInfoSeqVar;
//P3000041
//P3000041        try
//P3000041        {
//P3000041            deltaDCSpecInfoSeq = aPosPO->findDeltaDCSpecifications(aPosProdSpec);
//P3000041            deltaDCSpecInfoSeqVar = deltaDCSpecInfoSeq;
//P3000041        }
//P3000041        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findDeltaDCSpecifications);
//P3000041
//P3000041        CORBA::Long deltaDCSpecInfoLen = (*deltaDCSpecInfoSeq).length();

        //P3000041 add start
        PosDeltaDCSpecInfoSequence deltaDCSpecInfoSeq;
        deltaDCSpecInfoSeq.length( deltaDCDefInfoLen );

        CORBA::Long deltaDCSpecInfoLen = 0;
        CORBA::String_var prodSpecID;
        try
        {
            prodSpecID = aProdSpec->getIdentifier();
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProductSpecification::getIdentifier);

        for (CORBA::Long i=0 ; i<deltaDCDefInfoLen ; i++)
        {
            PPT_METHODTRACE_V3("","loop to (*deltaDCDefInfoSeq).length()",deltaDCDefInfoLen,i);
            PosDataCollectionSpecification_var aDeltaDCSpec;
//D4100020 start
            try
            {
                aDeltaDCSpec = aPosPO->findDeltaDCSpecification(prodSpecID,(*deltaDCDefInfoSeq)[i].deltaDCDefinition.identifier);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findDeltaDCSpecification);
//D4100020 end
//D4100020            try
//D4100020            {
//D4100020                aDeltaDCSpec = aPosPOS->findDeltaDCSpecification(prodSpecID,(*deltaDCDefInfoSeq)[i].deltaDCDefinition.identifier);
//D4100020            }
//D4100020            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::findDeltaDCSpecification);

            if (CORBA::is_nil(aDeltaDCSpec) != TRUE)
            {
                PPT_METHODTRACE_V1("","CORBA::is_nil(aDeltaDCSpec) != TRUE");
                PPT_SET_OBJECT_IDENTIFIER(deltaDCSpecInfoSeq[deltaDCSpecInfoLen].deltaDCSpecification,aDeltaDCSpec,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get, PosDataCollectionSpecification);
                deltaDCSpecInfoSeq[deltaDCSpecInfoLen].deltaDCDefinition    = (*deltaDCDefInfoSeq)[i].deltaDCDefinition;
                deltaDCSpecInfoLen++;
            }
        }
        deltaDCSpecInfoSeq.length(deltaDCSpecInfoLen);
        //P3000041 add end

        /*------------------------------------------*/
        /*                                          */
        /*   Set Returned DCDef Information - Raw   */
        /*                                          */
        /*------------------------------------------*/
        /*===== Start of Raw-DC Set =====*/
        {
            /*===== set tatal length of strDCDef =====*/
            strProcess_dataCollectionDefinition_Get_out.strDCDef.length(1+deltaDCDefInfoLen);

            /*===== set Raw-DC def info =====*/
            PPT_SET_OBJECT_IDENTIFIER(strProcess_dataCollectionDefinition_Get_out.strDCDef[0].dataCollectionDefinitionID,aDCDef,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get,PosDataCollectionDefinition);
            strProcess_dataCollectionDefinition_Get_out.strDCDef[0].description        = aDCDef->getDescription();
            strProcess_dataCollectionDefinition_Get_out.strDCDef[0].dataCollectionType = aDCDef->getCollectionType();

            /*===== set Raw-DC spec info =====*/
            if (CORBA::is_nil(aDCSpec) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(aDCSpec) == TRUE");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].specCheckRequiredFlag = FALSE;
            }
            else
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(aDCSpec) != TRUE");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].specCheckRequiredFlag = TRUE;
                PPT_SET_OBJECT_IDENTIFIER(strProcess_dataCollectionDefinition_Get_out.strDCDef[0].dataCollectionSpecificationID,aDCSpec,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get,PosDataCollectionSpecification);
            }

            /*===== set Raw-DC item Info =====*/
            PosDCItemDefinitionSequence* dcItemSeq = NULL; //P2200204
            PosDCItemDefinitionSequence_var varDcItemSeq;
            try
            {
                dcItemSeq = aDCDef->getDCItems();
                varDcItemSeq = dcItemSeq;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosDataCollectionDefinition::getDCItems);

            CORBA::Long itemLen;
            itemLen = dcItemSeq->length();

            strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem.length(itemLen);

            CORBA::Long delivedItemCnt = 0;
            for (CORBA::Long j=0 ; j<itemLen ; j++)
            {
                PPT_METHODTRACE_V3("","loop to dcItemSeq->length()",itemLen,j);
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].dataCollectionItemName = (*dcItemSeq)[j].dataItemName;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].dataCollectionMode     = (*dcItemSeq)[j].dataCollectionMethod;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].dataCollectionUnit     = (*dcItemSeq)[j].unitOfMeasure;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].dataType               = (*dcItemSeq)[j].valType;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].itemType               = (*dcItemSeq)[j].itemType;

                CORBA::String_var itemType;
                itemType = strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].itemType;
                //D5100004 if (CIMFWStrCmp(itemType,SP_DCDef_Item_Derived) == 0 )
                if (CIMFWStrCmp(itemType,SP_DCDef_Item_Derived) == 0 || CIMFWStrCmp(itemType,SP_DCDef_Item_UserFunction) == 0)    //D5100004
                {
                    PPT_METHODTRACE_V1("","itemType == SP_DCDef_Item_Derived");
                    delivedItemCnt++;
                }
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].measurementType        = (*dcItemSeq)[j].measType;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].waferID.identifier     = CIMFWStrDup("");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].waferPosition          = (*dcItemSeq)[j].waferPosition;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].sitePosition           = (*dcItemSeq)[j].sitePosition;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].historyRequiredFlag    = (*dcItemSeq)[j].isStored;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].calculationType        = (*dcItemSeq)[j].calculationType;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].calculationExpression  = (*dcItemSeq)[j].calculationExpression;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].dataValue              = CIMFWStrDup("");
                /*===== get from DCSpec =====*/
                if (CORBA::is_nil(aDCSpec) == TRUE)
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(aDCSpec) == TRUE");
                    strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].targetValue        = CIMFWStrDup("");
                }
                else
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(aDCSpec) != TRUE");
                    posDCItemSpecification_var aItemSpecVar;
                    try
                    {
                        aItemSpecVar = aDCSpec->findDCSpec(strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].dataCollectionItemName);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosDataCollectionSpecification::findDCSpec);

                    CORBA::String_var dataItemName;
                    dataItemName= aItemSpecVar->dataItemName;
                    if (CIMFWStrLen(dataItemName) == 0)
                    {
                        PPT_METHODTRACE_V1("", "CIMFWStrLen(dataItemName) == 0");
                        strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].targetValue    = CIMFWStrDup("");
                    }
                    else
                    {
                        char dbTarget[256];
                        PPT_METHODTRACE_V1("", "CIMFWStrLen(dataItemName) != 0");
//P3100342                        sprintf(dbTarget, "%lf", aItemSpecVar->target);
//P3100342 add start
                    if (-1.0 < aItemSpecVar->target && aItemSpecVar->target < 1.0)
                    {
                        sprintf(dbTarget, "%LG", aItemSpecVar->target);
                    }
                    else if (-100000000000.0 < aItemSpecVar->target && aItemSpecVar->target < 1000000000000.0)
                    {
                        sprintf( dbTarget, "%lf", aItemSpecVar->target);
                        if (CIMFWStrLen(dbTarget) > 12)
                        {
                            dbTarget[12] = '\0';
                        }
                    }
                    else
                    {
                        sprintf(dbTarget, "%LG", aItemSpecVar->target);
                    }
//P3100342 add end
                        strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].targetValue    = CIMFWStrDup(dbTarget);
                    }
                }
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].specCheckResult        = CIMFWStrDup("");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[j].actionCode.length(0);
            }

            if (delivedItemCnt == 0)
            {
                PPT_METHODTRACE_V1("", "delivedItemCnt == 0");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].calculationRequiredFlag = FALSE;
            }
            else
            {
                PPT_METHODTRACE_V1("", "delivedItemCnt != 0");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[0].calculationRequiredFlag = TRUE;
            }

        }
        /*===== End of Raw-DC Set =====*/

        /*--------------------------------------------*/
        /*                                            */
        /*   Set Returned DCDef Information - Delta   */
        /*                                            */
        /*--------------------------------------------*/
        /*===== Start of Delta-DC Set =====*/
        for (i=1 ; i<=deltaDCDefInfoLen ; i++)
        {
            PPT_METHODTRACE_V3("", "loop to deltaDCDefInfoLen",deltaDCDefInfoLen,i);

            /*===== prepare dDCDef / dDCSpec =====*/
            PosDataCollectionDefinition_var dDCDef;
            PPT_CONVERT_DATACOLDEFID_TO_DATACOLDEF_OR(dDCDef,(*deltaDCDefInfoSeq)[i-1].deltaDCDefinition,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get);

            PosProcessOperation_var dPO;
            PPT_CONVERT_STRING_TO_OBJECT((*deltaDCDefInfoSeq)[i-1].processOperation,dPO, PosProcessOperation);

            PosDataCollectionSpecification_var dDCSpec;
            for (CORBA::Long dd=0 ; dd<deltaDCSpecInfoLen ; dd++)
            {
                PPT_METHODTRACE_V3("", "loop to deltaDCSpecInfoLen",deltaDCSpecInfoLen,dd);

                CORBA::String_var deltaDCDefInfoSeq_deltaDCDefinition;
                CORBA::String_var deltaDCSpecInfoSeq_deltaDCDefinition;
                deltaDCDefInfoSeq_deltaDCDefinition  = (*deltaDCDefInfoSeq)[i-1].deltaDCDefinition.identifier;
//P3000041      deltaDCSpecInfoSeq_deltaDCDefinition = (*deltaDCSpecInfoSeq)[dd].deltaDCDefinition.identifier;
                deltaDCSpecInfoSeq_deltaDCDefinition = deltaDCSpecInfoSeq[dd].deltaDCDefinition.identifier; //P3000041
                if (CIMFWStrCmp(deltaDCDefInfoSeq_deltaDCDefinition,deltaDCSpecInfoSeq_deltaDCDefinition) == 0)
                {
                    PPT_METHODTRACE_V1("", "deltaDCDefInfoSeq_deltaDCDefinition ==deltaDCSpecInfoSeq_deltaDCDefinition");
//P3000041          PPT_CONVERT_DATACOLSPECID_TO_DATACOLSPEC_OR(dDCSpec,(*deltaDCSpecInfoSeq)[dd].deltaDCSpecification,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get);
                    PPT_CONVERT_DATACOLSPECID_TO_DATACOLSPEC_OR(dDCSpec,deltaDCSpecInfoSeq[dd].deltaDCSpecification,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get); //P3000041
                    break;
                }
            }

            /*===== set Delta-DC def info =====*/
            PPT_SET_OBJECT_IDENTIFIER(strProcess_dataCollectionDefinition_Get_out.strDCDef[i].dataCollectionDefinitionID,dDCDef,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get,PosDataCollectionDefinition);
            try
            {
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].description = dDCDef->getDescription();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosDataCollectionDefinition::getDescription);

            try
            {
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].dataCollectionType = dDCDef->getCollectionType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosDataCollectionDefinition::getCollectionType);

            /*===== set Delta-DC spec info =====*/
            if (CORBA::is_nil(dDCSpec) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(dDCSpec) == TRUE");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].specCheckRequiredFlag  = FALSE;
            }
            else
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(dDCSpec) != TRUE");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].specCheckRequiredFlag  = TRUE;
                PPT_SET_OBJECT_IDENTIFIER(strProcess_dataCollectionDefinition_Get_out.strDCDef[i].dataCollectionSpecificationID,dDCSpec,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get,PosDataCollectionSpecification);
            }

            /*===== set Delta-DC item info =====*/
            PosDCItemDefinitionSequence* dcItemSeq = NULL; //P2200204
            PosDCItemDefinitionSequence_var varDcItemSeq;
            try
            {
                dcItemSeq = dDCDef->getDCItems();
                varDcItemSeq = dcItemSeq;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosDataCollectionDefinition::getDCItems);

            CORBA::Long itemLen;
            itemLen = dcItemSeq->length();

            strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem.length(itemLen);

            CORBA::Long delivedItemCnt = 0;
            for (CORBA::Long j=0 ; j<itemLen ; j++)
            {
                PPT_METHODTRACE_V3("","loop to dcItemSeq->length()",itemLen,j);
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].dataCollectionItemName = (*dcItemSeq)[j].dataItemName;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].dataCollectionMode     = (*dcItemSeq)[j].dataCollectionMethod;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].dataCollectionUnit     = (*dcItemSeq)[j].unitOfMeasure;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].dataType               = (*dcItemSeq)[j].valType;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].itemType               = (*dcItemSeq)[j].itemType;

                CORBA::String_var itemType;
                itemType = strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].itemType;
                //D5100004 if (CIMFWStrCmp(itemType,SP_DCDef_Item_Derived) == 0)
                if (CIMFWStrCmp(itemType,SP_DCDef_Item_Derived) == 0 || CIMFWStrCmp(itemType,SP_DCDef_Item_UserFunction) == 0)    //D5100004
                {
                     PPT_METHODTRACE_V1("","itemType == SP_DCDef_Item_Derived");
                    delivedItemCnt++;
                }
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].measurementType        = (*dcItemSeq)[j].measType;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].waferID.identifier     = CIMFWStrDup("");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].waferPosition          = (*dcItemSeq)[j].waferPosition;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].sitePosition           = (*dcItemSeq)[j].sitePosition;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].historyRequiredFlag    = (*dcItemSeq)[j].isStored;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].calculationType        = (*dcItemSeq)[j].calculationType;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].calculationExpression  = (*dcItemSeq)[j].calculationExpression;
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].dataValue              = CIMFWStrDup("");
                /*===== get from DCSpec =====*/
                if (CORBA::is_nil(dDCSpec) == TRUE)
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(dDCSpec) == TRUE");
                    strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].targetValue        = CIMFWStrDup("");
                }
                else
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(dDCSpec) != TRUE");
                    posDCItemSpecification_var aItemSpecVar;
                    try
                    {
                        aItemSpecVar = dDCSpec->findDCSpec(strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].dataCollectionItemName);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosDataCollectionSpecification::findDCSpec);

                    CORBA::String_var dataItemName;
                    dataItemName = aItemSpecVar->dataItemName;
                    if (CIMFWStrLen(dataItemName) == 0)
                    {
                        PPT_METHODTRACE_V1("", "CIMFWStrLen(dataItemName) == 0");
                        strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].targetValue    = CIMFWStrDup("");
                    }
                    else
                    {
                        char dbTarget[256];
                        PPT_METHODTRACE_V1("", "CIMFWStrLen(dataItemName) != 0");
//P3100342                        sprintf(dbTarget, "%lf", aItemSpecVar->target);
//P3100342 add start
                    if (-1.0 < aItemSpecVar->target && aItemSpecVar->target < 1.0)
                    {
                        sprintf(dbTarget, "%LG", aItemSpecVar->target);
                    }
                    else if (-100000000000.0 < aItemSpecVar->target && aItemSpecVar->target < 1000000000000.0)
                    {
                        sprintf( dbTarget, "%lf", aItemSpecVar->target);
                        if (CIMFWStrLen(dbTarget) > 12)
                        {
                            dbTarget[12] = '\0';
                        }
                    }
                    else
                    {
                        sprintf(dbTarget, "%LG", aItemSpecVar->target);
                    }
//P3100342 add end
                        strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].targetValue    = CIMFWStrDup(dbTarget);
                    }
                }
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].specCheckResult        = CIMFWStrDup("");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[j].actionCode.length(0);
            }

            if (delivedItemCnt == 0)
            {
                PPT_METHODTRACE_V1("", "delivedItemCnt == 0");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].calculationRequiredFlag = FALSE;
            }
            else
            {
                PPT_METHODTRACE_V1("", "delivedItemCnt != 0");
                strProcess_dataCollectionDefinition_Get_out.strDCDef[i].calculationRequiredFlag = TRUE;
            }

            /*-------------------------------------*/
            /*   Set Delta ProcessOperation Info   */
            /*-------------------------------------*/
            if (CORBA::is_nil(dPO) != TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(dPO) != TRUE");

                PosDataCollectionDefinition_var pDCDef;
                try
                {
                    pDCDef = dPO->getAssignedDCDef();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedDCDef);

                if (CORBA::is_nil(pDCDef) == TRUE)
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(pDCDef) == TRUE");
                    PPT_SET_MSG_RC_KEY(strProcess_dataCollectionDefinition_Get_out,MSG_NOT_FOUND_PREVDCDEF, RC_NOT_FOUND_PREVDCDEF, "*****");
                    return(RC_NOT_FOUND_PREVDCDEF);
                }

                PosProcessDefinition_var pPD;
                try
                {
                    pPD = dPO->getProcessDefinition();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessDefinition);

                if (CORBA::is_nil(pPD) == TRUE)
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(pPD) == TRUE");
                    PPT_SET_MSG_RC_KEY(strProcess_dataCollectionDefinition_Get_out,MSG_NOT_FOUND_PREVPD, RC_NOT_FOUND_PREVPD, "*****");
                    return(RC_NOT_FOUND_PREVPD);
                }

                PPT_SET_OBJECT_IDENTIFIER(strProcess_dataCollectionDefinition_Get_out.strDCDef[i].previousDataCollectionDefinitionID,pDCDef,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get,PosDataCollectionDefinition);
                PPT_SET_OBJECT_IDENTIFIER(strProcess_dataCollectionDefinition_Get_out.strDCDef[i].previousOperationID,pPD,strProcess_dataCollectionDefinition_Get_out,process_dataCollectionDefinition_Get,PosProcessDefinition);
                try
                {
                    strProcess_dataCollectionDefinition_Get_out.strDCDef[i].previousOperationNumber = dPO->getOperationNumber();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber);
            }
//D4100157 add start
            /*-----------------------------------*/
            /* Get actual start info of delta PO */
            /*-----------------------------------*/
            //P4200192 Add Start
            if (CORBA::is_nil(dPO))
            {
                PPT_METHODTRACE_V1("", "dPO is Nil");
                PPT_SET_MSG_RC_KEY2(strProcess_dataCollectionDefinition_Get_out,MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "",lotID.identifier);
                return(RC_NOT_FOUND_PO);
            }
            //P4200192 Add End

            posActualStartInformationForPO_var pActualStartInfo;
            try
            {
                pActualStartInfo = dPO->getActualStartInfo();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getActualStartInfo);

            if( ( pActualStartInfo != NULL ) && pActualStartInfo->assignedDataCollections.length() > 0 )  //P4100543
            {                                                                                             //P4100543

                CORBA::Long pItemLen;
                pItemLen = pActualStartInfo->assignedDataCollections[0].dcItems.length();

                for(CORBA::Long ii=0 ; ii<pItemLen; ii++)
                {
                    PPT_METHODTRACE_V3("","loop to pActualStartInfo->assignedDataCollections[0].dcItems.length()",pItemLen,ii);

                    CORBA::String_var pDcItemName,pWaferPos,pSitePos,pWaferID;
                    pDcItemName = pActualStartInfo->assignedDataCollections[0].dcItems[ii].dataCollectionItemName;
                    pWaferPos = pActualStartInfo->assignedDataCollections[0].dcItems[ii].waferPosition;
                    pSitePos = pActualStartInfo->assignedDataCollections[0].dcItems[ii].sitePosition;
                    pWaferID = pActualStartInfo->assignedDataCollections[0].dcItems[ii].waferID.identifier;

                    /*----------------------*/
                    /* Omit waferID is NULL */
                    /*----------------------*/

                    if(CIMFWStrLen(pWaferID) == 0)
                    {
                        PPT_METHODTRACE_V1("","NULL waferID");
                        continue;
                    }

                    /*----------------------------------------------------*/
                    /* Pre-measured waferID does not exist in current Lot */
                    /*----------------------------------------------------*/
                    Material_var aWafer;
                    try
                    {
                        aWafer = aLot->findMaterialNamed( pWaferID );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::findMaterialNamed)

                    if(CORBA::is_nil(aWafer) == TRUE)
                    {
                        PPT_METHODTRACE_V1("", "CORBA::is_nil(aWafer) == TRUE");
                        continue;
                    }

                    /*------------------------------------*/
                    /* Check and Set pre-measured waferID */
                    /*------------------------------------*/
                    CORBA::Long dItemLen;
                    dItemLen = strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem.length();

                    for(CORBA::Long jj=0; jj<dItemLen; jj++)
                    {
                        PPT_METHODTRACE_V2("","loop to strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem.length()",jj);
//PSN000103711 add start
                        //skip case of derived data item
                        CORBA::String_var dCalcType = strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[jj].calculationType;;
                        PPT_METHODTRACE_V2("","dCalcType",dCalcType);
                        if (0 != CIMFWStrCmp(dCalcType, SP_DCDef_Calc_Delta))
                        {
                            continue;
                        }
//PSN000103711 add end

                        CORBA::String_var dCalcExpression;
                        dCalcExpression = strProcess_dataCollectionDefinition_Get_out.strDCDef[i].strDCItem[jj].calculationExpression;

//P4200057              PosCalculationExpressionInfoSequence* aCalcExpresInfoSeq = NULL ;
                        PosCalculationExpressionInfoSequence_var aCalcExpresInfoSeq = NULL ;                 //P4200057
                        aCalcExpresInfoSeq = convertFromCalculationExpression( dCalcExpression ,TRUE ) ;

                        CORBA::String_var preDcItemName,preWaferPos,preSitePos,postDcItemName,postWaferPos,postSitePos;

                        if( 2 <= aCalcExpresInfoSeq->length() )    //D5100004
                        {                                          //D5100004
                            if( (*aCalcExpresInfoSeq)[0].whichDef == 1 )
                            {
                                PPT_METHODTRACE_V1("","(*aCalcExpresInfoSeq)[0].whichDef == 1");
                                preDcItemName = (*aCalcExpresInfoSeq)[0].itemName;
                                preWaferPos = (*aCalcExpresInfoSeq)[0].waferPosition;
                                preSitePos = (*aCalcExpresInfoSeq)[0].sitePosition;

                                postDcItemName = (*aCalcExpresInfoSeq)[1].itemName;
                                postWaferPos = (*aCalcExpresInfoSeq)[1].waferPosition;
                                postSitePos = (*aCalcExpresInfoSeq)[1].sitePosition;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","(*aCalcExpresInfoSeq)[0].whichDef == 0");
                                preDcItemName = (*aCalcExpresInfoSeq)[1].itemName;
                                preWaferPos = (*aCalcExpresInfoSeq)[1].waferPosition;
                                preSitePos = (*aCalcExpresInfoSeq)[1].sitePosition;

                                postDcItemName = (*aCalcExpresInfoSeq)[0].itemName;
                                postWaferPos = (*aCalcExpresInfoSeq)[0].waferPosition;
                                postSitePos = (*aCalcExpresInfoSeq)[0].sitePosition;
                            }
                        }                                          //D5100004
//PSN000103711 add start
                        // skip the case for delta item pre-post on different position
                        if (0 != CIMFWStrCmp(preWaferPos, postWaferPos))
                        {
                            PPT_METHODTRACE_V1("","preWaferPos!=postWaferPos, skip waferID setting");
                            continue;
                        }
//PSN000103711 add end

                        if(CIMFWStrCmp(pDcItemName,preDcItemName) == 0 && CIMFWStrCmp(pWaferPos,preWaferPos) == 0 && CIMFWStrCmp(pSitePos,preSitePos) == 0 )
                        {
                            PPT_METHODTRACE_V2("","pDcItemName==preDcItemName && pWaferPos==preWaferPos && pSitePos==preSitePos",preDcItemName);

                            CORBA::Long cItemLen;
                            cItemLen = strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem.length();
                            for(CORBA::Long ll=0; ll<cItemLen; ll++)
                            {
                                PPT_METHODTRACE_V2("","loop to strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem.length()",ll);

                                CORBA::String_var cDcItemName,cWaferPos,cSitePos;
                                cDcItemName = strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[ll].dataCollectionItemName;
                                cWaferPos = strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[ll].waferPosition;
                                cSitePos = strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[ll].sitePosition;

                                if(CIMFWStrCmp(cDcItemName,postDcItemName) == 0 && CIMFWStrCmp(cWaferPos,postWaferPos) == 0 && CIMFWStrCmp(cSitePos,postSitePos) == 0 )
                                {
                                    PPT_METHODTRACE_V2("","cDcItemName==postDcItemName && cWaferPos==postWaferPos && cSitePos==postSitePos",postDcItemName);
                                    strProcess_dataCollectionDefinition_Get_out.strDCDef[0].strDCItem[ll].waferID = pActualStartInfo->assignedDataCollections[0].dcItems[ii].waferID;
                                }
                            }
                        }
                    }
                }
            }      //P4100543
//D4100157 add end

        }
        /*===== End of Delta-DC Set =====*/

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        if ( strProcess_dataCollectionDefinition_Get_out.dataCollectionFlag == TRUE )
        {
            CORBA::Long dcDEFLen = strProcess_dataCollectionDefinition_Get_out.strDCDef.length();
            PPT_METHODTRACE_V2("", "<<< dataCollectionFlag >>>", "TRUE");
            PPT_METHODTRACE_V2("", "<<< dcDEF count        >>>",  dcDEFLen);
        }
        else
        {
            CORBA::Long dcDEFLen = strProcess_dataCollectionDefinition_Get_out.strDCDef.length();
            PPT_METHODTRACE_V2("", "<<< dataCollectionFlag >>>", "FALSE");
            PPT_METHODTRACE_V2("", "<<< dcDEF count        >>>",  dcDEFLen);
        }
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::process_dataCollectionDefinition_Get");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strProcess_dataCollectionDefinition_Get_out, process_dataCollectionDefinition_Get, methodName);
}
