//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_APC_LithoCombineFlag_Get.cpp
//


#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_APC_LithoCombineFlag_Get()
//
// Change history:
// Date       Defect#   Person        Comments
// ---------- --------  ------------- -------------------------------------------
// 2017/08/28 INN-R170004 Gary Ke     INN-R170004: APC Litho Combine Flag
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    csObjAPC_LithoCombineFlag_Get_out&   strAPC_LithoCombineFlag_Get_out,
//    const pptObjCommonIn&                   strObjCommonIn,
//    const objectIdentifier&                 routeID,
//    const char*                             operationNumber
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_APC_LithoCombineFlag_Get(
    csObjAPC_LithoCombineFlag_Get_out&   strAPC_LithoCombineFlag_Get_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 routeID,
    const char*                             operationNumber) 

{

    CORBA::Long rc = RC_OK;

    return(RC_OK);
}
