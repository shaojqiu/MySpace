//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_whatNextLotList_to_StartCassetteForSLMDeliveryReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"
#include "plcrc.hh"
#include "pprsp.hh"
#include "pmcrc.hh"
#include "plot.hh"
#include "pptconverter.h"
#include "ppcflwx.hh"     //DSN000081739
#include "ppcope.hh"      //DSN000081739

//[Object Function Name]: long   whatNextLotList_to_StartCassetteForSLMDeliveryReq
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/06/27 DSIV00000099 K.Matsuei      SLM(Small Lot Manufacturing) Support.
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
// 2011/09/28 DSN000020767 T.Ishida       Auto Dispatch Control Support
// 2013/10/31 DSN000081739 Shudi Wang     Equipment Monitor Automation Support
// 2015/11/10 DSN000096126 C.Mo           cassette_ListGetDR__100 ==> cassette_ListGetDR__160
//                                        cassette_DBInfo_GetDR__120 ==> cassette_DBInfo_GetDR__160
// 2016/07/27 DSN000101569 C.Mo           cassette_ListGetDR__160 ==> cassette_ListGetDR__170
//                                        cassette_DBInfo_GetDR__160 ==> cassette_DBInfo_GetDR__170
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Jun Zhang      New Transfer State PI/PO.
//
//[Function Description]:
//  This object is make strStartCassette from in-param's pptWhatNextLotList for DeliveryReq.
//  1. make strStartCassette from in-param's pptWhatNextLotList.
//  2. check strStartCassette on each check's process.
//  3. focus strStartCassette with Equipment's multiRecipeCapability and Cassette's multiLotType.
//
//  The following input-parameters must be filled to call this object function.
//  - equipmentID
//  - strPortGroup
//  - strWhatNextLotListInqResult
//
//[Input Parameters]:
//  typedef struct objWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in_struct {
//      objectIdentifier             equipmentID;
//      pptPortGroupSequence         strPortGroup;
//      pptWhatNextLotListInqResult  strWhatNextLotListInqResult;
//      any                          siInfo;
//  } objWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in;
//
//[Output Parameters]:
//  typedef objWhatNextLotList_to_StartCassetteForDeliveryReq_out  objWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//
//[Pseudo Code]:
//

CORBA::Long CS_PPTManager_i::whatNextLotList_to_StartCassetteForSLMDeliveryReq(
    objWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out&  strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
    const pptObjCommonIn&                                      strObjCommonIn,
    objWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in&   strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::whatNextLotList_to_StartCassetteForSLMDeliveryReq");

        const objectIdentifier&            equipmentID = strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in.equipmentID;
        const pptPortGroupSequence&        strPortGroup = strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in.strPortGroup;
        const pptWhatNextLotListInqResult& strWhatNextLotListInqResult = strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in.strWhatNextLotListInqResult;

        /*---------------------------------*/
        /*   Debug Trace Input Parameter   */
        /*---------------------------------*/
{
        PPT_METHODTRACE_V1("","*****************************************************************");
        PPT_METHODTRACE_V1("","  Input Parameter");
        PPT_METHODTRACE_V1("","*****************************************************************");
        PPT_METHODTRACE_V2("","equipmentID__________________________",equipmentID.identifier);
        PPT_METHODTRACE_V1("","=================================================================");
        PPT_METHODTRACE_V2("", "portGroup___________________________", strPortGroup[0].portGroup);
        CORBA::Long ii = 0;
        CORBA::Long jj = 0;
        CORBA::Long len = strPortGroup[0].strPortID.length();
        PPT_METHODTRACE_V2("", "strPortID[0].length_________________", len);
        for (ii=0; ii < len; ii++)
        {
        PPT_METHODTRACE_V2("", "portID /////////////////////////////", strPortGroup[0].strPortID[ii].portID.identifier);
        PPT_METHODTRACE_V2("", "  loadSequenceNoInPortGroup_________", strPortGroup[0].strPortID[ii].loadSequenceNoInPortGroup);
        PPT_METHODTRACE_V2("", "  portUsage_________________________", strPortGroup[0].strPortID[ii].portUsage);
        PPT_METHODTRACE_V2("", "  usageType_________________________", strPortGroup[0].strPortID[ii].usageType);
        PPT_METHODTRACE_V2("", "  loadPurposeType___________________", strPortGroup[0].strPortID[ii].loadPurposeType);
        PPT_METHODTRACE_V2("", "  portState_________________________", strPortGroup[0].strPortID[ii].portState);
        PPT_METHODTRACE_V2("", "  categoryCapability.length()_______", strPortGroup[0].strPortID[ii].categoryCapability.length());
        for (jj=0; jj < strPortGroup[0].strPortID[ii].categoryCapability.length(); jj++)
        {
        PPT_METHODTRACE_V2("", "  categoryCapability________________", strPortGroup[0].strPortID[ii].categoryCapability[jj]);
        }
        }
        PPT_METHODTRACE_V1("","=================================================================");

        PPT_METHODTRACE_V2("", "equipmentCategory___________________", strWhatNextLotListInqResult.equipmentCategory);
        PPT_METHODTRACE_V2("", "processRunSizeMaximum_______________", strWhatNextLotListInqResult.processRunSizeMaximum);
        PPT_METHODTRACE_V2("", "processRunSizeMinimum_______________", strWhatNextLotListInqResult.processRunSizeMinimum);
        len = strWhatNextLotListInqResult.strWhatNextAttributes.length();
        PPT_METHODTRACE_V2("", "strWhatNextAttributes.length________", len);
        for (ii=0; ii < len; ii++)
        {
        PPT_METHODTRACE_V2("", "lotID //////////////////////////////", strWhatNextLotListInqResult.strWhatNextAttributes[ii].lotID.identifier);
        PPT_METHODTRACE_V2("", "  cassetteID________________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].cassetteID.identifier);
        PPT_METHODTRACE_V2("", "  lotType___________________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].lotType);
        PPT_METHODTRACE_V2("", "  multiLotType______________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].multiLotType);
        PPT_METHODTRACE_V2("", "  transferStatus____________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].transferStatus);
        PPT_METHODTRACE_V2("", "  requiredCassetteCategory__________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].requiredCassetteCategory);
        PPT_METHODTRACE_V2("", "  cassetteCategory__________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].cassetteCategory);
        PPT_METHODTRACE_V2("", "  next2requiredCassetteCategory_____", strWhatNextLotListInqResult.strWhatNextAttributes[ii].next2requiredCassetteCategory);
        PPT_METHODTRACE_V2("", "  routeID___________________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].routeID.identifier);
        PPT_METHODTRACE_V2("", "  operationID_______________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].operationID.identifier);
        PPT_METHODTRACE_V2("", "  operationNumber___________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].operationNumber);
        }
        PPT_METHODTRACE_V1("","");
}


        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        CORBA::String_var portGroupID;
        CORBA::String_var multiLotType;

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Check Condition and Get Information                                                                      */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine, equipmentID,
                                         strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                         whatNextLotList_to_StartCassetteForSLMDeliveryReq );

        /*-------------------------------------------*/
        /*   Get Equipment's MultiRecipeCapability   */
        /*-------------------------------------------*/
        CORBA::String_var multiRecipeCapability;
        try
        {
            multiRecipeCapability = aMachine->getMultipleRecipeCapability();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getMultipleRecipeCapability);
        PPT_METHODTRACE_V2("", "aMachine->getMultipleRecipeCapability", multiRecipeCapability);

        /**********************************************************************/
        /*                                                                    */
        /*   Get PortID List                                                  */
        /*                                                                    */
        /**********************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Get PortID List");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        objectIdentifierSequence portID;
        longSequence loadSequenceNumber;
        stringSequence loadPurposeType;

        CORBA::Long PortCount = 0;
        CORBA::Long nPortGrpLen = strPortGroup.length();
        PPT_METHODTRACE_V2("", "strPortGroup.length() =",nPortGrpLen);
        for (CORBA::Long i=0; i<nPortGrpLen; i++)
        {
            CORBA::Long nPortLen = strPortGroup[i].strPortID.length();
            PPT_METHODTRACE_V2("", "strPortGroup[i].strPortID.lenght() =",nPortLen);
            for (CORBA::Long j=0; j<nPortLen; j++)
            {
                if (CIMFWStrCmp(strPortGroup[i].strPortID[j].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
                {
                    PPT_METHODTRACE_V1("", "port.loadPurposeType == EmptyCassette   ...<<continue>>");
                    continue; //[j]
                }
                portID.length(PortCount+1);
                portID[PortCount] = strPortGroup[i].strPortID[j].portID;
                loadSequenceNumber.length(PortCount + 1);
                loadSequenceNumber[PortCount] = strPortGroup[i].strPortID[j].loadSequenceNoInPortGroup;
                loadPurposeType.length(PortCount + 1);
                loadPurposeType[PortCount] = CIMFWStrDup(strPortGroup[i].strPortID[j].loadPurposeType);

                PPT_METHODTRACE_V1("", "-----------------------------------------");
                PPT_METHODTRACE_V2("", "portID.................", portID[PortCount].identifier);
                PPT_METHODTRACE_V2("", "loadSequenceNumber.....", loadSequenceNumber[PortCount]);
                PPT_METHODTRACE_V2("", "loadPurposeType........", loadPurposeType[PortCount]);
                PortCount++;
            }
        }
        PPT_METHODTRACE_V2("","PortCount", PortCount);
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

        /*-----------------------------------------------*/
        /*   Check PortCount and processRunSizeMaximum   */
        /*-----------------------------------------------*/
        PPT_METHODTRACE_V1("","/*-----------------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   Check PortCount and processRunSizeMaximum   */");
        PPT_METHODTRACE_V1("","/*-----------------------------------------------*/");
        CORBA::Long processRunCount = 0;
        CORBA::Long processRunSizeMaximum = strWhatNextLotListInqResult.processRunSizeMaximum;

        PPT_METHODTRACE_V2("","processRunSizeMaximum", processRunSizeMaximum);

        if ( PortCount == 0 || PortCount < processRunSizeMaximum)
        {
            PPT_METHODTRACE_V1("","##### PortCount == 0 || PortCount < processRunSizeMaximum");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST);
            return RC_NOT_FOUND_FILLEDCAST;
        }

        /*---------------------------------------------*/
        /*   Get Equipment's Process Batch Condition   */
        /*---------------------------------------------*/
        PPT_METHODTRACE_V1("","/*-------------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   equipment_processBatchCondition_Get()   */");
        PPT_METHODTRACE_V1("","/*-------------------------------------------*/");
        objEquipment_processBatchCondition_Get_out strEquipment_processBatchCondition_Get_out;
        rc = equipment_processBatchCondition_Get( strEquipment_processBatchCondition_Get_out,
                                                  strObjCommonIn,
                                                  equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### equipment_processBatchCondition_Get() != RC_OK")
            strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strEquipment_processBatchCondition_Get_out.strResult;
            return ( rc );
        }
        PPT_METHODTRACE_V2("","maxBatchSize...........", strEquipment_processBatchCondition_Get_out.maxBatchSize);
        PPT_METHODTRACE_V2("","minBatchSize...........", strEquipment_processBatchCondition_Get_out.minBatchSize);
        PPT_METHODTRACE_V2("","minWaferSize...........", strEquipment_processBatchCondition_Get_out.minWaferSize);
        PPT_METHODTRACE_V2("","cassetteExchangeFlag...", (int)strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag);
        PPT_METHODTRACE_V2("","monitorCreationFlag....", (int)strEquipment_processBatchCondition_Get_out.monitorCreationFlag);
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

        /*-------------------------*/
        /*   Check WIP Lot Count   */
        /*-------------------------*/
        PPT_METHODTRACE_V1("","/*-------------------------*/");
        PPT_METHODTRACE_V1("","/*   Check WIP Lot Count   */");
        PPT_METHODTRACE_V1("","/*-------------------------*/");
        CORBA::Long attrLen = strWhatNextLotListInqResult.strWhatNextAttributes.length();
        PPT_METHODTRACE_V2("","strWhatNextLotListInqResult.strWhatNextAttributes.length()", attrLen);
        if ( 0 == attrLen )
        {
            PPT_METHODTRACE_V1("","0 == strWhatNextAttributes.length");
            SET_MSG_RC( strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST );
            return RC_NOT_FOUND_FILLEDCAST;
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

        /**********************************************************************/
        /*                                                                    */
        /*   Get Empty Cassette                                               */
        /*                                                                    */
        /**********************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Get Empty Cassette");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        objCassetteList_emptyAvailable_Pickup_out strCassetteList_emptyAvailable_Pickup_out;

        if ( TRUE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag
          || TRUE == strEquipment_processBatchCondition_Get_out.monitorCreationFlag )
        {
            PPT_METHODTRACE_V1("","EmptyCassette is necessary");

            /*------------------------*/
            /*   Get Empty Cassette   */
            /*------------------------*/
            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSN000096126            PPT_METHODTRACE_V1("", "/*   cassette_ListGetDR__100()   */");
            PPT_METHODTRACE_V1("", "/*   cassette_ListGetDR__170()   */"); //DSN000096126
            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSN000096126            objCassette_ListGetDR_in__100  strCassette_ListGetDR_in;
//DSN000101569            objCassette_ListGetDR_in__160  strCassette_ListGetDR_in; //DSN000096126
            objCassette_ListGetDR_in__170  strCassette_ListGetDR_in;                                                            //DSN000101569
            strCassette_ListGetDR_in.emptyFlag                  = TRUE;
            strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);
            strCassette_ListGetDR_in.maxRetrieveCount           = -1;
            strCassette_ListGetDR_in.sorterJobCreationCheckFlag = FALSE;
            objectIdentifier dummyID;                                      //DSN000096126
            dummyID.identifier = CIMFWStrDup("");                          //DSN000096126
            strCassette_ListGetDR_in.bankID                     = dummyID; //DSN000096126
            strCassette_ListGetDR_in.durableSubStatus           = dummyID;                                                      //DSN000101569
            strCassette_ListGetDR_in.flowStatus                 = CIMFWStrDup("");                                              //DSN000101569
//DSN000096126            objCassette_ListGetDR_out__100 strCassette_ListGetDR_out;
//DSN000096126            rc = cassette_ListGetDR__100( strCassette_ListGetDR_out,
//DSN000096126                                          strObjCommonIn,
//DSN000096126                                          strCassette_ListGetDR_in );
//DSN000101569            objCassette_ListGetDR_out__160 strCassette_ListGetDR_out; //DSN000096126
//DSN000101569            rc = cassette_ListGetDR__160(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in); //DSN000096126
            objCassette_ListGetDR_out__170 strCassette_ListGetDR_out;                                                           //DSN000101569
            rc = cassette_ListGetDR__170(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);                  //DSN000101569
            if ( rc != RC_OK )
            {
//DSN000096126                PPT_METHODTRACE_V1("", "cassette_ListGetDR__100() rc != RC_OK");
                PPT_METHODTRACE_V1("", "cassette_ListGetDR__170() rc != RC_OK"); //DSN000096126
                strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strCassette_ListGetDR_out.strResult ;
                return( rc );
            }

            PPTConverter converter;
            pptFoundCassetteSequence strFoundCassette;
//DSN000096126            converter.Convert100_to_080(strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette,
//DSN000101569            converter.Convert160_to_080(strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette, //DSN000096126
            converter.Convert170_to_080(strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette,                    //DSN000101569
                                        strFoundCassette );

            /*-----------------------------------*/
            /*   Pick Up Target Empty Cassette   */
            /*-----------------------------------*/
            PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   cassetteList_emptyAvailable_Pickup()   */");
            PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
            rc = cassetteList_emptyAvailable_Pickup( strCassetteList_emptyAvailable_Pickup_out,
                                                     strObjCommonIn,
                                                     strFoundCassette);  // Send to Node of equipmentID.
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### RC_OK != cassetteList_emptyAvailable_Pickup()");
                strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strCassetteList_emptyAvailable_Pickup_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2("","Found Empty Cassette Count--->", strCassetteList_emptyAvailable_Pickup_out.strFoundCassette.length());
        }
        else
        {
            PPT_METHODTRACE_V1("","EmptyCassette is unnecessary");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

        /**********************************************************************/
        /*                                                                    */
        /*   Get and Check FlowBatch Info                                     */
        /*                                                                    */
        /**********************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Get and Check FlowBatch Info");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        PPT_METHODTRACE_V1("", "call flowBatch_CheckConditionForCassetteDelivery()");
        objFlowBatch_CheckConditionForCassetteDelivery_out   strFlowBatch_CheckConditionForCassetteDelivery_out;
        rc = flowBatch_CheckConditionForCassetteDelivery( strFlowBatch_CheckConditionForCassetteDelivery_out,
                                                          strObjCommonIn,
                                                          equipmentID,
                                                          strWhatNextLotListInqResult );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### RC_OK != flowBatch_CheckConditionForCassetteDelivery()");
            strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strFlowBatch_CheckConditionForCassetteDelivery_out.strResult;
            return( rc );
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Make strStartCassette Process                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("","");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  make strStartCassette Process                                           */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        pptStartCassetteSequence  strStartCassette;

        CORBA::Boolean bCheckMinBatchSize = FALSE;
        CORBA::String_var checkMinBatchSize = CIMFWStrDup(getenv(SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY));
        PPT_METHODTRACE_V2("","SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY ---> ", checkMinBatchSize);
        if ( 0 == CIMFWStrCmp(checkMinBatchSize, "1") && 1 < strEquipment_processBatchCondition_Get_out.minBatchSize )
        {
            PPT_METHODTRACE_V1("","bCheckMinBatchSize is 1");
            bCheckMinBatchSize = TRUE;
        }

        CORBA::Long nSetStartCassetteCnt = 0;
        objectIdentifierSequence omitCassetteSeq;
        omitCassetteSeq.length(0);

        while ( 1 ) // MinBatchSize support loop.
        {
            // Reset variable.
            processRunCount = 0;

            CORBA::Long nPortLen = strPortGroup[0].strPortID.length();
            PPT_METHODTRACE_V2("","portID.length", nPortLen);
            strStartCassette.length( nPortLen );

            PPT_METHODTRACE_V2("","strWhatNextLotListInqResult.strWhatNextAttributes.length()", attrLen);
            CORBA::Long startNo = 0;
            CORBA::Boolean bWhileExitFlag = FALSE;
            objectIdentifier baseLogicalRecipeID;
            objectIdentifier baseMachineRecipeID;
            objectIdentifier tmpBaseLogicalRecipeID;
            objectIdentifier tmpBaseMachineRecipeID;

            CORBA::Boolean bAlreadyCheckMonitorCreationFlag = FALSE;
            nSetStartCassetteCnt = 0;
            CORBA::Long nAssignEmptyCassetteCnt = 0;
            objectIdentifierSequence useEmptyCassetteIDSeq;
            objectIdentifierSequence useAssignEmptyCassettePortSeq;
            useEmptyCassetteIDSeq.length( nPortLen );
            useAssignEmptyCassettePortSeq.length( nPortLen );

            CORBA::Long nWIPLotLoopEndCnt = 0;
            CORBA::Long nSaveProcessRunCount = -1;

            while ( processRunCount < processRunSizeMaximum )
            {
                PPT_METHODTRACE_V1("","");
                PPT_METHODTRACE_V1("","while ( processRunCount < processRunSizeMaximum ) --------------------------");
                PPT_METHODTRACE_V2("", "processRunCount =", processRunCount);

                if ( bWhileExitFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("","bWhileExitFlag == TRUE    break!!");
                    break;
                }

                CORBA::Boolean bTmpBaseRecipeFlag = FALSE;      // Temporary Base Recipe Flag

                pptStartCassetteSequence  tmpStartCassette;
                tmpStartCassette.length(0);

                /**********************************************************************************/
                /*                                                                                */
                /*   Set Cassette Info                                                            */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set Cassette Info");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                if ( nSaveProcessRunCount != processRunCount )
                {
                    PPT_METHODTRACE_V1("", "Change processRunCount!!  WIPLot start index <--- 0");
                    startNo = 0;
                    nWIPLotLoopEndCnt = 0;
                }
                nSaveProcessRunCount = processRunCount;

                for ( i=startNo; i < attrLen; i++ )
                {
                    PPT_METHODTRACE_V2("","for-loop counter--------------------------------------[i]",i);

                    PPT_METHODTRACE_V1("","Entry WhatNextData=====================================");
                    PPT_METHODTRACE_V2("","lotID...........................", strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID.identifier);
                    PPT_METHODTRACE_V2("","cassetteID......................", strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier);
                    PPT_METHODTRACE_V2("","lotType.........................", strWhatNextLotListInqResult.strWhatNextAttributes[i].lotType);
                    PPT_METHODTRACE_V2("","multiLotType....................", strWhatNextLotListInqResult.strWhatNextAttributes[i].multiLotType);
                    PPT_METHODTRACE_V2("","transferStatus..................", strWhatNextLotListInqResult.strWhatNextAttributes[i].transferStatus);
                    PPT_METHODTRACE_V2("","stockerID.......................", strWhatNextLotListInqResult.strWhatNextAttributes[i].stockerID.identifier);
                    PPT_METHODTRACE_V2("","logicalRecipeID.................", strWhatNextLotListInqResult.strWhatNextAttributes[i].logicalRecipeID.identifier);
                    PPT_METHODTRACE_V2("","machineRecipeID.................", strWhatNextLotListInqResult.strWhatNextAttributes[i].machineRecipeID.identifier);
                    PPT_METHODTRACE_V2("","totalWaferCount.................", strWhatNextLotListInqResult.strWhatNextAttributes[i].totalWaferCount);
                    PPT_METHODTRACE_V2("","requiredCassetteCategory........", strWhatNextLotListInqResult.strWhatNextAttributes[i].requiredCassetteCategory);
                    PPT_METHODTRACE_V2("","cassetteCategory................", strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteCategory);
                    PPT_METHODTRACE_V2("","next2requiredCassetteCategory...", strWhatNextLotListInqResult.strWhatNextAttributes[i].next2requiredCassetteCategory);
                    PPT_METHODTRACE_V2("","routeID.........................", strWhatNextLotListInqResult.strWhatNextAttributes[i].routeID.identifier);
                    PPT_METHODTRACE_V2("","operationID.....................", strWhatNextLotListInqResult.strWhatNextAttributes[i].operationID.identifier);
                    PPT_METHODTRACE_V2("","operationNumber.................", strWhatNextLotListInqResult.strWhatNextAttributes[i].operationNumber);
                    PPT_METHODTRACE_V1("","=======================================================");

                    /*-----------------------------*/
                    /*   Omit CassetteID is NULL   */
                    /*-----------------------------*/
                    if ( CIMFWStrLen(strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier) == 0 )
                    {
                        PPT_METHODTRACE_V1("","CassetteID is NULL   ..<<continue>>");
                        continue; // [i]
                    }

                    CORBA::Boolean bOmitCassette = FALSE;
                    CORBA::Long lenOmitCst = omitCassetteSeq.length();
                    for ( CORBA::Long m=0; m < lenOmitCst; m++ )
                    {
                        if ( 0 == CIMFWStrCmp(omitCassetteSeq[m].identifier,
                                              strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier) )
                        {
                            bOmitCassette = TRUE;
                            break;
                        }
                    }
                    if ( bOmitCassette )
                    {
                        PPT_METHODTRACE_V1("","Omit CassetteID   ..<<continue>>");
                        continue; // [i]
                    }

                    /*------------------------------------------*/
                    /*   Omit already saved strStartCassette    */
                    /*------------------------------------------*/
                    CORBA::Boolean bFoundFlag = FALSE;
                    CORBA::Long lenStartCassette = strStartCassette.length();
                    PPT_METHODTRACE_V2("","lenStartCassette", lenStartCassette);
                    for ( CORBA::Long j=0; j < lenStartCassette; j++ )
                    {
                        if (CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier,
                                        strStartCassette[j].cassetteID.identifier) == 0)
                        {
                            bFoundFlag = TRUE;
                            break; // [j]
                        }
                    }
                    if ( bFoundFlag == TRUE )
                    {
                        PPT_METHODTRACE_V2("","CassetteID is Exist   ..<<continue>>", strStartCassette[j].cassetteID.identifier);
                        continue; // [i]
                    }

                    /*---------------------------------------------------------------------*/
                    /*   Omit Lot which is not FlowBatchingLots in the case of FlowBatch   */
                    /*---------------------------------------------------------------------*/
                    if ( 0 < CIMFWStrLen(strFlowBatch_CheckConditionForCassetteDelivery_out.flowBatchID.identifier) )
                    {
                        PPT_METHODTRACE_V1("","Omit Lot which is not FlowBatchingLots in the case of FlowBatch");
                        CORBA::Boolean bFound = FALSE;
                        CORBA::Long lenFlowBatchLots = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch.length();
                        for ( j=0; j < lenFlowBatchLots; j++ )
                        {
                            if ( 0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID.identifier,
                                                  strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[j].lotID.identifier) )
                            {
                                bFound = TRUE;
                                break; // [j]
                            }
                        } //end of [j]
                        if ( FALSE == bFound )
                        {
                            PPT_METHODTRACE_V1("","LotID is not FlowBatchingLots   ..<<continue>>");
                            continue; // [i]
                        }

                        PPT_METHODTRACE_V2("","Lot is FlowBatching Lot!!", strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID.identifier);
                    }

//DSN000081739 Add Start
                    //----------------------------------------------------------------------------------------
                    //   Omit lot if "Monitor" label is put on lot's process and the lot doesn't have EqpMonitor job
                    //----------------------------------------------------------------------------------------
                    if ( 0 == CIMFWStrCmp( getenv(SP_EQPMONITOR_SWITCH), "1" ) )
                    {
                        PPT_METHODTRACE_V1("","SP_EQPMONITOR_SWITCH is 1");

                        //Check Lot type
                        objLot_lotType_Get_out strLot_lotType_Get_out;
                        objLot_lotType_Get_in  strLot_lotType_Get_in;
                        strLot_lotType_Get_in.lotID = strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID;
                        rc = lot_lotType_Get(strLot_lotType_Get_out,strObjCommonIn,strLot_lotType_Get_in);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
                            strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strLot_lotType_Get_out.strResult;
                            return (rc);
                        }
                        if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
                          || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot))
                        {
                            PPT_METHODTRACE_V1("","lotType is Equipment Monitor or Dummy.");
                            objLot_eqpMonitorOperationLabel_Get_out strLot_eqpMonitorOperationLabel_Get_out;
                            objLot_eqpMonitorOperationLabel_Get_in  strLot_eqpMonitorOperationLabel_Get_in;
                            strLot_eqpMonitorOperationLabel_Get_in.lotID = strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID;
                            rc = lot_eqpMonitorOperationLabel_Get( strLot_eqpMonitorOperationLabel_Get_out,
                                                                   strObjCommonIn,
                                                                   strLot_eqpMonitorOperationLabel_Get_in );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "lot_eqpMonitorOperationLabel_Get() != RC_OK", rc);
                                strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strLot_eqpMonitorOperationLabel_Get_out.strResult;
                                return (rc);
                            }
                            CORBA::Boolean bMonitorLabel = FALSE;
                            for ( CORBA::ULong x=0; x<strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq.length(); x++ )
                            {
                                PPT_METHODTRACE_V2("","Loop through strEqpMonitorLabelInfoSeq",x);
                                if( 0 == CIMFWStrCmp(strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq[x].operationLabel,SP_EqpMonitor_OpeLabel_Monitor) )
                                {
                                    PPT_METHODTRACE_V1("","Found Monitor label.");
                                    bMonitorLabel = TRUE;
                                    break;
                                }
                            }

                            if ( TRUE == bMonitorLabel )
                            {
                                PPT_METHODTRACE_V1("","bMonitorLabel is TRUE.");
                                objLot_eqpMonitorJob_Get_out strLot_eqpMonitorJob_Get_out;
                                objLot_eqpMonitorJob_Get_in  strLot_eqpMonitorJob_Get_in;
                                strLot_eqpMonitorJob_Get_in.lotID = strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID;
                                rc = lot_eqpMonitorJob_Get(strLot_eqpMonitorJob_Get_out,strObjCommonIn,strLot_eqpMonitorJob_Get_in);
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "lot_eqpMonitorJob_Get() rc != RC_OK", rc);
                                    strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strLot_eqpMonitorJob_Get_out.strResult;
                                    return rc;
                                }

                                if( 0 == CIMFWStrLen(strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.eqpMonitorJobID.identifier))
                                {
                                    PPT_METHODTRACE_V1("", "eqpMonitorJobID is not attached to lot");
                                    continue;
                                }

                                PosLot_var aPosLot;
                                PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID,strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,whatNextLotList_to_StartCassetteForSLMDeliveryReq);
                                PosProcessOperation_var aPosPO;
                                try
                                {
                                    ProcessOperation_var aPO = aPosLot->getProcessOperation();
                                    aPosPO = PosProcessOperation::_narrow(aPO);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);
                                if( CORBA::is_nil(aPosPO) )
                                {
                                    PPT_METHODTRACE_V1("", "aPosPO is nill");
                                    PPT_SET_MSG_RC_KEY2( strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                                         MSG_NOT_FOUND_PO,
                                                         RC_NOT_FOUND_PO,
                                                         "",
                                                         strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID.identifier );
                                    return RC_NOT_FOUND_PO;
                                }

                                CORBA::String_var strOPNumber;
                                try
                                {
                                    strOPNumber = aPosPO->getOperationNumber();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber);
                                PosProcessFlowContext_var aPFX ;
                                try
                                {
                                    aPFX = aPosLot->getProcessFlowContext() ;
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);
                                if ( CORBA::is_nil(aPFX) == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "CORBA::is_nil(aPFX)")

                                    PPT_SET_MSG_RC_KEY(strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                                       MSG_NOT_FOUND_PFX,
                                                       RC_NOT_FOUND_PFX,
                                                       "");

                                    return( RC_NOT_FOUND_PFX );
                                }

                                CORBA::String_var strEqpMonitorKey;
                                try
                                {
                                    strEqpMonitorKey = aPFX->getEqpMonOperationKey(strOPNumber);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getEqpMonOperationKey);

                                if( 0 != CIMFWStrCmp(strEqpMonitorKey, strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.monitorOpeKey))
                                {
                                    //The EqpMonitor job is for another Monitor process
                                    PPT_METHODTRACE_V1("","EqpMonitorKey is not same.");
                                    continue;
                                }
                                else
                                {
                                    // Check OK
                                    PPT_METHODTRACE_V1("","EqpMonitorKey is same.");
                                }
                            }
                        }
                    }
//DSN000081739 Add End

                    /*--------------------------------*/
                    /*   Search Port for ProcessLot   */
                    /*--------------------------------*/
                    PPT_METHODTRACE_V1("","Search Port for ProcessLot");
                    CORBA::Long nAssignPortIdx = -1;
                    CORBA::Long lenAssignPort = useAssignEmptyCassettePortSeq.length();
                    CORBA::Long lenPort = portID.length();
                    PPT_METHODTRACE_V2("","lenAssignPort.....", lenAssignPort);
                    PPT_METHODTRACE_V2("","lenPort...........", lenPort);
                    for ( j=0; j < lenPort; j++ )
                    {
                        CORBA::Boolean bFoundPort = FALSE;

                        for ( CORBA::Long k=0; k < lenAssignPort; k++ )
                        {
                            if ( 0 == CIMFWStrLen(useAssignEmptyCassettePortSeq[k].identifier) )
                            {
                                continue; //[k]
                            }
                            if ( 0 == CIMFWStrCmp(useAssignEmptyCassettePortSeq[k].identifier, portID[j].identifier) )
                            {
                                bFoundPort = TRUE;
                                break; //[k]
                            }
                        }
                        if ( TRUE != bFoundPort )
                        {
                            nAssignPortIdx = j;
                            break; //[j]
                        }
                    }
                    if ( 0 > nAssignPortIdx )
                    {
                        PPT_METHODTRACE_V1("","##### 0 > nAssignPortIdx #####");
                        break; //[i]
                    }
                    PPT_METHODTRACE_V2("","assignPortID=====>", portID[nAssignPortIdx].identifier);

                    /*------------------------------------------*/
                    /*   Check Category for Copper/Non Copper   */
                    /*------------------------------------------*/
                    PPT_METHODTRACE_V1("","Check Category for Copper/Non Copper");
                    objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
                    rc = lot_CassetteCategory_CheckForContaminationControl(
                                                strLot_CassetteCategory_CheckForContaminationControl_out,
                                                strObjCommonIn,
                                                strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID,
                                                strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID,
                                                equipmentID,
                                                portID[nAssignPortIdx] );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","UnMatch CarrierCategory (Copper/NonCopper)   ..<<continue>>", rc);
                        continue; //[i]
                    }

                    /*----------------------------------------------------*/
                    /*   Check Stocker which Lot belongs to, Available?   */
                    /*----------------------------------------------------*/
                    objectIdentifier checkID;
//INN-R170003       if ( 0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].transferStatus, SP_TransState_EquipmentIn)
                    if ( 0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].transferStatus, SP_TransState_EquipmentOut)  //INN-R170003
                      && 0 != CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].equipmentID.identifier, equipmentID.identifier) )
                    {
                        checkID = equipmentID;
                        PPT_METHODTRACE_V2("","*** Delivery Process is [EQP to EQP]", checkID.identifier);
                    }
                    else
                    {
                        checkID = strWhatNextLotListInqResult.strWhatNextAttributes[i].stockerID;
                        PPT_METHODTRACE_V2("","*** Delivery Process is [EQP to Stocker]", checkID.identifier);
                    }
                    PPT_METHODTRACE_V2("","Call equipment_CheckAvail()   check EqpID or StockerID --->", checkID.identifier);

                    objEquipment_CheckAvail_out   strEquipment_CheckAvail_out;
                    rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn,
                                               checkID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","RC_OK != equipment_CheckAvail()   ..<<continue>>", strEquipment_CheckAvail_out.strResult.returnCode);
                        continue; //[i]
                    }

                    /*-----------------------*/
                    /*   Check Scrap Wafer   */
                    /*-----------------------*/
                    objectIdentifierSequence cassetteIDs;
                    cassetteIDs.length(1);
                    cassetteIDs[0] = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;

                    PPT_METHODTRACE_V1("", "call cassette_scrapWafer_SelectDR()");
                    objCassette_scrapWafer_SelectDR_out strCassette_scrapWafer_SelectDR_out;
                    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out, strObjCommonIn, cassetteIDs );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### cassette_scrapWafer_SelectDR() != RC_OK", rc);
                        strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
                        return(rc);
                    }
                    CORBA::Long nScrapCnt = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
                    PPT_METHODTRACE_V2("", "nScrapCnt", nScrapCnt);
                    if ( 0 < nScrapCnt )
                    {
                        PPT_METHODTRACE_V1("","Cassette has ScrapWafer ..<<continue>>");
                        continue; //[i]
                    }

//DSN000020767 Add Start
//DSN000096126                    objCassette_DBInfo_GetDR_out__120 strCassette_DBInfo_GetDR_out;
//DSN000096126                    objCassette_DBInfo_GetDR_in__100 strCassette_DBInfo_GetDR_in;
//DSN000096126                    strCassette_DBInfo_GetDR_in.cassetteID = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;
//DSN000096126
//DSN000096126                    rc = cassette_DBInfo_GetDR__120( strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in );
//DSN000096126                    if ( rc != RC_OK )
//DSN000096126                    {
//DSN000096126                        PPT_METHODTRACE_V2("", "cassette_DBInfo_GetDR__120() != RC_OK",rc);
//DSN000096126                        strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strCassette_DBInfo_GetDR_out.strResult ;
//DSN000096126                        return( rc );
//DSN000096126                    }
//DSN000096126 Add Start
//DSN000101569                    objCassette_DBInfo_GetDR_out__160  strCassette_DBInfo_GetDR_out;
                    objCassette_DBInfo_GetDR_out__170  strCassette_DBInfo_GetDR_out;                                            //DSN000101569
                    objCassette_DBInfo_GetDR_in__160   strCassette_DBInfo_GetDR_in;
                    strCassette_DBInfo_GetDR_in.cassetteID                  = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;
                    strCassette_DBInfo_GetDR_in.durableOperationInfoFlag    = FALSE;
                    strCassette_DBInfo_GetDR_in.durableWipOperationInfoFlag = FALSE;
//DSN000101569                    rc = cassette_DBInfo_GetDR__160(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);
                    rc = cassette_DBInfo_GetDR__170(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in); //DSN000101569
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cassette_DBInfo_GetDR__170() != RC_OK",rc);
                        strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strCassette_DBInfo_GetDR_out.strResult;
                        return rc;
                    }
//DSN000096126 Add End

                    CORBA::Long lotLen = 0;
                    CORBA::Long lotCnt = 0;
                    CORBA::Boolean bCastDispatchDisableFlag = FALSE;
                    lotLen = strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteStatusInfo.strContainedLotInfo.length();
                    for( lotCnt = 0; lotCnt < lotLen; lotCnt++ )
                    {
                        if( strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteStatusInfo.strContainedLotInfo[lotCnt].autoDispatchDisableFlag == TRUE )
                        {
                            bCastDispatchDisableFlag = TRUE;
                            break;
                        }
                    }

                    if( bCastDispatchDisableFlag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "##### Cassette Auto Dispatch Disable Flag == TRUE ..<<continue>>");
                        continue; //[i]
                    }
//DSN000020767 Add End

                    tmpStartCassette.length(1);
                    tmpStartCassette[0].cassetteID = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;

                    PPT_METHODTRACE_V2("","Candidate CassetteID--->", tmpStartCassette[0].cassetteID.identifier);

                    /*-------------------------------*/
                    /*   Set Temporary Base Recipe   */
                    /*-------------------------------*/
                    PPT_METHODTRACE_V1("","===== Set Temporary Base Recipe ===============");
                    if ( processRunCount == 0 )
                    {
                        PPT_METHODTRACE_V1("","processRunCount == 0");
                        if ( bTmpBaseRecipeFlag == FALSE )
                        {
                            // Temporary Base Recipe
                            PPT_METHODTRACE_V1("","bTmpBaseRecipeFlag == FALSE");
                            tmpBaseLogicalRecipeID = strWhatNextLotListInqResult.strWhatNextAttributes[i].logicalRecipeID;
                            tmpBaseMachineRecipeID = strWhatNextLotListInqResult.strWhatNextAttributes[i].machineRecipeID;
                            bTmpBaseRecipeFlag = TRUE;

                            PPT_METHODTRACE_V2("","  tmpBaseLogicalRecipeID --->", tmpBaseLogicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","  tmpBaseMachineRecipeID --->", tmpBaseMachineRecipeID.identifier);
                        }
                    }

                    /*-------------------*/
                    /*   Set Port Info   */
                    /*-------------------*/
                    PPT_METHODTRACE_V1("","===== Set Port Info ==================");
                    tmpStartCassette[0].loadSequenceNumber = loadSequenceNumber[nAssignPortIdx];

                    if ( 0 == CIMFWStrCmp(loadPurposeType[nAssignPortIdx], SP_LoadPurposeType_ProcessMonitorLot) )
                    {
                        if ( 0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].lotType, SP_Lot_Type_ProductionMonitorLot) )
                        {
                            PPT_METHODTRACE_V1("","loadPurposeType == ProcessMonitorLot and LotType == ProcessMonitorLot");
                            tmpStartCassette[0].loadPurposeType = CIMFWStrDup(SP_LoadPurposeType_ProcessMonitorLot);
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","UnMatch LoadPurposeType  ..<<continue>>");
                            continue; // [i]
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","Set LoadPurposeType [ProcessLot]");
                        tmpStartCassette[0].loadPurposeType = CIMFWStrDup(SP_LoadPurposeType_ProcessLot);
                    }
                    tmpStartCassette[0].loadPortID = portID[nAssignPortIdx];

                    /*---------------------*/
                    /*   Get PortGroupID   */
                    /*---------------------*/
                    PPT_METHODTRACE_V1("","===== Get PortGroupID ==================");
                    bFoundFlag = FALSE;
                    for ( j=0; j < nPortGrpLen; j++ )
                    {
                        nPortLen = strPortGroup[j].strPortID.length();
                        for ( CORBA::Long k=0; k < nPortLen; k++ )
                        {
                            if ( CIMFWStrCmp(tmpStartCassette[0].loadPortID.identifier, strPortGroup[j].strPortID[k].portID.identifier) == 0 )
                            {
                                portGroupID = CIMFWStrDup(strPortGroup[j].portGroup);
                                bFoundFlag = TRUE;
                                break; // [k]
                            }
                        }
                        if ( bFoundFlag == TRUE )
                        {
                            break; // [j]
                        }
                    } //end of [j]
                    PPT_METHODTRACE_V1("","-------------------------------------------------");
                    PPT_METHODTRACE_V2("","  cassetteID...........", tmpStartCassette[0].cassetteID.identifier);
                    PPT_METHODTRACE_V2("","  loadSequenceNumber...", tmpStartCassette[0].loadSequenceNumber);
                    PPT_METHODTRACE_V2("","  loadPurposeType......", tmpStartCassette[0].loadPurposeType);
                    PPT_METHODTRACE_V2("","  loadPortID...........", tmpStartCassette[0].loadPortID.identifier);
                    PPT_METHODTRACE_V2("","  portGroupID..........", portGroupID);
                    PPT_METHODTRACE_V1("","-------------------------------------------------");

                    /*-----------------------------------*/
                    /*   Get Contained Lot in Cassette   */
                    /*-----------------------------------*/
                    PPT_METHODTRACE_V2("","===== cassette_GetLotList() ==================", tmpStartCassette[0].cassetteID.identifier);
                    objCassette_GetLotList_out strCassette_GetLotList_out;
                    rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, tmpStartCassette[0].cassetteID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK   ...<<continue>>", rc);
                        continue; // [i]
                    }

                    CORBA::Long nLotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
                    PPT_METHODTRACE_V2("","strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length", nLotLen);

                    tmpStartCassette[0].strLotInCassette.length(nLotLen);

                    for (j=0; j < nLotLen; j++)
                    {
                        tmpStartCassette[0].strLotInCassette[j].recipeParameterChangeType = CIMFWStrDup(SP_Rparm_ChangeType_ByLot);
                        tmpStartCassette[0].strLotInCassette[j].operationStartFlag = TRUE;
                        tmpStartCassette[0].strLotInCassette[j].lotID = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[j];

                        PosLot_var aLot;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot, tmpStartCassette[0].strLotInCassette[j].lotID,
                                                     strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                                     whatNextLotList_to_StartCassetteForSLMDeliveryReq );
                        try
                        {
                            tmpStartCassette[0].strLotInCassette[j].lotType = aLot->getLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)
                        PPT_METHODTRACE_V2("", "lotType", tmpStartCassette[0].strLotInCassette[j].lotType);

                        try
                        {
                            tmpStartCassette[0].strLotInCassette[j].subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType)
                        PPT_METHODTRACE_V2("", "subLotType", tmpStartCassette[0].strLotInCassette[j].subLotType);

                        objLot_productID_Get_out  strLot_productID_Get_out;
                        rc = lot_productID_Get( strLot_productID_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "##### lot_productID_Get() != RC_OK")
                            strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strLot_productID_Get_out.strResult;
                            return ( rc );
                        }

                        tmpStartCassette[0].strLotInCassette[j].productID = strLot_productID_Get_out.productID;
                        PPT_METHODTRACE_V2("", "productID", tmpStartCassette[0].strLotInCassette[j].productID.identifier);

                        /*------------------------*/
                        /*   Set Operation Info   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1("", "Set Operation Info")
                        for ( CORBA::Long m=0; m < attrLen; m++ )
                        {
                            if ( 0 == CIMFWStrCmp(tmpStartCassette[0].strLotInCassette[j].lotID.identifier,
                                                  strWhatNextLotListInqResult.strWhatNextAttributes[m].lotID.identifier) )
                            {
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.routeID         = strWhatNextLotListInqResult.strWhatNextAttributes[m].routeID;
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationID     = strWhatNextLotListInqResult.strWhatNextAttributes[m].operationID;
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationNumber = strWhatNextLotListInqResult.strWhatNextAttributes[m].operationNumber;

                                PPT_METHODTRACE_V2("", "lotID          ", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
                                PPT_METHODTRACE_V2("", "routeID        ", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.routeID.identifier);
                                PPT_METHODTRACE_V2("", "operationID    ", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationID.identifier);
                                PPT_METHODTRACE_V2("", "operationNumber", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationNumber);
                                break;
                            }
                        }

                        if ( CIMFWStrCmp(tmpStartCassette[0].loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot ) == 0 )
                        {
                            /*------------------*/
                            /*   Get Lot Type   */
                            /*------------------*/
                            PPT_METHODTRACE_V2("","===== lot_type_Get() ==================", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
                            objLot_type_Get_out strLot_type_Get_out;
                            rc = lot_type_Get( strLot_type_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "lot_type_Get() != RC_OK", rc);
                                continue; // [j]
                            }
                            if ( CIMFWStrCmp(strLot_type_Get_out.theLotType, SP_Lot_Type_ProductionMonitorLot ) == 0 )
                            {
                                PPT_METHODTRACE_V1("","LotType == [MonitorLot]");
                                tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = TRUE;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","LotType != [MonitorLot]");
                                tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = FALSE;
                            }
                        }
                        else
                        {
                            tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = FALSE;
                        }

                        /*-----------------------------------*/
                        /*   Get Contained Wafer in Lot      */
                        /*-----------------------------------*/
                        PPT_METHODTRACE_V2("","===== lot_waferMap_Get() ==================", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
                        objLot_waferMap_Get_out strLot_waferMap_Get_out;
                        rc = lot_waferMap_Get( strLot_waferMap_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "lot_waferMap_Get() != RC_OK   ..<<continue>>");
                            continue; // [j]
                        }
                        CORBA::Long nWafLen = strLot_waferMap_Get_out.strLotWaferMap.length();
                        tmpStartCassette[0].strLotInCassette[j].strLotWafer.length(nWafLen);

                        for ( CORBA::Long k=0; k < nWafLen; k++ )
                        {
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].waferID          = strLot_waferMap_Get_out.strLotWaferMap[k].waferID;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].slotNumber       = strLot_waferMap_Get_out.strLotWaferMap[k].slotNumber;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].controlWaferFlag = strLot_waferMap_Get_out.strLotWaferMap[k].controlWaferFlag;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length(0);

                            PPT_METHODTRACE_V4("","waferID--->", j,k,tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].waferID.identifier);
                        } //end of [k]
                    } //end of [j]

                    PPT_METHODTRACE_V1("", "Finished tmpStartCassette Info  ..<<break!! WhatNextInfo Loop>>");
                    break;  //[i]

                } //end of [i]
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

                /*--------------------------------------------------------------------*/
                /*   It is finished if Loop of WhatNextInfo finishes turning twice.   */
                /*--------------------------------------------------------------------*/
                if ( i >= attrLen - 1 )     // WhatNextInfo was seen to the end.
                {
                    nWIPLotLoopEndCnt++;    // Count it.
                    PPT_METHODTRACE_V2("","Turned WhatNextInfo Loop!!  Therefore Count It", nWIPLotLoopEndCnt);

                    if ( 1 < nWIPLotLoopEndCnt )
                    {
                        PPT_METHODTRACE_V2("","Turned <<Twice>> WhatNextInfo Loop!!   Therefore ..<<break!! WhatNextInfo Loop>>", nWIPLotLoopEndCnt);
                        break;
                    }
                }

                // Set Next Index of WIPLot loop
                startNo = i + 1;

                PPT_METHODTRACE_V1("","----------------------------------------------");
                PPT_METHODTRACE_V1("","make strStartCassette Process  done.");
                PPT_METHODTRACE_V2("","CassetteID", tmpStartCassette[0].cassetteID.identifier);
                PPT_METHODTRACE_V1("","----------------------------------------------");

                if ( 0 == CIMFWStrLen(tmpStartCassette[0].cassetteID.identifier) )
                {
                    PPT_METHODTRACE_V1("","tmpStartCassette[0].cassetteID.identifier is null  ..<<continue>>");
                    continue; //base loop
                }

                /**********************************************************************************/
                /*                                                                                */
                /*   Set logicalRecipeID, machineRecipeID and Set not use operationStartFlag      */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set logicalRecipeID, machineRecipeID and Set not use operationStartFlag");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                PPT_METHODTRACE_V2("","  atteLen", attrLen);
                PPT_METHODTRACE_V2("","  nLotLen", nLotLen);

                for ( CORBA::Long i=0; i < nLotLen; i++ )
                {
                    CORBA::Long bLotFindFlag = FALSE;
                    for ( CORBA::Long j=0; j < attrLen; j++ )
                    {
                        if ( CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[j].lotID.identifier,
                                         tmpStartCassette[0].strLotInCassette[i].lotID.identifier) == 0)
                        {
                            /*--------------------------------------------------------------------------*/
                            /*   Set logicalRecipeID, machineRecipeID for strWhatNextLotListInqResult   */
                            /*--------------------------------------------------------------------------*/
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID
                                                = strWhatNextLotListInqResult.strWhatNextAttributes[j].logicalRecipeID;
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID
                                                = strWhatNextLotListInqResult.strWhatNextAttributes[j].machineRecipeID;
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.physicalRecipeID
                                                = strWhatNextLotListInqResult.strWhatNextAttributes[j].physicalRecipeID;

                            bLotFindFlag = TRUE;

                            PPT_METHODTRACE_V3("","    lotID             ", i, tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                            PPT_METHODTRACE_V3("","      logicalRecipeID ", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID.identifier);
                            PPT_METHODTRACE_V3("","      machineRecipeID ", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID.identifier);
                            PPT_METHODTRACE_V3("","      physicalRecipeID", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.physicalRecipeID);
                        }
                    }
                    if ( bLotFindFlag == FALSE )
                    {
                        /*------------------------------------------------------------*/
                        /*   Set operationStartFlag for strWhatNextLotListInqResult   */
                        /*------------------------------------------------------------*/
                        PPT_METHODTRACE_V2("","      operationStartFlag <--- FALSE", i);
                        tmpStartCassette[0].strLotInCassette[i].operationStartFlag = FALSE;
                    }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


                /**********************************************************************************/
                /*                                                                                */
                /*   Set operationStartFlag for Recipe                                            */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set operationStartFlag for Recipe");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                /*---------------------------------*/
                /*   Get Cassette's MultiLotType   */
                /*---------------------------------*/
                PosCassette_var aCassette;
                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                       tmpStartCassette[0].cassetteID,
                                                       strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                                       whatNextLotList_to_StartCassetteForSLMDeliveryReq );
                try
                {
                    multiLotType = aCassette->getMultiLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType);

                PPT_METHODTRACE_V2("","multiRecipeCapability", multiRecipeCapability);
                PPT_METHODTRACE_V2("","multiLotType         ", multiLotType);

                if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe) == 0 &&
                    CIMFWStrCmp(multiLotType         , SP_Cas_MultiLotType_MultiLotMultiRecipe)   == 0 )
                {
                    PPT_METHODTRACE_V1("", "multiRecipeCapability is [SingleRecipe] and multiLotType is [ML-MR]");

                    CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                    PPT_METHODTRACE_V2("","tmpStartCassette[0].strLotInCassette.length", nLotLen);
                    for (CORBA::Long j=0; j<nLotLen; j++)
                    {
                        // Set operationStartFlag for Recipe
                        PPT_METHODTRACE_V3("","#     lotID", j, tmpStartCassette[0].strLotInCassette[j].lotID.identifier);

                        /*-------------------------------*/
                        /*   Set Temporary Base Recipe   */
                        /*-------------------------------*/
                        if ( processRunCount == 0 )
                        {
                            // Temporary Base Recipe
                            PPT_METHODTRACE_V1("","Temporary Base Recipe");
                        }
                        else
                        {
                            // Final Base Recipe
                            PPT_METHODTRACE_V2("","processRunCount", processRunCount);
                            PPT_METHODTRACE_V1("","Final Base Recipe");
                            tmpBaseLogicalRecipeID = baseLogicalRecipeID;
                            tmpBaseMachineRecipeID = baseMachineRecipeID;
                        }

                        objectIdentifier logicalRecipeID = tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID;
                        objectIdentifier machineRecipeID = tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID;

                        PPT_METHODTRACE_V1("","    Recipe Check");
                        PPT_METHODTRACE_V2("","      tmpBaseLogicalRecipeID", tmpBaseLogicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      tmpBaseMachineRecipeID", tmpBaseMachineRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      logicalRecipeID       ", logicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      machineRecipeID       ", machineRecipeID.identifier);

                        if ( CIMFWStrCmp(tmpBaseLogicalRecipeID.identifier, logicalRecipeID.identifier) == 0 &&
                             CIMFWStrCmp(tmpBaseMachineRecipeID.identifier, machineRecipeID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","tmpBaseLogicalRecipeID == logicalRecipeID && tmpBaseMachineRecipeID == machineRecipeID");
                        }
                        else
                        {
                            PPT_METHODTRACE_V2("","#       operationStartFlag <--- FALSE", j);
                            tmpStartCassette[0].strLotInCassette[j].operationStartFlag = FALSE;
                        }
                    }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   Set operationStartFlag for Recipe");

                /**********************************************************************************/
                /*                                                                                */
                /*   Set StartRecipeParameter                                                     */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set StartRecipeParameter");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                for ( CORBA::Long j=0; j < nLotLen; j++ )
                {
                    if ( TRUE != tmpStartCassette[0].strLotInCassette[j].operationStartFlag )
                    {
                        PPT_METHODTRACE_V1("", "tmpStartCassette[0].strLotInCassette[j].operationStartFlag is FALSE  ..<continue>");
                        continue;
                    }

                    PosLogicalRecipe_var aLogicalRecipe;
                    PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                     tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                                     strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                                                     whatNextLotList_to_StartCassetteForSLMDeliveryReq );

                    PosMachineRecipe_var aMachineRecipe;

                    /************************/
                    /*   Get subLotType     */
                    /************************/
                    PosLot_var aLot ; //DSIV00001443
                    CORBA::String_var subLotType;
                    if( 0 == CIMFWStrLen( tmpStartCassette[0].strLotInCassette[j].subLotType) )
                    {
//DSIV00001443                        PosLot_var aLot ;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                                     tmpStartCassette[0].strLotInCassette[j].lotID,
                                                     strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                                     whatNextLotList_to_StartCassetteForSLMDeliveryReq);
                        try
                        {
                            subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
                    }
                    else
                    {
                        subLotType = tmpStartCassette[0].strLotInCassette[j].subLotType ;
                    }

                    CORBA::Boolean skipFlag = FALSE;
                    objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                    rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                                   SP_FPC_ExchangeType_StartReserveInfo,
                                                   equipmentID,
                                                   tmpStartCassette[0].strLotInCassette[j].lotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                        strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult =
                            strLot_effectiveFPCInfo_Get_out.strResult;
                        return rc;
                    }

                    if( strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "MachineRecipe is overwritten by FPC");
                    }
                    else
                    {
                        if( searchCondition == 1 )                                                                     //DSIV00001443
                        {                                                                                              //DSIV00001443
                            if( CORBA::is_nil(aLot) == TRUE )                                                          //DSIV00001443
                            {                                                                                          //DSIV00001443
                                PPT_CONVERT_LOTID_TO_LOT_OR( aLot,                                                     //DSIV00001443
                                                             tmpStartCassette[0].strLotInCassette[j].lotID,            //DSIV00001443
                                                             strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, //DSIV00001443
                                                             whatNextLotList_to_StartCassetteForSLMDeliveryReq);       //DSIV00001443
                            }                                                                                          //DSIV00001443
                            try                                                                                        //DSIV00001443
                            {                                                                                          //DSIV00001443
                                aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine );               //DSIV00001443
                            }                                                                                          //DSIV00001443
                            CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)                         //DSIV00001443
                        }                                                                                              //DSIV00001443
                        else                                                                                           //DSIV00001443
                        {                                                                                              //DSIV00001443
                            try
                            {
                                aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType( aMachine, subLotType );
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType)
                        }                                                                                              //DSIV00001443

                        PosRecipeParameterSequence*    recipeParameterSeq = NULL;
                        PosRecipeParameterSequence_var recipeParameterSeqVar;
                        try
                        {
                            recipeParameterSeq = aLogicalRecipe->findRecipeParametersForSubLotType( aMachine, aMachineRecipe, subLotType );
                            recipeParameterSeqVar = recipeParameterSeq;
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersForSubLotType);

                        CORBA::Long rpmCnt = recipeParameterSeq->length();
                        PPT_METHODTRACE_V2("", "recipeParameterSeq->length()", rpmCnt);

                        CORBA::Long nWafLen = tmpStartCassette[0].strLotInCassette[j].strLotWafer.length();
                        for ( CORBA::Long k=0; k < nWafLen; k++ )
                        {
                            if ( NULL == recipeParameterSeq )
                            {
                                tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length(0);
                            }
                            else
                            {
                                tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length( rpmCnt );

                                for ( CORBA::Long l=0; l < rpmCnt; l++ )
                                {
                                    PPT_METHODTRACE_V2("", "rpmCnt----------------------------", l);
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName = (*recipeParameterSeq)[l].parameterName;
                                    if ( TRUE == (*recipeParameterSeq)[l].useCurrentValueFlag )
                                    {
                                        PPT_METHODTRACE_V1("", "(*recipeParameterSeq)[l].useCurrentValueFlag is TRUE");
                                        tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue = (const char*)"";
                                    }
                                    else
                                    {
                                        tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue = (*recipeParameterSeq)[l].defaultValue;
                                    }
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue = (*recipeParameterSeq)[l].defaultValue;
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag = (*recipeParameterSeq)[l].useCurrentValueFlag;

                                    PPT_METHODTRACE_V2("", ".parameterName _______________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName);
                                    PPT_METHODTRACE_V2("", ".parameterValue ______________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue);
                                    PPT_METHODTRACE_V2("", ".targetValue _________________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue);
                                    PPT_METHODTRACE_V2("", ".useCurrentSettingValueFlag __", (int)tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag);
                                }
                            }
                        }
                    }
                }

                /**********************************************************************************/
                /*                                                                                */
                /*   check strStartCassette Process                                               */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  check strStartCassette Process");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Cassette                                          */
                /*                                                                       */
                /*   The following conditions are checked by this object                 */
                /*                                                                       */
                /*   - controlJobID                                                      */
                /*   - multiLotType                                                      */
                /*   - transferState                                                     */
                /*   - transferReserved                                                  */
                /*   - dispatchState                                                     */
                /*   - maxBatchSize                                                      */
                /*   - minBatchSize                                                      */
                /*   - emptyCassetteCount                                                */
                /*   - cassette'sloadingSequenceNomber                                   */
                /*   - eqp's multiRecipeCapability and recipeParameter                   */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== Check Process for Cassette ==========");
                CORBA::Long saveLoadSequenceNumber = tmpStartCassette[0].loadSequenceNumber;
                tmpStartCassette[0].loadSequenceNumber = 1;

                /*===== for emptyCassetteCount =====*/
                PPT_METHODTRACE_V2("", "cassetteExchangeFlag  ", (int)strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag);
                PPT_METHODTRACE_V2("", "monitorCreationFlag   ", (int)strEquipment_processBatchCondition_Get_out.monitorCreationFlag);
                PPT_METHODTRACE_V2("", "minBatchSize          ", strEquipment_processBatchCondition_Get_out.minBatchSize);

                if ( strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag == TRUE ||
                     strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == TRUE ||
                     strEquipment_processBatchCondition_Get_out.minBatchSize > 1)
                {
                    PPT_METHODTRACE_V1("", "cassetteExchangeFlag == TRUE or monitorCreationFlag  == TRUE or minBatchSize > 1");
                    PPT_METHODTRACE_V1("", "call cassette_CheckConditionForDelivery()");
                    objCassette_CheckConditionForDelivery_out strCassette_CheckConditionForDelivery_out;
                    rc = cassette_CheckConditionForDelivery( strCassette_CheckConditionForDelivery_out,
                                                             strObjCommonIn,
                                                             equipmentID,
                                                             portGroupID,
                                                             tmpStartCassette,
                                                             SP_Operation_StartReservation );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "cassette_CheckConditionForDelivery() != RC_OK   ..<<continue>>");
                        continue; //base loop
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "!cassetteExchangeFlag == TRUE or monitorCreationFlag  == TRUE or minBatchSize > 1");
                    PPT_METHODTRACE_V1("", "call cassette_CheckConditionForOperation()");

                    objCassette_CheckConditionForOperation_out strCassette_CheckConditionForOperation_out;
                    rc = cassette_CheckConditionForOperation( strCassette_CheckConditionForOperation_out,
                                                              strObjCommonIn,
                                                              equipmentID,
                                                              portGroupID,
                                                              tmpStartCassette,
                                                              SP_Operation_StartReservation );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "cassette_CheckConditionForOperation() != RC_OK   ..<<continue>>");
                        continue; //base loop
                    }
                }

                tmpStartCassette[0].loadSequenceNumber = saveLoadSequenceNumber;

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Lot                                               */
                /*                                                                       */
                /*   The following conditions are checked by this object                 */
                /*                                                                       */
                /*   - controlJobID                                                      */
                /*   - lot's equipmentID                                                 */
                /*   - lotHoldState                                                      */
                /*   - lotProcessState                                                   */
                /*   - lotInventoryState                                                 */
                /*   - entityInhibition                                                  */
                /*   - minWaferCount                                                     */
                /*   - equipment's availability for specified lot                        */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== lot_CheckConditionForOperation() ==========");
                objLot_CheckConditionForOperation_out strLot_CheckConditionForOperation_out;
                rc = lot_CheckConditionForOperation( strLot_CheckConditionForOperation_out,
                                                     strObjCommonIn,
                                                     equipmentID,
                                                     portGroupID,
                                                     tmpStartCassette,
                                                     SP_Operation_CassetteDelivery );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_CheckConditionForOperation() != RC_OK   ..<<continue>>");
                    continue; //base loop
                }

                /*-----------------------------------------------------------------------------*/
                /*                                                                             */
                /*   Check Equipment Port for Start Reservation                                */
                /*                                                                             */
                /*   The following conditions are checked by this object                       */
                /*                                                                             */
                /*   1. In-parm's portGroupID must not have controlJobID.                      */
                /*   2. All of ports' loadMode must be CIMFW_PortRsc_Input or _InputOutput.    */
                /*   3. All of port, which is registered as in-parm's portGroup, must be       */
                /*      _LoadAvail or _LoadReq when equipment is online.                       */
                /*      As exceptional case, if equipment's takeOutInTransferFlag is True,     */
                /*      _UnloadReq is also OK for start reservation when equipment is Online.  */
                /*   4. All of port, which is registered as in-parm's portGroup,               */
                /*      must not have loadedCassetteID.                                        */
                /*   5. strStartCassette[].loadPortID's portGroupID must be same               */
                /*      as in-parm's portGroupID.                                              */
                /*   6. strStartCassette[].loadPurposeType must be match as specified port's   */
                /*      loadPutposeType.                                                       */
                /*   7. strStartCassette[].loadSequenceNumber must be same as specified port's */
                /*      loadSequenceNumber.                                                    */
                /*                                                                             */
                /*-----------------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== equipment_portState_CheckForStartReservation() ==========");
                objEquipment_portState_CheckForStartReservation_out strEquipment_portState_CheckForStartReservation_out;
                rc = equipment_portState_CheckForStartReservation( strEquipment_portState_CheckForStartReservation_out,
                                                                   strObjCommonIn,
                                                                   equipmentID,
                                                                   portGroupID,
                                                                   tmpStartCassette );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "equipment_portState_CheckForStartReservation() != RC_OK   ..<<continue>>");
                    continue; //base loop
                }

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Process Durable                                   */
                /*                                                                       */
                /*   The following conditions are checked by this object                 */
                /*                                                                       */
                /*   1. Whether equipment requires process durable or not                */
                /*      If no-need, return OK;                                           */
                /*                                                                       */
                /*   2. At least one of reticle / fixture for each reticleGroup /        */
                /*      fixtureGroup is in the equipment or not.                         */
                /*      Even if required reticle is in the equipment, its status must    */
                /*      be _Available or _InUse.                                         */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== Check Process for Process Durable ==========");

                CORBA::Boolean DurableRequiredFlag = FALSE;

                PPT_METHODTRACE_V1("", "call equipment_processDurableRequiredFlag_Get()");
                objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
                rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out,
                                                               strObjCommonIn,
                                                               equipmentID );
                if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
                {
                    PPT_METHODTRACE_V1("","rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");

                    if ( CIMFWStrCmp(tmpStartCassette[0].loadPurposeType, SP_LoadPurposeType_EmptyCassette) != 0)
                    {
                        PPT_METHODTRACE_V1("","tmpStartCassette[0].loadPurposeType != SP_LoadPurposeType_EmptyCassette");

                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for (CORBA::Long j=0; j<nLotLen; j++)
                        {
                            PPT_METHODTRACE_V2("","counter[j]", j);

                            if ( tmpStartCassette[0].strLotInCassette[j].operationStartFlag == FALSE )
                            {
                                PPT_METHODTRACE_V1("","tmpStartCassette[0].strLotInCassette[j].operationStartFlag == FALSE");
                                continue; //base loop
                            }

                            PPT_METHODTRACE_V2("","logicalRecipeID", tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","machineRecipeID", tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier);

                            /*--------------------------------------------------*/
                            /*   Check Process Durable Condition for OpeStart   */
                            /*--------------------------------------------------*/
                            PPT_METHODTRACE_V1("", "call processDurable_CheckConditionForOpeStart()");
                            objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                            rc = processDurable_CheckConditionForOpeStart( strProcessDurable_CheckConditionForOpeStart_out,
                                                                           strObjCommonIn,
                                                                           equipmentID,
                                                                           tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                                           tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID,
                                                                           tmpStartCassette[0].strLotInCassette[j].lotID );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","processDurable_CheckConditionForOpeStart() != RC_OK");
                                DurableRequiredFlag = TRUE;
                                PPT_METHODTRACE_V1("","DurableRequiredFlag = TRUE");
                                break;
                            }

                            /*---------------------------------------*/
                            /*   Set Available Reticles / Fixtures   */
                            /*---------------------------------------*/
                            tmpStartCassette[0].strLotInCassette[j].strStartRecipe.strStartReticle = strProcessDurable_CheckConditionForOpeStart_out.strStartReticle;
                            tmpStartCassette[0].strLotInCassette[j].strStartRecipe.strStartFixture = strProcessDurable_CheckConditionForOpeStart_out.strStartFixture;
                        }
                        if ( DurableRequiredFlag == TRUE)
                        {
                            PPT_METHODTRACE_V1("","DurableRequiredFlag == TRUE   ..<<continue>>");
                            continue; //base loop
                        }
                    }
                }
                else if ( rc != RC_EQP_PROCDRBL_NOT_REQD )
                {
                    PPT_METHODTRACE_V1("","rc != RC_EQP_PROCDRBL_NOT_REQD   ..<<continue>>");
                    continue; //base loop
                }

                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   check strStartCassette Process");

                /**********************************************************************************/
                /*                                                                                */
                /*   Check multiRecipeCapability and multiLotType                                 */
                /*   and Decide finally to put it in StartCassette                                */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Check multiRecipeCapability and multiLotType");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                //----------------------------------------------------------------------
                //      Equipment's         Cassette's
                // multiRecipeCapability    multiLotType    Same Recipe Check
                // =====================================================================
                // M-Recipe                 SL-SR           FALSE
                //                          ML-SR           FALSE
                //                          ML-MR           FALSE
                // -----------------------  --------------------------------------------
                // S-Recipe                 SL-SR           TRUE
                //                          ML-SR           TRUE
                //                          ML-MR           TRUE
                // -----------------------  --------------------------------------------
                // Batch                    SL-SR           TRUE
                //                          ML-SR           TRUE
                //                          ML-MR           Error
                // -----------------------  --------------------------------------------
                CORBA::Boolean bAddStartCassette = FALSE;

                if ( CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_MultipleRecipe) == 0 )
                {
                    // M-Recipe: SL-SR, ML-SR, ML-MR
                    // Same Recipe Check : FALSE
                    PPT_METHODTRACE_V1("","M-Recipe: SL-SR, ML-SR, ML-MR");
                    PPT_METHODTRACE_V1("","Same Recipe Check : FALSE");

                    PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);

                    bAddStartCassette = TRUE;
                }
                else if ( CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch)      == 0 &&
                          CIMFWStrCmp(multiLotType         , SP_Cas_MultiLotType_MultiLotMultiRecipe) == 0 )
                {
                    // Batch and ML-MR
                    // Error
                    PPT_METHODTRACE_V1("","Batch and ML-MR: continue");
                    continue; //base loop
                }
                else
                {
                    // S-Recipe: SL-SR, ML-SR, ML-MR
                    // Batch   : SL-SR, ML-SR
                    // Same Recipe Check : TRUE
                    PPT_METHODTRACE_V1("","S-Recipe: SL-SR, ML-SR, ML-MR");
                    PPT_METHODTRACE_V1("","Batch   : SL-SR, ML-SR");
                    PPT_METHODTRACE_V1("","Same Recipe Check : TRUE");

                    if ( processRunCount == 0 )
                    {
                        PPT_METHODTRACE_V1("","processRunCount == 0");

                        PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);
                        bAddStartCassette = TRUE;

                        /*------------------------------------------------------------*/
                        /*   Set Base Recipe (First operationStartFlag=TRUE Recipe)   */
                        /*------------------------------------------------------------*/
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for (CORBA::Long i=0; i<nLotLen; i++)
                        {
                            if (tmpStartCassette[0].strLotInCassette[i].operationStartFlag == TRUE)
                            {
                                baseLogicalRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID;
                                baseMachineRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID;
                                break;
                            }
                        }
                        if (CIMFWStrLen(baseLogicalRecipeID.identifier) == 0 || CIMFWStrLen(baseMachineRecipeID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","################## Can not Found Base Recipe!! ###################");
                            PPT_METHODTRACE_V2("","###  baseLogicalRecipeID", baseLogicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","###  baseMachineRecipeID", baseMachineRecipeID.identifier);
                            PPT_METHODTRACE_V1("","##################################################################");
                        }
                    }
                    else
                    {
                        objectIdentifier logicalRecipeID;
                        objectIdentifier machineRecipeID;
                        /*--------------------------------------------------------*/
                        /*   Find Recipe (First operationStartFlag=TRUE Recipe)   */
                        /*--------------------------------------------------------*/
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for (CORBA::Long i=0; i<nLotLen; i++)
                        {
                            if (tmpStartCassette[0].strLotInCassette[i].operationStartFlag == TRUE)
                            {
                                logicalRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID;
                                machineRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID;
                                break;
                            }
                        }
                        if (CIMFWStrLen(logicalRecipeID.identifier) == 0 || CIMFWStrLen(machineRecipeID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","################## Can not Found Recipe!! ###################");
                            PPT_METHODTRACE_V2("","###  logicalRecipeID", logicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","###  machineRecipeID", machineRecipeID.identifier);
                            PPT_METHODTRACE_V1("","#############################################################");
                        }

                        PPT_METHODTRACE_V1("","Recipe Check");
                        PPT_METHODTRACE_V2("","  baseLogicalRecipeID", baseLogicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  baseMachineRecipeID", baseMachineRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  logicalRecipeID    ", logicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  machineRecipeID    ", machineRecipeID.identifier);

                        if ( CIMFWStrCmp(baseLogicalRecipeID.identifier, logicalRecipeID.identifier) == 0 &&
                             CIMFWStrCmp(baseMachineRecipeID.identifier, machineRecipeID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","baseLogicalRecipeID == logicalRecipeID && baseMachineRecipeID == machineRecipeID");

                            PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);

                            bAddStartCassette = TRUE;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","###############################################");
                            PPT_METHODTRACE_V1("","Deferent Recipe.  ...<<<continue>>>");
                            PPT_METHODTRACE_V1("","###############################################");
                            continue; //base loop
                        }
                    }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   Add tmpStartCassette to StartCassette");

                /**********************************************************************************/
                /*                                                                                */
                /*   Add tmpStartCassette to StartCassette                                        */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Add tmpStartCassette to StartCassette");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                if ( TRUE == bAddStartCassette )
                {
                    /*******************************************************************************/
                    /*   Check MonitorCreationFlag                                                 */
                    /*   Only one time of the beginnings                                           */
                    /*******************************************************************************/
                    if ( FALSE == bAlreadyCheckMonitorCreationFlag
                      && TRUE == strEquipment_processBatchCondition_Get_out.monitorCreationFlag )
                    {
                        PPT_METHODTRACE_V1("","===== Check MonitorCreationFlag ==========");
                        PosLogicalRecipe_var aLogicalRecipe;
                        PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                         tmpBaseLogicalRecipeID,
                                                                         strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                                                         whatNextLotList_to_StartCassetteForSLMDeliveryReq );
                        PosProductSpecification_var aMonitorProduct;
                        try
                        {
                            aMonitorProduct = aLogicalRecipe->getMonitorProduct();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::getMonitorProduct)

                        if ( TRUE != CORBA::is_nil(aMonitorProduct) )
                        {
                            //***** EmptyCassette is necessary! *****
                            PPT_METHODTRACE_V1("", "===== Set EmptyCassette for MonitorCreation ==========");

                            /*------------------------------------------------*/
                            /*   Look for Port to assign, and EmptyCassette   */
                            /*------------------------------------------------*/
                            PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                            PPT_METHODTRACE_V1("","/*   Look for Port to assign, and EmptyCassette   */");
                            PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                            objectIdentifier dummyLotID;
                            objCassetteDelivery_SearchEmptyCassetteAssignPort_out strCassetteDelivery_SearchEmptyCassetteAssignPort_out;
                            rc = cassetteDelivery_SearchEmptyCassetteAssignPort(
                                            strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
                                            strObjCommonIn,
                                            dummyLotID,     // Because it is MonitorCreation, it doesn't have Lot
                                            strPortGroup[0].strPortID,
                                            strCassetteList_emptyAvailable_Pickup_out.strFoundCassette,
                                            useEmptyCassetteIDSeq,
                                            useAssignEmptyCassettePortSeq );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","##### NotFound!! Assign EmptyCassette or Assign Port!   set bWhileExitFlag = TRUE  ...<<<continue>>>");
                                bWhileExitFlag = TRUE;
                                continue; //base loop
                            }

                            // Hold EmptyCasstte and Port to prevent duplication
                            PPT_METHODTRACE_V1("", "Hold EmptyCasstte and Port to prevent duplication");
                            useAssignEmptyCassettePortSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;
                            useEmptyCassetteIDSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                            nAssignEmptyCassetteCnt++;
                            PPT_METHODTRACE_V2("", "nAssignEmptyCassetteCnt--------->", nAssignEmptyCassetteCnt);

                            /*-------------------------------------------------------------------------*/
                            /*   Found!! Assign EmptyCassette. ---> Add information on startCassette   */
                            /*   Put it at the head of StartCassette surely!!                          */
                            /*-------------------------------------------------------------------------*/
                            PPT_METHODTRACE_V1("", "Found!! Assign EmptyCassette. ---> Add information on startCassette");

                            strStartCassette[0].loadSequenceNumber = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.loadSequenceNoInPortGroup;
                            strStartCassette[0].cassetteID         = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                            strStartCassette[0].loadPurposeType    = CIMFWStrDup(SP_LoadPurposeType_EmptyCassette);
                            strStartCassette[0].loadPortID         = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;

                            nSetStartCassetteCnt++;

                            PPT_METHODTRACE_V1("","--------------------------------------------------------------------");
                            PPT_METHODTRACE_V2("","strStartCassette[0].loadSequenceNumber", strStartCassette[0].loadSequenceNumber);
                            PPT_METHODTRACE_V2("","strStartCassette[0].cassetteID        ", strStartCassette[0].cassetteID.identifier);
                            PPT_METHODTRACE_V2("","strStartCassette[0].loadPurposeType   ", strStartCassette[0].loadPurposeType);
                            PPT_METHODTRACE_V2("","strStartCassette[0].loadPortID        ", strStartCassette[0].loadPortID.identifier);
                            PPT_METHODTRACE_V1("","--------------------------------------------------------------------");

                            if ( strStartCassette[0].loadSequenceNumber == tmpStartCassette[0].loadSequenceNumber )
                            {
                                PPT_METHODTRACE_V1("","strStartCassette[0].loadSequenceNumber == tmpStartCassette[0].loadSequenceNumber");
                                PPT_METHODTRACE_V1("","@@@@@ Duplication Setting PortInfo!! @@@@@");

                                CORBA::Long lenPortIDs = portID.length();
                                PPT_METHODTRACE_V2("","lenPortIDs", lenPortIDs);
                                if ( 1 < lenPortIDs )
                                {
                                    // Set next port info.
                                    tmpStartCassette[0].loadSequenceNumber = loadSequenceNumber[1];
                                    tmpStartCassette[0].loadPortID = portID[1];
                                    PPT_METHODTRACE_V2("","tmpStartCassette[0].loadSequenceNumber", tmpStartCassette[0].loadSequenceNumber);
                                    PPT_METHODTRACE_V2("","tmpStartCassette[0].loadPortID        ", tmpStartCassette[0].loadPortID.identifier);
                                }
                            }
                        }

                        bAlreadyCheckMonitorCreationFlag = TRUE;
                        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
                    }

                    /*------------------------------------------------------------------------------------------------------*/
                    /*   Selected PortID and CassetteID is stocked.                                                         */
                    /*   Originally this Sequence(useAssignEmptyCassettePortSeq, useEmptyCassetteIDSeq) exists for Empty.   */
                    /*   But, by D4200302, Cassette must assign also to AnyPort.                                            */
                    /*   Here, if it does not set to these Sequences, following problem arises                              */
                    /*                                               by cassetteDelivery_SearchEmptyCassetteAssignPort().   */
                    /*     Equipment is CassetteExchange Type.                                                              */
                    /*                                                                                                      */
                    /*     PortID  PortGrp  Purpose                                                                         */
                    /*     --------------------------                                                                       */
                    /*       P1       A       Any                                                                           */
                    /*       P2       A       Any                                                                           */
                    /*                                                                                                      */
                    /*    First, P1 is assigned with ProcessLot.                                                            */
                    /*    Next, Search EmpPort by cassetteDelivery_SearchEmptyCassetteAssignPort().                         */
                    /*    But Function chooses P1.                                                                          */
                    /*    Because P1 is not set to useEmptyCassetteIDSeq.                                                   */
                    /*                                                                                                      */
                    /*    It is not necessary to put CassetteID into useAssignEmptyCassettePortSeq.                         */
                    /*    But sequence counter(nAssignEmptyCassetteCnt) becomes mismatching.                                */
                    /*    So, CassetteID is set also to useEmptyCassetteIDSeq.                                              */
                    /*------------------------------------------------------------------------------------------------------*/
                    useAssignEmptyCassettePortSeq[ nAssignEmptyCassetteCnt ] = tmpStartCassette[0].loadPortID;
                    useEmptyCassetteIDSeq[ nAssignEmptyCassetteCnt ] = tmpStartCassette[0].cassetteID;
                    nAssignEmptyCassetteCnt++;

                    PPT_METHODTRACE_V1("", "-----------------------------------------------------");
                    PPT_METHODTRACE_V1("", "[D4200302] Selected PortID and CassetteID is stocked.");
                    PPT_METHODTRACE_V1("", "-----------------------------------------------------");
                    PPT_METHODTRACE_V2("", "PortID-------------------------->", tmpStartCassette[0].loadPortID.identifier);
                    PPT_METHODTRACE_V2("", "CassetteID---------------------->", tmpStartCassette[0].cassetteID.identifier);
                    PPT_METHODTRACE_V2("", "nAssignEmptyCassetteCnt--------->", nAssignEmptyCassetteCnt);

                    /*******************************************************************************/
                    /*   Set EmptyCassette if it is necessary                                      */
                    /*******************************************************************************/
                    if ( TRUE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag )
                    {
                        PPT_METHODTRACE_V1("", "===== Set EmptyCassette for CassetteExchange ==========");

                        /*------------------------------------------------------*/
                        /*   Look for the first Lot when OpeStartFlag is TRUE   */
                        /*------------------------------------------------------*/
                        PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
                        PPT_METHODTRACE_V1("","/*   Look for the first Lot when OpeStartFlag is TRUE   */");
                        PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
                        objectIdentifier targetLotID;
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","tmpStartCassette[0].strLotInCassette.length", nLotLen);
                        for ( CORBA::Long i=0; i < nLotLen; i++ )
                        {
                            PPT_METHODTRACE_V3("","tmpStartCassette[0].strLotInCassette[i].lotID", i, tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                            if ( TRUE == tmpStartCassette[0].strLotInCassette[i].operationStartFlag )
                            {
                                PPT_METHODTRACE_V2("","Found!! Target LotID --->", tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                                targetLotID = tmpStartCassette[0].strLotInCassette[i].lotID;
                                break;
                            }
                        }
                        if ( 0 == CIMFWStrLen(targetLotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","targetLotID is null  ...<<<continue>>>");
                            continue; //base loop
                        }

                        /*------------------------------------------------*/
                        /*   Look for Port to assign, and EmptyCassette   */
                        /*------------------------------------------------*/
                        PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                        PPT_METHODTRACE_V1("","/*   Look for Port to assign, and EmptyCassette   */");
                        PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                        objCassetteDelivery_SearchEmptyCassetteAssignPort_out strCassetteDelivery_SearchEmptyCassetteAssignPort_out;
                        rc = cassetteDelivery_SearchEmptyCassetteAssignPort(
                                        strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
                                        strObjCommonIn,
                                        targetLotID,
                                        strPortGroup[0].strPortID,
                                        strCassetteList_emptyAvailable_Pickup_out.strFoundCassette,
                                        useEmptyCassetteIDSeq,
                                        useAssignEmptyCassettePortSeq );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("","##### NotFound!! Assign EmptyCassette or Assign Port!   set bWhileExitFlag = TRUE  ...<<<continue>>>");
                            bWhileExitFlag = TRUE;
                            continue; //base loop
                        }

                        // Hold EmptyCasstte and Port to prevent duplication
                        PPT_METHODTRACE_V1("", "Hold EmptyCasstte and Port to prevent duplication");
                        useAssignEmptyCassettePortSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;
                        useEmptyCassetteIDSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                        nAssignEmptyCassetteCnt++;
                        PPT_METHODTRACE_V2("", "nAssignEmptyCassetteCnt--------->", nAssignEmptyCassetteCnt);

                        /*-------------------------------------------------------------------------*/
                        /*   Found!! Assign EmptyCassette. -----> Add information on TmpCassette   */
                        /*-------------------------------------------------------------------------*/
                        PPT_METHODTRACE_V1("", "Found!! Assign EmptyCassette. -----> Add information on TmpCassette");
                        CORBA::Long lenTmp = tmpStartCassette.length();
                        tmpStartCassette.length(lenTmp + 1);
                        tmpStartCassette[lenTmp].loadSequenceNumber = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.loadSequenceNoInPortGroup;
                        tmpStartCassette[lenTmp].cassetteID         = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                        tmpStartCassette[lenTmp].loadPurposeType    = CIMFWStrDup(SP_LoadPurposeType_EmptyCassette);
                        tmpStartCassette[lenTmp].loadPortID         = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;

                        PPT_METHODTRACE_V1("","--------------------------------------------------------------------");
                        PPT_METHODTRACE_V3("","tmpStartCassette[lenTmp].loadSequenceNumber", lenTmp, tmpStartCassette[lenTmp].loadSequenceNumber);
                        PPT_METHODTRACE_V3("","tmpStartCassette[lenTmp].cassetteID        ", lenTmp, tmpStartCassette[lenTmp].cassetteID.identifier);
                        PPT_METHODTRACE_V3("","tmpStartCassette[lenTmp].loadPurposeType   ", lenTmp, tmpStartCassette[lenTmp].loadPurposeType);
                        PPT_METHODTRACE_V3("","tmpStartCassette[lenTmp].loadPortID        ", lenTmp, tmpStartCassette[lenTmp].loadPortID.identifier);
                        PPT_METHODTRACE_V1("","--------------------------------------------------------------------");
                    }

                    /*******************************************************************************/
                    /*   Add tmpStartCassette to StartCassette                                     */
                    /*******************************************************************************/
                    PPT_METHODTRACE_V1("","===== Add tmpStartCassette to StartCassette ==========");
                    CORBA::Long lenTmp = tmpStartCassette.length();
                    for ( CORBA::Long j=0; j < lenTmp; j++ )
                    {
                        PPT_METHODTRACE_V2("","Set tmpStartCassette on strStartCassette[n]", nSetStartCassetteCnt);
                        strStartCassette[ nSetStartCassetteCnt ] = tmpStartCassette[j];
                        nSetStartCassetteCnt++;
                    }

                    processRunCount++;
                    PPT_METHODTRACE_V2("","processRunCount++", processRunCount);
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   Add tmpStartCassette to StartCassette");
            }

            PPT_METHODTRACE_V1("","                       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            PPT_METHODTRACE_V2("","Select Cassette Result @@@@@ ProcessRunCount      @@@@@", processRunCount);
            PPT_METHODTRACE_V2("","                       @@@@@ nSetStartCassetteCnt @@@@@", nSetStartCassetteCnt);
            PPT_METHODTRACE_V1("","                       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

            /*-----------------------------------------------------------------------------------------*/
            /*   If selected Carrier does not fulfill MinBatchSize, they are omitted from candidate.   */
            /*-----------------------------------------------------------------------------------------*/
            if ( bCheckMinBatchSize
              && 0 < processRunCount && processRunCount < strEquipment_processBatchCondition_Get_out.minBatchSize )
            {
                PPT_METHODTRACE_V1("", "processRunCount < minBatchSize");
                for ( CORBA::Long m=0; m < nSetStartCassetteCnt; m++ )
                {
                    CORBA::Long lenOmitCst = omitCassetteSeq.length();
                    omitCassetteSeq.length( lenOmitCst + 1 );
                    omitCassetteSeq[ lenOmitCst ] = strStartCassette[m].cassetteID;
                    PPT_METHODTRACE_V2("", "Omit CassetteID", strStartCassette[m].cassetteID.identifier);
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "MinBatchSize support loop");
                break;
            }
        } // MinBatchSize support loop.


        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Final Check                                                                                              */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  Final Check                                                             */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        /*---------------------------*/
        /*   Check processRunCount   */
        /*---------------------------*/
        if ( processRunCount == 0 )
        {
            PPT_METHODTRACE_V1("","processRunCount == 0");
            PPT_METHODTRACE_V1("","##### return RC_NOT_FOUND_FILLEDCAST");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST);
            return RC_NOT_FOUND_FILLEDCAST;
        }

        if ( processRunCount < strEquipment_processBatchCondition_Get_out.minBatchSize )
        {
            PPT_METHODTRACE_V1("","processRunCount < minBatchSize");
            PPT_METHODTRACE_V1("","##### return RC_NOT_FOUND_FILLEDCAST");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST);
            return RC_NOT_FOUND_FILLEDCAST;
        }

        /*-------------------------------*/
        /*   Check Mininum Wafer Count   */
        /*-------------------------------*/
        PPT_METHODTRACE_V1("","Check Mininum Wafer Count");
        CORBA::Long nTotalWaferCount = 0;
        for ( i=0; i < nSetStartCassetteCnt; i++ )
        {
            CORBA::Long lenLot = strStartCassette[i].strLotInCassette.length();
            for ( CORBA::Long j=0; j < lenLot; j++ )
            {
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE )
                {
                    nTotalWaferCount += strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                    PPT_METHODTRACE_V2( "","Add nTotalWaferCount", nTotalWaferCount);
                }
            }
        }
        PPT_METHODTRACE_V2( "","nTotalWaferCount", nTotalWaferCount);
        if ( strEquipment_processBatchCondition_Get_out.minWaferSize > nTotalWaferCount )
        {
            PPT_METHODTRACE_V1( "","##### return RC_INVALID_INPUT_WAFER_COUNT");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, MSG_INVALID_INPUT_WAFER_COUNT, RC_INVALID_INPUT_WAFER_COUNT);
            return RC_INVALID_INPUT_WAFER_COUNT;
        }

//DSIV00000099 start
        //--------------------------------------------------------------------------------------
        // Count the wafer that is Stored or Retrieved in equipment container position.
        //--------------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "Count the wafer that is Stored or Retrieved in equipment container position.");

        objEquipmentContainer_info_GetDR_out strEquipmentContainer_info_GetDR_out;
        objEquipmentContainer_info_GetDR_in strEquipmentContainer_info_GetDR_in;

        strEquipmentContainer_info_GetDR_in.equipmentID = equipmentID;

        PPT_METHODTRACE_V1("", "call equipmentContainer_info_GetDR()");
        rc = equipmentContainer_info_GetDR( strEquipmentContainer_info_GetDR_out,
                                            strObjCommonIn,
                                            strEquipmentContainer_info_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### equipmentContainer_info_GetDR != RC_OK", rc);
            strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strEquipmentContainer_info_GetDR_out.strResult;
            return rc;
        }

        const pptEqpContainerSequence& strEqpContSeq = strEquipmentContainer_info_GetDR_out.strEqpContainerInfo.strEqpContainerSeq;

        CORBA::Long lenEqpCont = strEqpContSeq.length();
        PPT_METHODTRACE_V2("", "lenEqpCont", lenEqpCont);
        if ( 0 == lenEqpCont )
        {
            PPT_METHODTRACE_V1("", "##### return RC_NOT_FOUND_EQPCTN");
            SET_MSG_RC( strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, MSG_NOT_FOUND_EQPCTN, RC_NOT_FOUND_EQPCTN );
            return RC_NOT_FOUND_EQPCTN;
        }

        CORBA::Long waferInEqpCnt = 0;
        CORBA::Long waferNotInEqpCnt = 0;

        CORBA::Long lenEqpContPos = strEqpContSeq[0].strEqpContainerPositionSeq.length();
        PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);
        for ( CORBA::Long nECP=0; nECP < lenEqpContPos; nECP++ )
        {
            PPT_METHODTRACE_V2("", "  controlJobID...", strEqpContSeq[0].strEqpContainerPositionSeq[nECP].controlJobID.identifier);
            PPT_METHODTRACE_V2("", "  lotID..........", strEqpContSeq[0].strEqpContainerPositionSeq[nECP].lotID.identifier);
            PPT_METHODTRACE_V2("", "  waferID........", strEqpContSeq[0].strEqpContainerPositionSeq[nECP].waferID.identifier);
            PPT_METHODTRACE_V2("", "  SLMState.......", strEqpContSeq[0].strEqpContainerPositionSeq[nECP].SLMState);

            if (0 < CIMFWStrLen(strEqpContSeq[0].strEqpContainerPositionSeq[nECP].waferID.identifier))
            {
                waferInEqpCnt++;
                PPT_METHODTRACE_V2("", "  waferInEqpCnt", waferInEqpCnt);
            }
            else
            {
                waferNotInEqpCnt++;
                PPT_METHODTRACE_V2("", "  waferNotInEqpCnt", waferNotInEqpCnt);
            }
        } //[nECP]
        PPT_METHODTRACE_V2("", "Total waferInEqpCnt", waferInEqpCnt);
        PPT_METHODTRACE_V2("", "Total waferNotInEqpCnt", waferNotInEqpCnt);
        PPT_METHODTRACE_V2("", "equipment's maxRsvCount", strEqpContSeq[0].maxRsvCount);

        //--------------------------------------------------------------------------------------
        // Started wafers and wafers that is in equipment must not exceed maxRsvCount of equipment container.
        //--------------------------------------------------------------------------------------
        if ( nTotalWaferCount + waferInEqpCnt > strEqpContSeq[0].maxRsvCount )
        {
            PPT_METHODTRACE_V1("", "##### return RC_NOT_ENOUGH_CONTAINER_SPACE");
            // The starting wafers count [%s] and wafers that is already in container count [%s] exceed max reserve count [%s].

            char strStartWaferCnt[64];
            char strWaferInEqpCnt[64];
            char strMaxRsvCount[64];
            sprintf(strStartWaferCnt, "%ld", nTotalWaferCount);
            sprintf(strWaferInEqpCnt, "%ld", waferInEqpCnt);
            sprintf(strMaxRsvCount, "%ld", strEqpContSeq[0].maxRsvCount);

            PPT_SET_MSG_RC_KEY3( strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
                                 MSG_TOTAL_WAFER_OVER_MAXRSV_COUNT, RC_TOTAL_WAFER_OVER_MAXRSV_COUNT,
                                 strStartWaferCnt, strWaferInEqpCnt, strMaxRsvCount );
            return RC_TOTAL_WAFER_OVER_MAXRSV_COUNT;
        }
//DSIV00000099 end

        if ( 0 < CIMFWStrLen(strFlowBatch_CheckConditionForCassetteDelivery_out.flowBatchID.identifier) )
        {
            PPT_METHODTRACE_V1("","Check!! processRunCount must be the same as FlowBatching Lots Count");
            /*-----------------------------------------------------------------*/
            /*   processRunCount must be the same as FlowBatching Lots Count   */
            /*-----------------------------------------------------------------*/
            CORBA::Long lenFlowBatchLots = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch.length();
            PPT_METHODTRACE_V2("","lenFlowBatchLots", lenFlowBatchLots);
            objectIdentifierSequence cassetteIDSeq;
            cassetteIDSeq.length( lenFlowBatchLots );
            CORBA::Long nFlowBatchCasIdx = 0;
            for ( i=0; i < lenFlowBatchLots; i++ )
            {
                CORBA::Boolean bFound = FALSE;
                CORBA::Long lenCas = cassetteIDSeq.length();
                for ( CORBA::Long j=0; j < lenCas; j++ )
                {
                    if ( 0 == CIMFWStrCmp(cassetteIDSeq[j].identifier,
                                          strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[i].cassetteID.identifier) )
                    {
                        bFound = TRUE;
                        break;
                    }
                }
                if ( TRUE != bFound )
                {
                    cassetteIDSeq[nFlowBatchCasIdx] = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[i].cassetteID;
                    nFlowBatchCasIdx++;
                }
            }
            cassetteIDSeq.length( nFlowBatchCasIdx );
            PPT_METHODTRACE_V2("","nFlowBatchCasIdx", nFlowBatchCasIdx);

            if ( processRunCount != nFlowBatchCasIdx )
            {
                // return [All FlowBatchingLotss weren't select.]
                PPT_METHODTRACE_V1("","##### return RC_NOT_SELECT_ALL_FLOWBATCH_LOTS");
                SET_MSG_RC(strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, MSG_NOT_SELECT_ALL_FLOWBATCH_LOTS, RC_NOT_SELECT_ALL_FLOWBATCH_LOTS);
                return RC_NOT_SELECT_ALL_FLOWBATCH_LOTS;
            }
        }

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Process for FlowBatch                                         */
        /*                                                                       */
        /*   The following conditions are checked by this object                 */
        /*                                                                       */
        /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
        /*      fill  -> all of flowBatch member and in-parm's lot must be       */
        /*               same perfectly.                                         */
        /*      blank -> no check                                                */
        /*                                                                       */
        /*   2. whether lot is in flowBatch section or not                       */
        /*      in    -> lot must have flowBatchID, and flowBatch must have      */
        /*               reserved equipmentID.                                   */
        /*               if lot is on target operation, flowBatch's reserved     */
        /*               equipmentID and in-parm's equipmentID must be same.     */
        /*      out   -> no check                                                */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("","===== equipment_lot_CheckFlowBatchConditionForOpeStart__090() ==========");
        objEquipment_lot_CheckFlowBatchConditionForOpeStart_out__090 strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
        objEquipment_lot_CheckFlowBatchConditionForOpeStart_in__090  strEquipment_lot_CheckFlowBatchConditionForOpeStart_in;
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.equipmentID      = equipmentID;
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.portGroupID      = portGroupID;
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.strStartCassette = strStartCassette;
        rc  = equipment_lot_CheckFlowBatchConditionForOpeStart__090( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
                                                                     strObjCommonIn,
                                                                     strEquipment_lot_CheckFlowBatchConditionForOpeStart_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### RC_OK != equipment_lot_CheckFlowBatchConditionForOpeStart__090()", rc);
            strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.strResult;
            return rc;
        }

        CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );
        if( 1 == tmpFPCAdoptFlag )
        {
            PPT_METHODTRACE_V1("","FPC Adopt Flag is ON. Now apply FPCInfo.");
            objFPCStartCassetteInfo_Exchange_out  strFPCStartCassetteInfo_Exchange_out;
            rc = FPCStartCassetteInfo_Exchange( strFPCStartCassetteInfo_Exchange_out,
                                                strObjCommonIn,
                                                SP_FPC_ExchangeType_StartReserveInfo,
                                                equipmentID,
                                                strStartCassette );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("","FPCStartCassetteInfo_Exchange() != RC_OK", rc);
                strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strResult = strFPCStartCassetteInfo_Exchange_out.strResult;
                return rc;
            }

            strStartCassette = strFPCStartCassetteInfo_Exchange_out.strStartCassette;
        }
        else
        {
            PPT_METHODTRACE_V1("","FPC Adopt Flag is OFF.");
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Set Return Struct                                                                                        */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  Set Return Struct                                                       */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        strStartCassette.length( nSetStartCassetteCnt );
        strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out.strStartCassette = strStartCassette;

        PPT_METHODTRACE_V1("","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        PPT_METHODTRACE_V1("","@@@@@ Normal End.");
        PPT_METHODTRACE_V1("","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");




PPT_METHODTRACE_V1("","******************** DEBUG TRACE StartCassette start ********************");
CORBA::Long lenSC = strStartCassette.length();
for (i=0; i<lenSC; i++)
{
    PPT_METHODTRACE_V2("", "------------------------------------------round[i]", i);
    PPT_METHODTRACE_V2("", "[cassetteID        ]" , strStartCassette[i].cassetteID.identifier );
    PPT_METHODTRACE_V2("", "[loadSequenceNumber]" , strStartCassette[i].loadSequenceNumber );
    PPT_METHODTRACE_V2("", "[loadPurposeType   ]" , strStartCassette[i].loadPurposeType );
    PPT_METHODTRACE_V2("", "[loadPortID        ]" , strStartCassette[i].loadPortID.identifier );

    CORBA::Long nLotInCassetteLen = strStartCassette[i].strLotInCassette.length();
    for (CORBA::Long j=0; j<nLotInCassetteLen; j++)
    {
        PPT_METHODTRACE_V2("", "  [lotID              ]" , strStartCassette[i].strLotInCassette[j].lotID.identifier );
        PPT_METHODTRACE_V2("", "  [lotType            ]" , strStartCassette[i].strLotInCassette[j].lotType);
        PPT_METHODTRACE_V2("", "  [subLotType         ]" , strStartCassette[i].strLotInCassette[j].subLotType );
        PPT_METHODTRACE_V2("", "  [operationStartFlag ]" , (int)strStartCassette[i].strLotInCassette[j].operationStartFlag );
        PPT_METHODTRACE_V2("", "  [monitorLotFlag     ]" , (int)strStartCassette[i].strLotInCassette[j].monitorLotFlag );
    }
}
PPT_METHODTRACE_V1("","******************** DEBUG TRACE StartCassette end ********************");

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::whatNextLotList_to_StartCassetteForSLMDeliveryReq");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out, whatNextLotList_to_StartCassetteForSLMDeliveryReq, methodName);
}

