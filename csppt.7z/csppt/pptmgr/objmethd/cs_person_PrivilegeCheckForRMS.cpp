
#include "cs_pptmgr.hpp"
#include "pcode.hh"
#include "pperson.hh"
#include "pmc.hh"
#include "pstmc.hh"


// Class: CS_PPTManager
//
// Service: cs_person_PrivilegeCheckForRMS()
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//    csObjPerson_PrivilegeCheckForRMS_out&  strCsObjPerson_PrivilegeCheckForRMS,
//    const pptObjCommonIn&                  strObjCommonIn,
//    const objectIdentifier&                equipmentID,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_person_PrivilegeCheckForRMS(
    csObjPerson_PrivilegeCheckForRMS_out&  strCsObjPerson_PrivilegeCheckForRMS,
    const pptObjCommonIn&                  strObjCommonIn,
    const objectIdentifier&                equipmentID)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_person_PrivilegeCheckForRMS");
        /*---------------------------------------*/
        /*   get equipment's department ID       */
        /*---------------------------------------*/
        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         equipmentID,
                                         strCsObjPerson_PrivilegeCheckForRMS,
                                         cs_person_PrivilegeCheckForRMS );
        CORBA::String_var varEqpOwner;
        
        Person_var aPersonForOwner;
        try
        {
            aPersonForOwner = aPosMachine->getOwner();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getOwner)

        if ( CORBA::is_nil(aPersonForOwner) )
        {
            PPT_METHODTRACE_V1("","##### return RC_SYSTEM_ERROR");
            SET_MSG_RC(strCsObjPerson_PrivilegeCheckForRMS,MSG_SYSTEM_ERROR,RC_SYSTEM_ERROR);
            return RC_SYSTEM_ERROR ;
        }
        try
        {
            varEqpOwner = CIMFWStrDup(aPersonForOwner->getIdentifier());
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosPerson::getIdentifier)
        PPT_METHODTRACE_V2("","varEqpOwner", varEqpOwner)

        /*---------------------------------*/
        /*   get user's department ID      */
        /*---------------------------------*/
        CORBA::String_var varUserDepartment;
        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID( aPerson,
                                    strObjCommonIn.strUser.userID,
                                    strCsObjPerson_PrivilegeCheckForRMS,
                                    cs_person_PrivilegeCheckForRMS );

        if ( CORBA::is_nil(aPerson) )
        {
            SET_MSG_RC( strCsObjPerson_PrivilegeCheckForRMS, MSG_NOT_FOUND_PERSON, RC_NOT_FOUND_PERSON)
            return RC_NOT_FOUND_PERSON;
        }
        
        try
        {
            varUserDepartment = aPerson->getDepartment();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosPerson::getDepartment);

        PPT_METHODTRACE_V2("", "varUserDepartment",varUserDepartment);

        /*--------------------------------------------------*/
        /*   Compare eqp's department and user's department */
        /*--------------------------------------------------*/

        if ( CIMFWStrCmp(varUserDepartment, varEqpOwner) !=0 )
        {
            // D02.0146 Add Start
            char chrTempDept[65];

            memset( chrTempDept, '\0', sizeof( chrTempDept ) );
            CIMFWStrCat(chrTempDept,"TD-");
            CIMFWStrCat(chrTempDept,varEqpOwner);
            if ( CIMFWStrCmp(varUserDepartment, chrTempDept) !=0 )
            {
            // D02.0146 Add End 
                PPT_METHODTRACE_V1("", "varUserDepartment != varEqpOwner");
                SET_MSG_RC(strCsObjPerson_PrivilegeCheckForRMS,
                           CS_MSG_USER_RMS_FUNCTION_CHECK_FAIL,
                           CS_RC_USER_RMS_FUNCTION_CHECK_FAIL)
                return CS_RC_USER_RMS_FUNCTION_CHECK_FAIL;
            } //D02.0146
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_person_PrivilegeCheckForRMS")
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCsObjPerson_PrivilegeCheckForRMS, cs_person_PrivilegeCheckForRMS, methodName)
}