//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APCMgr_SendLithoUsedInfoReq.cpp
//

#include "cs_apcsm.hh"
#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APCMgr_SendLithoUsedInfoReq.cpp
//
//
// Innotron Modification History:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009 Nick Tsai      Send used recipe parameter to APC
//
// Function Description:
//
// Input Parameters:
//    csObjAPCMgr_SendLithoUsedInfoReq_out&       strObjAPCMgr_SendLithoUsedInfoReq_out,
//    const pptObjCommonIn&                       strObjCommonIn,
//    const csObjAPCMgr_SendLithoUsedInfoReq_in&  strObjAPCMgr_SendLithoUsedInfoReq_in
//
//typedef struct csObjAPCMgr_SendLithoUsedInfoReq_in_struct {
//    objectIdentifier            equipmentID;
//    pptStartCassetteSequence    strStartCassette;
//    any                         siInfo;
//}csObjAPCMgr_SendLithoUsedInfoReq_in;
//
//
// Output Parameters:
//
//typedef struct csObjAPCMgr_SendLithoUsedInfoReq_out_struct {
//    pptRetCode                      strResult;
//    any                             siInfo;
//}csObjAPCMgr_SendLithoUsedInfoReq_out;
//
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//


CORBA::Long CS_PPTManager_i::cs_APCMgr_SendLithoUsedInfoReq (
    csObjAPCMgr_SendLithoUsedInfoReq_out&       strObjAPCMgr_SendLithoUsedInfoReq_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const csObjAPCMgr_SendLithoUsedInfoReq_in&  strObjAPCMgr_SendLithoUsedInfoReq_in
)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APCMgr_SendLithoUsedInfoReq");

        //================================================================//
        //   Print input parameters                                       //
        //================================================================//
        PPT_METHODTRACE_V2("", "equipmentID ",  strObjAPCMgr_SendLithoUsedInfoReq_in.equipmentID.identifier);

        //================================================================//
        //   Check input parameters                                       //
        //================================================================//
        if ( CIMFWStrLen ( strObjAPCMgr_SendLithoUsedInfoReq_in.equipmentID.identifier) == 0 )
        {
            PPT_METHODTRACE_V1("","CIMFWStrLen ( strObjAPCMgr_SendLithoUsedInfoReq_in.equipmentID.identifier) == 0");
            PPT_SET_MSG_RC_KEY( strObjAPCMgr_SendLithoUsedInfoReq_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, "*******" );
            return RC_NOT_FOUND_EQP;
        }

        if ( strObjAPCMgr_SendLithoUsedInfoReq_in.strStartCassette.length() == 0 )
        {
            PPT_METHODTRACE_V1("","strObjAPCMgr_SendLithoUsedInfoReq_in.strStartCassette.length() == 0");
            SET_MSG_RC( strObjAPCMgr_SendLithoUsedInfoReq_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        //=======================================================================//
        //   1. Prepare APC (Lot & Context & Reticle) data                       //
        //   2. Send used recipe parameters to APC I/F                           //
        //=======================================================================//
        pptStartCassetteSequence strStartCassette = strObjAPCMgr_SendLithoUsedInfoReq_in.strStartCassette;

        CORBA::Long scLen = strStartCassette.length();
        PPT_METHODTRACE_V2("", "strStartCassette.length()", scLen) ;
        for ( CORBA::Long i = 0 ; i < scLen ; i ++ )
        {
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()", nLen) ;

            for ( CORBA::Long j = 0 ; j < nLen ; j ++ )
            {
                //================================================================//
                //   Omit Not-OpeStart Lot                                        //
                //================================================================//
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }
                PPT_METHODTRACE_V2("", "lotID",             strStartCassette[i].strLotInCassette[j].lotID.identifier) ;
                PPT_METHODTRACE_V2("", "routeID",           strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier) ;
                PPT_METHODTRACE_V2("", "operationNumber",   strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber) ;

                //================================================================//
                //   Omit Recommend Flag is FALSE                                 //
                //================================================================//
                csObjAPC_LithoAvailable_CheckCondition_out strAPC_LithoAvailable_CheckCondition_out;
                csObjAPC_LithoAvailable_CheckCondition_in  strAPC_LithoAvailable_CheckCondition_in;
                strAPC_LithoAvailable_CheckCondition_in.equipmentID       = strObjAPCMgr_SendLithoUsedInfoReq_in.equipmentID;
                strAPC_LithoAvailable_CheckCondition_in.routeID           = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                strAPC_LithoAvailable_CheckCondition_in.operationNumber   = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;

                rc = cs_APC_LithoAvailable_CheckCondition( strAPC_LithoAvailable_CheckCondition_out,
                                                           strObjCommonIn,
                                                           strAPC_LithoAvailable_CheckCondition_in ) ;
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "cs_APC_LithoAvailable_CheckCondition() != RC_OK", rc) ;
                    strObjAPCMgr_SendLithoUsedInfoReq_out.strResult = strAPC_LithoAvailable_CheckCondition_out.strResult ;
                    return(rc);
                }

                PPT_METHODTRACE_V2("", "usedFlag",   strAPC_LithoAvailable_CheckCondition_out.usedFlag) ;

                if ( strAPC_LithoAvailable_CheckCondition_out.usedFlag == TRUE )
                {
                    //================================================================//
                    //   Declare APC structure                                        //
                    //================================================================//
                    Innotron_Used_Request  strAPCUsedRequest;

                    //================================================================//
                    //   Prepare APC Lot Info                                         //
                    //================================================================//
                    csObjAPC_LithoLotDataInfo_Get_out strAPC_LithoLotDataInfo_Get_out;
                    csObjAPC_LithoLotDataInfo_Get_in  strAPC_LithoLotDataInfo_Get_in;

                    strAPC_LithoLotDataInfo_Get_in.lotID             = strStartCassette[i].strLotInCassette[j].lotID;
                    strAPC_LithoLotDataInfo_Get_in.routeID           = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                    strAPC_LithoLotDataInfo_Get_in.operationNumber   = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;

                    rc = cs_APC_LithoLotDataInfo_Get( strAPC_LithoLotDataInfo_Get_out,
                                                      strObjCommonIn,
                                                      strAPC_LithoLotDataInfo_Get_in ) ;
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "cs_APC_LithoLotDataInfo_Get() != RC_OK", rc) ;
                        strObjAPCMgr_SendLithoUsedInfoReq_out.strResult = strAPC_LithoLotDataInfo_Get_out.strResult ;
                        return(rc);
                    }

                    PPT_METHODTRACE_V2("", "lotID", strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.lotID.identifier) ;

                    strAPCUsedRequest.LOT_DATA.length(1) ;
                    strAPCUsedRequest.LOT_DATA[0].length(1) ;

                    strAPCUsedRequest.LOT_DATA[0][0].LOTID.length(1) ;
                    strAPCUsedRequest.LOT_DATA[0][0].LOTID[0] = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.lotID.identifier ;

                    CORBA::Long lWaferLen = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq.length();
                    strAPCUsedRequest.LOT_DATA[0][0].WAFERS.length(lWaferLen);
                    for ( CORBA::Long k = 0 ; k > lWaferLen ; k ++ )
                    {
                        PPT_METHODTRACE_V2("", "k",             k) ;
                        PPT_METHODTRACE_V2("", "waferID",       strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].waferID.identifier) ;
                        PPT_METHODTRACE_V2("", "slotNo",        strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].slotNo) ;
                        PPT_METHODTRACE_V2("", "chuckID",       strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].chuckID) ;
                        PPT_METHODTRACE_V2("", "reworkCount",   strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].reworkCount) ;

                        strAPCUsedRequest.LOT_DATA[0][0].WAFERS[k].length(1) ;
                        strAPCUsedRequest.LOT_DATA[0][0].WAFERS[k][0].WAFERID.length(1) ;
                        strAPCUsedRequest.LOT_DATA[0][0].WAFERS[k][0].WAFERID[0] = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].waferID.identifier ;
                        strAPCUsedRequest.LOT_DATA[0][0].WAFERS[k][0].SLOTNO     = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].slotNo ;
                        strAPCUsedRequest.LOT_DATA[0][0].WAFERS[k][0].CHUCKID    = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].chuckID ;
                        strAPCUsedRequest.LOT_DATA[0][0].WAFERS[k][0].REWORK_CNT = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].reworkCount ;
                    }

                    //================================================================//
                    //   Prepare APC Context Info                                     //
                    //================================================================//
                    csObjAPC_LithoContextInfo_Get_out strObjAPC_LithoContextInfo_Get_out;
                    csObjAPC_LithoContextInfo_Get_in  strObjAPC_LithoContextInfo_Get_in ;
                    strObjAPC_LithoContextInfo_Get_in.lotID                        = strStartCassette[i].strLotInCassette[j].lotID;
                    strObjAPC_LithoContextInfo_Get_in.routeID                      = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                    strObjAPC_LithoContextInfo_Get_in.operationNumber              = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;
                    strObjAPC_LithoContextInfo_Get_in.equipmentID                  = strObjAPCMgr_SendLithoUsedInfoReq_in.equipmentID;
                    strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq           = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle;
                    strObjAPC_LithoContextInfo_Get_in.action                       = CIMFWStrDup ( CS_APC_COMBINE_FLAG_ACTION_USED );

                    if ( strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0 )
                    {
                        PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0") ;
                        strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq   = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter;
                    }

                    rc = cs_APC_LithoContextInfo_Get( strObjAPC_LithoContextInfo_Get_out,
                                                      strObjCommonIn,
                                                      strObjAPC_LithoContextInfo_Get_in ) ;
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "cs_APC_LithoContextInfo_Get() != RC_OK", rc) ;
                        strObjAPCMgr_SendLithoUsedInfoReq_out.strResult = strObjAPC_LithoContextInfo_Get_out.strResult ;
                        return(rc);
                    }

                    PPT_METHODTRACE_V2("", "controlJobType",         strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.controlJobType);
                    PPT_METHODTRACE_V2("", "transactionID",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.transactionID);
                    PPT_METHODTRACE_V2("", "recommendTransactionID", strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.recommendTransactionID);
                    PPT_METHODTRACE_V2("", "lotID",                  strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotID);
                    PPT_METHODTRACE_V2("", "lotType",                strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotType);
                    PPT_METHODTRACE_V2("", "partID",                 strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.partID);
                    PPT_METHODTRACE_V2("", "layer",                  strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.layer);
                    PPT_METHODTRACE_V2("", "routeID",                strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeID);
                    PPT_METHODTRACE_V2("", "routeGroup",             strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeGroup);
                    PPT_METHODTRACE_V2("", "operationNumber",        strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.operationNumber);
                    PPT_METHODTRACE_V2("", "reticleID",              strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reticleID);
                    PPT_METHODTRACE_V2("", "processEquipmentType",   strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentType);
                    PPT_METHODTRACE_V2("", "processEquipmentID",     strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentID);
                    PPT_METHODTRACE_V2("", "recommendMode",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.recommendMode);
                    PPT_METHODTRACE_V2("", "reworkLotFlag",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reworkLotFlag);
                    PPT_METHODTRACE_V2("", "parentLotID",            strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.parentLotID);
                    PPT_METHODTRACE_V2("", "preToolID",              strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.preToolID);
                    PPT_METHODTRACE_V2("", "sendAheadFlag",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.sendAheadFlag);
                    PPT_METHODTRACE_V2("", "availableSubUnit",       strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.availableSubUnit);
                    PPT_METHODTRACE_V2("", "chuckDedication",        strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.chuckDedication);

                    strAPCUsedRequest.APC_CONTEXT.CONTROLJOBTYPE[0]    = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.controlJobType;
                    strAPCUsedRequest.APC_CONTEXT.TRANSACTIONID[0]     = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.transactionID;
                    strAPCUsedRequest.APC_CONTEXT.REC_TRANSACTIONID[0] = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.recommendTransactionID;
                    strAPCUsedRequest.APC_CONTEXT.LOTID[0]             = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotID;
                    strAPCUsedRequest.APC_CONTEXT.LOTTYPE[0]           = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotType;
                    strAPCUsedRequest.APC_CONTEXT.PARTID[0]            = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.partID;
                    strAPCUsedRequest.APC_CONTEXT.LAYER[0]             = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.layer;
                    strAPCUsedRequest.APC_CONTEXT.ROUTE[0]             = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeID;
                    strAPCUsedRequest.APC_CONTEXT.ROUTEGROUP[0]        = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeGroup;
                    strAPCUsedRequest.APC_CONTEXT.OPERATION[0]         = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.operationNumber;
                    strAPCUsedRequest.APC_CONTEXT.RETICLEID[0]         = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reticleID;
                    strAPCUsedRequest.APC_CONTEXT.PROCESSEQUIPTYPE[0]  = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentType;
                    strAPCUsedRequest.APC_CONTEXT.PROCESSEQUIPID[0]    = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentID;
                    strAPCUsedRequest.APC_CONTEXT.RECOMMENDMODE[0]     = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.recommendMode;
                    strAPCUsedRequest.APC_CONTEXT.REWORK[0]            = ( strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reworkLotFlag? CIMFWStrDup("TRUE"):CIMFWStrDup("FALSE") );
                    strAPCUsedRequest.APC_CONTEXT.PARENTLOTID[0]       = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.parentLotID;
                    strAPCUsedRequest.APC_CONTEXT.PRETOOL[0]           = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.preToolID;
                    strAPCUsedRequest.APC_CONTEXT.SENDAHEAD[0]         = ( strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.sendAheadFlag? CIMFWStrDup("TRUE"):CIMFWStrDup("FALSE") );
                    strAPCUsedRequest.APC_CONTEXT.AVAILABLE_SUBUNIT[0] = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.availableSubUnit;
                    strAPCUsedRequest.APC_CONTEXT.CHUCK_DEDICATION[0]  = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.chuckDedication;

                    CORBA::Long lExtLen = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends.length();
                    strAPCUsedRequest.APC_CONTEXT.LD_EXTEND.length(lExtLen);
                    for ( k = 0 ; k > lExtLen ; k ++ )
                    {
                        PPT_METHODTRACE_V2("", "k",     k) ;
                        PPT_METHODTRACE_V2("", "name",  strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends[k].name) ;
                        PPT_METHODTRACE_V2("", "value", strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends[k].value) ;

                        strAPCUsedRequest.APC_CONTEXT.LD_EXTEND[k].length(1) ;
                        strAPCUsedRequest.APC_CONTEXT.LD_EXTEND[k][0].NAME.length(1) ;
                        strAPCUsedRequest.APC_CONTEXT.LD_EXTEND[k][0].VALUE.length(1) ;
                        strAPCUsedRequest.APC_CONTEXT.LD_EXTEND[k][0].NAME[0]     = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends[k].name ;
                        strAPCUsedRequest.APC_CONTEXT.LD_EXTEND[k][0].VALUE[0]    = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends[k].value ;
                    }

                    //================================================================//
                    //   Prepare APC Reticle Info                                     //
                    //================================================================//
                    csAPCLithoRecipeParameterSequence  strAPCLithoRecipeParameterSeq_R1;
                    csAPCLithoRecipeParameterSequence  strAPCLithoRecipeParameterSeq_R2;

                    if ( strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0 )
                    {
                        CORBA::Long lRParmLen = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter.length();
                        strAPCLithoRecipeParameterSeq_R1.length(lRParmLen);
                        strAPCLithoRecipeParameterSeq_R2.length(lRParmLen);
                        PPT_METHODTRACE_V2("", "lRParmLen",  lRParmLen) ;

                        CORBA::Long lCnt_R1 = 0 ;
                        CORBA::Long lCnt_R2 = 0 ;
                        for ( k = 0 ; k < lRParmLen ; k ++ )
                        {
                            PPT_METHODTRACE_V2("", "parameterName",  strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter[k].parameterName) ;
                            PPT_METHODTRACE_V2("", "parameterValue", strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter[k].parameterValue) ;
                            if ( CIMFWStrnCmp ( strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter[k].parameterName,
                                                CS_DOUBLE_EXPOSURE_RECIPE_PARM_D1, 3 )  == 0 )
                            {
                                PPT_METHODTRACE_V2("", "lCnt_R1",  lCnt_R1) ;
                                strAPCLithoRecipeParameterSeq_R1[lCnt_R1].parameterName  = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter[k].parameterName;
                                strAPCLithoRecipeParameterSeq_R1[lCnt_R1].parameterValue = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter[k].parameterValue;
                                lCnt_R1 ++ ;
                            }

                            if ( CIMFWStrnCmp ( strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter[k].parameterName,
                                                CS_DOUBLE_EXPOSURE_RECIPE_PARM_D2, 3 )  == 0 )
                            {
                                PPT_METHODTRACE_V2("", "lCnt_R2",  lCnt_R2) ;
                                strAPCLithoRecipeParameterSeq_R2[lCnt_R2].parameterName  = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter[k].parameterName;
                                strAPCLithoRecipeParameterSeq_R2[lCnt_R2].parameterValue = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter[k].parameterValue;
                                lCnt_R2 ++ ;
                            }
                        }
                        PPT_METHODTRACE_V2("", "lCnt_R1",  lCnt_R1) ;
                        PPT_METHODTRACE_V2("", "lCnt_R2",  lCnt_R2) ;

                        strAPCLithoRecipeParameterSeq_R1.length(lCnt_R1);
                        strAPCLithoRecipeParameterSeq_R2.length(lCnt_R2);
                    }

                    CORBA::Long lRTCLLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
                    strAPCUsedRequest.RETICLES.length(lRTCLLen);
                    PPT_METHODTRACE_V2("", "lRTCLLen",  lRTCLLen) ;
                    for ( k = 0 ; k < lRTCLLen ; k ++ )
                    {
                        PPT_METHODTRACE_V2("", "strStartReticle[k].reticleID", strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier) ;
                        if ( k == 0 )
                        {
                            PPT_METHODTRACE_V1("", "k == 0") ;
                            strAPCUsedRequest.RETICLES[k].length(1);
                            strAPCUsedRequest.RETICLES[k][0].RETICLEID.length(1);
                            strAPCUsedRequest.RETICLES[k][0].RETICLEID[0] = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier;

                            CORBA::Long lAPCRParmLen_R1 = strAPCLithoRecipeParameterSeq_R1.length() ;
                            strAPCUsedRequest.RETICLES[k][0].PARAMS.length(lAPCRParmLen_R1);
                            PPT_METHODTRACE_V2("", "lAPCRParmLen_R1",  lAPCRParmLen_R1) ;
                            for ( CORBA::Long k1 = 0 ; k1 < lAPCRParmLen_R1 ; k1 ++ )
                            {
                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1].length(1);
                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1][0].NAME.length(1);
                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1][0].VALUE.length(1);

                                PPT_METHODTRACE_V2("", "parameterName",   strAPCLithoRecipeParameterSeq_R1[k1].parameterName) ;
                                PPT_METHODTRACE_V2("", "parameterValue",  strAPCLithoRecipeParameterSeq_R1[k1].parameterValue) ;

                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1][0].NAME[0]  = strAPCLithoRecipeParameterSeq_R1[k1].parameterName  ;
                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1][0].VALUE[0] = strAPCLithoRecipeParameterSeq_R1[k1].parameterValue ;
                            }
                        }
                        else if ( k == 1 )
                        {
                            PPT_METHODTRACE_V1("", "k == 1") ;
                            strAPCUsedRequest.RETICLES[k].length(1);
                            strAPCUsedRequest.RETICLES[k][0].RETICLEID.length(1);
                            strAPCUsedRequest.RETICLES[k][0].RETICLEID[0] = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier;

                            CORBA::Long lAPCRParmLen_R2 = strAPCLithoRecipeParameterSeq_R2.length() ;
                            strAPCUsedRequest.RETICLES[k][0].PARAMS.length(lAPCRParmLen_R2);
                            PPT_METHODTRACE_V2("", "lAPCRParmLen_R2",  lAPCRParmLen_R2) ;
                            for ( CORBA::Long k1 = 0 ; k1 < lAPCRParmLen_R2 ; k1 ++ )
                            {
                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1].length(1);
                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1][0].NAME.length(1);
                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1][0].VALUE.length(1);

                                PPT_METHODTRACE_V2("", "parameterName",   strAPCLithoRecipeParameterSeq_R2[k1].parameterName) ;
                                PPT_METHODTRACE_V2("", "parameterValue",  strAPCLithoRecipeParameterSeq_R2[k1].parameterValue) ;

                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1][0].NAME[0]  = strAPCLithoRecipeParameterSeq_R2[k1].parameterName  ;
                                strAPCUsedRequest.RETICLES[k][0].PARAMS[k1][0].VALUE[0] = strAPCLithoRecipeParameterSeq_R2[k1].parameterValue ;
                            }
                        }
                    }

                    //================================================================//
                    //   Set Used Equipment for Metrology                             //
                    //================================================================//
                    objObject_Get_out strObject_Get_out;
                    objObject_Get_in  strObject_Get_in;
                    strObject_Get_in.className                    = CIMFWStrDup(SP_ClassName_PosLot);
                    strObject_Get_in.strHashedInfoSeq.length(1);
                    strObject_Get_in.strHashedInfoSeq[0].hashKey  = CIMFWStrDup(SP_HashData_LOT_ID);
                    strObject_Get_in.strHashedInfoSeq[0].hashData = strStartCassette[i].strLotInCassette[j].lotID.identifier;

                    PPT_METHODTRACE_V1("", "call object_Get()");

                    rc = object_Get( strObject_Get_out,
                                     strObjCommonIn,
                                     strObject_Get_in );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "", "object_Get() rc != RC_OK" );
                        strObjAPCMgr_SendLithoUsedInfoReq_out.strResult = strObject_Get_out.strResult;
                        return rc;
                    }
                    PPT_METHODTRACE_V2("", "lotID stringifiedObjectReference", strObject_Get_out.stringifiedObjectReference);

                    pptUserData strUserData;
                    strUserData.name         = CIMFWStrDup ( "M_LOT_APCLithoUsedAsgnEqp" );
                    strUserData.type         = CIMFWStrDup ( CS_UDATA_TYPE_STRING );
                    strUserData.value        = strObjAPCMgr_SendLithoUsedInfoReq_in.equipmentID.identifier ;
                    strUserData.originator   = CIMFWStrDup ( SP_USERDATA_ORIG_MM );

                    PPT_METHODTRACE_V2("", "M_LOT_APCLithoUsedAsgnEqp", strObjAPCMgr_SendLithoUsedInfoReq_in.equipmentID.identifier);

                    objObject_UserData_Set_out  strObject_UserData_Set_out;
                    rc = object_userData_Set(strObject_UserData_Set_out, strObjCommonIn, strUserData, strObject_Get_out.stringifiedObjectReference);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_userData_Set() rc != RC_OK", rc)
                        strObjAPCMgr_SendLithoUsedInfoReq_out.strResult = strObject_UserData_Set_out.strResult ;
                        return( rc );
                    }

                    //================================================================//
                    //   Send used request to APC I/F                                 //
                    //================================================================//
                    // Get APC Server Name
                    PPT_METHODTRACE_V1("", "Get Server Name");
                    CORBA::String_var tmpAPCServerName = CIMFWStrDup( getenv(SP_APC_SERVER_NAME) );
                    char* APCServerName = CORBA::string_alloc( (CORBA::ULong) CIMFWStrLen(tmpAPCServerName)+1 );
                    CORBA::String_var tmpStr = APCServerName;
                    if ( NULL != APCServerName )
                    {
                        APCServerName[0] = NULL;
                    }

                    if ( strstr(tmpAPCServerName, ":") == NULL )
                    {
                        CIMFWStrCpy( APCServerName , ":" );
                        CIMFWStrCat( APCServerName , tmpAPCServerName );
                    }
                    else
                    {
                        CIMFWStrCpy( APCServerName , tmpAPCServerName );
                    }

                    // Get APC Host Name
                    PPT_METHODTRACE_V1("", "Get Host Name");
                    CORBA::String_var APCHostName;
                    APCHostName = CIMFWStrDup( getenv(SP_APC_HOST_NAME) );

                    LithoR2RWebServiceSoap_var APCSvcMgr;

                    PPT_METHODTRACE_V1("", "call APCMgr_GetServiceManager");
                    objAPCMgr_GetServiceManager_out strAPCMgr_GetServiceManager_out;
                    rc = APCMgr_GetServiceManager( strAPCMgr_GetServiceManager_out,
                                                   strObjCommonIn,
                                                   APCServerName,
                                                   APCHostName);

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "APCMgr_GetServiceManager() != RC_OK", rc);
                        strObjAPCMgr_SendLithoUsedInfoReq_out.strResult = strAPCMgr_GetServiceManager_out.strResult;
                        return( rc );
                    }

#ifdef EBROKER
                    CORBA::Object_var anObject = SP_STRING_TO_OBJECT(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#else
                    CORBA::Object_var anObject = CORBA::Orbix.string_to_object(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#endif
                    APCSvcMgr = LithoR2RWebServiceSoap::_narrow(anObject);
                    if ( CORBA::is_nil(APCSvcMgr) )
                    {
                        SET_MSG_RC(strObjAPCMgr_SendLithoUsedInfoReq_out, MSG_APC_SERVER_NIL_OBJ, RC_APC_SERVER_NIL_OBJ);
                        return( RC_APC_SERVER_NIL_OBJ );
                    }

                    CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;
                    CORBA::String_var timeOutValue;
                    timeOutValue = CIMFWStrDup( getenv(SP_TX_Timeout_APC) );
                    if ( 0 < CIMFWStrLen(timeOutValue) )
                    {
                        envTimeOut.timeout(atol(timeOutValue) * 1000);
                    }

                    // Get Environment for GenIOR
#ifdef EBROKER
                    tmpAPCServerName = CIMFWStrDup(APCServerName);
#else
                    tmpAPCServerName = CIMFWStrDup(getenv(SP_APCServerName_ForGenIOR));
#endif

                    PPT_METHODTRACE_V1("", "Send Request to APC");

                    // External System Interface Security Control
                    pptUser tmpRequestUser = strObjCommonIn.strUser;

                    CORBA::String_var configFlag = CIMFWStrDup( getenv(SP_USER_ID_PASSWORD_CONFIGRATION) );
                    PPT_METHODTRACE_V2("","SP_USER_ID_PASSWORD_CONFIGRATION ", configFlag);

                    if( 0 == CIMFWStrCmp( configFlag, "1" ) )
                    {
                        PPT_METHODTRACE_V1("","SP_USER_ID_PASSWORD_CONFIGRATION=1");

                        tmpRequestUser.userID.identifier = CIMFWStrDup( getenv(SP_APC_USER_ID) );
                        tmpRequestUser.password          = CIMFWStrDup( getenv(SP_APC_USER_PASSWORD) );
                    }

                    PPT_METHODTRACE_V2("","userID   ", tmpRequestUser.userID.identifier);
                    PPT_METHODTRACE_V2("","password ", tmpRequestUser.password);

                    Innotron_Used_Result*     apcResult = NULL;
                    Innotron_Used_Result_var  apcResultVar;
                    try
                    {
                        apcResult = APCSvcMgr->Used_Request( strAPCUsedRequest );
                        apcResultVar = apcResult;
                    }
                    catch(const CORBA::SystemException &SysEx)
                    {
                        PPT_METHODTRACE_V1("", "CORBA::SystemException caught");
                        APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                        SET_MSG_RC( strObjAPCMgr_SendLithoUsedInfoReq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                        try
                        {
                            PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);
                            externalServerList.remove((char *)tmpAPCServerName);
                        }
                        catch( ... )
                        {
                            PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                        }
                        //Nick return( RC_NO_RESPONSE_APC );
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "Unknown exception caught");
                        APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ( );
                        SET_MSG_RC( strObjAPCMgr_SendLithoUsedInfoReq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                        try
                        {
                            PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);
                            externalServerList.remove((char *)tmpAPCServerName);
                        }
                        catch( ... )
                        {
                            PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                        }
                        //Nick return( RC_NO_RESPONSE_APC );
                    }

                    // Check APC return error or not
                    PPT_METHODTRACE_V2("", "APC STATUSCODE", apcResult->APC_STATUS.STATUSCODE) ;  //APC only replies 0 or 1. 0:OK, 1:NG
                    if (apcResult->APC_STATUS.STATUSCODE != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "Used_Request() != RC_OK, Error") ;
                        strObjAPCMgr_SendLithoUsedInfoReq_out.strResult.transactionID  = strObjCommonIn.transactionID ;
                        strObjAPCMgr_SendLithoUsedInfoReq_out.strResult.returnCode     = ConvertLongtoString(RC_APC_RECIPEPARAMETERREQ_ERROR) ;
                        if ( apcResult->APC_STATUS.STATUSSTRING.length() > 0 )
                        {
                            strObjAPCMgr_SendLithoUsedInfoReq_out.strResult.messageText    = apcResult->APC_STATUS.STATUSSTRING[0] ;
                        }
                        //Nick return(RC_APC_RECIPEPARAMETERREQ_ERROR);
                    }
                }
            }
        }

        //================================================================//
        //   Return value                                                 //
        //================================================================//
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APCMgr_SendLithoUsedInfoReq");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjAPCMgr_SendLithoUsedInfoReq_out, cs_APCMgr_SendLithoUsedInfoReq, methodName)
}
