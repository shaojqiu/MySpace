//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APCMgr_SendLithoRecommendInfoInq.cpp
//

#include "cs_apcsm.hh"
#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APCMgr_SendLithoRecommendInfoInq.cpp
//
//
// Innotron Modification History:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009 Nick Tsai      Send APC recommend request and reply the recipe parameter
//
// Function Description:
//
// Input Parameters:
//    csObjAPCMgr_SendLithoRecommendInfoInq_out&       strObjAPCMgr_SendLithoRecommendInfoInq_out,
//    const pptObjCommonIn&                            strObjCommonIn,
//    const csObjAPCMgr_SendLithoRecommendInfoInq_in&  strObjAPCMgr_SendLithoRecommendInfoInq_in
//
//typedef struct csObjAPCMgr_SendLithoRecommendInfoInq_in_struct {
//    objectIdentifier            equipmentID;
//    pptStartCassetteSequence    strStartCassette;
//    string                      action;
//    any                         siInfo;
//}csObjAPCMgr_SendLithoRecommendInfoInq_in;
//
//
// Output Parameters:
//
//typedef struct csObjAPCMgr_SendLithoRecommendInfoInq_out_struct {
//    pptRetCode                      strResult;
//    pptStartCassetteSequence        strStartCassette;
//    any                             siInfo;
//}csObjAPCMgr_SendLithoRecommendInfoInq_out;
//
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//


CORBA::Long CS_PPTManager_i::cs_APCMgr_SendLithoRecommendInfoInq (
    csObjAPCMgr_SendLithoRecommendInfoInq_out&       strObjAPCMgr_SendLithoRecommendInfoInq_out,
    const pptObjCommonIn&                            strObjCommonIn,
    const csObjAPCMgr_SendLithoRecommendInfoInq_in&  strObjAPCMgr_SendLithoRecommendInfoInq_in
)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APCMgr_SendLithoRecommendInfoInq");
        //================================================================//
        //   Print input parameters                                       //
        //================================================================//
        PPT_METHODTRACE_V2("", "action ",       strObjAPCMgr_SendLithoRecommendInfoInq_in.action);
        PPT_METHODTRACE_V2("", "equipmentID ",  strObjAPCMgr_SendLithoRecommendInfoInq_in.equipmentID.identifier);

        //================================================================//
        //   Check input parameters                                       //
        //================================================================//
        if ( CIMFWStrCmp ( strObjAPCMgr_SendLithoRecommendInfoInq_in.action, CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND ) != 0 &&
             CIMFWStrCmp ( strObjAPCMgr_SendLithoRecommendInfoInq_in.action, CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND ) != 0    )
        {
            PPT_METHODTRACE_V1("","action != CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND && != CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND");
            SET_MSG_RC( strObjAPCMgr_SendLithoRecommendInfoInq_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        if ( CIMFWStrLen ( strObjAPCMgr_SendLithoRecommendInfoInq_in.equipmentID.identifier) == 0 )
        {
            PPT_METHODTRACE_V1("","CIMFWStrLen ( strObjAPCMgr_SendLithoRecommendInfoInq_in.equipmentID.identifier) == 0");
            PPT_SET_MSG_RC_KEY( strObjAPCMgr_SendLithoRecommendInfoInq_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, "*******" );
            return RC_NOT_FOUND_EQP;
        }

        if ( strObjAPCMgr_SendLithoRecommendInfoInq_in.strStartCassette.length() == 0 )
        {
            PPT_METHODTRACE_V1("","strObjAPCMgr_SendLithoRecommendInfoInq_in.strStartCassette.length() == 0");
            SET_MSG_RC( strObjAPCMgr_SendLithoRecommendInfoInq_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        //=======================================================================//
        //   1. Prepare APC (Lot & Context ) data for APC recommend request      //
        //   2. Send APC recommend request to APC I/F                            //
        //   3. Reply recommend recipe parameter to strStartCassette             //
        //=======================================================================//
        pptStartCassetteSequence strStartCassette = strObjAPCMgr_SendLithoRecommendInfoInq_in.strStartCassette;

        CORBA::Long scLen = strStartCassette.length();
        PPT_METHODTRACE_V2("", "strStartCassette.length()", scLen) ;
        for ( CORBA::Long i = 0 ; i < scLen ; i ++ )
        {
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()", nLen) ;

            for ( CORBA::Long j = 0 ; j < nLen ; j ++ )
            {
                //================================================================//
                //   Omit Not-OpeStart Lot                                        //
                //================================================================//
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }
                PPT_METHODTRACE_V2("", "lotID",             strStartCassette[i].strLotInCassette[j].lotID.identifier) ;
                PPT_METHODTRACE_V2("", "routeID",           strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier) ;
                PPT_METHODTRACE_V2("", "operationNumber",   strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber) ;

                //================================================================//
                //   Omit Recommend Flag is FALSE                                 //
                //================================================================//
                csObjAPC_LithoAvailable_CheckCondition_out strAPC_LithoAvailable_CheckCondition_out;
                csObjAPC_LithoAvailable_CheckCondition_in  strAPC_LithoAvailable_CheckCondition_in;
                strAPC_LithoAvailable_CheckCondition_in.equipmentID       = strObjAPCMgr_SendLithoRecommendInfoInq_in.equipmentID;
                strAPC_LithoAvailable_CheckCondition_in.routeID           = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                strAPC_LithoAvailable_CheckCondition_in.operationNumber   = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;

                rc = cs_APC_LithoAvailable_CheckCondition( strAPC_LithoAvailable_CheckCondition_out,
                                                           strObjCommonIn,
                                                           strAPC_LithoAvailable_CheckCondition_in ) ;
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "cs_APC_LithoAvailable_CheckCondition() != RC_OK", rc) ;
                    strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult = strAPC_LithoAvailable_CheckCondition_out.strResult ;
                    return(rc);
                }

                PPT_METHODTRACE_V2("", "recommendFlag",   strAPC_LithoAvailable_CheckCondition_out.recommendFlag) ;

                if ( strAPC_LithoAvailable_CheckCondition_out.recommendFlag == TRUE )
                {
                    //================================================================//
                    //   Declare APC structure                                        //
                    //================================================================//
                    Innotron_Recomd_Request  strAPCRecommendRequest;

                    //================================================================//
                    //   Prepare APC Lot Info                                         //
                    //================================================================//
                    csObjAPC_LithoLotDataInfo_Get_out strAPC_LithoLotDataInfo_Get_out;
                    csObjAPC_LithoLotDataInfo_Get_in  strAPC_LithoLotDataInfo_Get_in;

                    strAPC_LithoLotDataInfo_Get_in.lotID             = strStartCassette[i].strLotInCassette[j].lotID;
                    strAPC_LithoLotDataInfo_Get_in.routeID           = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                    strAPC_LithoLotDataInfo_Get_in.operationNumber   = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;

                    rc = cs_APC_LithoLotDataInfo_Get( strAPC_LithoLotDataInfo_Get_out,
                                                      strObjCommonIn,
                                                      strAPC_LithoLotDataInfo_Get_in ) ;
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "cs_APC_LithoLotDataInfo_Get() != RC_OK", rc) ;
                        strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult = strAPC_LithoLotDataInfo_Get_out.strResult ;
                        return(rc);
                    }

                    PPT_METHODTRACE_V2("", "lotID", strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.lotID.identifier) ;

                    strAPCRecommendRequest.LOT_DATA.length(1) ;
                    strAPCRecommendRequest.LOT_DATA[0].length(1) ;

                    strAPCRecommendRequest.LOT_DATA[0][0].LOTID.length(1) ;
                    strAPCRecommendRequest.LOT_DATA[0][0].LOTID[0] = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.lotID.identifier ;

                    CORBA::Long lWaferLen = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq.length();
                    strAPCRecommendRequest.LOT_DATA[0][0].WAFERS.length(lWaferLen);
                    for ( CORBA::Long k = 0 ; k > lWaferLen ; k ++ )
                    {
                        PPT_METHODTRACE_V2("", "k",             k) ;
                        PPT_METHODTRACE_V2("", "waferID",       strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].waferID.identifier) ;
                        PPT_METHODTRACE_V2("", "slotNo",        strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].slotNo) ;
                        PPT_METHODTRACE_V2("", "chuckID",       strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].chuckID) ;
                        PPT_METHODTRACE_V2("", "reworkCount",   strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].reworkCount) ;

                        strAPCRecommendRequest.LOT_DATA[0][0].WAFERS[k].length(1) ;
                        strAPCRecommendRequest.LOT_DATA[0][0].WAFERS[k][0].WAFERID.length(1) ;
                        strAPCRecommendRequest.LOT_DATA[0][0].WAFERS[k][0].WAFERID[0] = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].waferID.identifier ;
                        strAPCRecommendRequest.LOT_DATA[0][0].WAFERS[k][0].SLOTNO     = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].slotNo ;
                        strAPCRecommendRequest.LOT_DATA[0][0].WAFERS[k][0].CHUCKID    = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].chuckID ;
                        strAPCRecommendRequest.LOT_DATA[0][0].WAFERS[k][0].REWORK_CNT = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[k].reworkCount ;
                    }

                    //================================================================//
                    //   Prepare APC Context Info                                     //
                    //================================================================//
                    csObjAPC_LithoContextInfo_Get_out strObjAPC_LithoContextInfo_Get_out;
                    csObjAPC_LithoContextInfo_Get_in  strObjAPC_LithoContextInfo_Get_in ;
                    strObjAPC_LithoContextInfo_Get_in.lotID                        = strStartCassette[i].strLotInCassette[j].lotID;
                    strObjAPC_LithoContextInfo_Get_in.routeID                      = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                    strObjAPC_LithoContextInfo_Get_in.operationNumber              = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;
                    strObjAPC_LithoContextInfo_Get_in.equipmentID                  = strObjAPCMgr_SendLithoRecommendInfoInq_in.equipmentID;
                    strObjAPC_LithoContextInfo_Get_in.strStartReticleSeq           = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle;
                    if ( strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0 )
                    {
                        PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0") ;
                        strObjAPC_LithoContextInfo_Get_in.strStartRecipeParameterSeq   = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter;
                    }
                    strObjAPC_LithoContextInfo_Get_in.action                       = strObjAPCMgr_SendLithoRecommendInfoInq_in.action;

                    rc = cs_APC_LithoContextInfo_Get( strObjAPC_LithoContextInfo_Get_out,
                                                      strObjCommonIn,
                                                      strObjAPC_LithoContextInfo_Get_in ) ;
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "cs_APC_LithoContextInfo_Get() != RC_OK", rc) ;
                        strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult = strObjAPC_LithoContextInfo_Get_out.strResult ;
                        return(rc);
                    }

                    PPT_METHODTRACE_V2("", "controlJobType",        strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.controlJobType);
                    PPT_METHODTRACE_V2("", "transactionID",         strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.transactionID);
                    PPT_METHODTRACE_V2("", "lotID",                 strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotID);
                    PPT_METHODTRACE_V2("", "lotType",               strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotType);
                    PPT_METHODTRACE_V2("", "partID",                strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.partID);
                    PPT_METHODTRACE_V2("", "layer",                 strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.layer);
                    PPT_METHODTRACE_V2("", "routeID",               strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeID);
                    PPT_METHODTRACE_V2("", "routeGroup",            strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeGroup);
                    PPT_METHODTRACE_V2("", "operationNumber",       strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.operationNumber);
                    PPT_METHODTRACE_V2("", "reticleID",             strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reticleID);
                    PPT_METHODTRACE_V2("", "processEquipmentType",  strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentType);
                    PPT_METHODTRACE_V2("", "processEquipmentID",    strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentID);
                    PPT_METHODTRACE_V2("", "recommendMode",         strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.recommendMode);
                    PPT_METHODTRACE_V2("", "reworkLotFlag",         strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reworkLotFlag);
                    PPT_METHODTRACE_V2("", "parentLotID",           strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.parentLotID);
                    PPT_METHODTRACE_V2("", "preToolID",             strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.preToolID);
                    PPT_METHODTRACE_V2("", "sendAheadFlag",         strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.sendAheadFlag);
                    PPT_METHODTRACE_V2("", "availableSubUnit",      strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.availableSubUnit);
                    PPT_METHODTRACE_V2("", "opeStartRecommendFlag", strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.opeStartRecommendFlag);
                    PPT_METHODTRACE_V2("", "chuckDedication",       strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.chuckDedication);
                    PPT_METHODTRACE_V2("", "ParameterNames",        strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.ParameterNames);
                    PPT_METHODTRACE_V2("", "feedForward1",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.feedForward1);
                    PPT_METHODTRACE_V2("", "feedForward2",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.feedForward2);
                    PPT_METHODTRACE_V2("", "feedForward3",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.feedForward3);
                    PPT_METHODTRACE_V2("", "feedForward4",          strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.feedForward4);

                    strAPCRecommendRequest.APC_CONTEXT.CONTROLJOBTYPE[0]    = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.controlJobType;
                    strAPCRecommendRequest.APC_CONTEXT.TRANSACTIONID[0]     = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.transactionID;
                    strAPCRecommendRequest.APC_CONTEXT.LOTID[0]             = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotID;
                    strAPCRecommendRequest.APC_CONTEXT.LOTTYPE[0]           = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.lotType;
                    strAPCRecommendRequest.APC_CONTEXT.PARTID[0]            = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.partID;
                    strAPCRecommendRequest.APC_CONTEXT.LAYER[0]             = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.layer;
                    strAPCRecommendRequest.APC_CONTEXT.ROUTE[0]             = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeID;
                    strAPCRecommendRequest.APC_CONTEXT.ROUTEGROUP[0]        = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.routeGroup;
                    strAPCRecommendRequest.APC_CONTEXT.OPERATION[0]         = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.operationNumber;
                    strAPCRecommendRequest.APC_CONTEXT.RETICLEID[0]         = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reticleID;
                    strAPCRecommendRequest.APC_CONTEXT.PROCESSEQUIPTYPE[0]  = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentType;
                    strAPCRecommendRequest.APC_CONTEXT.PROCESSEQUIPID[0]    = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.processEquipmentID;
                    strAPCRecommendRequest.APC_CONTEXT.RECOMMENDMODE[0]     = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.recommendMode;
                    strAPCRecommendRequest.APC_CONTEXT.REWORK[0]            = ( strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.reworkLotFlag? CIMFWStrDup("TRUE"):CIMFWStrDup("FALSE") );
                    strAPCRecommendRequest.APC_CONTEXT.PARENTLOTID[0]       = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.parentLotID;
                    strAPCRecommendRequest.APC_CONTEXT.PRETOOL[0]           = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.preToolID;
                    strAPCRecommendRequest.APC_CONTEXT.SENDAHEAD[0]         = ( strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.sendAheadFlag? CIMFWStrDup("TRUE"):CIMFWStrDup("FALSE") );
                    strAPCRecommendRequest.APC_CONTEXT.AVAILABLE_SUBUNIT[0] = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.availableSubUnit;
                    strAPCRecommendRequest.APC_CONTEXT.IS_OPSTART_RECOMD[0] = ( strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.opeStartRecommendFlag? CIMFWStrDup("1"):CIMFWStrDup("0") );
                    strAPCRecommendRequest.APC_CONTEXT.CHUCK_DEDICATION[0]  = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.chuckDedication;
                    strAPCRecommendRequest.APC_CONTEXT.BR_PARAMS[0]         = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.ParameterNames;
                    strAPCRecommendRequest.APC_CONTEXT.FEEDFORWARD1[0]      = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.feedForward1;
                    strAPCRecommendRequest.APC_CONTEXT.FEEDFORWARD2[0]      = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.feedForward2;
                    strAPCRecommendRequest.APC_CONTEXT.FEEDFORWARD3[0]      = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.feedForward3;
                    strAPCRecommendRequest.APC_CONTEXT.FEEDFORWARD4[0]      = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.feedForward4;

                    CORBA::Long lExtLen = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends.length();
                    strAPCRecommendRequest.APC_CONTEXT.LD_EXTEND.length(lExtLen);
                    for ( k = 0 ; k > lExtLen ; k ++ )
                    {
                        PPT_METHODTRACE_V2("", "k",     k) ;
                        PPT_METHODTRACE_V2("", "name",  strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends[k].name) ;
                        PPT_METHODTRACE_V2("", "value", strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends[k].value) ;

                        strAPCRecommendRequest.APC_CONTEXT.LD_EXTEND[k].length(1) ;
                        strAPCRecommendRequest.APC_CONTEXT.LD_EXTEND[k][0].NAME.length(1) ;
                        strAPCRecommendRequest.APC_CONTEXT.LD_EXTEND[k][0].VALUE.length(1) ;
                        strAPCRecommendRequest.APC_CONTEXT.LD_EXTEND[k][0].NAME[0]     = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends[k].name ;
                        strAPCRecommendRequest.APC_CONTEXT.LD_EXTEND[k][0].VALUE[0]    = strObjAPC_LithoContextInfo_Get_out.strAPCLithoContextInfo.extends[k].value ;
                    }

                    //================================================================//
                    //   Send recommend request to APC I/F                            //
                    //================================================================//
                    // Get APC Server Name
                    PPT_METHODTRACE_V1("", "Get Server Name");
                    CORBA::String_var tmpAPCServerName = CIMFWStrDup( getenv(SP_APC_SERVER_NAME) );
                    char* APCServerName = CORBA::string_alloc( (CORBA::ULong) CIMFWStrLen(tmpAPCServerName)+1 );
                    CORBA::String_var tmpStr = APCServerName;
                    if ( NULL != APCServerName )
                    {
                        APCServerName[0] = NULL;
                    }

                    if ( strstr(tmpAPCServerName, ":") == NULL )
                    {
                        CIMFWStrCpy( APCServerName , ":" );
                        CIMFWStrCat( APCServerName , tmpAPCServerName );
                    }
                    else
                    {
                        CIMFWStrCpy( APCServerName , tmpAPCServerName );
                    }

                    // Get APC Host Name
                    PPT_METHODTRACE_V1("", "Get Host Name");
                    CORBA::String_var APCHostName;
                    APCHostName = CIMFWStrDup( getenv(SP_APC_HOST_NAME) );

                    LithoR2RWebServiceSoap_var APCSvcMgr;

                    PPT_METHODTRACE_V1("", "call APCMgr_GetServiceManager");
                    objAPCMgr_GetServiceManager_out strAPCMgr_GetServiceManager_out;
                    rc = APCMgr_GetServiceManager( strAPCMgr_GetServiceManager_out,
                                                   strObjCommonIn,
                                                   APCServerName,
                                                   APCHostName);

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "APCMgr_GetServiceManager() != RC_OK", rc);
                        strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult = strAPCMgr_GetServiceManager_out.strResult;
                        return( rc );
                    }

#ifdef EBROKER
                    CORBA::Object_var anObject = SP_STRING_TO_OBJECT(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#else
                    CORBA::Object_var anObject = CORBA::Orbix.string_to_object(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#endif
                    APCSvcMgr = LithoR2RWebServiceSoap::_narrow(anObject);
                    if ( CORBA::is_nil(APCSvcMgr) )
                    {
                        SET_MSG_RC(strObjAPCMgr_SendLithoRecommendInfoInq_out, MSG_APC_SERVER_NIL_OBJ, RC_APC_SERVER_NIL_OBJ);
                        return( RC_APC_SERVER_NIL_OBJ );
                    }

                    CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;
                    CORBA::String_var timeOutValue;
                    timeOutValue = CIMFWStrDup( getenv(SP_TX_Timeout_APC) );
                    if ( 0 < CIMFWStrLen(timeOutValue) )
                    {
                        envTimeOut.timeout(atol(timeOutValue) * 1000);
                    }

                    // Get Environment for GenIOR
#ifdef EBROKER
                    tmpAPCServerName = CIMFWStrDup(APCServerName);
#else
                    tmpAPCServerName = CIMFWStrDup(getenv(SP_APCServerName_ForGenIOR));
#endif

                    PPT_METHODTRACE_V1("", "Send Request to APC");

                    // External System Interface Security Control
                    pptUser tmpRequestUser = strObjCommonIn.strUser;

                    CORBA::String_var configFlag = CIMFWStrDup( getenv(SP_USER_ID_PASSWORD_CONFIGRATION) );
                    PPT_METHODTRACE_V2("","SP_USER_ID_PASSWORD_CONFIGRATION ", configFlag);

                    if( 0 == CIMFWStrCmp( configFlag, "1" ) )
                    {
                        PPT_METHODTRACE_V1("","SP_USER_ID_PASSWORD_CONFIGRATION=1");

                        tmpRequestUser.userID.identifier = CIMFWStrDup( getenv(SP_APC_USER_ID) );
                        tmpRequestUser.password          = CIMFWStrDup( getenv(SP_APC_USER_PASSWORD) );
                    }

                    PPT_METHODTRACE_V2("","userID   ", tmpRequestUser.userID.identifier);
                    PPT_METHODTRACE_V2("","password ", tmpRequestUser.password);

                    Innotron_Recomd_Result*     apcResult = NULL;
                    Innotron_Recomd_Result_var  apcResultVar;
                    try
                    {
                        apcResult = APCSvcMgr->Recommend_Request( strAPCRecommendRequest );
                        apcResultVar = apcResult;
                    }
                    catch(const CORBA::SystemException &SysEx)
                    {
                        PPT_METHODTRACE_V1("", "CORBA::SystemException caught");
                        APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                        SET_MSG_RC( strObjAPCMgr_SendLithoRecommendInfoInq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                        try
                        {
                            PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);
                            externalServerList.remove((char *)tmpAPCServerName);
                        }
                        catch( ... )
                        {
                            PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                        }
                        return( RC_NO_RESPONSE_APC );
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "Unknown exception caught");
                        APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ( );
                        SET_MSG_RC( strObjAPCMgr_SendLithoRecommendInfoInq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                        try
                        {
                            PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);
                            externalServerList.remove((char *)tmpAPCServerName);
                        }
                        catch( ... )
                        {
                            PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                        }
                        return( RC_NO_RESPONSE_APC );
                    }

                    // Check APC return error or not
                    PPT_METHODTRACE_V2("", "APC STATUSCODE", apcResult->APC_STATUS.STATUSCODE) ;  //APC only replies 0 or 1. 0:OK, 1:NG
                    if (apcResult->APC_STATUS.STATUSCODE != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "Recommend_Request() != RC_OK, Error") ;
                        strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult.transactionID  = strObjCommonIn.transactionID ;
                        strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult.returnCode     = ConvertLongtoString(RC_APC_RECIPEPARAMETERREQ_ERROR) ;
                        if ( apcResult->APC_STATUS.STATUSSTRING.length() > 0 )
                        {
                            strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult.messageText    = apcResult->APC_STATUS.STATUSSTRING[0] ;
                        }
                        return(RC_APC_RECIPEPARAMETERREQ_ERROR);
                    }

                    // Check need pilot or not
                    PPT_METHODTRACE_V2("", "APC SAHD_REQUEST", apcResult->APC_STATUS.SAHD_REQUEST) ;  //APC only replies 0 or 1. 0:OK, 1:need pilot
                    if (apcResult->APC_STATUS.SAHD_REQUEST != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "Recommend_Request() != RC_OK, Need Pilot") ;
                        strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult.transactionID  = strObjCommonIn.transactionID ;
                        strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult.returnCode     = ConvertLongtoString(CS_RC_APC_NEED_PILOT) ;
                        if ( apcResult->APC_STATUS.SAHD_REASON.length() > 0 )
                        {
                            strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult.messageText    = apcResult->APC_STATUS.SAHD_REASON[0] ;
                        }
                        return(CS_RC_APC_NEED_PILOT);
                    }

                    //================================================================//
                    //   Revise reticle1 and reticle2 in startCassette                //
                    //================================================================//
                    objectIdentifier reticleID1 ;
                    objectIdentifier reticleID2 ;
                    CORBA::Long lRTCLLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
                    PPT_METHODTRACE_V2("", "lRTCLLen", lRTCLLen) ;

                    CORBA::Long bRevisedReticle_0_SeqNo = FALSE ;
                    CORBA::Long bRevisedReticle_1_SeqNo = FALSE ;
                    for ( k = 0 ; k < lRTCLLen ; k ++ )
                    {
                        PPT_METHODTRACE_V2("", "strStartReticle[k].reticleID", strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier) ;
                        if ( k == 0 && apcResult->RETICLES.length() > 0 )
                        {
                            PPT_METHODTRACE_V2("", "apcResult->RETICLES", apcResult->RETICLES[k][0].RETICLEID[0]) ;
                            if ( CIMFWStrCmp ( strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier,
                                               apcResult->RETICLES[k][0].RETICLEID[0] ) != 0 )
                            {
                                PPT_METHODTRACE_V1("", "bRevisedReticle_0_SeqNo = TRUE") ;
                                bRevisedReticle_0_SeqNo = TRUE ;
                            }
                        }
                        else if ( k == 1 && apcResult->RETICLES.length() > 1 )
                        {
                            PPT_METHODTRACE_V2("", "apcResult->RETICLES", apcResult->RETICLES[k][0].RETICLEID[0]) ;
                            if ( CIMFWStrCmp ( strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier,
                                               apcResult->RETICLES[k][0].RETICLEID[0] ) != 0 )
                            {
                                PPT_METHODTRACE_V1("", "bRevisedReticle_1_SeqNo = TRUE") ;
                                bRevisedReticle_1_SeqNo = TRUE ;
                            }
                        }
                    }

                    if ( bRevisedReticle_0_SeqNo == TRUE )
                    {
                        PPT_METHODTRACE_V2("", "strStartReticle[0].reticleID", strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[0].reticleID.identifier) ;
                        PPT_METHODTRACE_V2("", "apcResult->RETICLES[0]", apcResult->RETICLES[0][0].RETICLEID[0] ) ;

                        objectIdentifier reticleID ;
                        reticleID.identifier = apcResult->RETICLES[0][0].RETICLEID[0] ;
                        strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[0].reticleID = reticleID ;
                    }

                    if ( bRevisedReticle_1_SeqNo == TRUE )
                    {
                        PPT_METHODTRACE_V2("", "strStartReticle[1].reticleID", strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[1].reticleID.identifier) ;
                        PPT_METHODTRACE_V2("", "apcResult->RETICLES[1]", apcResult->RETICLES[1][0].RETICLEID[0] ) ;

                        objectIdentifier reticleID ;
                        reticleID.identifier = apcResult->RETICLES[1][0].RETICLEID[0] ;
                        strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[1].reticleID = reticleID ;
                    }

                    //================================================================//
                    //   Prepare input data for recipe parameter replacement          //
                    //================================================================//
                    csAPCLithoRecommendReticleSequence strAPCLithoRecommendReticleSeq ;
                    CORBA::Long lCounter = 0;
                    for ( CORBA::Long x = 0 ; x < apcResult->RETICLES.length() ; x ++ )
                    {
                        PPT_METHODTRACE_V2("", "x", x )
                        for ( CORBA::Long y = 0 ; y < apcResult->RETICLES[x].length() ; y ++ )
                        {
                            PPT_METHODTRACE_V2("", "y", y )
                            if ( apcResult->RETICLES[x][y].RETICLEID.length() > 0 )
                            {
                                PPT_METHODTRACE_V2("", "apc reticleID", apcResult->RETICLES[x][y].RETICLEID[0] )
                                strAPCLithoRecommendReticleSeq.length(lCounter + 1);
                                strAPCLithoRecommendReticleSeq[lCounter].reticleID.identifier = apcResult->RETICLES[x][y].RETICLEID[0];

                                CORBA::Long lAPCRParmLen = apcResult->RETICLES[x][y].PARAMS.length();
                                strAPCLithoRecommendReticleSeq[lCounter].strAPCLithoRecipeParameterSeq.length(lAPCRParmLen);
                                PPT_METHODTRACE_V2("", "lAPCRParmLen", lAPCRParmLen );

                                for ( CORBA::Long z = 0 ; z < lAPCRParmLen ; z ++ )
                                {
                                    CORBA::Long lAPCRParmLen1 = apcResult->RETICLES[x][y].PARAMS[z].length();
                                    PPT_METHODTRACE_V3("", "z, lAPCRParmLen1", z, lAPCRParmLen1 );

                                    for ( CORBA::Long z1 = 0 ; z1 < lAPCRParmLen1 ; z1 ++ )
                                    {
                                        PPT_METHODTRACE_V2("", "z1",                         z1 )
                                        PPT_METHODTRACE_V2("", "apc recipe parameter name",  apcResult->RETICLES[x][y].PARAMS[z][z1].NAME[0] )
                                        PPT_METHODTRACE_V2("", "apc recipe parameter value", apcResult->RETICLES[x][y].PARAMS[z][z1].VALUE[0] )

                                        strAPCLithoRecommendReticleSeq[lCounter].strAPCLithoRecipeParameterSeq[z].parameterName =
                                                                                        apcResult->RETICLES[x][y].PARAMS[z][z1].NAME[0];

                                        strAPCLithoRecommendReticleSeq[lCounter].strAPCLithoRecipeParameterSeq[z].parameterValue =
                                                                                        apcResult->RETICLES[x][y].PARAMS[z][z1].VALUE[0];
                                    }
                                }
                            }
                        }
                    }

                    // In Litho tool, use recipe parameter of the first wafer to express the recipe paramter of the all wafers.
                    if ( strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0 )
                    {
                        //================================================================//
                        //   Replace recipe parameter by requirement rule                 //
                        //================================================================//
                        csObjAPC_LithoRecipeParameter_Replace_out strObjAPC_LithoRecipeParameter_Replace_out;
                        csObjAPC_LithoRecipeParameter_Replace_in  strObjAPC_LithoRecipeParameter_Replace_in ;
                        strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq        = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter;
                        strObjAPC_LithoRecipeParameter_Replace_in.strAPCLithoRecommendReticleSeq    = strAPCLithoRecommendReticleSeq ;

                        rc = cs_APC_LithoRecipeParameter_Replace( strObjAPC_LithoRecipeParameter_Replace_out,
                                                                  strObjCommonIn,
                                                                  strObjAPC_LithoRecipeParameter_Replace_in ) ;
                        if (rc != RC_OK)
                        {
                            PPT_METHODTRACE_V2("", "cs_APC_LithoRecipeParameter_Replace() != RC_OK", rc) ;
                            strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult = strObjAPC_LithoRecipeParameter_Replace_out.strResult ;
                            return(rc);
                        }

                        for ( k = 0 ; k < strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq.length() ; k ++ )
                        {
                            PPT_METHODTRACE_V2("", "k",                          k) ;
                            PPT_METHODTRACE_V2("", "parameterName",              strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[k].parameterName) ;
                            PPT_METHODTRACE_V2("", "parameterValue",             strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[k].parameterValue) ;
                            PPT_METHODTRACE_V2("", "targetValue",                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[k].targetValue) ;
                            PPT_METHODTRACE_V2("", "useCurrentSettingValueFlag", strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[k].useCurrentSettingValueFlag) ;
                        }
                        strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter = strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq;
                    }
                }
            }
        }

        //================================================================//
        //   Return value                                                 //
        //================================================================//
        strObjAPCMgr_SendLithoRecommendInfoInq_out.strStartCassette = strStartCassette;

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APCMgr_SendLithoRecommendInfoInq");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjAPCMgr_SendLithoRecommendInfoInq_out, cs_APCMgr_SendLithoRecommendInfoInq, methodName)
}
