#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/factory/cs_pptmgrof.cpp, mm_srv_90e_cspp, mm_srv_90e_cspp 7/13/07 19:55:57 [ 7/13/07 19:55:58 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Modeficaiton History:
// Date       Defect   Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya       Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami       eBrokerMigration.
// 2005/06/13 D6000354 K.Murakami       follow up for eBroker.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2013/02/22 DSN000071118 M.Ogawa        Set thePPTManager into PPTManagerObjectFactory in createPPTManager()
//

#include "cs_pptmgrof.hpp"
#include "cs_pptmgr.hpp"

#include <iostream.h>

//D6000025PPTManager_ptr CS_PPTManagerObjectFactory_i:: createPPTManager (CORBA::Environment &IT_env) 
PPTManager_ptr CS_PPTManagerObjectFactory_i:: createPPTManager (CORBAENV_ONLY_CPP)  //D6000025 
{
    PPT_METHODTRACE_ENTRY("PPTManagerObjectFactory_i::createPPTManager")
    PPTManager_ptr   retVal = PPTManager::_nil();
    CS_PPTManager_ptr csMgr;
	try
    {
        PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "1")
        if(!CORBA::is_nil(thePPTManager))
        {
            PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "!CORBA::is_nil(thePPTManager)")
		    csMgr = CS_PPTManager::_narrow(thePPTManager);
            retVal = csMgr; 
			return retVal;
        }
        PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "2")

//D6000354        MOFW_ManagedObjectBase_ptr newMOB_ptr = MOFW_ManagedObjectBase_nil();
        MOFW_ManagedObjectBase_ptr newMOB_ptr = MOFW_ManagedObjectBase::_nil();        //D6000354
//D6000354        MOFW_ManagedObjectBase_ptr existMOB_ptr = MOFW_ManagedObjectBase_nil();
        MOFW_ManagedObjectBase_ptr existMOB_ptr = MOFW_ManagedObjectBase::_nil();      //D6000354
        CORBA::Boolean existsFlag = FALSE;
        PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "creating object")
      
        try
        {
          PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "3")

          newMOB_ptr = getMyIMFactory()->objectMalloc("CS_PPTManager");
          if(CORBA::is_nil(newMOB_ptr))
          {
                PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "CORBA::is_nil(newMOB_ptr)")
                cout << " Object Malloc returned NULL - Throw FrameworkErrorSignal" << endl;
                throw 1 ;
          }
          else
          {
                PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "Else CORBA::is_nil(newMOB_ptr)")
                try
                {
                    csMgr = CS_PPTManager::_narrow(newMOB_ptr);
                    retVal = csMgr;
		    CORBA::release(newMOB_ptr);
                    existMOB_ptr = getMyIMFactory()->initializationCompleted(newMOB_ptr,existsFlag);
                    if (!existsFlag)
                    {
                        PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "!existsFlag")
                        csMgr->CS_PPTManager_init();
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "Else !existsFlag")
                    }
                    thePPTManager = PPTManager::_duplicate(retVal);     //DSN000071118
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "error in outer try block in Else")
                    throw ;
                }
           }
        }
        catch(...)
        {
            PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "error in outer try block")
            throw;
        }
    }
    catch(...)
	{
        PPT_METHODTRACE_V1("CS_PPTManagerObjectFactory_i::createPPTManager", "Error in Global try Catch")
	}
    PPT_METHODTRACE_EXIT("CS_PPTManagerObjectFactory_i::createPPTManager")
    return retVal;
}


CS_PPTManagerObjectFactory_i::CS_PPTManagerObjectFactory_i()
{
}


CS_PPTManagerObjectFactory_i::~CS_PPTManagerObjectFactory_i()
{
}
