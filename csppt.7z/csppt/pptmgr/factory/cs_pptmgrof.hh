//----------------------------------------------------------------------------
//
//  Generated from cs_pptmgrof.idl
//  On Tuesday, November 14, 2017 11:54:15 AM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_pptmgrof_server_defined
#ifndef _cs_pptmgrof_hh_included
#define _cs_pptmgrof_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif
#ifndef _DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT
#define _DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT 
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_PPTObjectFactory_idl 
#define CS_PPTObjectFactory_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _pptmgrof_hh_included
#include <pptmgrof.hh>
#endif
#else
#ifndef _pptmgrof_hh_included
#include "pptmgrof.hh"
#endif
#endif

// Begin mapping for interface ::CS_PPTManagerObjectFactory

#ifndef _DCL_CS_PPTManagerObjectFactory
#define _DCL_CS_PPTManagerObjectFactory
#ifndef _DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT
#define _DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT 
#endif
class _DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT
   CS_PPTManagerObjectFactory
    ;
class _DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTManagerObjectFactory_var;
typedef CS_PPTManagerObjectFactory* CS_PPTManagerObjectFactory_ptr;
typedef CS_PPTManagerObjectFactory* CS_PPTManagerObjectFactoryRef;

_DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT CORBA::Object_ptr SOMLINK CS_PPTManagerObjectFactory_getBase(void *);

_DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTManagerObjectFactory_ptr SOMLINK CS_PPTManagerObjectFactory_aux_duplicate(CS_PPTManagerObjectFactory_ptr);
_DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTManagerObjectFactory_ptr SOMLINK CS_PPTManagerObjectFactory_aux_narrow(::CORBA::Object_ptr);
_DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTManagerObjectFactory_ptr SOMLINK CS_PPTManagerObjectFactory_aux_nil();
_DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT const char* SOMLINK CS_PPTManagerObjectFactory_aux_CN();

    class _DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTManagerObjectFactory_StructElem
    {
        public:

        CS_PPTManagerObjectFactory_StructElem ();

        CS_PPTManagerObjectFactory_StructElem (const CS_PPTManagerObjectFactory_StructElem &s);

        CS_PPTManagerObjectFactory_StructElem &operator= (CS_PPTManagerObjectFactory_ptr p);

        CS_PPTManagerObjectFactory_StructElem &operator= (CS_PPTManagerObjectFactory_var v);

        CS_PPTManagerObjectFactory_StructElem &operator= (const CS_PPTManagerObjectFactory_StructElem &s);

        ~CS_PPTManagerObjectFactory_StructElem ();

        operator ::CORBA::Object_ptr() const;

        operator CS_PPTManagerObjectFactory_ptr () const;

        CS_PPTManagerObjectFactory_ptr _ptr;

    }; // CS_PPTManagerObjectFactory_StructElem

    class _DCL_CS_PPTManagerObjectFactory_SOM_IMPORTEXPORT CS_PPTManagerObjectFactory_SeqElem
    {
       public:

       CS_PPTManagerObjectFactory_SeqElem (CS_PPTManagerObjectFactory_ptr* p, unsigned char rel);

       CS_PPTManagerObjectFactory_SeqElem &operator= (CS_PPTManagerObjectFactory_ptr p);

        CS_PPTManagerObjectFactory_SeqElem &operator= (CS_PPTManagerObjectFactory_var v);

       CS_PPTManagerObjectFactory_SeqElem &operator= (const CS_PPTManagerObjectFactory_SeqElem &s);

       operator CS_PPTManagerObjectFactory_ptr () const;

       CS_PPTManagerObjectFactory_ptr operator->() const;

       protected:
       CS_PPTManagerObjectFactory_ptr *_ptr;
       unsigned char _release;
   }; // CS_PPTManagerObjectFactory_SeqElem


class  CS_PPTManagerObjectFactory_var : public ::CORBA::__vb__
{
    public:

    CS_PPTManagerObjectFactory_var ();
    CS_PPTManagerObjectFactory_var (CS_PPTManagerObjectFactory *p);
    CS_PPTManagerObjectFactory_var (const CS_PPTManagerObjectFactory_var &s);
    CS_PPTManagerObjectFactory_var (const CS_PPTManagerObjectFactory_StructElem &s);
    CS_PPTManagerObjectFactory_var (const CS_PPTManagerObjectFactory_SeqElem &s);
    CS_PPTManagerObjectFactory_var &operator= (CS_PPTManagerObjectFactory *p);
    CS_PPTManagerObjectFactory_var &operator= (const CS_PPTManagerObjectFactory_var &s);
    CS_PPTManagerObjectFactory_var &operator= (const CS_PPTManagerObjectFactory_StructElem &s);
    CS_PPTManagerObjectFactory_var &operator= (const CS_PPTManagerObjectFactory_SeqElem &s);
    ~CS_PPTManagerObjectFactory_var ();
    CS_PPTManagerObjectFactory_ptr in() const;
    CS_PPTManagerObjectFactory_ptr& inout();
    CS_PPTManagerObjectFactory_ptr& out();
    CS_PPTManagerObjectFactory_ptr _retn();
    CS_PPTManagerObjectFactory_ptr operator-> ();
    operator CS_PPTManagerObjectFactory_ptr& ();
    operator const CS_PPTManagerObjectFactory_ptr& () const;
#ifdef __sun
    operator CS_PPTManagerObjectFactory_ptr () { return _ptr; };
#endif

    protected:
       CS_PPTManagerObjectFactory *_ptr;

    private:
       ::CORBA::__vb__& operator= (::CORBA::__vb__&);

};  // CS_PPTManagerObjectFactory_var

#endif /* _DCL_CS_PPTManagerObjectFactory */ 


class 

   CS_PPTManagerObjectFactory
: virtual public ::PPTManagerObjectFactory {

public: 
    static const char* CS_PPTManagerObjectFactory_CN;
    static const char* CS_PPTManagerObjectFactory_RID;
    typedef CS_PPTManagerObjectFactory_ptr _ptr_type;
    typedef CS_PPTManagerObjectFactory_var _var_type;

    /* for Orbix compatibility */
    virtual void *_deref();

protected: 
    /* constructor */

   CS_PPTManagerObjectFactory
();
protected: 
    virtual ~

   CS_PPTManagerObjectFactory
();
private: 

   CS_PPTManagerObjectFactory
    (const 
   CS_PPTManagerObjectFactory
     &); // unimplemented

    void operator=(const 
   CS_PPTManagerObjectFactory
     &); // unimplemented
public: 

    static CS_PPTManagerObjectFactory_ptr SOMLINK _duplicate(CS_PPTManagerObjectFactory_ptr obj);

    static CS_PPTManagerObjectFactory_ptr SOMLINK _narrow (::CORBA::Object_ptr);

    virtual void* _has_ancestor(const char* classname);
    static CS_PPTManagerObjectFactory_ptr SOMLINK _nil ();

    CS_PPTManagerObjectFactory_ptr _self();
    CS_PPTManagerObjectFactory_ptr _this();
    virtual void *_SOMThis(const char *& ifname);



}; // end nesting scope for interface class ::CS_PPTManagerObjectFactory

#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif

class  CS_PPTManagerObjectFactory_ORBProxy : virtual public 

   CS_PPTManagerObjectFactory
, virtual public ::PPTManagerObjectFactory_ORBProxy {

public: 
    CS_PPTManagerObjectFactory_ORBProxy ();

}; /* end of ::CS_PPTManagerObjectFactory_ORBProxy*/
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
class  CS_PPTManagerObjectFactoryProxyFactory : virtual public ::PPTManagerObjectFactoryProxyFactory {

public:
   CS_PPTManagerObjectFactoryProxyFactory (::CORBA::Boolean is_default = 0);

   virtual ::CORBA::Object_ptr create_proxy (const char* classname);
   virtual ::CORBA::Object_ptr asObject(void *obj);
}; // CS_PPTManagerObjectFactoryProxyFactory


class  CS_PPTManagerObjectFactory_Dispatcher : virtual public ::PPTManagerObjectFactory_Dispatcher {

  public:

   CS_PPTManagerObjectFactory_Dispatcher (::CORBA::Object_ptr target);

   CS_PPTManagerObjectFactory_Dispatcher (); 

   virtual ::CORBA::Boolean dispatch (::CORBA::Request &request);
#ifdef _MSC_VER
   ::CORBA::Boolean __CS_PPTManagerObjectFactory__dispatch(::CORBA::Request &_req);
#endif // _MSC_VER
}; // CS_PPTManagerObjectFactory_Dispatcher
#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
class  CS_PPTManagerObjectFactoryBOAImpl : virtual public 

   CS_PPTManagerObjectFactory
, virtual public ::CORBA::Object_ORBProxy { 
   public:
     CS_PPTManagerObjectFactoryBOAImpl() ;

     virtual ~CS_PPTManagerObjectFactoryBOAImpl();
     CS_PPTManagerObjectFactoryBOAImpl &operator= (const CS_PPTManagerObjectFactoryBOAImpl &s);
     CS_PPTManagerObjectFactoryBOAImpl (const CS_PPTManagerObjectFactoryBOAImpl &s);
};  // CS_PPTManagerObjectFactoryBOAImpl

    extern  ::CORBA::TypeCode_ptr _tc_CS_PPTManagerObjectFactory;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_pptmgrof_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_pptmgrof_ANYOPERATOR__
#undef __NOTUSE_cs_pptmgrof_ANYOPERATOR__
#endif //__USE_cs_pptmgrof_ANYOPERATOR__
#ifndef __NOTUSE_cs_pptmgrof_ANYOPERATOR__
#define _DCL_ANYOPS_CS_PPTManagerObjectFactory
#endif //__NOTUSE_cs_pptmgrof_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_CS_PPTManagerObjectFactory
#ifndef __NOTUSE_ANYOPERATOR_INTERFACE__
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_PPTManagerObjectFactory_ptr _data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_PPTManagerObjectFactory_ptr *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_PPTManagerObjectFactory_ptr& _data);
#endif
#endif //__NOTUSE_ANYOPERATOR_INTERFACE__
#endif // _DCL_ANYOPS_CS_PPTManagerObjectFactory

#endif /* _cs_pptmgrof_hh_included */

#endif /* _cs_pptmgrof_server_defined */
