#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txEqpRelatedRecipeIDAuditFlagListInq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:18:42 [ 7/13/07 21:18:43 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_txEqpRelatedRecipeIDAuditFlagListInq.cpp
//

//INN-A170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-A170001

// Class: PPTManager
//
// Service: cs_txEqpRelatedRecipeIDAuditFlagListInq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/01/07 D4100057 Cinthia Jao    Initial Release (R41)
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
//
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//      Machine/Physical Recipe Directory Information Inquiry, with a customized option to get audit flag.
//
// Return:
//      long
//
// Parameter:
//
//      csEqpRelatedRecipeIDAuditFlagListInqResult&  strEqpRelatedRecipeIDAuditFlagListInqResult
//      const pptObjCommonIn&           strObjCommonIn
//      const objectIdentifier&         equipmentID
//      CORBA::Environment              &IT_env
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_txEqpRelatedRecipeIDAuditFlagListInq( csEqpRelatedRecipeIDAuditFlagListInqResult&  strEqpRelatedRecipeIDAuditFlagListInqResult,
        const pptObjCommonIn&           strObjCommonIn,
//D6000025         const objectIdentifier&         equipmentID,
//D6000025         CORBA::Environment              &IT_env )
        const objectIdentifier&         equipmentID, //D6000025
        CORBA::Boolean getAuditFlag
        CORBAENV_LAST_CPP )                         //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txEqpRelatedRecipeIDAuditFlagListInq");
    
    /*--------------------*/
    /*   Initialization   */
    /*--------------------*/
    CORBA::Long rc = RC_OK;
    SET_MSG_RC( strEqpRelatedRecipeIDAuditFlagListInqResult, MSG_OK, RC_OK );
    
    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    
    /*------------------------------------------*/
    /*   Get Equipment_multiRecipeCapability    */
    /*------------------------------------------*/
    objEquipment_multiRecipeCapability_Get_out strEquipment_multiRecipeCapability_Get_out ;
    rc = equipment_multiRecipeCapability_Get(strEquipment_multiRecipeCapability_Get_out, strObjCommonIn, equipmentID) ;
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i::cs_txEqpRelatedRecipeIDAuditFlagListInq", "equipment_multiRecipeCapability_Get() != RC_OK") ;
        strEqpRelatedRecipeIDAuditFlagListInqResult.strResult = strEquipment_multiRecipeCapability_Get_out.strResult ;
        return rc ;
    }
    
    PPT_METHODTRACE_V2("CS_PPTManager_i::cs_txEqpRelatedRecipeIDAuditFlagListInq", "equipment_multiRecipeCapability --> ", strEquipment_multiRecipeCapability_Get_out.multiRecipeCapability) ;
    strEqpRelatedRecipeIDAuditFlagListInqResult.multiRecipeCapability = strEquipment_multiRecipeCapability_Get_out.multiRecipeCapability;
    
    /*----------------------------*/
    /*   Get Recipe Information   */
    /*----------------------------*/
    PPT_METHODTRACE_V1("CS_PPTManager_i::cs_txEqpRelatedRecipeIDAuditFlagListInq", "Get Machine/Physical Recipe Information...");
    
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out strEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out;
    rc = cs_equipment_machine_and_physicalRecipeID_auditFlag_GetDR( strEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out,
                                           strObjCommonIn,
                                           equipmentID,
                                           getAuditFlag );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i::cs_txEqpRelatedRecipeIDAuditFlagListInq", "equipment_M_and_P_RecipeID_GetDR() != RC_OK");
        strEqpRelatedRecipeIDAuditFlagListInqResult.strResult = strEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out.strResult;
        return( rc );
    }
    strEqpRelatedRecipeIDAuditFlagListInqResult.strMandPRecipeInfo = strEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out.strMandPRecipeInfo;
    
    /*--------------------*/
    /*   Return to Main   */
    /*--------------------*/
    
    SET_MSG_RC(strEqpRelatedRecipeIDAuditFlagListInqResult, MSG_OK, RC_OK);
    
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpRelatedRecipeIDAuditFlagListInq");
    return( RC_OK );
    
}
