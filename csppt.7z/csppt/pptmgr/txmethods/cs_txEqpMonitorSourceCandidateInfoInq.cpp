//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorSourceCandidateInfoInq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txEqpMonitorSourceCandidateInfoInq()
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/18 INN-R170016  JJ.Zhang       Equipment Monitor customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csEqpMonitorSourceCandidateInfoInqResult& strEqpMonitorSourceCandidateInfoInqResult
//     const pptObjCommonIn& strObjCommonIn
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txEqpMonitorSourceCandidateInfoInq (csEqpMonitorSourceCandidateInfoInqResult& strEqpMonitorSourceCandidateInfoInqResult,
                                                           const pptObjCommonIn& strObjCommonIn,
                                                           const csEqpMonitorSourceCandidateInfoInqInParm& strEqpMonitorSourceCandidateInfoInqInParm
                                                           CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txEqpMonitorSourceCandidateInfoInq")
    CORBA::Long rc = RC_OK ;
    CORBA::Long i=0, j=0;
    CORBA::Long nBWSLen = 0;
    CORBA::Long nProdCount = 0;

    stringSequence BWSIDSeq;
    stringSequence strOrgBWSIDSeq;
    BWSIDSeq.length(0);
    strOrgBWSIDSeq.length(0);

    strEqpMonitorSourceCandidateInfoInqResult.totalAvailableQty = 0;
    strEqpMonitorSourceCandidateInfoInqResult.strBWSInfoForSTBSeq.length(0);
    strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq.length(0);

    //-------------------------------------------------------------
    // Get monitor product setting and source product per NPW type
    //-------------------------------------------------------------
    if( 0 == CIMFWStrCmp(strEqpMonitorSourceCandidateInfoInqInParm.npwType, CS_EqpMonitor_NPW_Type_Monitor))
    {
        PPT_METHODTRACE_V2("", "npwType=Monitor,eqpMonitorID", strEqpMonitorSourceCandidateInfoInqInParm.eqpMonitorID.identifier);
        //----------------------------------------------------------------
        //  Get EqpMonitor information from DB
        //----------------------------------------------------------------
        objEqpMonitor_list_GetDR_in  strEqpMonitor_list_GetDR_in;
        strEqpMonitor_list_GetDR_in.eqpMonitorID = strEqpMonitorSourceCandidateInfoInqInParm.eqpMonitorID;

        csObjEqpMonitor_list_GetDR_out strEqpMonitor_list_GetDR_out;
        rc = cs_eqpMonitor_list_GetDR( strEqpMonitor_list_GetDR_out,
                                    strObjCommonIn,
                                    strEqpMonitor_list_GetDR_in );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_eqpMonitor_list_GetDR() != RC_OK", rc);
            strEqpMonitorSourceCandidateInfoInqResult.strResult = strEqpMonitor_list_GetDR_out.strResult;
            return rc;
        }
        CORBA::Long nSeqLen = strEqpMonitor_list_GetDR_out.strEqpMonitorDetailInfoSeq.length();
        PPT_METHODTRACE_V2("", "strEqpMonitorDetailInfoSeq.length", nSeqLen);

        if( 0 == nSeqLen)
        {
            PPT_METHODTRACE_V1("", "Input parameter eqpMonitorID is invalid");
            PPT_SET_MSG_RC_KEY( strEqpMonitorSourceCandidateInfoInqResult,
                                MSG_NOT_FOUND_EQPMONITOR,
                                RC_NOT_FOUND_EQPMONITOR,
                                strEqpMonitorSourceCandidateInfoInqInParm.eqpMonitorID.identifier );
            return RC_NOT_FOUND_EQPMONITOR;
        }
        pptEqpMonitorProductInfoSequence& strEqpMonitorProductInfoSeq = strEqpMonitor_list_GetDR_out.strEqpMonitorDetailInfoSeq[0].strEqpMonitorProductInfoSeq;
        CORBA::Long nProdLen = strEqpMonitorProductInfoSeq.length();
        strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq.length(nProdLen);
        strOrgBWSIDSeq.length(nProdLen);
        PPT_METHODTRACE_V2("", "strEqpMonitorProductInfoSeq.length", nProdLen);

        //---------------------------------------------
        // Get monitor product setting info for every
        // product used in this EQP Monitor Definiton
        //---------------------------------------------
        for( i=0; i<nProdLen; i++)
        {
            PPT_METHODTRACE_V2("", "productID", strEqpMonitorProductInfoSeq[i].productID.identifier);

            csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
            strEqpMonitorInventory_ListGetDR_in.npwType = strEqpMonitorSourceCandidateInfoInqInParm.npwType;
            strEqpMonitorInventory_ListGetDR_in.productID = strEqpMonitorProductInfoSeq[i].productID.identifier;

            csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
            rc = cs_eqpMonitorInventory_ListGetDR(strEqpMonitorInventory_ListGetDR_out,
                                         strObjCommonIn,
                                         strEqpMonitorInventory_ListGetDR_in) ;

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_ListGetDR() rc != RC_OK")
                strEqpMonitorSourceCandidateInfoInqResult.strResult = strEqpMonitorInventory_ListGetDR_out.strResult ;
                return rc ;
            }
            nSeqLen = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length();
            PPT_METHODTRACE_V2("", "strEqpMonitorInventoryInfoSeq.length", nSeqLen);

            if( 0 == nSeqLen)
            {
                PPT_METHODTRACE_V1("", "not valid strEqpMonitorInventoryInfoSeq.length" );
                CS_PPT_SET_MSG_RC_KEY1( strEqpMonitorSourceCandidateInfoInqResult,
                                        CS_MSG_NOT_FOUND_EQPMONITOR_INVENTORY_INFO,
                                        CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO,
                                        strEqpMonitorProductInfoSeq[i].productID.identifier );
                return CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO;
            }
            csEqpMonitorInventoryInfo& strEqpMonitorInventoryInfo = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq[0];
            strOrgBWSIDSeq[nProdCount] = strEqpMonitorInventoryInfo.startBWSID;
            PPT_METHODTRACE_V2("", "strOrgBWSIDSeq[nProdCount]", strOrgBWSIDSeq[nProdCount]);

            //---------------------------------------------
            // Get source product info
            //---------------------------------------------
            csObjNPW_sourceProductInfo_GetDR_in strNPW_sourceProductInfo_GetDR_in;
            strNPW_sourceProductInfo_GetDR_in.productID = strEqpMonitorProductInfoSeq[i].productID;
            strNPW_sourceProductInfo_GetDR_in.bankID.identifier = strEqpMonitorInventoryInfo.startBankID;

            csObjNPW_sourceProductInfo_GetDR_out strNPW_sourceProductInfo_GetDR_out;
            rc = cs_NPW_sourceProductInfo_GetDR(strNPW_sourceProductInfo_GetDR_out,
                                         strObjCommonIn,
                                         strNPW_sourceProductInfo_GetDR_in) ;

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cs_NPW_sourceProductInfo_GetDR() rc != RC_OK")
                strEqpMonitorSourceCandidateInfoInqResult.strResult = strNPW_sourceProductInfo_GetDR_out.strResult ;
                return rc ;
            }
            //seting return info for this Eqp Monitor Product
            strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq[nProdCount].sourceProductID.identifier = strEqpMonitorInventoryInfo.productID;
            strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq[nProdCount].subLotType = strEqpMonitorInventoryInfo.subLotType;
            strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq[nProdCount].routeID.identifier = strEqpMonitorInventoryInfo.routeID;
            strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq[nProdCount].startBankID.identifier = strEqpMonitorInventoryInfo.startBankID;
            strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq[nProdCount].availableWaferQty = strNPW_sourceProductInfo_GetDR_out.totalAvailableQty;
            nProdCount++;
            PPT_METHODTRACE_V2("", "totalAvailableQty", strNPW_sourceProductInfo_GetDR_out.totalAvailableQty);
        }
        strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq.length(nProdCount);
        strOrgBWSIDSeq.length(nProdCount);
    }
    else if( 0 == CIMFWStrCmp(strEqpMonitorSourceCandidateInfoInqInParm.npwType, CS_EqpMonitor_NPW_Type_PreProcess)
          || 0 == CIMFWStrCmp(strEqpMonitorSourceCandidateInfoInqInParm.npwType, CS_EqpMonitor_NPW_Type_Recycle) )
    {
        PPT_METHODTRACE_V1("", "npwType=PreProcess or Recycle");
        PPT_METHODTRACE_V2("", "productID", strEqpMonitorSourceCandidateInfoInqInParm.productID.identifier);

        //---------------------------------------------
        // Get monitor product setting info
        //---------------------------------------------
        csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
        strEqpMonitorInventory_ListGetDR_in.npwType = strEqpMonitorSourceCandidateInfoInqInParm.npwType;
        strEqpMonitorInventory_ListGetDR_in.productID = strEqpMonitorSourceCandidateInfoInqInParm.productID.identifier;

        csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
        rc = cs_eqpMonitorInventory_ListGetDR(strEqpMonitorInventory_ListGetDR_out,
                                     strObjCommonIn,
                                     strEqpMonitorInventory_ListGetDR_in) ;

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_ListGetDR() rc != RC_OK")
            strEqpMonitorSourceCandidateInfoInqResult.strResult = strEqpMonitorInventory_ListGetDR_out.strResult ;
            return rc ;
        }
        CORBA::Long nLen = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length();
        PPT_METHODTRACE_V2("", "strEqpMonitorInventoryInfoSeq.length", nLen);

        if( 0 == nLen)
        {
            PPT_METHODTRACE_V1("", "not valid strEqpMonitorInventoryInfoSeq.length" );
            CS_PPT_SET_MSG_RC_KEY1( strEqpMonitorSourceCandidateInfoInqResult,
                                    CS_MSG_NOT_FOUND_EQPMONITOR_INVENTORY_INFO,
                                    CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO,
                                    strEqpMonitorSourceCandidateInfoInqInParm.productID.identifier );
            return CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO;
        }
        strEqpMonitorSourceCandidateInfoInqResult.strEqpMonitorInventoryInfo = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq[0];
        strOrgBWSIDSeq.length(1);
        strOrgBWSIDSeq[0] = strEqpMonitorSourceCandidateInfoInqResult.strEqpMonitorInventoryInfo.startBWSID;
        PPT_METHODTRACE_V2("", "strOrgBWSIDSeq[0]", strOrgBWSIDSeq[0]);

        //---------------------------------------------
        // Get source product info
        //---------------------------------------------
        csObjNPW_sourceProductInfo_GetDR_in strNPW_sourceProductInfo_GetDR_in;
        strNPW_sourceProductInfo_GetDR_in.productID = strEqpMonitorSourceCandidateInfoInqInParm.productID;
        strNPW_sourceProductInfo_GetDR_in.bankID.identifier = strEqpMonitorSourceCandidateInfoInqResult.strEqpMonitorInventoryInfo.startBankID;

        csObjNPW_sourceProductInfo_GetDR_out strNPW_sourceProductInfo_GetDR_out;
        rc = cs_NPW_sourceProductInfo_GetDR(strNPW_sourceProductInfo_GetDR_out,
                                     strObjCommonIn,
                                     strNPW_sourceProductInfo_GetDR_in) ;

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_NPW_sourceProductInfo_GetDR() rc != RC_OK")
            strEqpMonitorSourceCandidateInfoInqResult.strResult = strNPW_sourceProductInfo_GetDR_out.strResult ;
            return rc ;
        }
        strEqpMonitorSourceCandidateInfoInqResult.sourceProductSeq = strNPW_sourceProductInfo_GetDR_out.sourceProductSeq;
        strEqpMonitorSourceCandidateInfoInqResult.totalAvailableQty = strNPW_sourceProductInfo_GetDR_out.totalAvailableQty;
        PPT_METHODTRACE_V2("", "totalAvailableQty", strNPW_sourceProductInfo_GetDR_out.totalAvailableQty);
    }
    else
    {
        PPT_METHODTRACE_V2("", "npwType=PreProcess or Recycle", strEqpMonitorSourceCandidateInfoInqInParm.npwType );
        SET_MSG_RC(strEqpMonitorSourceCandidateInfoInqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER);
        return RC_INVALID_PARAMETER;
    }

    //---------------------------------------------
    // Get same BWSIDs used by all products
    //---------------------------------------------
    PPT_METHODTRACE_V1("", "call csObjNPW_sameBWSID_Get_out" );
    csObjNPW_sameBWSID_Get_in strNPW_sameBWSID_Get_in;
    strNPW_sameBWSID_Get_in.strOrgBWSIDSeq = strOrgBWSIDSeq;

    csObjNPW_sameBWSID_Get_out strNPW_sameBWSID_Get_out;
    rc = cs_NPW_sameBWSID_Get( strNPW_sameBWSID_Get_out,
                               strObjCommonIn,
                               strNPW_sameBWSID_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_NPW_sameBWSID_Get() != RC_OK", rc);
        strEqpMonitorSourceCandidateInfoInqResult.strResult = strNPW_sameBWSID_Get_out.strResult;
        return rc;
    }
    BWSIDSeq = strNPW_sameBWSID_Get_out.BWSIDs;

    //---------------------------------------------
    // Get BWS Port Info
    //---------------------------------------------
    nBWSLen = BWSIDSeq.length();
    strEqpMonitorSourceCandidateInfoInqResult.strBWSInfoForSTBSeq.length(nBWSLen);

    for (i=0; i<nBWSLen; i++ )
    {
        PPT_METHODTRACE_V2( "", "call equipment_portInfo_GetDR()", BWSIDSeq[i] );

        objectIdentifier equipmentID;
        equipmentID.identifier = BWSIDSeq[i];

        objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
        rc = equipment_portInfo_GetDR( strEquipment_portInfo_GetDR_out, strObjCommonIn, equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "equipment_portInfo_GetDR rc = ", rc );
            strEqpMonitorSourceCandidateInfoInqResult.strResult = strEquipment_portInfo_GetDR_out.strResult;
            return (rc);
        }
        strEqpMonitorSourceCandidateInfoInqResult.strBWSInfoForSTBSeq[i].BWSID = equipmentID;
        strEqpMonitorSourceCandidateInfoInqResult.strBWSInfoForSTBSeq[i].strEqpPortStatus = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus;
    }

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    SET_MSG_RC(strEqpMonitorSourceCandidateInfoInqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txEqpMonitorSourceCandidateInfoInq")
    return( RC_OK );
}
