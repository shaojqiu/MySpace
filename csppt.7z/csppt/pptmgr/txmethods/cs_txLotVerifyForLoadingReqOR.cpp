#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txLotVerifyForLoadingReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:26:05 [ 7/13/07 21:26:07 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txLotVerifyForLoadingReqOR.cpp
//

//INN-A170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-A170001
#include "penin.hh"

//=============================================================================
// For TXTRC011 : txLotVerifyForLoadingReq
//=============================================================================
// Class: CS_PPTManager
//
// Service: txLotVerifyForLoadingReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/10          O.Sugiyama     Initial Release
// 2000/08/10 P3000025 O.Sugiyama     Add logic for "cassetteID/portID set to strStartCassette"
// 2000-09-04 P3000051 T.Yamano       Add logic for "check OperationStartFlag"
// 2000/09/08 P3000078 O.Sugiyama     loadPurposeType if use CIMFWStrCmp
// 2000/09/08 0.01     Y.Iwasaki      Bug fix for Loop-Counter
// 2000-09-20 Q3000107 S.Kawabe       Add check logic for EmptyCassette
// 2000-09-28 0.02     Y.Iwasaki      Bug Fix
// 2000-09-28 0.03     Y.Iwasaki      Bug Fix for initial value of operationStartFlag
// 2001-03-07 P3100077 K.Matsuei      Reticle Inhibit is not effected for Loading / StartReserve
// 2001-03-13 P3100104 K.Kido         zerofault error fix
// 2001-06-04 D4000017 O.Sugiyama     Add Detail Error MSG for LoadingLotRpt
// 2001-07-05 D4000015 H.Katoh        Add Check Logic of Equipment Category because of
//                                    Internal Buffer Support
// 2001-07-05 D4000016 M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001-07-11          O.Sugiyama     if -> #if
// 2001-08-09 D4000048 M.Ameshita     Reticle set support (Rel4.0).
// 2001-09-03 D4000138 S.Tokumasu     Add to return error code for un-candidate lot.
// 2001-09-07 D4000148 S.Tokumasu     Add lot_recipeCombination_CheckForLoading
// 2001/12/05 P4100018 M.Shimizu      Add LogicalScrap Check(Except loadPurposeType=Other carrier)
// 2002-08-06 P4200089 K.Matsuei      Lot dose not become the error of Reticle Inhibit in txLotVerifyForLoading.
// 2002-08-22 D4200062 K.Kido         Change for BakcupOperation(Rel4.2).
// 2002-08-26 P4200126 H.Adachi       Add Cassette and Port Category Check for Load Purpose Type is Other Case.
// 2002-09-20 D4200031 H.Adachi       Chg not to check reticle for the case a lot is in a operation with no photo layer.
// 2003/02/05 P4200534 H.Adachi       Add ProcessMonitorLot Quantity Check
// 2003/10/17 D5100053 T.Hikari       ProcessMonitoring By ProductionLot.
// 2004/02/20 P5100157 T.Hikari       Change set monitorLotFlag.
// 10/22/04   D6000025 K.Murakami     eBroker Migration.
// 2005/10/03 D7000009 K.Matsuei      Take-out Xfer for LoadVerifyNG Carrier by CassetteDelivery.
// 2005/11/09 D7000026 K.Kido         Delete unnecessary method (lot_GetInfoDR ==> lot_subLotType_GetDR)
// 2005/12/07 D7000042 K.Kido         Check Recipe combination only if the Lot doesn't have CJ.
// 2005/12/12 D7000135 K.Matsuei      Show the reason of ForceLoad.
// 2006/07/26 P7000118 K.Kido         Obtains recipe information only if CJ is not found.
// 2006/12/14 D7000239 H.Mutoh        Add equipment availability check for EmptyCassette and OtherPurpose.
// 2007/07/10 P9000022 M.Murata       Fix logic for Recipe Body Management.
// 2008/07/04 DSIV00000099 K.Matsuei  SLM(Small Lot Manufacturing) Support.
// 2010/04/16 DSIV00001830 R.Okano    Wafer Stacking Operation Support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2014/05/27 DSN000085791 C.Mo           Entity Inhibit Exception Lot Support. (R150)
// 2015/01/13 DSN000085770 C.Mo           Durable Control Job Management support. (R160)
// 2016/07/13 DSN000101569 K.Yamaoku      Durable Sub Status Control
// 2017/03/21 PSN000104651 XF.Ming        Access the 0th element without checking the length of the sequence
//
// Innotron Modification history :
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptLotVerifyForLoadingReqResult&    strLotVerifyForLoadingReqResult
//    const pptObjCommonIn&               strObjCommonIn
//    const objectIdentifier&             equipmentID
//    const objectIdentifier&             portID
//    const objectIdentifier&             cassetteID
//    const char *                        loadPurposeType
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
CORBA::Long CS_PPTManager_i:: txLotVerifyForLoadingReq (
    pptLotVerifyForLoadingReqResult&    strLotVerifyForLoadingReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const objectIdentifier&             portID,
    const objectIdentifier&             cassetteID,
//D6000025     const char *                        loadPurposeType,
//D6000025     CORBA::Environment &                IT_env)
    const char *                        loadPurposeType  //D6000025
    CORBAENV_LAST_CPP)                                   //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txLotVerifyForLoadingReq");
    CORBA::Long rc = RC_OK ;

    PPT_METHODTRACE_V2( "", "in para equipmentID     ", equipmentID.identifier );
    PPT_METHODTRACE_V2( "", "in para portID          ", portID.identifier );
    PPT_METHODTRACE_V2( "", "in para cassetteID      ", cassetteID.identifier );
    PPT_METHODTRACE_V2( "", "in para loadPurposeType ", loadPurposeType );

    //D4000015 Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strLotVerifyForLoadingReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //D4000015 End

//DSN000085770 Add Start
    /*---------------------------------*/
    /*   Get Durable Control Job ID    */
    /*---------------------------------*/
    objDurable_durableControlJobID_Get_out strDurable_durableControlJobID_Get_out;
    objDurable_durableControlJobID_Get_in  strDurable_durableControlJobID_Get_in;
    strDurable_durableControlJobID_Get_in.durableID       = cassetteID;
    strDurable_durableControlJobID_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
    rc = durable_durableControlJobID_Get( strDurable_durableControlJobID_Get_out, 
                                          strObjCommonIn, 
                                          strDurable_durableControlJobID_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","durable_durableControlJobID_Get() returned error.");
        strLotVerifyForLoadingReqResult.strResult = strDurable_durableControlJobID_Get_out.strResult;
        return (rc);
    }

    if ( CIMFWStrLen(strDurable_durableControlJobID_Get_out.durableControlJobID.identifier) != 0 )
    {
        if ( CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_Other) != 0 )
        {
            PPT_METHODTRACE_V2("","Port LoadPurposeType is invalid.", loadPurposeType);
            PPT_SET_MSG_RC_KEY(strLotVerifyForLoadingReqResult, MSG_INVALID_PURPOSE_TYPE_FOR_PROCESSDURABLE, RC_INVALID_PURPOSE_TYPE_FOR_PROCESSDURABLE, loadPurposeType) ;
            return (RC_INVALID_PURPOSE_TYPE_FOR_PROCESSDURABLE);
        }
    }
//DSN000085770 Add End

//P4100018 Add Start
    //-----------------------------------------------------------------------------
    //  Check Scrap Wafer Exist In Carrier (Except loadPurposeType=Other carrier)
    //-----------------------------------------------------------------------------
    if(CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_Other) != 0)
    {
        objectIdentifierSequence cassetteIDs ;
        cassetteIDs.length( 1 ) ;
        cassetteIDs[0] = cassetteID;

        objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
        rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                           strObjCommonIn,
                                           cassetteIDs);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_scrapWafer_SelectDR() != RC_OK",rc);
            strLotVerifyForLoadingReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
            return (rc);
        }

        CORBA::Long scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
        if( scrapCount > 0 )
        {
            PPT_METHODTRACE_V2("", "ScrapWafer Found ",scrapCount);
            SET_MSG_RC(strLotVerifyForLoadingReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
            return (RC_FOUND_SCRAP);
        }
    }
//P4100018 Add End

    //Q3000107 add start
    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process For Empty Cassette                                    */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
    {
        PPT_METHODTRACE_V1( "", "loadPurposeType == SP_LoadPurposeType_EmptyCassette");

        /*------------------------------------*/
        /*                                    */
        /*   Check Cassette is Empty or Not   */
        /*                                    */
        /*------------------------------------*/
        objCassette_CheckEmpty_out  strCassette_CheckEmpty_out;
        rc = cassette_CheckEmpty( strCassette_CheckEmpty_out, strObjCommonIn, cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_CheckEmpty() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strCassette_CheckEmpty_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V1( "", "Cassette is Empty.");

        /*--------------------------------------------------------*/
        /*                                                        */
        /*   Check Cassette Condition for Loading                 */
        /*                                                        */
        /*   The following conditions are checked for Loading.    */
        /*                                                        */
        /*   - controlJobID                                       */
        /*   - multiLotType                                       */
        /*   - transferState                                      */
        /*   - cassetteState                                      */
        /*                                                        */
        /*--------------------------------------------------------*/
        objCassette_CheckConditionForLoading_out   strCassette_CheckConditionForLoading_out;
        rc = cassette_CheckConditionForLoading( strCassette_CheckConditionForLoading_out, strObjCommonIn, equipmentID, portID, cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_CheckConditionForLoading() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strCassette_CheckConditionForLoading_out.strResult;
            return( rc );
        }

        /*--------------------------------------------------------*/
        /*                                                        */
        /*   Check Equipment and Port Condition for Loading       */
        /*                                                        */
        /*   The following conditions are checked for Loading.    */
        /*                                                        */
        /*   - controlJobID                                       */
        /*   - loadPort's reservedControlJob VS cassette's one    */
        /*   - loading sequence                                   */
        /*   - loadPort's portUsage (Input or InOut)              */
        /*   - loadPurposeType                                    */
        /*   - portState                                          */
        /*                                                        */
        /*--------------------------------------------------------*/
        objEquipment_CheckConditionForLoading_out   strEquipment_CheckConditionForLoading_out;
        rc = equipment_CheckConditionForLoading( strEquipment_CheckConditionForLoading_out,
                                                 strObjCommonIn,
                                                 equipmentID,
                                                 portID,
                                                 cassetteID,
                                                 loadPurposeType );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "equipment_CheckConditionForLoading() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strEquipment_CheckConditionForLoading_out.strResult;
            return( rc );
        }

//D4000016 start
        /*---------------------------------------------------------------------------*/
        /*                                                                           */
        /*   Check Category for process contamination control (Copper/Non Copper)    */
        /*                                                                           */
        /*   It is checked in the following method whether it is the condition       */
        /*   that Lot of the object is made of OpeStart.                             */
        /*                                                                           */
        /*   1. It is checked whether the CassetteCategory of PosCassette and        */
        /*      the CassetteCategoryCapability of PosPortResource are the same.      */
        /*                                                                           */
        /*   2. It is proper condition if CassetteCategoryCapability is the same     */
        /*      as RequiredCassetteCategory and CassetteCategory.                    */
        /*                                                                           */
        /*---------------------------------------------------------------------------*/

        objectIdentifier dummy;
        objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
        rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                                strObjCommonIn,
                                                                dummy,
                                                                cassetteID,
                                                                equipmentID,
                                                                portID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "CS_PPTManager_i:: txLotVerifyForLoadingReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
            return( rc );
        }
//D4000016 end
//D7000239 add start
        objEquipment_CheckAvail_out strEquipment_CheckAvail_out;
        rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn, equipmentID );
        if ( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "Equipment is now available. Go ahead!!");
        }
        else
        {
            PPT_METHODTRACE_V2("", "Equipment is not available. return to caller", rc);
            strLotVerifyForLoadingReqResult.strResult = strEquipment_CheckAvail_out.strResult;
            return( rc );
        }
//D7000239 add end

        /*--------------------------------------------*/
        /*                                            */
        /*   Return to Caller (Empty Cassette case)   */
        /*                                            */
        /*--------------------------------------------*/
        SET_MSG_RC(strLotVerifyForLoadingReqResult, MSG_OK, RC_OK);

        PPT_METHODTRACE_EXIT("");
        return ( RC_OK );
    }
    //Q3000107 add end

//DSN000085770 Add Start
    if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_Other) == 0)
    {
        /*------------------------------------*/
        /*  Call equipment_brInfo_GetDR__120  */
        /*------------------------------------*/
        PPT_METHODTRACE_V1("", "call equipment_brInfo_GetDR__120()...");
        objEquipment_brInfo_GetDR_out__120 strEquipment_brInfo_GetDR_out;
        objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
        strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
        rc = equipment_brInfo_GetDR__120( strEquipment_brInfo_GetDR_out, strObjCommonIn, strEquipment_brInfo_GetDR_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR__120() != RC_OK", rc);
            strLotVerifyForLoadingReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
            return( rc );
        }

        CORBA::ULong spcCtlLen = strEquipment_brInfo_GetDR_out.equipmentBRInfo.specialControl.length();
        for ( CORBA::ULong i=0; i<spcCtlLen; i++ )
        {
            if (CIMFWStrCmp(strEquipment_brInfo_GetDR_out.equipmentBRInfo.specialControl[i], SP_Mc_SpecialEquipmentControl_DurableCarrier) == 0
             || CIMFWStrCmp(strEquipment_brInfo_GetDR_out.equipmentBRInfo.specialControl[i], SP_Mc_SpecialEquipmentControl_DurableReticle) == 0
             || CIMFWStrCmp(strEquipment_brInfo_GetDR_out.equipmentBRInfo.specialControl[i], SP_Mc_SpecialEquipmentControl_DurableReticlePod) == 0)
            {
                /*---------------------------------*/
                /*  Check condition for durable    */
                /*---------------------------------*/
                objDurable_CheckConditionForOperation_out strDurable_CheckConditionForOperation_out;
                objDurable_CheckConditionForOperation_in  strDurable_CheckConditionForOperation_in;
                strDurable_CheckConditionForOperation_in.operation       = CIMFWStrDup(SP_Operation_Loading);
                strDurable_CheckConditionForOperation_in.equipmentID     = equipmentID;
                strDurable_CheckConditionForOperation_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
                strDurable_CheckConditionForOperation_in.strStartDurables.length(1);
                strDurable_CheckConditionForOperation_in.strStartDurables[0].durableID = cassetteID;
                rc = durable_CheckConditionForOperation( strDurable_CheckConditionForOperation_out, 
                                                         strObjCommonIn, 
                                                         strDurable_CheckConditionForOperation_in );
                if ( rc != RC_OK )
                {
                    strLotVerifyForLoadingReqResult.strResult = strDurable_CheckConditionForOperation_out.strResult;
                    return( rc );
                }

                objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
                objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
                strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup(SP_Operation_Loading);
                strDurable_status_CheckForOperation_in.durableID       = cassetteID;
                strDurable_status_CheckForOperation_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
                rc = durable_status_CheckForOperation( strDurable_status_CheckForOperation_out,
                                                       strObjCommonIn,
                                                       strDurable_status_CheckForOperation_in );
                if ( rc != RC_OK )
                {
                    strLotVerifyForLoadingReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
                    return( rc );
                }

                objEquipment_portGroupID_Get_out strEquipment_portGroupID_Get_out;
                objEquipment_portGroupID_Get_in  strEquipment_portGroupID_Get_in;
                strEquipment_portGroupID_Get_in.equipmentID = equipmentID;
                strEquipment_portGroupID_Get_in.portID      = portID;
                rc = equipment_portGroupID_Get( strEquipment_portGroupID_Get_out,
                                                strObjCommonIn,
                                                strEquipment_portGroupID_Get_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_portGroupID_Get() != RC_OK", rc);
                    strLotVerifyForLoadingReqResult.strResult = strEquipment_portGroupID_Get_out.strResult;
                    return rc;
                }

                objEquipment_and_portState_CheckForDurableOperation_out strEquipment_and_portState_CheckForDurableOperation_out;
                objEquipment_and_portState_CheckForDurableOperation_in  strEquipment_and_portState_CheckForDurableOperation_in;
                strEquipment_and_portState_CheckForDurableOperation_in.operation        = CIMFWStrDup(SP_Operation_Loading);
                strEquipment_and_portState_CheckForDurableOperation_in.equipmentID      = equipmentID;
                strEquipment_and_portState_CheckForDurableOperation_in.portGroupID      = strEquipment_portGroupID_Get_out.portGroupID;
                strEquipment_and_portState_CheckForDurableOperation_in.durableCategory  = CIMFWStrDup(SP_DurableCat_Cassette);
                strEquipment_and_portState_CheckForDurableOperation_in.strStartDurables.length(1);
                strEquipment_and_portState_CheckForDurableOperation_in.strStartDurables[0].durableID = cassetteID;
                strEquipment_and_portState_CheckForDurableOperation_in.strStartDurables[0].strStartDurablePort.loadPortID = portID;
                strEquipment_and_portState_CheckForDurableOperation_in.strStartDurables[0].strStartDurablePort.loadPurposeType = loadPurposeType;
                rc = equipment_and_portState_CheckForDurableOperation( strEquipment_and_portState_CheckForDurableOperation_out,
                                                                       strObjCommonIn,
                                                                       strEquipment_and_portState_CheckForDurableOperation_in );
                if ( rc != RC_OK )
                {
                    strLotVerifyForLoadingReqResult.strResult = strEquipment_and_portState_CheckForDurableOperation_out.strResult;
                    return( rc );
                }

                objDurable_CassetteCategory_CheckForContaminationControl_out strDurable_CassetteCategory_CheckForContaminationControl_out;
                objDurable_CassetteCategory_CheckForContaminationControl_in  strDurable_CassetteCategory_CheckForContaminationControl_in;
                strDurable_CassetteCategory_CheckForContaminationControl_in.cassetteID  = cassetteID;
                strDurable_CassetteCategory_CheckForContaminationControl_in.equipmentID = equipmentID;
                strDurable_CassetteCategory_CheckForContaminationControl_in.portID      = portID;
                rc = durable_CassetteCategory_CheckForContaminationControl( strDurable_CassetteCategory_CheckForContaminationControl_out,
                                                                            strObjCommonIn,
                                                                            strDurable_CassetteCategory_CheckForContaminationControl_in );
                if ( rc != RC_OK )
                {
                    strLotVerifyForLoadingReqResult.strResult = strDurable_CassetteCategory_CheckForContaminationControl_out.strResult;
                    return( rc );
                }

                objEquipment_CheckAvail_out strEquipment_CheckAvail_out;
                rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn, equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "Equipment is not available. return to caller", rc);
                    strLotVerifyForLoadingReqResult.strResult = strEquipment_CheckAvail_out.strResult;
                    return( rc );
                }

                return ( RC_OK );
            }
        }
    }
//DSN000085770 Add End
    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process For Lot                                               */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    pptStartCassette strStartCassette;

    //P3000025 add start
    /*----------------------------------------------*/
    /*   Set Input Parameters to strStartCassette   */
    /*----------------------------------------------*/
    strStartCassette.cassetteID      = cassetteID;                     //P3000025
    strStartCassette.loadPurposeType = loadPurposeType;                //P3000025
    strStartCassette.loadPortID      = portID;                         //P3000025
    //P3000025 add end

    strStartCassette.loadSequenceNumber = 0;                           //P3100104

    /*---------------------------------*/
    /*   Get Cassette's ControlJobID   */
    /*---------------------------------*/
    PPT_METHODTRACE_V1( "", "Get Cassette's ControlJobID");
    objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
    rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn,
                                   cassetteID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK");
        strLotVerifyForLoadingReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
        return( rc );
    }

    CORBA::Long i = 0;
    CORBA::Long lotLen = 0;
    if (CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1( "", "CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) == 0");
        /*-----------------------------------*/
        /*   Get Contained Lot in Cassette   */
        /*-----------------------------------*/
        PPT_METHODTRACE_V1( "", "Get Contained Lot in Cassette");
        objCassette_GetLotList_out strCassette_GetLotList_out;
        rc = cassette_GetLotList(strCassette_GetLotList_out, strObjCommonIn,
                                 cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_GetLotList() != RC_OK");
            if (rc == RC_NOT_FOUND_LOT &&                                                               //DSIV00000099
                CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_SLMRetrieving) == 0)                    //DSIV00000099
            {                                                                                           //DSIV00000099
                PPT_METHODTRACE_V1( "", "rc == RC_NOT_FOUND_LOT && loadPurposeType = SLMRetrieving");   //DSIV00000099
            }                                                                                           //DSIV00000099
            else                                                                                        //DSIV00000099
            {                                                                                           //DSIV00000099
                strLotVerifyForLoadingReqResult.strResult = strCassette_GetLotList_out.strResult;
                return( rc );
            }                                                                                           //DSIV00000099
        }

        lotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
//        strStartCassette.strLotInCassette(lotLen);
        strStartCassette.strLotInCassette.length(lotLen);

        PPT_METHODTRACE_V2( "", "lotLen = ", lotLen);
        for ( i=0 ; i<lotLen ; i++ )
        {
//0.03      strStartCassette.strLotInCassette[i].operationStartFlag = FALSE;
            if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_SLMRetrieving) != 0)                    //DSIV00000099
            {                                                                                           //DSIV00000099
                strStartCassette.strLotInCassette[i].operationStartFlag = TRUE;   //0.03
            }                                                                                           //DSIV00000099
            else                                                                                        //DSIV00000099
            {                                                                                           //DSIV00000099
                strStartCassette.strLotInCassette[i].operationStartFlag = FALSE;                        //DSIV00000099
            }                                                                                           //DSIV00000099
            strStartCassette.strLotInCassette[i].lotID = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[i];
            if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot) == 0)
            {
//Q3000104       strStartCassette.strLotInCassette[i].monitorLotFlag = TRUE;
                //Q3000104 add start
                /*------------------*/
                /*   Get Lot Type   */
                /*------------------*/
                objLot_type_Get_out strLot_type_Get_out;
                rc = lot_type_Get( strLot_type_Get_out, strObjCommonIn, strStartCassette.strLotInCassette[i].lotID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "lot_type_Get() != RC_OK");
                    strLotVerifyForLoadingReqResult.strResult = strLot_type_Get_out.strResult;
                    return( rc );
                }
                if (CIMFWStrCmp(strLot_type_Get_out.theLotType, SP_Lot_Type_ProductionMonitorLot ) == 0)
                {
                    PPT_METHODTRACE_V1("","theLotType == SP_Lot_Type_ProductionMonitorLot");
                    strStartCassette.strLotInCassette[i].monitorLotFlag = TRUE;
                }
                else
                {
//D5100053 Add Start
                    objLot_monitorRouteFlag_Get_out strLot_monitorRouteFlag_Get_out;

                    rc = lot_monitorRouteFlag_Get(strLot_monitorRouteFlag_Get_out,
                                                  strObjCommonIn,
                                                  strStartCassette.strLotInCassette[i].lotID);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("","lot_monitorRouteFlag_Get() != RC_OK");
                        strLotVerifyForLoadingReqResult.strResult = strLot_monitorRouteFlag_Get_out.strResult;
                        return ( rc );
                    }

                    PPT_METHODTRACE_V2( "", "monitorRoute_Flag =", strLot_monitorRouteFlag_Get_out.monitorRoute_Flag );

                    if ( strLot_monitorRouteFlag_Get_out.monitorRoute_Flag == TRUE )
                    {
                        strStartCassette.strLotInCassette[i].monitorLotFlag = TRUE;
                        PPT_METHODTRACE_V1("","strStartCassette.strLotInCassette[i].monitorLotFlag = TRUE");
                    }
                    else
                    {
                        strStartCassette.strLotInCassette[i].monitorLotFlag = FALSE;
                        PPT_METHODTRACE_V1("","strStartCassette.strLotInCassette[i].monitorLotFlag = FALSE");
                    }
//D5100053 Add End
//D5100053                    PPT_METHODTRACE_V1("","theLotType != SP_Lot_Type_ProductionMonitorLot");
//D5100053                    strStartCassette.strLotInCassette[i].monitorLotFlag = FALSE;
                }
                //Q3000104 add end
                strStartCassette.strLotInCassette[i].lotType = strLot_type_Get_out.theLotType;    //P4200534
            }
            else
            {
                strStartCassette.strLotInCassette[i].monitorLotFlag = FALSE;
            }
        }
    }
    else
    {
        PPT_METHODTRACE_V1( "", "CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) != 0");
        /*-------------------------------------*/
        /*   Get Contained Lot in ControlJob   */
        /*-------------------------------------*/
        PPT_METHODTRACE_V1( "", "Get Contained Lot in ControlJob");
        objControlJob_containedLot_Get_out strControlJob_containedLot_Get_out;
        rc = controlJob_containedLot_Get(strControlJob_containedLot_Get_out, strObjCommonIn,
                                         strCassette_controlJobID_Get_out.controlJobID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "controlJob_containedLot_Get() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strControlJob_containedLot_Get_out.strResult;
            return( rc );
        }

        CORBA::Long nLen = strControlJob_containedLot_Get_out.strControlJobCassette.length();
        PPT_METHODTRACE_V2( "", "nLen = ", nLen);
        for ( i=0 ; i<nLen; i++ )
        {
            if (CIMFWStrCmp(strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID.identifier,
                            cassetteID.identifier) == 0)
            {
                lotLen = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot.length();
//                strStartCassette.strLotInCassette(lotLen);
                strStartCassette.strLotInCassette.length(lotLen);
                CORBA::Long j = 0;
                PPT_METHODTRACE_V3( "", "lotLen = ", lotLen, i);
                for ( j=0 ; j<lotLen ; j++ )
                {
                    strStartCassette.strLotInCassette[j].operationStartFlag = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].operationStartFlag;
//P5100157//D5100053 Add Start
//P5100157                    objLot_monitorRouteFlag_Get_out strLot_monitorRouteFlag_Get_out;
//P5100157                    rc = lot_monitorRouteFlag_Get(strLot_monitorRouteFlag_Get_out,
//P5100157                                                  strObjCommonIn,
//P5100157                                                  strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].lotID);
//P5100157                    if ( rc != RC_OK )
//P5100157                    {
//P5100157                        PPT_METHODTRACE_V1( "","lot_monitorRouteFlag_Get() != RC_OK");
//P5100157                        strLotVerifyForLoadingReqResult.strResult = strLot_monitorRouteFlag_Get_out.strResult;
//P5100157                        return ( rc );
//P5100157                    }
//P5100157
//P5100157                    PPT_METHODTRACE_V2( "", "monitorRoute_Flag =", strLot_monitorRouteFlag_Get_out.monitorRoute_Flag );
//P5100157
//P5100157                    if ( strLot_monitorRouteFlag_Get_out.monitorRoute_Flag == TRUE )
//P5100157                    {
//P5100157                        strStartCassette.strLotInCassette[j].monitorLotFlag = TRUE;
//P5100157                        PPT_METHODTRACE_V1( "","strStartCassette.strLotInCassette[j].monitorLotFlag = TRUE");
//P5100157                    }
//P5100157                    else
//P5100157                    {
//P5100157                        strStartCassette.strLotInCassette[j].monitorLotFlag = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag;
//P5100157                        PPT_METHODTRACE_V2( "", "strStartCassette.strLotInCassette[j].monitorLotFlag =", strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag );
//P5100157                    }
//P5100157//D5100053 Add End
//D5100053                    strStartCassette.strLotInCassette[j].monitorLotFlag     = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag;
                    strStartCassette.strLotInCassette[j].monitorLotFlag     = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag;    //P5100157
                    strStartCassette.strLotInCassette[j].lotID              = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].lotID;

                    //P4200534 Add Start
                    objLot_type_Get_out strLot_type_Get_out;
                    rc = lot_type_Get( strLot_type_Get_out, strObjCommonIn, strStartCassette.strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "", "lot_type_Get() != RC_OK");
                        strLotVerifyForLoadingReqResult.strResult = strLot_type_Get_out.strResult;
                        return( rc );
                    }
                    strStartCassette.strLotInCassette[j].lotType = strLot_type_Get_out.theLotType;

                    PPT_METHODTRACE_V3( "", "LotID & LotType", strStartCassette.strLotInCassette[j].lotID.identifier,
                                                               strStartCassette.strLotInCassette[j].lotType );
                    //P4200534 Add End
                }
                break;
            }
        }
    }

    /*-------------------------------------------------------*/
    /*                                                       */
    /*   Check Lot Condition for Loading                     */
    /*                                                       */
    /*   The following conditions are checked for each lot.  */
    /*                                                       */
    /*   - lot's equipmentID                                 */
    /*   - lotHoldState                                      */
    /*   - lotProcessState                                   */
    /*   - lotInventoryState                                 */
    /*   - entityInhibition                                  */
    /*   - equipment's availability for specified lot        */
    /*                                                       */
    /*   (*)                                                 */ //P3100077
    /*   About for reticle/fixture, whether these are        */ //P3100077
    /*   Inhibited or not itself is checked at later.        */ //P3100077
    /*   (by processDurable_CheckConditionForOpeStart)       */ //P3100077
    /*-------------------------------------------------------*/
    PPT_METHODTRACE_V1( "", "Check Lot Condition for Loading");
    PPT_METHODTRACE_V2( "", "lotLen = ", lotLen);
//D7000239 add start
    if ( 0 == CIMFWStrCmp(strStartCassette.loadPurposeType, SP_LoadPurposeType_Other) )
    {
        PPT_METHODTRACE_V2("", "LoadPurposeType is ", strStartCassette.loadPurposeType);
        objEquipment_CheckAvail_out strEquipment_CheckAvail_out;
        rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn, equipmentID );
        if ( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "Equipment is now available. Go ahead!!");
        }
        else
        {
            PPT_METHODTRACE_V2("", "Equipment is not available. return to caller", rc);
            strLotVerifyForLoadingReqResult.strResult = strEquipment_CheckAvail_out.strResult;
            return( rc );
        }
    }
//D7000239 add end
//D4000017 add start
    stringSequence verifyNGReasons;
    verifyNGReasons.length( lotLen );
//D4000017 add end
    for ( i=0 ; i<lotLen ; i++ )
    {
//D4000017 add start
        verifyNGReasons[i] = CIMFWStrDup("");
//D4000017 add end
        // Start L0.02
        if ( strStartCassette.strLotInCassette[i].operationStartFlag == FALSE )
        {
            continue;
        }
        // End L0.02

        objLot_CheckConditionForLoading_out strLot_CheckConditionForLoading_out;
        rc = lot_CheckConditionForLoading(strLot_CheckConditionForLoading_out, strObjCommonIn,
                                          equipmentID,
                                          strStartCassette.strLotInCassette[i].lotID );
        if ( rc == RC_OK )
        {
            strStartCassette.strLotInCassette[i].operationStartFlag = TRUE;
            PPT_METHODTRACE_V2( "", "Check Lot Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", "TRUE"); //PSN000104651
        }
        else if ( rc == RC_NOT_CANDIDATE_LOT_FOR_OPE_START )
        {
            strStartCassette.strLotInCassette[i].operationStartFlag = FALSE;
            PPT_METHODTRACE_V2( "", "Check Lot Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", "FALSE"); //PSN000104651
//D4000017 add start
            verifyNGReasons[i] = strLot_CheckConditionForLoading_out.strResult.messageText;
            PPT_METHODTRACE_V3( "", "verifyNGReasons[i]", i, verifyNGReasons[i]);
//D4000017 add end
        }
        else
        {
            PPT_METHODTRACE_V1( "", "lot_CheckConditionForLoading() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strLot_CheckConditionForLoading_out.strResult;
            return( rc );
        }
    }
//PSN000104651    PPT_METHODTRACE_V2( "", "Check Lot Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    /*--------------------------------------------------------*/
    /*                                                        */
    /*   Check Cassette Condition for Loading                 */
    /*                                                        */
    /*   The following conditions are checked for Loading.    */
    /*                                                        */
    /*   - controlJobID                                       */
    /*   - multiLotType                                       */
    /*   - transferState                                      */
    /*   - cassetteState                                      */
    /*                                                        */
    /*--------------------------------------------------------*/
    PPT_METHODTRACE_V1( "", "Check Cassette Condition for Loading");
//PSN000104651    PPT_METHODTRACE_V2( "", "Check Cassette Condition for Loading befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    objCassette_CheckConditionForLoading_out strCassette_CheckConditionForLoading_out;
    rc = cassette_CheckConditionForLoading(strCassette_CheckConditionForLoading_out, strObjCommonIn,
                                           equipmentID, portID, cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "cassette_CheckConditionForLoading() != RC_OK");
        strLotVerifyForLoadingReqResult.strResult = strCassette_CheckConditionForLoading_out.strResult;

//D7000009 start
        // strLoadingVerifiedLot information must be set for ForceLoad process.
        if ( rc == RC_INVALID_CAST_XFERSTAT )
        {
            PPT_METHODTRACE_V1("", "rc == RC_INVALID_CAST_XFERSTAT");
            PPT_METHODTRACE_V2("", "lotLen", lotLen);
            strLotVerifyForLoadingReqResult.strLoadingVerifiedLot.length( lotLen );
            for ( CORBA::Long j=0; j < lotLen; j++ )
            {
                strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].operationStartFlag = FALSE;
                strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].monitorLotFlag     = FALSE;
                strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].lotID              = strStartCassette.strLotInCassette[j].lotID;
//D7000135 start
                strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].verifyNGReason     = strCassette_CheckConditionForLoading_out.strResult.messageText;
                PPT_METHODTRACE_V2( "", "verifyNGReason", strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].verifyNGReason);
//D7000135 end
                PPT_METHODTRACE_V2( "", "Check Cassette Condition for Loading after strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].operationStartFlag", "FALSE"); //PSN000104651
            }
        }
//D7000009 end

        return( rc );
    }
//PSN000104651    PPT_METHODTRACE_V2( "", "Check Cassette Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    /*--------------------------------------------------------*/
    /*                                                        */
    /*   Check Equipment and Port Condition for Loading       */
    /*                                                        */
    /*   The following conditions are checked for Loading.    */
    /*                                                        */
    /*   - controlJobID                                       */
    /*   - loadPort's reservedControlJob VS cassette's one    */
    /*   - loading sequence                                   */
    /*   - loadPort's portUsage (Input or InOut)              */
    /*   - loadPurposeType                                    */
    /*   - portState                                          */
    /*                                                        */
    /*--------------------------------------------------------*/
    PPT_METHODTRACE_V1( "", "Check Equipment and Port Condition for Loading");
//PSN000104651    PPT_METHODTRACE_V2( "", "Check Equipment and Port Condition for Loading befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    objEquipment_CheckConditionForLoading_out strEquipment_CheckConditionForLoading_out;
    rc = equipment_CheckConditionForLoading(strEquipment_CheckConditionForLoading_out, strObjCommonIn,
                                            equipmentID, portID, cassetteID, loadPurposeType );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "equipment_CheckConditionForLoading() != RC_OK");
        strLotVerifyForLoadingReqResult.strResult = strEquipment_CheckConditionForLoading_out.strResult;

//D7000009 start
        // strLoadingVerifiedLot information must be set for ForceLoad process.
        if ( rc == RC_CAST_CTRLJOBID_BLANK )
        {
            PPT_METHODTRACE_V1("", "rc == RC_CAST_CTRLJOBID_BLANK");
            PPT_METHODTRACE_V2("", "lotLen", lotLen);
            strLotVerifyForLoadingReqResult.strLoadingVerifiedLot.length( lotLen );
            for ( CORBA::Long j=0; j < lotLen; j++ )
            {
                strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].operationStartFlag = FALSE;
                strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].monitorLotFlag     = FALSE;
                strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].lotID              = strStartCassette.strLotInCassette[j].lotID;
//D7000135 start
                strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].verifyNGReason     = strEquipment_CheckConditionForLoading_out.strResult.messageText;
                PPT_METHODTRACE_V2( "", "verifyNGReason", strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].verifyNGReason);
//D7000135 end
                PPT_METHODTRACE_V2( "", "Check Equipment and Port Condition for Loading after strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[j].operationStartFlag", "FALSE"); //PSN000104651
            }
        }
//D7000009 end

        return( rc );
    }
//PSN000104651    PPT_METHODTRACE_V2( "", "Check Equipment and Port Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

//DSIV00000099 start
    if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_SLMRetrieving) == 0)
    {
        /*----------------------------------------*/
        /*                                        */
        /*   Check Condition for SLM.             */
        /*                                        */
        /*----------------------------------------*/
        objSLM_CheckConditionForOperation_out strSLM_CheckConditionForOperation_out;
        objSLM_CheckConditionForOperation_in  strSLM_CheckConditionForOperation_in;

        pptStartCassetteSequence strStartCassetteSeq;
        strStartCassetteSeq.length(1);
        strStartCassetteSeq[0] = strStartCassette;

        strSLM_CheckConditionForOperation_in.equipmentID = equipmentID;
        strSLM_CheckConditionForOperation_in.strStartCassette = strStartCassetteSeq;
        strSLM_CheckConditionForOperation_in.operation = CIMFWStrDup( SP_Operation_LoadingLot );

        PPT_METHODTRACE_V1("", "call SLM_CheckConditionForOperation()");
        rc = SLM_CheckConditionForOperation( strSLM_CheckConditionForOperation_out,
                                             strObjCommonIn,
                                             strSLM_CheckConditionForOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "SLM_CheckConditionForOperation() != RC_OK", rc);
            strLotVerifyForLoadingReqResult.strResult = strSLM_CheckConditionForOperation_out.strResult;
            return( rc );
        }
    }
//DSIV00000099 end

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check FlowBatch Condition for Loading                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
    /*      fill  -> in-parm's lot must have same flowBatchID                */
    /*      blank -> no check                                                */
    /*                                                                       */
    /*   2. whether lot is in flowBatch section or not                       */
    /*      in    -> lot must have flowBatchID, and flowBatch must have      */
    /*               reserved equipmentID.                                   */
    /*               if lot is on target operation, flowBatch's reserved     */
    /*               equipmentID and in-parm's equipmentID must be same.     */
    /*      out   -> no check                                                */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1( "", "Check FlowBatch Condition for Loading");
//PSN000104651    PPT_METHODTRACE_V2( "", "Check FlowBatch Condition for Loading befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    objEquipment_lot_CheckFlowBatchConditionForLoading_out strEquipment_lot_CheckFlowBatchConditionForLoading_out;
    rc = equipment_lot_CheckFlowBatchConditionForLoading(strEquipment_lot_CheckFlowBatchConditionForLoading_out,
                                                         strObjCommonIn,
                                                         equipmentID, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "equipment_lot_CheckFlowBatchConditionForLoading() != RC_OK");
        strLotVerifyForLoadingReqResult.strResult = strEquipment_lot_CheckFlowBatchConditionForLoading_out.strResult;
        return( rc );
    }
//PSN000104651    PPT_METHODTRACE_V2( "", "Check FlowBatch Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process Durable Condition for Loading                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. Whether equipment requires process durable or not                */
    /*      If no-need, return OK;                                           */
    /*                                                                       */
    /*   2. At least one of reticle / fixture for each reticleGroup /        */
    /*      fixtureGroup is in the equipment or not.                         */
    /*      Even if required reticle is in the equipment, its status must    */
    /*      be _Available or _InUse.                                         */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1( "", "Check Process Durable Condition for Loading");
//PSN000104651    PPT_METHODTRACE_V2( "", "Check Process Durable Condition for Loading befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

//P3000078  if ( loadPurposeType == SP_LoadPurposeType_EmptyCassette )
    if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0) //P3000078
    {
        //no-need to check for process durable
        ;
    }
    else
    {
        /*-----------------------------------------*/
        /*   Check Process Durable Required Flag   */
        /*-----------------------------------------*/
        PPT_METHODTRACE_V1( "", "Check Process Durable Required Flag");

        objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
        rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out,
                                                       strObjCommonIn,
                                                       equipmentID );

        CORBA::Long saveRC = rc;    //P3100077

        if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
        {
            PPT_METHODTRACE_V1( "", "rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");
            CORBA::Long j = 0;
            CORBA::Long nLen = strStartCassette.strLotInCassette.length();
            PPT_METHODTRACE_V2( "", "nLen = ", nLen);
            for ( j=0 ; j<nLen; j++ )
            {
//0.01          if ( strStartCassette.strLotInCassette[i].operationStartFlag == FALSE )
                if ( strStartCassette.strLotInCassette[j].operationStartFlag == FALSE ) //0.01
                {
                    PPT_METHODTRACE_V1( "", "strStartCassette.strLotInCassette[j].operationStartFlag == FALSE");
                    continue;
                }

//P7000118                /*-------------------------------------------------*/
//P7000118                /*   Get Lot's LogicalRecipeID / MachineRecipeID   */
//P7000118                /*-------------------------------------------------*/
//P7000118                PPT_METHODTRACE_V1( "", "Get Lot's LogicalRecipeID / MachineRecipeID");
//P7000118
//P7000118                objLot_recipe_Get_out strLot_recipe_Get_out;
//P7000118                rc = lot_recipe_Get(strLot_recipe_Get_out, strObjCommonIn,
//P7000118//0.01                              equipmentID, strStartCassette.strLotInCassette[i].lotID );
//P7000118                                    equipmentID, strStartCassette.strLotInCassette[j].lotID ); //0.01
//P7000118                if ( rc != RC_OK )
//P7000118                {
//P7000118                    PPT_METHODTRACE_V1( "", "lot_recipe_Get() != RC_OK");
//P7000118                    strLotVerifyForLoadingReqResult.strResult = strLot_recipe_Get_out.strResult;
//P7000118                    return( rc );
//P7000118                }
//P7000118//0.01          strStartCassette.strLotInCassette[i].strStartRecipe.logicalRecipeID = strLot_recipe_Get_out.logicalRecipeID;
//P7000118//0.01          strStartCassette.strLotInCassette[i].strStartRecipe.machineRecipeID = strLot_recipe_Get_out.machineRecipeID;
//P7000118                strStartCassette.strLotInCassette[j].strStartRecipe.logicalRecipeID = strLot_recipe_Get_out.logicalRecipeID; //0.01
//P7000118                strStartCassette.strLotInCassette[j].strStartRecipe.machineRecipeID = strLot_recipe_Get_out.machineRecipeID; //0.01

//P3100077 start
                /*--------------------------------*/
                /*   check reserve reticle info   */
                /*--------------------------------*/
                PPT_METHODTRACE_V1( "", "/*--------------------------------*/");
                PPT_METHODTRACE_V1( "", "/*   check reserve reticle info   */");
                PPT_METHODTRACE_V1( "", "/*--------------------------------*/");

                if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100077 start @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    PPT_METHODTRACE_V1("", "Exist controlJobID !!");

                    objControlJob_startReserveInformation_Get_out strControlJob_startReserveInformation_Get_out;
                    rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
                                                                 strObjCommonIn,
                                                                 strCassette_controlJobID_Get_out.controlJobID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() rc != RC_OK");
                        strLotVerifyForLoadingReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult;
                        return( rc );
                    }

                    CORBA::Long lenStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette.length();
                    PPT_METHODTRACE_V2("", "lenStartCassette", lenStartCassette);
                    CORBA::Long k, l, m;

                    for ( k=0; k < lenStartCassette; k++ )
                    {
                        PPT_METHODTRACE_V2("", "StartCassette-------------------------------round [K]", k);

                        if ( 0 == CIMFWStrCmp(strControlJob_startReserveInformation_Get_out.strStartCassette[k].cassetteID.identifier,
                                              cassetteID.identifier) )
                        {
                            PPT_METHODTRACE_V2("", "found same cassette!!", cassetteID.identifier);

                            CORBA::Long lenLotInCassette = strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette.length();
                            PPT_METHODTRACE_V2("", "lenLotInCassette", lenLotInCassette);

                            for ( l=0; l < lenLotInCassette; l++ )
                            {
                                PPT_METHODTRACE_V2("", "LotInCassette-----------------------------------round [l]", l);

                                if ( FALSE == strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].operationStartFlag )
                                {
                                    PPT_METHODTRACE_V1("", "FALSE == operationStartFlag ---> continue!!");
                                    continue;
                                }

//D4200031                      if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD                                     //D4200031
                                  && strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle.length()> 0 ) //D4200031
                                {
                                    PPT_METHODTRACE_V1("", "saveRC == RC_EQP_PROCDRBL_RTCL_REQD");

                                    /*---------------------------------*/
                                    /*   Get and Check Reticle State   */
                                    /*     - state                     */
                                    /*     - transferState             */
                                    /*---------------------------------*/
                                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");
                                    PPT_METHODTRACE_V1("", "/*   Get and Check Reticle State   */");
                                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");

                                    objReticle_state_Check_out strReticle_state_Check_out;
//DSN000101569                                    rc = reticle_state_Check( strReticle_state_Check_out,
//DSN000101569                                                              strObjCommonIn,
//DSN000101569                                                              equipmentID,
//DSN000101569                                                              strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle );
//DSN000101569 add start
                                    rc = reticle_state_Check__170( strReticle_state_Check_out,
                                                                   strObjCommonIn,
                                                                   equipmentID,
                                                                   strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle,
                                                                   strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].lotID );
//DSN000101569 add end
                                    if ( rc != RC_OK )
                                    {
                                        PPT_METHODTRACE_V1("", "reticle_state_Check() rc != RC_OK");
                                        strLotVerifyForLoadingReqResult.strResult = strReticle_state_Check_out.strResult;
                                        return( rc );
                                    }

                                    /*------------------------------*/
                                    /*   Check Reticle Inhibition   */
                                    /*------------------------------*/
                                    PPT_METHODTRACE_V1("", "/*------------------------------*/");
                                    PPT_METHODTRACE_V1("", "/*   Check Reticle Inhibition   */");
                                    PPT_METHODTRACE_V1("", "/*------------------------------*/");

                                    CORBA::Long lenStartReticle = strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle.length();
                                    PPT_METHODTRACE_V2("", "lenStartReticle", lenStartReticle);

                                    pptEntityInhibitAttributes entityInhibitAttributes;
                                    entityInhibitAttributes.entities.length(lenStartReticle);

                                    for ( m=0 ; m < lenStartReticle ; m++ )
                                    {
                                        entityInhibitAttributes.entities[m].className = CIMFWStrDup( SP_InhibitClassID_Reticle );
                                        entityInhibitAttributes.entities[m].objectID  = strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle[m].reticleID;
                                        entityInhibitAttributes.entities[m].attrib    = CIMFWStrDup( "" );

                                        PPT_METHODTRACE_V2("", "entityInhibitAttributes.entities[k].objectID ---> ", entityInhibitAttributes.entities[m].objectID.identifier);
                                    }

//P4200089 start
                                    // Get Lot's subLotType
//D7000026                          objLot_GetInfoDR_out strLot_GetInfoDR_out;
//D7000026                          rc = lot_GetInfoDR( strLot_GetInfoDR_out,
//D7000026                                              strObjCommonIn,
//D7000026                                              strStartCassette.strLotInCassette[j].lotID,
//D7000026                                              TRUE,       // lotBasicInfoFlag
//D7000026                                              FALSE,      // lotControlUseInfoFlag
//D7000026                                              FALSE,      // lotFlowBatchInfoFlag
//D7000026                                              FALSE,      // lotNoteFlagInfoFlag
//D7000026                                              FALSE,      // lotOperationInfoFlag
//D7000026                                              FALSE,      // lotOrderInfoFlag
//D7000026                                              FALSE,      // lotControlJobInfoFlag
//D7000026                                              FALSE,      // lotProductInfoFlag
//D7000026                                              FALSE,      // lotRecipeInfoFlag
//D7000026                                              FALSE,      // lotLocationInfoFlag
//D7000026                                              FALSE,      // lotWipOperationInfoFlag
//D7000026                                              FALSE,      // lotWaferAttributesFlag
//D7000026                                              FALSE );    //D4200062 lotBackupInfoFlag
//D7000026
//D7000026                          PPT_METHODTRACE_V2("", "subLotType", strLot_GetInfoDR_out.strLotInfo.strLotBasicInfo.subLotType);
//D7000026                          if ( 0 < CIMFWStrLen(strLot_GetInfoDR_out.strLotInfo.strLotBasicInfo.subLotType) )
//D7000026                          {
//D7000026                              entityInhibitAttributes.subLotTypes.length(1);
//D7000026                              entityInhibitAttributes.subLotTypes[0] = CIMFWStrDup( strLot_GetInfoDR_out.strLotInfo.strLotBasicInfo.subLotType );
//D7000026                          }
//D7000026                          else
//D7000026                          {
//D7000026                              entityInhibitAttributes.subLotTypes.length(0);
//D7000026                          }
//D7000026 add start
                                    objLot_subLotType_GetDR_out strLot_subLotType_GetDR_out;
                                    rc = lot_subLotType_GetDR( strLot_subLotType_GetDR_out, strObjCommonIn,
                                                               strStartCassette.strLotInCassette[j].lotID );

                                    if( rc != RC_OK )
                                    {
                                        PPT_METHODTRACE_V1(""," #### lot_subLotType_GetDR != RC_OK");
                                        strLotVerifyForLoadingReqResult.strResult = strLot_subLotType_GetDR_out.strResult ;
                                        return rc ;
                                    }

                                    if ( 0 < CIMFWStrLen( strLot_subLotType_GetDR_out.subLotType ) )
                                    {
                                        entityInhibitAttributes.subLotTypes.length(1);
                                        entityInhibitAttributes.subLotTypes[0] = CIMFWStrDup( strLot_subLotType_GetDR_out.subLotType );
                                    }
                                    else
                                    {
                                        entityInhibitAttributes.subLotTypes.length(0);
                                    }
//D7000026 add end
//P4200089 end

                                    objEntityInhibit_CheckForEntities_out strEntityInhibit_CheckForEntities_out;
                                    rc = entityInhibit_CheckForEntities( strEntityInhibit_CheckForEntities_out,
                                                                         strObjCommonIn,
                                                                         entityInhibitAttributes );
                                    if ( rc != RC_OK )
                                    {
                                        PPT_METHODTRACE_V1("", "entityInhibit_CheckForEntities() rc != RC_OK");
                                        strLotVerifyForLoadingReqResult.strResult = strEntityInhibit_CheckForEntities_out.strResult;
                                        return( rc );
                                    }

                                    CORBA::Long lenInhibit = strEntityInhibit_CheckForEntities_out.entityInhibitInfo.length();
                                    PPT_METHODTRACE_V2("", "lenInhibit", lenInhibit );
//DSN000085791 add start
                                    objEntityInhibit_FilterExceptionLot_out strEntityInhibit_FilterExceptionLot_out;
                                    if ( lenInhibit > 0 )
                                    {
                                        // filter exception for entity inhibit
                                        objEntityInhibit_FilterExceptionLot_in strEntityInhibit_FilterExceptionLot_in;
                                        strEntityInhibit_FilterExceptionLot_in.strEntityInhibitInfos = strEntityInhibit_CheckForEntities_out.entityInhibitInfo;
                                        strEntityInhibit_FilterExceptionLot_in.lotID = strStartCassette.strLotInCassette[j].lotID;

                                        rc = entityInhibit_FilterExceptionLot(strEntityInhibit_FilterExceptionLot_out,
                                                                              strObjCommonIn,
                                                                              strEntityInhibit_FilterExceptionLot_in);
                                        if ( rc != RC_OK )
                                        {
                                            PPT_METHODTRACE_V2( ""," #### entityInhibit_FilterExceptionLot() != RC_OK : rc = ", rc );
                                            strLotVerifyForLoadingReqResult.strResult = strEntityInhibit_FilterExceptionLot_out.strResult;
                                            return rc;
                                        }

                                        lenInhibit = strEntityInhibit_FilterExceptionLot_out.strEntityInhibitInfos.length();
                                        PPT_METHODTRACE_V2("","number of Inhibits filtered exception",lenInhibit);
                                    }
//DSN000085791 add end
                                    if( lenInhibit > 0 )
                                    {
                                        PPT_METHODTRACE_V2("", "Inhibit record for reticle is found", lenInhibit );
                                        PPT_SET_MSG_RC_KEY2 ( strLotVerifyForLoadingReqResult,
                                                              MSG_INHIBIT_ENTITY,
                                                              RC_INHIBIT_ENTITY,
//DSN000085791                                                              strEntityInhibit_CheckForEntities_out.entityInhibitInfo[0].entityInhibitAttributes.entities[0].objectID.identifier,
                                                              strEntityInhibit_FilterExceptionLot_out.strEntityInhibitInfos[0].entityInhibitAttributes.entities[0].objectID.identifier, //DSN000085791
                                                              SP_InhibitClassID_Reticle );
                                        return( RC_INHIBIT_ENTITY );
                                    }
                                }
                                else if ( saveRC == RC_EQP_PROCDRBL_FIXT_REQD )
                                {
                                    PPT_METHODTRACE_V1("", "saveRC == RC_EQP_PROCDRBL_FIXT_REQD");
                                    /*---------------------------------*/
                                    /*   Get and Check Fixture State   */
                                    /*     - state                     */
                                    /*     - transferState             */
                                    /*---------------------------------*/
                                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");
                                    PPT_METHODTRACE_V1("", "/*   Get and Check Fixture State   */");
                                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");

                                    objFixture_state_Check_out strFixture_state_Check_out;
                                    rc = fixture_state_Check( strFixture_state_Check_out,
                                                              strObjCommonIn,
                                                              equipmentID,
                                                              strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartFixture );
                                    if ( rc != RC_OK )
                                    {
                                        PPT_METHODTRACE_V1("", "entitfixture_state_CheckyInhibit_CheckForEntities() rc != RC_OK");
                                        strLotVerifyForLoadingReqResult.strResult = strFixture_state_Check_out.strResult;
                                        return( rc );
                                    }
                                }
                            }
                        }
                    }
                    PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100077 end @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                }
                else
                {
//P3100077 end
//P7000118 add start
                    /*-------------------------------------------------*/
                    /*   Get Lot's LogicalRecipeID / MachineRecipeID   */
                    /*-------------------------------------------------*/
                    PPT_METHODTRACE_V1( "", "Get Lot's LogicalRecipeID / MachineRecipeID");

                    objLot_recipe_Get_out strLot_recipe_Get_out;
                    rc = lot_recipe_Get(strLot_recipe_Get_out, strObjCommonIn,
                                        equipmentID, strStartCassette.strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "", "lot_recipe_Get() != RC_OK");
                        strLotVerifyForLoadingReqResult.strResult = strLot_recipe_Get_out.strResult;
                        return( rc );
                    }

                    strStartCassette.strLotInCassette[j].strStartRecipe.logicalRecipeID = strLot_recipe_Get_out.logicalRecipeID;
                    strStartCassette.strLotInCassette[j].strStartRecipe.machineRecipeID = strLot_recipe_Get_out.machineRecipeID;
//P7000118 add end
                    /*--------------------------------------------------*/
                    /*   Check Process Durable Condition for OpeStart   */
                    /*    - At least one of reticle / fixture for each  */  //P3100077
                    /*      reticleGroup / fixtureGroup is in the       */  //P3100077
                    /*      equipment or not. Even if required reticle  */  //P3100077
                    /*      is in the equipment, its status must be     */  //P3100077
                    /*      _Available or _InUse.                       */  //P3100077
                    /*    - Found reticles must not be inhibited.       */  //P3100077
                    /*--------------------------------------------------*/
                    PPT_METHODTRACE_V1( "", "/*--------------------------------------------------*/");
                    PPT_METHODTRACE_V1( "", "/*   Check Process Durable Condition for OpeStart   */");
                    PPT_METHODTRACE_V1( "", "/*--------------------------------------------------*/");

                    objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                    rc = processDurable_CheckConditionForOpeStart(strProcessDurable_CheckConditionForOpeStart_out,
                                                                  strObjCommonIn,
                                                                  equipmentID,
//0.01                                                            strStartCassette.strLotInCassette[i].strStartRecipe.logicalRecipeID,
//0.01                                                            strStartCassette.strLotInCassette[i].strStartRecipe.machineRecipeID );
                                                                  strStartCassette.strLotInCassette[j].strStartRecipe.logicalRecipeID,   //0.01
//D4000048                                                        strStartCassette.strLotInCassette[j].strStartRecipe.machineRecipeID ); //0.01
                                                                  strStartCassette.strLotInCassette[j].strStartRecipe.machineRecipeID,   //D4000048
                                                                  strStartCassette.strLotInCassette[j].lotID );                          //D4000048

                    if ( rc == RC_OK )
                    {
                        //check OK
                        ;
                        PPT_METHODTRACE_V1( "", "check OK");
                    }
                    else if ( rc == RC_NOT_AVAILABLE_RETICLE || rc == RC_NOT_AVAILABLE_FIXTURE )
                    {
                        PPT_METHODTRACE_V1( "", "rc == RC_NOT_AVAILABLE_RETICLE || rc == RC_NOT_AVAILABLE_FIXTURE");
//0.01                  strStartCassette.strLotInCassette[i].operationStartFlag = FALSE;
                        strStartCassette.strLotInCassette[j].operationStartFlag = FALSE; //0.01
//D4000017 add start
                        verifyNGReasons[j] = strProcessDurable_CheckConditionForOpeStart_out.strResult.messageText;
                        PPT_METHODTRACE_V3( "", "verifyNGReasons[j]", j, verifyNGReasons[j]);
//D4000017 add end
                        PPT_METHODTRACE_V2( "", "Check Process Durable Condition for Loading after strStartCassette.strLotInCassette[j].operationStartFlag", "FALSE"); //PSN000104651
                    }
                    else
                    {
                        PPT_METHODTRACE_V1( "", "processDurable_CheckConditionForOpeStart() != RC_OK");
                        strLotVerifyForLoadingReqResult.strResult = strProcessDurable_CheckConditionForOpeStart_out.strResult;
                        return( rc );
                    }
                }        //P3100077
            }
            rc = RC_OK;
        }
        else if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
        {
            PPT_METHODTRACE_V1( "", "rc == RC_EQP_PROCDRBL_NOT_REQD");
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1( "", "equipment_processDurableRequiredFlag_Get() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult;
            return( rc );
        }
    }
//PSN000104651    PPT_METHODTRACE_V2( "", "Check Process Durable Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

//P9000022    /*----------------------------------------------------------------------*/
//P9000022    /*                                                                      */
//P9000022    /*   Confirmation for Uploaded Recipe Body and Eqp's Recipe Body        */
//P9000022    /*                                                                      */
//P9000022    /*   When the following conditions are all matched, recipe body         */
//P9000022    /*   confirmation request is sent to TCS.                               */
//P9000022    /*                                                                      */
//P9000022    /*   1. Equipment's onlineMode is Online                                */
//P9000022    /*   2. Equipment's recipe body manage flag is TRUE.                    */
//P9000022    /*   3. Machine recipe's recipe body confirm flag is TRUE.              */
//P9000022    /*                                                                      */
//P9000022    /*----------------------------------------------------------------------*/
//P9000022    PPT_METHODTRACE_V1( "", "Confirmation for Uploaded Recipe Body and Eqp's Recipe Body");
//P9000022
//P9000022    /*---------------------------------------------*/
//P9000022    /*   Get Machine Recipe List to be Confirmed   */
//P9000022    /*---------------------------------------------*/
//P9000022    PPT_METHODTRACE_V1( "", "Get Machine Recipe List to be Confirmed");
//P9000022    PPT_METHODTRACE_V2( "", "Get Machine Recipe List to be Confirmed befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));
//P9000022
//P9000022    pptStartCassetteSequence tmpStartCassetteSeq(1);
//P9000022    tmpStartCassetteSeq.length(1);
//P9000022    tmpStartCassetteSeq[0] = strStartCassette;
//P9000022
//P9000022    objMachineRecipe_GetListForConfirmation_out strMachineRecipe_GetListForConfirmation_out;
//P9000022    rc = machineRecipe_GetListForConfirmation(strMachineRecipe_GetListForConfirmation_out,
//P9000022                                              strObjCommonIn,
//P9000022                                              equipmentID, tmpStartCassetteSeq );
//P9000022    if ( rc != RC_OK )
//P9000022    {
//P9000022        PPT_METHODTRACE_V1( "", "machineRecipe_GetListForConfirmation() != RC_OK");
//P9000022        strLotVerifyForLoadingReqResult.strResult = strMachineRecipe_GetListForConfirmation_out.strResult;
//P9000022        return( rc );
//P9000022    }
//P9000022// sequence length of returned machineRecipeID
//P9000022    CORBA::Long nLen = strMachineRecipe_GetListForConfirmation_out.machineRecipeID.length();
//P9000022    PPT_METHODTRACE_V2( "", "nLen = ", nLen);
//P9000022    for ( i=0 ; i<nLen; i++ )
//P9000022    {
//P9000022        /*-------------------------------------------*/
//P9000022        /*   Send Recipe Body Confirmation Request   */
//P9000022        /*-------------------------------------------*/
//P9000022        PPT_METHODTRACE_V2( "", "Send Recipe Body Confirmation Request", i);
//P9000022
//P9000022        pptRecipeConfirmationReqResult strRecipeConfirmationReqResult;
//P9000022        rc = txRecipeConfirmationReq(strRecipeConfirmationReqResult, strObjCommonIn,
//P9000022                                     equipmentID, strMachineRecipe_GetListForConfirmation_out.machineRecipeID[i],
//P9000022                                     "", "", "", FALSE, "");
//P9000022        if ( rc != RC_OK )
//P9000022        {
//P9000022            PPT_METHODTRACE_V1( "", "txRecipeConfirmReq() != RC_OK");
//P9000022            strLotVerifyForLoadingReqResult.strResult = strRecipeConfirmationReqResult.strResult;
//P9000022            return( rc );
//P9000022        }
//P9000022    }
//P9000022    PPT_METHODTRACE_V2( "", "Get Machine Recipe List to be Confirmed after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

//P9000022 add start
    //-----------------------------------------------------------------------------------------
    //
    //
    //   Check confirmation request setting for Uploaded Recipe Body and Eqp's Recipe Body
    //
    //   Recipe Body Confirmation/DownLoad cannot be performed without StartLotsReserve.
    //
    //
    //-----------------------------------------------------------------------------------------
    //---------------------------------------------------
    // Get Machine Recipe List for Recipe Body Management
    //---------------------------------------------------
    PPT_METHODTRACE_V2( "", "Control Job exists ??? ", strCassette_controlJobID_Get_out.controlJobID.identifier);
    if ( 0 == CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier ) )
    {
        objMachineRecipe_GetListForRecipeBodyManagement_in  strMachineRecipe_GetListForRecipeBodyManagement_in;
        strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette.length(1);
        strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0] = strStartCassette;
        strMachineRecipe_GetListForRecipeBodyManagement_in.equipmentID         = equipmentID;

        CORBA::Long lotInCstLen = strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette.length();
        for(CORBA::Long lotInCstCnt = 0; lotInCstCnt < lotInCstLen; lotInCstCnt++)
        {
            if ( FALSE == strStartCassette.strLotInCassette[lotInCstCnt].operationStartFlag )
            {
                PPT_METHODTRACE_V1( "", "FALSE == strStartCassette.strLotInCassette[lotInCstCnt].operationStartFlag ");
                continue;
            }

            //----------------------------------------------------------------------------
            //   Get Lot's LogicalRecipeID / MachineRecipeID from standard definition.
            //----------------------------------------------------------------------------
            PPT_METHODTRACE_V2( "", "Get Lot's LogicalRecipeID / MachineRecipeID from standard definition.", strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette[lotInCstCnt].lotID.identifier);
            objLot_recipe_Get_out strLot_recipe_Get_out;
            rc = lot_recipe_Get(strLot_recipe_Get_out, strObjCommonIn, equipmentID, strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette[lotInCstCnt].lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "lot_recipe_Get() != RC_OK");
                strLotVerifyForLoadingReqResult.strResult = strLot_recipe_Get_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V3( "", "Get Lot's LogicalRecipeID / MachineRecipeID", strLot_recipe_Get_out.logicalRecipeID.identifier, strLot_recipe_Get_out.machineRecipeID.identifier);
            strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette[lotInCstCnt].strStartRecipe.logicalRecipeID = strLot_recipe_Get_out.logicalRecipeID;
            strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette[lotInCstCnt].strStartRecipe.machineRecipeID = strLot_recipe_Get_out.machineRecipeID;
        }

        PPT_METHODTRACE_V1( "", "Get Machine Recipe List for Recipe Body Mangement." );
        objMachineRecipe_GetListForRecipeBodyManagement_out strMachineRecipe_GetListForRecipeBodyManagement_out;
        rc = machineRecipe_GetListForRecipeBodyManagement( strMachineRecipe_GetListForRecipeBodyManagement_out, strObjCommonIn, strMachineRecipe_GetListForRecipeBodyManagement_in);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1( "", "machineRecipe_GetListForRecipeBodyManagement() != RC_OK" );
            strLotVerifyForLoadingReqResult.strResult = strMachineRecipe_GetListForRecipeBodyManagement_out.strResult;
            return( rc );
        }

        CORBA::Long targetRecipeLen = strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq.length();
        PPT_METHODTRACE_V2( "", "Recipe for Recipe Body Management ...", targetRecipeLen );
        // Check
        if( 0 == targetRecipeLen )
        {
            //ok. no action.
            PPT_METHODTRACE_V1( "", "Recipe for Recipe Body Management does not exist. And controljob does not exist. OK." );
        }
        else if( 0 != targetRecipeLen )
        {
            PPT_METHODTRACE_V1( "", "Bypass Cannot perform Recipe Confirmation/Download without Lot Reservation. " ); //INN-A170001
            //error.
//INN-A170001            PPT_METHODTRACE_V1( "", "Cannot perform Recipe Confirmation/Download without Lot Reservation. Please retry after Lot Reservation." );
//INN-A170001            SET_MSG_RC( strLotVerifyForLoadingReqResult, MSG_CANNOT_LOAD_WITHOUT_CJ, RC_CANNOT_LOAD_WITHOUT_CJ );
//INN-A170001            return ( RC_CANNOT_LOAD_WITHOUT_CJ );
        }
    }
//P9000022 add end

    //P4200126 Add Start
    //-----------------------------------------------------------------
    // Load Purpose Type is Other Case:
    //   Execute Cassette Category and Port Category Combination Check.
    //-----------------------------------------------------------------
    if(CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_Other) == 0)
    {
        PPT_METHODTRACE_V1("","Load Purpose Type is OTHER case, Checking Category");
        objectIdentifier dummy;
        objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
        rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                                strObjCommonIn,
                                                                dummy,
                                                                cassetteID,
                                                                equipmentID,
                                                                portID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "loadPurposeType is Other Case: lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
            return( rc );
        }

    }
    //P4200126 Add End

//D4000016 Add Start
    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Category for Copper/Non Copper                                    */
    /*                                                                           */
    /*   It is checked in the following method whether it is the condition       */
    /*   that Lot of the object is made of OpeStart.                             */
    /*                                                                           */
    /*   1. It is checked whether CassetteCategory of RequiredCassetteCategory   */
    /*      of PosLot and PosCassette is the same.                               */
    /*                                                                           */
    /*   2. It is checked whether CassetteCategoryCapability of CassetteCategory */
    /*      of PosCassette and PosPortResource is the same.                      */
    /*                                                                           */
    /*   3. It is proper condition if CassetteCategoryCapability is the same     */
    /*      as RequiredCassetteCategory and CassetteCategory.                    */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    CORBA::Long ii;
    CORBA::Long nLotInCastLen = strStartCassette.strLotInCassette.length();

    for ( ii = 0; ii < nLotInCastLen; ii++ )
    {

//D4000046 add start 2001/09/06
        if(strStartCassette.strLotInCassette[ii].operationStartFlag == FALSE )
        {
            continue ;
        }
//D4000046 add end 2001/09/06

        objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
        rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                                strObjCommonIn,
                                                                strStartCassette.strLotInCassette[ii].lotID,
                                                                strStartCassette.cassetteID,
                                                                equipmentID,
                                                                strStartCassette.loadPortID);
//D4000046 add start 2001/08/23


        if ( rc == RC_OK )
        {
//D4000138            strStartCassette.strLotInCassette[ii].operationStartFlag = TRUE;
            PPT_METHODTRACE_V2( "", "lot_CassetteCategory_CheckForContaminationControl", "operationStartFlag = TRUE!"); //D4000138
        }
        else if ( rc == RC_INVALID_CATEGORY_CHECK )
        {
            strStartCassette.strLotInCassette[ii].operationStartFlag = FALSE;

            verifyNGReasons[ii] = strLot_CassetteCategory_CheckForContaminationControl_out.strResult.messageText;
            PPT_METHODTRACE_V3( "", "verifyNGReasons[ii]", ii, verifyNGReasons[ii]);

        }
        else
        {
            PPT_METHODTRACE_V1( "CS_PPTManager_i:: txLotVerifyForLoadingReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
            strLotVerifyForLoadingReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
            return( rc );
        }

//D4000046 add end 2001/08/23

//D4000046 remove        if ( rc != RC_OK )
//D4000046 remove        {
//D4000046 remove            PPT_METHODTRACE_V1( "CS_PPTManager_i:: txLotVerifyForLoadingReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
//D4000046 remove            strLotVerifyForLoadingReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
//D4000046 remove            return( rc );
//D4000046 remove        }

    }

//D4000016 Add End
//DSIV00001830 add start
    //-----------------------------------------------------------//
    //  Wafer Stacking Operation                                 //
    //    If Equipment Category is SP_Mc_Category_WaferBonding,  //
    //    check Bonding Group Condition for Loading              //
    //-----------------------------------------------------------//
    if (CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_ProcessLot) == 0 ||
        CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_ProcessMonitorLot) == 0 )
    {
        PPT_METHODTRACE_V1( "", "Check Bonding Group Condition for Loading");
        objLot_bondingGroup_UpdateByOperation_out strLot_bondingGroup_UpdateByOperation_out;
        objLot_bondingGroup_UpdateByOperation_in strLot_bondingGroup_UpdateByOperation_in;
        strLot_bondingGroup_UpdateByOperation_in.equipmentID = equipmentID;
        strLot_bondingGroup_UpdateByOperation_in.controlJobID = strCassette_controlJobID_Get_out.controlJobID;
        pptStartCassetteSequence strStartCassetteSeq;
        strStartCassetteSeq.length(1);
        strStartCassetteSeq[0] = strStartCassette;
        strLot_bondingGroup_UpdateByOperation_in.strStartCassette = strStartCassetteSeq;
        strLot_bondingGroup_UpdateByOperation_in.operation = CIMFWStrDup( SP_Operation_LoadingLot );

        PPT_METHODTRACE_V1("", "call lot_bondingGroup_UpdateByOperation()");
        rc = lot_bondingGroup_UpdateByOperation( strLot_bondingGroup_UpdateByOperation_out, strObjCommonIn, strLot_bondingGroup_UpdateByOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "lot_bondingGroup_UpdateByOperation() != RC_OK", rc );
            strLotVerifyForLoadingReqResult.strResult = strLot_bondingGroup_UpdateByOperation_out.strResult;
            return (rc);
        }
    }
//DSIV00001830 add end

    /*--------------------------*/
    /*                          */
    /*   Set Return Structure   */
    /*                          */
    /*--------------------------*/
    CORBA::Long startLotCount   = 0;  //P3000051
    CORBA::Long monitorLotCount = 0;  //P3000104

//  strLotVerifyForLoadingReqResult.strLoadingVerifiedLot(lotLen);
    strLotVerifyForLoadingReqResult.strLoadingVerifiedLot.length(lotLen);
    PPT_METHODTRACE_V2( "", "lotLen = ", lotLen);
    for ( i=0 ; i<lotLen ; i++ )
    {
        strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].operationStartFlag = strStartCassette.strLotInCassette[i].operationStartFlag;
        strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].monitorLotFlag     = strStartCassette.strLotInCassette[i].monitorLotFlag;
        strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].lotID              = strStartCassette.strLotInCassette[i].lotID;
//D4000017 add start
        strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].verifyNGReason     = verifyNGReasons[i];
        PPT_METHODTRACE_V3( "", "# operationStartFlag ", i, (int)strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].operationStartFlag);
        PPT_METHODTRACE_V3( "", "# lotID              ", i, strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].lotID.identifier);
        PPT_METHODTRACE_V3( "", "# verifyNGReason     ", i, strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].verifyNGReason);
//D4000017 add end

        //P3000051 add start
        CORBA::Boolean operationStartFlag;
        operationStartFlag = strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].operationStartFlag;
        if (operationStartFlag == TRUE)
        {
            PPT_METHODTRACE_V1( "", "strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].operationStartFlag == TRUE");
            startLotCount++;
            if ( strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].monitorLotFlag == TRUE )                       //Q3000104
            {                                                                                                            //Q3000104
                PPT_METHODTRACE_V1( "",
                                    "strLotVerifyForLoadingReqResult.strLoadingVerifiedLot[i].monitorLotFlag == TRUE");  //Q3000104
                monitorLotCount++;                                                                                       //Q3000104
            }                                                                                                            //Q3000104
        }
        //P3000051 add end
    }

    //P3000051 add start
    /*-----------------------------------------------------------*/
    /*                                                           */
    /*   Final Check for Start Lot Count and Monitor Lot Count   */ //Q3000104
    /*                                                           */
    /*-----------------------------------------------------------*/
    if (CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_ProcessLot) == 0 ||
        CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_ProcessMonitorLot) == 0 )
    {
        PPT_METHODTRACE_V1( "", "in-parm's loadPurposeType == (SP_LoadPurposeType_ProcessLot,SP_LoadPurposeType_ProcessProcessMonitorLot)");

        //--D4000148 start
        if( 0 == CIMFWStrLen( strCassette_controlJobID_Get_out.controlJobID.identifier) )    //D7000042
        {                                                                                    //D7000042
            pptStartCassetteSequence strStartCassetteSeq;
            strStartCassetteSeq.length(1);
            strStartCassetteSeq[0] = strStartCassette;

            objLot_recipeCombination_CheckForLoading_out  strLot_recipeCombination_CheckForLoading_out;
            rc = lot_recipeCombination_CheckForLoading(
                                               strLot_recipeCombination_CheckForLoading_out,
                                               strObjCommonIn,
                                               equipmentID,
                                               strStartCassetteSeq,
                                               loadPurposeType) ;
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotVerifyForLoadingReq", "lot_recipeCombination_CheckForLoading() != RC_OK") ;
                strLotVerifyForLoadingReqResult.strResult = strLot_recipeCombination_CheckForLoading_out.strResult ;
                return rc ;
            }
        }    //D7000042
        //--D4000148 end

        if ( startLotCount == 0 )
        {
            PPT_METHODTRACE_V1( "", "startLotCount == 0");
            SET_MSG_RC(strLotVerifyForLoadingReqResult,MSG_NOT_CANDIDATE_LOT_FOR_OPE_START,RC_NOT_CANDIDATE_LOT_FOR_OPE_START);
            return(RC_NOT_CANDIDATE_LOT_FOR_OPE_START);
        }
        if ( monitorLotCount > 1 )                                                                                   //Q3000104
        {                                                                                                            //Q3000104
            PPT_METHODTRACE_V1( "", "monitorLotCount > 0");                   //Q3000104
            SET_MSG_RC(strLotVerifyForLoadingReqResult,MSG_INVALID_PROCMONITOR_COUNT,RC_INVALID_PROCMONITOR_COUNT);  //Q3000104
            return(RC_INVALID_PROCMONITOR_COUNT);                                                                    //Q3000104
        }                                                                                                            //Q3000104

        //P4200534 add start
        //-----------------------------------------------------------//
        //                                                           //
        //   Final Check for LoadPurposeType:ProcessMonitorLot       //
        //                                                           //
        //   The lot, which meets fhe following conditions must be   //
        //   exist, and its lot count must be 1.                     //
        //      - OpeStartFlag   : TRUE                              //
        //      - LotType        : ProcessMonitor                    //
        //      - MonitorLotFlag : TRUE                              //
        //                                                           //
        //-----------------------------------------------------------//
        PPT_METHODTRACE_V3("", "strStartCassette Info", strStartCassette.cassetteID.identifier,
                            strStartCassette.loadPurposeType );

        if (CIMFWStrCmp( strStartCassette.loadPurposeType,
                         SP_LoadPurposeType_ProcessMonitorLot ) ==0 )
        {
            PPT_METHODTRACE_V1( "", "loadPurposeType is ProcessMonitorLot" )

            if ( monitorLotCount != 1 )
            {
                PPT_METHODTRACE_V2( "", "nMonitorLotCnt != 1", monitorLotCount );
                SET_MSG_RC( strLotVerifyForLoadingReqResult, MSG_INVALID_PROCMONITOR_COUNT, RC_INVALID_PROCMONITOR_COUNT );
                return( RC_INVALID_PROCMONITOR_COUNT );
            }

            CORBA::Long    i_lot = 0;
            CORBA::Long    lotLen = strStartCassette.strLotInCassette.length();

            for ( i_lot = 0 ; i_lot < lotLen ; i_lot++ )
            {
                if (( strStartCassette.strLotInCassette[i_lot].monitorLotFlag     == TRUE )&&
                    ( strStartCassette.strLotInCassette[i_lot].operationStartFlag == TRUE ))
                {
                    PPT_METHODTRACE_V3( "", "LotID & LotType", strStartCassette.strLotInCassette[i_lot].lotID.identifier,
                                                               strStartCassette.strLotInCassette[i_lot].lotType );

                    if ( CIMFWStrCmp(strStartCassette.strLotInCassette[i_lot].lotType,
                                     SP_Lot_Type_ProductionMonitorLot ) != 0 )
                    {
//D5100053 Add Start
                        objLot_monitorRouteFlag_Get_out strLot_monitorRouteFlag_Get_out;
                        rc = lot_monitorRouteFlag_Get(strLot_monitorRouteFlag_Get_out,
                                                      strObjCommonIn,
                                                      strStartCassette.strLotInCassette[i_lot].lotID);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1( "","lot_monitorRouteFlag_Get() != RC_OK");
                            strLotVerifyForLoadingReqResult.strResult = strLot_monitorRouteFlag_Get_out.strResult;
                            return ( rc );
                        }

                        PPT_METHODTRACE_V2( "", "monitorRoute_Flag =", strLot_monitorRouteFlag_Get_out.monitorRoute_Flag );

                        if ( strLot_monitorRouteFlag_Get_out.monitorRoute_Flag == FALSE )
                        {
                            PPT_METHODTRACE_V1( "", "Specified Lot Type is not ProductionMonitorLot" );
                            PPT_SET_MSG_RC_KEY2( strLotVerifyForLoadingReqResult, MSG_INVALID_LOT_TYPE, RC_INVALID_LOT_TYPE,
                                                 strStartCassette.strLotInCassette[i_lot].lotType,
                                                 strStartCassette.strLotInCassette[i_lot].lotID.identifier );
                            return( RC_INVALID_LOT_TYPE );
                        }
//D5100053 Add End
//D5100053                        PPT_METHODTRACE_V1( "", "Specified Lot Type is not ProductionMonitorLot" );
//D5100053                        PPT_SET_MSG_RC_KEY2( strLotVerifyForLoadingReqResult, MSG_INVALID_LOT_TYPE, RC_INVALID_LOT_TYPE,
//D5100053                                             strStartCassette.strLotInCassette[i_lot].lotType,
//D5100053                                             strStartCassette.strLotInCassette[i_lot].lotID.identifier );
//D5100053                        return( RC_INVALID_LOT_TYPE );
                    }

                    break;

                }
            }
        }
        //P4200534 add end
    }
    //P3000051 add end

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/
    SET_MSG_RC(strLotVerifyForLoadingReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txLotVerifyForLoadingReq");
    return ( RC_OK );
}
