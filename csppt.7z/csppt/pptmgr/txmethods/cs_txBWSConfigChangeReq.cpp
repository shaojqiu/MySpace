// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
//
// SiView
// Name: cs_txBWSConfigChangeReq.cpp
//
// Modeficaiton History:
// Date       Defect        Name          Description
// ---------- ------------- ------------- ----------------------------------------------
// 2017/10/20 INN-R170017   ChengLi      BWS Config Change Request
//
// Class: PPTServiceManager
//
// Service: cs_txBWSConfigChangeReq()
//
// Description:
//<Method Summary>
//
//</Method Summary>
//
// Return:
//     long
//
// Parameter:
//
//     csBWSConfigChangeReqResult&              strBWSConfigChangeReqResult,
//     const pptObjCommonIn&                    strObjCommonIn,
//     const csBWSConfigChangeReqInParm&        strBWSConfigChangeReqInParm
//     const char *                             claimMemo
//
#include "cs_pptmgr.hpp"
CORBA::Long CS_PPTManager_i::cs_txBWSConfigChangeReq(
        csBWSConfigChangeReqResult&         strBWSConfigChangeReqResult,
        const pptObjCommonIn&               strObjCommonIn,
        const csBWSConfigChangeReqInParm&   strBWSConfigChangeReqInParm,
        const char *                        claimMemo
        CORBAENV_LAST_CPP)
{

    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txBWSConfigChangeReq")
    CORBA::Long rc = RC_OK ;

    CORBA::Long nLenBWS = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq.length();

    //--------------------------------------------------------------------
    // Add BWS Config
    //--------------------------------------------------------------------
    if (0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.actionType, CS_BWS_ConfigAction_Add))
    {
        PPT_METHODTRACE_V1("", "Begin to Add BWS Config");
        
        //----------------------------------------
        // Check Incoming Paramter Capacity
        //----------------------------------------
        for (CORBA::Long i = 0; i < nLenBWS; i++)
        {
            csObjBWS_Config_GetDR_out strBWS_Config_GetDR_out;
            csObjBWS_Config_GetDR_in strBWS_Config_GetDR_in;
            strBWS_Config_GetDR_in.BWSID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].BWSID;
        
            rc = cs_BWS_Config_GetDR(strBWS_Config_GetDR_out,
                                     strObjCommonIn,
                                     strBWS_Config_GetDR_in);
        
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","cs_BWS_Config_GetDR != RC_OK", rc );
                strBWSConfigChangeReqResult.strResult = strBWS_Config_GetDR_out.strResult;
                return rc;
            }
    
            CORBA::Long nLenBWSInDB = strBWS_Config_GetDR_out.strBWSConfigInfoSeq.length();
            if(nLenBWSInDB == 1)
            {
                CORBA::Long nLenBWSZoneInDB = strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq.length();
                CORBA::Long nLenBWSZonePara = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq.length();
                
                //for(CORBA::Long a = 0; a < nLenBWSZoneInDB; a++)
                //{     
                //    for(CORBA::Long b = 0; b < nLenBWSZonePara; b++)
                //    {
                //        if(0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[b].zoneID,
                //                            strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[a].zoneID))
                //            {
                //                strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[a] 
                //                = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[b];
                //                break;
                //            }
                //    }
                //}
                
                CORBA::Long totalLenBWSZone = nLenBWSZoneInDB + nLenBWSZonePara;
                strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq.length(totalLenBWSZone);
                CORBA::Long a = nLenBWSZoneInDB;
                for(CORBA::Long b = 0; b < nLenBWSZonePara; b++)
                {
                    strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[a] 
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[b];
                    a++;
                }
                
                CORBA::Long bwsZoneCapacityTotal = 0;
                for (CORBA::Long j = 0; j < totalLenBWSZone; j++) 
                {
                    bwsZoneCapacityTotal = bwsZoneCapacityTotal
                                           +
                                           strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[j].maxCapacity;
                                           
                    if(strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[j].maxCapacity 
                       > strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].maxCapacity)
                    {
                        CS_PPT_SET_MSG_RC_KEY3(strBWSConfigChangeReqResult,
                               CS_MSG_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                               CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                               ConvertLongtoString(strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[j].maxCapacity),
                               ConvertLongtoString(strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].maxCapacity),
                               strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].BWSID.identifier);
                        return (CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY);
                    }
                }
                
                PPT_METHODTRACE_V4("", "Check BWS Capaciy to its Zones total Capacity",
                                       strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].BWSID.identifier,
                                       strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].maxCapacity,
                                       bwsZoneCapacityTotal);
                
                if (strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].maxCapacity < bwsZoneCapacityTotal) {
                    PPT_METHODTRACE_V2("",
                                       "BWS Max Capacity is not big than total Zone Capacity",
                                       CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
                
                    CS_PPT_SET_MSG_RC_KEY1(strBWSConfigChangeReqResult,
                               CS_MSG_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                               CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                               strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].BWSID.identifier);
                    return (CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
                }
                
            }
            else
            {
                CORBA::Long nLenBWSZone = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq.length();
                CORBA::Long bwsZoneCapacityTotal = 0;
                for (CORBA::Long j = 0; j < nLenBWSZone; j++) 
                {
                    bwsZoneCapacityTotal = bwsZoneCapacityTotal
                                           +
                                           strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].maxCapacity;
                                           
                    if(strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].maxCapacity 
                       > strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].maxCapacity)
                    {
                        CS_PPT_SET_MSG_RC_KEY3(strBWSConfigChangeReqResult,
                               CS_MSG_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                               CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                               ConvertLongtoString(strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].maxCapacity),
                               ConvertLongtoString(strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].maxCapacity),
                               strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].BWSID.identifier);
                        return (CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY);
                    }
                }
                
                PPT_METHODTRACE_V4("", "Check BWS Capaciy to its Zones total Capacity",
                                       strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].BWSID.identifier,
                                       strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].maxCapacity,
                                       bwsZoneCapacityTotal);
                
                if (strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].maxCapacity < bwsZoneCapacityTotal) 
                {
                    PPT_METHODTRACE_V2("",
                                       "BWS Max Capacity is not big than total Zone Capacity",
                                       CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
                
                    CS_PPT_SET_MSG_RC_KEY1(strBWSConfigChangeReqResult,
                               CS_MSG_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                               CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                               strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].BWSID.identifier);
                    return (CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
                }
            }
        }
        PPT_METHODTRACE_V1("", "Check BWS Config Capacity Done");

        //----------------------------------
        // Check EQPID whether BWS
        //----------------------------------
        pptEqpListInqResult__100 strEqpListInqResult;
        pptEqpListInqInParm__160  strEqpListInqInParm;
        strEqpListInqInParm.equipmentCategory = CORBA::string_dup(SP_Mc_Category_WaferSorter);
	    strEqpListInqInParm.specialControl = CORBA::string_dup(CS_EQP_SpecialEquipmentControl_BareWaferStocker);
        
        rc = txEqpListInq__160(strEqpListInqResult, 
                               strObjCommonIn, 
                               strEqpListInqInParm );
        if (rc != RC_OK) 
        {
                PPT_METHODTRACE_V2("", "txEqpListInq__160 != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strEqpListInqResult.strResult;
                return rc;
        }
        CORBA::Long eqpLen = strEqpListInqResult.strAreaEqp.length();
        for (CORBA::Long m = 0; m < nLenBWS; m++)
        {
            CORBA::Boolean matchBWS = FALSE;
            for (CORBA::Long n = 0; n < eqpLen; n++)
            {
                if(0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[m].BWSID.identifier,
                                    strEqpListInqResult.strAreaEqp[n].equipmentID.identifier))
                {
                    matchBWS = TRUE;
                    break;
                }
            }
            if(TRUE != matchBWS )
            {
                PPT_METHODTRACE_V2("", "EQP should define as BWS", 
                                   strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[m].BWSID.identifier);
                SET_MSG_RC(strBWSConfigChangeReqResult,
                       MSG_INVALID_INPUT_PARM,
                       RC_INVALID_INPUT_PARM);

                return (RC_INVALID_INPUT_PARM);
            }
        }
        PPT_METHODTRACE_V1("", "Check BWS Config BWSID Done");
        
        //--------------------------------
        // Check EQP online mode 
        //--------------------------------
        
        for (CORBA::Long x = 0; x < nLenBWS; x++)
        {
            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            objectIdentifier equipmentID;
            equipmentID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[x].BWSID;
            rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out,
                                        strObjCommonIn,
                                        equipmentID);
            if (rc != RC_OK) 
            {
                PPT_METHODTRACE_V2("", "equipment_portInfo_Get != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return rc;
            }
            CORBA::Long eqpPortStatusLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            for(CORBA::Long y = 0; y < nLenBWS; y++)
            {
                if(0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[y].onlineMode,
                                    SP_Eqp_OnlineMode_Offline))
                {
                    PPT_METHODTRACE_V3("", "EPQ online mode should be offline.", 
                                     strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[x].BWSID.identifier,
                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[y].onlineMode);
                    PPT_SET_MSG_RC_KEY2(strBWSConfigChangeReqResult,
                                    MSG_EQP_ONLINE_MODE,
                                    RC_EQP_ONLINE_MODE,
                                    strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[x].BWSID.identifier,
                                    strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[y].onlineMode);
                    return (RC_EQP_ONLINE_MODE);
                }
            }
        }
        PPT_METHODTRACE_V1("", "Check EQP online mode Done");
        
        //------------------------------------------
        // Call Add BWS Config obj method
        //------------------------------------------
        for (CORBA::Long ix = 0; ix < nLenBWS; ix++)
        {

            csObjBWS_Config_AddDR_out strBWS_Config_AddDR_out;
            csObjBWS_Config_AddDR_in strBWS_Config_AddDR_in;

            strBWS_Config_AddDR_in.strBWSConfigInfo.BWSID
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID;
            strBWS_Config_AddDR_in.strBWSConfigInfo.maxCapacity
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].maxCapacity;
            strBWS_Config_AddDR_in.strBWSConfigInfo.strZoneConfigInfoSeq
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq;

            rc = cs_BWS_Config_AddDR(strBWS_Config_AddDR_out,
                                     strObjCommonIn,
                                     strBWS_Config_AddDR_in,"");

            if (rc != RC_OK) 
            {
                PPT_METHODTRACE_V2("", "cs_BWS_Config_AddDR != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strBWS_Config_AddDR_out.strResult;
                return rc;
            }
        }
        SET_MSG_RC(strBWSConfigChangeReqResult, MSG_OK, RC_OK);
    }

    //--------------------------------------------------------------------
    // Update BWS Config
    //--------------------------------------------------------------------
    else if (0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.actionType, CS_BWS_ConfigAction_Update))
    {
        PPT_METHODTRACE_V1("", "Begin to Update BWS Config");
        
        //-------------------------------------------------
        // Check Incoming Paramter Capacity and waferCount
        //-------------------------------------------------
        for (CORBA::Long i = 0; i < nLenBWS; i++)
        {
            
            csBWSConfigInfoInqResult strBWSConfigInfoInqResult;
            csBWSConfigInfoInqInParm strBWSConfigInfoInqInParm;
            strBWSConfigInfoInqInParm.BWSID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].BWSID;
            
            rc = cs_txBWSConfigInfoInq(strBWSConfigInfoInqResult,
                                       strObjCommonIn,
                                       strBWSConfigInfoInqInParm);
            if (rc != RC_OK) 
            {
                PPT_METHODTRACE_V2("", "cs_txBWSConfigInfoInq != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strBWSConfigInfoInqResult.strResult;
                return rc;
            }
            
            CORBA::Long lenBWSInDB = strBWSConfigInfoInqResult.strBWSConfigInfoSeq.length();
            
            if(lenBWSInDB == 0)
            {
                PPT_METHODTRACE_V2("", "INVALID_INPUT_PARM!! None of this BWS In Data to update!",
                                        strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].BWSID.identifier);
                CS_PPT_SET_MSG_RC_KEY1(strBWSConfigChangeReqResult,
                              CS_MSG_BWS_CONFIG_NOT_FOUND_BWS,
                              CS_RC_BWS_CONFIG_NOT_FOUND_BWS,
                              strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].BWSID.identifier);
                return (CS_RC_BWS_CONFIG_NOT_FOUND_BWS);
            }
            
            CORBA::Long waferCountOfBWS =  strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].maxCapacity 
                                           - strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].availableCapacity;
                                           
            strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].maxCapacity 
                      = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].maxCapacity;
                 
            // Check updated bws max capacity whether bigger than bws wafer count
            if(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].maxCapacity < waferCountOfBWS)
            {
                PPT_METHODTRACE_V2("", "INVALID INPUT maxCapacity of BWS! It should bigger than waferCount of this BWS",
                                        strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].BWSID.identifier);
                CS_PPT_SET_MSG_RC_KEY1(strBWSConfigChangeReqResult,
                           CS_MSG_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                           CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                           strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].BWSID.identifier);
                return (CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
            }
             
            CORBA::Long lenBWSZoneInDB = strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq.length();
            CORBA::Long lenBWSZonePara = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq.length();
            for(CORBA::Long m = 0; m < lenBWSZoneInDB; m++)
            {
                for(CORBA::Long n = 0; n < lenBWSZonePara; n++)
                {
                    if(0 == CIMFWStrCmp(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[m].zoneID,
                                        strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[n].zoneID))
                    {
                        CORBA::Long waferCountOfZone = strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[m].maxCapacity 
                                                       - strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[m].availableCapacity;
                                             
                        strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[m]
                             = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[n];
                        
                        // Check updated zone max capacity whether bigger than zone wafer count                        
                        if(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[m].maxCapacity < waferCountOfZone)
                        {
                            PPT_METHODTRACE_V5("", "BWS Zone Capaciy should bigger than its wafer count",
                                   strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].BWSID.identifier,
                                   strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[m].zoneID,
                                   ConvertLongtoString(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[m].maxCapacity),
                                   ConvertLongtoString(waferCountOfZone));
                            CS_PPT_SET_MSG_RC_KEY3(strBWSConfigChangeReqResult,
                                    CS_MSG_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                                    CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                                    ConvertLongtoString(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[m].maxCapacity),
                                    ConvertLongtoString(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].maxCapacity),
                                    strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].BWSID.identifier);
                            return (CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY);
                        }
                        break;
                    }
                }
            }
            
            //CORBA::Long nLenBWSZone = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq.length();
            CORBA::Long bwsZoneCapacityTotal = 0;
            for (CORBA::Long j = 0; j < lenBWSZoneInDB; j++) 
            {
                bwsZoneCapacityTotal = bwsZoneCapacityTotal
                                       +
                                       strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[j].maxCapacity;
                                       
                if(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[j].maxCapacity 
                   > strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].maxCapacity)
                {
                    CS_PPT_SET_MSG_RC_KEY3(strBWSConfigChangeReqResult,
                           CS_MSG_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                           CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                           ConvertLongtoString(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].strZoneConfigInfoSeq[j].maxCapacity),
                           ConvertLongtoString(strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].maxCapacity),
                           strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].BWSID.identifier);
                    return (CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY);
                }
            }

            PPT_METHODTRACE_V4("", "Check BWS Capaciy to its Zones total Capacity",
                                   strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].BWSID.identifier,
                                   strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].maxCapacity,
                                   bwsZoneCapacityTotal);
            if (strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].maxCapacity < bwsZoneCapacityTotal) {
                PPT_METHODTRACE_V2("",
                                   "BWS Max Capacity is not big than total Zone Capacity",
                                   CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);

                CS_PPT_SET_MSG_RC_KEY1(strBWSConfigChangeReqResult,
                           CS_MSG_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                           CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                           strBWSConfigInfoInqResult.strBWSConfigInfoSeq[0].BWSID.identifier);
                return (CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
            }
        }
        PPT_METHODTRACE_V1("", "Check BWS Config Capacity Done");
        
        //-------------------------------------------------
        // Check BWS job. If in work, shall not be updated 
        //-------------------------------------------------
        for (CORBA::Long m = 0; m < nLenBWS; m++)
        {
            objectIdentifier BWSID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[m].BWSID;
            pptSortJobListInqResult strSortJobListInqResult;
            objectIdentifier dummy;
            rc = txSortJobListInq( strSortJobListInqResult,
                               strObjCommonIn,
                               BWSID,
                               dummy,
                               dummy,
                               dummy,
                               dummy );
            
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "txSortJobListInq() != RC_OK, rc=", rc )
                strBWSConfigChangeReqResult.strResult = strSortJobListInqResult.strResult;
                return(rc);
            }
            CORBA::Long sortJobListLength = strSortJobListInqResult.strSortJobListAttributesSequence.length();
            for (CORBA::Long n = 0; n < sortJobListLength; n++)
            {
                if(0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[m].BWSID.identifier,
                                    strSortJobListInqResult.strSortJobListAttributesSequence[n].equipmentID.identifier))
                {

                    PPT_METHODTRACE_V3( "", "BWS has SortJob, cannot be updated.", 
                                       strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[m].BWSID.identifier,
                                       strSortJobListInqResult.strSortJobListAttributesSequence[n].sorterJobID.identifier)
                    CS_SET_MSG_RC(strBWSConfigChangeReqResult,
                                  CS_MSG_BWS_CONFIG_NOT_ALLOWED_UPDATE_ZONE,
                                  CS_RC_BWS_CONFIG_NOT_ALLOWED_UPDATE_ZONE);
                    return (CS_RC_BWS_CONFIG_NOT_ALLOWED_UPDATE_ZONE);

                }
            }
            
        }
        PPT_METHODTRACE_V1("", "Check BWS Config SortJob Done");
        
        //--------------------------------
        // Check EQP online mode 
        //--------------------------------
        for (CORBA::Long x = 0; x < nLenBWS; x++)
        {
            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            objectIdentifier equipmentID;
            equipmentID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[x].BWSID;
            rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out,
                                        strObjCommonIn,
                                        equipmentID);
            if (rc != RC_OK) 
            {
                PPT_METHODTRACE_V2("", "equipment_portInfo_Get != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return rc;
            }
            CORBA::Long eqpPortStatusLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            for(CORBA::Long y = 0; y < nLenBWS; y++)
            {
                if(0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[y].onlineMode,
                                    SP_Eqp_OnlineMode_Offline))
                {
                    PPT_METHODTRACE_V3("", "EPQ online mode should be offline.", 
                                     strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[x].BWSID.identifier,
                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[y].onlineMode);
                    PPT_SET_MSG_RC_KEY2(strBWSConfigChangeReqResult,
                                    MSG_EQP_ONLINE_MODE,
                                    RC_EQP_ONLINE_MODE,
                                    strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[x].BWSID.identifier,
                                    strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[y].onlineMode);
                    return (RC_EQP_ONLINE_MODE);
                }
            }
        }
        PPT_METHODTRACE_V1("", "Check EQP online mode Done");

        //------------------------------------------
        // Call Update BWS Config obj method
        //------------------------------------------
        for (CORBA::Long ix = 0; ix < nLenBWS; ix++)
        {

            csObjBWS_Config_UpdateDR_out strBWS_Config_UpdateDR_out;
            csObjBWS_Config_UpdateDR_in strBWS_Config_UpdateDR_in;

            strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID;
            strBWS_Config_UpdateDR_in.strBWSConfigInfo.maxCapacity
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].maxCapacity;
            strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq;

            rc = cs_BWS_Config_UpdateDR(strBWS_Config_UpdateDR_out,
                                        strObjCommonIn,
                                        strBWS_Config_UpdateDR_in,
                                        "");

            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "cs_BWS_Config_UpdateDR != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strBWS_Config_UpdateDR_out.strResult;
                return rc;
            }
        }
        SET_MSG_RC(strBWSConfigChangeReqResult, MSG_OK, RC_OK);
    }


    //--------------------------------------------------------------------
    // Delete BWS Config
    //--------------------------------------------------------------------
    else if (0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.actionType, CS_BWS_ConfigAction_Delete))
    {
        PPT_METHODTRACE_V1("", "Begin to Delete BWS Config");
        
        for (CORBA::Long ix = 0; ix < nLenBWS; ix++)
        {
            
            //--------------------------------
            // Check EQP online mode 
            //--------------------------------

            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            objectIdentifier equipmentID;
            equipmentID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID;
            rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out,
                                        strObjCommonIn,
                                        equipmentID);
            if (rc != RC_OK) 
            {
                PPT_METHODTRACE_V2("", "equipment_portInfo_Get != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return rc;
            }
            CORBA::Long eqpPortStatusLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            for(CORBA::Long iy = 0; iy < nLenBWS; iy++)
            {
                if(0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[iy].onlineMode,
                                    SP_Eqp_OnlineMode_Offline))
                {
                    PPT_METHODTRACE_V3("", "EPQ online mode should be offline.", 
                                     strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID.identifier,
                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[iy].onlineMode);
                    PPT_SET_MSG_RC_KEY2(strBWSConfigChangeReqResult,
                                    MSG_EQP_ONLINE_MODE,
                                    RC_EQP_ONLINE_MODE,
                                    strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID.identifier,
                                    strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[iy].onlineMode);
                    return (RC_EQP_ONLINE_MODE);
                }
            }
            PPT_METHODTRACE_V2("", "Check EQP online mode Done",
                               strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID.identifier);
            
            
            csObjBWS_Config_DeleteDR_out strBWS_Config_DeleteDR_out;
            csObjBWS_Config_DeleteDR_in strBWS_Config_DeleteDR_in;
            strBWS_Config_DeleteDR_in.BWSID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID;
        
            CORBA::Long bwsZonelen = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq.length();
        
            //------------------------------------------
            // Call Delete BWS Config obj method
            //------------------------------------------
            for(CORBA::Long jx = 0; jx < bwsZonelen; jx++)
            {
                
                //-----------------------------------------------------
                // Check Zone of BWS wafer count whether can be delete
                //-----------------------------------------------------
                PPT_METHODTRACE_V1("", "Check Zone of BWS wafer count whether it can be deleted");
                csObjBWS_WaferCount_GetDR_in strBWS_WaferCount_GetDR_in;
                csObjBWS_WaferCount_GetDR_out strBWS_WaferCount_GetDR_out;
                strBWS_WaferCount_GetDR_in.BWSID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID;
                strBWS_WaferCount_GetDR_in.zoneID 
                                = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq[jx].zoneID;
                
                rc = cs_BWS_WaferCount_GetDR(strBWS_WaferCount_GetDR_out,
                                        strObjCommonIn,
                                        strBWS_WaferCount_GetDR_in);
                if (rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "cs_BWS_WaferCount_GetDR != RC_OK", rc);
                    strBWSConfigChangeReqResult.strResult = strBWS_WaferCount_GetDR_out.strResult;
                    return rc;
                }
                else
                {
                    CORBA::Long waferCountLen 
                          = strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq.length();
                    if(waferCountLen > 0)
                    { 
                        for(CORBA::Long kx = 0; kx < waferCountLen; kx++)
                        {
                            if(0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq[jx].zoneID,
                                                strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq[kx].zoneID))
                            {
                                if(strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq[kx].waferCount > 0)
                                {
                                    PPT_METHODTRACE_V3("", "Some Wafer in the BWS",
                                                       strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID.identifier,
                                                       strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq[jx].zoneID);
                                    CS_PPT_SET_MSG_RC_KEY2(strBWSConfigChangeReqResult,
                                                           CS_MSG_BWS_CONFIG_NOT_ALLOWED_DELETE_ZONE,
                                                           CS_RC_BWS_CONFIG_NOT_ALLOWED_DELETE_ZONE,
                                                           strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq[jx].zoneID,
                                                           strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID.identifier);
                                    return (CS_RC_BWS_CONFIG_NOT_ALLOWED_DELETE_ZONE);
                                }
                                break;                                
                            }
                        }
                    }
                    PPT_METHODTRACE_V1("", "Check BWS Config Zone WaferCount done");
                }
                
                
                strBWS_Config_DeleteDR_in.zoneID
                        = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq[jx].zoneID;
        
                rc = cs_BWS_Config_DeleteDR(strBWS_Config_DeleteDR_out,
                                            strObjCommonIn,
                                            strBWS_Config_DeleteDR_in,
                                            "");
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "cs_BWS_Config_DeleteDR != RC_OK", rc);
                    strBWSConfigChangeReqResult.strResult = strBWS_Config_DeleteDR_out.strResult;
                    return rc;
                }
            }
            SET_MSG_RC(strBWSConfigChangeReqResult, MSG_OK, RC_OK);
        }
    }
    else
    {
            PPT_METHODTRACE_V1("", "INVALID_INPUT_PARM!! Action_Type is not one of the Add, Update and Delete!");
            SET_MSG_RC(strBWSConfigChangeReqResult,
                       MSG_INVALID_INPUT_PARM,
                       RC_INVALID_INPUT_PARM);

            return (RC_INVALID_INPUT_PARM);
    }

    return rc;
}
