//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txDurablesInfoForStartReservationForInternalBufferInq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txDurablesInfoForStartReservationForInternalBufferInq
(
    csDurablesInfoForStartReservationForInternalBufferInqResult&        strDurablesInfoForStartReservationForInternalBufferInqResult,
    const pptObjCommonIn&                                               strObjCommonIn,
    const csDurablesInfoForStartReservationForInternalBufferInqInParam& strDurablesInfoForStartReservationForInternalBufferInqInParam
    CORBAENV_LAST_CPP
)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txDurablesInfoForStartReservationForInternalBufferInq");

    /*--------------------------------------------*/
    /*                                            */
    /*      Pre Process                           */
    /*                                            */
    /*--------------------------------------------*/
    CORBA::Long rc = RC_OK;

    const csDurablesInfoForStartReservationForInternalBufferInqInParam& strInParm = strDurablesInfoForStartReservationForInternalBufferInqInParam;

    /*--------------------------------------------*/
    /*                                            */
    /*      In-Parameter Trace                    */
    /*                                            */
    /*--------------------------------------------*/
    if( 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", strInParm.durableCategory);
        PPT_SET_MSG_RC_KEY( strDurablesInfoForStartReservationForInternalBufferInqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            strInParm.durableCategory );
        return RC_INVALID_DURABLE_CATEGORY;
    }

    // Check length of In-Parameter
    CORBA::ULong durableLen = strInParm.durableIDs.length();
    if(durableLen <= 0)
    {
        PPT_METHODTRACE_V1("", "durableLen <= 0");
        SET_MSG_RC(strDurablesInfoForStartReservationForInternalBufferInqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER);
        return RC_INVALID_PARAMETER;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Tx ID Check                           */
    /*                                            */
    /*--------------------------------------------*/
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_SpecialControlVsTxID_CheckCombination_out strEquipment_SpecialControlVsTxID_CheckCombination_out;
    objEquipment_SpecialControlVsTxID_CheckCombination_in  strEquipment_SpecialControlVsTxID_CheckCombination_in;
    strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID = strInParm.equipmentID;
    rc = equipment_SpecialControlVsTxID_CheckCombination(strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                                         strObjCommonIn,
                                                         strEquipment_SpecialControlVsTxID_CheckCombination_in);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "equipment_SpecialControlVsTxID_CheckCombination() returned error.");
        strDurablesInfoForStartReservationForInternalBufferInqResult.strResult = strEquipment_SpecialControlVsTxID_CheckCombination_out.strResult;
        return rc;
    }

    /*-----------------------------------------------------*/
    /*                                                     */
    /*      Get Information for Start Reservation          */
    /*                                                     */
    /*-----------------------------------------------------*/
    objProcess_startDurablesReserveInformation_GetBaseInfoForClient_out strProcess_startDurablesReserveInformation_GetBaseInfoForClient_out;
    objProcess_startDurablesReserveInformation_GetBaseInfoForClient_in  strProcess_startDurablesReserveInformation_GetBaseInfoForClient_in;
    strProcess_startDurablesReserveInformation_GetBaseInfoForClient_in.equipmentID     = strInParm.equipmentID;
    strProcess_startDurablesReserveInformation_GetBaseInfoForClient_in.durableCategory = strInParm.durableCategory;
    strProcess_startDurablesReserveInformation_GetBaseInfoForClient_in.durables        = strInParm.durableIDs;
    rc = process_startDurablesReserveInformation_GetBaseInfoForClient(strProcess_startDurablesReserveInformation_GetBaseInfoForClient_out,
                                                                      strObjCommonIn,
                                                                      strProcess_startDurablesReserveInformation_GetBaseInfoForClient_in);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_startDurablesReserveInformation_GetBaseInfoForClient() != RC_OK");
        strDurablesInfoForStartReservationForInternalBufferInqResult.strResult = strProcess_startDurablesReserveInformation_GetBaseInfoForClient_out.strResult;
        return rc;
    }

    // Set to return structure
    strDurablesInfoForStartReservationForInternalBufferInqResult.equipmentID           = strProcess_startDurablesReserveInformation_GetBaseInfoForClient_out.equipmentID;
    strDurablesInfoForStartReservationForInternalBufferInqResult.durableCategory       = strProcess_startDurablesReserveInformation_GetBaseInfoForClient_out.durableCategory;
    strDurablesInfoForStartReservationForInternalBufferInqResult.strStartDurables      = strProcess_startDurablesReserveInformation_GetBaseInfoForClient_out.strStartDurables;
    strDurablesInfoForStartReservationForInternalBufferInqResult.strDurableStartRecipe = strProcess_startDurablesReserveInformation_GetBaseInfoForClient_out.strDurableStartRecipe;

    SET_MSG_RC(strDurablesInfoForStartReservationForInternalBufferInqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txDurablesInfoForStartReservationForInternalBufferInq");
    return RC_OK;
}
