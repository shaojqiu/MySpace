//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txEqpRMSFlgInq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txEqpRMSFlgInq()
//
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csEqpRMSFlgInqResult&          strEqpRMSFlgInqResult,
//      const pptObjCommonIn&              strObjCommonIn,
//      const objectIdentifier&            equipmentOwnerID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txEqpRMSFlgInq(
    csEqpRMSFlgInqResult&          strEqpRMSFlgInqResult,
    const pptObjCommonIn&          strObjCommonIn,
    const objectIdentifier&        equipmentID
    CORBAENV_LAST_CPP)        
{
    /*------------------------------------------------------------------------*/
    /*   Return Code Initialization                                           */
    /*------------------------------------------------------------------------*/

    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txEqpRMSFlgInq")
    CORBA::Long rc = RC_OK ;

    pptUserDataInqResult        strUserDataInqResult;
    pptUserDataInqInParm__101   strUserDataInqInParm;

    strUserDataInqInParm.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strUserDataInqInParm.userDataName       = CIMFWStrDup( CS_M_RMS_BODY_FLAG );
    strUserDataInqInParm.userDataOriginator = CIMFWStrDup( SP_USERDATA_ORIG_MM );
    strUserDataInqInParm.stringifiedObjectReference = equipmentID.stringifiedObjectReference;
    strUserDataInqInParm.strHashedInfoSeq.length(1);
    strUserDataInqInParm.strHashedInfoSeq[0].hashKey = CIMFWStrDup( SP_HashData_EQP_ID );
    strUserDataInqInParm.strHashedInfoSeq[0].hashData = equipmentID.identifier;
    PPT_METHODTRACE_V2("", "strUserDataInqInParm.hashKey  is ",strUserDataInqInParm.strHashedInfoSeq[0].hashKey);
    PPT_METHODTRACE_V2("", "strUserDataInqInParm.hashData is ",strUserDataInqInParm.strHashedInfoSeq[0].hashData);
    
    rc = txUserDataInq__101 ( strUserDataInqResult, strObjCommonIn, strUserDataInqInParm, NULL );
    if ( rc != RC_OK && rc != RC_NOT_FOUND_UDATA )
    {
        PPT_METHODTRACE_V2("", "txUserDataInq__101() rc != RC_OK",rc ) ;
        strEqpRMSFlgInqResult.strResult = strUserDataInqResult.strResult ;
        return( rc );
    }
    
    if( strUserDataInqResult.strUserDataSeq.length() > 0 &&
        CIMFWStrCmp(strUserDataInqResult.strUserDataSeq[0].value, "1" ) == 0 )
    {
        strEqpRMSFlgInqResult.theRMSBodyFlag = TRUE;
    }
    else
    {
        strEqpRMSFlgInqResult.theRMSBodyFlag = FALSE;
    }
    PPT_METHODTRACE_V2("", "Set strEqpRMSFlgInqResult.theRMSBodyFlag",((strEqpRMSFlgInqResult.theRMSBodyFlag==TRUE)?1:0) );

    pptUserDataInqResult        strUserDataInqResultForConst;
    strUserDataInqInParm.userDataName       = CIMFWStrDup( CS_M_RMS_CONST_FLAG );
    rc = txUserDataInq__101 ( strUserDataInqResultForConst, strObjCommonIn, strUserDataInqInParm, NULL );
    if ( rc != RC_OK && rc != RC_NOT_FOUND_UDATA )
    {
        PPT_METHODTRACE_V2("", "txUserDataInq__101() rc != RC_OK",rc ) ;
        strEqpRMSFlgInqResult.strResult = strUserDataInqResultForConst.strResult ;
        return( rc );
    }
    
    if( strUserDataInqResultForConst.strUserDataSeq.length() > 0 &&
        CIMFWStrCmp(strUserDataInqResultForConst.strUserDataSeq[0].value, "1" ) == 0 )
    {
        strEqpRMSFlgInqResult.theRMSConstFlag = TRUE;
    }
    else
    {
        strEqpRMSFlgInqResult.theRMSConstFlag = FALSE;
    }
    PPT_METHODTRACE_V2("", "Set strEqpRMSFlgInqResult.theRMSConstFlag",((strEqpRMSFlgInqResult.theRMSConstFlag==TRUE)?1:0) );

    char* workptr = NULL;
    workptr = getenv(CS_SP_RMS_CHECK_ONLINE_FLAG);
    if(CIMFWStrCmp(workptr,"1")==0)
        strEqpRMSFlgInqResult.theRMSTotalFlag = TRUE;
    else
        strEqpRMSFlgInqResult.theRMSTotalFlag = FALSE;

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strEqpRMSFlgInqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txEqpRMSFlgInq ") ;
    return(RC_OK);
}
