//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txEqpListByOwnerInq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txEqpListByOwnerInq()
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csEqpListByOwnerInqResult&          strCsEqpListByOwnerInqResult,
//      const pptObjCommonIn&              strObjCommonIn,
//      const objectIdentifier&            equipmentOwnerID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txEqpListByOwnerInq(
    csEqpListByOwnerInqResult&          strCsEqpListByOwnerInqResult,
    const pptObjCommonIn&              strObjCommonIn,
    const objectIdentifier&            equipmentOwnerID
    CORBAENV_LAST_CPP)
{
    /*------------------------------------------------------------------------*/
    /*   Return Code Initialization                                           */
    /*------------------------------------------------------------------------*/

    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txEqpListByOwnerInq")
    CORBA::Long rc = RC_OK ;

    /*-------------------*/
    /*   Get area list   */
    /*-------------------*/
    csObjEquipment_ListByOwnerDR_out strCsObjEquipment_ListByOwnerDR_out;
    rc = cs_equipment_ListByOwnerDR (strCsObjEquipment_ListByOwnerDR_out, strObjCommonIn, equipmentOwnerID);

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_txEqpListByOwnerInq() != RC_OK");
        strCsEqpListByOwnerInqResult.strResult = strCsObjEquipment_ListByOwnerDR_out.strResult;
        return( rc );
    }
    strCsEqpListByOwnerInqResult.strEqpsByOwners = strCsObjEquipment_ListByOwnerDR_out.strEqpsByOwners;

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strCsEqpListByOwnerInqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txEqpListByOwnerInq ") ;
    return(RC_OK);
}
