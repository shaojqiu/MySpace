#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/txCassetteUsageCountResetReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:15:14 [ 7/13/07 21:15:15 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: cs_txCassetteUsageCountResetReqOR.cpp
//

//INN-R170003 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"     //INN-R170003

#include "pcas.hh"     //P3100315
#include "pctrlj.hh"   //P3100315


// Class: CS_PPTManager
//
// Service: txCassetteUsageCountResetReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/09/12 P3000139 O.Sugiyama     add SET_MSG_RC
// 2000/09/18 P3000139 T.Yamano       add SET_MSG_RC
// 2001/05/08 P3100315 K.Matsuei      Add Check Logic for LotSchdlChangeReq,
//                                    LotMfgOrderChangeReq, txCassetteUsageCountResetReq
// 2002/01/18 D4100081 Cinthia Jao    Add call DurableChangeEvent_Make
// 2002/08/22 D4200039 H.Adachi       Replace Direct FW Calling.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04   D6000025 K.Murakami     eBroker Migration.
// 2006/05/18 D7000092 Y.Kadowaki     Add object lock for cassette.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/04 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2013/05/13 DSN000071674 C.Mo           Remove part of the EI state limitation
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/16 INN-R170003  Nick Tsai      add PI/PO logic
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptCassetteUsageCountResetReqResult& strCassetteUsageCountResetReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& cassetteID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170003 CORBA::Long PPTManager_i::txCassetteUsageCountResetReq (pptCassetteUsageCountResetReqResult& strCassetteUsageCountResetReqResult,
CORBA::Long CS_PPTManager_i::txCassetteUsageCountResetReq (pptCassetteUsageCountResetReqResult& strCassetteUsageCountResetReqResult,    //INN-R170003
                                                           const pptObjCommonIn& strObjCommonIn,
                                                           const objectIdentifier& cassetteID,
//D6000025                                                         const char * claimMemo,
//D6000025                                                         CORBA::Environment &IT_env)
                                                           const char * claimMemo //D6000025
                                                           CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txCassetteUsageCountResetReq")
    CORBA::Long rc = RC_OK ;

//D7000092 add start
    //------------------------------
    // Object Lock for Cassette
    //------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, cassetteID, SP_ClassName_PosCassette);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strCassetteUsageCountResetReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }
//D7000092 add end

//D4200039//P3100315 start
//D4200039    char * methodName = NULL;
//D4200039    PPT_METHODTRACE_V1("", "P3100315 start ##################################################");
//D4200039    PosCassette_var aPosCassette;
//D4200039    PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, cassetteID,
//D4200039                                           strCassetteUsageCountResetReqResult, txCassetteUsageCountResetReq );
//D4200039
//D4200039    if ( ! CORBA::is_nil( aPosCassette ) )
//D4200039    {
//D4200039      PPT_METHODTRACE_V1("", "aPosCassette is not nil");
//D4200039        /*----------------------*/
//D4200039        /*   check XferStetus   */
//D4200039        /*----------------------*/
//D4200039      PPT_METHODTRACE_V1("", "-----------check XferStetus-----------");
//D4200039        CORBA::String_var strCassetteXferState;
//D4200039        try
//D4200039        {
//D4200039            strCassetteXferState = aPosCassette->getTransportState();
//D4200039        }
//D4200039        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//D4200039
//D4200039      PPT_METHODTRACE_V2("", "strCassetteXferState--->", strCassetteXferState);
//D4200039        if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
//D4200039        {
//D4200039          PPT_METHODTRACE_V1("", "##### strCassetteXferState == SP_TransState_EquipmentIn");
//D4200039            PPT_SET_MSG_RC_KEY2( strCassetteUsageCountResetReqResult,
//D4200039                                 MSG_INVALID_CAST_XFERSTAT,
//D4200039                                 RC_INVALID_CAST_XFERSTAT,
//D4200039                                 strCassetteXferState,
//D4200039                                 cassetteID.identifier );
//D4200039
//D4200039            return RC_INVALID_CAST_XFERSTAT;
//D4200039        }
//D4200039
//D4200039        /*------------------------*/
//D4200039        /*   check controlJobID   */
//D4200039        /*------------------------*/
//D4200039      PPT_METHODTRACE_V1("", "-----------check controlJobID-----------");
//D4200039        PosControlJob_var aPosControlJob;
//D4200039        try
//D4200039        {
//D4200039            aPosControlJob = aPosCassette->getControlJob();
//D4200039        }
//D4200039        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//D4200039
//D4200039        if ( ! CORBA::is_nil(aPosControlJob) )
//D4200039        {
//D4200039          PPT_METHODTRACE_V1("", "##### aPosControlJob is not nil");
//D4200039            SET_MSG_RC( strCassetteUsageCountResetReqResult,
//D4200039                        MSG_CAST_CTRLJOBID_FILLED,
//D4200039                        RC_CAST_CTRLJOBID_FILLED );
//D4200039
//D4200039            return RC_CAST_CTRLJOBID_FILLED;
//D4200039        }
//D4200039        else
//D4200039        {
//D4200039          PPT_METHODTRACE_V1("", "aPosControlJob is nil");
//D4200039        }
//D4200039    }
//D4200039    else
//D4200039    {
//D4200039      PPT_METHODTRACE_V1("", "aPosCassette is nil") ;
//D4200039    }
//D4200039    PPT_METHODTRACE_V1("", "P3100315 end ####################################################");
//D4200039//P3100315 end

    //D4200039 Add Ster
//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
    if ( 1 == lotOperationEIcheck )
    {
//DSN000071674 add end
        //------------------------------
        // Check Cassette Xfer Stat
        //------------------------------
        CORBA::String_var strCassetteXferState;
        objCassette_transferState_Get_out strCassette_transferState_Get_out;

        rc = cassette_transferState_Get(strCassette_transferState_Get_out,strObjCommonIn ,cassetteID);

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_transferState_Get() rc != RC_OK")
            strCassetteUsageCountResetReqResult.strResult = strCassette_transferState_Get_out.strResult;
            return(rc);
        }
        strCassetteXferState = strCassette_transferState_Get_out.transferState;

        //INN-R170003 if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
        //INN-R170003 add start
        if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn )  ||
            0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentOut ) ||
            0 == CIMFWStrCmp(strCassetteXferState, CS_TRANS_STATE_PORT_IN )   )
        //INN-R170003 add end
        {
            PPT_METHODTRACE_V1("", "##### strCassetteXferState == SP_TransState_EquipmentIn");
            PPT_SET_MSG_RC_KEY2( strCassetteUsageCountResetReqResult,
                                 MSG_INVALID_CAST_XFERSTAT,
                                 RC_INVALID_CAST_XFERSTAT,
                                 strCassetteXferState,
                                 cassetteID.identifier );
            return RC_INVALID_CAST_XFERSTAT;
        }
    } //DSN000071674

    //---------------------------------
    //   Get Cassette's ControlJobID
    //---------------------------------
    objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

    rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                    strObjCommonIn,
                                    cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
        strCassetteUsageCountResetReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
        return( rc );
    }

    if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
    {
        PPT_METHODTRACE_V1( "", "len(controlJobID) > 0" );
        SET_MSG_RC( strCassetteUsageCountResetReqResult,
                    MSG_CAST_CTRLJOBID_FILLED,
                    RC_CAST_CTRLJOBID_FILLED );

        return RC_CAST_CTRLJOBID_FILLED;
    }
    else
    {
        PPT_METHODTRACE_V1("", "strCassette_controlJobID_Get_out.controlJobID.identifier is nil") ;
    }
    //D4200039 Add End

//DSIV00000214 add start
        objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
        objCassette_interFabXferState_Get_in strCassette_interFabXferState_Get_in;
        strCassette_interFabXferState_Get_in.cassetteID = cassetteID;

        rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out,
                                             strObjCommonIn,
                                             strCassette_interFabXferState_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_interFabXferState_Get() != RC_OK");
            strCassetteUsageCountResetReqResult.strResult = strCassette_interFabXferState_Get_out.strResult;
            return( rc );
        }

        if( CIMFWStrCmp( strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) == 0 )
        {
             PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
             PPT_SET_MSG_RC_KEY2( strCassetteUsageCountResetReqResult,
                                  MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                  RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                  cassetteID.identifier,
                                  strCassette_interFabXferState_Get_out.interFabXferState );
             return( RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ );
        }
//DSIV00000214 add end

    /*--------------------------------------*/
    /*   Reset cassette usage information   */
    /*--------------------------------------*/
    objCassette_usageInfo_Reset_out strCassette_usageInfo_Reset_out ;
    rc = cassette_usageInfo_Reset(strCassette_usageInfo_Reset_out,strObjCommonIn,cassetteID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_usageInfo_Reset() rc != RC_OK")
        strCassetteUsageCountResetReqResult.strResult = strCassette_usageInfo_Reset_out.strResult ;
        return( rc );
    }

    /*---------------------------------------------*/
    /*   D4100081  Create Durable Change Event     */
    /*---------------------------------------------*/
    objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
    rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                 strObjCommonIn,
                                 "TXPDC008",
                                 cassetteID,
                                 SP_DurableCat_Cassette,
                                 SP_DurableEvent_Action_PMReset,
                                 claimMemo) ;

    if( rc )
    {
        PPT_METHODTRACE_V1("", "durableChangeEvent_Make() rc != RC_OK")
        strCassetteUsageCountResetReqResult.strResult = strDurableChangeEvent_Make_out.strResult ;
//P5000145        PPT_SET_MSG_RC_KEY(strCassetteUsageCountResetReqResult, MSG_FAIL_MAKE_HISTORY, rc ,cassetteID.identifier);
        SET_MSG_RC( strCassetteUsageCountResetReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return rc ;
    }
    // D4100081 End

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    strCassetteUsageCountResetReqResult.cassetteID = cassetteID ;
//P3000139    strCassetteUsageCountResetReqResult.strResult = strCassette_usageInfo_Reset_out.strResult ;

    SET_MSG_RC(strCassetteUsageCountResetReqResult, MSG_OK, RC_OK); //P3000139

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txCassetteUsageCountResetReq")
    return( RC_OK );
}
