#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txLotInfoInq__160OR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/22/07 17:30:25 [ 11/22/07 17:30:27 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txLotInfoInq__160OR.cpp
//

#include "cs_pptmgr.hpp"
//DSIV00001830 #include "pptconvert.h"   //D9000005
#include "pptconverter.h" //DSIV00000214

// Class: CS_PPTManager
//
// Service: txLotInfoInq__160()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/09          S.Kawabe       Initial Release (R30)
// 2000/09/05 P3000031 S.Kawabe       Bug Fix
// 2002/08/20 D4200062 K.Kimura       Backup Operation (change in-parm)
// 2003-01-29 P4200553 H.Adachi       Return RC_OK when Lot does not has relation of carrier
// 2003-07-08 D5000154 K.Kido         Change for HAS.    (R50)
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/09/11 D7000026 K.Kido         Delete unnecessary methods.
// ------------------------------------------------------------------------------
// 2007/06/15 D9000005 K.Kido         Initial release for Wafer sorter automation (AAS support).
// 2007/08/03 D9000056 H.Hotta        PostProcess performance improvement.
// ------------------------------------------------------------------------------
// 2008/10/10 DSIV00000214 K.Matsuei  Multi Fab Transfer Support.
// 2010/05/10 DSIV00001830 K.Yamaoku  Wafer Stacking Operation Support
// 2011/09/21 DSN000020767 T.Ishida   Auto Dispatch Control Support
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2013/08/29 DSN000081739 Sa Guo         Equipment Monitor Automation Support
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2015/07/23 DSN000096135 XF.Ming        Virtual Operation support
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txLotInfoInq__160
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptLotInfoInqResult__160& strLotInfoInqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifierSequence& lotID
//     const CORBA::Boolean lotBasicInfoFlag,
//     const CORBA::Boolean lotControlUseInfoFlag,
//     const CORBA::Boolean lotFlowBatchInfoFlag,
//     const CORBA::Boolean lotNoteFlagInfoFlag,
//     const CORBA::Boolean lotOperationInfoFlag,
//     const CORBA::Boolean lotOrderInfoFlag,
//     const CORBA::Boolean lotControlJobInfoFlag,
//     const CORBA::Boolean lotProductInfoFlag,
//     const CORBA::Boolean lotRecipeInfoFlag,
//     const CORBA::Boolean lotLocationInfoFlag,
//     const CORBA::Boolean lotWipOperationInfoFlag,
//     const CORBA::Boolean lotWaferAttributesFlag,
//     const CORBA::Boolean lotListInCassetteInfoFlag,
//     const CORBA::Boolean waferMapInCassetteInfoFlag,
//     const CORBA::Boolean lotBackupInfoFlag,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//DSN000085698    CORBA::Long CS_PPTManager_i::txLotInfoInq__140 ( pptLotInfoInqResult__140& strLotInfoInqResult,
//DSN000096135 CORBA::Long CS_PPTManager_i::txLotInfoInq__150 ( pptLotInfoInqResult__150& strLotInfoInqResult,                    //DSN000085698
CORBA::Long CS_PPTManager_i::txLotInfoInq__160 ( pptLotInfoInqResult__160& strLotInfoInqResult,                    //DSN000096135
                                              const pptObjCommonIn& strObjCommonIn,
                                              const objectIdentifierSequence& lotID,
                                              const CORBA::Boolean lotBasicInfoFlag,
                                              const CORBA::Boolean lotControlUseInfoFlag,
                                              const CORBA::Boolean lotFlowBatchInfoFlag,
                                              const CORBA::Boolean lotNoteFlagInfoFlag,
                                              const CORBA::Boolean lotOperationInfoFlag,
                                              const CORBA::Boolean lotOrderInfoFlag,
                                              const CORBA::Boolean lotControlJobInfoFlag,
                                              const CORBA::Boolean lotProductInfoFlag,
                                              const CORBA::Boolean lotRecipeInfoFlag,
                                              const CORBA::Boolean lotLocationInfoFlag,
                                              const CORBA::Boolean lotWipOperationInfoFlag,
                                              const CORBA::Boolean lotWaferAttributesFlag,
                                              const CORBA::Boolean lotListInCassetteInfoFlag,
                                              const CORBA::Boolean waferMapInCassetteInfoFlag,
                                              const CORBA::Boolean lotBackupInfoFlag
                                              CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txLotInfoInq__160 ") ;
    CORBA::Long rc = RC_OK ;

//D5000154 add start
//D7000026    if( 0 == CIMFWStrCmp(getenv(SP_LOTINFO_BY_SQL),"1") )
//D7000026    {
    /*------------------------------------------------------------------------*/
    /*   Get lot status information for all lotIDs of in-parameter            */
    /*------------------------------------------------------------------------*/
    CORBA::Long nLen=0;
    nLen = lotID.length();
    PPT_METHODTRACE_V2("", "lotID.length()", nLen) ;

    strLotInfoInqResult.strLotInfo.length( nLen );
    for ( CORBA::Long i = 0; i < nLen; i++ )
    {
        PPT_METHODTRACE_V2("", " ########## For-Loop of lot_detailInfo_GetDR()...", i) ;

//DSN000085698        objLot_detailInfo_GetDR_out strLot_detailInfo_GetDR_out;
//DSN000085698        rc = lot_detailInfo_GetDR(strLot_detailInfo_GetDR_out, strObjCommonIn, lotID[i],
//DSN000096135        objLot_detailInfo_GetDR_out__150 strLot_detailInfo_GetDR_out;                               //DSN000085698
//DSN000096135        rc = lot_detailInfo_GetDR__150(strLot_detailInfo_GetDR_out, strObjCommonIn, lotID[i],       //DSN000085698
        objLot_detailInfo_GetDR_out__160 strLot_detailInfo_GetDR_out;                           //DSN000096135
        rc = lot_detailInfo_GetDR__160(strLot_detailInfo_GetDR_out, strObjCommonIn, lotID[i],   //DSN000096135
                                  lotBasicInfoFlag,
                                  lotControlUseInfoFlag,
                                  lotFlowBatchInfoFlag,
                                  lotNoteFlagInfoFlag,
                                  lotOperationInfoFlag,
                                  lotOrderInfoFlag,
                                  lotControlJobInfoFlag,
                                  lotProductInfoFlag,
                                  lotRecipeInfoFlag,
                                  lotLocationInfoFlag,
                                  lotWipOperationInfoFlag,
                                  lotWaferAttributesFlag,
                                  lotBackupInfoFlag);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "lot_detailInfo_GetDR() != RC_OK");
            strLotInfoInqResult.strResult = strLot_detailInfo_GetDR_out.strResult ;
            return(rc);
        }
//D9000005  strLotInfoInqResult.strLotInfo[i] = strLot_detailInfo_GetDR_out.strLotInfo;
//D9000005 add start
//DSIV00000214            PPTConvert conv(strLot_detailInfo_GetDR_out.strLotInfo);
//DSIV00000214            strLotInfoInqResult.strLotInfo[i] = conv;
//DSIV00000214 start
//DSN000085698        PPTConverter converter;
//DSIV00001830            converter.Convert080_to_100( strLot_detailInfo_GetDR_out.strLotInfo, strLotInfoInqResult.strLotInfo[i] );
//DSN000020767        converter.Convert080_to_101( strLot_detailInfo_GetDR_out.strLotInfo, strLotInfoInqResult.strLotInfo[i] );  //DSIV00001830
//DSN000081739        converter.Convert080_to_120( strLot_detailInfo_GetDR_out.strLotInfo, strLotInfoInqResult.strLotInfo[i] );    //DSN000020767
//DSN000085698        converter.Convert080_to_140( strLot_detailInfo_GetDR_out.strLotInfo, strLotInfoInqResult.strLotInfo[i] );    //DSN000081739
        strLotInfoInqResult.strLotInfo[i] = strLot_detailInfo_GetDR_out.strLotInfo;                                                //DSN000081739

        if ( lotBasicInfoFlag )
        {
            // Get InterFab Transfer State
            PPT_METHODTRACE_V1("", "Get InterFab Transfer State");
            objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
            objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

            strLot_interFabXferState_Get_in.lotID = lotID[i];

            rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                            strObjCommonIn,
                                            strLot_interFabXferState_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
                strLotInfoInqResult.strResult = strLot_interFabXferState_Get_out.strResult ;
                return rc;
            }

            strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.interFabXferState = strLot_interFabXferState_Get_out.interFabXferState;
        }
//DSIV00000214 end

        /****************************************/
        /* Get sorter information for the Lot.  */
        /****************************************/
        strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.sorterJobExistFlag = FALSE;
        if(lotBasicInfoFlag)
        {
            objSorter_jobList_GetDR_in strSorter_jobList_GetDR_in;
            objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;

            strSorter_jobList_GetDR_in.lotID = lotID[i];
            rc = sorter_jobList_GetDR(strSorter_jobList_GetDR_out, strObjCommonIn, strSorter_jobList_GetDR_in);

            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "sorter_jobList_GetDR() != RC_OK");
                strLotInfoInqResult.strResult = strSorter_jobList_GetDR_out.strResult ;
                return rc;
            }

            if( 0 != strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length() )
            {
                strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.sorterJobExistFlag = TRUE;
            }
        }
//D9000005 add end

//D9000056 add start
        PPT_METHODTRACE_V3("", "Get InPostProcessFlag of Lot", i, lotID[i].identifier);
        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_out  strLot_inPostProcessFlag_Get_out;
        objLot_inPostProcessFlag_Get_in   strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = lotID[i];

        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strLotInfoInqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            return( rc );
        }

        strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.inPostProcessFlagOfCassette = strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfCassette;
        strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.inPostProcessFlagOfLot      = strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot;
        PPT_METHODTRACE_V2("", "  inPostProcessFlagOfCassette", strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.inPostProcessFlagOfCassette);
        PPT_METHODTRACE_V2("", "  inPostProcessFlagOfLot     ", strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.inPostProcessFlagOfLot);
//D9000056 add end

//DSIV00001830 add start
        if( lotBasicInfoFlag )
        {
            //----------------------------------
            //  Get Bonding Group ID
            //----------------------------------
            objLot_bondingGroupID_GetDR_in strLot_bondingGroupID_GetDR_in;
            strLot_bondingGroupID_GetDR_in.lotID = lotID[i];

            objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
            rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "lot_bondingGroupID_GetDR() != RC_OK" );
                strLotInfoInqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
                return rc;
            }

            //----------------------------------
            //  Set Bonding Group ID
            //----------------------------------
            strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.bondingGroupID = CIMFWStrDup( strLot_bondingGroupID_GetDR_out.bondingGroupID );
        }

        if( lotProductInfoFlag )
        {
            //------------------------------------------------------
            // Get product BOM information
            //------------------------------------------------------
            objProduct_BOMInfo_Get_out strProduct_BOMInfo_Get_out;
            objProduct_BOMInfo_Get_in  strProduct_BOMInfo_Get_in;
            strProduct_BOMInfo_Get_in.productID = strLotInfoInqResult.strLotInfo[i].strLotProductInfo.productID;

            PPT_METHODTRACE_V1( "", "call product_BOMInfo_Get()" )
            rc = product_BOMInfo_Get( strProduct_BOMInfo_Get_out,
                                      strObjCommonIn,
                                      strProduct_BOMInfo_Get_in );
            if( rc != RC_OK && rc != RC_BOM_NOT_DEFINED )
            {
                PPT_METHODTRACE_V2( "", "product_BOMInfo_Get() != RC_OK", rc );
                strLotInfoInqResult.strResult = strProduct_BOMInfo_Get_out.strResult;
                return rc;
            }

            //----------------------------------
            //  Set BOM ID
            //----------------------------------
            strLotInfoInqResult.strLotInfo[i].strLotProductInfo.bomID = strProduct_BOMInfo_Get_out.bomID;
        }
//DSIV00001830 add end

//DSN000020767 Add Start
        if( lotBasicInfoFlag )
        {
            //--------------------------------------------
            //  Get Auto Dispatch Control Information
            //--------------------------------------------
            objAutoDispatchControl_info_GetDR_in strAutoDispatchControl_info_GetDR_in;
            strAutoDispatchControl_info_GetDR_in.lotID = lotID[i];

            objAutoDispatchControl_info_GetDR_out strAutoDispatchControl_info_GetDR_out;
            rc = autoDispatchControl_info_GetDR( strAutoDispatchControl_info_GetDR_out, strObjCommonIn, strAutoDispatchControl_info_GetDR_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "autoDispatchControl_info_GetDR() != RC_OK" );
                strLotInfoInqResult.strResult = strAutoDispatchControl_info_GetDR_out.strResult;
                return rc;
            }

            //----------------------------------
            //  Set Auto Dispatch Control Flag
            //----------------------------------
            if( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq.length() > 0 )
            {
                strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.autoDispatchControlFlag = TRUE;
            }
            else
            {
                strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.autoDispatchControlFlag = FALSE;
            }
        }
//DSN000020767 Add End

//DSN000081739 Add Start
        if( lotBasicInfoFlag )
        {
            PPT_METHODTRACE_V1("", "lotBasicInfoFlag == TRUE");
            //--------------------------------------------
            //  Get Equipment Monitor Job Information
            //--------------------------------------------
            objLot_eqpMonitorJob_Get_out strLot_eqpMonitorJob_Get_out;
            objLot_eqpMonitorJob_Get_in  strLot_eqpMonitorJob_Get_in;
            strLot_eqpMonitorJob_Get_in.lotID = lotID[i];
            rc = lot_eqpMonitorJob_Get( strLot_eqpMonitorJob_Get_out,
                                        strObjCommonIn,
                                        strLot_eqpMonitorJob_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_eqpMonitorJob_Get() != RC_OK", rc);
                strLotInfoInqResult.strResult = strLot_eqpMonitorJob_Get_out.strResult;
                return rc;
            }

            if ( 0 < CIMFWStrLen( strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.eqpMonitorJobID.identifier ) )
            {
                PPT_METHODTRACE_V1("", "Lot is involved in EqpMonitor Job");
                pptEqpMonitorID strEqpMonitorID;
                strEqpMonitorID.equipmentID     = strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.equipmentID;
                strEqpMonitorID.chamberID       = strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.chamberID;
                strEqpMonitorID.eqpMonitorID    = strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.eqpMonitorID;
                strEqpMonitorID.eqpMonitorJobID = strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.eqpMonitorJobID;

                strLotInfoInqResult.strLotInfo[i].strLotBasicInfo.strEqpMonitorID = strEqpMonitorID;
            }
        }
//DSN000081739 Add End
    }


    pptLotListInCassetteInfo             strLotListInCassetteInfo;
    pptWaferMapInCassetteInfoSequence    strWaferMapInCassetteInfo;

    PPT_METHODTRACE_V2("", "lotID.length()", nLen) ;
    if ( nLen == 1 )
    {
        objLot_cassetteList_GetDR_out   strLot_cassetteList_GetDR_out;
        rc = lot_cassetteList_GetDR( strLot_cassetteList_GetDR_out, strObjCommonIn, lotID[0]);
        if ( rc != RC_OK && rc != RC_NOT_FOUND_CST )
        {
            strLotInfoInqResult.strResult = strLot_cassetteList_GetDR_out.strResult ;
            return ( rc );
        }
        else if ( rc == RC_OK )
        {
            if ( CIMFWStrLen (strLot_cassetteList_GetDR_out.cassetteID.identifier) > 0 )
            {
                if ( lotListInCassetteInfoFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("", "lotListInCassetteInfoFlag == TRUE");

                    objCassette_lotList_GetDR_out   strCassette_lotList_GetDR_out;
                    rc = cassette_lotList_GetDR( strCassette_lotList_GetDR_out,
                                                 strObjCommonIn,
                                                 strLot_cassetteList_GetDR_out.cassetteID);

                    if ( rc == RC_NOT_FOUND_LOT )
                    {
                        PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() == RC_NOT_FOUND_LOT");
                        rc = RC_OK ;
                    }
                    else if ( rc == RC_NOT_FOUND_CASSETTE )
                    {
                        PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() == RC_NOT_FOUND_CASSETTE");
                        rc = RC_OK ;
                    }
                    else if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() != RC_OK");
                        strLotInfoInqResult.strResult = strCassette_lotList_GetDR_out.strResult ;
                        return(rc);
                    }
                    strLotListInCassetteInfo = strCassette_lotList_GetDR_out.strLotListInCassetteInfo;
                }

                if ( waferMapInCassetteInfoFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("", "waferMapInCassetteInfoFlag == TRUE");

                    objCassette_GetWaferMapDR_out   strCassette_GetWaferMapDR_out;
                    rc = cassette_GetWaferMapDR( strCassette_GetWaferMapDR_out,
                                                 strObjCommonIn,
                                                 strLot_cassetteList_GetDR_out.cassetteID);

                    if ( rc == RC_NOT_FOUND_CASSETTE )
                    {
                        PPT_METHODTRACE_V1("", "cassette_GetWaferMapDR() == RC_NOT_FOUND_CASSETTE");
                        rc = RC_OK ;
                    }
                    else if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "cassette_GetWaferMapDR() != RC_OK");
                        strLotInfoInqResult.strResult = strCassette_GetWaferMapDR_out.strResult ;
                        return(rc);
                    }
                    strWaferMapInCassetteInfo = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo;
                }
            }
        }

    }
    else if ( nLen > 1 )
    {
        objLot_cassette_SameCheckDR_out   strLot_cassette_SameCheckDR_out;
        rc = lot_cassette_SameCheckDR( strLot_cassette_SameCheckDR_out,
                                       strObjCommonIn,
                                       lotID );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "lot_cassette_CheckSame() != RC_OK");
            strLotInfoInqResult.strResult = strLot_cassette_SameCheckDR_out.strResult ;
            return(rc);
        }
        if (CIMFWStrLen(strLot_cassette_SameCheckDR_out.cassetteID.identifier) > 0)
        {
            if ( lotListInCassetteInfoFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "lotListInCassetteInfoFlag == TRUE");

                objCassette_lotList_GetDR_out   strCassette_lotList_GetDR_out;
                rc = cassette_lotList_GetDR( strCassette_lotList_GetDR_out,
                                             strObjCommonIn,
                                             strLot_cassette_SameCheckDR_out.cassetteID);

                if ( rc == RC_NOT_FOUND_LOT )
                {
                    PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() == RC_NOT_FOUND_LOT");
                    rc = RC_OK ;
                }
                else if ( rc == RC_NOT_FOUND_CASSETTE )
                {
                    PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() == RC_NOT_FOUND_CASSETTE");
                    rc = RC_OK ;
                }
                else if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1( "", "cassette_lotList_GetDR() != RC_OK" );
                    strLotInfoInqResult.strResult = strCassette_lotList_GetDR_out.strResult;
                    return(rc);
                }
                strLotListInCassetteInfo = strCassette_lotList_GetDR_out.strLotListInCassetteInfo;
            }

            if ( waferMapInCassetteInfoFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "waferMapInCassetteInfoFlag == TRUE");

                objCassette_GetWaferMapDR_out   strCassette_GetWaferMapDR_out;
                rc = cassette_GetWaferMapDR( strCassette_GetWaferMapDR_out,
                                             strObjCommonIn,
                                             strLot_cassette_SameCheckDR_out.cassetteID );

                if ( rc == RC_NOT_FOUND_CASSETTE )
                {
                    PPT_METHODTRACE_V1("", "cassette_GetWaferMapDR() == RC_NOT_FOUND_CASSETTE");
                    rc = RC_OK ;
                }
                else if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "cassette_GetWaferMapDR() != RC_OK");
                    strLotInfoInqResult.strResult = strCassette_GetWaferMapDR_out.strResult ;
                    return(rc);
                }
                strWaferMapInCassetteInfo = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo;
            }
        }
    }

    strLotInfoInqResult.strLotListInCassetteInfo  = strLotListInCassetteInfo;
    strLotInfoInqResult.strWaferMapInCassetteInfo = strWaferMapInCassetteInfo;
//D7000026    }
//D7000026    else
//D7000026    {
//D5000154 add end
//D7000026        /*------------------------------------------------------------------------*/
//D7000026        /*   Get lot status information for all lotIDs of in-parameter            */
//D7000026        /*------------------------------------------------------------------------*/
//D7000026        CORBA::Long nLen=0;
//D7000026        nLen = lotID.length();
//D7000026        PPT_METHODTRACE_V2("PPTServiceManager_i::txLotInfoInq__100", "lotID.length()", nLen) ;
//D7000026
//D7000026        strLotInfoInqResult.strLotInfo.length(nLen);
//D7000026        for(CORBA::Long i=0; i<nLen; i++ )
//D7000026        {
//D7000026            PPT_METHODTRACE_V2("PPTServiceManager_i::txLotInfoInq__100", "For-Loop of lot_GetInfoDR()...", i) ;
//D7000026
//D7000026            objLot_GetInfoDR_out strLot_GetInfoDR_out;
//D7000026            rc = lot_GetInfoDR(strLot_GetInfoDR_out, strObjCommonIn, lotID[i],
//D7000026                               lotBasicInfoFlag,
//D7000026                               lotControlUseInfoFlag,
//D7000026                               lotFlowBatchInfoFlag,
//D7000026                               lotNoteFlagInfoFlag,
//D7000026                               lotOperationInfoFlag,
//D7000026                               lotOrderInfoFlag,
//D7000026                               lotControlJobInfoFlag,
//D7000026                               lotProductInfoFlag,
//D7000026                               lotRecipeInfoFlag,
//D7000026                               lotLocationInfoFlag,
//D7000026                               lotWipOperationInfoFlag,
//D7000026                               lotWaferAttributesFlag,
//D7000026                               lotBackupInfoFlag);    //D4200062
//D7000026            if (rc != RC_OK)
//D7000026            {
//D7000026                PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "lot_GetInfoDR() != RC_OK");
//D7000026                strLotInfoInqResult.strResult = strLot_GetInfoDR_out.strResult ;
//D7000026                return(rc);
//D7000026            }
//D7000026            PPT_METHODTRACE_V1("PPTServiceManager_i::txLotInfoInq__100", "Set strLotInfo") ;
//D7000026            strLotInfoInqResult.strLotInfo[i] = strLot_GetInfoDR_out.strLotInfo;
//D7000026            PPT_METHODTRACE_V1("PPTServiceManager_i::txLotInfoInq__100", "End strLotInfo") ;
//D7000026        }
//D7000026
//D7000026    //0.01    /*------------------------------------------------------------------------*/
//D7000026    //0.01    /*   Check if all lotIDs of in-parameter are in the same casetteID or not */
//D7000026    //0.01    /*------------------------------------------------------------------------*/
//D7000026    //0.01    objLot_cassette_CheckSame_out strLot_cassette_CheckSame_out ;
//D7000026    //0.01    rc = lot_cassette_CheckSame(strLot_cassette_CheckSame_out, strObjCommonIn, lotID);
//D7000026    //0.01    if ( rc != RC_OK )
//D7000026    //0.01    {
//D7000026    //0.01        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "lot_cassette_CheckSame() != RC_OK") ;
//D7000026    //0.01        strLotInfoInqResult.strResult = strLot_cassette_CheckSame_out.strResult ;
//D7000026    //0.01        return(rc);
//D7000026    //0.01    }
//D7000026    //0.01
//D7000026
//D7000026    //0.01    /*------------------------------------------------------------------------*/
//D7000026    //0.01    /*   Get lot status information for all lotIDs of in-parameter            */
//D7000026    //0.01    /*------------------------------------------------------------------------*/
//D7000026    //0.01    CORBA::Long nLen=0;
//D7000026    //0.01    nLen = lotID.length();
//D7000026    //0.01    PPT_METHODTRACE_V2("PPTServiceManager_i::txLotInfoInq__100", "lotID.length()", nLen) ;
//D7000026    //0.01
//D7000026    //0.01    for(CORBA::Long i=0; i<nLen; i++ )
//D7000026    //0.01    {
//D7000026    //0.01        PPT_METHODTRACE_V2("PPTServiceManager_i::txLotInfoInq__100", "For-Loop of lot_GetInfoDR()...", i) ;
//D7000026    //0.01
//D7000026    //0.01        objLot_GetInfoDR_out strLot_GetInfoDR_out;
//D7000026    //0.01        rc = lot_GetInfoDR(strLot_GetInfoDR_out, strObjCommonIn, lotID[i],
//D7000026    //0.01                           lotBasicInfoFlag,
//D7000026    //0.01                           lotControlUseInfoFlag,
//D7000026    //0.01                           lotFlowBatchInfoFlag,
//D7000026    //0.01                           lotNoteFlagInfoFlag,
//D7000026    //0.01                           lotOperationInfoFlag,
//D7000026    //0.01                           lotOrderInfoFlag,
//D7000026    //0.01                           lotControlJobInfoFlag,
//D7000026    //0.01                           lotProductInfoFlag,
//D7000026    //0.01                           lotRecipeInfoFlag,
//D7000026    //0.01                           lotLocationInfoFlag,
//D7000026    //0.01                           lotWipOperationInfoFlag,
//D7000026    //0.01                           lotWaferAttributesFlag);
//D7000026    //0.01        if (rc != RC_OK)
//D7000026    //0.01        {
//D7000026    //0.01            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "lot_GetInfoDR() != RC_OK");
//D7000026    //0.01            strLotInfoInqResult.strResult = strLot_GetInfoDR_out.strResult ;
//D7000026    //0.01            return(rc);
//D7000026    //0.01        }
//D7000026    //0.01        strLotInfoInqResult.strLotInfo[i] = strLot_GetInfoDR_out.strLotInfo;
//D7000026    //0.01    }
//D7000026    //0.01
//D7000026    //0.01    if ( lotListInCassetteInfoFlag == TRUE)
//D7000026    //0.01    {
//D7000026    //0.01        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "lotListInCassetteInfoFlag == TRUE");
//D7000026    //0.01
//D7000026    //0.01        objCassette_GetLotList_out strCassette_GetLotList_out;
//D7000026    //0.01        rc = cassette_GetLotList(strCassette_GetLotList_out, strObjCommonIn, strLot_cassette_CheckSame_out.cassetteID);
//D7000026    //0.01        if (rc == RC_NOT_FOUND_LOT )
//D7000026    //0.01        {
//D7000026    //0.01            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetLotList() == RC_NOT_FOUND_LOT");
//D7000026    //0.01            rc = RC_OK;
//D7000026    //0.01        }
//D7000026    //0.01        else if ( rc == RC_NOT_FOUND_MATERIAL )
//D7000026    //0.01        {
//D7000026    //0.01            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetLotList() == RC_NOT_FOUND_MATERIAL");
//D7000026    //0.01            rc = RC_OK;
//D7000026    //0.01        }
//D7000026    //0.01        else if (rc != RC_OK)
//D7000026    //0.01        {
//D7000026    //0.01            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetLotList() != RC_OK");
//D7000026    //0.01            strLotInfoInqResult.strResult = strCassette_GetLotList_out.strResult ;
//D7000026    //0.01            return(rc);
//D7000026    //0.01        }
//D7000026    //0.01    }
//D7000026    //0.01
//D7000026    //0.01    if ( waferMapInCassetteInfoFlag == TRUE )
//D7000026    //0.01    {
//D7000026    //0.01        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "waferMapInCassetteInfoFlag == TRUE");
//D7000026    //0.01
//D7000026    //0.01        objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
//D7000026    //0.01        rc = cassette_GetWaferMapDR(strCassette_GetWaferMapDR_out, strObjCommonIn, strLot_cassette_CheckSame_out.cassetteID);
//D7000026    //0.01        if ( rc == RC_NOT_FOUND_LOT )
//D7000026    //0.01        {
//D7000026    //0.01            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() == RC_NOT_FOUND_LOT");
//D7000026    //0.01            rc = RC_OK;
//D7000026    //0.01        }
//D7000026    //0.01        else if ( rc == RC_NOT_FOUND_MATERIAL )
//D7000026    //0.01        {
//D7000026    //0.01            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() == RC_NOT_FOUND_MATERIAL");
//D7000026    //0.01            rc = RC_OK;
//D7000026    //0.01        }
//D7000026    //0.01        else if (rc != RC_OK)
//D7000026    //0.01        {
//D7000026    //0.01            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() != RC_OK");
//D7000026    //0.01            strLotInfoInqResult.strResult = strCassette_GetWaferMapDR_out.strResult ;
//D7000026    //0.01            return(rc);
//D7000026    //0.01        }
//D7000026    //0.01    }
//D7000026
//D7000026        /*--------------------------------------------------------------------------------*/
//D7000026        /*    If lotListInCassetteInfoFlag or/and waferMapInCassetteInfoFlag are          */
//D7000026        /*   TRUE, strLotListInCassetteInfo or/and strWaferMapInCassetteInfo              */
//D7000026        /*   2 kinds of data structures should be filled by using the only 1 common       */
//D7000026        /*   cassetteID which are used for lotIDs of in-parameter.                        */
//D7000026        /*                                                                                */
//D7000026        /*   If lotID of in-parameter is the only 1,                                      */
//D7000026        /*    Check the relation between lot and cassetteID, here are 3 cases;            */
//D7000026        /*    1. No relation to cassetteID (= Vendor Lot),                                */
//D7000026        /*          2 kinds of data structure are returned as blank.                      */
//D7000026        /*    2. Relation to 1 cassetteID (= WIP Lot),                                    */
//D7000026        /*          2 kinds of data structure are filled by using the related cassetteID  */
//D7000026        /*    3. Relation to plural cassetteID (= BankIn Lot)                             */
//D7000026        /*          2 kinds of data structure are returned as blank.                      */
//D7000026        /*                                                                                */
//D7000026        /*   If lotID of in-parameter are the plural lotIDs, it is assumed that all of    */
//D7000026        /*   lotIDs are related to the common cassetteID.                                 */
//D7000026        /*                                                                                */
//D7000026        /*    Find out the common cassetteID which are used for lotIDs of in-parameter.   */
//D7000026        /*    2 kinds of data structure are filled by using the common cassetteID.        */
//D7000026        /*                                                                                */
//D7000026        /*--------------------------------------------------------------------------------*/
//D7000026        pptLotListInCassetteInfo             strLotListInCassetteInfo;
//D7000026        pptWaferMapInCassetteInfoSequence    strWaferMapInCassetteInfo;
//D7000026
//D7000026        PPT_METHODTRACE_V1("PPTServiceManager_i::txLotInfoInq__100", "Set strLotListInCasetteInfo") ;
//D7000026        strLotInfoInqResult.strLotListInCassetteInfo  = strLotListInCassetteInfo;
//D7000026
//D7000026        PPT_METHODTRACE_V1("PPTServiceManager_i::txLotInfoInq__100", "Set strWaferMapInCassetteInfo") ;
//D7000026        strLotInfoInqResult.strWaferMapInCassetteInfo = strWaferMapInCassetteInfo;
//D7000026
//D7000026        PPT_METHODTRACE_V2("PPTServiceManager_i::txLotInfoInq__100", "lotID.length()", nLen) ;
//D7000026        if ( nLen == 1 )
//D7000026        {
//D7000026            objLot_cassetteList_Get_out   strLot_cassetteList_Get_out;
//D7000026            rc = lot_cassetteList_Get( strLot_cassetteList_Get_out, strObjCommonIn, lotID[0]);
//D7000026            if ( rc != RC_OK && rc != RC_NOT_FOUND_CST )
//D7000026            {
//D7000026                PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "lot_cassetteList_Get() != RC_OK && RC_NOT_FOUND_CST");
//D7000026                strLotInfoInqResult.strResult = strLot_cassetteList_Get_out.strResult ;
//D7000026                return(rc);
//D7000026            }
//D7000026            else if ( rc == RC_OK )
//D7000026            {
//D7000026                CORBA::Long nnLen = 0;
//D7000026                nnLen = strLot_cassetteList_Get_out.cassetteIDs.length();
//D7000026                PPT_METHODTRACE_V2("CS_PPTManager_i:: txLotInfoInq__100",
//D7000026                                   "strLot_cassetteList_Get_out.cassetteIDs.length()", nnLen);
//D7000026
//D7000026                if ( nnLen == 1 )
//D7000026                {
//D7000026                    if ( lotListInCassetteInfoFlag == TRUE )
//D7000026                    {
//D7000026                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "lotListInCassetteInfoFlag == TRUE");
//D7000026
//D7000026                        objCassette_GetLotList_out   strCassette_GetLotList_out;
//D7000026                        rc = cassette_GetLotList( strCassette_GetLotList_out,
//D7000026                                                  strObjCommonIn,
//D7000026                                                  strLot_cassetteList_Get_out.cassetteIDs[0]);
//D7000026
//D7000026                        if ( rc == RC_NOT_FOUND_LOT )
//D7000026                        {
//D7000026                            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetLotList() == RC_NOT_FOUND_LOT");
//D7000026                            rc = RC_OK ;
//D7000026                        }
//D7000026                        else if ( rc == RC_NOT_FOUND_MATERIAL )
//D7000026                        {
//D7000026                            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "rccassette_GetLotList == RC_NOT_FOUND_MATERIAL");
//D7000026                            rc = RC_OK ;
//D7000026                        }
//D7000026                        else if (rc != RC_OK)
//D7000026                        {
//D7000026                            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetLotList() != RC_OK");
//D7000026                            strLotInfoInqResult.strResult = strCassette_GetLotList_out.strResult ;
//D7000026                            return(rc);
//D7000026                        }
//D7000026                        strLotListInCassetteInfo = strCassette_GetLotList_out.strLotListInCassetteInfo;    //P3000031
//D7000026                    }
//D7000026
//D7000026                    if ( waferMapInCassetteInfoFlag == TRUE )
//D7000026                    {
//D7000026                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "waferMapInCassetteInfoFlag == TRUE");
//D7000026
//D7000026                        objCassette_GetWaferMapDR_out   strCassette_GetWaferMapDR_out;
//D7000026                        rc = cassette_GetWaferMapDR( strCassette_GetWaferMapDR_out,
//D7000026                                                     strObjCommonIn,
//D7000026                                                     strLot_cassetteList_Get_out.cassetteIDs[0]);
//D7000026                        if ( rc == RC_NOT_FOUND_LOT )
//D7000026                        {
//D7000026                            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() == RC_NOT_FOUND_LOT");
//D7000026                            rc = RC_OK ;
//D7000026                        }
//D7000026                        else if ( rc == RC_NOT_FOUND_MATERIAL )
//D7000026                        {
//D7000026                            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() == RC_NOT_FOUND_MATERIAL");
//D7000026                            rc = RC_OK ;
//D7000026                        }
//D7000026                        else if (rc != RC_OK)
//D7000026                        {
//D7000026                            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() != RC_OK");
//D7000026                            strLotInfoInqResult.strResult = strCassette_GetWaferMapDR_out.strResult ;
//D7000026                            return(rc);
//D7000026                        }
//D7000026                        strWaferMapInCassetteInfo = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo;    //P3000031
//D7000026                    }
//D7000026                }
//D7000026            }
//D7000026
//D7000026        }
//D7000026        else if ( nLen > 1 )
//D7000026        {
//D7000026            objLot_cassette_CheckSame_out   strLot_cassette_CheckSame_out;
//D7000026            rc = lot_cassette_CheckSame( strLot_cassette_CheckSame_out,
//D7000026                                         strObjCommonIn,
//D7000026                                         lotID);
//D7000026            if (rc != RC_OK)
//D7000026            {
//D7000026                PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "lot_cassette_CheckSame() != RC_OK");
//D7000026                strLotInfoInqResult.strResult = strLot_cassette_CheckSame_out.strResult ;
//D7000026                return(rc);
//D7000026            }
//D7000026            if (CIMFWStrLen(strLot_cassette_CheckSame_out.cassetteID.identifier) > 0)
//D7000026            {
//D7000026                PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100",
//D7000026                                   "strLot_cassette_CheckSame_out.cassetteID.identifier) > 0");
//D7000026                if ( lotListInCassetteInfoFlag == TRUE )
//D7000026                {
//D7000026                    PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "lotListInCassetteInfoFlag == TRUE");
//D7000026
//D7000026                    objCassette_GetLotList_out   strCassette_GetLotList_out;
//D7000026                    rc = cassette_GetLotList( strCassette_GetLotList_out,
//D7000026                                              strObjCommonIn,
//D7000026                                              strLot_cassette_CheckSame_out.cassetteID);
//D7000026                    if (rc == RC_NOT_FOUND_LOT )
//D7000026                    {
//D7000026                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetLotList() == RC_NOT_FOUND_LOT");
//D7000026                        rc = RC_OK ;
//D7000026                    }
//D7000026                    else if ( rc == RC_NOT_FOUND_MATERIAL )
//D7000026                    {
//D7000026                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetLotList() == RC_NOT_FOUND_MATERIAL");
//D7000026                        rc = RC_OK ;
//D7000026                    }
//D7000026                    else if (rc != RC_OK)
//D7000026                    {
//D7000026                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetLotList() != RC_OK");
//D7000026                        strLotInfoInqResult.strResult = strCassette_GetLotList_out.strResult ;
//D7000026                        return(rc);
//D7000026                    }
//D7000026                    strLotListInCassetteInfo = strCassette_GetLotList_out.strLotListInCassetteInfo;    //P3000031
//D7000026                }
//D7000026
//D7000026                if ( waferMapInCassetteInfoFlag == TRUE )
//D7000026                {
//D7000026                    PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "waferMapInCassetteInfoFlag == TRUE");
//D7000026
//D7000026                    objCassette_GetWaferMapDR_out   strCassette_GetWaferMapDR_out;
//D7000026                    rc = cassette_GetWaferMapDR( strCassette_GetWaferMapDR_out,
//D7000026                                                 strObjCommonIn,
//D7000026                                                 strLot_cassette_CheckSame_out.cassetteID);
//D7000026                    if ( rc == RC_NOT_FOUND_LOT )
//D7000026                    {
//D7000026                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() == RC_NOT_FOUND_LOT");
//D7000026                        rc = RC_OK ;
//D7000026                    }
//D7000026                    else if ( rc == RC_NOT_FOUND_MATERIAL )
//D7000026                    {
//D7000026                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() == RC_NOT_FOUND_MATERIAL");
//D7000026                        rc = RC_OK ;
//D7000026                    }
//D7000026                    else if (rc != RC_OK)
//D7000026                    {
//D7000026                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotInfoInq__100", "cassette_GetWaferMapDR() != RC_OK");
//D7000026                        strLotInfoInqResult.strResult = strCassette_GetWaferMapDR_out.strResult ;
//D7000026                        return(rc);
//D7000026                    }
//D7000026                    strWaferMapInCassetteInfo = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo;    //P3000031
//D7000026                }
//D7000026            }
//D7000026        }
//D7000026
//D7000026        strLotInfoInqResult.strLotListInCassetteInfo  = strLotListInCassetteInfo;    //P3000031
//D7000026        strLotInfoInqResult.strWaferMapInCassetteInfo = strWaferMapInCassetteInfo;   //P3000031
//D7000026    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strLotInfoInqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txLotInfoInq__160 ");

    return( RC_OK );        //P4200553

//P4200553    return(rc);
}
