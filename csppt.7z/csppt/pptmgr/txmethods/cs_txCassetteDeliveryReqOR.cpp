#ifndef lint
static char *sccsid =  "@(#) 1.8 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txCassetteDeliveryReqOR.cpp, mm_srv_120e_ppt, mm_srv_120e_ppt 2/25/08 20:42:11 [ 2/25/08 20:42:13 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txCassetteDeliveryReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pptconvert.h"  //D9000005
#include "pptconverter.h"  //DSIV00000099

extern void traceSampledStartCassette( const pptStartCassetteSequence& strStartCassette );    //D9000003 for Cassette trace

//
// PPT Service Manager - Transaction Method Design
//
//
// Subsystem Name      : PPT Service Manager
// TX Method ID        : TXDSC008
// TX Method Name      : txCassetteDeliveryReq
// Process Description : Auto Lot Selection & Xfer Req to XMS
//
// TX Generates Return Code and Message :
//
// Return Code                             Message
// --------------------------------------- ---------------------------------------
// RC_OK                                   MSG_OK
// RC_NOT_FOUND_FILLEDCAST                 MSG_NOT_FOUND_FILLEDCAST
// RC_NOT_FOUND_EMPTYCAST                  MSG_NOT_FOUND_EMPTYCAST
// RC_NOT_FOUND_TARGET_PORT                MSG_NOT_FOUND_TARGET_PORT
// RC_INVAL_EQP_MODE                       MSG_INVAL_EQP_MODE
// RC_INVAL_EQP_STAT                       MSG_INVAL_EQP_STAT
//
// Date        Level     Author         Note
// ----------  --------  -------------  ---------------------------------------------
// 2000-11-09  D3000086  K.Matsuei      Initial Release
// 2000-11-24  0.01      O.Sugiyama     System Report
// 2000-11-29  0.02      O.Sugiyama     System Report Null Comp
// 2000-11-29  0.03      M.Mori         Loop Max
// 2000-12-05  0.04      O.Sugiyama     mail message
// 2000-12-13  0.05      M.Mori         Delivery from Eqp to Eqp
// 2001-02-16  P3100020  K.Matsuei      bug fix delivery check logic
// 2001-03-28  P3100203  M.Mori         change txWhatNextLotListInq parameter
// 2001-07-05  D4000015  H.Katoh        Add Equipment Category Check Logic because of
//                                      Internal Buffer Support
// 2001-07-12  P4000052  K.Matsuei      RTD Interface Bug Fix.
// 2001-08-17  D4000016  M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001-09-17  0.06      K.Matsuei      RTDInterface Logic ---> objmethod (cassetteDelivery_RTDInterfaceReq)
// 2001-09-17  P4000190  K.Matsuei      SystemMessage wasn't sent properly with CassetteDelivery.
// 2001-09-17  D4000184  K.Matsuei      The problem of CopperNonCopper was found with CassetteDelivery.
// 2001/10/09  P4000332  K.Matsuei      E-Mail for Error which CassetteDelivery sends is inappropriate.
// 2002/05/27  P4100480  K.Matsuei      Size of EqpID for debug is short.
// 2002/12/12  D4200189  K.Matsuei      CassetteDelivery different carrier category support.
// 2003/01/23  D4200273  K.Matsuei      TakeOut Xfer is supported under EqpState:NotAvailable, PortState:UnloadReq conditions.
// 2003/08/15  D5000194  K.Matsuei      ReRoute of Xfer is supported by CassetteDelivery.
// 2004/05/20  D5100229  H.Adachi       Remove EQP Object Locking. It is unnecessary by D5100041.
// 2004/05/25  P5100218  T.Funabiki     When StartLotsReservation of Eqp to Eqp returns error, it is sent E-MAIL.
// 2004/08/11  D51M0000  K.Tachibana    APC I/F Enhance for Interface Spec-B
// 2004/10/22  D6000025  K.Murakami     eBroker Migration.
// 2005/10/21  P6000651  K.Kido         Set Return Code.
// 2006/01/24  D7000182  H.Mutoh        Change txStartLotsReservation/CancelReq parameter
// 2006/11/20  D8000028  K.Kido         Set system message.
// 2006/12/05  D8000024  H.Mutoh        Flexible Process Condition Change (R80)
// 2007/03/15  D8000195  D.Tamura       Check new return codes of singleCarrierXferFillInTXLGC013InParm.cpp and set system message.
// 2007/04/20  D9000001  H.Murakami     64bit support.
// 2007/06/04  D9000003  M.Nakano       Add wafer sampling operation logic and e-mail send logic
// 2007/06/19  D9000005  H.Hotta        Wafer sorter automation support.(R9.0)
// 2007/09/20  D9000084  K.Kido         txEqpInfoInq ==> txEqpInfoInq__090
// 2007/09/20  D9000079  M.Murata       txEqpInfoInq ==> txEqpInfoInq__090 (Modified by D9000084 )
// 2008/02/25  D9000175  K.Kido         Support TakeOutIn transfer function.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/03 DSIV00000099 M.Ogawa        txEqpInfoInq__090 ==> txEqpInfoInq__100
// 2010/05/06 DSIV00001830 K.Yamaoku      txWhatNextLotListInq__090 ==> txWhatNextLotListInq__101
//                                        txEqpInfoInq__100 ==> txEqpInfoInq__101
// 2011/08/09 DSN000015229 Sa Guo         txEqpInfoInq__101 ==> txEqpInfoInq__120
// 2011/09/27 DSN000020767 T.Ishida       txWhatNextLotListInq__101 ==> txWhatNextLotListInq__120
// 2012/07/19 PSN000040416 Sa Guo         Fix TransactionID for controlJobStatusChangeEvent_Make
// 2012/12/20 PSN000062212 Sa Guo         Fix to return txLotCassetteTakeOutInReq error message
// 2013/04/18 PSN000073169 GC.Wang        Move check logic on port conditions (related to PSN000055527)
// 2013/07/10 DSN000081739 Sa Guo         Equipment Monitor Automation Support
// 2015/11/10 DSN000096126 C.Mo           txEqpInfoInq__120 ==> txEqpInfoInq__160
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/08 INN-R170002  JJ.Zhang       Contamination Control
//
CORBA::Long CS_PPTManager_i::txCassetteDeliveryReq(
                 pptCassetteDeliveryReqResult& strCassetteDeliveryReqResult,
                 const pptObjCommonIn& strObjCommonIn,
//D6000025                 const objectIdentifier& equipmentID,
//D6000025                 CORBA::Environment &IT_env)
                 const objectIdentifier& equipmentID //D6000025
                 CORBAENV_LAST_CPP)                  //D6000025
{
    /*----------------*/
    /*   Initialize   */
    /*----------------*/
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txCassetteDeliveryReq @Delivery@");

//P4100480    char strTrace[64];
    char strTrace[128];  //P4100480
    sprintf(strTrace, "DL@%s", (const char*)equipmentID.identifier);

    PPT_METHODTRACE_V2(strTrace, "InParam [equipmentID]", equipmentID.identifier);
    CORBA::Long rc = RC_OK;
    CORBA::Long i, j;

//D4000015 Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strCassetteDeliveryReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return( rc );
    }
//D4000015 End

//D5100229    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//D5100229    /*                                                                       */
//D5100229    /*   Object Lock Process                                                 */
//D5100229    /*                                                                       */
//D5100229    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//D5100229
//D5100229    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D5100229    PPT_METHODTRACE_V1(strTrace, "Lock objects to be updated");
//D5100229    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D5100229    /*--------------------------------*/
//D5100229    /*   Lock objects to be updated   */
//D5100229    /*--------------------------------*/
//D5100229    objObject_Lock_out strObject_Lock_out;
//D5100229    rc = object_Lock( strObject_Lock_out,
//D5100229                      strObjCommonIn,
//D5100229                      equipmentID,
//D5100229                      SP_ClassName_PosMachine );
//D5100229    if ( rc != RC_OK )
//D5100229    {
//D5100229        PPT_METHODTRACE_V1(strTrace, "object_Lock() rc != RC_OK");
//D5100229        strCassetteDeliveryReqResult.strResult = strObject_Lock_out.strResult;
//D5100229        return( rc );
//D5100229    }
    PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    PPT_METHODTRACE_V1(strTrace, "Get Equipment Infomation");
    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    /*--------------------------------*/
    /*   Get Equipment Infomation     */
    /*--------------------------------*/
//D9000084    pptEqpInfoInqResult strEqpInfoInqResult;
//DSIV00000099    pptEqpInfoInqResult__090 strEqpInfoInqResult;    //D9000084
//DSIV00001830    pptEqpInfoInqResult__100 strEqpInfoInqResult;    //DSIV00000099
//DSN000015229    pptEqpInfoInqResult__101 strEqpInfoInqResult;    //DSIV00001830
//DSN000096126    pptEqpInfoInqResult__120 strEqpInfoInqResult;    //DSN000015229
    pptEqpInfoInqResult__160 strEqpInfoInqResult;    //DSN000096126

    strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag  = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.reticleUseFlag              = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.fixtureUseFlag              = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.cassetteChangeFlag          = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.startLotsNotifyRequiredFlag = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.monitorCreationFlag         = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.eqpToEqpTransferFlag        = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.takeInOutTransferFlag       = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.emptyCassetteRequireFlag    = FALSE;
    strEqpInfoInqResult.equipmentBRInfo.SLMCapabilityFlag           = FALSE;  //DSIV00000099

//D9000084    rc = txEqpInfoInq ( strEqpInfoInqResult,
//D9000084                        strObjCommonIn,
//D9000084                        equipmentID,
//D9000084                        TRUE,      // requestFlagForBRInfo
//D9000084                        TRUE,      // requestFlagForStatusInfo
//D9000084                        FALSE,     // requestFlagForPMInfo
//D9000084                        TRUE,      // requestFlagForPortInfo
//D9000084                        FALSE,     // requestFlagForChamberInfo
//D9000084                        FALSE,     // requestFlagForStockerInfo
//D9000084                        FALSE,     // requestFlagForInprocessingLotInfo,            <NEW>
//D9000084                        FALSE);    // requestFlagForReservedControlJobInfo,         <NEW>
//D9000084    if ( rc != RC_OK )
//D9000084    {
//D9000084        PPT_METHODTRACE_V1(strTrace, "txEqpInfoInq() rc != RC_OK");
//D9000084        strCassetteDeliveryReqResult.strResult = strEqpInfoInqResult.strResult;
//D9000084        return( rc );
//D9000084    }
//DSIV00000099//D9000084 add start
//DSIV00000099    rc = txEqpInfoInq__090 ( strEqpInfoInqResult,
//DSIV00000099                             strObjCommonIn,
//DSIV00000099                             equipmentID,
//DSIV00000099                             TRUE,      // requestFlagForBRInfo
//DSIV00000099                             TRUE,      // requestFlagForStatusInfo
//DSIV00000099                             FALSE,     // requestFlagForPMInfo
//DSIV00000099                             TRUE,      // requestFlagForPortInfo
//DSIV00000099                             FALSE,     // requestFlagForChamberInfo
//DSIV00000099                             FALSE,     // requestFlagForStockerInfo
//DSIV00000099                             FALSE,     // requestFlagForInprocessingLotInfo             <NEW>
//DSIV00000099                             FALSE,     // requestFlagForReservedControlJobInfo          <NEW>
//DSIV00000099                             FALSE);    // requestFlagForRSPPortInfo                     <NEW>
//DSIV00000099    if ( rc != RC_OK )
//DSIV00000099    {
//DSIV00000099        PPT_METHODTRACE_V1(strTrace, "txEqpInfoInq__090() rc != RC_OK");
//DSIV00000099        strCassetteDeliveryReqResult.strResult = strEqpInfoInqResult.strResult;
//DSIV00000099        return( rc );
//DSIV00000099    }
//DSIV00000099//D9000084 add end
//DSIV00000099 add start
//DSIV00001830        rc = txEqpInfoInq__100( strEqpInfoInqResult, strObjCommonIn,
//DSN000015229        rc = txEqpInfoInq__101( strEqpInfoInqResult, strObjCommonIn,  //DSIV00001830
//DSN000015229                                equipmentID,
//DSN000015229                                TRUE,    //requestFlagForBRInfo
//DSN000015229                                TRUE,    //requestFlagForStatusInfo
//DSN000015229                                FALSE,   //requestFlagForPMInfo
//DSN000015229                                TRUE,    //requestFlagForPortInfo
//DSN000015229                                FALSE,   //requestFlagForChamberInfo
//DSN000015229                                FALSE,   //requestFlagForStockerInfo
//DSN000015229                                FALSE,   //requestFlagForInprocessingLotInfo
//DSN000015229                                FALSE,   //requestFlagForReservedControlJobInfo
//DSN000015229                                FALSE,   //requestFlagForRSPPortInfo
//DSN000015229                                FALSE ); //requestFlagEqpContainerInfo
//DSN000015229
//DSN000015229        if(rc != RC_OK)
//DSN000015229        {
//DSN000015229//DSIV00001830            PPT_METHODTRACE_V1("","txEqpInfoInq__100() != RC_OK");
//DSN000015229            PPT_METHODTRACE_V1("","txEqpInfoInq__101() != RC_OK");  //DSIV00001830
//DSN000015229            strCassetteDeliveryReqResult.strResult = strEqpInfoInqResult.strResult ;
//DSN000015229            return (rc);
//DSN000015229        }
//DSN000096126//DSN000015229 Add Start
//DSN000096126        rc = txEqpInfoInq__120( strEqpInfoInqResult, strObjCommonIn,
//DSN000096126                                equipmentID,
//DSN000096126                                TRUE,    //requestFlagForBRInfo
//DSN000096126                                TRUE,    //requestFlagForStatusInfo
//DSN000096126                                FALSE,   //requestFlagForPMInfo
//DSN000096126                                TRUE,    //requestFlagForPortInfo
//DSN000096126                                FALSE,   //requestFlagForChamberInfo
//DSN000096126                                FALSE,   //requestFlagForStockerInfo
//DSN000096126                                FALSE,   //requestFlagForInprocessingLotInfo
//DSN000096126                                FALSE,   //requestFlagForReservedControlJobInfo
//DSN000096126                                FALSE,   //requestFlagForRSPPortInfo
//DSN000096126                                FALSE ); //requestFlagEqpContainerInfo
//DSN000096126
//DSN000096126        if(rc != RC_OK)
//DSN000096126        {
//DSN000096126            PPT_METHODTRACE_V2("", "txEqpInfoInq__120() != RC_OK", rc);
//DSN000096126            strCassetteDeliveryReqResult.strResult = strEqpInfoInqResult.strResult ;
//DSN000096126            return (rc);
//DSN000096126        }
//DSN000096126//DSN000015229 Add End
//DSN000096126 Add Start
        rc = txEqpInfoInq__160( strEqpInfoInqResult, strObjCommonIn,
                                equipmentID,
                                TRUE,    //requestFlagForBRInfo
                                TRUE,    //requestFlagForStatusInfo
                                FALSE,   //requestFlagForPMInfo
                                TRUE,    //requestFlagForPortInfo
                                FALSE,   //requestFlagForChamberInfo
                                FALSE,   //requestFlagForStockerInfo
                                FALSE,   //requestFlagForInprocessingLotInfo
                                FALSE,   //requestFlagForReservedControlJobInfo
                                FALSE,   //requestFlagForRSPPortInfo
                                FALSE ); //requestFlagEqpContainerInfo

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "txEqpInfoInq__160() != RC_OK", rc);
            strCassetteDeliveryReqResult.strResult = strEqpInfoInqResult.strResult;
            return (rc);
        }
//DSN000096126 Add End

//DSIV00000099 add end
    PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


    /*------------------------------------------*/
    /*   Check Online Mode and Available Flag   */
    /*------------------------------------------*/
    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    PPT_METHODTRACE_V1(strTrace, "Check Online Mode and Available Flag");
    PPT_METHODTRACE_V1(strTrace, "***************************************************************");

    CORBA::Long nILen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length();
    PPT_METHODTRACE_V2(strTrace, "strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length", nILen);
    for ( i=0; i < nILen; i++ )
    {
        PPT_METHODTRACE_V2(strTrace, "-------------------------------------------------------------round[i]", i);
        PPT_METHODTRACE_V2(strTrace, "portID...............", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portID.identifier);
        PPT_METHODTRACE_V2(strTrace, "portGroup............", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup);
        PPT_METHODTRACE_V2(strTrace, "loadSequenceNumber...", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].loadSequenceNumber);
        PPT_METHODTRACE_V2(strTrace, "loadPurposeType......", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].loadPurposeType);
        PPT_METHODTRACE_V2(strTrace, "portState............", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portState);
        PPT_METHODTRACE_V2(strTrace, "operationMode........", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].operationMode);
        PPT_METHODTRACE_V2(strTrace, "onlineMode...........", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode);
        PPT_METHODTRACE_V2(strTrace, "dispatchMode.........", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].dispatchMode);
        PPT_METHODTRACE_V2(strTrace, "accessMode...........", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].accessMode);
        PPT_METHODTRACE_V1(strTrace, "");

        if ( 0 == CIMFWStrCmp(strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode, SP_Eqp_OnlineMode_Offline) )
        {
            PPT_METHODTRACE_V1(strTrace, "##### onlineMode == [Offline]");
            PPT_SET_MSG_RC_KEY2( strCassetteDeliveryReqResult, MSG_INVALID_EQP_MODE, RC_INVALID_EQP_MODE,
                                 equipmentID.identifier,
                                 strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode );
            return RC_INVALID_EQP_MODE;
        }
        else
        {
            PPT_METHODTRACE_V2(strTrace, "onlineMode is OK", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode);
        }
    }

//D4200273 start
    CORBA::String_var takeOutXferInNotAvailableState = CIMFWStrDup(getenv(SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE));
    PPT_METHODTRACE_V2("","takeOutXferInNotAvailableState",takeOutXferInNotAvailableState);
//D4200273 end

//D9000001    PPT_METHODTRACE_V2(strTrace, "equipmentAvailableFlag", (long)strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag);
    PPT_METHODTRACE_V2(strTrace, "equipmentAvailableFlag", (CORBA::Long)strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag); //D9000001
    if ( TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag && 0 != CIMFWStrCmp(takeOutXferInNotAvailableState, "1") ) //D4200273
//D4200273    if ( TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag )
    {
        PPT_METHODTRACE_V1(strTrace, "##### TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag");
        PPT_SET_MSG_RC_KEY2( strCassetteDeliveryReqResult, MSG_INVALID_EQP_STAT, RC_INVALID_EQP_STAT,
                            equipmentID.identifier, "NotAvailable" );  //D4200273
//D4200273                            equipmentID.identifier,
//D4200273                            "*****" );
        return RC_INVALID_EQP_STAT;
    }
    PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    PPT_METHODTRACE_V1(strTrace, "Sorting Port Group Info by Port Group");
    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    /*-------------------------------------------*/
    /*   Sorting Port Group Info by Port Group   */
    /*-------------------------------------------*/
    objEquipment_portInfo_SortByGroup_out strEquipment_portInfo_SortByGroup_out;
    rc = equipment_portInfo_SortByGroup( strEquipment_portInfo_SortByGroup_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1(strTrace, "##### equipment_portInfo_SortByGroup() rc != RC_OK");
        strCassetteDeliveryReqResult.strResult = strEquipment_portInfo_SortByGroup_out.strResult;
        return( rc );
    }
    PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    PPT_METHODTRACE_V1(strTrace, "Pick Up Target Port");
    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    /*------------------------*/
    /*   Pick Up Target Port  */
    /*------------------------*/
    objEquipment_targetPort_Pickup_out strEquipment_targetPort_Pickup_out;

    strEquipment_targetPort_Pickup_out.whatsNextRequireFlag = FALSE;

//DSIV00000099 add start
    pptEqpBrInfo strEqpBrInfo;
    PPTConverter converter;
//DSIV00001830    converter.Convert100_to_080( strEqpInfoInqResult.equipmentBRInfo, strEqpBrInfo );
//DSN000015229    converter.Convert101_to_080( strEqpInfoInqResult.equipmentBRInfo, strEqpBrInfo );  //DSIV00001830
    converter.Convert120_to_080( strEqpInfoInqResult.equipmentBRInfo, strEqpBrInfo );  //DSN000015229

    rc = equipment_targetPort_Pickup( strEquipment_targetPort_Pickup_out,
                                      strObjCommonIn,
                                      strEquipment_portInfo_SortByGroup_out.strEqpPortInfoOrderByGroup,
                                      strEqpBrInfo,
                                      strEqpInfoInqResult.equipmentPortInfo );
//DSIV00000099 add end

//DSIV00000099    rc = equipment_targetPort_Pickup( strEquipment_targetPort_Pickup_out,
//DSIV00000099                                      strObjCommonIn,
//DSIV00000099                                      strEquipment_portInfo_SortByGroup_out.strEqpPortInfoOrderByGroup,
//DSIV00000099                                      strEqpInfoInqResult.equipmentBRInfo,          //P3100020
//DSIV00000099                                      strEqpInfoInqResult.equipmentPortInfo );      //P3100020
//P3100020                                      strEqpInfoInqResult.equipmentBRInfo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1(strTrace, "##### equipment_targetPort_Pickup() rc != RC_OK");
        strCassetteDeliveryReqResult.strResult = strEquipment_targetPort_Pickup_out.strResult;
        return( rc );
    }
    PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

//VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV
{
    PPT_METHODTRACE_V1(strTrace, "VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
    CORBA::Long ii, jj, kk;
    CORBA::Long len1 = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup.length();
    PPT_METHODTRACE_V2(strTrace, "len1--->", len1);
    for (ii=0; ii < len1; ii++)
    {
        PPT_METHODTRACE_V2(strTrace, "portGroup--->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].portGroup);
        CORBA::Long len2 = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID.length();
        PPT_METHODTRACE_V2(strTrace, "len2--->", len2);
        for (jj=0; jj < len2; jj++)
        {
            PPT_METHODTRACE_V2(strTrace, "portID                   --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portID.identifier);
            PPT_METHODTRACE_V2(strTrace, "loadSequenceNoInPortGroup--->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].loadSequenceNoInPortGroup);
            PPT_METHODTRACE_V2(strTrace, "portUsage                --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portUsage);
            PPT_METHODTRACE_V2(strTrace, "usageType                --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].usageType);
            PPT_METHODTRACE_V2(strTrace, "loadPurposeType          --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].loadPurposeType);
            PPT_METHODTRACE_V2(strTrace, "portState                --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portState);
            PPT_METHODTRACE_V2(strTrace, "cassetteID               --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].cassetteID.identifier);
            PPT_METHODTRACE_V2(strTrace, "dispatchState            --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchState);
            PPT_METHODTRACE_V2(strTrace, "dispatchState_TimeStamp  --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchState_TimeStamp);
            PPT_METHODTRACE_V2(strTrace, "dispatchLoadLotID        --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchLoadLotID.identifier);
            PPT_METHODTRACE_V2(strTrace, "dispatchLoadCassetteID   --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchLoadCassetteID.identifier);
            PPT_METHODTRACE_V2(strTrace, "dispatchUnloadLotID      --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchUnloadLotID.identifier);
            PPT_METHODTRACE_V2(strTrace, "dispatchUnloadCassetteID --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchUnloadCassetteID.identifier);

            CORBA::Long len3 = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].strLotInfoOnPort.length();
            PPT_METHODTRACE_V2(strTrace, "len3--->", len3);
            for (kk=0; kk < len3; kk++)
            {
                PPT_METHODTRACE_V2(strTrace, "  lotID                  --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].strLotInfoOnPort[kk].lotID.identifier);
                PPT_METHODTRACE_V2(strTrace, "  lotType                --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].strLotInfoOnPort[kk].lotType);
            }
        }
    }
    PPT_METHODTRACE_V1(strTrace, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
}
//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    PPT_METHODTRACE_V1(strTrace, "Check Target Port Count");
    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
    /*----------------------------*/
    /*   Check Target Port Count  */
    /*----------------------------*/
    CORBA::Long lenPortGroup = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup.length();
    PPT_METHODTRACE_V2(strTrace, "Target Port Group count--->", lenPortGroup);
    if ( 0 == lenPortGroup )
    {
        PPT_METHODTRACE_V1(strTrace, "##### 0 == lenPortGroup");
        SET_MSG_RC( strCassetteDeliveryReqResult, MSG_NOT_FOUND_TARGET_PORT, RC_NOT_FOUND_TARGET_PORT);
        return RC_NOT_FOUND_TARGET_PORT;
    }
    PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    objectIdentifier dummy;             //0.06
    CORBA::Boolean bLoadReqFlag = TRUE;
    CORBA::Long nPortLen;

    char  *tmpAPCIFControlStatus = NULL;      //D7000182
    CORBA::String_var  APCIFControlStatus;    //D7000182

    PPT_METHODTRACE_V2(strTrace, "targetPortType", strEquipment_targetPort_Pickup_out.targetPortType);
    /*--------------------*/
    /*   Unload Request   */
    /*--------------------*/
    if ( 0 == CIMFWStrCmp(strEquipment_targetPort_Pickup_out.targetPortType, SP_PortRsc_PortState_UnloadReq) )
    {
        PPT_METHODTRACE_V1(strTrace, "");
        PPT_METHODTRACE_V1(strTrace, "***************************************************************");
        PPT_METHODTRACE_V1(strTrace, "Unload Request");
        PPT_METHODTRACE_V1(strTrace, "***************************************************************");

        bLoadReqFlag = FALSE;

//P3100020 start   Do this check with equipment_targetPort_Pickup.
//P3100020
//P3100020        PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//P3100020        PPT_METHODTRACE_V1(strTrace, "Check Port Dispatch Mode");
//P3100020        PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//P3100020        /*------------------------------*/
//P3100020        /*   Check Port Dispatch Mode   */
//P3100020        /*------------------------------*/
//P3100020        nPortLen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length();
//P3100020        PPT_METHODTRACE_V2(strTrace, "nPortLen", nPortLen);
//P3100020        for ( i=0; i < nPortLen; i++ )
//P3100020        {
//P3100020            PPT_METHODTRACE_V2(strTrace, "dispatchMode", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].dispatchMode);
//P3100020            PPT_METHODTRACE_V2(strTrace, "accessMode  ", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].accessMode);
//P3100020
//P3100020            if ( 0 != CIMFWStrCmp(strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].dispatchMode, SP_Eqp_DispatchMode_Auto)
//P3100020              || 0 != CIMFWStrCmp(strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].accessMode, SP_Eqp_AccessMode_Auto) )
//P3100020            {
//P3100020                PPT_METHODTRACE_V1(strTrace, "RC_INVALID_EQP_STAT!!");
//P3100020                SET_MSG_RC( strCassetteDeliveryReqResult, MSG_INVALID_EQP_STAT, RC_INVALID_EQP_STAT );
//P3100020                return( RC_INVALID_EQP_STAT );
//P3100020            }
//P3100020        }
//P3100020 end

        PPT_METHODTRACE_V1(strTrace, "***************************************************************");
        PPT_METHODTRACE_V1(strTrace, "Check Lot Process State");
        PPT_METHODTRACE_V1(strTrace, "***************************************************************");
        /*-----------------------------*/
        /*   Check Lot Process State   */
        /*-----------------------------*/
//P3100020 start
        PPT_METHODTRACE_V2(strTrace, "TergetPort [PortGroupID]", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].portGroup);

        nPortLen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length();
        PPT_METHODTRACE_V2(strTrace, "strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length", nPortLen);
        for ( i=0; i < nPortLen; i++ )
        {
            PPT_METHODTRACE_V2(strTrace, "EqpInfo [PortGroupID]", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup);

            // check is targetPortInfo only
            if ( 0 == CIMFWStrCmp(strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].portGroup,
                                  strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup) )
            {
                PPT_METHODTRACE_V1(strTrace, "TergetPortGropuID == EqpInfoPortGroupID");

                CORBA::Long nLotOnPortLen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].strLotOnPort.length();
                PPT_METHODTRACE_V2(strTrace, "nLotOnPortLen--->", nLotOnPortLen);

                for ( j=0; j < nLotOnPortLen; j++ )
                {
                    PPT_METHODTRACE_V2(strTrace, "EqpInfo [lotID]", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].strLotOnPort[j].lotID.identifier);

                    objLot_processState_Get_out strLot_processState_Get_out;
                    rc = lot_processState_Get(strLot_processState_Get_out, strObjCommonIn,
                                              strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].strLotOnPort[j].lotID );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1(strTrace, "##### lot_processState_Get() rc != RC_OK");
                        strCassetteDeliveryReqResult.strResult = strLot_processState_Get_out.strResult;
                        return( rc );
                    }

                    PPT_METHODTRACE_V2(strTrace, "theLotProcessState", strLot_processState_Get_out.theLotProcessState);

                    if ( 0 == CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) )
                    {
                        PPT_METHODTRACE_V1(strTrace, "strLot_processState_Get_out.theLotProcessState == SP_Lot_ProcState_Processing");
                        PPT_METHODTRACE_V1(strTrace, "##### Cancel UnloadReq #####");
                        bLoadReqFlag = TRUE;        // Cancel UnloadReq
                        break;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V2(strTrace, "NoCheck ignore [PortGropuID]", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup);
            }
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
//P3100020 end
//P3100020 start
//P3100020        for (i=0; i < nPortLen; i++ )
//P3100020        {
//P3100020            CORBA::Long nLotOnPortLen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].strLotOnPort.length();
//P3100020            PPT_METHODTRACE_V2(strTrace, "nLotOnPortLen--->", nLotOnPortLen);
//P3100020            for ( j=0; j < nLotOnPortLen; j++ )
//P3100020            {
//P3100020                PPT_METHODTRACE_V2(strTrace, "lotID", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].strLotOnPort[j].lotID.identifier);
//P3100020
//P3100020                objLot_processState_Get_out strLot_processState_Get_out;
//P3100020
//P3100020                rc = lot_processState_Get(strLot_processState_Get_out, strObjCommonIn,
//P3100020                                          strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].strLotOnPort[j].lotID );
//P3100020
//P3100020                if ( rc != RC_OK )
//P3100020                {
//P3100020                    PPT_METHODTRACE_V1(strTrace, "lot_processState_Get() rc != RC_OK");
//P3100020                    strCassetteDeliveryReqResult.strResult = strLot_processState_Get_out.strResult;
//P3100020                    return( rc );
//P3100020                }
//P3100020
//P3100020                PPT_METHODTRACE_V2(strTrace, "theLotProcessState", strLot_processState_Get_out.theLotProcessState);
//P3100020
//P3100020                if ( 0 == CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) )
//P3100020                {
//P3100020                    PPT_METHODTRACE_V1(strTrace, "strLot_processState_Get_out.theLotProcessState == SP_Lot_ProcState_Processing");
//P3100020                    PPT_METHODTRACE_V1(strTrace, "!!!!! Cancel UnloadReq !!!!!");
//P3100020                    bLoadReqFlag = TRUE;        // Cancel UnloadReq
//P3100020                    break;
//P3100020                }
//P3100020            }
//P3100020        }
//P3100020 end
//D9000175 add start
        /*--------------------------------------------------------*/
        /*   Check equipment availability of TakeOutIn transfer   */
        /*--------------------------------------------------------*/
        objEquipment_TakeOutInMode_Check_out strEquipment_TakeOutInMode_Check_out;
        objEquipment_TakeOutInMode_Check_in strEquipment_TakeOutInMode_Check_in;
        strEquipment_TakeOutInMode_Check_in.equipmentID = equipmentID;
        rc = equipment_TakeOutInMode_Check( strEquipment_TakeOutInMode_Check_out, strObjCommonIn,
                                            strEquipment_TakeOutInMode_Check_in);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "equipment_TakeOutInMode_Check() != RC_OK" );
            strCassetteDeliveryReqResult.strResult = strEquipment_TakeOutInMode_Check_out.strResult;
            return( rc );
        }

        CORBA::Long eqpTakeOutInSupport = strEquipment_TakeOutInMode_Check_out.eqpTakeOutInSupport;
        PPT_METHODTRACE_V2( "", "eqpTakeOutInSupport = ",eqpTakeOutInSupport );
//D9000175 add end

//0.05 add start
        if ( bLoadReqFlag == FALSE )
        {
            PPT_METHODTRACE_V1(strTrace, "bLoadReqFlag == FALSE");

            if ( TRUE == strEqpInfoInqResult.equipmentBRInfo.eqpToEqpTransferFlag )
            {
                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                PPT_METHODTRACE_V1(strTrace, "UnLoadReq Process RUN!!  EQP -> EQP");
                PPT_METHODTRACE_V1(strTrace, "***************************************************************");

                /*------------------------------*/
                /*   get whereNextTransferEqp   */
                /*------------------------------*/
                PPT_METHODTRACE_V1(strTrace, "// get whereNextTransferEqp");
                objWhereNextTransferEqp_out_struct strWhereNextTransferEqp_struct_out;
                rc = whereNextTransferEqp( strWhereNextTransferEqp_struct_out,
                                           strObjCommonIn,
                                           equipmentID,
                                           strEquipment_targetPort_Pickup_out );

                if (rc == RC_OK)
                {
                    PPT_METHODTRACE_V1(strTrace, "whereNextTransferEqp() rc == RC_OK");

                    PPT_METHODTRACE_V2(strTrace, "Reservation [equipmentID] --->", strWhereNextTransferEqp_struct_out.equipmentID.identifier);
                    PPT_METHODTRACE_V2(strTrace, "Reservation [portGroup] ----->", strWhereNextTransferEqp_struct_out.portGroup);

//D8000024 add start
//D9000001                    CORBA::Long tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
                    CORBA::Long tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
                    if( 1 == tmpFPCAdoptFlag )
                    {
                        PPT_METHODTRACE_V1("", "FPC adopt Flag is ON. New apply FPCInfo.");
                        objFPCStartCassetteInfo_Exchange_out strFPCStartCassetteInfo_Exchange_out;
                        rc = FPCStartCassetteInfo_Exchange( strFPCStartCassetteInfo_Exchange_out,
                                                            strObjCommonIn,
                                                            SP_FPC_ExchangeType_StartReserveInfo,
                                                            equipmentID,
                                                            strWhereNextTransferEqp_struct_out.strStartCassette );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "FPCStartCassetteInfo_Exchange() != RC_OK", rc);
                            strCassetteDeliveryReqResult.strResult = strFPCStartCassetteInfo_Exchange_out.strResult;
                            return rc;
                        }
                        strWhereNextTransferEqp_struct_out.strStartCassette = strFPCStartCassetteInfo_Exchange_out.strStartCassette;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "FPC adopt Flag is OFF.");
                    }
//D8000024 add end

//D9000003 add start
                    PPT_METHODTRACE_V1("","Set processJobExecFlag based on wafer sampling setting. ");
                    CORBA::Boolean notSendIgnoreMail = FALSE;
                    CORBA::Long startCassette_processJobExecFlag_SetRc = RC_OK;
                    objStartCassette_processJobExecFlag_Set_out__090 strStartCassette_processJobExecFlag_Set_out__090;
                    objStartCassette_processJobExecFlag_Set_in__090 strStartCassette_processJobExecFlag_Set_in__090;
                    strStartCassette_processJobExecFlag_Set_in__090.strStartCassette = strWhereNextTransferEqp_struct_out.strStartCassette;
                    strStartCassette_processJobExecFlag_Set_in__090.equipmentID = strWhereNextTransferEqp_struct_out.equipmentID;

                    rc = startCassette_processJobExecFlag_Set__090(strStartCassette_processJobExecFlag_Set_out__090, strObjCommonIn, strStartCassette_processJobExecFlag_Set_in__090);
                    PPT_METHODTRACE_V2("", "startCassette_processJobExecFlag_Set__090(): rc", rc);
                    if( rc != RC_NO_SMPL_SETTING && rc != RC_OK)
                    {
                        // When errors have occurred, hold all the error lot and send e-mail to notify that.
                        notSendIgnoreMail = TRUE;
                        strCassetteDeliveryReqResult.strResult = strStartCassette_processJobExecFlag_Set_out__090.strResult;
                        startCassette_processJobExecFlag_SetRc = RC_INVALID_SMPL_SETTING;
                    }

                    CORBA::Long mailLen = strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length();
                    //hold lots and send E-Mails if error
                    for(CORBA::Long mailCnt = 0; mailCnt < mailLen; mailCnt++)
                    {
                        if( (strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType == SP_Sampling_error_mail)
                            || (strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType == SP_Sampling_warn_mail))
                        {
                            PPT_METHODTRACE_V1("", "messageType == SP_Sampling_error_mail || SP_Sampling_warn_mail ");

                            // Lot Hold
                            objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                            rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                               strObjCommonIn,
                                                               strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].lotID ) ;

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                                strCassetteDeliveryReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult ;
                                return (rc) ;
                            }

                            pptHoldLotReqResult strHoldLotReqResult ;
                            pptHoldListSequence strLotHoldReqList ;
                            strLotHoldReqList.length( 1 ) ;

                            strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold ) ;
                            strLotHoldReqList[0].holdReasonCodeID.identifier          = CIMFWStrDup( SP_Reason_WaferSamplingHold );
                            strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
                            strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
                            strLotHoldReqList[0].routeID                  = strLot_currentOperationInfo_Get_out.routeID ;
                            strLotHoldReqList[0].operationNumber          = strLot_currentOperationInfo_Get_out.operationNumber ;
                            strLotHoldReqList[0].claimMemo                = CIMFWStrDup("");

                            rc = txHoldLotReq( strHoldLotReqResult,
                                               strObjCommonIn ,
                                               strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].lotID,
                                               strLotHoldReqList ) ;

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                                strCassetteDeliveryReqResult.strResult = strHoldLotReqResult.strResult ;
                                return( rc );
                            }
                        }  //end if (messageType ==  SP_Sampling_error_mail || SP_Sampling_warn_mail)

                        //error Mail Set
                        if( notSendIgnoreMail == FALSE ||  strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType != SP_Sampling_ignored_mail )
                        {
                            PPT_METHODTRACE_V1("", "notSendIgnoreMail == FALSE ||  strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType != SP_Sampling_ignored_mail") ;

                            //When notSendIgnoreMail == TRUE, just the Lot Hold mail is to be sent.
                            ostrstream messageText;
                            if(strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType == SP_Sampling_warn_mail)
                            {
                                PPT_METHODTRACE_V1("", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType == SP_Sampling_warn_mail") ;
                                //-------------------------------------------------------------------
                                // create mail text if message type == SP_Sampling_warn_mail;
                                // startCassette_processJobExecFlag_Set__090 returns just error text. Caller should switch text handling.
                                //-------------------------------------------------------------------
                                objLot_samplingMessage_Create_out strLot_samplingMessage_Create_out;
                                objLot_samplingMessage_Create_in strLot_samplingMessage_Create_in;
                                strLot_samplingMessage_Create_in.lotID = strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].lotID;
                                strLot_samplingMessage_Create_in.messageType = SP_Sampling_error_mail;
                                strLot_samplingMessage_Create_in.messageText = strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageText;

                                rc = lot_samplingMessage_Create(strLot_samplingMessage_Create_out, strObjCommonIn, strLot_samplingMessage_Create_in);
                                if(rc != RC_OK)
                                {
                                    PPT_METHODTRACE_V1("", "lot_samplingMessage_Create() != RC_OK") ;
                                    strCassetteDeliveryReqResult.strResult = strLot_samplingMessage_Create_out.strResult;
                                    return rc;
                                }
                                messageText << strLot_samplingMessage_Create_out.message;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType != SP_Sampling_warn_mail") ;
                                messageText << strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageText;
                            }
                            messageText << ends;
                            PPT_METHODTRACE_V2("", "messageText", messageText.str()) ;
                            /*------------------------*/
                            /*   Set System Message   */
                            /*------------------------*/
                            PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                            PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   For wafer sampling                 */");
                            PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                            objectIdentifier dummy;
                            pptSysMsgStockInfo sysMsg;
                            sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                            sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_SMPLERR );
                            sysMsg.systemMessageText      = CIMFWStrDup( messageText.str() );
                            sysMsg.notifyFlag             = TRUE;
                            sysMsg.equipmentID            = strWhereNextTransferEqp_struct_out.equipmentID;
                            sysMsg.equipmentStatus        = CIMFWStrDup("");
                            sysMsg.stockerID              = dummy;
                            sysMsg.stockerStatus          = CIMFWStrDup("");
                            sysMsg.AGVID                  = dummy;
                            sysMsg.AGVStatus              = CIMFWStrDup("");
                            sysMsg.lotID                  = strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].lotID;
                            sysMsg.lotStatus              = CIMFWStrDup("");
                            sysMsg.routeID                = dummy;
                            sysMsg.operationID            = dummy;
                            sysMsg.operationNumber        = CIMFWStrDup("");
                            sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                            CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                            strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                            strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
                            messageText.rdbuf()->freeze(0);
                        }
                    } //end for-Loop
                    if(notSendIgnoreMail == TRUE)
                    {
                        PPT_METHODTRACE_V2("", "notSendIgnoreMail == TRUE  return this TX.",startCassette_processJobExecFlag_SetRc) ;
                        strCassetteDeliveryReqResult.strResult = strStartCassette_processJobExecFlag_Set_out__090.strResult;
                        return startCassette_processJobExecFlag_SetRc;
                    }

                    //valid check of processJobExecFlag for each lot.
                    //Check every lot has at least one wafer with processJobExecFlag == TRUE
                    objLot_processJobExecFlag_ValidCheck_out strLot_processJobExecFlag_ValidCheck_out;
                    objLot_processJobExecFlag_ValidCheck_in strLot_processJobExecFlag_ValidCheck_in;
                    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = strStartCassette_processJobExecFlag_Set_out__090.strStartCassette;

                    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
                    PPT_METHODTRACE_V2("", "lot_processJobExecFlag_ValidCheck(): rc", rc);
                    if( rc != RC_OK && rc != RC_NO_PROCESSJOBEXECFLAG)
                    {
                        PPT_METHODTRACE_V1("", "lot_processJobExecFlag_ValidCheck() != RC_OK && != RC_NO_PROCESSJOBEXECFLAG") ;
                        strCassetteDeliveryReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
                        return rc;
                    }
                    if( rc == RC_NO_PROCESSJOBEXECFLAG)
                    {
                        PPT_METHODTRACE_V1(strTrace, "objLot_processJobExecFlag_ValidCheck() rc == RC_NO_PROCESSJOBEXECFLAG");
                        // Lot Hold + error mail
                        // create hold mail message
                        objLot_samplingMessage_Create_out strLot_samplingMessage_Create_out;
                        objLot_samplingMessage_Create_in strLot_samplingMessage_Create_in;
                        strLot_samplingMessage_Create_in.lotID = strLot_processJobExecFlag_ValidCheck_out.lotID;
                        strLot_samplingMessage_Create_in.messageType = SP_Sampling_error_mail;
                        strLot_samplingMessage_Create_in.messageText = strLot_processJobExecFlag_ValidCheck_out.strResult.messageText;
                        rc = lot_samplingMessage_Create(strLot_samplingMessage_Create_out, strObjCommonIn, strLot_samplingMessage_Create_in);

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_samplingMessage_Create() != RC_OK", rc);
                            strCassetteDeliveryReqResult.strResult = strLot_samplingMessage_Create_out.strResult ;
                            return (rc) ;
                        }

                        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                           strObjCommonIn,
                                                           strLot_processJobExecFlag_ValidCheck_out.lotID ) ;
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                            strCassetteDeliveryReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult ;
                            return (rc) ;
                        }

                        pptHoldLotReqResult strHoldLotReqResult ;
                        pptHoldListSequence strLotHoldReqList ;
                        strLotHoldReqList.length( 1 ) ;

                        strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold ) ;
                        strLotHoldReqList[0].holdReasonCodeID.identifier          = CIMFWStrDup( SP_Reason_WaferSamplingHold );
                        strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
                        strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
                        strLotHoldReqList[0].routeID                  = strLot_currentOperationInfo_Get_out.routeID ;
                        strLotHoldReqList[0].operationNumber          = strLot_currentOperationInfo_Get_out.operationNumber ;
                        strLotHoldReqList[0].claimMemo                = CIMFWStrDup("");

                        PPT_METHODTRACE_V1("", "txHoldLotReq() execute ");
                        rc = txHoldLotReq( strHoldLotReqResult,
                                           strObjCommonIn ,
                                           strLot_processJobExecFlag_ValidCheck_out.lotID,
                                           strLotHoldReqList ) ;

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                            strCassetteDeliveryReqResult.strResult = strHoldLotReqResult.strResult ;
                            return( rc );
                        }

                        //error Mail Set

                        /*------------------------*/
                        /*   Set System Message   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                        PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   For wafer sampling                 */");
                        PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                        objectIdentifier dummy;
                        pptSysMsgStockInfo sysMsg;
                        sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                        sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_SMPLERR );
                        sysMsg.systemMessageText      = CIMFWStrDup( strLot_samplingMessage_Create_out.message );
                        sysMsg.notifyFlag             = TRUE;
                        sysMsg.equipmentID            = strWhereNextTransferEqp_struct_out.equipmentID;
                        sysMsg.equipmentStatus        = CIMFWStrDup("");
                        sysMsg.stockerID              = dummy;
                        sysMsg.stockerStatus          = CIMFWStrDup("");
                        sysMsg.AGVID                  = dummy;
                        sysMsg.AGVStatus              = CIMFWStrDup("");
                        sysMsg.lotID                  = strLot_processJobExecFlag_ValidCheck_out.lotID;
                        sysMsg.lotStatus              = CIMFWStrDup("");
                        sysMsg.routeID                = dummy;
                        sysMsg.operationID            = dummy;
                        sysMsg.operationNumber        = CIMFWStrDup("");
                        sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                        CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;

                        strCassetteDeliveryReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
                        return RC_NO_PROCESSJOBEXECFLAG;

                    } //end if (rc == RC_NO_PROCESSJOBEXECFLAG)

                    traceSampledStartCassette(strStartCassette_processJobExecFlag_Set_out__090.strStartCassette);  //D9000003

                    strWhereNextTransferEqp_struct_out.strStartCassette = strStartCassette_processJobExecFlag_Set_out__090.strStartCassette;
                    PPT_METHODTRACE_V1("","Set processJobExecFlag based on wafer sampling setting end. ");

//D9000003 add end

                    /*--------------------------------------*/
                    /*   Request to Start Lot Reservation   */
                    /*--------------------------------------*/
                    PPT_METHODTRACE_V1(strTrace, "// Request to Start Lot Reservation");
                    objectIdentifier dummy;
                    pptStartLotsReservationReqResult strStartLotsReservationReqResult;
//PSN000040416 start
                    // Change TransactionID
                    pptObjCommonIn strTmpObjCommonIn;
                    strTmpObjCommonIn = strObjCommonIn;
                    strTmpObjCommonIn.transactionID = CIMFWStrDup("TXTRC041");  // TransactionID of TxStartLotsReservationReq
//PSN000040416 end
                    rc = txStartLotsReservationReq( strStartLotsReservationReqResult,
//PSN000040416                                                    strObjCommonIn,
                                                    strTmpObjCommonIn,        //PSN000040416
                                                    strWhereNextTransferEqp_struct_out.equipmentID,
                                                    strWhereNextTransferEqp_struct_out.portGroup,
                                                    dummy,
                                                    strWhereNextTransferEqp_struct_out.strStartCassette,
//D7000182                                                    "" );
                                                    "",                       //D7000182
                                                    tmpAPCIFControlStatus );  //D7000182
                    APCIFControlStatus = CIMFWStrDup(tmpAPCIFControlStatus);  //D7000182
                    CORBA::string_free(tmpAPCIFControlStatus);                //D7000182
                    tmpAPCIFControlStatus = NULL;                             //D7000182

                    if (rc == RC_OK)
                    {
                        PPT_METHODTRACE_V1(strTrace, "txStartLotsReservationReq() == RC_OK");

                        /*------------------------------------------*/
                        /*   Make txMultiCarrierXferReq parameter   */
                        /*------------------------------------------*/
                        PPT_METHODTRACE_V1(strTrace, "// Make txMultiCarrierXferReq parameter");
                        objMultiCarrierXferFillInTXLGC012InParm_out strMultiCarrierXferFillInTXLGC012InParm_out;
                        rc = multiCarrierXferFillInTXLGC012InParm( strMultiCarrierXferFillInTXLGC012InParm_out,
                                                                   strObjCommonIn,
                                                                   strWhereNextTransferEqp_struct_out.equipmentID,
                                                                   strWhereNextTransferEqp_struct_out.strStartCassette );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1(strTrace, "##### multiCarrierXferFillInTXLGC012InParm() rc != RC_OK");
                            strCassetteDeliveryReqResult.strResult = strMultiCarrierXferFillInTXLGC012InParm_out.strResult;

                            PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------*/");
                            PPT_METHODTRACE_V1(strTrace, "/*   Request to Start Lot Reservation Cancel   */");
                            PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------*/");

                            CORBA::Long saveRC = rc;
                            /*---------------------------------------------*/
                            /*   Request to Start Lot Reservation Cancel   */
                            /*---------------------------------------------*/
                            pptStartLotsReservationCancelReqResult strStartLotsReservationCancelReqResult;
                            rc = txStartLotsReservationCancelReq ( strStartLotsReservationCancelReqResult,
                                                                   strObjCommonIn,
                                                                   strWhereNextTransferEqp_struct_out.equipmentID,
                                                                   strStartLotsReservationReqResult.controlJobID,
//D7000182                                                                   "" );
                                                                   "",                       //D7000182
                                                                   tmpAPCIFControlStatus );  //D7000182
                            APCIFControlStatus = CIMFWStrDup(tmpAPCIFControlStatus);         //D7000182
                            CORBA::string_free(tmpAPCIFControlStatus);                       //D7000182
                            tmpAPCIFControlStatus = NULL;                                    //D7000182

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1(strTrace, "txStartLotsReservationCancelReq != RC_OK");
                            }

                            rc = saveRC;
                            return( rc );
//                          return ( RC_START_LOT_RESERVATION_FAIL );
                        }

//D9000175 add start
                        /*****************************************/
                        /*                                       */
                        /*         TakeOutIn transfer            */
                        /*                                       */
                        /*****************************************/
                        /*------------------------------------------------------------*/
                        /*   Check takeOutIn transfer function enable. (EQP -> EQP)   */
                        /*------------------------------------------------------------*/
                        PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                        PPT_METHODTRACE_V1(strTrace, "/*   Check takeOutIn transfer function enable. (EQP -> EQP)   */");
                        PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                        if( 1 == eqpTakeOutInSupport )
                        {
                            PPT_METHODTRACE_V1("","##### TakeOutIn enable for this equipment. Call txLotCassetteTakeOutInReq() ");
                            pptLotCassetteTakeOutInReqResult strLotCassetteTakeOutInReqResult;
                            pptLotCassetteTakeOutInReqInParm strLotCassetteTakeOutInReqInParm;
                            strLotCassetteTakeOutInReqInParm.EqpToEqpFlag = TRUE;
                            strLotCassetteTakeOutInReqInParm.equipmentID  = equipmentID;
                            strLotCassetteTakeOutInReqInParm.controlJobID = strStartLotsReservationReqResult.controlJobID;
                            strLotCassetteTakeOutInReqInParm.strEqpTargetPortInfo = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo;
                            strLotCassetteTakeOutInReqInParm.strCarrierXferReqSeq = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq;

                            //Call txLotCassetteTakeOutInReq
                            rc = txLotCassetteTakeOutInReq( strLotCassetteTakeOutInReqResult,
                                                            strObjCommonIn,
                                                            strLotCassetteTakeOutInReqInParm,
                                                            "" ); //claimMemo

                            // Set mail information even if the transaction returns error.
                            CORBA::ULong sysMsgLen = strLotCassetteTakeOutInReqResult.strSysMsgStockInfoSeq.length();
                            for( CORBA::ULong i = 0 ; i < sysMsgLen ; i++ )
                            {
                                CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                                strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                                strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = strLotCassetteTakeOutInReqResult.strSysMsgStockInfoSeq[i];
                            }

                            if(rc != RC_OK)
                            {
                                PPT_METHODTRACE_V1("","### txLotCassetteTakeOutInReq() != RC_OK");
                                strCassetteDeliveryReqResult.strResult = strLotCassetteTakeOutInReqResult.strResult;   //PSN000062212
                                return rc;
                            }

                            /*--------------------*/
                            /*   Return to Main   */
                            /*--------------------*/
                            PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                            PPT_METHODTRACE_V1(strTrace, "@@@@@ OK! OK! OK! [EQP to EQP with TakeOutIn]  Return to Main");
                            PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

                            return RC_OK;
                        }
                        else
                        {
//D9000175 add end
                        PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------*/");
                        PPT_METHODTRACE_V1(strTrace, "/*   Send Transfer Request to XM. (EQP -> EQP)   */");
                        PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------*/");
                        /*-----------------------------------------------*/
                        /*   Send Transfer Request to XM. (EQP -> EQP)   */
                        /*-----------------------------------------------*/
                        pptMultiCarrierXferReqResult strMultiCarrierXferReqResult;
                        rc = txMultiCarrierXferReq( strMultiCarrierXferReqResult,
                                                    strObjCommonIn,
                                                    FALSE,        // const : FALSE
                                                    "S",          // const : "S"
                                                    strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1(strTrace, "##### txMultiCarrierXferReq() rc != RC_OK");
                            strCassetteDeliveryReqResult.strResult = strMultiCarrierXferReqResult.strResult;

//P4000332 start
                            //-------------------------------------------------------
                            // Prepare e-mail Message Text
                            //-------------------------------------------------------
                            CORBA::String_var msg;
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Transfer Error!  (EQP -> EQP) >>>" );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );

                            CORBA::Long ii, jj;
                            CORBA::Long lenCarrierXfer = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq.length();
                            for ( ii=0; ii < lenCarrierXfer; ii++ )
                            {
                                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
                                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].carrierID.identifier );
                                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
                                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].lotID.identifier );
                                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
                                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].fromMachineID.identifier );
                                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
                                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].fromPortID.identifier );
                                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
                                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].toStockerGroup );

                                CORBA::Long lenToEqp = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine.length();
                                if ( 0 == lenToEqp )
                                {
                                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
                                }
                                for ( jj=0; jj < lenToEqp; jj++ )
                                {
                                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
                                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine[jj].toMachineID.identifier );
                                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
                                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine[jj].toPortID.identifier );
                                }
                            }
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.transactionID );
                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.returnCode );
                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.messageID );
                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.messageText );
                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.reasonText );

                            PPT_METHODTRACE_V2("", "messageText--->", msg);

                            /*------------------------*/
                            /*   Set System Message   */
                            /*------------------------*/
                            PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                            PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   txMultiCarrierXferReq() != RC_OK   */");
                            PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                            pptSysMsgStockInfo sysMsg;
                            sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                            sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                            sysMsg.systemMessageText      = CIMFWStrDup( msg );
                            sysMsg.notifyFlag             = TRUE;
                            sysMsg.equipmentID            = equipmentID;
                            sysMsg.equipmentStatus        = CIMFWStrDup("");
                            sysMsg.stockerID              = dummy;
                            sysMsg.stockerStatus          = CIMFWStrDup("");
                            sysMsg.AGVID                  = dummy;
                            sysMsg.AGVStatus              = CIMFWStrDup("");
                            sysMsg.lotID                  = dummy;
                            sysMsg.lotStatus              = CIMFWStrDup("");
                            sysMsg.routeID                = dummy;
                            sysMsg.operationID            = dummy;
                            sysMsg.operationNumber        = CIMFWStrDup("");
                            sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                            CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                            strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                            strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
//P4000332 end

                            PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------*/");
                            PPT_METHODTRACE_V1(strTrace, "/*   Request to Start Lot Reservation Cancel   */");
                            PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------*/");

                            CORBA::Long saveRC = rc;
                            /*---------------------------------------------*/
                            /*   Request to Start Lot Reservation Cancel   */
                            /*---------------------------------------------*/
                            pptStartLotsReservationCancelReqResult strStartLotsReservationCancelReqResult;
                            rc = txStartLotsReservationCancelReq ( strStartLotsReservationCancelReqResult,
                                                                   strObjCommonIn,
                                                                   strWhereNextTransferEqp_struct_out.equipmentID,
                                                                   strStartLotsReservationReqResult.controlJobID,
//D7000182                                                                   "" );
                                                                   "",                        //D7000182
                                                                   tmpAPCIFControlStatus );   //D7000182
                            APCIFControlStatus = CIMFWStrDup(tmpAPCIFControlStatus);          //D7000182
                            CORBA::string_free(tmpAPCIFControlStatus);                        //D7000182
                            tmpAPCIFControlStatus = NULL;                                     //D7000182

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1(strTrace, "txStartLotsReservationCancelReq != RC_OK");
                            }

                            rc = saveRC;
                            return( rc );
//                          return ( RC_START_LOT_RESERVATION_FAIL );
                        }

                        /*--------------------*/
                        /*   Return to Main   */
                        /*--------------------*/
                        PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                        PPT_METHODTRACE_V1(strTrace, "@@@@@ OK! OK! OK! [EQP to EQP]  Return to Main");
                        PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

                        SET_MSG_RC(strCassetteDeliveryReqResult, MSG_OK, RC_OK);
                        return RC_OK;
                        }       //D9000175  (else( 1 == eqpTakeOutInSupport ))
                    }
                    else
                    {
                        PPT_METHODTRACE_V1(strTrace, "##### txStartLotsReservationReq() rc != RC_OK");
                        strCassetteDeliveryReqResult.strResult = strStartLotsReservationReqResult.strResult;
//P5100218                        return( rc );
//P5100218 Start
                        //---------------------------------------------------------------------------------------------
                        //  Prepare message text string for case of failure of start lot reservation.
                        //  If start lot reservation for equipment is fail, this messageText is filled.
                        //---------------------------------------------------------------------------------------------
                        PPT_METHODTRACE_V1(strTrace, "### Prepare e-mail Message Text");

                        //-------------------------------------------------------
                        // Prepare e-mail Message Text
                        //-------------------------------------------------------
                        CORBA::String_var msg;
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< StartLotsReservation Error!  (EQP -> EQP) >>>" );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhereNextTransferEqp_struct_out.equipmentID.identifier );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot IDs              : " );

                        CORBA::Boolean bLotSet = FALSE;
                        CORBA::Long nCastCnt = strWhereNextTransferEqp_struct_out.strStartCassette.length();
                        for ( i=0; i < nCastCnt; i++ )
                        {
                            CORBA::Long nLotCnt = strWhereNextTransferEqp_struct_out.strStartCassette[i].strLotInCassette.length();
                            for ( j=0; j < nLotCnt; j++ )
                            {
                                if (CIMFWStrLen(strWhereNextTransferEqp_struct_out.strStartCassette[i].strLotInCassette[j].lotID.identifier) != 0)
                                {
                                    if ( TRUE == bLotSet )
                                    {
                                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, ", " );
                                    }
                                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, strWhereNextTransferEqp_struct_out.strStartCassette[i].strLotInCassette[j].lotID.identifier );
                                    bLotSet = TRUE;
                                }
                            }
                        }
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.transactionID );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.returnCode );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.messageID );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.messageText );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.reasonText );

                        PPT_METHODTRACE_V2("", "messageText--->", msg);

                        pptSysMsgStockInfo sysMsg;
                        sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                        sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                        sysMsg.systemMessageText      = CIMFWStrDup( msg );
                        sysMsg.notifyFlag             = TRUE;
                        sysMsg.equipmentID            = equipmentID;
                        sysMsg.equipmentStatus        = CIMFWStrDup("");
                        sysMsg.stockerID              = dummy;
                        sysMsg.stockerStatus          = CIMFWStrDup("");
                        sysMsg.AGVID                  = dummy;
                        sysMsg.AGVStatus              = CIMFWStrDup("");
                        sysMsg.lotID                  = dummy;
                        sysMsg.lotStatus              = CIMFWStrDup("");
                        sysMsg.routeID                = dummy;
                        sysMsg.operationID            = dummy;
                        sysMsg.operationNumber        = CIMFWStrDup("");
                        sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                        CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;

//D51M0000                        PPT_METHODTRACE_V1(strTrace, "return ( RC_START_LOT_RESERVATION_FAIL )");
                        PPT_METHODTRACE_V2(strTrace, "return rc", rc); //D51M0000
                        strCassetteDeliveryReqResult.strResult.reasonText = msg;
//D51M0000                        return RC_START_LOT_RESERVATION_FAIL;
//INN-R170002 add start
                        if ( rc == CS_RC_CARRIER_CONTAMINATION_MISMATCH )
                        {
                            PPT_METHODTRACE_V1( "", "rc == CS_RC_CARRIER_CONTAMINATION_MISMATCH");

                            //copy holtLotList to TxCDR
                            csStartLotsReservationReqResult_siInfo* strStartLotsReservationReqResult_siInfo;
                            if( strStartLotsReservationReqResult.siInfo >>= strStartLotsReservationReqResult_siInfo)
                            {
                                PPT_METHODTRACE_V1( "", "strStartLotsReservationReqResult_siInfo is valid");
                                csCassetteDeliveryReqResult_siInfo strCassetteDeliveryReqResult_siInfo;
                                strCassetteDeliveryReqResult_siInfo.holdLotIDs = strStartLotsReservationReqResult_siInfo->holdLotIDs;
                                strCassetteDeliveryReqResult.siInfo <<= strCassetteDeliveryReqResult_siInfo;
                            }
                        }
//INN-R170002 add end
                        return ( rc );                                  //D51M0000
//P5100218 End
                    }
                }
            }
        }
//0.05 add end


        if ( bLoadReqFlag == FALSE )
        {
            PPT_METHODTRACE_V1(strTrace, "***************************************************************");
            PPT_METHODTRACE_V1(strTrace, " UnLoadReq Process RUN!!");
            PPT_METHODTRACE_V1(strTrace, "***************************************************************");
            pptCarrierXferReqSequence tmpCarrierXferReqSeq;    //D9000175
            CORBA::ULong XferCnt = 0 ;                         //D9000175

            CORBA::Long nILen = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID.length();
            for ( i=0; i < nILen; i++ )
            {
                PPT_METHODTRACE_V2(strTrace, "Get Where Next Stocker [i]", i);
                PPT_METHODTRACE_V2(strTrace, "cassetteID", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID.identifier);

                /*----------------------------*/
                /*   Get Where Next Stocker   */
                /*----------------------------*/
//0.06                objectIdentifier dummy;
                pptWhereNextInterBayInqResult strWhereNextInterBayInqResult;

//0.06 start
                /*------------------------*/
                /*   Call RTD Interface   */
                /*------------------------*/
                PPT_METHODTRACE_V1(strTrace, "/*------------------------*/");
                PPT_METHODTRACE_V1(strTrace, "/*   Call RTD Interface   */");
                PPT_METHODTRACE_V1(strTrace, "/*------------------------*/");

                objCassetteDelivery_RTDInterfaceReq_out  strCassetteDelivery_RTDInterfaceReq_out;
                rc = cassetteDelivery_RTDInterfaceReq( strCassetteDelivery_RTDInterfaceReq_out,
                                                       strObjCommonIn,
                                                       SP_RTD_Function_Code_WhereNext,
                                                       strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID );
                if ( rc == RC_OK )
                {
                    PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    PPT_METHODTRACE_V1(strTrace, "Normal End      RTD Interface of txWhereNextInterBayInqResult");
                    PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    strWhereNextInterBayInqResult = strCassetteDelivery_RTDInterfaceReq_out.strWhereNextInterBayInqResult;
                }
                else
                {
                    PPT_METHODTRACE_V1(strTrace, "Faild RTD Interface -----> Call Normal Function (txWhereNextInterBayInq)");

//P4000190 start
                    if ( rc != RC_RTD_INTERFACE_SWITCH_OFF && rc != RC_NOT_FOUND_RTD )  //P4000332
                    {                                                                   //P4000332
                        /*------------------------*/
                        /*   Set System Message   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------------------------------*/");
                        PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   cassetteDelivery_RTDInterfaceReq() != RC_OK   */");
                        PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------------------------------*/");

//P4000332 start
                        CORBA::String_var msg;
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< RTD Interface Error!  (WhereNext of CassetteDelivery) >>>" );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.transactionID );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.returnCode );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.messageID );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.messageText );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.reasonText );

                        PPT_METHODTRACE_V2("", "messageText--->", msg);
//P4000332 end

                        pptSysMsgStockInfo sysMsg;
                        sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                        sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_RTDError );
//P4000332                        sysMsg.systemMessageText      = CIMFWStrDup( strCassetteDelivery_RTDInterfaceReq_out.strResult.messageText );
                        sysMsg.systemMessageText      = CIMFWStrDup( msg );     //P4000332
                        sysMsg.notifyFlag             = TRUE;
                        sysMsg.equipmentID            = equipmentID;
                        sysMsg.equipmentStatus        = CIMFWStrDup("");
                        sysMsg.stockerID              = dummy;
                        sysMsg.stockerStatus          = CIMFWStrDup("");
                        sysMsg.AGVID                  = dummy;
                        sysMsg.AGVStatus              = CIMFWStrDup("");
                        sysMsg.lotID                  = dummy;
                        sysMsg.lotStatus              = CIMFWStrDup("");
                        sysMsg.routeID                = dummy;
                        sysMsg.operationID            = dummy;
                        sysMsg.operationNumber        = CIMFWStrDup("");
                        sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                        CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
                    }       //P4000332
//P4000190 end

                    /*---------------------------------------------------*/
                    /*   Call Normal Function (txWhereNextInterBayInq)   */
                    /*---------------------------------------------------*/
                    PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------------*/");
                    PPT_METHODTRACE_V1(strTrace, "/*   Call Normal Function (txWhereNextInterBayInq)   */");
                    PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------------*/");
                    rc = txWhereNextInterBayInq( strWhereNextInterBayInqResult,
                                                 strObjCommonIn,
                                                 dummy,
                                                 strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID );

                    if ( rc != RC_OK )
                    {
//P4000190 start
                        /*------------------------*/
                        /*   Set System Message   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1(strTrace, "/*-------------------------------------------------------------*/");
                        PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   txWhereNextInterBayInq() != RC_OK   */");
                        PPT_METHODTRACE_V1(strTrace, "/*-------------------------------------------------------------*/");

//P4000332 start
                        CORBA::String_var msg;
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< WhereNext Error!  (EQP -> Stocker) >>>" );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhereNextInterBayInqResult.strResult.transactionID );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhereNextInterBayInqResult.strResult.returnCode );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhereNextInterBayInqResult.strResult.messageID );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhereNextInterBayInqResult.strResult.messageText );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhereNextInterBayInqResult.strResult.reasonText );

                        PPT_METHODTRACE_V2("", "messageText--->", msg);
//P4000332 end

                        pptSysMsgStockInfo sysMsg;
                        sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
//P4000332                        sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_WhereNextError );
                        sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );      //P4000332
//P4000332                        sysMsg.systemMessageText      = CIMFWStrDup( strWhereNextInterBayInqResult.strResult.messageText );
                        sysMsg.systemMessageText      = CIMFWStrDup( msg );     //P4000332
                        sysMsg.notifyFlag             = TRUE;
                        sysMsg.equipmentID            = equipmentID;
                        sysMsg.equipmentStatus        = CIMFWStrDup("");
                        sysMsg.stockerID              = dummy;
                        sysMsg.stockerStatus          = CIMFWStrDup("");
                        sysMsg.AGVID                  = dummy;
                        sysMsg.AGVStatus              = CIMFWStrDup("");
                        sysMsg.lotID                  = dummy;
                        sysMsg.lotStatus              = CIMFWStrDup("");
                        sysMsg.routeID                = dummy;
                        sysMsg.operationID            = dummy;
                        sysMsg.operationNumber        = CIMFWStrDup("");
                        sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                        CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
//P4000190 end

                        strCassetteDeliveryReqResult.strResult = strWhereNextInterBayInqResult.strResult;   //P6000651
                        PPT_METHODTRACE_V1(strTrace, "##### txWhereNextInterBayInq() != RC_OK");
                        return( rc );
                    }
                }
//0.06 end

//0.06//P4000052 Katoh RTD Interface Modify Start
//0.06//P4000052 Following Logic was moved from txWhereNextInterBayInq()
//0.06//P4000052 But not completely the same
//0.06
//0.06                CORBA::Boolean bRTDErr = FALSE;
//0.06                CORBA::String_var strRTDErrMsg;
//0.06
//0.06                stringSequence additParams;
//0.06                additParams.length(0);
//0.06
//0.06                //---------------------------------------
//0.06                // Read setting information from FSRTDIF
//0.06                //---------------------------------------
//0.06                PPT_METHODTRACE_V1(strTrace, "Read setting information from FSRTDIF");
//0.06
//0.06                objRTD_data_GetDR_out strRTD_data_GetDR_out;
//0.06                rc = RTD_data_GetDR( strRTD_data_GetDR_out,
//0.06                                     strObjCommonIn,
//0.06                                     SP_RTD_Function_Code_WhereNext,
//0.06                                     strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID.identifier );
//0.06
//0.06                if ( rc != RC_OK && rc == RC_NOT_FOUND_RTD )
//0.06                {
//0.06                    PPT_METHODTRACE_V1(strTrace, "RTD_data_GetDR != RC_OK && RTD_data_GetDR == RC_NOT_FOUND_RTD");
//0.06                    rc = RTD_data_GetDR( strRTD_data_GetDR_out,
//0.06                                         strObjCommonIn,
//0.06                                         SP_RTD_Function_Code_WhereNext,
//0.06                                         "*" );
//0.06                }
//0.06
//0.06                if( rc == RC_OK )
//0.06                {
//0.06                    PPT_METHODTRACE_V1(strTrace, "rc == RC_OK");
//0.06                    char tmpBuf[1024];
//0.06                    CIMFWStrCpy(&tmpBuf[0], strRTD_data_GetDR_out.RTDRecords[0].optionAttributes);
//0.06
//0.06                    char *startPos = &tmpBuf[0];
//0.06                    char *endPos   = &tmpBuf[0];
//0.06
//0.06                    CORBA::Long nDataNum;
//0.06                    for ( nDataNum=0; endPos != NULL; nDataNum++ )
//0.06                    {
//0.06                        endPos = strstr(startPos, ",");
//0.06                        if ( endPos != NULL )
//0.06                        {
//0.06                            PPT_METHODTRACE_V1(strTrace,"endPos != NULL");
//0.06                            *endPos = '\0';
//0.06                            additParams.length(nDataNum + 1);
//0.06                            additParams[nDataNum] = CIMFWStrDup(startPos);
//0.06                            startPos = endPos + 1;
//0.06                        }
//0.06                        else
//0.06                        {
//0.06                            PPT_METHODTRACE_V1(strTrace,"endPos == NULL");
//0.06                            additParams.length(nDataNum + 1);
//0.06                            additParams[nDataNum] = CIMFWStrDup(startPos);
//0.06                        }
//0.06                    }
//0.06
//0.06                    CORBA::Long len = additParams.length();
//0.06                    PPT_METHODTRACE_V2(strTrace, "additParams.length", len);
//0.06                    for (i=0; i < len; i++)
//0.06                    {
//0.06                        PPT_METHODTRACE_V3(strTrace, "additParams", i, additParams[i]);
//0.06                    }
//0.06
//0.06                    /*------------------------------*/
//0.06                    /*   call RTD Service Manager   */
//0.06                    /*------------------------------*/
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*------------------------------*/");
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*   call RTD Service Manager   */");
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*------------------------------*/");
//0.06                    pptRTDDispatchListInqResult  strRTDDispatchListInqResult;
//0.06                    rc = txRTDDispatchListInq( strRTDDispatchListInqResult,
//0.06                                               strObjCommonIn,
//0.06                                               SP_RTD_Function_Code_WhereNext,
//0.06                                               strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID.identifier,
//0.06                                               additParams );
//0.06
//0.06                    if( rc == RC_OK )
//0.06                    {
//0.06                        /*-----------------------------------------------*/
//0.06                        /*   convert dispatchInfo to WhereNextInterBay   */
//0.06                        /*-----------------------------------------------*/
//0.06                        PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------*/");
//0.06                        PPT_METHODTRACE_V1(strTrace, "/*   convert dispatchInfo to WhereNextInterBay   */");
//0.06                        PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------*/");
//0.06                        objRTD_dispatchDataToWhereNextInterBay_Convert_out  strRTD_dispatchDataToWhereNextInterBay_Convert_out;
//0.06                        rc = RTD_dispatchDataToWhereNextInterBay_Convert( strRTD_dispatchDataToWhereNextInterBay_Convert_out,
//0.06                                                                        strObjCommonIn,
//0.06                                                                        strRTDDispatchListInqResult.strDispatchResult );
//0.06
//0.06                        if ( rc == RC_OK )
//0.06                        {
//0.06                            strWhereNextInterBayInqResult = strRTD_dispatchDataToWhereNextInterBay_Convert_out.strWhereNextInterBayInqResult;
//0.06                        }
//0.06                        else
//0.06                        {
//0.06                            PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                            PPT_METHODTRACE_V1(strTrace, "  RTD_dispatchDataToWhereNextInterBay_Convert() rc != RC_OK ---> Call Normal txWhereNextInterBayInq");
//0.06                            PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                            // call normal function txWhereNextInterBayInq
//0.06                            bRTDErr = TRUE;
//0.06                            strRTDErrMsg = CIMFWStrDup( strRTD_dispatchDataToWhereNextInterBay_Convert_out.strResult.messageText );
//0.06                        }
//0.06                    }
//0.06                    else
//0.06                    {
//0.06                        PPT_METHODTRACE_V2(strTrace, "rc != RC_OK", strRTDDispatchListInqResult.strResult.messageText);
//0.06                        PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                        PPT_METHODTRACE_V1(strTrace, "  txRTDDispatchListInq() rc != RC_OK ---> Call Normal txWhereNextInterBayInq");
//0.06                        PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                        // normal function call txWhereNextInterBayInq
//0.06                        bRTDErr = TRUE;
//0.06                        strRTDErrMsg = CIMFWStrDup( strRTDDispatchListInqResult.strResult.messageText );
//0.06                    }
//0.06                }
//0.06                else
//0.06                {
//0.06                    PPT_METHODTRACE_V1(strTrace, "RTD_data_GetDR() rc != RC_OK");
//0.06                    bRTDErr = TRUE;
//0.06                }
//0.06
//0.06                if ( TRUE == bRTDErr )
//0.06                {
//0.06                    /*-------------------------*/
//0.06                    /*   RTD Interface Failed  */
//0.06                    /*   Call System Message   */
//0.06                    /*-------------------------*/
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*-------------------------*/");
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*   RTD Interface Failed  */");
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*   Call System Message   */");
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*-------------------------*/");
//0.06
//0.06                    pptSystemMsgRptResult strSystemMsgRptResult;
//0.06                    objectIdentifier      dummy;
//0.06
//0.06                    rc = txSystemMsgRpt( strSystemMsgRptResult,
//0.06                                         strObjCommonIn,
//0.06                                         SP_SubSystemID_MM,
//0.06                                         SP_SystemMsgCode_RTDError,
//0.06                                         strRTDErrMsg,    //message  text
//0.06                                         TRUE,
//0.06                                         dummy,
//0.06                                         "",
//0.06                                         dummy,
//0.06                                         "",
//0.06                                         dummy,
//0.06                                         "",
//0.06                                         dummy,
//0.06                                         "",
//0.06                                         dummy,
//0.06                                         dummy,
//0.06                                         "",
//0.06                                         strObjCommonIn.strTimeStamp.reportTimeStamp,
//0.06                                         "");
//0.06                    if ( rc != RC_OK )
//0.06                    {
//0.06                        PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                        PPT_METHODTRACE_V1(strTrace, " txSystemMsgRpt() != RC_OK") ;
//0.06                        PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                        strCassetteDeliveryReqResult.strResult = strSystemMsgRptResult.strResult ;
//0.06                        return(rc);
//0.06                    }
//0.06//P4000052 Katoh RTD Interface Modify End
//0.06
//0.06                    rc = txWhereNextInterBayInq( strWhereNextInterBayInqResult,
//0.06                                                 strObjCommonIn,
//0.06                                                 dummy,
//0.06                                                 strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID );
//0.06
//0.06                    if ( rc != RC_OK )
//0.06                    {
//0.06                        PPT_METHODTRACE_V1(strTrace, "txWhereNextInterBayInq() rc != RC_OK");
//0.06                        strCassetteDeliveryReqResult.strResult = strWhereNextInterBayInqResult.strResult;
//0.06                        return( rc );
//0.06                    }
//0.06//P4000052 Katoh RTD Interface Modify Start
//0.06                }
//0.06//P4000052 Katoh RTD Interface Modify End


                PPT_METHODTRACE_V1(strTrace, "// Make txSingleCarrierXferReq parameter");
                /*-------------------------------------------*/
                /*   Make txSingleCarrierXferReq parameter   */
                /*-------------------------------------------*/
                objSingleCarrierXferFillInTXLGC013InParm_out strSingleCarrierXferFillInTXLGC013InParm_out;
                rc = singleCarrierXferFillInTXLGC013InParm(
                            strSingleCarrierXferFillInTXLGC013InParm_out,
                            strObjCommonIn,
                            equipmentID,
                            strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].portID,
                            strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID,
                            strWhereNextInterBayInqResult );
//D8000195//D8000028 add start
//D8000195                if( rc == RC_CASSETTE_TRANSFERED_TO_TEMPORARY_STOCKER )
//D8000195                {
//D8000195                    /*------------------------*/
//D8000195                    /*   Set System Message   */
//D8000195                    /*------------------------*/
//D8000195                    PPT_METHODTRACE_V1(strTrace, "/*----------------------------------------------------------------------------*/");
//D8000195                    PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   singleCarrierXferFillInTXLGC013InParm() != RC_OK   */");
//D8000195                    PPT_METHODTRACE_V1(strTrace, "/*----------------------------------------------------------------------------*/");
//D8000195
//D8000195                    CORBA::String_var msg;
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Cassette is transfered to temporary Stocker! >>>" );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID.identifier );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID.identifier );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID.identifier );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup );
//D8000195                    if(strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine.length())
//D8000195                    {
//D8000195                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
//D8000195                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[0].toMachineID.identifier );
//D8000195                    }
//D8000195                    else
//D8000195                    {
//D8000195                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
//D8000195                    }
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.transactionID );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.returnCode );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.messageID );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.messageText );
//D8000195                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
//D8000195                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.reasonText );
//D8000195
//D8000195                    PPT_METHODTRACE_V2("", "messageText--->", msg);
//D8000195
//D8000195                    pptSysMsgStockInfo sysMsg;
//D8000195                    sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
//D8000195                    sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
//D8000195                    sysMsg.systemMessageText      = CIMFWStrDup( msg );
//D8000195                    sysMsg.notifyFlag             = TRUE;
//D8000195                    sysMsg.equipmentID            = equipmentID;
//D8000195                    sysMsg.equipmentStatus        = CIMFWStrDup("");
//D8000195                    sysMsg.stockerID              = dummy;
//D8000195                    sysMsg.stockerStatus          = CIMFWStrDup("");
//D8000195                    sysMsg.AGVID                  = dummy;
//D8000195                    sysMsg.AGVStatus              = CIMFWStrDup("");
//D8000195                    sysMsg.lotID                  = dummy;
//D8000195                    sysMsg.lotStatus              = CIMFWStrDup("");
//D8000195                    sysMsg.routeID                = dummy;
//D8000195                    sysMsg.operationID            = dummy;
//D8000195                    sysMsg.operationNumber        = CIMFWStrDup("");
//D8000195                    sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
//D8000195
//D8000195                    CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
//D8000195                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
//D8000195                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
//D8000195                }
//D8000195                else if ( rc != RC_OK )
//D8000195//D8000028 add end
//D8000195//D8000028      if ( rc != RC_OK )
//D8000195 add start
                if ( rc == RC_NO_XFER_NEEDED )
                {
                    PPT_METHODTRACE_V1(strTrace, "No Transfer Job is requested by environment variable. Proceed to the Next Port...");
                    continue;
                }
                else if (rc == RC_NO_STOCKER_FOR_CURRENT_EQP)
                {
                    PPT_METHODTRACE_V1(strTrace, "An Error is Detected. Proceed to the Next Port...");
                    //-------------------------------------------------------
                    // Prepare e-mail Message Text
                    //-------------------------------------------------------
                    CORBA::String_var msg;
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Transfer Error!  (EQP -> Stocker) >>>" );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup );

                    CORBA::Long jj;
                    CORBA::Long lenToEqp = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine.length();
                    if ( 0 == lenToEqp )
                    {
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
                    }
                    for ( jj=0; jj < lenToEqp; jj++ )
                    {
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[jj].toMachineID.identifier );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[jj].toPortID.identifier );
                    }
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.transactionID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.returnCode );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.messageID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.messageText );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.reasonText );

                    PPT_METHODTRACE_V2("", "messageText--->", msg);

                    /*------------------------*/
                    /*   Set System Message   */
                    /*------------------------*/
                    PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------------------------------------*/");
                    PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   singleCarrierXferFillInTXLGC013InParm) != RC_OK   */");
                    PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------------------------------------*/");

                    pptSysMsgStockInfo sysMsg;
                    sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                    sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                    sysMsg.systemMessageText      = CIMFWStrDup( msg );
                    sysMsg.notifyFlag             = TRUE;
                    sysMsg.equipmentID            = equipmentID;
                    sysMsg.equipmentStatus        = CIMFWStrDup("");
                    sysMsg.stockerID              = dummy;
                    sysMsg.stockerStatus          = CIMFWStrDup("");
                    sysMsg.AGVID                  = dummy;
                    sysMsg.AGVStatus              = CIMFWStrDup("");
                    sysMsg.lotID                  = dummy;
                    sysMsg.lotStatus              = CIMFWStrDup("");
                    sysMsg.routeID                = dummy;
                    sysMsg.operationID            = dummy;
                    sysMsg.operationNumber        = CIMFWStrDup("");
                    sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                    CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
                    continue;
                }
                else if ( rc != RC_OK )
//D8000195 add end
                {
                    PPT_METHODTRACE_V1(strTrace, "##### singleCarrierXferFillInTXLGC013InParm() rc != RC_OK");
                    strCassetteDeliveryReqResult.strResult = strSingleCarrierXferFillInTXLGC013InParm_out.strResult;
                    return( rc );
                }
//D9000175 add start
                /*****************************************/
                /*                                       */
                /*         TakeOutIn transfer            */
                /*                                       */
                /*****************************************/
                /*------------------------------------------------------------*/
                /*   Check takeOutIn transfer function enable. (EQP -> STK)   */
                /*------------------------------------------------------------*/
                PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                PPT_METHODTRACE_V1(strTrace, "/*   Check takeOutIn transfer function enable. (EQP -> STK)   */");
                PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                if( 1 == eqpTakeOutInSupport )
                {
                    PPT_METHODTRACE_V1("","##### TakeOutIn enable for this equipment. Stock Carrier Xfer information() ");
                    tmpCarrierXferReqSeq.length(XferCnt+1);
                    tmpCarrierXferReqSeq[XferCnt].carrierID          = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID;
                    tmpCarrierXferReqSeq[XferCnt].lotID              = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID;
                    tmpCarrierXferReqSeq[XferCnt].zoneType           = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.zoneType;
                    tmpCarrierXferReqSeq[XferCnt].n2PurgeFlag        = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.n2PurgeFlag;
                    tmpCarrierXferReqSeq[XferCnt].fromMachineID      = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID;
                    tmpCarrierXferReqSeq[XferCnt].fromPortID         = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID;
                    tmpCarrierXferReqSeq[XferCnt].toStockerGroup     = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup;
                    tmpCarrierXferReqSeq[XferCnt].strToMachine       = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine;
                    tmpCarrierXferReqSeq[XferCnt].expectedStartTime  = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedStartTime;
                    tmpCarrierXferReqSeq[XferCnt].expectedEndTime    = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedEndTime;
                    tmpCarrierXferReqSeq[XferCnt].mandatoryFlag      = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.mandatoryFlag;
                    tmpCarrierXferReqSeq[XferCnt].priority           = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.priority;
                    XferCnt++;
                }
                else
                {
//D9000175 add end


//PSN000073169 add start

                /*------------------------------------------------------*/
                /*  Check whether specified machine is eqp or stocker   */
                /*------------------------------------------------------*/
                CORBA::Boolean isStorageFlag = FALSE ;
                objEquipment_statusInfo_Get_out__090 strEquipment_statusInfo_GetDR_outForLock;
                objEquipment_statusInfo_Get_in__090  strEquipment_statusInfo_Get_in;
                strEquipment_statusInfo_Get_in.equipmentID = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID;
                rc = equipment_statusInfo_Get__090( strEquipment_statusInfo_GetDR_outForLock,
                                                    strObjCommonIn,
                                                    strEquipment_statusInfo_Get_in);

                if ( rc != RC_OK )
                {
                    if ( rc == RC_NOT_FOUND_EQP )
                    {
                        isStorageFlag = TRUE;
                    }
                    else
                    {
                        PPT_METHODTRACE_V2("", "equipment_statusInfo_Get__090() rc != RC_OK", rc);
                        strCassetteDeliveryReqResult.strResult = strEquipment_statusInfo_GetDR_outForLock.strResult;
                        return( rc );
                    }
                }

                PPT_METHODTRACE_V3("", "Equipment is Storage or not == ", strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID.identifier, isStorageFlag );

                if ( FALSE == isStorageFlag )
                {
                    /*--------------------------------------------*/
                    /* Lock Port object of machine                */
                    /*--------------------------------------------*/

                    objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                    rc = object_LockForEquipmentResource(strObject_LockForEquipmentResource_out,
                                                         strObjCommonIn,
                                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID,
                                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID,
                                                         SP_ClassName_PosPortResource );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier );
                        strCassetteDeliveryReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
                        return( rc );
                    }
                    PPT_METHODTRACE_V2("","Locked port object  :", strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier);

                    /*-----------------------------------------------------------------------------*/
                    /*                                                                             */
                    /*   Check Equipment Port for Sending Request to XM. (EQP -> Stocker)          */
                    /*                                                                             */
                    /*-----------------------------------------------------------------------------*/
                    objEquipment_portState_CheckForCassetteDelivery_out strEquipment_portState_CheckForCassetteDelivery_out;
                    objEquipment_portState_CheckForCassetteDelivery_in strEquipment_portState_CheckForCassetteDelivery_in;
                    strEquipment_portState_CheckForCassetteDelivery_in.equipmentID = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID;
                    strEquipment_portState_CheckForCassetteDelivery_in.portID = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID;
                    rc = equipment_portState_CheckForCassetteDelivery(strEquipment_portState_CheckForCassetteDelivery_out,
                                                                      strObjCommonIn,
                                                                      strEquipment_portState_CheckForCassetteDelivery_in);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "", "equipment_portState_CheckForCassetteDelivery() != RC_OK" );
                        strCassetteDeliveryReqResult.strResult = strEquipment_portState_CheckForCassetteDelivery_out.strResult;
                        return( rc );
                    }
                }
//PSN000073169 add end

                PPT_METHODTRACE_V1(strTrace, "// Send Request to XM. (EQP -> Stocker)");
                /*------------------------------------------*/
                /*   Send Request to XM. (EQP -> Stocker)   */
                /*------------------------------------------*/
                pptSingleCarrierXferReqResult strSingleCarrierXferReqResult;
                rc = txSingleCarrierXferReq( strSingleCarrierXferReqResult,
                                             strObjCommonIn,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.rerouteFlag,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.zoneType,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.n2PurgeFlag,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedStartTime,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedEndTime,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.mandatoryFlag,
                                             strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.priority );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1(strTrace, "##### txSingleCarrierXferReq() rc != RC_OK");
                    strCassetteDeliveryReqResult.strResult = strSingleCarrierXferReqResult.strResult;

//P4000332 start
                    //-------------------------------------------------------
                    // Prepare e-mail Message Text
                    //-------------------------------------------------------
                    CORBA::String_var msg;
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Transfer Error!  (EQP -> Stocker) >>>" );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup );

                    CORBA::Long jj;
                    CORBA::Long lenToEqp = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine.length();
                    if ( 0 == lenToEqp )
                    {
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
                    }
                    for ( jj=0; jj < lenToEqp; jj++ )
                    {
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[jj].toMachineID.identifier );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[jj].toPortID.identifier );
                    }
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.transactionID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.returnCode );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.messageID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.messageText );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.reasonText );

                    PPT_METHODTRACE_V2("", "messageText--->", msg);

                    /*------------------------*/
                    /*   Set System Message   */
                    /*------------------------*/
                    PPT_METHODTRACE_V1(strTrace, "/*-------------------------------------------------------------*/");
                    PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   txSingleCarrierXferReq() != RC_OK   */");
                    PPT_METHODTRACE_V1(strTrace, "/*-------------------------------------------------------------*/");

                    pptSysMsgStockInfo sysMsg;
                    sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                    sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                    sysMsg.systemMessageText      = CIMFWStrDup( msg );
                    sysMsg.notifyFlag             = TRUE;
                    sysMsg.equipmentID            = equipmentID;
                    sysMsg.equipmentStatus        = CIMFWStrDup("");
                    sysMsg.stockerID              = dummy;
                    sysMsg.stockerStatus          = CIMFWStrDup("");
                    sysMsg.AGVID                  = dummy;
                    sysMsg.AGVStatus              = CIMFWStrDup("");
                    sysMsg.lotID                  = dummy;
                    sysMsg.lotStatus              = CIMFWStrDup("");
                    sysMsg.routeID                = dummy;
                    sysMsg.operationID            = dummy;
                    sysMsg.operationNumber        = CIMFWStrDup("");
                    sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                    CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
//P4000332 end

                    return( rc );
                }
                }       //D9000175  (else( 1 == eqpTakeOutInSupport ))
            }
//D9000175 add start
            /*****************************************/
            /*                                       */
            /*         TakeOutIn transfer            */
            /*                                       */
            /*****************************************/
            /*------------------------------------------------------------*/
            /*   Check takeOutIn transfer function enable. (EQP -> STK)   */
            /*------------------------------------------------------------*/
            PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
            PPT_METHODTRACE_V1(strTrace, "/*   Check takeOutIn transfer function enable. (EQP -> STK)   */");
            PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

            if( 1 == eqpTakeOutInSupport )
            {
                PPT_METHODTRACE_V1("","##### TakeOutIn enable for this equipment. Call txLotCassetteTakeOutInReq() ");
                pptLotCassetteTakeOutInReqResult strLotCassetteTakeOutInReqResult;
                pptLotCassetteTakeOutInReqInParm strLotCassetteTakeOutInReqInParm;
                strLotCassetteTakeOutInReqInParm.EqpToEqpFlag = FALSE;
                strLotCassetteTakeOutInReqInParm.equipmentID  = equipmentID;
                strLotCassetteTakeOutInReqInParm.controlJobID.identifier = CIMFWStrDup("");
                strLotCassetteTakeOutInReqInParm.strEqpTargetPortInfo = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo;
                strLotCassetteTakeOutInReqInParm.strCarrierXferReqSeq = tmpCarrierXferReqSeq;

                //Call txLotCassetteTakeOutInReq
                rc = txLotCassetteTakeOutInReq( strLotCassetteTakeOutInReqResult,
                                                strObjCommonIn,
                                                strLotCassetteTakeOutInReqInParm,
                                                "" );  //claimMemo

                // Set mail information even if the transaction returns error.
                CORBA::ULong sysMsgLen = strLotCassetteTakeOutInReqResult.strSysMsgStockInfoSeq.length();
                for( CORBA::ULong i = 0 ; i < sysMsgLen ; i++ )
                {
                    CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = strLotCassetteTakeOutInReqResult.strSysMsgStockInfoSeq[i];
                }

                if(rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("","### txLotCassetteTakeOutInReq() != RC_OK");
                    strCassetteDeliveryReqResult.strResult = strLotCassetteTakeOutInReqResult.strResult;   //PSN000062212
                    return rc;
                }

                /*--------------------*/
                /*   Return to Main   */
                /*--------------------*/
                PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                PPT_METHODTRACE_V1(strTrace, "@@@@@ OK! OK! OK! [EQP to Stocker with TakeOutIn]  Return to Main");
                PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

                return RC_OK;
            }
//D9000175 add end

            /*--------------------*/
            /*   End of Process   */
            /*--------------------*/
            bLoadReqFlag = FALSE;

            PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            PPT_METHODTRACE_V1(strTrace, "@@@@@ OK! OK! OK! [EQP to Stocker]  Return to Main");
            PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        }
    }

    if ( bLoadReqFlag == TRUE )
    {
        PPT_METHODTRACE_V1(strTrace, "bLoadReqFlag == TRUE");
        /*-----------------*/
        /*   Load Request  */
        /*-----------------*/
        if ( 0 == CIMFWStrCmp(strEquipment_targetPort_Pickup_out.targetPortType, SP_PortRsc_PortState_LoadReq) )
        {
            PPT_METHODTRACE_V1(strTrace, "***************************************************************");
            PPT_METHODTRACE_V1(strTrace, "Load Request");
            PPT_METHODTRACE_V1(strTrace, "***************************************************************");

//D4200273 start
            if ( TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag )
            {
                PPT_METHODTRACE_V1(strTrace, "##### TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag");
                PPT_SET_MSG_RC_KEY2( strCassetteDeliveryReqResult, MSG_INVALID_EQP_STAT, RC_INVALID_EQP_STAT,
                                    equipmentID.identifier, "NotAvailable" );
                return RC_INVALID_EQP_STAT;
            }
//D4200273 end

//P3100020 start   Do this check with equipment_targetPort_Pickup.
//P3100020
//P3100020            PPT_METHODTRACE_V1(strTrace, "");
//P3100020            PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//P3100020            PPT_METHODTRACE_V1(strTrace, "Check Port Access Mode");
//P3100020            PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//P3100020            /*----------------------------*/
//P3100020            /*   Check Port Access Mode   */
//P3100020            /*----------------------------*/
//P3100020            nPortLen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length();
//P3100020            PPT_METHODTRACE_V2(strTrace, "nPortLen", nPortLen);
//P3100020            for ( i=0; i < nPortLen; i++ )
//P3100020            {
//P3100020                PPT_METHODTRACE_V2(strTrace, "dispatchMode", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].dispatchMode);
//P3100020                PPT_METHODTRACE_V2(strTrace, "accessMode  ", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].accessMode);
//P3100020                PPT_METHODTRACE_V2(strTrace, "onlineMode  ", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode);
//P3100020
//P3100020                if ( 0 != CIMFWStrCmp(strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].dispatchMode, SP_Eqp_DispatchMode_Auto)
//P3100020                  || 0 != CIMFWStrCmp(strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].accessMode, SP_Eqp_AccessMode_Auto)
//P3100020                  || (0 != CIMFWStrCmp(strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode, SP_Eqp_OnlineMode_OnlineLocal)
//P3100020                  && 0 != CIMFWStrCmp(strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode, SP_Eqp_OnlineMode_OnlineRemote)) )
//P3100020                {
//P3100020                    PPT_METHODTRACE_V1(strTrace, "RC_INVALID_EQP_STAT!!");
//P3100020                    SET_MSG_RC( strCassetteDeliveryReqResult, MSG_INVALID_EQP_STAT, RC_INVALID_EQP_STAT );
//P3100020                    return( RC_INVALID_EQP_STAT );
//P3100020                }
//P3100020            }
//P3100020 end

            PPT_METHODTRACE_V1(strTrace, "***************************************************************");
            PPT_METHODTRACE_V1(strTrace, "Get WIP Lots <<< txWhatNextLotListInq >>>");
            PPT_METHODTRACE_V1(strTrace, "***************************************************************");
            /*------------------*/
            /*   Get WIP Lots   */
            /*------------------*/
//D9000005            pptWhatNextLotListInqResult strWhatNextLotListInqResult;
//DSIV00001830            pptWhatNextLotListInqResult__090 strWhatNextLotListInqResult;  //D9000005
//DSN000020767            pptWhatNextLotListInqResult__101 strWhatNextLotListInqResult;  //DSIV00001830
//DSN000081739            pptWhatNextLotListInqResult__120 strWhatNextLotListInqResult;    //DSN000020767
            pptWhatNextLotListInqResult__140 strWhatNextLotListInqResult;    //DSN000081739

//0.06 start
            /*------------------------*/
            /*   Call RTD Interface   */
            /*------------------------*/
            PPT_METHODTRACE_V1(strTrace, "/*------------------------*/");
            PPT_METHODTRACE_V1(strTrace, "/*   Call RTD Interface   */");
            PPT_METHODTRACE_V1(strTrace, "/*------------------------*/");
            objCassetteDelivery_RTDInterfaceReq_out  strCassetteDelivery_RTDInterfaceReq_out;
            rc = cassetteDelivery_RTDInterfaceReq( strCassetteDelivery_RTDInterfaceReq_out,
                                                   strObjCommonIn,
                                                   SP_RTD_Function_Code_WhatNext,
                                                   equipmentID );
            if ( rc == RC_OK )
            {
                PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                PPT_METHODTRACE_V1(strTrace, "Normal End      RTD Interface of txWhatNextLotListInq");
                PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//D9000005                strWhatNextLotListInqResult = strCassetteDelivery_RTDInterfaceReq_out.strWhatNextLotListInqResult;
//DSIV00001830                PPTConvert conv(strCassetteDelivery_RTDInterfaceReq_out.strWhatNextLotListInqResult);  //D9000005
//DSIV00001830                strWhatNextLotListInqResult = conv;                                                    //D9000005
                PPTConverter converter;                                                                                                           //DSIV00001830
//DSN000020767                converter.Convert080_to_101( strCassetteDelivery_RTDInterfaceReq_out.strWhatNextLotListInqResult, strWhatNextLotListInqResult );  //DSIV00001830
//DSN000081739                converter.Convert080_to_120( strCassetteDelivery_RTDInterfaceReq_out.strWhatNextLotListInqResult, strWhatNextLotListInqResult );    //DSN000020767
                converter.Convert080_to_140( strCassetteDelivery_RTDInterfaceReq_out.strWhatNextLotListInqResult, strWhatNextLotListInqResult );    //DSN000081739
            }
            else
            {
                PPT_METHODTRACE_V1(strTrace, "Faild RTD Interface -----> Call Normal Function (txWhatNextLotListInq)");

//P4000190 start
                if ( rc != RC_RTD_INTERFACE_SWITCH_OFF && rc != RC_NOT_FOUND_RTD )  //P4000332
                {                                                                   //P4000332
                    /*------------------------*/
                    /*   Set System Message   */
                    /*------------------------*/
                    PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------------------------------*/");
                    PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   cassetteDelivery_RTDInterfaceReq() != RC_OK   */");
                    PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------------------------------*/");

//P4000332 start
                    CORBA::String_var msg;
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< RTD Interface Error!  (WhatNext of CassetteDelivery) >>>" );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.transactionID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.returnCode );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.messageID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.messageText );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strCassetteDelivery_RTDInterfaceReq_out.strResult.reasonText );

                    PPT_METHODTRACE_V2("", "messageText--->", msg);
//P4000332 end

                    pptSysMsgStockInfo sysMsg;
                    sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                    sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_RTDError );
//P4000332                    sysMsg.systemMessageText      = CIMFWStrDup( strCassetteDelivery_RTDInterfaceReq_out.strResult.messageText );
                    sysMsg.systemMessageText      = CIMFWStrDup( msg );     //P4000332
                    sysMsg.notifyFlag             = TRUE;
                    sysMsg.equipmentID            = equipmentID;
                    sysMsg.equipmentStatus        = CIMFWStrDup("");
                    sysMsg.stockerID              = dummy;
                    sysMsg.stockerStatus          = CIMFWStrDup("");
                    sysMsg.AGVID                  = dummy;
                    sysMsg.AGVStatus              = CIMFWStrDup("");
                    sysMsg.lotID                  = dummy;
                    sysMsg.lotStatus              = CIMFWStrDup("");
                    sysMsg.routeID                = dummy;
                    sysMsg.operationID            = dummy;
                    sysMsg.operationNumber        = CIMFWStrDup("");
                    sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                    CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
                }       //P4000332
//P4000190 end

                /*-------------------------------------------------*/
                /*   Call Normal Function (txWhatNextLotListInq)   */
                /*-------------------------------------------------*/
                PPT_METHODTRACE_V1(strTrace, "/*-------------------------------------------------*/");
                PPT_METHODTRACE_V1(strTrace, "/*   Call Normal Function (txWhatNextLotListInq)   */");
                PPT_METHODTRACE_V1(strTrace, "/*-------------------------------------------------*/");
//D9000005                rc = txWhatNextLotListInq( strWhatNextLotListInqResult,
//DSIV00001830                rc = txWhatNextLotListInq__090( strWhatNextLotListInqResult,  //D9000005
//DSN000020767                rc = txWhatNextLotListInq__101( strWhatNextLotListInqResult,  //DSIV00001830
//DSN000081739                rc = txWhatNextLotListInq__120( strWhatNextLotListInqResult,    //DSN000020767
                rc = txWhatNextLotListInq__140( strWhatNextLotListInqResult,    //DSN000081739
                                           strObjCommonIn,
                                           equipmentID,
                                           SP_DP_SelectCriteria_Auto3 );
                if( rc != RC_OK )
                {
//P4000190 start
                    if ( rc != RC_NO_WIP_LOT )          //P4000332
                    {                                   //P4000332
                        /*------------------------*/
                        /*   Set System Message   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------------------*/");
                        PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   txWhatNextLotListInq() != RC_OK   */");
                        PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------------------*/");

//P4000332 start
                        CORBA::String_var msg;
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< WhatNext Error!  (Stocker -> EQP) >>>" );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextLotListInqResult.strResult.transactionID );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextLotListInqResult.strResult.returnCode );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextLotListInqResult.strResult.messageID );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextLotListInqResult.strResult.messageText );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextLotListInqResult.strResult.reasonText );

                        PPT_METHODTRACE_V2("", "messageText--->", msg);
//P4000332 end

                        pptSysMsgStockInfo sysMsg;
                        sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
//P4000332                        sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_WhatNextError );
                        sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );      //P4000332
//P4000332                        sysMsg.systemMessageText      = CIMFWStrDup( strWhatNextLotListInqResult.strResult.messageText );
                        sysMsg.systemMessageText      = CIMFWStrDup( msg );     //P4000332
                        sysMsg.notifyFlag             = TRUE;
                        sysMsg.equipmentID            = equipmentID;
                        sysMsg.equipmentStatus        = CIMFWStrDup("");
                        sysMsg.stockerID              = dummy;
                        sysMsg.stockerStatus          = CIMFWStrDup("");
                        sysMsg.AGVID                  = dummy;
                        sysMsg.AGVStatus              = CIMFWStrDup("");
                        sysMsg.lotID                  = dummy;
                        sysMsg.lotStatus              = CIMFWStrDup("");
                        sysMsg.routeID                = dummy;
                        sysMsg.operationID            = dummy;
                        sysMsg.operationNumber        = CIMFWStrDup("");
                        sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                        CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
                    }       //P4000332
//P4000190 end

                    PPT_METHODTRACE_V1(strTrace, "##### txWhatNextLotListInq() != RC_OK");
                    return( rc );
                }
            }
//0.06 end

//0.06//P4000052 Katoh RTD Interface Modify Start
//0.06//P4000052 Following Logic was moved from txWhatNextLotListInq()
//0.06//P4000052 But not completely the same
//0.06
//0.06            CORBA::Boolean bRTDErr = FALSE;
//0.06            CORBA::String_var strRTDErrMsg;
//0.06
//0.06            stringSequence additParams;
//0.06            additParams.length(0);
//0.06
//0.06            //---------------------------------------
//0.06            // Read setting information from FSRTDIF
//0.06            //---------------------------------------
//0.06            objRTD_data_GetDR_out strRTD_data_GetDR_out;
//0.06            rc = RTD_data_GetDR( strRTD_data_GetDR_out,
//0.06                                 strObjCommonIn,
//0.06                                 SP_RTD_Function_Code_WhatNext,
//0.06                                 equipmentID.identifier );
//0.06
//0.06            if ( rc != RC_OK && rc == RC_NOT_FOUND_RTD )
//0.06            {
//0.06                rc = RTD_data_GetDR( strRTD_data_GetDR_out,
//0.06                                     strObjCommonIn,
//0.06                                     SP_RTD_Function_Code_WhatNext,
//0.06                                     "*" );
//0.06            }
//0.06
//0.06            if( rc == RC_OK )
//0.06            {
//0.06                char tmpBuf[1024];
//0.06                CIMFWStrCpy(&tmpBuf[0], strRTD_data_GetDR_out.RTDRecords[0].optionAttributes);
//0.06
//0.06                char *startPos = &tmpBuf[0];
//0.06                char *endPos   = &tmpBuf[0];
//0.06
//0.06                CORBA::Long nDataNum;
//0.06                for ( nDataNum=0; endPos != NULL; nDataNum++ )
//0.06                {
//0.06                    endPos = strstr(startPos, ",");
//0.06                    if ( endPos != NULL )
//0.06                    {
//0.06                        PPT_METHODTRACE_V1(strTrace,"endPos != NULL");
//0.06                        *endPos = '\0';
//0.06                        additParams.length(nDataNum + 1);
//0.06                        additParams[nDataNum] = CIMFWStrDup(startPos);
//0.06                        startPos = endPos + 1;
//0.06                    }
//0.06                    else
//0.06                    {
//0.06                        PPT_METHODTRACE_V1(strTrace,"endPos == NULL");
//0.06                        additParams.length(nDataNum + 1);
//0.06                        additParams[nDataNum] = CIMFWStrDup(startPos);
//0.06                    }
//0.06                }
//0.06
//0.06                CORBA::Long len = additParams.length();
//0.06                PPT_METHODTRACE_V2(strTrace, "additParams.length", len);
//0.06                for (i=0; i < len; i++)
//0.06                {
//0.06                    PPT_METHODTRACE_V3(strTrace, "additParams", i, additParams[i]);
//0.06                }
//0.06
//0.06                /*------------------------------*/
//0.06                /*   call RTD Service Manager   */
//0.06                /*------------------------------*/
//0.06                PPT_METHODTRACE_V1(strTrace, "/*------------------------------*/");
//0.06                PPT_METHODTRACE_V1(strTrace, "/*   call RTD Service Manager   */");
//0.06                PPT_METHODTRACE_V1(strTrace, "/*------------------------------*/");
//0.06                pptRTDDispatchListInqResult  strRTDDispatchListInqResult;
//0.06                rc = txRTDDispatchListInq( strRTDDispatchListInqResult,
//0.06                                           strObjCommonIn,
//0.06                                           SP_RTD_Function_Code_WhatNext,
//0.06                                           equipmentID.identifier,
//0.06                                           additParams );
//0.06
//0.06                if( rc == RC_OK )
//0.06                {
//0.06                    /*------------------------------------------*/
//0.06                    /*   convert dispatchInfo to WhatNextInfo   */
//0.06                    /*------------------------------------------*/
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------*/");
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*   convert dispatchInfo to WhatNextInfo   */");
//0.06                    PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------*/");
//0.06                    objRTD_dispatchDataToWhatNextLotList_Convert_out  strRTD_dispatchDataToWhatNextLotList_Convert_out;
//0.06                    rc = RTD_dispatchDataToWhatNextLotList_Convert( strRTD_dispatchDataToWhatNextLotList_Convert_out,
//0.06                                                                    strObjCommonIn,
//0.06                                                                    strRTDDispatchListInqResult.strDispatchResult );
//0.06
//0.06                    if ( rc == RC_OK )
//0.06                    {
//0.06                        strWhatNextLotListInqResult = strRTD_dispatchDataToWhatNextLotList_Convert_out.strWhatNextLotListInqResult;
//0.06                    }
//0.06                    else
//0.06                    {
//0.06                        PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                        PPT_METHODTRACE_V1(strTrace, "  RTD_dispatchDataToWhatNextLotList_Convert() rc != RC_OK ---> Call Normal txWhatNextLotListInq");
//0.06                        PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                        // call normal function txWhatNextLotListInq
//0.06                        bRTDErr = TRUE;
//0.06                        strRTDErrMsg = CIMFWStrDup( strRTD_dispatchDataToWhatNextLotList_Convert_out.strResult.messageText );
//0.06                    }
//0.06                }
//0.06                else
//0.06                {
//0.06                    PPT_METHODTRACE_V2(strTrace, "rc != RC_OK", strRTDDispatchListInqResult.strResult.messageText);
//0.06                    PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                    PPT_METHODTRACE_V1(strTrace, "  txRTDDispatchListInq() rc != RC_OK ---> Call Normal txWhatNextLotListInq");
//0.06                    PPT_METHODTRACE_V1(strTrace, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
//0.06                    // call normal function txWhatNextLotListInq
//0.06                    bRTDErr = TRUE;
//0.06                    strRTDErrMsg = CIMFWStrDup( strRTDDispatchListInqResult.strResult.messageText );
//0.06                }
//0.06            }
//0.06            else
//0.06            {
//0.06                PPT_METHODTRACE_V1(strTrace, "RTD_data_GetDR() rc != RC_OK");
//0.06                bRTDErr = TRUE;
//0.06            }
//0.06
//0.06            if ( TRUE == bRTDErr )
//0.06            {
//0.06//P4000052 Katoh RTD Interface Modify End
//0.06
//0.06                rc = txWhatNextLotListInq( strWhatNextLotListInqResult,
//0.06                                           strObjCommonIn,
//0.06                                           equipmentID,
//0.06                                           SP_DP_SelectCriteria_Auto3 );
//0.06//P3100203                                 SP_DP_SelectCriteria_Full2 );
//0.06
//0.06                if( rc != RC_OK )
//0.06                {
//0.06                    /*------------------------*/
//0.06                    /*   Send System Report   */
//0.06                    /*------------------------*/
//0.06                    PPT_METHODTRACE_V1(strTrace, "txWhatNextLotListInq() rc != RC_OK");
//0.06                    strCassetteDeliveryReqResult.strResult = strWhatNextLotListInqResult.strResult;
//0.06
//0.06                    pptSystemMsgRptResult strSystemMsgRptResult;
//0.06                    objectIdentifier tmpOI;
//0.06                    rc = txSystemMsgRpt( strSystemMsgRptResult,
//0.06                                         strObjCommonIn,
//0.06                                         SP_SubSystemID_MM,
//0.06                                         SP_SystemMsgCode_WhatNextError,
//0.06                                         "",                                //System Message Text
//0.06                                         TRUE,                              //Notify Flag
//0.06                                         equipmentID, "",                   //Equipment ID and Status
//0.06                                         tmpOI, "",                         //Stocker ID and Status
//0.06                                         tmpOI, "",                         //AGV ID and Status
//0.06                                         tmpOI, "",                         //Lot ID and Status
//0.06                                         tmpOI, tmpOI, "",                  //Route ID and Operation ID and Operation Number
//0.06                                         strObjCommonIn.strTimeStamp.reportTimeStamp,
//0.06                                         "" );
//0.06                }
//0.06//P4000052 Katoh RTD Interface Modify Start
//0.06            }
//0.06//P4000052 Katoh RTD Interface Modify End


//VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV
{
    PPT_METHODTRACE_V1(strTrace, "VVVVV txWhatNextLotListInq VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
    PPT_METHODTRACE_V2(strTrace, "lastRecipeID ------------>", strWhatNextLotListInqResult.lastRecipeID.identifier);
    PPT_METHODTRACE_V2(strTrace, "dispatchRule ------------>", strWhatNextLotListInqResult.dispatchRule);
    PPT_METHODTRACE_V2(strTrace, "processRunSizeMaximum --->", strWhatNextLotListInqResult.processRunSizeMaximum);
    PPT_METHODTRACE_V2(strTrace, "processRunSizeMinimum --->", strWhatNextLotListInqResult.processRunSizeMinimum);

    CORBA::Long ii, jj, kk;
    CORBA::Long len1 = strWhatNextLotListInqResult.strWhatNextAttributes.length();
    PPT_METHODTRACE_V2(strTrace, "strWhatNextAttributes.length--->", len1);
    for (ii=0; ii < len1; ii++)
    {
        PPT_METHODTRACE_V2(strTrace, "--------------------------------------------------------------[count]", ii);
        PPT_METHODTRACE_V2(strTrace, "  lotID ----------------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].lotID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  cassetteID ------------------>", strWhatNextLotListInqResult.strWhatNextAttributes[ii].cassetteID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  lotType --------------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].lotType);
        PPT_METHODTRACE_V2(strTrace, "  multiLotType ---------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].multiLotType);
        PPT_METHODTRACE_V2(strTrace, "  transferStatus -------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].transferStatus);
        PPT_METHODTRACE_V2(strTrace, "  transferReserveUserID ------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].transferReserveUserID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  stockerID ------------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].stockerID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  equipmentID ----------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].equipmentID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  flowBatchID ----------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].flowBatchID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  controlJob ------------------>", strWhatNextLotListInqResult.strWhatNextAttributes[ii].controlJob.identifier);
        PPT_METHODTRACE_V2(strTrace, "  processReserveEquipmentID --->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].processReserveEquipmentID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  processReserveUserID -------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].processReserveUserID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  productID ------------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].productID.identifier);
//D9000001        PPT_METHODTRACE_V2(strTrace, "  recipeAvailableFlag --------->", (long)strWhatNextLotListInqResult.strWhatNextAttributes[ii].recipeAvailableFlag);
        PPT_METHODTRACE_V2(strTrace, "  recipeAvailableFlag --------->", (CORBA::Long)strWhatNextLotListInqResult.strWhatNextAttributes[ii].recipeAvailableFlag); //D9000001
        PPT_METHODTRACE_V2(strTrace, "  logicalRecipeID ------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].logicalRecipeID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  machineRecipeID ------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].machineRecipeID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  physicalRecipeID ------------>", strWhatNextLotListInqResult.strWhatNextAttributes[ii].physicalRecipeID);
        PPT_METHODTRACE_V2(strTrace, "  lastClaimedTimeStamp -------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].lastClaimedTimeStamp);
        PPT_METHODTRACE_V2(strTrace, "  stateChangeTimeStamp -------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].stateChangeTimeStamp);
        PPT_METHODTRACE_V2(strTrace, "  stateChangeTimeStamp -------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].stateChangeTimeStamp);
        PPT_METHODTRACE_V2(strTrace, "  inventoryChangeTimeStamp ---->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].inventoryChangeTimeStamp);
        PPT_METHODTRACE_V2(strTrace, "  dueTimeStamp ---------------->", strWhatNextLotListInqResult.strWhatNextAttributes[ii].dueTimeStamp);
    }
    PPT_METHODTRACE_V1(strTrace, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
}
//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

//D4200189 start
            PPT_METHODTRACE_V2(strTrace, "lenPortGroup", lenPortGroup);
            for ( i=0; i < lenPortGroup; i++ )
            {
                PPT_METHODTRACE_V3(strTrace, "-----------------------------------round[i]", i,
                                    strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[i].portGroup);

                pptPortGroupSequence strPortGroupSeq;
                strPortGroupSeq.length(1);
                strPortGroupSeq[0] = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[i];
//D4200189 end
                PPT_METHODTRACE_V1(strTrace, "");
                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                PPT_METHODTRACE_V1(strTrace, "Select Multiple Lots <<< whatNextLotList_to_StartCassetteForDeliveryReq >>>");
                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                /*--------------------------*/
                /*   Select Multiple Lots   */
                /*--------------------------*/
//DSIV00001830                PPTConvert convWhatNextLotListInqResult(strWhatNextLotListInqResult);  //D9000005
                pptWhatNextLotListInqResult convWhatNextLotListInqResult;                                  //DSIV00001830
                PPTConverter converter;                                                                    //DSIV00001830
//DSN000020767                converter.Convert101_to_080( strWhatNextLotListInqResult, convWhatNextLotListInqResult );  //DSIV00001830
//DSN000081739                converter.Convert120_to_080( strWhatNextLotListInqResult, convWhatNextLotListInqResult );    //DSN000020767
                converter.Convert140_to_080( strWhatNextLotListInqResult, convWhatNextLotListInqResult );    //DSN000081739

                objWhatNextLotList_to_StartCassetteForDeliveryReq_out strWhatNextLotList_to_StartCassetteForDeliveryReq_out;
                rc = whatNextLotList_to_StartCassetteForDeliveryReq(
                                    strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                    strObjCommonIn,
                                    equipmentID,
//D4200189                                    strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup,
                                    strPortGroupSeq,        //D4200189
                                    convWhatNextLotListInqResult );  //D9000005
//D9000005                                    strWhatNextLotListInqResult );
                if ( rc != RC_OK )
                {
//D4200189                    PPT_METHODTRACE_V1(strTrace, "##### whatNextLotList_to_StartCassetteForDeliveryReq() rc != RC_OK");
//D4200189                    strCassetteDeliveryReqResult.strResult = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult;
//D4200189                    return( rc );
//D4200189 start
                    PPT_METHODTRACE_V2(strTrace, "whatNextLotList_to_StartCassetteForDeliveryReq() rc != RC_OK", rc);
                    if ( i == lenPortGroup - 1 )
                    {
                        PPT_METHODTRACE_V1(strTrace, "##### i is last loop. so return error.");
                        strCassetteDeliveryReqResult.strResult = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult;
                        return( rc );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1(strTrace, "continue next PortGroup!!");
                        continue;
                    }
//D4200189 end
                }

//D8000024 add start
//D9000001                CORBA::Long tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
                CORBA::Long tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
                if( 1 == tmpFPCAdoptFlag )
                {
                    PPT_METHODTRACE_V1("", "FPC Adopt Flag is ON. Now apply FPCInfo.");
                    objFPCStartCassetteInfo_Exchange_out strFPCStartCassetteInfo_Exchange_out;
                    rc = FPCStartCassetteInfo_Exchange( strFPCStartCassetteInfo_Exchange_out,
                                                        strObjCommonIn,
                                                        SP_FPC_ExchangeType_StartReserveInfo,
                                                        equipmentID,
                                                        strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "FPCStartCassetteInfo_Exchange() != RC_OK", rc);
                        strCassetteDeliveryReqResult.strResult = strFPCStartCassetteInfo_Exchange_out.strResult;
                        return rc;
                    }

                    strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette =
                        strFPCStartCassetteInfo_Exchange_out.strStartCassette;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "FPC Adopt Flag is OFF.");
                }
//D8000024 add end


//D9000003 add start

                PPT_METHODTRACE_V1("","Set processJobExecFlag based on wafer sampling setting. ");
                CORBA::Boolean notSendIgnoreMail = FALSE;
                CORBA::Long startCassette_processJobExecFlag_SetRc = RC_OK;
                objStartCassette_processJobExecFlag_Set_out__090 strStartCassette_processJobExecFlag_Set_out__090;
                objStartCassette_processJobExecFlag_Set_in__090 strStartCassette_processJobExecFlag_Set_in__090;
                strStartCassette_processJobExecFlag_Set_in__090.strStartCassette = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette;
                strStartCassette_processJobExecFlag_Set_in__090.equipmentID = equipmentID;

                rc = startCassette_processJobExecFlag_Set__090(strStartCassette_processJobExecFlag_Set_out__090, strObjCommonIn, strStartCassette_processJobExecFlag_Set_in__090);
                PPT_METHODTRACE_V2("", "startCassette_processJobExecFlag_Set__090(): rc", rc);
                if( rc != RC_NO_SMPL_SETTING && rc != RC_OK)
                {
                    // When errors have occurred, hold all the error lot and send e-mail to notify that.
                    notSendIgnoreMail = TRUE;
                    strCassetteDeliveryReqResult.strResult = strStartCassette_processJobExecFlag_Set_out__090.strResult;
                    startCassette_processJobExecFlag_SetRc = RC_INVALID_SMPL_SETTING;
                }

                CORBA::Long mailLen = strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length();

                //hold lots and send E-Mails if error
                for(CORBA::Long mailCnt = 0; mailCnt < mailLen; mailCnt++)
                {
                    if( (strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType == SP_Sampling_error_mail)
                        || (strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType == SP_Sampling_warn_mail))
                    {
                        PPT_METHODTRACE_V1("", "messageType == SP_Sampling_error_mail || SP_Sampling_warn_mail ");

                        // Lot Hold
                        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                           strObjCommonIn,
                                                           strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].lotID ) ;

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                            strCassetteDeliveryReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult ;
                            return (rc) ;
                        }

                        pptHoldLotReqResult strHoldLotReqResult ;
                        pptHoldListSequence strLotHoldReqList ;
                        strLotHoldReqList.length( 1 ) ;

                        strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold ) ;
                        strLotHoldReqList[0].holdReasonCodeID.identifier          = CIMFWStrDup( SP_Reason_WaferSamplingHold );
                        strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
                        strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
                        strLotHoldReqList[0].routeID                  = strLot_currentOperationInfo_Get_out.routeID ;
                        strLotHoldReqList[0].operationNumber          = strLot_currentOperationInfo_Get_out.operationNumber ;
                        strLotHoldReqList[0].claimMemo                = CIMFWStrDup("");

                        rc = txHoldLotReq( strHoldLotReqResult,
                                           strObjCommonIn ,
                                           strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].lotID,
                                           strLotHoldReqList ) ;

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                            strCassetteDeliveryReqResult.strResult = strHoldLotReqResult.strResult ;
                            return( rc );
                        }
                    }  //end if (messageType ==  SP_Sampling_error_mail || SP_Sampling_warn_mail)

                    //error Mail Set
                    if( notSendIgnoreMail == FALSE ||  strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType != SP_Sampling_ignored_mail )
                    {
                        PPT_METHODTRACE_V1("", "notSendIgnoreMail == FALSE ||  strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType != SP_Sampling_ignored_mail") ;
                        //When notSendIgnoreMail == TRUE, just the Lot Hold mail is to be sent.
                        ostrstream messageText;
                        if(strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType == SP_Sampling_warn_mail)
                        {
                            PPT_METHODTRACE_V1("", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType == SP_Sampling_warn_mail") ;
                            //----------------------------------------------------------------
                            // create mail text if message type == SP_Sampling_warn_mail;
                            // startCassette_processJobExecFlag_Set__090 returns just error text. Caller should switch text handling.
                            //----------------------------------------------------------------
                            objLot_samplingMessage_Create_out strLot_samplingMessage_Create_out;
                            objLot_samplingMessage_Create_in strLot_samplingMessage_Create_in;
                            strLot_samplingMessage_Create_in.lotID = strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].lotID;
                            strLot_samplingMessage_Create_in.messageType = SP_Sampling_error_mail;
                            strLot_samplingMessage_Create_in.messageText = strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageText;

                            rc = lot_samplingMessage_Create(strLot_samplingMessage_Create_out, strObjCommonIn, strLot_samplingMessage_Create_in);
                            if(rc != RC_OK)
                            {
                                PPT_METHODTRACE_V1("", "lot_samplingMessage_Create() != RC_OK") ;
                                strCassetteDeliveryReqResult.strResult = strLot_samplingMessage_Create_out.strResult;
                                return rc;
                            }
                            messageText << strLot_samplingMessage_Create_out.message;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageType != SP_Sampling_warn_mail") ;
                            messageText << strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].messageText;
                        }
                        messageText << ends;
                        PPT_METHODTRACE_V2("", "messageText", messageText.str()) ;

                        /*------------------------*/
                        /*   Set System Message   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                        PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   For wafer sampling                 */");
                        PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                        objectIdentifier dummy;
                        pptSysMsgStockInfo sysMsg;
                        sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                        sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_SMPLERR );
                        sysMsg.systemMessageText      = CIMFWStrDup( messageText.str() );
                        sysMsg.notifyFlag             = TRUE;
                        sysMsg.equipmentID            = equipmentID;
                        sysMsg.equipmentStatus        = CIMFWStrDup("");
                        sysMsg.stockerID              = dummy;
                        sysMsg.stockerStatus          = CIMFWStrDup("");
                        sysMsg.AGVID                  = dummy;
                        sysMsg.AGVStatus              = CIMFWStrDup("");
                        sysMsg.lotID                  = strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[mailCnt].lotID;
                        sysMsg.lotStatus              = CIMFWStrDup("");
                        sysMsg.routeID                = dummy;
                        sysMsg.operationID            = dummy;
                        sysMsg.operationNumber        = CIMFWStrDup("");
                        sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                        CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                        strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
                        messageText.rdbuf()->freeze(0);
                    }
                } //end for-Loop
                if(notSendIgnoreMail == TRUE)
                {
                    PPT_METHODTRACE_V2("", "notSendIgnoreMail == TRUE  return this TX.",startCassette_processJobExecFlag_SetRc) ;
                    strCassetteDeliveryReqResult.strResult = strStartCassette_processJobExecFlag_Set_out__090.strResult;
                    return startCassette_processJobExecFlag_SetRc;
                }

                //valid check of processJobExecFlag for each lot.
                //Check every lot has at least one wafer with processJobExecFlag == TRUE
                objLot_processJobExecFlag_ValidCheck_out strLot_processJobExecFlag_ValidCheck_out;
                objLot_processJobExecFlag_ValidCheck_in strLot_processJobExecFlag_ValidCheck_in;
                strLot_processJobExecFlag_ValidCheck_in.strStartCassette = strStartCassette_processJobExecFlag_Set_out__090.strStartCassette;

                rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
                if( rc != RC_OK && rc != RC_NO_PROCESSJOBEXECFLAG)
                {
                    PPT_METHODTRACE_V1("", "lot_processJobExecFlag_ValidCheck() != RC_OK && != RC_NO_PROCESSJOBEXECFLAG") ;
                    strCassetteDeliveryReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
                    return rc;
                }
                if( rc == RC_NO_PROCESSJOBEXECFLAG)
                {
                    PPT_METHODTRACE_V1(strTrace, "objLot_processJobExecFlag_ValidCheck() rc == RC_NO_PROCESSJOBEXECFLAG");
                    // Lot Hold + error mail
                    // create hold mail message
                    objLot_samplingMessage_Create_out strLot_samplingMessage_Create_out;
                    objLot_samplingMessage_Create_in strLot_samplingMessage_Create_in;
                    strLot_samplingMessage_Create_in.lotID = strLot_processJobExecFlag_ValidCheck_out.lotID;
                    strLot_samplingMessage_Create_in.messageType = SP_Sampling_error_mail;
                    strLot_samplingMessage_Create_in.messageText = strLot_processJobExecFlag_ValidCheck_out.strResult.messageText;
                    rc = lot_samplingMessage_Create(strLot_samplingMessage_Create_out, strObjCommonIn, strLot_samplingMessage_Create_in);

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_samplingMessage_Create() != RC_OK", rc);
                        strCassetteDeliveryReqResult.strResult = strLot_samplingMessage_Create_out.strResult ;
                        return (rc) ;
                    }

                    objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                       strObjCommonIn,
                                                       strLot_processJobExecFlag_ValidCheck_out.lotID ) ;
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                        strCassetteDeliveryReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult ;
                        return (rc) ;
                    }

                    pptHoldLotReqResult strHoldLotReqResult ;
                    pptHoldListSequence strLotHoldReqList ;
                    strLotHoldReqList.length( 1 ) ;

                    strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold ) ;
                    strLotHoldReqList[0].holdReasonCodeID.identifier          = CIMFWStrDup( SP_Reason_WaferSamplingHold );
                    strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
                    strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
                    strLotHoldReqList[0].routeID                  = strLot_currentOperationInfo_Get_out.routeID ;
                    strLotHoldReqList[0].operationNumber          = strLot_currentOperationInfo_Get_out.operationNumber ;
                    strLotHoldReqList[0].claimMemo                = CIMFWStrDup("");

                    PPT_METHODTRACE_V1("", "txHoldLotReq() execute ");
                    rc = txHoldLotReq( strHoldLotReqResult,
                                       strObjCommonIn ,
                                       strLot_processJobExecFlag_ValidCheck_out.lotID,
                                       strLotHoldReqList ) ;

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                        strCassetteDeliveryReqResult.strResult = strHoldLotReqResult.strResult ;
                        return( rc );
                    }

                    //error Mail Set

                    /*------------------------*/
                    /*   Set System Message   */
                    /*------------------------*/
                    PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                    PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   For wafer sampling                 */");
                    PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                    objectIdentifier dummy;
                    pptSysMsgStockInfo sysMsg;
                    sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                    sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_SMPLERR );
                    sysMsg.systemMessageText      = CIMFWStrDup( strLot_samplingMessage_Create_out.message );
                    sysMsg.notifyFlag             = TRUE;
                    sysMsg.equipmentID            = equipmentID;
                    sysMsg.equipmentStatus        = CIMFWStrDup("");
                    sysMsg.stockerID              = dummy;
                    sysMsg.stockerStatus          = CIMFWStrDup("");
                    sysMsg.AGVID                  = dummy;
                    sysMsg.AGVStatus              = CIMFWStrDup("");
                    sysMsg.lotID                  = strLot_processJobExecFlag_ValidCheck_out.lotID;
                    sysMsg.lotStatus              = CIMFWStrDup("");
                    sysMsg.routeID                = dummy;
                    sysMsg.operationID            = dummy;
                    sysMsg.operationNumber        = CIMFWStrDup("");
                    sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                    CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;

                    strCassetteDeliveryReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
                    return RC_NO_PROCESSJOBEXECFLAG;

                } //end if (rc == RC_NO_PROCESSJOBEXECFLAG)

                traceSampledStartCassette(strStartCassette_processJobExecFlag_Set_out__090.strStartCassette);  //D9000003

                strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette = strStartCassette_processJobExecFlag_Set_out__090.strStartCassette;
                PPT_METHODTRACE_V1("","Set processJobExecFlag based on wafer sampling setting end. ");
//D9000003 add end


//VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV
{
    PPT_METHODTRACE_V1(strTrace, "VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
    CORBA::Long ii, jj, kk;
    CORBA::Long len1 = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette.length();
    PPT_METHODTRACE_V2(strTrace, "strStartCassette.length--->", len1);
    for (ii=0; ii < len1; ii++)
    {
        PPT_METHODTRACE_V1(strTrace, "  ----------");
        PPT_METHODTRACE_V2(strTrace, "  loadSequenceNumber --->", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].loadSequenceNumber);
        PPT_METHODTRACE_V2(strTrace, "  cassetteID ----------->", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].cassetteID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  loadPurposeType ------>", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].loadPurposeType);
        PPT_METHODTRACE_V2(strTrace, "  loadPortID ----------->", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].loadPortID.identifier);
        PPT_METHODTRACE_V2(strTrace, "  unloadPortID --------->", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].unloadPortID.identifier);

        CORBA::Long len2 = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette.length();
        PPT_METHODTRACE_V2(strTrace, "  strStartCassette[ii].strLotInCassette--->", len2);
        for (jj=0; jj < len2; jj++)
        {
            PPT_METHODTRACE_V1(strTrace, "    -----");
//D9000001            PPT_METHODTRACE_V2(strTrace, "    operationStartFlag---->", (long)strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].operationStartFlag);
//D9000001            PPT_METHODTRACE_V2(strTrace, "    monitorLotFlag ------->", (long)strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].monitorLotFlag);
            PPT_METHODTRACE_V2(strTrace, "    operationStartFlag---->", (CORBA::Long)strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].operationStartFlag); //D9000001
            PPT_METHODTRACE_V2(strTrace, "    monitorLotFlag ------->", (CORBA::Long)strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].monitorLotFlag); //D9000001
            PPT_METHODTRACE_V2(strTrace, "    lotID ---------------->", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].lotID.identifier);
            PPT_METHODTRACE_V2(strTrace, "    lotType -------------->", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].lotType);
            PPT_METHODTRACE_V2(strTrace, "    subLotType ----------->", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].subLotType);
            PPT_METHODTRACE_V2(strTrace, "    logicalRecipeID ------>", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.logicalRecipeID.identifier);
            PPT_METHODTRACE_V2(strTrace, "    machineRecipeID ------>", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.machineRecipeID.identifier);
            PPT_METHODTRACE_V2(strTrace, "    physicalRecipeID ----->", strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.physicalRecipeID);
        }
    }
    PPT_METHODTRACE_V1(strTrace, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
}
//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

//D4000184 delete start
//D4000184            PPT_METHODTRACE_V1(strTrace, "Check Empty Cassette");
//D4000184            /*--------------------------*/
//D4000184            /*   Check Empty Cassette   */
//D4000184            /*--------------------------*/
//D4000184            if ( TRUE == strEqpInfoInqResult.equipmentBRInfo.emptyCassetteRequireFlag )
//D4000184            {
//D4000184                PPT_METHODTRACE_V1(strTrace, "");
//D4000184                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D4000184                PPT_METHODTRACE_V1(strTrace, "!!!!! Empty Cassette Check !!!!!");
//D4000184                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D4000184
//D4000184                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D4000184                PPT_METHODTRACE_V1(strTrace, "Get Empty Cassette");
//D4000184                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D4000184
//D4000184//D4000016 Add Start
//D4000184                /*--------------------------------------------------*/
//D4000184                /*   Get Next2 Operation RequiredCassetteCategory   */
//D4000184                /*--------------------------------------------------*/
//D4000184                PPT_METHODTRACE_V1("txCassetteDeliveryReq", "Start lot_requiredCassetteCategory_GetForNextOperation() ");
//D4000184                objLot_requiredCassetteCategory_GetForNextOperation_out strLot_requiredCassetteCategory_GetForNextOperation_out;
//D4000184                rc = lot_requiredCassetteCategory_GetForNextOperation(
//D4000184                                strLot_requiredCassetteCategory_GetForNextOperation_out,
//D4000184                                strObjCommonIn,
//D4000184                                strWhatNextLotListInqResult.strWhatNextAttributes[0].lotID );
//D4000184
//D4000184                if ( rc != RC_OK )
//D4000184                {
//D4000184                    PPT_METHODTRACE_V1("txCassetteDeliveryReq", "lot_requiredCassetteCategory_GetForNextOperation() rc != RC_OK");
//D4000184                    strCassetteDeliveryReqResult.strResult = strLot_requiredCassetteCategory_GetForNextOperation_out.strResult;
//D4000184                    return( rc );
//D4000184                }
//D4000184                CORBA::String_var nextRequiredCassetteCategory;
//D4000184                nextRequiredCassetteCategory = strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory;
//D4000184                PPT_METHODTRACE_V2("txCassetteDeliveryReq", "nextRequiredCassetteCategory =  ",nextRequiredCassetteCategory);
//D4000016 Add End
//D4000184
//D4000184                objectIdentifier aTempOI;
//D4000184                /*------------------------*/
//D4000184                /*   Get Empty Cassette   */
//D4000184                /*------------------------*/
//D4000184                pptCassetteListInqResult strCassetteListInqResult;
//D4000184                //D4000043 rc = txCassetteListInq( strCassetteListInqResult,
//D4000184                //D4000043                         strObjCommonIn,
//D4000184                //D4000043                         "",            // const char * cassetteCategory,
//D4000184                //D4000043                         TRUE,          // CORBA::Boolean emptyFlag,
//D4000184                //D4000043                         aTempOI,       // const objectIdentifier& stockerID,
//D4000184                //D4000043                         aTempOI );     // const objectIdentifier& cassetteID
//D4000184
//D4000184//D4000016                rc = txCassetteListInq( strCassetteListInqResult,
//D4000184//D4000016                                        strObjCommonIn,
//D4000184//D4000016                                        "",                           // const char * cassetteCategory,
//D4000184//D4000016                                        TRUE,                         // CORBA::Boolean emptyFlag,
//D4000184//D4000016                                        aTempOI,                      // const objectIdentifier& stockerID,
//D4000184//D4000016                                        aTempOI,                      // const objectIdentifier& cassetteID
//D4000184//D4000016                                        CIMFW_Durable_Available,      // const char * cassetteStatus
//D4000184//D4000016                                        10);                          // CORBA:Long maxRetrieveCount
//D4000184
//D4000184//D4000016 Edit Start
//D4000184                rc = txCassetteListInq( strCassetteListInqResult,
//D4000184                                        strObjCommonIn,
//D4000184                                        nextRequiredCassetteCategory, // const char * cassetteCategory,
//D4000184                                        TRUE,                         // CORBA::Boolean emptyFlag,
//D4000184                                        aTempOI,                      // const objectIdentifier& stockerID,
//D4000184                                        aTempOI,                      // const objectIdentifier& cassetteID
//D4000184                                        CIMFW_Durable_Available,      // const char * cassetteStatus
//D4000184                                        10);                          // CORBA:Long maxRetrieveCount
//D4000184//D4000016 Edit End
//D4000184
//D4000184                if ( rc != RC_OK )
//D4000184                {
//D4000184                    PPT_METHODTRACE_V1(strTrace, "txCassetteListInq() rc != RC_OK");
//D4000184                    strCassetteDeliveryReqResult.strResult = strCassetteListInqResult.strResult;
//D4000184                    return( rc );
//D4000184                }
//D4000184
//D4000184                PPT_METHODTRACE_V1(strTrace, "");
//D4000184                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D4000184                PPT_METHODTRACE_V1(strTrace, "Abstract Empty Cassette Info");
//D4000184                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D4000184                /*----------------------------------*/
//D4000184                /*   Abstract Empty Cassette Info   */
//D4000184                /*----------------------------------*/
//D4000184                objEquipment_portInfo_AssignEmptyCassette_out strEquipment_portInfo_AssignEmptyCassette_out;
//D4000184                rc = equipment_portInfo_AssignEmptyCassette(
//D4000184                                strEquipment_portInfo_AssignEmptyCassette_out,
//D4000184                                strObjCommonIn,
//D4000184                                strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo,
//D4000184                                strCassetteListInqResult );
//D4000184                if ( rc != RC_OK )
//D4000184                {
//D4000184                    PPT_METHODTRACE_V1(strTrace, "equipment_portInfo_AssignEmptyCassette() rc != RC_OK");
//D4000184                    strCassetteDeliveryReqResult.strResult = strEquipment_portInfo_AssignEmptyCassette_out.strResult;
//D4000184                    return( rc );
//D4000184                }
//D4000184
//D4000184                PPT_METHODTRACE_V1(strTrace, "");
//D4000184                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D4000184                PPT_METHODTRACE_V1(strTrace, "Merge Process Cassette and Empty Cassette");
//D4000184                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
//D4000184                /*------------------------------------------------*/
//D4000184                /*   Merge Process Cassette and Empty Cassette    */
//D4000184                /*------------------------------------------------*/
//D4000184                objCassette_ListParameter_Merge_out strCassette_ListParameter_Merge_out;
//D4000184                strCassette_ListParameter_Merge_out.strStartCassette = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette;
//D4000184                rc = cassette_ListParameter_Merge(
//D4000184                                strCassette_ListParameter_Merge_out,
//D4000184                                strObjCommonIn,
//D4000184                                equipmentID,
//D4000184                                strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup,
//D4000184                                strEquipment_portInfo_AssignEmptyCassette_out.strDispatchReq_EmptyCassette );
//D4000184                if ( rc != RC_OK )
//D4000184                {
//D4000184                    PPT_METHODTRACE_V1(strTrace, "cassette_ListParameter_Merge() rc != RC_OK");
//D4000184                    strCassetteDeliveryReqResult.strResult = strCassette_ListParameter_Merge_out.strResult;
//D4000184                    return( rc );
//D4000184                }
//D4000184
//D4000184                PPT_METHODTRACE_V1(strTrace, "Set Common Buffer");
//D4000184                /*------------------------*/
//D4000184                /*   Set Common Buffer    */
//D4000184                /*------------------------*/
//D4000184                strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette = strCassette_ListParameter_Merge_out.strStartCassette;
//D4000184            }
//D4000184 delete end

                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                PPT_METHODTRACE_V1(strTrace, "Request to Start Lot Reservation");
                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                /*--------------------------------------*/
                /*   Request to Start Lot Reservation   */
                /*--------------------------------------*/
                objectIdentifier dummy;
                pptStartLotsReservationReqResult strStartLotsReservationReqResult;
//PSN000040416 start
                // Change TransactionID
                pptObjCommonIn strTmpObjCommonIn;
                strTmpObjCommonIn = strObjCommonIn;
                strTmpObjCommonIn.transactionID = CIMFWStrDup("TXTRC041");  // TransactionID of TxStartLotsReservationReq
//PSN000040416 end
                rc = txStartLotsReservationReq( strStartLotsReservationReqResult,
//PSN000040416                                                strObjCommonIn,
                                                strTmpObjCommonIn,       //PSN000040416
                                                equipmentID,
//D4200189                                                strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].portGroup,
                                                strPortGroupSeq[0].portGroup,  //D4200189
                                                dummy,         // Unnecessary. Set to controlJob_Create in this function.
                                                strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette,
//D7000182                                                "" );          // Confirm to IWASAKI
                                                "",                      //D7000182
                                                tmpAPCIFControlStatus ); //D7000182
                APCIFControlStatus = CIMFWStrDup(tmpAPCIFControlStatus); //D7000182
                CORBA::string_free(tmpAPCIFControlStatus);               //D7000182
                tmpAPCIFControlStatus = NULL;                            //D7000182

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1(strTrace, "txStartLotsReservationReq() rc != RC_OK");
                    strCassetteDeliveryReqResult.strResult = strStartLotsReservationReqResult.strResult;
//0.01          return( rc );
//0.01 add start
                    //---------------------------------------------------------------------------------------------
                    //  Prepare message text string for case of failure of start lot reservation
                    //  Only if start lot resercatioin for current equipment is fail, this messageText is filled
                    //---------------------------------------------------------------------------------------------
                    PPT_METHODTRACE_V1(strTrace, "### Prepare e-mail Message Text");

//P4000332 delete start
//P4000332                char* messageText = NULL;
//P4000332                CORBA::String_var messageTextVar ;
//P4000332
//P4000332                //Prepare e-mail Message Text
//P4000332                char* lotIDText   = NULL;
//P4000332                long lotIDTextLen = 0;
//P4000332                long nLotSeqLen = 0;
//P4000332
//P4000332//                long nLotSeqLen = strDeliveryReq_FillInTxTRC041InParm_out_forCurrent.strStartLot.length();
//P4000332//                for(iCnt=0; iCnt<nLotSeqLen; iCnt++)
//P4000332//                {
//P4000332//                    lotIDTextLen += CIMFWStrLen(strDeliveryReq_FillInTxTRC041InParm_out_forCurrent.strStartLot[iCnt].lotID.identifier) ;
//P4000332//                }
//P4000332                CORBA::Long nCasLen = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette.length();
//P4000332                PPT_METHODTRACE_V2(strTrace, "  nCasLen", nCasLen);
//P4000332                for (CORBA::Long i = 0; i< nCasLen; i++)
//P4000332                {
//P4000332                    CORBA::Long nLotLen = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette.length();
//P4000332                    PPT_METHODTRACE_V2(strTrace, "nLotLen", nLotLen);
//P4000332//0.03                    for (CORBA::Long j = 0; j< nCasLen; j++)
//P4000332                    for (CORBA::Long j = 0; j< nLotLen; j++)
//P4000332                    {
//P4000332                        lotIDTextLen += CIMFWStrLen(strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette[j].lotID.identifier);
//P4000332                        nLotSeqLen++;
//P4000332                    }
//P4000332                }
//P4000332
//P4000332//0.02          lotIDText = CORBA::string_alloc( lotIDTextLen + nLotSeqLen + 1 );
//P4000332//0.02          memset(lotIDText, '\0', lotIDTextLen + nLotSeqLen + 1);
//P4000332//0.02 add start
//P4000332                CORBA::Long nMallocSize = lotIDTextLen + nLotSeqLen + 1;
//P4000332                PPT_METHODTRACE_V2(strTrace, "  lotIDTextLen", lotIDTextLen);
//P4000332                PPT_METHODTRACE_V2(strTrace, "  nLotSeqLen  ", nLotSeqLen);
//P4000332                PPT_METHODTRACE_V2(strTrace, "  nMallocSize ", nMallocSize);
//P4000332                lotIDText = CORBA::string_alloc( nMallocSize );
//P4000332                memset(lotIDText, '\0', nMallocSize );
//P4000332//0.02 add end
//P4000332
//P4000332//                for(iCnt=0; iCnt<nLotSeqLen; iCnt++)
//P4000332//                {
//P4000332//                    if((char*)strDeliveryReq_FillInTxTRC041InParm_out_forCurrent.strStartLot[iCnt].lotID.identifier != NULL)
//P4000332//                    {
//P4000332//                        lotIDText = strcat( lotIDText, strDeliveryReq_FillInTxTRC041InParm_out_forCurrent.strStartLot[iCnt].lotID.identifier) ;
//P4000332//                    }
//P4000332//                    if(iCnt!=nLotSeqLen-1)
//P4000332//                    {
//P4000332//                        lotIDText = strcat( lotIDText, "," ) ;
//P4000332//                    }
//P4000332//                }
//P4000332                CORBA::Long nCnt = 0;
//P4000332                for (i = 0; i< nCasLen; i++)
//P4000332                {
//P4000332                    CORBA::Long nLotLen = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette.length();
//P4000332//0.03                    for (CORBA::Long j = 0; j< nCasLen; j++)
//P4000332                    for (CORBA::Long j = 0; j< nLotLen; j++)
//P4000332                    {
//P4000332//0.02                  if (strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette[j].lotID.identifier != NULL)
//P4000332                        if (CIMFWStrLen(strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette[j].lotID.identifier) != 0) //0.02
//P4000332                        {
//P4000332                            lotIDText = strcat( lotIDText, strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette[j].lotID.identifier);
//P4000332//0.04                      nCnt++;
//P4000332                        }
//P4000332                        nCnt++; //0.04
//P4000332//0.04                  if (nCnt != nLotSeqLen - 1)
//P4000332                        if ( nCnt != nLotSeqLen ) //0.04
//P4000332                        {
//P4000332                            lotIDText = strcat( lotIDText, "," ) ;
//P4000332                        }
//P4000332                    }
//P4000332                }
//P4000332                PPT_METHODTRACE_V2(strTrace, "  lotIDText Size", CIMFWStrLen(lotIDText));
//P4000332                PPT_METHODTRACE_V2(strTrace, "  lotIDText ", lotIDText);
//P4000332                CORBA::String_var lotIDTextVar = lotIDText;
//P4000332
//P4000332//0.02          messageText = CORBA::string_alloc(   CIMFWStrLen( equipmentID.identifier )
//P4000332//0.02                                             + CIMFWStrLen( lotIDText )
//P4000332//0.02                                             + CIMFWStrLen( strStartLotsReservationReqResult.strResult.transactionID )
//P4000332//0.02                                             + CIMFWStrLen( strStartLotsReservationReqResult.strResult.returnCode )
//P4000332//0.02                                             + CIMFWStrLen( strStartLotsReservationReqResult.strResult.messageID )
//P4000332//0.02                                             + CIMFWStrLen( strStartLotsReservationReqResult.strResult.messageText )
//P4000332//0.02                                             + CIMFWStrLen( strStartLotsReservationReqResult.strResult.reasonText )
//P4000332//0.02                                             + 256 ) ;
//P4000332
//P4000332//0.02          memset(messageText, '\0',   CIMFWStrLen( equipmentID.identifier )
//P4000332//0.02                                    + CIMFWStrLen( lotIDText )
//P4000332//0.02                                    + CIMFWStrLen( strStartLotsReservationReqResult.strResult.transactionID )
//P4000332//0.02                                    + CIMFWStrLen( strStartLotsReservationReqResult.strResult.returnCode )
//P4000332//0.02                                    + CIMFWStrLen( strStartLotsReservationReqResult.strResult.messageID )
//P4000332//0.02                                    + CIMFWStrLen( strStartLotsReservationReqResult.strResult.messageText )
//P4000332//0.02                                    + CIMFWStrLen( strStartLotsReservationReqResult.strResult.reasonText )
//P4000332//0.02                                    + 256 ) ;
//P4000332//0.02 add start
//P4000332                CORBA::Long nMaloc2Size = CIMFWStrLen( equipmentID.identifier )
//P4000332                                          + CIMFWStrLen( lotIDText )
//P4000332                                          + CIMFWStrLen( strStartLotsReservationReqResult.strResult.transactionID )
//P4000332                                          + CIMFWStrLen( strStartLotsReservationReqResult.strResult.returnCode )
//P4000332                                          + CIMFWStrLen( strStartLotsReservationReqResult.strResult.messageID )
//P4000332                                          + CIMFWStrLen( strStartLotsReservationReqResult.strResult.messageText )
//P4000332                                          + CIMFWStrLen( strStartLotsReservationReqResult.strResult.reasonText )
//P4000332                                          + 256 ;
//P4000332                PPT_METHODTRACE_V2(strTrace, "  nMaloc2Size", nMaloc2Size);
//P4000332                messageText = CORBA::string_alloc( nMaloc2Size  );
//P4000332                memset(messageText, '\0',   nMaloc2Size );
//P4000332//0.02 add end
//P4000332
//P4000332//0.04 add start
//P4000332PPT_METHODTRACE_V1(strTrace, "### MAIL VALUE DUMP start ###");
//P4000332PPT_METHODTRACE_V2(strTrace, "  equipmentID  ", equipmentID.identifier );
//P4000332PPT_METHODTRACE_V2(strTrace, "  lotIDText    ", lotIDText );
//P4000332PPT_METHODTRACE_V2(strTrace, "  transactionID", strStartLotsReservationReqResult.strResult.transactionID );
//P4000332PPT_METHODTRACE_V2(strTrace, "  returnCode   ", strStartLotsReservationReqResult.strResult.returnCode );
//P4000332PPT_METHODTRACE_V2(strTrace, "  messageID    ", strStartLotsReservationReqResult.strResult.messageID );
//P4000332PPT_METHODTRACE_V2(strTrace, "  messageText  ", strStartLotsReservationReqResult.strResult.messageText );
//P4000332PPT_METHODTRACE_V2(strTrace, "  reasonText   ", strStartLotsReservationReqResult.strResult.reasonText );
//P4000332PPT_METHODTRACE_V1(strTrace, "### MAIL VALUE DUMP end ###");
//P4000332//0.04 add end
//P4000332
//P4000332//0.04 modify start : add (const char*)
//P4000332                sprintf(messageText, "<<< Lot Delivery Failure >>>\n"\
//P4000332                                     "    Equipment ID            : %s \n"\
//P4000332                                     "    Lot IDs                 : %s \n"\
//P4000332                                     "    Transaction ID          : %s \n"\
//P4000332                                     "    Return Code             : %s \n"\
//P4000332                                     "    Message ID              : %s \n"\
//P4000332                                     "    Message Text            : %s \n"\
//P4000332                                     "    Reason Text             : %s",
//P4000332                                      (const char*)equipmentID.identifier,
//P4000332                                      (const char*)lotIDText,
//P4000332                                      (const char*)strStartLotsReservationReqResult.strResult.transactionID,
//P4000332                                      (const char*)strStartLotsReservationReqResult.strResult.returnCode,
//P4000332                                      (const char*)strStartLotsReservationReqResult.strResult.messageID,
//P4000332                                      (const char*)strStartLotsReservationReqResult.strResult.messageText,
//P4000332                                      (const char*)strStartLotsReservationReqResult.strResult.reasonText) ;
//P4000332//0.04 modify end
//P4000332
//P4000332                PPT_METHODTRACE_V2(strTrace, "  messageText Size", CIMFWStrLen(messageText));
//P4000332                PPT_METHODTRACE_V2(strTrace, "  messageText     ", messageText);
//P4000332
//P4000332                // for memory management of string
//P4000332                messageTextVar = messageText;
//P4000332 delete end

//P4000332 start
                    //-------------------------------------------------------
                    // Prepare e-mail Message Text
                    //-------------------------------------------------------
                    CORBA::String_var msg;
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< StartLotsReservation Error!  (Stocker -> EQP) >>>" );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot IDs              : " );

                    CORBA::Boolean bFirstSet = FALSE;
                    CORBA::Long nCasLen = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette.length();
                    for ( i=0; i < nCasLen; i++ )
                    {
                        CORBA::Long nLotLen = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette.length();
                        for ( j=0; j < nLotLen; j++ )
                        {
                            if (CIMFWStrLen(strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette[j].lotID.identifier) != 0)
                            {
                                if ( TRUE == bFirstSet )
                                {
                                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, ", " );
                                }
                                PPT_STRDUPCAT_STRING( FALSE, msg, msg, strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette[j].lotID.identifier );
                                bFirstSet = TRUE;
                            }
                        }
                    }
                    PPT_STRDUPCAT_STRING( TRUE, msg, msg, "" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.transactionID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.returnCode );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.messageID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.messageText );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartLotsReservationReqResult.strResult.reasonText );

                    PPT_METHODTRACE_V2("", "messageText--->", msg);
//P4000332 end

//P4000190 start
                    pptSysMsgStockInfo sysMsg;
                    sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                    sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
//P4000332                sysMsg.systemMessageText      = CIMFWStrDup( messageText );
                    sysMsg.systemMessageText      = CIMFWStrDup( msg );     //P4000332
                    sysMsg.notifyFlag             = TRUE;
                    sysMsg.equipmentID            = equipmentID;
                    sysMsg.equipmentStatus        = CIMFWStrDup("");
                    sysMsg.stockerID              = dummy;
                    sysMsg.stockerStatus          = CIMFWStrDup("");
                    sysMsg.AGVID                  = dummy;
                    sysMsg.AGVStatus              = CIMFWStrDup("");
                    sysMsg.lotID                  = dummy;
                    sysMsg.lotStatus              = CIMFWStrDup("");
                    sysMsg.routeID                = dummy;
                    sysMsg.operationID            = dummy;
                    sysMsg.operationNumber        = CIMFWStrDup("");
                    sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                    CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
//P4000190 end

//D51M0000                    PPT_METHODTRACE_V1(strTrace, "return ( RC_START_LOT_RESERVATION_FAIL )");
                    PPT_METHODTRACE_V2(strTrace, "return rc", rc); //D51M0000
//P4000332                strCassetteDeliveryReqResult.strResult.reasonText = messageTextVar;
                    strCassetteDeliveryReqResult.strResult.reasonText = msg;        //P4000332
//D51M0000                    return RC_START_LOT_RESERVATION_FAIL;
//INN-R170002 add start
                    if ( rc == CS_RC_CARRIER_CONTAMINATION_MISMATCH )
                    {
                        PPT_METHODTRACE_V1( "", "rc == CS_RC_CARRIER_CONTAMINATION_MISMATCH");

                        //copy holtLotList to TxCDR
                        csStartLotsReservationReqResult_siInfo* strStartLotsReservationReqResult_siInfo;
                        if( strStartLotsReservationReqResult.siInfo >>= strStartLotsReservationReqResult_siInfo)
                        {
                            PPT_METHODTRACE_V1( "", "strStartLotsReservationReqResult_siInfo is valid");
                            csCassetteDeliveryReqResult_siInfo strCassetteDeliveryReqResult_siInfo;
                            strCassetteDeliveryReqResult_siInfo.holdLotIDs = strStartLotsReservationReqResult_siInfo->holdLotIDs;
                            strCassetteDeliveryReqResult.siInfo <<= strCassetteDeliveryReqResult_siInfo;
                        }
                    }
//INN-R170002 add end
                    return ( rc ); //D51M0000
//0.01 add end
                }

                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                PPT_METHODTRACE_V1(strTrace, "Make txMultiCarrierXferReq parameter");
                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                /*------------------------------------------*/
                /*   Make txMultiCarrierXferReq parameter   */
                /*------------------------------------------*/
                objMultiCarrierXferFillInTXLGC012InParm_out strMultiCarrierXferFillInTXLGC012InParm_out;
                rc = multiCarrierXferFillInTXLGC012InParm( strMultiCarrierXferFillInTXLGC012InParm_out,
                                                           strObjCommonIn,
                                                           equipmentID,
                                                           strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1(strTrace, "multiCarrierXferFillInTXLGC012InParm() rc != RC_OK");
                    strCassetteDeliveryReqResult.strResult = strMultiCarrierXferFillInTXLGC012InParm_out.strResult;
//0.05          return( rc );
//0.05 add start
                    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                    PPT_METHODTRACE_V1(strTrace, "Request to Start Lot Reservation Cancel");
                    PPT_METHODTRACE_V1(strTrace, "***************************************************************");

                    CORBA::Long saveRC = rc;
                    /*---------------------------------------------*/
                    /*   Request to Start Lot Reservation Cancel   */
                    /*---------------------------------------------*/
                    pptStartLotsReservationCancelReqResult strStartLotsReservationCancelReqResult;
                    rc = txStartLotsReservationCancelReq ( strStartLotsReservationCancelReqResult,
                                                           strObjCommonIn,
                                                           equipmentID,
                                                           strStartLotsReservationReqResult.controlJobID,
//D7000182                                                           "" );          // Confirmed by katoh
                                                           "",                      //D7000182
                                                           tmpAPCIFControlStatus ); //D7000182
                    APCIFControlStatus = CIMFWStrDup(tmpAPCIFControlStatus);        //D7000182
                    CORBA::string_free(tmpAPCIFControlStatus);                      //D7000182
                    tmpAPCIFControlStatus = NULL;                                   //D7000182

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1(strTrace, "txStartLotsReservationCancelReq != RC_OK");
                    }

                    rc = saveRC;  //PSN000062212
//PSN000062212                    return RC_START_LOT_RESERVATION_FAIL;
                    return rc;    //PSN000062212
//0.05 add end
                }

//D5000194 start
                CORBA::Boolean bReRouteFlg = FALSE;
                CORBA::String_var reRouteXferFlag = CIMFWStrDup(getenv(SP_REROUTE_XFER_FLAG));
                PPT_METHODTRACE_V2("","SP_REROUTE_XFER_FLAG ---> ",reRouteXferFlag);
                if ( 0 == CIMFWStrCmp(reRouteXferFlag, "1") )
                {
                    PPT_METHODTRACE_V1("","reRouteXferFlag is 1");
                    bReRouteFlg = TRUE;
                }
//D5000194 end

                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                PPT_METHODTRACE_V1(strTrace, "Send Transfer Request to XM. (Stocker -> EQP)");
                PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                /*---------------------------------------------------*/
                /*   Send Transfer Request to XM. (Stocker -> EQP)   */
                /*---------------------------------------------------*/
                pptMultiCarrierXferReqResult strMultiCarrierXferReqResult;
                rc = txMultiCarrierXferReq( strMultiCarrierXferReqResult,
                                            strObjCommonIn,
                                            bReRouteFlg,  //D5000194
//D5000194                                            FALSE,        // const : FALSE
                                            "S",          // const : "S"
                                            strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1(strTrace, "txMultiCarrierXferReq() rc != RC_OK");
                    strCassetteDeliveryReqResult.strResult = strMultiCarrierXferReqResult.strResult;

//P4000332 start
                    //-------------------------------------------------------
                    // Prepare e-mail Message Text
                    //-------------------------------------------------------
                    CORBA::String_var msg;
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Transfer Error!  (Stocker -> EQP) >>>" );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );

                    CORBA::Long ii, jj;
                    CORBA::Long lenCarrierXfer = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq.length();
                    for ( ii=0; ii < lenCarrierXfer; ii++ )
                    {
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].carrierID.identifier );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].lotID.identifier );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].fromMachineID.identifier );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].fromPortID.identifier );
                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].toStockerGroup );

                        CORBA::Long lenToEqp = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine.length();
                        if ( 0 == lenToEqp )
                        {
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
                        }
                        for ( jj=0; jj < lenToEqp; jj++ )
                        {
                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine[jj].toMachineID.identifier );
                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
                            PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine[jj].toPortID.identifier );
                        }
                    }
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.transactionID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.returnCode );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.messageID );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.messageText );
                    PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                    PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.reasonText );

                    PPT_METHODTRACE_V2("", "messageText--->", msg);

                    /*------------------------*/
                    /*   Set System Message   */
                    /*------------------------*/
                    PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                    PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   txMultiCarrierXferReq() != RC_OK   */");
                    PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                    pptSysMsgStockInfo sysMsg;
                    sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                    sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                    sysMsg.systemMessageText      = CIMFWStrDup( msg );
                    sysMsg.notifyFlag             = TRUE;
                    sysMsg.equipmentID            = equipmentID;
                    sysMsg.equipmentStatus        = CIMFWStrDup("");
                    sysMsg.stockerID              = dummy;
                    sysMsg.stockerStatus          = CIMFWStrDup("");
                    sysMsg.AGVID                  = dummy;
                    sysMsg.AGVStatus              = CIMFWStrDup("");
                    sysMsg.lotID                  = dummy;
                    sysMsg.lotStatus              = CIMFWStrDup("");
                    sysMsg.routeID                = dummy;
                    sysMsg.operationID            = dummy;
                    sysMsg.operationNumber        = CIMFWStrDup("");
                    sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                    CORBA::Long lenSysMsg = strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length();
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence.length( lenSysMsg+1 );
                    strCassetteDeliveryReqResult.strSysMstStockInfoSequence[lenSysMsg] = sysMsg;
//P4000332 end

                    PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                    PPT_METHODTRACE_V1(strTrace, "Request to Start Lot Reservation Cancel");
                    PPT_METHODTRACE_V1(strTrace, "***************************************************************");

                    CORBA::Long saveRC = rc;
                    /*---------------------------------------------*/
                    /*   Request to Start Lot Reservation Cancel   */
                    /*---------------------------------------------*/
                    pptStartLotsReservationCancelReqResult strStartLotsReservationCancelReqResult;
                    rc = txStartLotsReservationCancelReq ( strStartLotsReservationCancelReqResult,
                                                           strObjCommonIn,
                                                           equipmentID,
                                                           strStartLotsReservationReqResult.controlJobID,
//D7000182                                                           "" );          // Confirmed by katoh
                                                           "",                      //D7000182
                                                           tmpAPCIFControlStatus ); //D7000182
                    APCIFControlStatus = CIMFWStrDup(tmpAPCIFControlStatus);        //D7000182
                    CORBA::string_free(tmpAPCIFControlStatus);                      //D7000182
                    tmpAPCIFControlStatus = NULL;                                   //D7000182

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1(strTrace, "txStartLotsReservationCancelReq != RC_OK");
                    }

                    rc = saveRC;
//0.01          return( rc );
//PSN000062212                    return RC_START_LOT_RESERVATION_FAIL; //0.01
                    return rc;    //PSN000062212
                }

                /*--------------------*/
                /*   End of Process   */
                /*--------------------*/
                PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                PPT_METHODTRACE_V1(strTrace, "@@@@@ OK! OK! OK! [Stocker to EQP]  Return to Main");
                PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                break;      //D4200189
            } //end of [i]  //D4200189
        }
    }

    /*--------------------*/
    /*                    */
    /*   Return to Main   */
    /*                    */
    /*--------------------*/
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txCassetteDeliveryReq");

    SET_MSG_RC(strCassetteDeliveryReqResult, MSG_OK, RC_OK);
    return RC_OK;
}
