//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txStartDurablesReservationCancelForInternalBufferReq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txStartDurablesReservationCancelForInternalBufferReq
(
    csStartDurablesReservationCancelForInternalBufferReqResult&         strStartDurablesReservationCancelForInternalBufferReqResult,
    const pptObjCommonIn&                                               strObjCommonIn,
    const csStartDurablesReservationCancelForInternalBufferReqInParam&  strStartDurablesReservationCancelForInternalBufferReqInParam,
    const char *                                                        claimMemo
    CORBAENV_LAST_CPP
)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txStartDurablesReservationCancelForInternalBufferReq");

    /*--------------------------------------------*/
    /*                                            */
    /*      Pre Process                           */
    /*                                            */
    /*--------------------------------------------*/
    // Initialize
    CORBA::Long rc = RC_OK;

    const csStartDurablesReservationCancelForInternalBufferReqInParam& strInParm = strStartDurablesReservationCancelForInternalBufferReqInParam;

    /*--------------------------------------------*/
    /*                                            */
    /*      In-Parameter Trace                    */
    /*                                            */
    /*--------------------------------------------*/
    //Trace InParameters
    PPT_METHODTRACE_V2("", "in-parm equipmentID           ", strInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "in-parm durableControlJobID   ", strInParm.durableControlJobID.identifier);

    if ( 0 >= CIMFWStrLen(strInParm.durableControlJobID.identifier) )
    {
        PPT_METHODTRACE_V1("", "durableControlJobID is empty.");
        SET_MSG_RC( strStartDurablesReservationCancelForInternalBufferReqResult,
                    MSG_DURABLECTRLJOBID_BLANK,
                    RC_DURABLECTRLJOBID_BLANK );
        return RC_DURABLECTRLJOBID_BLANK;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Tx ID Check                           */
    /*                                            */
    /*--------------------------------------------*/
    objEquipment_SpecialControlVsTxID_CheckCombination_out strEquipment_SpecialControlVsTxID_CheckCombination_out;
    objEquipment_SpecialControlVsTxID_CheckCombination_in  strEquipment_SpecialControlVsTxID_CheckCombination_in;
    strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID = strInParm.equipmentID;
    rc = equipment_SpecialControlVsTxID_CheckCombination( strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                                          strObjCommonIn,
                                                          strEquipment_SpecialControlVsTxID_CheckCombination_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_SpecialControlVsTxID_CheckCombination() != RC_OK", rc);
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strEquipment_SpecialControlVsTxID_CheckCombination_out.strResult;
        return rc;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Object Lock Process                   */
    /*                                            */
    /*--------------------------------------------*/
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = strInParm.equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "CSPDC007" );  //CS_TxStartDurablesReservationCancelForInternalBufferReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return rc;
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2("", "lockMode", lockMode);
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = strInParm.equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2("", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject);
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return rc;
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode == SP_EQP_LOCK_MODE_WRITE");
        PPT_METHODTRACE_V1("", "#### Machine Object Lock ");

        // Machine Object Lock Process
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          strInParm.equipmentID,
                          SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return rc;
        }
    }

    objDurableControlJob_startReserveInformation_Get_out strDurableControlJob_startReserveInformation_Get_out;
    objDurableControlJob_startReserveInformation_Get_in  strDurableControlJob_startReserveInformation_Get_in;
    strDurableControlJob_startReserveInformation_Get_in.durableControlJobID = strInParm.durableControlJobID;
    rc = durableControlJob_startReserveInformation_Get( strDurableControlJob_startReserveInformation_Get_out,
                                                        strObjCommonIn,
                                                        strDurableControlJob_startReserveInformation_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durableControlJob_startReserveInformation_Get() != RC_OK", rc);
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strDurableControlJob_startReserveInformation_Get_out.strResult;
        return rc;
    }

    CORBA::String_var durableCategory = strDurableControlJob_startReserveInformation_Get_out.durableCategory;
    if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
        PPT_SET_MSG_RC_KEY( strStartDurablesReservationCancelForInternalBufferReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            durableCategory );
        return RC_INVALID_DURABLE_CATEGORY ;
    }

    //----------------------------------------------------------------
    //  Port Object Lock Process
    //----------------------------------------------------------------
    pptStartDurableSequence strStartDurables;
    strStartDurables = strDurableControlJob_startReserveInformation_Get_out.strStartDurables;
    CORBA::ULong durableLen = strStartDurables.length();
    CORBA::ULong durableCnt = 0;

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");

        if (lockMode != SP_EQP_LOCK_MODE_WRITE)
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

            for ( CORBA::ULong ll = 0 ; ll < durableLen ; ll++ )
            {
                PPT_METHODTRACE_V2( "", "calling object_LockForEquipmentResource()", SP_ClassName_PosPortResource );

                objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                      strObjCommonIn,
                                                      strInParm.equipmentID,
                                                      strStartDurables[ll].strStartDurablePort.loadPortID,
                                                      SP_ClassName_PosPortResource );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", rc);
                    strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                    return rc;
                }

                PPT_METHODTRACE_V2("", "Locked port object  : ", strStartDurables[ll].strStartDurablePort.loadPortID.identifier);
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");

            objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
            rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                            strObjCommonIn,
                                                            strInParm.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_portInfoForInternalBuffer_GetDR() != RC_OK", rc);
                strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                return rc;
            }

            CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
            for ( CORBA::Long jj = 0 ; jj < lenPortInfo ; jj++ )
            {
                objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                      strObjCommonIn,
                                                      strInParm.equipmentID,
                                                      strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID,
                                                      SP_ClassName_PosPortResource );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", rc);
                    strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                    return rc;
                }

                PPT_METHODTRACE_V2("", "Locked port object  : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
            }
        }

        if (lockMode != SP_EQP_LOCK_MODE_WRITE)
        {
            for ( CORBA::ULong ll = 0 ; ll < durableLen ; ll++ )
            {
                PPT_METHODTRACE_V3( "", "calling advanced_object_LockForEquipmentResource()", SP_ClassName_PosMaterialLocation_ByCastID, strStartDurables[ll].durableID.identifier );

                objAdvanced_object_LockForEquipmentResource_in strAdvanced_object_LockForEquipmentResource_in;
                strAdvanced_object_LockForEquipmentResource_in.equipmentID              = strInParm.equipmentID;
                strAdvanced_object_LockForEquipmentResource_in.className                = CIMFWStrDup( SP_ClassName_PosMaterialLocation_ByCastID );
                strAdvanced_object_LockForEquipmentResource_in.objectID                 = strStartDurables[ll].durableID;
                strAdvanced_object_LockForEquipmentResource_in.objectLockType           = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_LockForEquipmentResource_in.bufferResourceName       = strStartDurables[ll].strStartDurablePort.loadPurposeType;
                strAdvanced_object_LockForEquipmentResource_in.bufferResourceLockType   = SP_ObjectLock_LockType_READ;

                objAdvanced_object_LockForEquipmentResource_out strAdvanced_object_LockForEquipmentResource_out;
                rc =  advanced_object_LockForEquipmentResource( strAdvanced_object_LockForEquipmentResource_out,
                                                                strObjCommonIn,
                                                                strAdvanced_object_LockForEquipmentResource_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_LockForEquipmentResource() != RC_OK", rc);
                    strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strAdvanced_object_LockForEquipmentResource_out.strResult;
                    return( rc );
                }
            }
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
            objObject_LockForEquipmentResource_out strobject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strobject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  strInParm.equipmentID,
                                                  strStartDurables[durableCnt].strStartDurablePort.loadPortID,
                                                  SP_ClassName_PosReticlePodPortResource );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", rc);
                strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strobject_LockForEquipmentResource_out.strResult;
                return rc;
            }
        }
    }

    // Lock DurableControlJob Object Process
    rc = object_Lock( strObject_Lock_out,
                      strObjCommonIn,
                      strInParm.durableControlJobID,
                      SP_ClassName_PosDurableControlJob );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }

    //----------------------------------------------------------------
    //  Lock Durable Object
    //----------------------------------------------------------------
    objectIdentifierSequence durableIDs;
    durableIDs.length(durableLen);
    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
        durableIDs[durableCnt] = strStartDurables[durableCnt].durableID;
    }

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosCassette);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosReticlePod);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosReticlePod );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosProcessDurable);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosProcessDurable );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Check Process for Durables          */
    /*                                            */
    /*--------------------------------------------*/
    csObjDurable_CheckConditionForOperationForInternalBuffer_in strDurable_CheckConditionForOperationForInternalBuffer_in;
    strDurable_CheckConditionForOperationForInternalBuffer_in.operation             = CIMFWStrDup( SP_Operation_StartReservationCancel );
    strDurable_CheckConditionForOperationForInternalBuffer_in.equipmentID           = strInParm.equipmentID;
    strDurable_CheckConditionForOperationForInternalBuffer_in.durableCategory       = durableCategory;
    strDurable_CheckConditionForOperationForInternalBuffer_in.strStartDurables      = strStartDurables;

    csObjDurable_CheckConditionForOperationForInternalBuffer_out strDurable_CheckConditionForOperationForInternalBuffer_out;
    rc = cs_durable_CheckConditionForOperationForInternalBuffer( strDurable_CheckConditionForOperationForInternalBuffer_out,
                                                                 strObjCommonIn,
                                                                 strDurable_CheckConditionForOperationForInternalBuffer_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_durable_CheckConditionForOperationForInternalBuffer() != RC_OK", rc);
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strDurable_CheckConditionForOperationForInternalBuffer_out.strResult;
        return rc;
    }

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);

        objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
        objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
        strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup( SP_Operation_StartReservationCancel );
        strDurable_status_CheckForOperation_in.durableID       = strStartDurables[durableCnt].durableID;
        strDurable_status_CheckForOperation_in.durableCategory = durableCategory;
        rc = durable_status_CheckForOperation( strDurable_status_CheckForOperation_out,
                                               strObjCommonIn,
                                               strDurable_status_CheckForOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_status_CheckForOperation() != RC_OK", rc);
            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
            return rc;
        }
    }

    /*---------------------------------------------------------------*/
    /*                                                               */
    /*        Check Equipment Port for Durable Operation             */
    /*                                                               */
    /*---------------------------------------------------------------*/
    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in;
    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.operation        = CIMFWStrDup( SP_Operation_StartReservationCancel );
    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.equipmentID      = strInParm.equipmentID;
    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.durableCategory  = durableCategory;
    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.strStartDurables = strStartDurables;

    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out;
    rc = cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                                               strObjCommonIn,
                                                                               strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer() != RC_OK", rc);
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult;
        return rc;
    }

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V3("", "loadPortID", strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier, durableCnt);
            CORBA::ULong basePGNo = 0;

            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                         strObjCommonIn,
                                         strInParm.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_portInfo_Get() != RC_OK", rc);
                strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return rc;
            }

            CORBA::ULong lenPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            PPT_METHODTRACE_V2("", "strEqpPortStatus.length", lenPortInfo);

            for ( CORBA::ULong portCnt=0; portCnt < lenPortInfo; portCnt++ )
            {
                PPT_METHODTRACE_V3("", "strEqpPortStatus[portCnt].portID", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier, portCnt);
                PPT_METHODTRACE_V2("", "strEqpPortStatus[portCnt].dispatchState", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].dispatchState);

                if ( 0 != CIMFWStrCmp( strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                       strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "Not same portID, continue...");
                    continue;
                }

                if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
                {
                    PPT_METHODTRACE_V1("", "dispatchState == Dispatched");

                    if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_LoadReq)
                      || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_UnloadReq)
                      || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_Unknown) )
                    {
                        PPT_METHODTRACE_V1("", "portState == LoadReq or UnloadReq or '-'");

                        /*------------------------*/
                        /*   change to Required   */
                        /*------------------------*/
                        objectIdentifier dummyOI;
                        objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out;
                        rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                             strObjCommonIn,
                                                             strInParm.equipmentID,
                                                             strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID,
                                                             SP_PortRsc_DispatchState_Required,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "equipment_dispatchState_Change() != RC_OK", rc);
                            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strEquipment_dispatchState_Change_out.strResult;
                            return rc;
                        }
                    }

                    basePGNo = portCnt;
                    break;
                }
            }
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V3("", "loadPortID", strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier, durableCnt);
            objEquipment_reticlePodPortInfo_GetDR_out strEquipment_reticlePodPortInfo_GetDR_out;
            rc = equipment_reticlePodPortInfo_GetDR( strEquipment_reticlePodPortInfo_GetDR_out,
                                                     strObjCommonIn,
                                                     strInParm.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_reticlePodPortInfo_GetDR() != RC_OK", rc);
                strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strEquipment_reticlePodPortInfo_GetDR_out.strResult;
                return rc;
            }

            CORBA::ULong lenPortInfo = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length();
            PPT_METHODTRACE_V2("", "strReticlePodPortInfo.length", lenPortInfo);

            for ( CORBA::ULong portCnt=0; portCnt < lenPortInfo; portCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length()", portCnt);
                if ( 0 != CIMFWStrCmp( strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                       strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].reticlePodPortID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "Not same portID, continue...");
                    continue;
                }

                if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].dispatchStatus, SP_PortRsc_DispatchState_Dispatched) )
                {
                    PPT_METHODTRACE_V1("", "dispatchStatus == Dispatched");

                    if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_LoadReq)
                      || 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_UnloadReq)
                      || 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_Unknown) )
                    {
                        PPT_METHODTRACE_V1("", "portStatus == LoadReq or UnloadReq or '-'");

                        objMachine_reticlePodPort_ReserveCancel_out strMachine_reticlePodPort_ReserveCancel_out;
                        rc = machine_reticlePodPort_ReserveCancel( strMachine_reticlePodPort_ReserveCancel_out,
                                                                   strObjCommonIn,
                                                                   strInParm.equipmentID,
                                                                   strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].reticlePodPortID );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "machine_reticlePodPort_ReserveCancel() != RC_OK", rc);
                            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strMachine_reticlePodPort_ReserveCancel_out.strResult;
                            return rc;
                        }
                    }

                    break;
                }
            }
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);

            objReticle_detailInfo_GetDR_out__170 strReticle_detailInfo_GetDR_out;
            objReticle_detailInfo_GetDR_in__160  strReticle_detailInfo_GetDR_in;
            strReticle_detailInfo_GetDR_in.reticleID                   = strStartDurables[durableCnt].durableID;
            strReticle_detailInfo_GetDR_in.durableOperationInfoFlag    = FALSE;
            strReticle_detailInfo_GetDR_in.durableWipOperationInfoFlag = FALSE;

            rc = reticle_detailInfo_GetDR__170(strReticle_detailInfo_GetDR_out, strObjCommonIn, strReticle_detailInfo_GetDR_in);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "reticle_detailInfo_GetDR__170() != RC_OK", rc);
                strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strReticle_detailInfo_GetDR_out.strResult;
                return( rc );
            }

            pptReticleStatusInfo__170 reticleStatusInfo = strReticle_detailInfo_GetDR_out.strReticleStatusInqResult.reticleStatusInfo;

            if ( 0 != CIMFWStrLen(reticleStatusInfo.reticlePodID.identifier) )
            {
                PPT_METHODTRACE_V1("", "Reticle is in ReticlePod");
                objEquipment_reticlePodPortInfo_GetDR_out strEquipment_reticlePodPortInfo_GetDR_out;
                rc = equipment_reticlePodPortInfo_GetDR( strEquipment_reticlePodPortInfo_GetDR_out,
                                                         strObjCommonIn,
                                                         strInParm.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_reticlePodPortInfo_GetDR() != RC_OK", rc);
                    strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strEquipment_reticlePodPortInfo_GetDR_out.strResult;
                    return rc;
                }

                CORBA::ULong lenPortInfo = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length();
                PPT_METHODTRACE_V2("", "strReticlePodPortInfo.length", lenPortInfo);

                for ( CORBA::ULong portCnt=0; portCnt < lenPortInfo; portCnt++ )
                {
                    PPT_METHODTRACE_V2("", "loop to strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length()", portCnt);
                    if ( 0 != CIMFWStrCmp( strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                           strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].reticlePodPortID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "Not same portID, continue...");
                        continue;
                    }

                    if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].dispatchStatus, SP_PortRsc_DispatchState_Dispatched) )
                    {
                        PPT_METHODTRACE_V1("", "dispatchStatus == Dispatched");

                        if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_LoadReq)
                          || 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_UnloadReq)
                          || 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_Unknown) )
                        {
                            PPT_METHODTRACE_V1("", "portStatus == LoadReq or UnloadReq or '-'");

                            objMachine_reticlePodPort_ReserveCancel_out strMachine_reticlePodPort_ReserveCancel_out;
                            rc = machine_reticlePodPort_ReserveCancel( strMachine_reticlePodPort_ReserveCancel_out,
                                                                       strObjCommonIn,
                                                                       strInParm.equipmentID,
                                                                       strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].reticlePodPortID );

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "machine_reticlePodPort_ReserveCancel() != RC_OK", rc);
                                strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strMachine_reticlePodPort_ReserveCancel_out.strResult;
                                return rc;
                            }
                        }

                        break;
                    }
                }
            }
        }
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Main process                        */
    /*                                            */
    /*--------------------------------------------*/
    // Clear reserved info
    objProcess_startDurablesReserveInformation_Clear_out strProcess_startDurablesReserveInformation_Clear_out;
    objProcess_startDurablesReserveInformation_Clear_in  strProcess_startDurablesReserveInformation_Clear_in;
    strProcess_startDurablesReserveInformation_Clear_in.durableCategory  = durableCategory;
    strProcess_startDurablesReserveInformation_Clear_in.strStartDurables = strStartDurables;
    rc = process_startDurablesReserveInformation_Clear( strProcess_startDurablesReserveInformation_Clear_out,
                                                        strObjCommonIn,
                                                        strProcess_startDurablesReserveInformation_Clear_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "process_startDurablesReserveInformation_Clear() != RC_OK", rc);
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strProcess_startDurablesReserveInformation_Clear_out.strResult;
        return rc;
    }

    // Delete durable control job
    pptDurableControlJobCreateRequest strDurableControlJobCreateRequest;
    strDurableControlJobCreateRequest.equipmentID      = strInParm.equipmentID;
    strDurableControlJobCreateRequest.durableCategory  = durableCategory;
    strDurableControlJobCreateRequest.strStartDurables = strStartDurables;

    pptDurableControlJobManageReqInParam strDurableControlJobManageReqInParam;
    strDurableControlJobManageReqInParam.durableControlJobID               = strInParm.durableControlJobID;
    strDurableControlJobManageReqInParam.controlJobAction                  = CIMFWStrDup( SP_DurableControlJobAction_Type_delete );
    strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest = strDurableControlJobCreateRequest;

    pptDurableControlJobManageReqResult  strDurableControlJobManageReqResult;
    rc = txDurableControlJobManageReq( strDurableControlJobManageReqResult,
                                       strObjCommonIn,
                                       strDurableControlJobManageReqInParam,
                                       claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txDurableControlJobManageReq() != RC_OK", rc);
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strDurableControlJobManageReqResult.strResult;
        return rc;
    }

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);

            // Change Cassette's Dispatch State to FALSE
            objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out,
                                                strObjCommonIn,
                                                strStartDurables[durableCnt].durableID,
                                                FALSE );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_dispatchState_Change() != RC_OK", rc);
                strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
                return rc;
            }
        }
    }

    /*------------------------------------------------------------*/
    /*                                                            */
    /*        Send Start Durables Reservation Cancel to TCS       */
    /*                                                            */
    /*------------------------------------------------------------*/
    CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0;
    CORBA::Long retryCountValue = 0;

    if ( 0 == CIMFWStrLen(tmpSleepTimeValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = atoi(tmpSleepTimeValue);
    }

    if ( 0 == CIMFWStrLen(tmpRetryCountValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("", "env value of SP_BIND_SLEEP_TIME_TCS  = ", sleepTimeValue);
    PPT_METHODTRACE_V2("", "env value of SP_BIND_RETRY_COUNT_TCS = ", retryCountValue);

    objTCSMgr_SendStartDurablesReservationCancelReq_out strTCSMgr_SendStartDurablesReservationCancelReq_out;
    objTCSMgr_SendStartDurablesReservationCancelReq_in  strTCSMgr_SendStartDurablesReservationCancelReq_in;
    strTCSMgr_SendStartDurablesReservationCancelReq_in.strStartDurablesReservationCancelReqInParam.equipmentID         = strInParm.equipmentID;
    strTCSMgr_SendStartDurablesReservationCancelReq_in.strStartDurablesReservationCancelReqInParam.durableControlJobID = strInParm.durableControlJobID;
    strTCSMgr_SendStartDurablesReservationCancelReq_in.claimMemo                                                       = claimMemo;

    //'retryCountValue + 1' means first try plus retry count
    for ( CORBA::ULong retryNum=0; retryNum < (retryCountValue + 1); retryNum++ )
    {
        PPT_METHODTRACE_V2("", "loop to retryCountValue + 1", retryNum);
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        rc = TCSMgr_SendStartDurablesReservationCancelReq( strTCSMgr_SendStartDurablesReservationCancelReq_out,
                                                           strObjCommonIn,
                                                           strTCSMgr_SendStartDurablesReservationCancelReq_in );

        PPT_METHODTRACE_V2("", "rc = ", rc);

        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL
               || rc == RC_EXT_SERVER_NIL_OBJ
               || rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("", "TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...", retryNum);
            PPT_METHODTRACE_V2("", "now sleeping... ", sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendStartDurablesReservationCancelReq() != RC_OK");
            strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strTCSMgr_SendStartDurablesReservationCancelReq_out.strResult;
            return rc;
        }
    }

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "TCSMgr_SendStartDurablesReservationCancelReq() != RC_OK");
        strStartDurablesReservationCancelForInternalBufferReqResult.strResult = strTCSMgr_SendStartDurablesReservationCancelReq_out.strResult;
        return rc;
    }

    // Set Return Structure
    strStartDurablesReservationCancelForInternalBufferReqResult.durableCategory  = durableCategory;
    strStartDurablesReservationCancelForInternalBufferReqResult.strStartDurables = strStartDurables;

    // Return to caller
    SET_MSG_RC( strStartDurablesReservationCancelForInternalBufferReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txStartDurablesReservationCancelForInternalBufferReq");
    return RC_OK;
}