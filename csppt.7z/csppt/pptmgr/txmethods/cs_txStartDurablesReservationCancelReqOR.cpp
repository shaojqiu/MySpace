//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: txStartDurablesReservationCancelReq.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txStartDurablesReservationCancelReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2015/01/05 DSN000085770 Sa Guo         Durable Management.
// 2015/11/11 DSN000096126 C.Mo           reticle_detailInfo_GetDR__090 ==> reticle_detailInfo_GetDR__160
// 2016/07/27 DSN000101569 C.Mo           reticle_detailInfo_GetDR__160 ==> reticle_detailInfo_GetDR__170
//
// Description:
//    This function cancels the relation between Equipments and Durables reserved by TxStartDurablesReservationReq transaction.
//      - Input parameter check( durableControlJobID is not empty )
//      - Consisytency check of Transaction ID and SpecialControl of Equipment Category
//      - Get startDurablesReserve information
//      - Check condition of durable( PFX is not Nil, Cassette is not dispatchReserved )
//      - Check status of durable
//      - Check equipment and port state for cassette and reticle pod( Input EqpID and durableControlJob's EqpID should match )
//      - Change equipment dispatchState if needed
//      - reticlePodPort reserveCancel if needed
//      - Clear startDurablesReserve information
//      - Delete durable controlJob
//      - Change cassette dispatchState
//      - Send start durables reservation cancel notification request to TCS
//
// Return:
//    long
//
// Parameter:
//
//  [Input Parameters]:
//    const pptObjCommonIn&                                strObjCommonIn
//    const pptStartDurablesReservationCancelReqInParam&   strStartDurablesReservationCancelReqInParam
//    const char *                                         claimMemo
//
//  [Output Parameters]:
//    pptStartDurablesReservationCancelReqResult&          strStartDurablesReservationCancelReqResult
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txStartDurablesReservationCancelReq(
    pptStartDurablesReservationCancelReqResult&          strStartDurablesReservationCancelReqResult,
    const pptObjCommonIn&                                strObjCommonIn,
    const pptStartDurablesReservationCancelReqInParam&   strStartDurablesReservationCancelReqInParam,
    const char *                                         claimMemo
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txStartDurablesReservationCancelReq");
    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------

    // Initialize
    CORBA::Long rc = RC_OK;

    const pptStartDurablesReservationCancelReqInParam& strInParm = strStartDurablesReservationCancelReqInParam;

    //----------------------------------------------------------------
    //  In-Parameter Trace
    //----------------------------------------------------------------
    //Trace InParameters
    PPT_METHODTRACE_V2("", "in-parm equipmentID           ", strInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "in-parm durableControlJobID   ", strInParm.durableControlJobID.identifier);

    if ( 0 >= CIMFWStrLen(strInParm.durableControlJobID.identifier) )
    {
        PPT_METHODTRACE_V1("", "durableControlJobID is empty.");
        SET_MSG_RC( strStartDurablesReservationCancelReqResult,
                    MSG_DURABLECTRLJOBID_BLANK,
                    RC_DURABLECTRLJOBID_BLANK );
        return RC_DURABLECTRLJOBID_BLANK;
    }

    objEquipment_SpecialControlVsTxID_CheckCombination_out strEquipment_SpecialControlVsTxID_CheckCombination_out;
    objEquipment_SpecialControlVsTxID_CheckCombination_in  strEquipment_SpecialControlVsTxID_CheckCombination_in;
    strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID = strInParm.equipmentID;
    rc = equipment_SpecialControlVsTxID_CheckCombination( strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                                          strObjCommonIn,
                                                          strEquipment_SpecialControlVsTxID_CheckCombination_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_SpecialControlVsTxID_CheckCombination() != RC_OK", rc);
        strStartDurablesReservationCancelReqResult.strResult = strEquipment_SpecialControlVsTxID_CheckCombination_out.strResult;
        return rc;
    }

    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = strInParm.equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXPDC041" ); //TxStartDurablesReservationCancelReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strStartDurablesReservationCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return rc;
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2("", "lockMode", lockMode);
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = strInParm.equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2("", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject);
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return rc;
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode == SP_EQP_LOCK_MODE_WRITE");
        /*--------------------------------------------*/
        /*                                            */
        /*      Machine Object Lock Process           */
        /*                                            */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("", "#### Machine Object Lock ");
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          strInParm.equipmentID,
                          SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelReqResult.strResult = strObject_Lock_out.strResult;
            return rc;
        }
    }

    objDurableControlJob_startReserveInformation_Get_out strDurableControlJob_startReserveInformation_Get_out;
    objDurableControlJob_startReserveInformation_Get_in  strDurableControlJob_startReserveInformation_Get_in;
    strDurableControlJob_startReserveInformation_Get_in.durableControlJobID = strInParm.durableControlJobID;
    rc = durableControlJob_startReserveInformation_Get( strDurableControlJob_startReserveInformation_Get_out,
                                                        strObjCommonIn,
                                                        strDurableControlJob_startReserveInformation_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durableControlJob_startReserveInformation_Get() != RC_OK", rc);
        strStartDurablesReservationCancelReqResult.strResult = strDurableControlJob_startReserveInformation_Get_out.strResult;
        return rc;
    }

    CORBA::String_var durableCategory = strDurableControlJob_startReserveInformation_Get_out.durableCategory;
    if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
        PPT_SET_MSG_RC_KEY( strStartDurablesReservationCancelReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            durableCategory );
        return RC_INVALID_DURABLE_CATEGORY ;
    }

    pptStartDurableSequence strStartDurables;
    strStartDurables = strDurableControlJob_startReserveInformation_Get_out.strStartDurables;
    CORBA::ULong durableLen = strStartDurables.length();
    CORBA::ULong durableCnt = 0;

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objPortResource_allPortsInSameGroup_Get_out strPortResource_allPortsInSameGroup_Get_out;
        rc = portResource_allPortsInSameGroup_Get( strPortResource_allPortsInSameGroup_Get_out,
                                                   strObjCommonIn,
                                                   strInParm.equipmentID,
                                                   strStartDurables[0].strStartDurablePort.loadPortID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "portResource_allPortsInSameGroup_Get() != RC_OK", rc);
            strStartDurablesReservationCancelReqResult.strResult = strPortResource_allPortsInSameGroup_Get_out.strResult;
            return rc;
        }

        /*---------------------------------------------------------*/
        /* Lock All Ports being in the same Port Group as ToPort   */
        /*---------------------------------------------------------*/
        CORBA::ULong lenToPort = strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        for ( CORBA::ULong portCnt=0; portCnt < lenToPort; portCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length()", portCnt);
            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  strInParm.equipmentID,
                                                  strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID,
                                                  SP_ClassName_PosPortResource );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier);
                strStartDurablesReservationCancelReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "Locked port object  : ", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier);
        }

        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
            /*-----------------------------------*/
            /*  Check cassette transfer status   */
            /*-----------------------------------*/
            PPT_METHODTRACE_V1( "", "Check cassette transfer status");
            objCassette_transferState_Get_out strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                             strObjCommonIn,
                                             strStartDurables[durableCnt].durableID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_transferState_Get != RC_OK", rc);
                strStartDurablesReservationCancelReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return rc;
            }

            if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )
            {
                PPT_METHODTRACE_V2("", "Cassette's transferState == EI ", strStartDurables[durableCnt].durableID.identifier);
                /*------------------------------------*/
                /*   Get Cassette Info in Equipment   */
                /*------------------------------------*/
                PPT_METHODTRACE_V1("", "Get Cassette Info in Equipment");
                objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
                rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                               strObjCommonIn,
                                               strStartDurables[durableCnt].durableID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "cassette_equipmentID_Get != RC_OK", rc);
                    strStartDurablesReservationCancelReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                    return rc;
                }
                PPT_METHODTRACE_V2("", "equipmentID == ", strCassette_equipmentID_Get_out.equipmentID.identifier);

                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                             strObjCommonIn,
                                             strCassette_equipmentID_Get_out.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_portInfo_Get != RC_OK", rc);
                    strStartDurablesReservationCancelReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                    return rc;
                }

                /*----------------------------------------------------------*/
                /*  Lock port object which has the specified cassette.      */
                /*----------------------------------------------------------*/
                CORBA::ULong lenFromPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
                for ( portCnt=0 ; portCnt < lenFromPort ; portCnt++ )
                {
                    PPT_METHODTRACE_V2("", "loop to strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", portCnt);
                    if ( 0 == CIMFWStrCmp(strStartDurables[durableCnt].durableID.identifier,
                                          strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].loadedCassetteID.identifier) )
                    {
                        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                              strObjCommonIn,
                                                              strCassette_equipmentID_Get_out.equipmentID,
                                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID,
                                                              SP_ClassName_PosPortResource );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier);
                            strStartDurablesReservationCancelReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                            return rc;
                        }
                        PPT_METHODTRACE_V2("", "Locked port object(to)  : ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier);
                    }
                }
            }
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
            objObject_LockForEquipmentResource_out strobject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strobject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  strInParm.equipmentID,
                                                  strStartDurables[durableCnt].strStartDurablePort.loadPortID,
                                                  SP_ClassName_PosReticlePodPortResource );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", rc);
                strStartDurablesReservationCancelReqResult.strResult = strobject_LockForEquipmentResource_out.strResult;
                return rc;
            }
        }
    }

    rc = object_Lock( strObject_Lock_out,
                      strObjCommonIn,
                      strInParm.durableControlJobID,
                      SP_ClassName_PosDurableControlJob );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
        strStartDurablesReservationCancelReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }

    objectIdentifierSequence durableIDs;
    durableIDs.length(durableLen);
    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
        durableIDs[durableCnt] = strStartDurables[durableCnt].durableID;
    }

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosCassette);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosReticlePod);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosReticlePod );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosProcessDurable);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosProcessDurable );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationCancelReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }

    CORBA::String_var portGroupID;
    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objEquipment_portGroupID_Get_out strEquipment_portGroupID_Get_out;
        objEquipment_portGroupID_Get_in  strEquipment_portGroupID_Get_in;
        strEquipment_portGroupID_Get_in.equipmentID = strInParm.equipmentID;
        strEquipment_portGroupID_Get_in.portID      = strStartDurables[0].strStartDurablePort.loadPortID;
        rc = equipment_portGroupID_Get( strEquipment_portGroupID_Get_out,
                                        strObjCommonIn,
                                        strEquipment_portGroupID_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_portGroupID_Get() != RC_OK", rc);
            strStartDurablesReservationCancelReqResult.strResult = strEquipment_portGroupID_Get_out.strResult;
            return rc;
        }
        portGroupID = strEquipment_portGroupID_Get_out.portGroupID;
    }
    else
    {
        PPT_METHODTRACE_V1("", "durableCategory != SP_DurableCat_Cassette");
        portGroupID = CIMFWStrDup("");
    }

    objDurable_CheckConditionForOperation_out strDurable_CheckConditionForOperation_out;
    objDurable_CheckConditionForOperation_in  strDurable_CheckConditionForOperation_in;
    strDurable_CheckConditionForOperation_in.operation             = CIMFWStrDup( SP_Operation_StartReservationCancel );
    strDurable_CheckConditionForOperation_in.equipmentID           = strInParm.equipmentID;
    strDurable_CheckConditionForOperation_in.durableCategory       = durableCategory;
    strDurable_CheckConditionForOperation_in.strStartDurables      = strStartDurables;
    strDurable_CheckConditionForOperation_in.strDurableStartRecipe = strDurableControlJob_startReserveInformation_Get_out.strDurableStartRecipe;
    rc = durable_CheckConditionForOperation( strDurable_CheckConditionForOperation_out,
                                             strObjCommonIn,
                                             strDurable_CheckConditionForOperation_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durable_CheckConditionForOperation() != RC_OK", rc);
        strStartDurablesReservationCancelReqResult.strResult = strDurable_CheckConditionForOperation_out.strResult;
        return rc;
    }

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
        objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
        objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
        strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup( SP_Operation_StartReservationCancel );
        strDurable_status_CheckForOperation_in.durableID       = strStartDurables[durableCnt].durableID;
        strDurable_status_CheckForOperation_in.durableCategory = durableCategory;
        rc = durable_status_CheckForOperation( strDurable_status_CheckForOperation_out,
                                               strObjCommonIn,
                                               strDurable_status_CheckForOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_status_CheckForOperation() != RC_OK", rc);
            strStartDurablesReservationCancelReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
            return rc;
        }
    }

    objEquipment_and_portState_CheckForDurableOperation_out strEquipment_and_portState_CheckForDurableOperation_out;
    objEquipment_and_portState_CheckForDurableOperation_in  strEquipment_and_portState_CheckForDurableOperation_in;
    strEquipment_and_portState_CheckForDurableOperation_in.operation        = CIMFWStrDup( SP_Operation_StartReservationCancel );
    strEquipment_and_portState_CheckForDurableOperation_in.equipmentID      = strInParm.equipmentID;
    strEquipment_and_portState_CheckForDurableOperation_in.portGroupID      = portGroupID;
    strEquipment_and_portState_CheckForDurableOperation_in.durableCategory  = durableCategory;
    strEquipment_and_portState_CheckForDurableOperation_in.strStartDurables = strStartDurables;
    rc = equipment_and_portState_CheckForDurableOperation( strEquipment_and_portState_CheckForDurableOperation_out,
                                                           strObjCommonIn,
                                                           strEquipment_and_portState_CheckForDurableOperation_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_and_portState_CheckForDurableOperation() != RC_OK", rc);
        strStartDurablesReservationCancelReqResult.strResult = strEquipment_and_portState_CheckForDurableOperation_out.strResult;
        return rc;
    }

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V3("", "loadPortID", strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier, durableCnt);
            CORBA::ULong basePGNo = 0;

            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                         strObjCommonIn,
                                         strInParm.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_portInfo_Get() != RC_OK", rc);
                strStartDurablesReservationCancelReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return rc;
            }

            CORBA::ULong lenPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            PPT_METHODTRACE_V2("", "strEqpPortStatus.length", lenPortInfo);

            for ( CORBA::ULong portCnt=0; portCnt < lenPortInfo; portCnt++ )
            {
                PPT_METHODTRACE_V3("", "strEqpPortStatus[portCnt].portID", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier, portCnt);
                PPT_METHODTRACE_V2("", "strEqpPortStatus[portCnt].dispatchState", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].dispatchState);

                if ( 0 != CIMFWStrCmp( strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                       strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "Not same portID, continue...");
                    continue;
                }

                if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
                {
                    PPT_METHODTRACE_V1("", "dispatchState == Dispatched");

                    if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_LoadReq)
                      || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_UnloadReq)
                      || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_Unknown) )
                    {
                        PPT_METHODTRACE_V1("", "portState == LoadReq or UnloadReq or '-'");

                        /*------------------------*/
                        /*   change to Required   */
                        /*------------------------*/
                        objectIdentifier dummyOI;
                        objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out;
                        rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                             strObjCommonIn,
                                                             strInParm.equipmentID,
                                                             strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID,
                                                             SP_PortRsc_DispatchState_Required,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "equipment_dispatchState_Change() != RC_OK", rc);
                            strStartDurablesReservationCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult;
                            return rc;
                        }
                    }

                    basePGNo = portCnt;
                    break;
                }
            }

            /*--------------------------*/
            /*   find Same Port Group   */
            /*--------------------------*/
            for ( portCnt=0; portCnt < lenPortInfo; portCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to strEqpPortStatus", portCnt);

                /*===== Omit Base Port =====*/
                if ( portCnt == basePGNo )
                {
                    PPT_METHODTRACE_V1("", "portCnt == basePGNo, continue...");
                    continue;
                }
                /*===== Omit Different Group's Port =====*/
                if ( 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup,
                                      strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[basePGNo].portGroup) )
                {
                    PPT_METHODTRACE_V1("", "Not same portGroup, continue...");
                    continue;
                }

                /*===== Check portState =====*/
                if ( 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_LoadReq)
                  && 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_UnloadReq)
                  && 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portState, SP_PortRsc_PortState_Unknown) )
                {
                    PPT_METHODTRACE_V1("", "portState != LoadReq or UnloadReq or '-', continue...");
                    continue;
                }

                /*===== Check dispatchState =====*/
                if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].dispatchState, SP_PortRsc_DispatchState_Dispatched)
                  || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].dispatchState, SP_PortRsc_DispatchState_NotDispatched) )
                {
                    PPT_METHODTRACE_V1("", "Same PortGroup == Dispatched or NotDispatched");
                    PPT_METHODTRACE_V2("", "dispatchState", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].dispatchState);

                    /*------------------------*/
                    /*   change to Required   */
                    /*------------------------*/
                    objectIdentifier dummyOI;
                    objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out ;
                    rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                         strObjCommonIn,
                                                         strInParm.equipmentID,
                                                         strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID,
                                                         SP_PortRsc_DispatchState_Required,
                                                         dummyOI,
                                                         dummyOI,
                                                         dummyOI,
                                                         dummyOI );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "equipment_dispatchState_Change() != RC_OK", rc);
                        strStartDurablesReservationCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult;
                        return rc;
                    }
                }
            }
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V3("", "loadPortID", strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier, durableCnt);
            objEquipment_reticlePodPortInfo_GetDR_out strEquipment_reticlePodPortInfo_GetDR_out;
            rc = equipment_reticlePodPortInfo_GetDR( strEquipment_reticlePodPortInfo_GetDR_out,
                                                     strObjCommonIn,
                                                     strInParm.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_reticlePodPortInfo_GetDR() != RC_OK", rc);
                strStartDurablesReservationCancelReqResult.strResult = strEquipment_reticlePodPortInfo_GetDR_out.strResult;
                return rc;
            }

            CORBA::ULong lenPortInfo = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length();
            PPT_METHODTRACE_V2("", "strReticlePodPortInfo.length", lenPortInfo);

            for ( CORBA::ULong portCnt=0; portCnt < lenPortInfo; portCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length()", portCnt);
                if ( 0 != CIMFWStrCmp( strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                       strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].reticlePodPortID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "Not same portID, continue...");
                    continue;
                }

                if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].dispatchStatus, SP_PortRsc_DispatchState_Dispatched) )
                {
                    PPT_METHODTRACE_V1("", "dispatchStatus == Dispatched");

                    if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_LoadReq)
                      || 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_UnloadReq)
                      || 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_Unknown) )
                    {
                        PPT_METHODTRACE_V1("", "portStatus == LoadReq or UnloadReq or '-'");

                        objMachine_reticlePodPort_ReserveCancel_out strMachine_reticlePodPort_ReserveCancel_out;
                        rc = machine_reticlePodPort_ReserveCancel( strMachine_reticlePodPort_ReserveCancel_out,
                                                                   strObjCommonIn,
                                                                   strInParm.equipmentID,
                                                                   strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].reticlePodPortID );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "machine_reticlePodPort_ReserveCancel() != RC_OK", rc);
                            strStartDurablesReservationCancelReqResult.strResult = strMachine_reticlePodPort_ReserveCancel_out.strResult;
                            return rc;
                        }
                    }

                    break;
                }
            }
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
//DSN000096126            objReticle_detailInfo_GetDR_out__090 strReticle_detailInfo_GetDR_out__090;
//DSN000096126            objReticle_detailInfo_GetDR_in__090  strReticle_detailInfo_GetDR_in__090;
//DSN000096126            strReticle_detailInfo_GetDR_in__090.reticleID = strStartDurables[durableCnt].durableID;
//DSN000096126            rc = reticle_detailInfo_GetDR__090( strReticle_detailInfo_GetDR_out__090,
//DSN000096126                                                strObjCommonIn,
//DSN000096126                                                strReticle_detailInfo_GetDR_in__090 );
//DSN000096126            if ( rc != RC_OK )
//DSN000096126            {
//DSN000096126                PPT_METHODTRACE_V2("", "reticle_detailInfo_GetDR__090() != RC_OK", rc);
//DSN000096126                strStartDurablesReservationCancelReqResult.strResult = strReticle_detailInfo_GetDR_out__090.strResult;
//DSN000096126                return rc;
//DSN000096126            }
//DSN000096126            pptReticleStatusInfo reticleStatusInfo = strReticle_detailInfo_GetDR_out__090.strReticleStatusInqResult.reticleStatusInfo;
//DSN000096126 Add Start
//DSN000101569            objReticle_detailInfo_GetDR_out__160 strReticle_detailInfo_GetDR_out;
            objReticle_detailInfo_GetDR_out__170 strReticle_detailInfo_GetDR_out;                                               //DSN000101569
            objReticle_detailInfo_GetDR_in__160  strReticle_detailInfo_GetDR_in;
            strReticle_detailInfo_GetDR_in.reticleID                   = strStartDurables[durableCnt].durableID;
            strReticle_detailInfo_GetDR_in.durableOperationInfoFlag    = FALSE;
            strReticle_detailInfo_GetDR_in.durableWipOperationInfoFlag = FALSE;
//DSN000101569            rc = reticle_detailInfo_GetDR__160(strReticle_detailInfo_GetDR_out, strObjCommonIn, strReticle_detailInfo_GetDR_in);
            rc = reticle_detailInfo_GetDR__170(strReticle_detailInfo_GetDR_out, strObjCommonIn, strReticle_detailInfo_GetDR_in);//DSN000101569
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "reticle_detailInfo_GetDR__170() != RC_OK", rc);
                strStartDurablesReservationCancelReqResult.strResult = strReticle_detailInfo_GetDR_out.strResult;
                return( rc );
            }
//DSN000101569            pptReticleStatusInfo__160 reticleStatusInfo = strReticle_detailInfo_GetDR_out.strReticleStatusInqResult.reticleStatusInfo;
            pptReticleStatusInfo__170 reticleStatusInfo = strReticle_detailInfo_GetDR_out.strReticleStatusInqResult.reticleStatusInfo;//DSN000101569
//DSN000096126 Add End

            if ( 0 != CIMFWStrLen(reticleStatusInfo.reticlePodID.identifier) )
            {
                PPT_METHODTRACE_V1("", "Reticle is in ReticlePod");
                objEquipment_reticlePodPortInfo_GetDR_out strEquipment_reticlePodPortInfo_GetDR_out;
                rc = equipment_reticlePodPortInfo_GetDR( strEquipment_reticlePodPortInfo_GetDR_out,
                                                         strObjCommonIn,
                                                         strInParm.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_reticlePodPortInfo_GetDR() != RC_OK", rc);
                    strStartDurablesReservationCancelReqResult.strResult = strEquipment_reticlePodPortInfo_GetDR_out.strResult;
                    return rc;
                }

                CORBA::ULong lenPortInfo = strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length();
                PPT_METHODTRACE_V2("", "strReticlePodPortInfo.length", lenPortInfo);

                for ( CORBA::ULong portCnt=0; portCnt < lenPortInfo; portCnt++ )
                {
                    PPT_METHODTRACE_V2("", "loop to strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo.length()", portCnt);
                    if ( 0 != CIMFWStrCmp( strStartDurables[durableCnt].strStartDurablePort.loadPortID.identifier,
                                           strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].reticlePodPortID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "Not same portID, continue...");
                        continue;
                    }

                    if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].dispatchStatus, SP_PortRsc_DispatchState_Dispatched) )
                    {
                        PPT_METHODTRACE_V1("", "dispatchStatus == Dispatched");

                        if ( 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_LoadReq)
                          || 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_UnloadReq)
                          || 0 == CIMFWStrCmp(strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].portStatus, SP_PortRsc_PortState_Unknown) )
                        {
                            PPT_METHODTRACE_V1("", "portStatus == LoadReq or UnloadReq or '-'");

                            objMachine_reticlePodPort_ReserveCancel_out strMachine_reticlePodPort_ReserveCancel_out;
                            rc = machine_reticlePodPort_ReserveCancel( strMachine_reticlePodPort_ReserveCancel_out,
                                                                       strObjCommonIn,
                                                                       strInParm.equipmentID,
                                                                       strEquipment_reticlePodPortInfo_GetDR_out.strReticlePodPortInfo[portCnt].reticlePodPortID );

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "machine_reticlePodPort_ReserveCancel() != RC_OK", rc);
                                strStartDurablesReservationCancelReqResult.strResult = strMachine_reticlePodPort_ReserveCancel_out.strResult;
                                return rc;
                            }
                        }

                        break;
                    }
                }
            }
        }
    }

    objProcess_startDurablesReserveInformation_Clear_out strProcess_startDurablesReserveInformation_Clear_out;
    objProcess_startDurablesReserveInformation_Clear_in  strProcess_startDurablesReserveInformation_Clear_in;
    strProcess_startDurablesReserveInformation_Clear_in.durableCategory  = durableCategory;
    strProcess_startDurablesReserveInformation_Clear_in.strStartDurables = strStartDurables;
    rc = process_startDurablesReserveInformation_Clear( strProcess_startDurablesReserveInformation_Clear_out,
                                                        strObjCommonIn,
                                                        strProcess_startDurablesReserveInformation_Clear_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "process_startDurablesReserveInformation_Clear() != RC_OK", rc);
        strStartDurablesReservationCancelReqResult.strResult = strProcess_startDurablesReserveInformation_Clear_out.strResult;
        return rc;
    }

    pptDurableControlJobManageReqResult  strDurableControlJobManageReqResult;
    pptDurableControlJobManageReqInParam strDurableControlJobManageReqInParam;
    strDurableControlJobManageReqInParam.durableControlJobID               = strInParm.durableControlJobID;
    strDurableControlJobManageReqInParam.controlJobAction                  = CIMFWStrDup( SP_DurableControlJobAction_Type_delete );
    pptDurableControlJobCreateRequest strDurableControlJobCreateRequest;
    strDurableControlJobCreateRequest.equipmentID      = strInParm.equipmentID;
    strDurableControlJobCreateRequest.durableCategory  = durableCategory;
    strDurableControlJobCreateRequest.strStartDurables = strStartDurables;
    strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest = strDurableControlJobCreateRequest;
    rc = txDurableControlJobManageReq( strDurableControlJobManageReqResult,
                                       strObjCommonIn,
                                       strDurableControlJobManageReqInParam,
                                       claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txDurableControlJobManageReq() != RC_OK", rc);
        strStartDurablesReservationCancelReqResult.strResult = strDurableControlJobManageReqResult.strResult;
        return rc;
    }

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
            /*-----------------------------------------------*/
            /*   Change Cassette's Dispatch State to FALSE   */
            /*-----------------------------------------------*/
            objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out,
                                                strObjCommonIn,
                                                strStartDurables[durableCnt].durableID,
                                                FALSE );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_dispatchState_Change() != RC_OK", rc);
                strStartDurablesReservationCancelReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
                return rc;
            }
        }
    }

    /*-----------------------------------------------------*/
    /*   Send StartDurablesReservationCancelReq() to TCS   */
    /*-----------------------------------------------------*/
    CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0;
    CORBA::Long retryCountValue = 0;

    if ( 0 == CIMFWStrLen(tmpSleepTimeValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = atoi(tmpSleepTimeValue);
    }

    if ( 0 == CIMFWStrLen(tmpRetryCountValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("", "env value of SP_BIND_SLEEP_TIME_TCS  = ", sleepTimeValue);
    PPT_METHODTRACE_V2("", "env value of SP_BIND_RETRY_COUNT_TCS = ", retryCountValue);

    objTCSMgr_SendStartDurablesReservationCancelReq_out strTCSMgr_SendStartDurablesReservationCancelReq_out;
    objTCSMgr_SendStartDurablesReservationCancelReq_in  strTCSMgr_SendStartDurablesReservationCancelReq_in;
    strTCSMgr_SendStartDurablesReservationCancelReq_in.strStartDurablesReservationCancelReqInParam = strInParm;
    strTCSMgr_SendStartDurablesReservationCancelReq_in.claimMemo                                   = claimMemo;

    //'retryCountValue + 1' means first try plus retry count
    for ( CORBA::ULong retryNum=0; retryNum < (retryCountValue + 1); retryNum++ )
    {
        PPT_METHODTRACE_V2("", "loop to retryCountValue + 1", retryNum);
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        rc = TCSMgr_SendStartDurablesReservationCancelReq( strTCSMgr_SendStartDurablesReservationCancelReq_out,
                                                           strObjCommonIn,
                                                           strTCSMgr_SendStartDurablesReservationCancelReq_in );

        PPT_METHODTRACE_V2("", "rc = ", rc);

        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL
               || rc == RC_EXT_SERVER_NIL_OBJ
               || rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("", "TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...", retryNum);
            PPT_METHODTRACE_V2("", "now sleeping... ", sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendStartDurablesReservationCancelReq() != RC_OK");
            strStartDurablesReservationCancelReqResult.strResult = strTCSMgr_SendStartDurablesReservationCancelReq_out.strResult;
            return rc;
        }
    }

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "TCSMgr_SendStartDurablesReservationCancelReq() != RC_OK");
        strStartDurablesReservationCancelReqResult.strResult = strTCSMgr_SendStartDurablesReservationCancelReq_out.strResult;
        return rc;
    }

    // Set Return Structure
    strStartDurablesReservationCancelReqResult.durableCategory  = durableCategory;
    strStartDurablesReservationCancelReqResult.strStartDurables = strStartDurables;

    // Return to caller
    SET_MSG_RC( strStartDurablesReservationCancelReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("PPTManager_i::txStartDurablesReservationCancelReq");
    return RC_OK;
}