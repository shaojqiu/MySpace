//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: cs_txCollectedDataActionByPostProcReqOR.cpp
//

//INN-R170009 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"  //INN-R170009

void DebugOutStartCassette(pptDataSpecCheckReqResult& tg);

// Class: CS_PPTManager
//
// Service:  txCollectedDataActionByPostProcReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/02 DSIV00000201 M.Ishino       Improvement of Post-Processing.
// 2008/11/03 DSIV00000214 H.Mutoh        Multi Fab Transfer Support.
// 2009/09/07 DSIV00001021 H.Nonaka       Multiple Corresponding Operations Support
// 2009/10/02 DSIV00001365 R.Okano        Entity Inhibit Improvement. (R101)
// 2009/10/21 DSIV00001471 F.Chen         Change lot_previousOperationInfo_Get -> lot_previousOperationInfo_Get__101
// 2010-04-20 DSIV00001830 R.Iriguchi     Wafer Stacking Operation Support.
// 2010-06-16 PSIV00002109 R.Iriguchi     Fix miss-removal of Code in DSIV00001830.
// 2011/09/08 DSN000015229 K.Yamaoku      Advanced Wafer Level Control support
// 2012/08/12 PSN000049719 M.Ogawa        Fix Tx ID for Post Process Registration
// 2013/01/23 DSN000050720 M.Ogawa        Lock monitored lots and monitor group
// 2013/09/06 DSN000081739 Sa Guo         Equipment Monitor Automation Support
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/18 INN-R170009  Qufd           Send Data Collection to APC
//
// Description:
//  This function performs SPEC Check and SPC Check, and performs action to the entities specified based on the check result.
//  The actions are Entity Inhibition and Hold.
//  If the target Lot belongs to Monitor Group and it is the representative Lot,
//  the Monitor Group and Hold of Monitored Lot are released according to a setup of the previous operation of Lot.
//  And then, if the monitored Lot's operation which moved by Hold release is measurement, measurement operation is passed.
//  At last, PO's collected data information is stored with data conversion.
//
// Return:
//     long
//
// Parameter:
//     pptCollectedDataActionByPostProcReqResult&       strCollectedDataActionByPostProcReqResult
//     const pptObjCommonIn&                            strObjCommonIn
//     const pptCollectedDataActionByPostProcReqInParm& strCollectedDataActionByPostProcReqInParm
//     const char*                                      claimMemo
//
//     typedef struct pptCollectedDataActionByPostProcReqInParm_struct {
//         objectIdentifier                equipmentID;                    //<i>Equipment ID
//         objectIdentifier                controlJobID;                   //<i>Control Job ID
//         objectIdentifier                lotID;                          //<i>Lot ID
//         any siInfo;                                                     //<i>Reserved for SI customization
//     } pptCollectedDataActionByPostProcReqInParm;
//
//     typedef struct pptCollectedDataActionByPostProcReqResult_struct {
//         pptRetCode                      strResult;                      //<i>Transaction Execution Result Information
//         pptOpeCompWithDataReqResult     strOpeCompWithDataReqResult;    //<i>SPEC Check Result and SPC Check Result
//         objectIdentifierSequence        holdReleasedLotIDs;             //<i>Hold Released Lot IDs
//         string                          RelatedQueuekey;                //<i>Key of PostProcess for a Hold Released Lot
//         any siInfo;                                                     //<i>Reserved for SI customization
//     } pptCollectedDataActionByPostProcReqResult;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170009 CORBA::Long PPTManager_i::txCollectedDataActionByPostProcReq (
CORBA::Long CS_PPTManager_i::txCollectedDataActionByPostProcReq (  //INN-R170009
                    pptCollectedDataActionByPostProcReqResult&          strCollectedDataActionByPostProcReqResult,
                    const pptObjCommonIn&                               strObjCommonIn,
                    const pptCollectedDataActionByPostProcReqInParm&    strCollectedDataActionByPostProcReqInParm,
                    const char*                                         claimMemo
                    CORBAENV_LAST_CPP )
{

//INN-R170009    PPT_METHODTRACE_ENTRY( "PPTManager_i:: txCollectedDataActionByPostProcReq ");
    PPT_METHODTRACE_ENTRY( "CS_PPTManager_i:: txCollectedDataActionByPostProcReq "); //INN-R170009
    PPT_METHODTRACE_V2( "", "equipmentID  ", strCollectedDataActionByPostProcReqInParm.equipmentID.identifier );
    PPT_METHODTRACE_V2( "", "controlJobID ", strCollectedDataActionByPostProcReqInParm.controlJobID.identifier );
    PPT_METHODTRACE_V2( "", "lotID        ", strCollectedDataActionByPostProcReqInParm.lotID.identifier );

    //---------------------------------//
    // Initialize variable             //
    //---------------------------------//
    CORBA::Long i=0, j=0, k=0, l=0;   // For loop counter.
    CORBA::Long nCastLen    = 0;      // For StartCassetteLen
    CORBA::Long nLotCastLen = 0;      // For LotInCassetteLen
    CORBA::Long nDCDefLen   = 0;      // For DCDefLen
    CORBA::Long nDCitemLen  = 0;      // For DCItemLen
    CORBA::Long rc          = 0;      // For return value.
    CORBA::Long dcDefIndexNum  = 0;   // DSN000015229
    CORBA::Long dcItemIndexNum = 0;   // DSN000015229

    pptStartCassetteSequence  tmpStartCassette;     // StartCassette
    CORBA::Boolean specCheckRequiredFlag = FALSE;   // for Spec Check
    CORBA::Boolean spcCheckRequiredFlag  = FALSE;   // for SPC  Check

    //--------------------------------------------------
    // check input parameter
    //--------------------------------------------------
    if ( CIMFWStrLen( strCollectedDataActionByPostProcReqInParm.equipmentID.identifier ) <= 0 )
    {
        PPT_METHODTRACE_V2("", "The input parameter is not specified.","equipmentID is Blank");
        SET_MSG_RC( strCollectedDataActionByPostProcReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }
    if ( CIMFWStrLen( strCollectedDataActionByPostProcReqInParm.controlJobID.identifier ) <= 0 )
    {
        PPT_METHODTRACE_V2("", "The input parameter is not specified.","controlJobID is Blank");
        SET_MSG_RC( strCollectedDataActionByPostProcReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }
    if ( CIMFWStrLen( strCollectedDataActionByPostProcReqInParm.lotID.identifier ) <= 0 )
    {
        PPT_METHODTRACE_V2("", "The input parameter is not specified.","lotID is Blank");
        SET_MSG_RC( strCollectedDataActionByPostProcReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }


    /*=============================================================================*/
    /*                                                                             */
    /* Check Process                                                               */
    /*                                                                             */
    /*=============================================================================*/
    PPT_METHODTRACE_V1("", "There is no StartCassette length of inparmeter. Try to get StartCassette with previous operation.");
    //-----------------------------------------------------------------------//
    //   Get Started Lot information which is specified with ControlJob ID   //
    //-----------------------------------------------------------------------//
    objLot_previousOperation_DataCollectionInformation_Get_out   strLot_previousOperation_DataCollectionInformation_Get_out;
    objLot_previousOperation_DataCollectionInformation_Get_in    strLot_previousOperation_DataCollectionInformation_Get_in;
    // set input parameter
    strLot_previousOperation_DataCollectionInformation_Get_in.equipmentID  = strCollectedDataActionByPostProcReqInParm.equipmentID;
    strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs.length(1);
    strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs[0]    = strCollectedDataActionByPostProcReqInParm.lotID;

    rc = lot_previousOperation_DataCollectionInformation_Get( strLot_previousOperation_DataCollectionInformation_Get_out,
                                                              strObjCommonIn,
                                                              strLot_previousOperation_DataCollectionInformation_Get_in);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "lot_previousOperation_DataCollectionInformation_Get() != RC_OK" );
        strCollectedDataActionByPostProcReqResult.strResult = strLot_previousOperation_DataCollectionInformation_Get_out.strResult;
        return( rc );
    }
    tmpStartCassette = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette;

    // Recheck StartCassette length.
    if( 0 >= tmpStartCassette.length() )
    {
        PPT_SET_MSG_RC_KEY(strCollectedDataActionByPostProcReqResult, MSG_NOT_FOUND_CASSETTE, RC_NOT_FOUND_CASSETTE, "(There is no started cassette.)");
        return RC_NOT_FOUND_CASSETTE;
    }

//DSN000050720 Add Start
    // Get PostProcForLotFlag from thread specific data
    CORBA::Boolean bParallelPostProcFlag = FALSE;
    char* methodName = NULL;
    CORBA::String_var strParallelPostProcFlag;
    try
    {
        methodName = CIMFWStrDup("getThreadSpecificDataString");
        strParallelPostProcFlag = getThreadSpecificDataString(SP_ThreadSpecificData_Key_PostProcParallelFlag);
        CORBA::string_free(methodName);
        methodName = NULL;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCollectedDataActionByPostProcReqResult, txCollectedDataActionByPostProcReq, methodName);

    PPT_METHODTRACE_V2("", "strParallelPostProcFlag", strParallelPostProcFlag);

    if ( 0 == CIMFWStrCmp(strParallelPostProcFlag, SP_PostProcess_ParallelExecution_ON) )
    {
        PPT_METHODTRACE_V1("","strParallelPostProcFlag=SP_PostProcess_ParallelExecution_ON");
        bParallelPostProcFlag = TRUE;
    }
//DSN000050720 Add End
    /*=============================================================================*/
    /*                                                                             */
    /* Object Lock Process                                                         */
    /*                                                                             */
    /*=============================================================================*/
    nCastLen = tmpStartCassette.length();
    objObject_Lock_out  strObject_Lock_out;
    PPT_METHODTRACE_V2("", "tmpStartCassette.length", nCastLen);

    for ( i = 0; i < nCastLen; i++ )
    {
        nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V2("", "tmpStartCassette[i].strLotInCassette.length", nLotCastLen);

        for ( j = 0; j < nLotCastLen; j++ )
        {
            //---------------------------//
            //   Omit Not-OpeStart Lot   //
            //---------------------------//
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");
                continue;
            }

            //---------------------//
            //   Lock Lot Object   //
            //---------------------//
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, tmpStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK");
                strCollectedDataActionByPostProcReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }

             //-------------------------------//
             //  Set Spec Check Required Flag //
             //-------------------------------//
             if ( specCheckRequiredFlag == FALSE)
             {
                 nDCDefLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                 for ( k = 0; k < nDCDefLen; k++ )
                 {
                     if ( tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].specCheckRequiredFlag == TRUE )
                     {
                         specCheckRequiredFlag = TRUE;
                     }
                 }
             }
//DSN000050720 Add Start
             if( TRUE == bParallelPostProcFlag )
             {
                //PostProcess parallel execution
                 PPT_METHODTRACE_V1("", "Check monitor group existence.");
                 objMonitorGroup_GetDR_out strMonitorGroup_GetDR_out ;
                 rc = monitorGroup_GetDR( strMonitorGroup_GetDR_out,
                                          strObjCommonIn,
                                          tmpStartCassette[i].strLotInCassette[j].lotID ) ;
                 if( rc != RC_OK )
                 {
                     PPT_METHODTRACE_V2("", "monitorGroup_GetDR() != RC_OK", rc);
                     strCollectedDataActionByPostProcReqResult.strResult = strMonitorGroup_GetDR_out.strResult;
                     return( rc );
                 }

                 //--------------------------------------------------//
                 //   Lock MonitorGroup to keep data inconsistency   //
                 //--------------------------------------------------//
                 CORBA::ULong monGrpLen = strMonitorGroup_GetDR_out.strMonitorGroups.length();
                 PPT_METHODTRACE_V2("", "monGrpLen", monGrpLen);
                 for( CORBA::ULong k = 0; k < monGrpLen; k++ )
                 {
                     PPT_METHODTRACE_V3( "", "Loop for i, Monitor lotID.", k, strMonitorGroup_GetDR_out.strMonitorGroups[k].monitorLotID.identifier );
                     if( 0 == CIMFWStrCmp( tmpStartCassette[i].strLotInCassette[j].lotID.identifier, strMonitorGroup_GetDR_out.strMonitorGroups[k].monitorLotID.identifier ) )
                     {
                         PPT_METHODTRACE_V1("", "lotID matches.") ;
                         rc = object_Lock( strObject_Lock_out, strObjCommonIn, strMonitorGroup_GetDR_out.strMonitorGroups[k].monitorGroupID, SP_ClassName_PosMonitorGroup );
                         if ( rc != RC_OK )
                         {
                             PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                             strCollectedDataActionByPostProcReqResult.strResult = strObject_Lock_out.strResult;
                             return( rc );
                         }

                         CORBA::ULong monitoredLotLen = strMonitorGroup_GetDR_out.strMonitorGroups[k].strMonitoredLots.length();
                         PPT_METHODTRACE_V2("", "monitoredLotLen", monitoredLotLen );

                         //--------------------------------------------//
                         //   Lock Monitored lots to avoid dead lock   //
                         //--------------------------------------------//
                         for( CORBA::ULong l = 0; l < monitoredLotLen; l++ )
                         {
                             PPT_METHODTRACE_V2("", "Monitored LotID", strMonitorGroup_GetDR_out.strMonitorGroups[k].strMonitoredLots[l].lotID.identifier );
                             rc = object_Lock( strObject_Lock_out, strObjCommonIn, strMonitorGroup_GetDR_out.strMonitorGroups[k].strMonitoredLots[l].lotID, SP_ClassName_PosLot );
                             if ( rc != RC_OK && rc != RC_NOT_FOUND_LOT )    // RC_NOT_FOUND_LOT is OK
                             {
                                 PPT_METHODTRACE_V2("", "object_Lock() != RC_OK && RC_NOT_FOUND_LOT", rc);
                                 strCollectedDataActionByPostProcReqResult.strResult = strObject_Lock_out.strResult;
                                 return( rc );
                             }
                         } //[l]
                     }
                 } //[k]
             }
//DSN000050720 Add End
         }   // loop - Lot
     }   // loop - Cassette

//DSN000015229 Add start
    /*=============================================================================*/
    /*                                                                             */
    /* Check Reported PJ Data Item                                                 */
    /*                                                                             */
    /*=============================================================================*/
    CORBA::Boolean bPJDataExistFlag = FALSE;
    objProcessOperation_DataCondition_GetDR_out  strProcessOperation_DataCondition_GetDR_out;
    objProcessOperation_DataCondition_GetDR_in   strProcessOperation_DataCondition_GetDR_in;
    strProcessOperation_DataCondition_GetDR_in.lotID    = strCollectedDataActionByPostProcReqInParm.lotID;
    strProcessOperation_DataCondition_GetDR_in.category = CIMFWStrDup(SP_DataConditionCategory_SpecCheckResult);

    PPT_METHODTRACE_V1( "", "calling processOperation_DataCondition_GetDR()" );
    rc = processOperation_DataCondition_GetDR( strProcessOperation_DataCondition_GetDR_out,
                                               strObjCommonIn,
                                               strProcessOperation_DataCondition_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "","processOperation_DataCondition_GetDR() != RC_OK", rc );
        strCollectedDataActionByPostProcReqResult.strResult = strProcessOperation_DataCondition_GetDR_out.strResult;
        return( rc );
    }
    if ( 0 < strProcessOperation_DataCondition_GetDR_out.count )
    {
        PPT_METHODTRACE_V1( "", "0 < strProcessOperation_DataCondition_GetDR_out.count" );
        bPJDataExistFlag = TRUE;
    }
    PPT_METHODTRACE_V2( "", "bPJDataExistFlag", (int)bPJDataExistFlag );

    pptDCDefSequence& strInitDCDefSeq = tmpStartCassette[0].strLotInCassette[0].strStartRecipe.strDCDef;
    nDCDefLen = strInitDCDefSeq.length();

    /*=============================================================================*/
    /*                                                                             */
    /* Get Expand Derived Data Item                                                */
    /*                                                                             */
    /*=============================================================================*/
    CORBA::Boolean bExistAsteriskItemFlag = FALSE;
    strProcessOperation_DataCondition_GetDR_in.category = CIMFWStrDup(SP_DataConditionCategory_ExpandDerivedData);

    PPT_METHODTRACE_V1( "", "calling processOperation_DataCondition_GetDR()" );
    rc = processOperation_DataCondition_GetDR( strProcessOperation_DataCondition_GetDR_out,
                                               strObjCommonIn,
                                               strProcessOperation_DataCondition_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "","processOperation_DataCondition_GetDR() != RC_OK", rc );
        strCollectedDataActionByPostProcReqResult.strResult = strProcessOperation_DataCondition_GetDR_out.strResult;
        return( rc );
    }

    pptDCDefSequence& strExpandDerivedDCDef = strProcessOperation_DataCondition_GetDR_out.strExpandDerivedDCDef;
    CORBA::ULong nExpandDCDefLen = strExpandDerivedDCDef.length();
    PPT_METHODTRACE_V2( "", "nExpandDCDefLen", nExpandDCDefLen );

    longSequence* specCheckIndexSeq = NULL;
    CORBA::ULong specCheckIndexLen = nDCDefLen;

    //-------------------------------//
    //  Set Spec Check Required Flag //
    //-------------------------------//
    specCheckIndexSeq = new longSequence[specCheckIndexLen];
    pptDCDefSequence strDCDefSeq = strInitDCDefSeq;

    //List of WaferID
    typedef SPDynamicTableS <char*, char*, char*, char*, stringSequence, stringSequence> waferIDList;
    waferIDList aWaferIDList;

    for ( CORBA::ULong nDCDefNum = 0; nDCDefNum < specCheckIndexLen; nDCDefNum++ )
    {
        PPT_METHODTRACE_V2("", "nDCDefNum", nDCDefNum);
        CORBA::ULong nChkd = 0;

        CORBA::ULong nExpandDCItemLen = 0;
        CORBA::ULong nExpandDCDefNum  = 0;
        for ( nExpandDCDefNum = 0; nExpandDCDefNum < nExpandDCDefLen; nExpandDCDefNum++ )
        {
            PPT_METHODTRACE_V2("", "nExpandDCDefNum", nExpandDCDefNum);
            if ( 0 == CIMFWStrCmp(strInitDCDefSeq[nDCDefNum].dataCollectionDefinitionID.identifier, strExpandDerivedDCDef[nExpandDCDefNum].dataCollectionDefinitionID.identifier) )
            {
                PPT_METHODTRACE_V1("", "strInitDCDefSeq[nDCDefNum].dataCollectionDefinitionID == strExpandDerivedDCDef[nExpandDCDefNum].dataCollectionDefinitionID");
                nExpandDCItemLen = strExpandDerivedDCDef[nExpandDCDefNum].strDCItem.length();
                break;
            }
        }

        nDCitemLen = strInitDCDefSeq[nDCDefNum].strDCItem.length();
        specCheckIndexSeq[nDCDefNum].length(nDCitemLen + nExpandDCItemLen);

        strDCDefSeq[nDCDefNum].strDCItem.length(nDCitemLen + nExpandDCItemLen);

        CORBA::ULong derivedIndexCnt = 0;
        longSequence derivedIndexSeq;
        derivedIndexSeq.length(nDCitemLen);

        CORBA::ULong nDCItemCnt = 0;
        CORBA::ULong nExpandDCItemCurrPos = 0;
        CORBA::String_var expandCurrDCItemName = CIMFWStrDup("");
        CORBA::String_var expandCurrMeasType = CIMFWStrDup("");
        CORBA::String_var expandCurrSitePos = CIMFWStrDup("");
        for ( CORBA::ULong nDCItemNum = 0; nDCItemNum < nDCitemLen; nDCItemNum++ )
        {
            PPT_METHODTRACE_V2("", "nDCItemNum", nDCItemNum);
            CORBA::Boolean bCheckedFlag = FALSE;
            if ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJ,          strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].measurementType )
              || 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWafer,     strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].measurementType )
              || 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWaferSite, strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].measurementType ) )
            {
                PPT_METHODTRACE_V1("", "DCItem by PJ");

                /*=============================================================================*/
                /*                                                                             */
                /* Expand Derived Data Item                                                    */
                /*                                                                             */
                /*=============================================================================*/
                if ( 0 < nExpandDCItemLen
                  && ( 0 == CIMFWStrCmp( SP_DCDef_Item_Derived,      strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].itemType )
                    || 0 == CIMFWStrCmp( SP_DCDef_Item_UserFunction, strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].itemType ) ) )
                {
                    PPT_METHODTRACE_V1("", "0 < nExpandDCItemLen and itemType == Derived");

                    if ( 0 == CIMFWStrLen( expandCurrDCItemName ) )
                    {
                        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen( expandCurrDCItemName )");
                        expandCurrDCItemName = strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].dataCollectionItemName;
                        expandCurrMeasType   = strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].measurementType;
                        expandCurrSitePos    = strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].sitePosition;
                    }

                    if ( 0 == CIMFWStrCmp( expandCurrDCItemName, strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].dataCollectionItemName )
                      && 0 == CIMFWStrCmp( expandCurrMeasType,   strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].measurementType )
                      && 0 == CIMFWStrCmp( expandCurrSitePos,    strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].sitePosition ) )
                    {
                        PPT_METHODTRACE_V1("", "Start of the expansion");

                        CORBA::ULong nExpandDCItemCnt = 0;
                        for ( nExpandDCItemCnt = nExpandDCItemCurrPos; nExpandDCItemCnt < nExpandDCItemLen; nExpandDCItemCnt++ )
                        {
                            PPT_METHODTRACE_V3("", "nExpandDCItemLen/nExpandDCItemCnt", nExpandDCItemLen, nExpandDCItemCnt);

                            if ( 0 == CIMFWStrCmp( expandCurrDCItemName, strExpandDerivedDCDef[nExpandDCDefNum].strDCItem[nExpandDCItemCnt].dataCollectionItemName )
                              && 0 == CIMFWStrCmp( expandCurrMeasType,   strExpandDerivedDCDef[nExpandDCDefNum].strDCItem[nExpandDCItemCnt].measurementType )
                              && 0 == CIMFWStrCmp( expandCurrSitePos,    strExpandDerivedDCDef[nExpandDCDefNum].strDCItem[nExpandDCItemCnt].sitePosition ) )
                            {
                                PPT_METHODTRACE_V4("", "Add Expand Item", expandCurrDCItemName, expandCurrMeasType, expandCurrSitePos);
                                strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt] = strExpandDerivedDCDef[nExpandDCDefNum].strDCItem[nExpandDCItemCnt];
                                nChkd++;
                                nDCItemCnt++;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "End of the expansion");
                                expandCurrDCItemName = strExpandDerivedDCDef[nExpandDCDefNum].strDCItem[nExpandDCItemCnt].dataCollectionItemName;
                                expandCurrMeasType   = strExpandDerivedDCDef[nExpandDCDefNum].strDCItem[nExpandDCItemCnt].measurementType;
                                expandCurrSitePos    = strExpandDerivedDCDef[nExpandDCDefNum].strDCItem[nExpandDCItemCnt].sitePosition;
                                break;
                            }
                        } // nExpandDCItemCnt loop end
                        nExpandDCItemCurrPos = nExpandDCItemCnt;
                    }
                }

                if ( ( 0 == CIMFWStrCmp( SP_DCDef_Item_Derived,      strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].itemType )
                    || 0 == CIMFWStrCmp( SP_DCDef_Item_UserFunction, strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].itemType ) )
                  && 0 == CIMFWStrCmp( strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum].waferPosition, "*" ) )
                {
                    PPT_METHODTRACE_V1("", "itemType == Derived and waferPosition == '*'");
                    continue;
                }
                strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt] = strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum];

                if ( 0 < CIMFWStrLen(strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].specCheckResult) )
                {
                    PPT_METHODTRACE_V1("", "specCheckResult.length > 0");
                    bCheckedFlag = TRUE;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "DCItem by CJ");
                strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt] = strInitDCDefSeq[nDCDefNum].strDCItem[nDCItemNum];
            }
            if ( FALSE == bCheckedFlag )
            {
                PPT_METHODTRACE_V1("", "FALSE == bCheckedFlag");
                specCheckIndexSeq[nDCDefNum][nChkd] = nDCItemCnt;
                nChkd++;
            }

            if ( 0 < CIMFWStrLen( strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferPosition )
              && 0 != CIMFWStrCmp( SP_DCDef_Meas_PJ, strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].measurementType ) )
            {
                PPT_METHODTRACE_V1("", "0 < CIMFWStrLen(waferPosition) and measurementType != SP_DCDef_Meas_PJ");
                // DCDef
                if ( 0 == nDCDefNum )
                {
                    PPT_METHODTRACE_V1("", "0 == nDCDefNum");
                    if ( ( 0 == CIMFWStrCmp( SP_DCDef_Item_Derived,      strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].itemType )
                        || 0 == CIMFWStrCmp( SP_DCDef_Item_UserFunction, strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].itemType ) )
                      && 0 == CIMFWStrLen( strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferID.identifier ) )
                    {
                        PPT_METHODTRACE_V2("", "Add derivedIndexSeq", nDCItemNum);
                        derivedIndexSeq[derivedIndexCnt++] = nDCItemNum;
                    }
                    else if ( 0 == CIMFWStrCmp( SP_DCDef_Item_Raw, strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].itemType )
                      && 0 < CIMFWStrLen(strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "itemType == Raw && 0 < CIMFWStrLen(waferID)");
                        if( !aWaferIDList.exists( strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferPosition ) )
                        {
                            PPT_METHODTRACE_V3("", "Add aProcessWaferDeltaPOList", strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferPosition, strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferID.identifier);
                            aWaferIDList.add( CIMFWStrDup(strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferPosition), CIMFWStrDup(strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferID.identifier) );
                        }
                    }
                }
                //Delta
                else
                {
                    PPT_METHODTRACE_V1("", "0 != nDCDefNum");
                    if ( ( 0 == CIMFWStrCmp( SP_DCDef_Item_Derived,      strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].itemType )
                        || 0 == CIMFWStrCmp( SP_DCDef_Item_UserFunction, strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].itemType ) )
                      && 0 == CIMFWStrLen( strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferID.identifier ) )
                    {
                        PPT_METHODTRACE_V1("", "itemType == Derived && 0 == CIMFWStrLen(waferID)");
                        char* aWaferID = NULL;
                        if( aWaferIDList.find( strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferPosition, aWaferID ) )
                        {
                            PPT_METHODTRACE_V4("", "Set WaferID", strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].dataCollectionItemName, strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferPosition, aWaferID);
                            strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferID.identifier = CIMFWStrDup( aWaferID );
                        }
                    }
                }
            }

            nDCItemCnt++;
        }
        strDCDefSeq[nDCDefNum].strDCItem.length(nDCItemCnt);

        specCheckIndexSeq[nDCDefNum].length(nChkd);

        derivedIndexSeq.length(derivedIndexCnt);
        // DCDef
        if ( 0 == nDCDefNum )
        {
            PPT_METHODTRACE_V1("", "0 == nDCDefNum");
            for ( CORBA::ULong derivedIndexNum = 0; derivedIndexNum < derivedIndexCnt; derivedIndexNum++ )
            {
                PPT_METHODTRACE_V3("", "derivedIndexCnt / derivedIndexNum", derivedIndexCnt, derivedIndexNum);
                nDCItemCnt = derivedIndexSeq[derivedIndexNum];
                char* aWaferID = NULL;
                if( aWaferIDList.find( strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferPosition, aWaferID ) )
                {
                    PPT_METHODTRACE_V4("", "Set WaferID", strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].dataCollectionItemName, strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferPosition, aWaferID);
                    strDCDefSeq[nDCDefNum].strDCItem[nDCItemCnt].waferID.identifier = CIMFWStrDup( aWaferID );
                }
            }
        }
    }
    strInitDCDefSeq = strDCDefSeq;
//DSN000015229 Add end

    /*=============================================================================*/
    /*                                                                             */
    /* Main Process                                                                */
    /*                                                                             */
    /*=============================================================================*/

    PPT_METHODTRACE_V2("", "specCheckRequiredFlag is ", specCheckRequiredFlag );
    //----------------------------------------------//
    //   If specCheckRequiredFlag is TRUE           //
    //   Call txSpecCheckDataReq                    //
    //----------------------------------------------//
    if ( specCheckRequiredFlag == TRUE )
    {
        PPT_METHODTRACE_V1("", "Do Spec Check");
        pptDataSpecCheckReqResult strDataSpecCheckReqResult;
        //-------------------------------------------------------------------------------------------//
        //   Do Spec Check                                                                           //
        //      - Calculate the derived value and Set them to PO if calculationRequiredFlag is TRUE  //
        //      - Set spec  check result to PO if speckCheckRequiredFlag is TRUE.                    //
        //-------------------------------------------------------------------------------------------//
        for ( i = 0; i < nCastLen; i++ )
        {
            nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V2("", "tmpStartCassette[i].strLotInCassette.length", nLotCastLen);

            for ( j = 0; j < nLotCastLen; j++ )
            {
                //---------------------------//
                //   Omit Not-OpeStart Lot   //
                //---------------------------//
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");
                    continue;
                }

                //--------------------------------------------------------------------------------------//
                // Control Job is deleted for the logic of new post-processing by OpeComp.              //
                // Therefore, Control Job cannot be obtained from Lot.                                  //
                // In this case, Control Job of equipment is compared with Control Job of PreviousPO.   //
                //--------------------------------------------------------------------------------------//
//DSIV00001471                 objLot_previousOperationInfo_Get_out    strLot_previousOperationInfo_Get_out;
//DSIV00001471                 objLot_previousOperationInfo_Get_in     strLot_previousOperationInfo_Get_in;
//DSIV00001471                 strLot_previousOperationInfo_Get_in.lotID = tmpStartCassette[i].strLotInCassette[j].lotID;
//DSIV00001471                 rc = lot_previousOperationInfo_Get( strLot_previousOperationInfo_Get_out,
//DSIV00001471                                                     strObjCommonIn,
//DSIV00001471                                                     strLot_previousOperationInfo_Get_in );
//DSIV00001471 Add Start
                objLot_previousOperationInfo_Get_out__101 strLot_previousOperationInfo_Get_out;
                objLot_previousOperationInfo_Get_in strLot_previousOperationInfo_Get_in;
                strLot_previousOperationInfo_Get_in.lotID = tmpStartCassette[i].strLotInCassette[j].lotID;
                rc = lot_previousOperationInfo_Get__101 (   strLot_previousOperationInfo_Get_out,
                                                            strObjCommonIn,
                                                            strLot_previousOperationInfo_Get_in );
//DSIV00001471 Add End
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_previousOperationInfo_Get() != RC_OK", rc);
                    strCollectedDataActionByPostProcReqResult.strResult = strLot_previousOperationInfo_Get_out.strResult;
//DSN000015229 Add start
                    if ( NULL != specCheckIndexSeq )
                    {
                        PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                        delete [] specCheckIndexSeq;
                    }
//DSN000015229 Add end
                    return (rc);
                }
                PPT_METHODTRACE_V2( "", "Previous PO controlJobID = ", strLot_previousOperationInfo_Get_out.controlJobID.identifier );
                PPT_METHODTRACE_V2( "", "Equipment   controlJobID = ", strCollectedDataActionByPostProcReqInParm.controlJobID.identifier );

                if( 0 != CIMFWStrCmp( strLot_previousOperationInfo_Get_out.controlJobID.identifier,
                                      strCollectedDataActionByPostProcReqInParm.controlJobID.identifier ) )
                {
                    SET_MSG_RC( strCollectedDataActionByPostProcReqResult,
                                MSG_INVALID_INPUT_PARM,
                                RC_INVALID_INPUT_PARM );
//DSN000015229 Add start
                    if ( NULL != specCheckIndexSeq )
                    {
                        PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                        delete [] specCheckIndexSeq;
                    }
//DSN000015229 Add end
                    return( RC_INVALID_INPUT_PARM );
                }
            }
        }


//DSIV00001471 Add Start
        CORBA::String_var dcCheckLevel = CIMFWStrDup(getenv(SP_DC_DATA_CHECK_LEVEL));
        CORBA::String_var dcCheckPhase = CIMFWStrDup(getenv(SP_DC_DATA_CHECK_PHASE));
        PPT_METHODTRACE_V2("", "dcCheckLevel = ", dcCheckLevel);
        PPT_METHODTRACE_V2("", "dcCheckPhase = ", dcCheckPhase);
        if ( CIMFWStrCmp (dcCheckLevel, "1") != 0 && CIMFWStrCmp (dcCheckLevel, "2") != 0)
        {
            dcCheckLevel = CIMFWStrDup("0");
        }
        if ( CIMFWStrCmp (dcCheckPhase, "1") != 0 )
        {
            dcCheckPhase = CIMFWStrDup("0");
        }
        PPT_METHODTRACE_V2("", "dcCheckLevel = ", dcCheckLevel);
        PPT_METHODTRACE_V2("", "dcCheckPhase = ", dcCheckPhase);

        objDataValue_CheckValidityForSpecCheckDR_out strDataValue_CheckValidityForSpecCheckDR_out;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.equipmentID      = strCollectedDataActionByPostProcReqInParm.equipmentID;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.controlJobID     = strCollectedDataActionByPostProcReqInParm.controlJobID;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette = tmpStartCassette;

        if ( CIMFWStrCmp (dcCheckLevel, "0") != 0 &&   //SP_DC_DATA_CHECK_LEVEL is not 0
             CIMFWStrCmp (dcCheckPhase, "1") == 0)     //SP_DC_DATA_CHECK_PHASE is set to 1
        {
            PPT_METHODTRACE_V1("", "Do dataValue_CheckValidityForSpecCheck");


            /*--------------------*/
            /*   Validity Check   */
            /*--------------------*/
            rc = dataValue_CheckValidityForSpecCheckDR(strDataValue_CheckValidityForSpecCheckDR_out, strObjCommonIn);
            switch ( rc )
            {
                case RC_OK:
                    PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() == RC_OK");
                    break;
                case RC_ALL_DATAVAL_ASTERISK:
                    PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() == RC_ALL_DATAVAL_ASTERISK");
                    break;
                default:
                    PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() != RC_OK");
                    strCollectedDataActionByPostProcReqResult.strResult = strDataValue_CheckValidityForSpecCheckDR_out.strResult;
//DSN000015229 Add start
                    if ( NULL != specCheckIndexSeq )
                    {
                        PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                        delete [] specCheckIndexSeq;
                    }
//DSN000015229 Add end
                    return(rc);
            }
        }
//DSIV00001471 Add End

//DSIV00001471         /*------------------------------------------------*/
//DSIV00001471         /*   Set DC Spec's detailed information into PO   */
//DSIV00001471         /*------------------------------------------------*/
//DSIV00001471         objProcess_dataCollectionSpecification_Set_out strProcess_dataCollectionSpecification_Set_out;
//DSIV00001471
//DSIV00001471         rc = process_dataCollectionSpecification_Set( strProcess_dataCollectionSpecification_Set_out,
//DSIV00001471                                                       strObjCommonIn,
//DSIV00001471                                                       tmpStartCassette );
//DSIV00001471         if ( rc != RC_OK )
//DSIV00001471         {
//DSIV00001471             PPT_METHODTRACE_V1("", "process_dataCollectionSpecification_Set() != RC_OK");
//DSIV00001471             strCollectedDataActionByPostProcReqResult.strResult = strProcess_dataCollectionSpecification_Set_out.strResult;
//DSIV00001471             return( rc );
//DSIV00001471         }

        /*-------------------*/
        /*   Do Spec Check   */
        /*-------------------*/
        objSpecCheck_FillInTxDCC001DR_out strSpecCheck_FillInTxDCC001DR_out;
//DSIV00001471         strSpecCheck_FillInTxDCC001DR_out.strResult = strProcess_dataCollectionSpecification_Set_out.strResult;
//DSIV00001471         strSpecCheck_FillInTxDCC001DR_out.strDataSpecCheckReqResult.strStartCassette = strProcess_dataCollectionSpecification_Set_out.strStartCassette;
        strSpecCheck_FillInTxDCC001DR_out.strResult = strDataValue_CheckValidityForSpecCheckDR_out.strResult;   //DSIV00001471
        strSpecCheck_FillInTxDCC001DR_out.strDataSpecCheckReqResult = strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult;   //DSIV00001471

        rc = specCheck_FillInTxDCC001DR(strSpecCheck_FillInTxDCC001DR_out, strObjCommonIn);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "specCheck_FillInTxDCC001DR() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strSpecCheck_FillInTxDCC001DR_out.strResult;
//DSN000015229 Add start
            if ( NULL != specCheckIndexSeq )
            {
                PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                delete [] specCheckIndexSeq;
            }
//DSN000015229 Add end
            return( rc );
        }

//DSN000015229 Add start
        /*--------------------------------------------------------*/
        /*   Merge already checked data item into StartCassette   */
        /*--------------------------------------------------------*/
        if ( TRUE == bPJDataExistFlag )
        {
            PPT_METHODTRACE_V1("", "TRUE == bPJDataExistFlag");
            pptStartCassetteSequence& strStartCassetteSpecCheckResult = strSpecCheck_FillInTxDCC001DR_out.strDataSpecCheckReqResult.strStartCassette;
            pptStartCassetteSequence& strStartCassetteSource          = strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette;

            for ( dcDefIndexNum = 0; dcDefIndexNum < specCheckIndexLen; dcDefIndexNum++ )
            {
                PPT_METHODTRACE_V2("", "dcDefIndexNum", dcDefIndexNum);
                CORBA::Long specCheckIndexCnt = specCheckIndexSeq[dcDefIndexNum].length();
                pptDCItemSequence& strResultDCItemSeq = strStartCassetteSpecCheckResult[0].strLotInCassette[0].strStartRecipe.strDCDef[dcDefIndexNum].strDCItem;
                pptDCItemSequence& strSourceDCItemSeq = strStartCassetteSource[0].strLotInCassette[0].strStartRecipe.strDCDef[dcDefIndexNum].strDCItem;
                for ( dcItemIndexNum = 0; dcItemIndexNum < specCheckIndexCnt; dcItemIndexNum++ )
                {
                    PPT_METHODTRACE_V2("", "dcItemIndexNum", dcItemIndexNum);
                    CORBA::Long sourceIndex = specCheckIndexSeq[dcDefIndexNum][dcItemIndexNum];
                    if ( sourceIndex >= strSourceDCItemSeq.length() )
                    {
                        PPT_METHODTRACE_V1("", "index >= strDCItem.length()");
                        SET_MSG_RC(strCollectedDataActionByPostProcReqResult, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                        delete [] specCheckIndexSeq;
                        return( RC_SYSTEM_ERROR );
                    }
                    strSourceDCItemSeq[sourceIndex] = strResultDCItemSeq[sourceIndex];
                }
            }
            strStartCassetteSpecCheckResult = strStartCassetteSource;
        }
//DSN000015229 Add end

        /*-----------------------*/
        /*   Set out structure   */
        /*-----------------------*/
        strDataSpecCheckReqResult = strSpecCheck_FillInTxDCC001DR_out.strDataSpecCheckReqResult;

        /*--------------------------*/
        /*   APC Derived Data       */
        /*--------------------------*/
//DSN000015229        pptAPCDerivedDataInqResult strAPCDerivedDataInqResult;
//DSN000015229        rc = txAPCDerivedDataInq(strAPCDerivedDataInqResult,
//DSN000015229                                 strObjCommonIn,
//DSN000015229                                 strCollectedDataActionByPostProcReqInParm.equipmentID,
//DSN000015229                                 strCollectedDataActionByPostProcReqInParm.controlJobID,
//DSN000015229                                 strSpecCheck_FillInTxDCC001DR_out.strDataSpecCheckReqResult.strStartCassette );
//DSN000015229 Add start
        pptAPCDerivedDataInqResult__120 strAPCDerivedDataInqResult;

        PPT_METHODTRACE_V1("","calling txAPCDerivedDataInq__120()");
        rc = txAPCDerivedDataInq__120( strAPCDerivedDataInqResult,
                                       strObjCommonIn,
                                       strCollectedDataActionByPostProcReqInParm.equipmentID,
                                       strCollectedDataActionByPostProcReqInParm.controlJobID,
                                       strSpecCheck_FillInTxDCC001DR_out.strDataSpecCheckReqResult.strStartCassette,
                                       SP_APCDerivedDataReq_ByControlJob );
//DSN000015229 Add end

        /*-----------------------*/
        /*   Set out structure   */
        /*-----------------------*/
        strDataSpecCheckReqResult.strStartCassette = strAPCDerivedDataInqResult.strStartCassette;

        if( rc == RC_NO_RESPONSE_APC       ||
            rc == RC_APC_SERVER_BIND_FAIL  ||
            rc == RC_APC_DERIVEDDATA_ERROR )
        {
//DSN000015229            PPT_METHODTRACE_V1("", "txAPCDerivedDataInq() == APC Error");
            PPT_METHODTRACE_V1("", "txAPCDerivedDataInq__120() == APC Error");           //DSN000015229

            //----------------------------------------------------
            //   Search strAPCDerivedDataResponseList
            //----------------------------------------------------
            CORBA::Long apc_resLen  = strAPCDerivedDataInqResult.strAPCDerivedDataResponseList.length();
            CORBA::Long start_casLen = strDataSpecCheckReqResult.strStartCassette.length();

            PPT_METHODTRACE_V2("", "strAPCDerivedDataResponseList.length()", apc_resLen);
            PPT_METHODTRACE_V2("", "strStartCassette.length()", start_casLen);

            //------------------------------------------
            //   for strAPCDerivedDataResponseList
            //------------------------------------------
            for( CORBA::Long apc_i = 0; apc_i < apc_resLen; apc_i++ )
            {
                CORBA::Long apc_lotderLen = strAPCDerivedDataInqResult.strAPCDerivedDataResponseList[apc_i].strAPCLotDerivedDataList.length();
                PPT_METHODTRACE_V3("", "strAPCLotDerivedDataList.length()", apc_lotderLen, apc_i);

                for( CORBA::Long apc_j = 0; apc_j < apc_lotderLen; apc_j++ )
                {
                    PPT_METHODTRACE_V3("", "APC lotID", strAPCDerivedDataInqResult.strAPCDerivedDataResponseList[apc_i].strAPCLotDerivedDataList[apc_j].lotID, apc_j);

                    //--------------------------
                    //   for StartCassette
                    //--------------------------
                    for( CORBA::Long sc_i = 0; sc_i < start_casLen; sc_i++ )
                    {
                        CORBA::Long start_lotLen = strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette.length();
                        PPT_METHODTRACE_V3("", "strLotInCassette.length()", start_lotLen, sc_i);

                        for( CORBA::Long sc_j = 0; sc_j < start_lotLen; sc_j++ )
                        {
                            if( strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].operationStartFlag == FALSE )
                            {
                                PPT_METHODTRACE_V1("", "strStartCassette's operationStartFlag == FALSE");
                                continue;
                            }

                            PPT_METHODTRACE_V3("", "strStartCassette's lotID", strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].lotID.identifier, sc_j);

                            //----------------------
                            //   Lot check
                            //----------------------
                            if( CIMFWStrCmp(strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].lotID.identifier,
                                            strAPCDerivedDataInqResult.strAPCDerivedDataResponseList[apc_i].strAPCLotDerivedDataList[apc_j].lotID) == 0 )
                            {
                                PPT_METHODTRACE_V1("", "StartCassette's LotID == APC's LotID");

                                CORBA::Long apc_derLen = strAPCDerivedDataInqResult.strAPCDerivedDataResponseList[apc_i].strAPCLotDerivedDataList[apc_j].strAPCDerivedDataList.length();
                                PPT_METHODTRACE_V3("", "strAPCDerivedDataList.length()", apc_derLen, apc_j);

                                for( CORBA::Long apc_k = 0; apc_k < apc_derLen; apc_k++ )
                                {
                                    CORBA::Long start_dcDefLen = strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef.length();
                                    PPT_METHODTRACE_V3("", "strDCDef.length()", start_dcDefLen, sc_j);

                                    for( CORBA::Long sc_k = 0; sc_k < start_dcDefLen; sc_k++ )
                                    {
                                        CORBA::Long start_dcitemLen = strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem.length();
                                        PPT_METHODTRACE_V3("", "strDCItem.length()", start_dcitemLen, sc_k);

                                        for( CORBA::Long sc_l = 0; sc_l < start_dcitemLen; sc_l++ )
                                        {
                                            //----------------------
                                            //   itemType check
                                            //----------------------
                                            if( CIMFWStrCmp(strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].itemType, SP_DCDef_Item_UserFunction) != 0)
                                            {
                                                PPT_METHODTRACE_V1("", "itemType != SP_DCDef_Item_UserFunction" );
                                                continue;
                                            }

                                            PPT_METHODTRACE_V2("", "strAPCDerivedDataInqResult.strAPCDerivedDataResponseList--Lot",
                                                                    strAPCDerivedDataInqResult.strAPCDerivedDataResponseList[apc_i].strAPCLotDerivedDataList[apc_j].lotID);
                                            PPT_METHODTRACE_V2("", "strDataSpecCheckReqResult.strStartCassette--Lot",
                                                                    strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].lotID.identifier);
                                            PPT_METHODTRACE_V2("", "name",
                                                                    strAPCDerivedDataInqResult.strAPCDerivedDataResponseList[apc_i].strAPCLotDerivedDataList[apc_j].strAPCDerivedDataList[apc_k].name);
                                            PPT_METHODTRACE_V2("", "dataCollectionItemName",
                                                                    strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].dataCollectionItemName);

                                            //--------------------------------------
                                            //   dataCollectionItemName check
                                            //--------------------------------------
                                            CORBA::Long start_actionLen = 0;
                                            if( CIMFWStrCmp(strAPCDerivedDataInqResult.strAPCDerivedDataResponseList[apc_i].strAPCLotDerivedDataList[apc_j].strAPCDerivedDataList[apc_k].name,
                                                            strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].dataCollectionItemName) == 0)
                                            {
                                                PPT_METHODTRACE_V1("", "APC--lotID == StartCassette--lotID AND APC--name == StartCassette--dataCollectionItemName" );

                                                strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].specCheckResult = CIMFWStrDup( SP_SpecCheckResult_APCError );
                                                PPT_METHODTRACE_V2("", "Set specCheckResult",
                                                                        strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].specCheckResult);

                                                start_actionLen = strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].actionCode.length();
                                                strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].actionCode.length(start_actionLen + 3);   //P6000053
                                                strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].actionCode[start_actionLen]
                                                    = CIMFWStrDup( SP_ActionCode_LotHold );
                                                strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].actionCode[start_actionLen + 1]
                                                    = CIMFWStrDup( SP_ActionCode_EquipmentHold );
                                                strDataSpecCheckReqResult.strStartCassette[sc_i].strLotInCassette[sc_j].strStartRecipe.strDCDef[sc_k].strDCItem[sc_l].actionCode[start_actionLen + 2]   //P6000053
                                                    = CIMFWStrDup( SP_ActionCode_Mail );                                                                                                                //P6000053
                                            }
                                        } //for strDCItem
                                    } //for strDCDef
                                } //for strAPCDerivedDataList
                            } //if StartCassette's LotID == APC's LotID
                        } //for strLotInCassette
                    } //for strStartCassette
                } //for strAPCLotDerivedDataList
            } //for strAPCDerivedDataResponseList
        }
        else if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txAPCDerivedDataInq() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strAPCDerivedDataInqResult.strResult;
//DSN000015229 Add start
            if ( NULL != specCheckIndexSeq )
            {
                PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                delete [] specCheckIndexSeq;
            }
//DSN000015229 Add end
            return( rc );
        }

//DSIV00001830 Add Start
        //----------------------------------------------------------------
        // Bonding Map Info Get
        //----------------------------------------------------------------
        objBondingGroup_infoByEqp_GetDR_out strBondingGroup_infoByEqp_GetDR_out;
        objBondingGroup_infoByEqp_GetDR_in strBondingGroup_infoByEqp_GetDR_in;
        strBondingGroup_infoByEqp_GetDR_in.equipmentID        = strCollectedDataActionByPostProcReqInParm.equipmentID;
        strBondingGroup_infoByEqp_GetDR_in.controlJobID       = strCollectedDataActionByPostProcReqInParm.controlJobID;
        strBondingGroup_infoByEqp_GetDR_in.bondingMapInfoFlag = TRUE;

        PPT_METHODTRACE_V1( "", "calling bondingGroup_infoByEqp_GetDR()" );
        rc = bondingGroup_infoByEqp_GetDR( strBondingGroup_infoByEqp_GetDR_out,
                                           strObjCommonIn,
                                           strBondingGroup_infoByEqp_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "","bondingGroup_infoByEqp_GetDR() != RC_OK", rc );
            strCollectedDataActionByPostProcReqResult.strResult = strBondingGroup_infoByEqp_GetDR_out.strResult;
//DSN000015229 Add start
            if ( NULL != specCheckIndexSeq )
            {
                PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                delete [] specCheckIndexSeq;
            }
//DSN000015229 Add end
            return rc;
        }
        const CORBA::Long topLotLen = strBondingGroup_infoByEqp_GetDR_out.topLotIDSeq.length();
        PPT_METHODTRACE_V2( "", "topLotLen", topLotLen );

        if ( topLotLen > 0 )
        {
            PPT_METHODTRACE_V1("", "There is Top Lot." );

            nCastLen = strDataSpecCheckReqResult.strStartCassette.length();
            for ( i = 0; i < nCastLen; i++ )
            {
                nLotCastLen = strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette.length();
                PPT_METHODTRACE_V2("", "strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette.length", nLotCastLen);

                for ( j = 0; j < nLotCastLen; j++ )
                {
                    //---------------------------//
                    //   Omit Not-OpeStart Lot   //
                    //---------------------------//
                    if ( !strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].operationStartFlag )
                    {
                        PPT_METHODTRACE_V1("", "strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");
                        continue;
                    }

                    CORBA::Boolean isTopLot = FALSE;
                    for ( CORBA::Long topLotCnt = 0; topLotCnt < topLotLen; topLotCnt++ )
                    {
                        if ( CIMFWStrCmp( strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                          strBondingGroup_infoByEqp_GetDR_out.topLotIDSeq[topLotCnt].identifier ) == 0 )
                        {
                            PPT_METHODTRACE_V2( "","isTopLot", topLotCnt );
                            isTopLot = TRUE;
                            break;
                        }
                    }
                    if ( isTopLot )
                    {
                        PPT_METHODTRACE_V2( "", "Lot is Top Lot. Clearing Action.", strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].lotID.identifier );
                        pptDCDefSequence& strDCDef = strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef;
                        CORBA::Long defLen = strDCDef.length();
                        for ( CORBA::Long defCnt = 0; defCnt < defLen; defCnt++ )
                        {
//PSIV00002109                            strDCDef[defCnt].specCheckRequiredFlag = FALSE;

                            CORBA::Long itmLen = strDCDef[defCnt].strDCItem.length();
                            for ( CORBA::Long itmCnt = 0; itmCnt < itmLen; itmCnt++ )
                            {
                                strDCDef[defCnt].strDCItem[itmCnt].actionCode.length( 0 );
                                strDCDef[defCnt].strDCItem[itmCnt].specCheckResult = CIMFWStrDup( "" );
                            }
                        }
                        continue;
                    }
                }   // loop - Lot
            }   // loop - Cassette
        }
//DSIV00001830 Add End

        /*----------------------------------*/
        /*   Set APCDerived Data into PO    */
        /*----------------------------------*/
        PPT_METHODTRACE_V1("", "Set APCDerived Data into PO...");
        objProcessOperation_tempData_Set_out strProcessOperation_tempData_Set_out;
        rc = processOperation_tempData_Set( strProcessOperation_tempData_Set_out,
                                            strObjCommonIn,
                                            strCollectedDataActionByPostProcReqInParm.controlJobID,
                                            strDataSpecCheckReqResult.strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "processOperation_tempData_Set() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strProcessOperation_tempData_Set_out.strResult;
//DSN000015229 Add start
            if ( NULL != specCheckIndexSeq )
            {
                PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                delete [] specCheckIndexSeq;
            }
//DSN000015229 Add end
            return( rc );
        }
        DebugOutStartCassette( strDataSpecCheckReqResult );
        //----------------------------------------------------------//
        // End of Data Spec Check                                   //
        //----------------------------------------------------------//

        //----------------------------------------------//
        //  Replace ReturnCode for SPCCheckRequired.    //
        //----------------------------------------------//
        if ( rc == RC_OK )
        {
            rc = RC_NO_NEED_SPEC_CHECK;
//DSIV00001830            nCastLen = strDataSpecCheckReqResult.strStartCassette.length();
            nCastLen = strDataSpecCheckReqResult.strStartCassette.length();     //PSIV00002109
            for( i = 0; i < nCastLen; i++ )
            {
                nLotCastLen = strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette.length();
                for( j = 0; j < nLotCastLen; j++ )
                {
                    if ( strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                    {
                        continue;
                    }

                    nDCDefLen = strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                    for( k = 0; k < nDCDefLen; k++ )
                    {
                        if ( 0 == CIMFWStrCmp( strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].dataCollectionSpecificationID.identifier, "" ) )
                        {
                            continue;
                        }

                        nDCitemLen = strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem.length();
                        for( l = 0; l < nDCitemLen; l++ )
                        {
                            if( 0 != CIMFWStrCmp(strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].specCheckResult, "*") &&
                                0 != CIMFWStrCmp(strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].specCheckResult, "") )
                            {
                                rc = RC_OK;
                                break;
                            }
                        }
                        if( rc == RC_OK )
                        {
                            break;
                        }
                    }
                    if( rc == RC_OK )
                    {
                        break;
                    }
                }
                if( rc == RC_OK )
                {
                    break;
                }
            }
        }

        if ( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "Data Spec Check == RC_OK");
//DSIV00001830            //-------------------------------------------------------------------------------//
//DSIV00001830            //   Get Started Lot information in order to get the derived / delta datavalues  //
//DSIV00001830            //-------------------------------------------------------------------------------//
//DSIV00001830            objLot_previousOperation_DataCollectionInformation_Get_out   strLot_previousOperation_DataCollectionInformation_Get_out;
//DSIV00001830            objLot_previousOperation_DataCollectionInformation_Get_in    strLot_previousOperation_DataCollectionInformation_Get_in;
//DSIV00001830            // set input parameter
//DSIV00001830            strLot_previousOperation_DataCollectionInformation_Get_in.equipmentID  = strCollectedDataActionByPostProcReqInParm.equipmentID;
//DSIV00001830            strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs.length(1);
//DSIV00001830            strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs[0]    = strCollectedDataActionByPostProcReqInParm.lotID;
//DSIV00001830
//DSIV00001830            rc = lot_previousOperation_DataCollectionInformation_Get( strLot_previousOperation_DataCollectionInformation_Get_out,
//DSIV00001830                                                                      strObjCommonIn,
//DSIV00001830                                                                      strLot_previousOperation_DataCollectionInformation_Get_in);
//DSIV00001830            if ( rc != RC_OK )
//DSIV00001830            {
//DSIV00001830                PPT_METHODTRACE_V1("", "lot_previousOperation_DataCollectionInformation_Get() != RC_OK");
//DSIV00001830                strCollectedDataActionByPostProcReqResult.strResult = strLot_previousOperation_DataCollectionInformation_Get_out.strResult;
//DSIV00001830                return( rc );
//DSIV00001830            }
//DSIV00001830            //Reset StartCassette.
//DSIV00001830            tmpStartCassette = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette;
            spcCheckRequiredFlag = TRUE;
        }
        else if ( rc == RC_NO_NEED_SPEC_CHECK )
        {
            PPT_METHODTRACE_V1("", "Data Spec Check == RC_NO_NEED_TO_SPECCHECK");
//DSIV00001830            rc = RC_OK;
//DSIV00001830            //-------------------------------------------------------------------------------//
//DSIV00001830            //   Get Started Lot information in order to get the derived / delta datavalues  //
//DSIV00001830            //-------------------------------------------------------------------------------//
//DSIV00001830            objLot_previousOperation_DataCollectionInformation_Get_out   strLot_previousOperation_DataCollectionInformation_Get_out;
//DSIV00001830            objLot_previousOperation_DataCollectionInformation_Get_in    strLot_previousOperation_DataCollectionInformation_Get_in;
//DSIV00001830            // set input parameter
//DSIV00001830            strLot_previousOperation_DataCollectionInformation_Get_in.equipmentID  = strCollectedDataActionByPostProcReqInParm.equipmentID;
//DSIV00001830            strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs.length(1);
//DSIV00001830            strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs[0]    = strCollectedDataActionByPostProcReqInParm.lotID;
//DSIV00001830
//DSIV00001830            rc = lot_previousOperation_DataCollectionInformation_Get( strLot_previousOperation_DataCollectionInformation_Get_out,
//DSIV00001830                                                                      strObjCommonIn,
//DSIV00001830                                                                      strLot_previousOperation_DataCollectionInformation_Get_in);
//DSIV00001830            if ( rc != RC_OK )
//DSIV00001830            {
//DSIV00001830                PPT_METHODTRACE_V1("", "lot_previousOperation_DataCollectionInformation_Get() != RC_OK");
//DSIV00001830                strCollectedDataActionByPostProcReqResult.strResult = strLot_previousOperation_DataCollectionInformation_Get_out.strResult;
//DSIV00001830                return( rc );
//DSIV00001830            }
//DSIV00001830            //Reset StartCassette.
//DSIV00001830            tmpStartCassette = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette;
        }
        else
        {
            PPT_METHODTRACE_V1("", "Data Spec Check != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strDataSpecCheckReqResult.strResult;
//DSN000015229 Add start
            if ( NULL != specCheckIndexSeq )
            {
                PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                delete [] specCheckIndexSeq;
            }
//DSN000015229 Add end
            return( rc );
        }

//PSIV00002109 Add Start
        //-------------------------------------------------------------------------------//
        //  Get Started Lot information in order to get the derived / delta data values  //
        //-------------------------------------------------------------------------------//
        objLot_previousOperation_DataCollectionInformation_Get_out   strLot_previousOperation_DataCollectionInformation_Get_out;
        objLot_previousOperation_DataCollectionInformation_Get_in    strLot_previousOperation_DataCollectionInformation_Get_in;
        // set input parameter
        strLot_previousOperation_DataCollectionInformation_Get_in.equipmentID  = strCollectedDataActionByPostProcReqInParm.equipmentID;
        strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs.length(1);
        strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs[0]    = strCollectedDataActionByPostProcReqInParm.lotID;

        rc = lot_previousOperation_DataCollectionInformation_Get( strLot_previousOperation_DataCollectionInformation_Get_out,
                                                                  strObjCommonIn,
                                                                  strLot_previousOperation_DataCollectionInformation_Get_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "lot_previousOperation_DataCollectionInformation_Get() != RC_OK", rc );
            strCollectedDataActionByPostProcReqResult.strResult = strLot_previousOperation_DataCollectionInformation_Get_out.strResult;
//DSN000015229 Add start
            if ( NULL != specCheckIndexSeq )
            {
                PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                delete [] specCheckIndexSeq;
            }
//DSN000015229 Add end
            return rc;
        }
        //Reset StartCassette.
        tmpStartCassette = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette;
//PSIV00002109 Add End
    }


    //-------------------------//
    //                         //
    //   SPC Check Procedure   //
    //                         //
    //-------------------------//
    PPT_METHODTRACE_V2("", "spcCheckRequiredFlag is ", spcCheckRequiredFlag );
//DSIV00001021    pptSpcCheckReqResult strSpcCheckReqResult;
//DSIV00001021    objSPCMgr_SendSPCCheckReq_out strSPCMgr_SendSPCCheckReq_out;
//DSIV00001021    if ( spcCheckRequiredFlag == TRUE )
//DSIV00001021    {
//DSIV00001021        //----------------------------//
//DSIV00001021        //   Send SPC Check Request   //
//DSIV00001021        //----------------------------//
//DSIV00001021        rc = SPCMgr_SendSPCCheckReq( strSPCMgr_SendSPCCheckReq_out,
//DSIV00001021                                     strObjCommonIn,
//DSIV00001021                                     strCollectedDataActionByPostProcReqInParm.equipmentID,
//DSIV00001021                                     strCollectedDataActionByPostProcReqInParm.controlJobID,
//DSIV00001021                                     tmpStartCassette );
//DSIV00001021        if ( rc == RC_OK || rc == RC_NO_NEED_TO_SPCCHECK )
//DSIV00001021        {
//DSIV00001021            PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq() == RC_OK || RC_NO_NEED_TO_SPCCHECK") ;
//DSIV00001021            rc = RC_OK;
//DSIV00001021        }
//DSIV00001021        else
//DSIV00001021        {
//DSIV00001021            PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq() != RC_OK") ;
//DSIV00001021            strCollectedDataActionByPostProcReqResult.strResult = strSPCMgr_SendSPCCheckReq_out.strResult ;
//DSIV00001021            return( rc );
//DSIV00001021        }
//DSIV00001021 add start
    pptSpcCheckReqResult__101 strSpcCheckReqResult;
    objSPCMgr_SendSPCCheckReq_out__101 strSPCMgr_SendSPCCheckReq_out;
    if ( spcCheckRequiredFlag == TRUE )
    {
        //----------------------------//
        //   Send SPC Check Request   //
        //----------------------------//
        rc = SPCMgr_SendSPCCheckReq__101( strSPCMgr_SendSPCCheckReq_out,
                                     strObjCommonIn,
                                     strCollectedDataActionByPostProcReqInParm.equipmentID,
                                     strCollectedDataActionByPostProcReqInParm.controlJobID,
                                     tmpStartCassette );
        if ( rc == RC_OK || rc == RC_NO_NEED_TO_SPCCHECK )
        {
            PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq__101() == RC_OK || RC_NO_NEED_TO_SPCCHECK");
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq__101() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strSPCMgr_SendSPCCheckReq_out.strResult;
//DSN000015229 Add start
            if ( NULL != specCheckIndexSeq )
            {
                PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
                delete [] specCheckIndexSeq;
            }
//DSN000015229 Add end
            return( rc );
        }
//DSIV00001021 add end
        strSpcCheckReqResult = strSPCMgr_SendSPCCheckReq_out.strSpcCheckReqResult;
    }

//DSN000015229 Add start
    //---------------------
    // Remove Already checked item from tmpStartCassette
    //---------------------
    pptStartCassetteSequence strStartCassetteForAction;

    if ( TRUE == bPJDataExistFlag )
    {
        PPT_METHODTRACE_V1("", "TRUE == bPJDataExistFlag");
        //---------------------
        // Remove Already checked item from tmpStartCassette
        //---------------------
        strStartCassetteForAction = tmpStartCassette;

        for ( dcDefIndexNum = 0; dcDefIndexNum < specCheckIndexLen; dcDefIndexNum++ )
        {
            PPT_METHODTRACE_V2("", "dcDefIndexNum", dcDefIndexNum);
            CORBA::Long specCheckIndexCnt = specCheckIndexSeq[dcDefIndexNum].length();
            pptDCItemSequence& strSourceDCItemSeq = tmpStartCassette[0].strLotInCassette[0].strStartRecipe.strDCDef[dcDefIndexNum].strDCItem;
            pptDCItemSequence& strTargetDCItemSeq = strStartCassetteForAction[0].strLotInCassette[0].strStartRecipe.strDCDef[dcDefIndexNum].strDCItem;
            strTargetDCItemSeq.length(specCheckIndexCnt);
            for ( dcItemIndexNum = 0; dcItemIndexNum < specCheckIndexCnt; dcItemIndexNum++ )
            {
                PPT_METHODTRACE_V2("", "dcItemIndexNum", dcItemIndexNum);
                CORBA::Long sourceIndex = specCheckIndexSeq[dcDefIndexNum][dcItemIndexNum];
                if ( sourceIndex >= strSourceDCItemSeq.length() )
                {
                    PPT_METHODTRACE_V1("", "index >= strDCItem.length()");
                    SET_MSG_RC(strCollectedDataActionByPostProcReqResult, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                    delete [] specCheckIndexSeq;
                    return( RC_SYSTEM_ERROR );
                }
                strTargetDCItemSeq[dcItemIndexNum] = strSourceDCItemSeq[sourceIndex];
            }
        }
    }

    if ( NULL != specCheckIndexSeq )
    {
        PPT_METHODTRACE_V1("", "NULL != specCheckIndexSeq");
        delete [] specCheckIndexSeq;
    }
//DSN000015229 Add end

    //-----------------------------------------------------------------//
    //   Summary Action Items to Lot based on the Spec Check Result    //
    //-----------------------------------------------------------------//
//DSIV00000214    objStartLot_actionList_EffectSpecCheck_out strStartLot_actionList_EffectSpecCheck_out;
//DSIV00000214    rc = startLot_actionList_EffectSpecCheck(  strStartLot_actionList_EffectSpecCheck_out, strObjCommonIn,
//DSIV00000214                                               tmpStartCassette,
//DSIV00000214                                               strCollectedDataActionByPostProcReqInParm.equipmentID);
//DSIV00000214    if ( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "startLot_actionList_EffectSpecCheck() != RC_OK") ;
//DSIV00000214        strCollectedDataActionByPostProcReqResult.strResult = strStartLot_actionList_EffectSpecCheck_out.strResult ;
//DSIV00000214        return( rc );
//DSIV00000214    }
//DSIV00000214 add start
//DSIV00001021    objStartLot_actionList_EffectSpecCheck_out__100 strStartLot_actionList_EffectSpecCheck_out;
//DSIV00001021    objStartLot_actionList_EffectSpecCheck_in__100  strStartLot_actionList_EffectSpecCheck_in;
//DSIV00001021    strStartLot_actionList_EffectSpecCheck_in.strStartCassette = tmpStartCassette;
//DSIV00001021    strStartLot_actionList_EffectSpecCheck_in.equipmentID      = strCollectedDataActionByPostProcReqInParm.equipmentID;
//DSIV00001021    pptInterFabMonitorGroupActionInfoSequence strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    strStartLot_actionList_EffectSpecCheck_in.strInterFabMonitorGroupActionInfoSequence = strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    rc = startLot_actionList_EffectSpecCheck__100( strStartLot_actionList_EffectSpecCheck_out, strObjCommonIn,
//DSIV00001021                                                   strStartLot_actionList_EffectSpecCheck_in );
//DSIV00001021    if( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V2("", "startLot_actionList_EffectSpecCheck__100() != RC_OK", rc);
//DSIV00001021        strCollectedDataActionByPostProcReqResult.strResult = strStartLot_actionList_EffectSpecCheck_out.strResult;
//DSIV00001021        return rc;
//DSIV00001021    }
//DSIV00000214 add end
//DSIV00001021 add start
    objStartLot_actionList_EffectSpecCheck_out__101 strStartLot_actionList_EffectSpecCheck_out;
    objStartLot_actionList_EffectSpecCheck_in__101  strStartLot_actionList_EffectSpecCheck_in;
//DSN000015229    strStartLot_actionList_EffectSpecCheck_in.strStartCassette = tmpStartCassette;
//DSN000015229 Add start
    if ( TRUE == bPJDataExistFlag )
    {
        PPT_METHODTRACE_V1("", "TRUE == bPJDataExistFlag");
        strStartLot_actionList_EffectSpecCheck_in.strStartCassette = strStartCassetteForAction;
    }
    else
    {
        PPT_METHODTRACE_V1("", "TRUE != bPJDataExistFlag");
        strStartLot_actionList_EffectSpecCheck_in.strStartCassette = tmpStartCassette;
    }
//DSN000015229 Add end
    strStartLot_actionList_EffectSpecCheck_in.equipmentID      = strCollectedDataActionByPostProcReqInParm.equipmentID;
    pptInterFabMonitorGroupActionInfoSequence strInterFabMonitorGroupActionInfoSequence;
    strStartLot_actionList_EffectSpecCheck_in.strInterFabMonitorGroupActionInfoSequence = strInterFabMonitorGroupActionInfoSequence;
    pptDCActionLotResultSequence strDCActionLotResult;
    strStartLot_actionList_EffectSpecCheck_in.strDCActionLotResult = strDCActionLotResult;
    rc = startLot_actionList_EffectSpecCheck__101( strStartLot_actionList_EffectSpecCheck_out, strObjCommonIn,
                                                   strStartLot_actionList_EffectSpecCheck_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "startLot_actionList_EffectSpecCheck__101() != RC_OK", rc);
        strCollectedDataActionByPostProcReqResult.strResult = strStartLot_actionList_EffectSpecCheck_out.strResult;
        return rc;
    }
//DSIV00001021 add end
    //-----------------------------------------------------------------//
    //   Register Entity Inhibition as the result of SPEC Check        //
    //-----------------------------------------------------------------//
    CORBA::Long nCheckLen = strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length();
    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length()", nCheckLen );

//DSIV00001365    pptEntityInhibitReqResult strEntityInhibitReqResult;
    pptEntityInhibitReqResult__101 strEntityInhibitReqResult;    //DSIV00001365

    for( i=0; i < nCheckLen; i++ )
    {
//DSIV00001365        rc = txEntityInhibitReq(strEntityInhibitReqResult, strObjCommonIn,
//DSIV00001365                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[i],
//DSIV00001365                                claimMemo);
//DSIV00001365
//DSIV00001365        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))
//DSIV00001365        {
//DSIV00001365            PPT_METHODTRACE_V1("", "txEntityInhibitReq() != RC_OK") ;
//DSIV00001365            strCollectedDataActionByPostProcReqResult.strResult = strEntityInhibitReqResult.strResult ;
//DSIV00001365            return( rc );
//DSIV00001365        }
//DSIV00001365        PPT_METHODTRACE_V2("", "txEntityInhibitReq() rc = ", rc);
//DSIV00001365 add start
        rc = txEntityInhibitReq__101(strEntityInhibitReqResult, strObjCommonIn,
                                     strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[i],
                                     claimMemo);

        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))
        {
            PPT_METHODTRACE_V1("", "txEntityInhibitReq__101() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strEntityInhibitReqResult.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "txEntityInhibitReq__101() rc = ", rc);
//DSIV00001365 add end
    }

    //-----------------------------------------------//
    //   Send a message as the result of SPEC Check  //
    //-----------------------------------------------//
    CORBA::Long nMsgLen = strStartLot_actionList_EffectSpecCheck_out.strMessageList.length();
    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSpecCheck_out.strMessageList.length()",nMsgLen);

    objMessageDistributionMgr_PutMessage_out   strMessageDistributionMgr_PutMessage_out;

    for( i=0; i < nMsgLen; i++ )
    {
        rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out, strObjCommonIn,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].messageID,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].lotID,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].lotStatus,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].equipmentID,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].routeID,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].operationNumber,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].reasonCode,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].messageText);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult;
            return( rc );
        }
    }

//DSIV00000214 add start
    //-------------------------------------------------------------------------//
    //   Register Entity Inhibition as the result of Spec Check(SaR request)   //
    //-------------------------------------------------------------------------//
    objEntityInhibit_RequestForMultiFab_out strEntityInhibit_RequestForMultiFab_out;
//DSIV00001365    objEntityInhibit_RequestForMultiFab_in  strEntityInhibit_RequestForMultiFab_in;
    objEntityInhibit_RequestForMultiFab_in__101  strEntityInhibit_RequestForMultiFab_in;    //DSIV00001365
    strEntityInhibit_RequestForMultiFab_in.strEntityInhibitionsWithFabInfo = strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo;
    strEntityInhibit_RequestForMultiFab_in.claimMemo = CIMFWStrDup("");
//DSIV00001365    rc = entityInhibit_RequestForMultiFab( strEntityInhibit_RequestForMultiFab_out, strObjCommonIn,
//DSIV00001365                                           strEntityInhibit_RequestForMultiFab_in );
//DSIV00001365    if( rc != RC_OK )
//DSIV00001365    {
//DSIV00001365        PPT_METHODTRACE_V2("", "entityInhibit_RequestForMultiFab() != RC_OK", rc);
//DSIV00001365        strCollectedDataActionByPostProcReqResult.strResult = strEntityInhibit_RequestForMultiFab_out.strResult;
//DSIV00001365        return rc;
//DSIV00001365    }
//DSIV00001365 add start
    rc = entityInhibit_RequestForMultiFab__101( strEntityInhibit_RequestForMultiFab_out, strObjCommonIn,
                                                strEntityInhibit_RequestForMultiFab_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "entityInhibit_RequestForMultiFab__101() != RC_OK", rc);
        strCollectedDataActionByPostProcReqResult.strResult = strEntityInhibit_RequestForMultiFab_out.strResult;
        return rc;
    }
//DSIV00001365 add end
//DSIV00000214 add end

    //-----------------------------------------------------------------//
    //   Summary Action Items to Lot based on the SPC Check Result     //
    //-----------------------------------------------------------------//
//DSIV00000214    objStartLot_actionList_EffectSPCCheck_out   strStartLot_actionList_EffectSPCCheck_out;
//DSIV00000214    rc = startLot_actionList_EffectSPCCheck(strStartLot_actionList_EffectSPCCheck_out, strObjCommonIn,
//DSIV00000214                                            strSpcCheckReqResult.strSpcCheckLot,
//DSIV00000214                                            strSPCMgr_SendSPCCheckReq_out.strSpcIFParm,
//DSIV00000214                                            strCollectedDataActionByPostProcReqInParm.equipmentID);
//DSIV00000214    if ( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "strStartLot_actionList_EffectSPCCheck_out() != RC_OK") ;
//DSIV00000214        strCollectedDataActionByPostProcReqResult.strResult = strStartLot_actionList_EffectSPCCheck_out.strResult ;
//DSIV00000214        return( rc );
//DSIV00000214    }
//DSIV00000214 add start
//DSIV00001021    objStartLot_actionList_EffectSPCCheck_out__100 strStartLot_actionList_EffectSPCCheck_out;
//DSIV00001021    objStartLot_actionList_EffectSPCCheck_in__100  strStartLot_actionList_EffectSPCCheck_in;
//DSIV00001021    strStartLot_actionList_EffectSPCCheck_in.strSpcCheckLot = strSpcCheckReqResult.strSpcCheckLot;
//DSIV00001021    strStartLot_actionList_EffectSPCCheck_in.strSpcIFParm   = strSPCMgr_SendSPCCheckReq_out.strSpcIFParm;
//DSIV00001021    strStartLot_actionList_EffectSPCCheck_in.equipmentID    = strCollectedDataActionByPostProcReqInParm.equipmentID;
//DSIV00001021    strStartLot_actionList_EffectSPCCheck_in.strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSpecCheck_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    rc = startLot_actionList_EffectSPCCheck__100( strStartLot_actionList_EffectSPCCheck_out, strObjCommonIn,
//DSIV00001021                                                  strStartLot_actionList_EffectSPCCheck_in );
//DSIV00001021    if( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V2("", "startLot_actionList_EffectSPCCheck__100() != RC_OK", rc);
//DSIV00001021        strCollectedDataActionByPostProcReqResult.strResult = strStartLot_actionList_EffectSPCCheck_out.strResult;
//DSIV00001021        return rc;
//DSIV00001021    }
//DSIV00000214 add end
//DSIV00001021 add start
    objStartLot_actionList_EffectSPCCheck_out__101 strStartLot_actionList_EffectSPCCheck_out;
    objStartLot_actionList_EffectSPCCheck_in__101  strStartLot_actionList_EffectSPCCheck_in;
    strStartLot_actionList_EffectSPCCheck_in.strSpcCheckLot = strSpcCheckReqResult.strSpcCheckLot;
    strStartLot_actionList_EffectSPCCheck_in.strSpcIFParm   = strSPCMgr_SendSPCCheckReq_out.strSpcIFParm;
    strStartLot_actionList_EffectSPCCheck_in.equipmentID    = strCollectedDataActionByPostProcReqInParm.equipmentID;
    strStartLot_actionList_EffectSPCCheck_in.strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSpecCheck_out.strInterFabMonitorGroupActionInfoSequence;
    strStartLot_actionList_EffectSPCCheck_in.strDCActionLotResult = strStartLot_actionList_EffectSpecCheck_out.strDCActionLotResult;
    rc = startLot_actionList_EffectSPCCheck__101( strStartLot_actionList_EffectSPCCheck_out, strObjCommonIn,
                                                  strStartLot_actionList_EffectSPCCheck_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "startLot_actionList_EffectSPCCheck__101() != RC_OK", rc);
        strCollectedDataActionByPostProcReqResult.strResult = strStartLot_actionList_EffectSPCCheck_out.strResult;
        return rc;
    }
//DSIV00001021 add end
    //-----------------------------------------------------------------------//
    //   Register Entity Inhibition as the result of SPC Check               //
    //-----------------------------------------------------------------------//
    nCheckLen = 0; // Initialize for recycling.
    nCheckLen = strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length();
    PPT_METHODTRACE_V2("",  "strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length()", nCheckLen);

//DSIV00001365    pptEntityInhibitReqResult strSpcEntityInhibitReqResult;
    pptEntityInhibitReqResult__101 strSpcEntityInhibitReqResult;    //DSIV00001365

    for( i=0; i < nCheckLen; i++ )
    {
//DSIV00001365        rc = txEntityInhibitReq(strSpcEntityInhibitReqResult, strObjCommonIn,
//DSIV00001365                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[i],
//DSIV00001365                                claimMemo);
//DSIV00001365
//DSIV00001365        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))
//DSIV00001365        {
//DSIV00001365            PPT_METHODTRACE_V1("", "txEntityInhibitReq() != RC_OK") ;
//DSIV00001365            strCollectedDataActionByPostProcReqResult.strResult = strSpcEntityInhibitReqResult.strResult ;
//DSIV00001365            return( rc );
//DSIV00001365        }
//DSIV00001365        PPT_METHODTRACE_V2("", "txEntityInhibitReq() rc = ", rc) ;
//DSIV00001365 add start
        rc = txEntityInhibitReq__101(strSpcEntityInhibitReqResult, strObjCommonIn,
                                     strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[i],
                                     claimMemo);

        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))
        {
            PPT_METHODTRACE_V1("", "txEntityInhibitReq__101() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strSpcEntityInhibitReqResult.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "txEntityInhibitReq__101() rc = ", rc);
//DSIV00001365 add end
    }

    //-----------------------------------------------//
    //   Send a message as the result of SPC Check   //
    //-----------------------------------------------//
    nMsgLen = 0; // Initialize for recycling.
    nMsgLen = strStartLot_actionList_EffectSPCCheck_out.strMessageList.length();
    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSPCCheck_out.strMessageList.length()", nMsgLen);

    for( i=0; i < nMsgLen; i++ )
    {
        PPT_METHODTRACE_V2("", "messageText", strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageText);

        rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out, strObjCommonIn,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageID,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].lotID,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].lotStatus,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].equipmentID,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].routeID,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].operationNumber,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].reasonCode,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageText);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult;
            return( rc );
        }
    }

//DSIV00000214 add start
    //------------------------------------------------------------------------//
    //   Register Entity Inhibition as the result of SPC Check(SaR request)   //
    //------------------------------------------------------------------------//
    objEntityInhibit_RequestForMultiFab_out strEntityInhibit_RequestForMultiFab_outForSPC;
//DSIV00001365    objEntityInhibit_RequestForMultiFab_in  strEntityInhibit_RequestForMultiFab_inForSPC;
    objEntityInhibit_RequestForMultiFab_in__101  strEntityInhibit_RequestForMultiFab_inForSPC;    //DSIV00001365
    strEntityInhibit_RequestForMultiFab_inForSPC.strEntityInhibitionsWithFabInfo = strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo;
    strEntityInhibit_RequestForMultiFab_inForSPC.claimMemo = CIMFWStrDup("");
//DSIV00001365    rc = entityInhibit_RequestForMultiFab( strEntityInhibit_RequestForMultiFab_outForSPC, strObjCommonIn,
//DSIV00001365                                           strEntityInhibit_RequestForMultiFab_inForSPC );
//DSIV00001365    if( rc != RC_OK )
//DSIV00001365    {
//DSIV00001365        PPT_METHODTRACE_V2("", "entityInhibit_RequestForMultiFab() != RC_OK", rc);
//DSIV00001365        strCollectedDataActionByPostProcReqResult.strResult = strEntityInhibit_RequestForMultiFab_outForSPC.strResult;
//DSIV00001365        return rc;
//DSIV00001365    }
//DSIV00001365 add start
    rc = entityInhibit_RequestForMultiFab__101( strEntityInhibit_RequestForMultiFab_outForSPC, strObjCommonIn,
                                                strEntityInhibit_RequestForMultiFab_inForSPC );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "entityInhibit_RequestForMultiFab__101() != RC_OK", rc);
        strCollectedDataActionByPostProcReqResult.strResult = strEntityInhibit_RequestForMultiFab_outForSPC.strResult;
        return rc;
    }
//DSIV00001365 add end

    //----------------------------------------------------------------------------//
    //   Send a message per chart owner as the result of SPC Check(SaR request)   //
    //----------------------------------------------------------------------------//
    objSystemMessage_RequestForMultiFab_out strSystemMessage_RequestForMultiFab_out;
    objSystemMessage_RequestForMultiFab_in  strSystemMessage_RequestForMultiFab_in;
    pptMessageAttributesWithFabInfoSequence tmpMessageAttributesWithFabInfoSeq;
    CORBA::Long mailLen = strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo.length();
    tmpMessageAttributesWithFabInfoSeq.length(1);
    for( i=0; i<mailLen; i++ )
    {
        tmpMessageAttributesWithFabInfoSeq[0].fabID = strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[i].fabID;
        tmpMessageAttributesWithFabInfoSeq[0].strMessageAttributes = strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[i].strMailSend.messageAttributes;
        pptObjCommonIn tmpObjCommonIn;
        tmpObjCommonIn.strUser.userID.identifier = strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[i].strMailSend.chartMailAdderess;

        strSystemMessage_RequestForMultiFab_in.strMessageListWithFabInfo = tmpMessageAttributesWithFabInfoSeq;
        rc = systemMessage_RequestForMultiFab( strSystemMessage_RequestForMultiFab_out, strObjCommonIn,
                                               strSystemMessage_RequestForMultiFab_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "systemMessage_RequestForMultiFab() != RC_OK", rc);
            strCollectedDataActionByPostProcReqResult.strResult = strSystemMessage_RequestForMultiFab_out.strResult;
            return rc;
        }
    }
//DSIV00000214 add end

    //---------------------------------------------------------------------------
    //   Execute Lot Hold Action based on SpecCheck and also SPC Check result.
    //---------------------------------------------------------------------------

    //-------------------------------------//
    //   Effect The Result of SPEC Check   //
    //-------------------------------------//
//DSIV00000214    objLot_holdRecord_EffectSpecCheckResult_out strLot_holdRecord_EffectSpecCheckResult_out;
//DSIV00000214    rc = lot_holdRecord_EffectSpecCheckResult(  strLot_holdRecord_EffectSpecCheckResult_out, strObjCommonIn, tmpStartCassette);
//DSIV00000214    if ( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSpecCheckResult() != RC_OK") ;
//DSIV00000214        strCollectedDataActionByPostProcReqResult.strResult = strLot_holdRecord_EffectSpecCheckResult_out.strResult ;
//DSIV00000214        return( rc );
//DSIV00000214    }
//DSIV00000214 add start
//DSIV00001021    objLot_holdRecord_EffectSpecCheckResult_out__100 strLot_holdRecord_EffectSpecCheckResult_out;
//DSIV00001021    objLot_holdRecord_EffectSpecCheckResult_in__100  strLot_holdRecord_EffectSpecCheckResult_in;
//DSIV00001021    strLot_holdRecord_EffectSpecCheckResult_in.strStartCassette = tmpStartCassette;
//DSIV00001021    strLot_holdRecord_EffectSpecCheckResult_in.strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSPCCheck_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    rc = lot_holdRecord_EffectSpecCheckResult__100( strLot_holdRecord_EffectSpecCheckResult_out, strObjCommonIn,
//DSIV00001021                                                    strLot_holdRecord_EffectSpecCheckResult_in );
//DSIV00001021    if( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSpecCheckResult__100() != RC_OK", rc);
//DSIV00001021        strCollectedDataActionByPostProcReqResult.strResult = strLot_holdRecord_EffectSpecCheckResult_out.strResult;
//DSIV00001021        return rc;
//DSIV00001021    }
//DSIV00000214 add end
//DSIV00001021 add start
    objLot_holdRecord_EffectSpecCheckResult_out__101 strLot_holdRecord_EffectSpecCheckResult_out;
    objLot_holdRecord_EffectSpecCheckResult_in__101  strLot_holdRecord_EffectSpecCheckResult_in;
    strLot_holdRecord_EffectSpecCheckResult_in.strStartCassette = tmpStartCassette;
    strLot_holdRecord_EffectSpecCheckResult_in.strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSPCCheck_out.strInterFabMonitorGroupActionInfoSequence;
    strLot_holdRecord_EffectSpecCheckResult_in.strDCActionLotResult = strStartLot_actionList_EffectSPCCheck_out.strDCActionLotResult;
    rc = lot_holdRecord_EffectSpecCheckResult__101( strLot_holdRecord_EffectSpecCheckResult_out, strObjCommonIn,
                                                    strLot_holdRecord_EffectSpecCheckResult_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSpecCheckResult__101() != RC_OK", rc);
        strCollectedDataActionByPostProcReqResult.strResult = strLot_holdRecord_EffectSpecCheckResult_out.strResult;
        return rc;
    }
//DSIV00001021 add end
    //--------------//
    // Lot Hold     //
    //--------------//
    CORBA::Long nSpecLotHoldEffectListLen = 0;
    nSpecLotHoldEffectListLen = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length();
    if ( nSpecLotHoldEffectListLen  > 0 )
    {
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length()", nSpecLotHoldEffectListLen);

        pptHoldLotReqResult strHoldLotReqResult;

        pptHoldListSequence strLotHoldReqList;
        strLotHoldReqList.length( 1 );

        for( i = 0; i < nSpecLotHoldEffectListLen; i++ )
        {
            strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].holdType;
            strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].reasonCodeID;
            strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].userID;
            strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].responsibleOperationMark;
            strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].routeID;
            strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].operationNumber;
            strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].relatedLotID;
            strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].claimMemo;

            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn , strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].lotID , strLotHoldReqList );
            if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
                strCollectedDataActionByPostProcReqResult.strResult = strHoldLotReqResult.strResult;
                return( rc );
            }
        }
    }

    //--------------//
    // Future Hold  //
    //--------------//
    CORBA::Long nSpecFutureHoldEffectLen = 0;
    nSpecFutureHoldEffectLen = strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length();
    if ( nSpecFutureHoldEffectLen  > 0 )
    {
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length()", nSpecFutureHoldEffectLen);

        for( i=0; i < nSpecFutureHoldEffectLen; i++ )
        {
            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult, strObjCommonIn ,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].holdType ,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].lotID,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].routeID,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].operationNumber,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
                                          TRUE,
                                          TRUE,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].claimMemo );
            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
            {
                PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY");
                strCollectedDataActionByPostProcReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
                return( rc );
            }
        }
    }

    //------------------------------------//
    //   Effect The Result of SPC Check   //
    //------------------------------------//
//DSIV00000214    objLot_holdRecord_EffectSPCCheckResult_out strLot_holdRecord_EffectSPCCheckResult_out;
//DSIV00000214    rc = lot_holdRecord_EffectSPCCheckResult(  strLot_holdRecord_EffectSPCCheckResult_out, strObjCommonIn, strSpcCheckReqResult.strSpcCheckLot );
//DSIV00000214    if ( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSPCCheckResult() != RC_OK") ;
//DSIV00000214        strCollectedDataActionByPostProcReqResult.strResult = strLot_holdRecord_EffectSPCCheckResult_out.strResult ;
//DSIV00000214        return( rc );
//DSIV00000214    }
//DSIV00000214 add start
//DSIV00001021    objLot_holdRecord_EffectSPCCheckResult_out__100 strLot_holdRecord_EffectSPCCheckResult_out;
//DSIV00001021    objLot_holdRecord_EffectSPCCheckResult_in__100  strLot_holdRecord_EffectSPCCheckResult_in;
//DSIV00001021    strLot_holdRecord_EffectSPCCheckResult_in.strSpcCheckLot = strSpcCheckReqResult.strSpcCheckLot;
//DSIV00001021    strLot_holdRecord_EffectSPCCheckResult_in.strInterFabMonitorGroupActionInfoSequence = strLot_holdRecord_EffectSpecCheckResult_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    rc = lot_holdRecord_EffectSPCCheckResult__100( strLot_holdRecord_EffectSPCCheckResult_out, strObjCommonIn,
//DSIV00001021                                                   strLot_holdRecord_EffectSPCCheckResult_in );
//DSIV00001021    if( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSPCCheckResult__100() != RC_OK", rc);
//DSIV00001021        strCollectedDataActionByPostProcReqResult.strResult = strLot_holdRecord_EffectSPCCheckResult_out.strResult;
//DSIV00001021        return rc;
//DSIV00001021    }
//DSIV00000214 add end
//DSIV00001021 add start
    objLot_holdRecord_EffectSPCCheckResult_out__101 strLot_holdRecord_EffectSPCCheckResult_out;
    objLot_holdRecord_EffectSPCCheckResult_in__101  strLot_holdRecord_EffectSPCCheckResult_in;
    strLot_holdRecord_EffectSPCCheckResult_in.strSpcCheckLot = strSpcCheckReqResult.strSpcCheckLot;
    strLot_holdRecord_EffectSPCCheckResult_in.strInterFabMonitorGroupActionInfoSequence = strLot_holdRecord_EffectSpecCheckResult_out.strInterFabMonitorGroupActionInfoSequence;
    strLot_holdRecord_EffectSPCCheckResult_in.strDCActionLotResult = strLot_holdRecord_EffectSpecCheckResult_out.strDCActionLotResult;
    rc = lot_holdRecord_EffectSPCCheckResult__101( strLot_holdRecord_EffectSPCCheckResult_out, strObjCommonIn,
                                                   strLot_holdRecord_EffectSPCCheckResult_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSPCCheckResult__101() != RC_OK", rc);
        strCollectedDataActionByPostProcReqResult.strResult = strLot_holdRecord_EffectSPCCheckResult_out.strResult;
        return rc;
    }
//DSIV00001021 add end

    CORBA::Long nSPCLotHoldEffectListLen = 0;
    nSPCLotHoldEffectListLen = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList.length();
    if ( nSPCLotHoldEffectListLen  > 0 )
    {
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList.length()", nSPCLotHoldEffectListLen);

        pptHoldLotReqResult strHoldLotReqResult;

        pptHoldListSequence strLotHoldReqList;
        strLotHoldReqList.length( 1 );

        for( i = 0; i< nSPCLotHoldEffectListLen; i++ )
        {
            strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].holdType;
            strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].reasonCodeID;
            strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].userID;
            strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].responsibleOperationMark;
            strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].routeID;
            strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].operationNumber;
            strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].relatedLotID;
            strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].claimMemo;

            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].lotID , strLotHoldReqList );
            if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
                strCollectedDataActionByPostProcReqResult.strResult = strHoldLotReqResult.strResult;
                return( rc );
            }
        }
    }

    CORBA::Long nSPCFutureHoldEffectLen = 0;
    nSPCFutureHoldEffectLen = strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList.length();
    if ( nSPCFutureHoldEffectLen  > 0 )
    {
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList.length()", nSPCFutureHoldEffectLen);

        for( i=0; i< nSPCFutureHoldEffectLen; i++ )
        {
            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult, strObjCommonIn ,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].holdType ,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].lotID,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].routeID,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].operationNumber,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
                                          TRUE,
                                          TRUE,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].claimMemo );
            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
            {
                PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY");
                strCollectedDataActionByPostProcReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
                return( rc );
            }
        }
    }

//DSIV00000214 add start
    pptInterFabMonitorGroupActionInfoSequence tmpInterFabMonitorGroupActionInfoSequence;
    tmpInterFabMonitorGroupActionInfoSequence = strLot_holdRecord_EffectSPCCheckResult_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00000214 add end

    //---------------------------------------------------------------//
    //   Cut Monitor Relation for ProcessMonitorLot and ProcessLot   //
    //---------------------------------------------------------------//
    nCastLen = 0;                          // Initialize for recycling.
    nCastLen = tmpStartCassette.length();
    CORBA::Long holdReleasedLotCount = 0;
    objectIdentifierSequence holdReleasedLotIDs;

    objectIdentifier monitorLotID;
    for ( i=0; i < nCastLen; i++ )
    {
        nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
        for ( j=0; j < nLotCastLen; j++ )
        {
            //---------------------------//
            //   Omit Not-OpeStart Lot   //
            //---------------------------//
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            //-----------------------------//
            //   Delete Monitor Grouping   //
            //-----------------------------//
//DSIV00000214            objMonitorGroup_DeleteComp_out  strMonitorGroup_DeleteComp_out;
//DSIV00000214            rc = monitorGroup_DeleteComp( strMonitorGroup_DeleteComp_out, strObjCommonIn,
//DSIV00000214                                          tmpStartCassette[i].strLotInCassette[j].lotID);
//DSIV00000214            if ( rc != RC_OK )
//DSIV00000214            {
//DSIV00000214                PPT_METHODTRACE_V1("", "monitorGroup_DeleteComp() != RC_OK") ;
//DSIV00000214                strCollectedDataActionByPostProcReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult ;
//DSIV00000214                return( rc );
//DSIV00000214            }
//DSIV00000214 add start
            objMonitorGroup_DeleteComp_out__100 strMonitorGroup_DeleteComp_out;
            objMonitorGroup_DeleteComp_in__100  strMonitorGroup_DeleteComp_in;
            strMonitorGroup_DeleteComp_in.lotID = tmpStartCassette[i].strLotInCassette[j].lotID;
            strMonitorGroup_DeleteComp_in.strInterFabMonitorGroupActionInfoSequence = tmpInterFabMonitorGroupActionInfoSequence;
            rc = monitorGroup_DeleteComp__100( strMonitorGroup_DeleteComp_out, strObjCommonIn,
                                               strMonitorGroup_DeleteComp_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "monitorGroup_DeleteComp__100() != RC_OK", rc);
                strCollectedDataActionByPostProcReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult;
                return rc;
            }

            tmpInterFabMonitorGroupActionInfoSequence = strMonitorGroup_DeleteComp_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00000214 add end

            CORBA::Long nMonitorCompLotsLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length();

            if( nMonitorCompLotsLen != 0 )
            {
                // Preparing for HoldRelease.
                pptHoldLotReleaseReqResult strHoldLotReleaseReqResult;
                objectIdentifier aReasonCodeID;
                aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_WaitingMonitorHoldRelease );

                holdReleasedLotIDs.length(holdReleasedLotCount + nMonitorCompLotsLen);

                for( k = 0; k < nMonitorCompLotsLen; k++ )
                {
                    CORBA::Long nLotHoldLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].strLotHoldReleaseReqList.length();
                    if ( nLotHoldLen > 0 )
                    {
                        rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn,
                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID,
                                                  aReasonCodeID,
                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].strLotHoldReleaseReqList );
                        if( rc != RC_OK)
                        {
                            PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK");
                            strCollectedDataActionByPostProcReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                            return (rc);
                        }

                        //----------------------------------------
                        //Return Hold Released LotID for Caller
                        //----------------------------------------
                        holdReleasedLotIDs[holdReleasedLotCount] = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID;

                        PPT_METHODTRACE_V3("","Hold Released LotID", holdReleasedLotCount,  holdReleasedLotIDs[holdReleasedLotCount].identifier );
                        holdReleasedLotCount++;

                        //------------------------------------------
                        //  Check Lot Type of Monitoring Lot
                        //------------------------------------------
                        if( CIMFWStrCmp( SP_Lot_Type_ProductionLot, tmpStartCassette[i].strLotInCassette[j].lotType ) == 0 )
                        {
                            while( 1 )
                            {
                                //------------------------------------------
                                //  Check whether GatePass is required
                                //------------------------------------------
                                PPT_METHODTRACE_V2("", "===== repeatGatePass_CheckCondition() ========",tmpStartCassette[i].strLotInCassette[j].lotID.identifier);

                                objRepeatGatePass_CheckCondition_out  strRepeatGatePass_CheckCondition_out;
                                strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag = TRUE;
                                rc = repeatGatePass_CheckCondition( strRepeatGatePass_CheckCondition_out, strObjCommonIn,
                                                                    tmpStartCassette[i].strLotInCassette[j].lotID,
                                                                    strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID );
                                if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "repeatGatePass_CheckCondition() != RC_OK", rc);
                                    strCollectedDataActionByPostProcReqResult.strResult = strRepeatGatePass_CheckCondition_out.strResult;
                                    return( rc );
                                }
                                if( strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag == FALSE )
                                {
                                    PPT_METHODTRACE_V1("", "gatePassRequiredFlag == FALSE");
                                    break;  // break while loop.
                                }

                                //--------------------------------
                                //  Get Monitored Lot's Info
                                //--------------------------------
                                objLot_currentOperationInfo_Get_out  strLot_currentOperationInfo_Get_out;
                                rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn,
                                                                   strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID );
                                if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK", rc);
                                    strCollectedDataActionByPostProcReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
                                    return( rc );
                                }

                                //------------------------------------------
                                //  Call txGatePassReq
                                //------------------------------------------
                                pptGatePassReqResult        strGatePassReqResult;
                                CORBA::Long                 seqIndex = 0;
                                pptGatePassLotInfoSequence  strGatePassLotInfo;
                                objectIdentifierSequence    dummyLotIDs;            //for Return, but it's dummy.

                                strGatePassReqResult.strGatePassLotsResult.length( 1 );
                                strGatePassLotInfo.length( 1 );
                                strGatePassLotInfo[0].lotID                  = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID;
                                strGatePassLotInfo[0].currentRouteID         = strLot_currentOperationInfo_Get_out.routeID;
                                strGatePassLotInfo[0].currentOperationNumber = CIMFWStrDup( strLot_currentOperationInfo_Get_out.operationNumber );

                                rc = txGatePassReq( strGatePassReqResult,strObjCommonIn,
                                                    seqIndex, strGatePassLotInfo, claimMemo, dummyLotIDs );
                                if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "txGatePassReq() != RC_OK", rc);
                                    strCollectedDataActionByPostProcReqResult.strResult = strGatePassReqResult.strResult;
                                    return( rc );
                                }
                            } // while loop
                        }
                        else
                        {
                            // Lot Type is not SP_Lot_Type_ProductionLot.
                            continue;
                        }
                    } // Monitor Hold Released Lot List.
                } // MonitorCompLotsLen Loop
            } // MonitorCompLotsLen != 0
        } // Start Lot In Cassette Len
    } // Start Cassette Len

//DSIV00000214 add start
    //------------------------------------------------------------------------------------//
    //   MonitorGroupRelease, Hold and SpecOver/SPCViolation mail Request for other Fab   //
    //------------------------------------------------------------------------------------//
    CORBA::Long monRelLen = tmpInterFabMonitorGroupActionInfoSequence.length();
    PPT_METHODTRACE_V2("", "monitoringLots count", monRelLen);
    for( i=0; i<monRelLen; i++ )
    {
        PPT_METHODTRACE_V1("","monitorGroupRelease required flag for other fab is TRUE.");
        objMonitorGroupRelease_RequestForMultiFab_out strMonitorGroupRelease_RequestForMultiFab_out;
        objMonitorGroupRelease_RequestForMultiFab_in  strMonitorGroupRelease_RequestForMultiFab_in;
        strMonitorGroupRelease_RequestForMultiFab_in.strInterFabMonitorGroupActionInfo = tmpInterFabMonitorGroupActionInfoSequence[i];
        rc = monitorGroupRelease_RequestForMultiFab( strMonitorGroupRelease_RequestForMultiFab_out,
                                                     strObjCommonIn,
                                                     strMonitorGroupRelease_RequestForMultiFab_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "monitorGroupRelease_RequestForMultiFab() != RC_OK", rc);
            strCollectedDataActionByPostProcReqResult.strResult = strMonitorGroupRelease_RequestForMultiFab_out.strResult;
            return rc;
        }
    }
//DSIV00000214 add end

    // Resize HoldReleasedLotIDs length.
    holdReleasedLotIDs.length(holdReleasedLotCount);
    PPT_METHODTRACE_V2("","HoldReleased Lot Count is", holdReleasedLotCount );

    // Set HoldReleasedLots to return structure.
    strCollectedDataActionByPostProcReqResult.holdReleasedLotIDs = holdReleasedLotIDs;

    //----------------------------------------------------//
    //   Update PO's collected data information finally   //
    //----------------------------------------------------//
    PPT_METHODTRACE_V1("", "Update PO's collected data information finally.");
//DSIV00001021    objProcess_dataCollectionInformation_Update_out strProcess_dataCollectionInformation_Update_out;
//DSIV00001021    rc = process_dataCollectionInformation_Update( strProcess_dataCollectionInformation_Update_out, strObjCommonIn, tmpStartCassette );
//DSIV00001021    if ( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V1("", "process_dataCollectionInformation_Update() != RC_OK");
//DSIV00001021        strCollectedDataActionByPostProcReqResult.strResult = strProcess_dataCollectionInformation_Update_out.strResult;
//DSIV00001021        return( rc );
//DSIV00001021    }
//DSIV00001021 add start
    objProcess_dataCollectionInformation_Update_out__101 strProcess_dataCollectionInformation_Update_out;
    rc = process_dataCollectionInformation_Update__101( strProcess_dataCollectionInformation_Update_out, strObjCommonIn, tmpStartCassette, strLot_holdRecord_EffectSPCCheckResult_out.strDCActionLotResult );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_dataCollectionInformation_Update__101() != RC_OK");
        strCollectedDataActionByPostProcReqResult.strResult = strProcess_dataCollectionInformation_Update_out.strResult;
        return( rc );
    }
//DSIV00001021 add end

//INN-R170009 add start
    CORBA::String_var APCAvailable = CIMFWStrDup(getenv(SP_APC_Available));

    if (CIMFWStrCmp(APCAvailable, SP_CheckFlag_On) == 0 )
    {
        PPT_METHODTRACE_V1("", "if (CIMFWStrCmp(APCAvailable, SP_CheckFlag_On) == 0 )");

        csObjAPCMgr_SendLithoMetrologyInfoReq_out  strObjAPCMgr_SendLithoMetrologyInfoReq_out;
        csObjAPCMgr_SendLithoMetrologyInfoReq_in   strObjAPCMgr_SendLithoMetrologyInfoReq_in;
        strObjAPCMgr_SendLithoMetrologyInfoReq_in.equipmentID      = strCollectedDataActionByPostProcReqInParm.equipmentID;
        strObjAPCMgr_SendLithoMetrologyInfoReq_in.strStartCassette = tmpStartCassette;
        rc = cs_APCMgr_SendLithoMetrologyInfoReq( strObjAPCMgr_SendLithoMetrologyInfoReq_out,
                                                  strObjCommonIn,
                                                  strObjAPCMgr_SendLithoMetrologyInfoReq_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_APCMgr_SendLithoMetrologyInfoReq() != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strObjAPCMgr_SendLithoMetrologyInfoReq_out.strResult;
            return ( rc );
        }
    }
//INN-R170009 add end

    //---------------------------------------------------------------//
    //   New Action by SPC Check result                              //
    //---------------------------------------------------------------//
    pptSpcActionExecuteReqResult strSpcActionExecuteReqResult;
    rc = txSpcActionExecuteReq( strSpcActionExecuteReqResult, strObjCommonIn,
                                strStartLot_actionList_EffectSPCCheck_out.strBankMoveList,
                                strStartLot_actionList_EffectSPCCheck_out.strMailSendList,
                                strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList,
                                claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txSpcActionExecuteReq() != RC_OK");
        strCollectedDataActionByPostProcReqResult.strResult = strSpcActionExecuteReqResult.strResult;
        return(rc);
    }

    //----------------------------------------------------------------------------
    // Post-Processing Registration for Hold Released Lot IDs (Monitored Lots)
    //----------------------------------------------------------------------------
    pptPostProcessActionRegistReqResult__100 strPostProcessActionRegistReqResult;
    CORBA::Long    holdReleasedLotLen;
    holdReleasedLotLen = holdReleasedLotIDs.length();

    if ( holdReleasedLotLen != 0 )
    {
        PPT_METHODTRACE_V2("", "Registration of Post-Processng for HoldReleasedLot", holdReleasedLotLen);

        //HoldReleased LotID Trace
        for ( i = 0; i < holdReleasedLotLen; i++ )
        {
            PPT_METHODTRACE_V2("", "HoldRelesedLotIDs", holdReleasedLotIDs[i].identifier);
        }

        //Set input parameter
        CORBA::String_var txID_HoldReleasedLot    = CIMFWStrDup("");
        pptPostProcessRegistrationParm strPostProcessRegistrationParm;
        strPostProcessRegistrationParm.equipmentID  = strCollectedDataActionByPostProcReqInParm.equipmentID;
        strPostProcessRegistrationParm.controlJobID = strCollectedDataActionByPostProcReqInParm.controlJobID;
        strPostProcessRegistrationParm.lotIDs       = holdReleasedLotIDs;

        PPT_METHODTRACE_V2("", "OpeCompedLot   : TXID ", strObjCommonIn.transactionID);
        //Set TXID for Hold Released Lot
        // TXTRC004 is TxOpeCompWithDataReq.
        // TXTRC055 is TxOpeCompForInternalBufferReq.
        // TXEWC015 is TxPartialOpeCompWithDataReq.
        // TXEWC016 is TxPartialOpeCompForInternalBufferReq.
        // TXEWC010 is TxForceOpeCompReq.
        // TXEWC011 is TxForceOpeCompForInternalBufferReq.
//DSN000015229        if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRC004") == 0 )
        if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRC004") == 0 )       //PSN000049719
//PSN000049719        if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRC004") == 0         //DSN000015229
//PSN000049719         || CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC015") == 0 )       //DSN000015229
        {
            txID_HoldReleasedLot = CIMFWStrDup("ThTRC_04");
        }
//DSN000015229        else if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRC055") == 0 )
        else if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRC055") == 0 )      //PSN000049719
//PSN000049719        else if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRC055") == 0    //DSN000015229
//PSN000049719              || CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC016") == 0 )  //DSN000015229
        {
            txID_HoldReleasedLot = CIMFWStrDup("ThTRC_55");
        }
        else if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC010") == 0 )
        {
            txID_HoldReleasedLot = CIMFWStrDup("ThEWC_10");
        }
        else if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC011") == 0 )
        {
            txID_HoldReleasedLot = CIMFWStrDup("ThEWC_11");
        }
//PSN000049719 Add Start
        else if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC015") == 0 )
        {
            txID_HoldReleasedLot = CIMFWStrDup("ThEWC_15");
        }
        else if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC016") == 0 )
        {
            txID_HoldReleasedLot = CIMFWStrDup("ThEWC_16");
        }
//PSN000049719 Add End
        else
        {
            PPT_SET_MSG_RC_KEY(strCollectedDataActionByPostProcReqResult,
                               MSG_CALLED_FROM_INVALID_TRANSACTION,
                               RC_CALLED_FROM_INVALID_TRANSACTION,
                               strObjCommonIn.transactionID);
            return( RC_CALLED_FROM_INVALID_TRANSACTION );
        }
        PPT_METHODTRACE_V2("", "HoldReleasedLot: TXID ", txID_HoldReleasedLot);

        //Post-Processing Registration for Released Lot
        rc = txPostProcessActionRegistReq__100( strPostProcessActionRegistReqResult,
                                                strObjCommonIn,
                                                txID_HoldReleasedLot,            //TXID
                                                NULL,                            //patternID
                                                NULL,                            //dKey
                                                -1,                              //seqNo
                                                strPostProcessRegistrationParm,
                                                claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "Registration of Post Process for HoldReleasedLot:rc != RC_OK");
            strCollectedDataActionByPostProcReqResult.strResult = strPostProcessActionRegistReqResult.strResult;
            return(rc);
        }
        strCollectedDataActionByPostProcReqResult.RelatedQueuekey = CIMFWStrDup( strPostProcessActionRegistReqResult.dKey );
        PPT_METHODTRACE_V2("", "HoldReleasedLot: dKey ",strCollectedDataActionByPostProcReqResult.RelatedQueuekey);
    }

    //--------------------------//
    //                          //
    //   Set Return Structure   //
    //                          //
    //--------------------------//
//DSIV00001021    objEquipment_FillInTxTRC004_out   strEquipment_FillInTxTRC004_out;
//DSIV00001021    rc = equipment_FillInTxTRC004( strEquipment_FillInTxTRC004_out, strObjCommonIn, tmpStartCassette, strSpcCheckReqResult.strSpcCheckLot);
//DSIV00001021    if ( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V1("", "equipment_FillInTxTRC004() != RC_OK") ;
//DSIV00001021        strCollectedDataActionByPostProcReqResult.strResult = strEquipment_FillInTxTRC004_out.strResult ;
//DSIV00001021        return(rc);
//DSIV00001021    }
//DSIV00001021 add start
    objEquipment_FillInTxTRC004_out__101   strEquipment_FillInTxTRC004_out;
    rc = equipment_FillInTxTRC004__101( strEquipment_FillInTxTRC004_out, strObjCommonIn, tmpStartCassette, strSpcCheckReqResult.strSpcCheckLot);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_FillInTxTRC004__101() != RC_OK");
        strCollectedDataActionByPostProcReqResult.strResult = strEquipment_FillInTxTRC004_out.strResult;
        return(rc);
    }
//DSIV00001021 add end
//DSN000081739 Add Start
    CORBA::Long eqpMonitorSwitch = atoi( getenv(SP_EQPMONITOR_SWITCH) );
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        for ( CORBA::ULong iCnt=0; iCnt<strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot.length(); iCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot.length()", iCnt);
            objLot_lotType_Get_out strLot_lotType_Get_out;
            objLot_lotType_Get_in  strLot_lotType_Get_in;
            strLot_lotType_Get_in.lotID = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].lotID;
            rc = lot_lotType_Get( strLot_lotType_Get_out,
                                  strObjCommonIn,
                                  strLot_lotType_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
                strCollectedDataActionByPostProcReqResult.strResult = strLot_lotType_Get_out.strResult;
                return rc;
            }

            if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
              || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot) )
            {
                PPT_METHODTRACE_V1("", "strLot_lotType_Get_out.lotType is Equipment Monitor or Dummy");
                if ( (0 != CIMFWStrCmp(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].specCheckResult, SP_SpecCheckResult_OK)
                  && 0 < CIMFWStrLen(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].specCheckResult)
                  && 0 != CIMFWStrCmp(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].specCheckResult, SP_SpecCheckResult_1Asterisk))
                  || 0 == CIMFWStrCmp(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].spcCheckResult, SP_SPCCheck_HoldLimitOff)
                  || 0 == CIMFWStrCmp(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].spcCheckResult, SP_SPCCheck_WarningLimitOff) )
                {
                    PPT_METHODTRACE_V1("", "Call eqpMonitorJob_lot_Update");
                    //Update information of EqpMonitor job lot
                    objEqpMonitorJob_lot_Update_out strEqpMonitorJob_lot_Update_out;
                    objEqpMonitorJob_lot_Update_in  strEqpMonitorJob_lot_Update_in;
                    strEqpMonitorJob_lot_Update_in.lotID     = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].lotID;
                    strEqpMonitorJob_lot_Update_in.operation = CIMFWStrDup(SP_EqpMonitorJob_OpeCategory_SpecCheck);
                    rc = eqpMonitorJob_lot_Update( strEqpMonitorJob_lot_Update_out,
                                                   strObjCommonIn,
                                                   strEqpMonitorJob_lot_Update_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "eqpMonitorJob_lot_Update() != RC_OK", rc);
                        strCollectedDataActionByPostProcReqResult.strResult = strEqpMonitorJob_lot_Update_out.strResult;
                        return rc;
                    }
                }
            }
        }
    }
//DSN000081739 Add End
    strCollectedDataActionByPostProcReqResult.strOpeCompWithDataReqResult = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult;

    //------------------
    // Return to Main
    //------------------
    SET_MSG_RC(strCollectedDataActionByPostProcReqResult, MSG_OK, RC_OK);
//INN-R170009    PPT_METHODTRACE_EXIT("PPTManager_i::txCollectedDataActionByPostProcReq");
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txCollectedDataActionByPostProcReq"); //INN-R170009
    return( RC_OK );
}


void DebugOutStartCassette(pptDataSpecCheckReqResult& tg)   //P3100372 add
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txCollectedDataActionByPostProcReq::DebugOutStartCassette "); //D4100092
    PPT_METHODTRACE_V1("", "P3100372 log start ******************************************");
    CORBA::Long ii, jj, kk, ll, mm;
    CORBA::Long len1, len2, len3, len4, len5;
    len1 = tg.strStartCassette.length();
    PPT_METHODTRACE_V2("", "tg.strStartCassette.length**********>", len1);
    for ( ii = 0; ii < len1; ii++ )
    {
        PPT_METHODTRACE_V2("", "loadSequenceNumber------------------------", tg.strStartCassette[ii].loadSequenceNumber);
        PPT_METHODTRACE_V2("", "cassetteID--------------------------------", tg.strStartCassette[ii].cassetteID.identifier);
        PPT_METHODTRACE_V2("", "loadPurposeType---------------------------", tg.strStartCassette[ii].loadPurposeType);
        PPT_METHODTRACE_V2("", "loadPortID--------------------------------", tg.strStartCassette[ii].loadPortID.identifier);
        PPT_METHODTRACE_V2("", "unloadPortID------------------------------", tg.strStartCassette[ii].unloadPortID.identifier);

        len2 = tg.strStartCassette[ii].strLotInCassette.length();
        PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette.length**********>", len2);
        for ( jj = 0; jj < len2; jj++ )
        {
            PPT_METHODTRACE_V2("", "  operationStartFlag----------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].operationStartFlag); //D9000001
            PPT_METHODTRACE_V2("", "  monitorLotFlag--------------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].monitorLotFlag); //D9000001
            PPT_METHODTRACE_V2("", "  lotID-----------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].lotID.identifier);
            PPT_METHODTRACE_V2("", "  lotType---------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].lotType);
            PPT_METHODTRACE_V2("", "  subLotType------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].subLotType);
            PPT_METHODTRACE_V2("", "    logicalRecipeID-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.logicalRecipeID.identifier);
            PPT_METHODTRACE_V2("", "    machineRecipeID-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.machineRecipeID.identifier);
            PPT_METHODTRACE_V2("", "    physicalRecipeID----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.physicalRecipeID);

            len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle.length();
            PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle.length**********>", len3);
            for ( kk = 0; kk < len3; kk++ )
            {
                PPT_METHODTRACE_V2("", "      sequenceNumber----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle[kk].sequenceNumber);
                PPT_METHODTRACE_V2("", "      reticleID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle[kk].reticleID.identifier);
            }
            len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture.length();
            PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture.length**********>", len3);
            for ( kk = 0; kk < len3; kk++ )
            {
                PPT_METHODTRACE_V2("", "      fixtureID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture[kk].fixtureID.identifier);
                PPT_METHODTRACE_V2("", "      fixtureCategory---------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture[kk].fixtureCategory);
                PPT_METHODTRACE_V2("", "    dataCollectionFlag--------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.dataCollectionFlag); //D9000001
            }
            len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef.length();
            PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef.length**********>", len3);
            for ( kk = 0; kk < len3; kk++ )
            {
                PPT_METHODTRACE_V2("", "      dataCollectionDefinitionID----------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionDefinitionID.identifier);
                PPT_METHODTRACE_V2("", "      description-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].description);
                PPT_METHODTRACE_V2("", "      dataCollectionType------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionType);

                len4 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem.length();
                PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem.length**********>", len4);
                for ( ll = 0; ll < len4; ll++ )
                {
                    PPT_METHODTRACE_V2("", "        dataCollectionItemName------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionItemName);
                    PPT_METHODTRACE_V2("", "        dataCollectionMode----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionMode);
                    PPT_METHODTRACE_V2("", "        dataCollectionUnit----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionUnit);
                    PPT_METHODTRACE_V2("", "        dataType--------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataType);
                    PPT_METHODTRACE_V2("", "        itemType--------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].itemType);
                    PPT_METHODTRACE_V2("", "        measurementType-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].measurementType);
                    PPT_METHODTRACE_V2("", "        waferID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].waferID.identifier);
                    PPT_METHODTRACE_V2("", "        waferPosition---------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].waferPosition);
                    PPT_METHODTRACE_V2("", "        sitePosition----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].sitePosition);
                    PPT_METHODTRACE_V2("", "        historyRequiredFlag---------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].historyRequiredFlag); //D9000001
                    PPT_METHODTRACE_V2("", "        calculationType-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].calculationType);
                    PPT_METHODTRACE_V2("", "        calculationExpression-------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].calculationExpression);
                    PPT_METHODTRACE_V2("", "        dataValue-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataValue);
                    PPT_METHODTRACE_V2("", "        targetValue-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].targetValue);
                    PPT_METHODTRACE_V2("", "        specCheckResult-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].specCheckResult);
                }
                PPT_METHODTRACE_V2("", "      calculationRequiredFlag-------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].calculationRequiredFlag); //D9000001
                PPT_METHODTRACE_V2("", "      specCheckRequiredFlag---------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].specCheckRequiredFlag); //D9000001
                PPT_METHODTRACE_V2("", "      dataCollectionSpecificationID-------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionSpecificationID.identifier);
                PPT_METHODTRACE_V2("", "      previousDataCollectionDefinitionID--", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousDataCollectionDefinitionID.identifier);
                PPT_METHODTRACE_V2("", "      previousOperationID-----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousOperationID.identifier);
                PPT_METHODTRACE_V2("", "      previousOperationNumber-------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousOperationNumber);
                PPT_METHODTRACE_V2("", "  recipeParameterChangeType---------------", tg.strStartCassette[ii].strLotInCassette[jj].recipeParameterChangeType);
            }
            len3 = tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer.length();
            PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer.length**********>", len3);
            for ( kk = 0; kk < len3; kk++ )
            {
                PPT_METHODTRACE_V2("", "    waferID-------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].waferID.identifier);
                PPT_METHODTRACE_V2("", "    slotNumber----------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].slotNumber);
                PPT_METHODTRACE_V2("", "    controlWaferFlag----------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].controlWaferFlag); //D9000001

                len4 = tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter.length();
                PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter.length**********>", len4);
                for ( ll = 0; ll < len4; ll++ )
                {
                    PPT_METHODTRACE_V2("", "      parameterName-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].parameterName);
                    PPT_METHODTRACE_V2("", "      parameterValue----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].parameterValue);
                    PPT_METHODTRACE_V2("", "      targetValue-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].targetValue);
                    PPT_METHODTRACE_V2("", "      useCurrentSettingValueFlag----------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].useCurrentSettingValueFlag); //D9000001
                }
            }
            PPT_METHODTRACE_V2("", "  productID-------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].productID.identifier);
        }
    }
    PPT_METHODTRACE_V1("", "P3100372 log end ******************************************");
}
