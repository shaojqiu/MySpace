#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/txmethods/txWaferSorterOnEqpCancelReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/9/07 19:08:48 [ 8/9/07 19:08:49 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView Standard
// Name:txWaferSorterOnEqpCancelReq.cpp
//

//INN-R170017 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-R170017

// PPT Service Manager - Transaction Method Design
//
//
// Subsystem Name      : PPT Service Manager
// TX Method ID        : TXTRC063
// TX Method Name      : txWaferSorterOnEqpCancelReq
// Process Description : send WaferSort CancelRequest to TCS
//
// TX Generates Return Code and Message :
//
// Return Code                             Message
// --------------------------------------- ---------------------------------------
//
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2001/07/31  D4000056  Y.Yoshihara    Initial Release
// 2001/08/08  D4000056  Y.Yoshihara    Change IDL
// 2001/08/21  P4000099  Y.Yoshihara    Change Method Name and add tx combination check
// 2001/08/23  D4000056  Y.Yoshihara    Change parameter of waferSorter_slotMap_SelectDR
// 2002/03/29  P4100299  H.Adachi       Fix Coding Miss
// 2002/08/12  P4200105  H.Adachi       Fix MM Server CORE Dump
// 2002/12/13  P4200451  H.Adachi       Fix USTKR.
// 2004/10/22  D6000025  K.Murakami     eBroker Migration.
// 2007/08/03  D9000056  H.Hotta        Add check logic for InPostProcessFlag.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/07 DSIV00000214 K.Kido         Mulit Fab Support.
// 2012/12/04 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
// 2013/06/19 PSN000078594 W.Zhang        add retry for TCSMgr_SendWaferSortOnEqpCancelReq
//
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/26 INN-R170017  Evie Su        BWS Management
//
//===========================================================
//
//        Private Method : txWaferSorterOnEqpCancelReq
//
//===========================================================
//INN-R170017 CORBA::Long PPTManager_i::txWaferSorterOnEqpCancelReq (
CORBA::Long CS_PPTManager_i::txWaferSorterOnEqpCancelReq ( //INN-R170017
    pptWaferSorterOnEqpCancelReqResult&  strWaferSorterOnEqpCancelReqResult,
    const pptObjCommonIn&                strObjCommonIn,
    const pptUser&                       requestUserID,
    const objectIdentifier&              equipmentID,
    const char *                         portGroup,
    const char *                         requestTimeStamp,
//D6000025     const char *                         claimMemo,
//D6000025     CORBA::Environment &                 IT_env)
    const char *                         claimMemo //D6000025
    CORBAENV_LAST_CPP)                             //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txWaferSorterOnEqpCancelReq") ;

    PPT_METHODTRACE_V2("", "in para equipmentID ",equipmentID.identifier );
    PPT_METHODTRACE_V2("", "in para portGroupID", portGroup);
    PPT_METHODTRACE_V2("", "in para requestTimeStamp", requestTimeStamp);
    PPT_METHODTRACE_V2("", "in para userID",      strObjCommonIn.strUser.userID.identifier);

    //--------------
    // Initialize
    //--------------
    CORBA::Long rc = RC_OK;

    //P4000099 Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strWaferSorterOnEqpCancelReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //P4000099 End

//DSN000049350 Add Start
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

    CORBA::Long sorterJobLockFlag = atoi( getenv(SP_SORTERJOB_LOCK_FLAG) );
    PPT_METHODTRACE_V2("","sorterJobLockFlag", sorterJobLockFlag);
    CORBA::Long lockMode = SP_EQP_LOCK_MODE_WRITE;

    if ( 1 == sorterJobLockFlag )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

        // Get required equipment lock mode
        strObject_lockMode_Get_in.objectID           = equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( SP_FunctionCategory_SorterTxID ); // SorterTxID
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strWaferSorterOnEqpCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }
        lockMode = strObject_lockMode_Get_out.lockMode;
    }
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
//DSN000049350 Add End

    // ================================================================
    // Checking Previous Job is running or not
    // ================================================================
    pptWaferSorterSlotMap               strWaferSorterSlotMap;

    //------------------------------------------------------
    //   Setting Search Condition Value
    //   Condition
    //   sorterStatus = "Resuested"
    //   direction    = "MM"
    //   This condition means Sort request was submitted,
    //   but TCS Responce is not received
    //------------------------------------------------------
    strWaferSorterSlotMap.equipmentID      = equipmentID;
    strWaferSorterSlotMap.portGroup        = CIMFWStrDup(portGroup);
    strWaferSorterSlotMap.requestTime      = CIMFWStrDup(requestTimeStamp);
    strWaferSorterSlotMap.sorterStatus     = CIMFWStrDup(SP_Sorter_Requested);
    strWaferSorterSlotMap.direction        = CIMFWStrDup(SP_Sorter_Direction_MM);

    //------------------------------------------------------
    //   Setting Not Search Condition Value
    //------------------------------------------------------
    strWaferSorterSlotMap.destinationSlotNumber               = 0; // To be Ignored
    strWaferSorterSlotMap.originalSlotNumber                  = 0; // To be Ignored
    strWaferSorterSlotMap.bDestinationCassetteManagedBySiView = FALSE;    //P4200451
    strWaferSorterSlotMap.bOriginalCassetteManagedBySiView    = FALSE;    //P4200451

    //------------------------------------------------------
    //   Search From Flotmap DB
    //------------------------------------------------------
    objWaferSorter_slotMap_SelectDR_out    strWaferSorter_slotMap_SelectDR_out;
    rc = waferSorter_slotMap_SelectDR(strWaferSorter_slotMap_SelectDR_out ,
                                      strObjCommonIn,
                                      SP_Sorter_SlotMap_AllData,
                                      "",
                                      SP_Sorter_Ignore_SiViewFlag,  // D4000056
                                      SP_Sorter_Ignore_SiViewFlag,  // D4000056
                                      strWaferSorterSlotMap );

    //------------------------------------------------------
    // When Error Occures.
    //------------------------------------------------------
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","waferSorter_slotMap_SelectDR() returned error");
        strWaferSorterOnEqpCancelReqResult.strResult = strWaferSorter_slotMap_SelectDR_out.strResult ;
        return(rc);
    }

    //------------------------------------------------------------
    // Check output parameter of sorter_waferTransferInfo_Restructure()
    //------------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txWaferSorterOnEqpCancelReq",
                          "Check output parameter of waferSorter_GetSlotMapDR()");

    CORBA::Long nOutputLotLen = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();
    //------------------------------------------------------------
    // If Current running Job is not existed
    // then return
    //------------------------------------------------------------
    if ( nOutputLotLen == 0 )
    {
        PPT_METHODTRACE_V3("","There's no running Jobs on Eqp:PortGroup",equipmentID.identifier,portGroup);
        strWaferSorterOnEqpCancelReqResult.strResult = strWaferSorter_slotMap_SelectDR_out.strResult ;
        return(RC_NOT_FOUND_SCRAP);
    }

//D9000056 add start
    objectIdentifierSequence tmpCassetteIDs;
    booleanSequence          tmpCassetteManagedBySiViewSeq;
    CORBA::Long nCastLen = 0;
    CORBA::Long nSlotMapLen = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();
    CORBA::Boolean autoSorterJobFlag = FALSE; //DSN000049350

    for( CORBA::Long i = 0; i < nSlotMapLen; i++ )
    {
        CORBA::Long bExist = FALSE;

        //-----------------------------------
        //  Get all destinationCassetteID
        //-----------------------------------
//DSN000049350 Add Start
        if ( 0 == i && 0 == CIMFWStrCmp( strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].actionCode, SP_Sorter_AutoSorting ) )
        {
            PPT_METHODTRACE_V1("","i = 0 and actionCode = SP_Sorter_AutoSorting");
            autoSorterJobFlag = TRUE;
        }
//DSN000049350 Add End
        if( 0 != CIMFWStrLen( strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier ) )
        {
            bExist = FALSE;
            nCastLen = tmpCassetteIDs.length();

            for( CORBA::Long j = 0; j < nCastLen; j++ )
            {
                if( 0 == CIMFWStrCmp( tmpCassetteIDs[j].identifier,
                                      strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "destinationCassetteID bExist == TRUE");
                    bExist = TRUE;
                    break;
                }
            }

            if( FALSE == bExist )
            {
                PPT_METHODTRACE_V1("", "destinationCassetteID bExist == FALSE");
                tmpCassetteIDs.length( nCastLen + 1 );
                tmpCassetteIDs[nCastLen] = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationCassetteID;
                tmpCassetteManagedBySiViewSeq.length( nCastLen + 1 );
                tmpCassetteManagedBySiViewSeq[nCastLen] = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView;
                nCastLen++;
            }
        }

        //-----------------------------------
        //  Get all originalCassetteID
        //-----------------------------------
        if( 0 != CIMFWStrLen( strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].originalCassetteID.identifier) )
        {
            bExist = FALSE;
            nCastLen = tmpCassetteIDs.length();

            for( CORBA::Long j = 0; j < nCastLen; j++ )
            {
                if( 0 == CIMFWStrCmp( tmpCassetteIDs[j].identifier,
                                      strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].originalCassetteID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "originalCassetteID bExist == TRUE");
                    bExist = TRUE;
                    break;
                }
            }

            if( FALSE == bExist )
            {
                tmpCassetteIDs.length( nCastLen + 1 );
                tmpCassetteIDs[nCastLen] = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].originalCassetteID;
                tmpCassetteManagedBySiViewSeq.length( nCastLen + 1 );
                tmpCassetteManagedBySiViewSeq[nCastLen] = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView;
                nCastLen++;
            }
        }
    }

    //-----------------------------
    //  Check InPostProcessFlag
    //-----------------------------
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    nCastLen = tmpCassetteIDs.length();

    stringSequence loadCastSeq;    //DSN000049350
    CORBA::ULong loadCastCnt = 0;  //DSN000049350
    loadCastSeq.length(nCastLen);  //DSN000049350
    for( i = 0; i < nCastLen; i++ )
    {
        if( TRUE == tmpCassetteManagedBySiViewSeq[i] )
        {
            loadCastSeq[loadCastCnt++] = tmpCassetteIDs[i].identifier; //DSN000049350

            //---------------------------------------
            //  Get InPostProcessFlag of Cassette
            //---------------------------------------
            objCassette_inPostProcessFlag_Get_out strCassette_inPostProcessFlag_Get_out;
            objCassette_inPostProcessFlag_Get_in  strCassette_inPostProcessFlag_Get_in;
            strCassette_inPostProcessFlag_Get_in.cassetteID = tmpCassetteIDs[i];

            rc = cassette_inPostProcessFlag_Get( strCassette_inPostProcessFlag_Get_out,
                                                 strObjCommonIn,
                                                 strCassette_inPostProcessFlag_Get_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_inPostProcessFlag_Get() != RC_OK");
                strWaferSorterOnEqpCancelReqResult.strResult = strCassette_inPostProcessFlag_Get_out.strResult;
                return( rc );
            }

            //---------------------------------------------------
            //  If Cassette is in post process, returns error
            //---------------------------------------------------
            if( TRUE == strCassette_inPostProcessFlag_Get_out.inPostProcessFlagOfCassette )
            {
                PPT_METHODTRACE_V1("", "Cassette is in post process.");
                PPT_SET_MSG_RC_KEY( strWaferSorterOnEqpCancelReqResult,
                                    MSG_CAST_INPOSTPROCESS, RC_CAST_INPOSTPROCESS,
                                    tmpCassetteIDs[i].identifier );
                return( RC_CAST_INPOSTPROCESS );
            }

//DSIV00000214 add start
            //-------------------------------------------------------
            // Check cassette InterFabXfer State
            //-------------------------------------------------------
            objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
            objCassette_interFabXferState_Get_in  strCassette_interFabXferState_Get_in;
            strCassette_interFabXferState_Get_in.cassetteID = tmpCassetteIDs[i] ;
            rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out,
                                                 strObjCommonIn,
                                                 strCassette_interFabXferState_Get_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_interFabXferState_Get() != RC_OK", rc);
                strWaferSorterOnEqpCancelReqResult.strResult = strCassette_interFabXferState_Get_out.strResult;
                return( rc );
            }

            if( 0 == CIMFWStrCmp( strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) )
            {
                PPT_METHODTRACE_V1("", "return RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ");
                PPT_SET_MSG_RC_KEY2( strWaferSorterOnEqpCancelReqResult,
                                     MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                     RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                     tmpCassetteIDs[i].identifier,
                                     strCassette_interFabXferState_Get_out.interFabXferState );
                return RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ;
            }
//DSIV00000214 add end
        }
    }
//D9000056 add end
    loadCastSeq.length(loadCastCnt);                      //DSN000049350
    PPT_METHODTRACE_V2( "", "loadCastCnt", loadCastCnt);  //DSN000049350

//DSN000049350 Add Start
    if ( 1 == sorterJobLockFlag && 0 < loadCastSeq.length() && TRUE == autoSorterJobFlag )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

        //---------------------------------
        // Lock Sort Jobs
        //---------------------------------
        objectIdentifier dummyID;
        objectIdentifier loadCassetteID;
        loadCassetteID.identifier = loadCastSeq[0];
        objSorter_sorterJob_LockDR_out strSorter_sorterJob_LockDR_out;
        objSorter_sorterJob_LockDR_in strSorter_sorterJob_LockDR_in;
        strSorter_sorterJob_LockDR_in.sorterJobID          = dummyID;
        strSorter_sorterJob_LockDR_in.sorterComponentJobID = dummyID;
        strSorter_sorterJob_LockDR_in.cassetteID           = loadCassetteID;
        strSorter_sorterJob_LockDR_in.lockType             = SP_ObjectLock_LockType_WRITE;

        PPT_METHODTRACE_V1( "", "calling sorter_sorterJob_LockDR()" );
        rc = sorter_sorterJob_LockDR ( strSorter_sorterJob_LockDR_out,
                                       strObjCommonIn,
                                       strSorter_sorterJob_LockDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "sorter_sorterJob_LockDR() != RC_OK", rc);
            strWaferSorterOnEqpCancelReqResult.strResult = strSorter_sorterJob_LockDR_out.strResult;
            return( rc );
        }
    }

    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strWaferSorterOnEqpCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }

        if (loadCastSeq.length() > 0)
        {
            PPT_METHODTRACE_V2("", "loadCastSeq.lengthloadCastSeq.length > 0", loadCastSeq.length());

            // Lock Equipment LoadCassette Element (Read)
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_READ;
            strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strWaferSorterOnEqpCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
    }
//DSN000049350 Add End

//DSIV00000214 add start
    //-------------------------------------------------------
    // Check InterFabXfer State of Lot
    //-------------------------------------------------------

    // Make LotID unique sequence
    PPT_METHODTRACE_V1("", "Make LotID unique sequence");
    objectIdentifierSequence tmpLotIDs;
    tmpLotIDs.length( nSlotMapLen );
    CORBA::Long nLotCnt = 0;

    for ( i=0; i < nSlotMapLen; i++ )
    {
        const pptWaferSorterSlotMap& slotMap = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i];

        if ( 0 == CIMFWStrLen(slotMap.lotID.identifier) )
        {
            continue; //[i]
        }

        CORBA::Boolean bAlreadySet = FALSE;
        for ( CORBA::Long nLot=0; nLot < nLotCnt; nLot++ )
        {
            if ( 0 == CIMFWStrCmp(slotMap.lotID.identifier, tmpLotIDs[nLot].identifier) )
            {
                bAlreadySet = TRUE;
                break; //[nLot]
            }
        } //[nLot]
        if ( bAlreadySet )
        {
            continue; //[i]
        }

        PPT_METHODTRACE_V2("", "found LotID", slotMap.lotID.identifier);
        tmpLotIDs[nLotCnt] = slotMap.lotID;
        nLotCnt++;
    } //[i]

    PPT_METHODTRACE_V1("", "Check Lot's InterFabXferState");
    for ( CORBA::Long nLot=0; nLot < nLotCnt; nLot++ )
    {
        PPT_METHODTRACE_V2("", "call lot_interFabXferState_Get()", tmpLotIDs[nLot].identifier);
        objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;
        objLot_interFabXferState_Get_in strLot_interFabXferState_Get_in;
        strLot_interFabXferState_Get_in.lotID = tmpLotIDs[nLot];

        rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                        strObjCommonIn,
                                        strLot_interFabXferState_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### lot_interFabXferState_Get() != RC_OK", rc);
            strWaferSorterOnEqpCancelReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
            return( rc );
        }

        if ( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required)
          || 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring) )
        {
             PPT_METHODTRACE_V1("", "##### return RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ");
             PPT_SET_MSG_RC_KEY2( strWaferSorterOnEqpCancelReqResult,
                                  MSG_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                  RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                  tmpLotIDs[nLot].identifier,
                                  strLot_interFabXferState_Get_out.interFabXferState );
             return( RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ );
        }
    } //[nLot]
//DSIV00000214 add end

    // ================================================================
    // Sumbit request to TCS
    // ================================================================
    //PSN000078594 PPT_METHODTRACE_V1("","Try to TCSMgr_SendWaferSortOnEqpCancelReq");
    //PSN000078594 objTCSMgr_SendWaferSortOnEqpCancelReq_out strTCSMgr_SendWaferSortOnEqpCancelReq_out;
    //PSN000078594 rc = TCSMgr_SendWaferSortOnEqpCancelReq ( strTCSMgr_SendWaferSortOnEqpCancelReq_out,
    //PSN000078594                                     strObjCommonIn,
    //PSN000078594                                     requestUserID,
    //PSN000078594                                     equipmentID,
    //PSN000078594                                     portGroup,
    //PSN000078594                                     requestTimeStamp);
    //PSN000078594 add start
    CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0;
    CORBA::Long retryCountValue = 0;

    if (CIMFWStrLen(tmpSleepTimeValue) == 0)
    {
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        sleepTimeValue = atoi(tmpSleepTimeValue) ;
    }

    if (CIMFWStrLen(tmpRetryCountValue) == 0)
    {
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
    PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

    PPT_METHODTRACE_V1("","Try to TCSMgr_SendWaferSortOnEqpCancelReq");
    objTCSMgr_SendWaferSortOnEqpCancelReq_out strTCSMgr_SendWaferSortOnEqpCancelReq_out;

    //'retryCountValue + 1' means first try plus retry count
    for( CORBA::ULong retryNum = 0 ; retryNum < (retryCountValue + 1) ; retryNum++ )
    {
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        PPT_METHODTRACE_V1("", "call TCSMgr_SendWaferSortOnEqpCancelReq()");
        rc = TCSMgr_SendWaferSortOnEqpCancelReq ( strTCSMgr_SendWaferSortOnEqpCancelReq_out,
                                            strObjCommonIn,
                                            requestUserID,
                                            equipmentID,
                                            portGroup,
                                            requestTimeStamp);

        PPT_METHODTRACE_V2("","rc = ",rc);

        if(rc == RC_OK)
        {
            PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                  rc == RC_EXT_SERVER_NIL_OBJ   ||
                  rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",retryNum);
            PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            break;
        }
    }
    //PSN000078594 add end

    //------------------------------------------------------
    // When Error Occures.
    //------------------------------------------------------
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","TCSMgr_SendWaferSortOnEqpCancelReq() returned error");
        // Temporary
        if ( rc != RC_NOT_FOUND_TCS )
        {
            strWaferSorterOnEqpCancelReqResult.strResult = strTCSMgr_SendWaferSortOnEqpCancelReq_out.strResult ;
            return(rc);
        }
        else
        {
            PPT_METHODTRACE_V1("","Continue ");
        }
    }

    //========================================================
    // Delete Slotmap information of requested data
    //========================================================
    // same Eqp/PortGroup/requestTimeStamp/
    //      SP_Sorter_Requested/SP_Sorter_Direction_MM
    //--------------------------------------------------------
    objectIdentifierSequence   cassetteIDs;

    //--------------------------------------------------------------------------
    // Does not need cassetteIDs.
    // Because record in DB will be deleted by EQP, Port Group and Request Time.
    //--------------------------------------------------------------------------
    cassetteIDs.length(0);                        //P4200105

//P4200105    cassetteIDs.length(nOutputLotLen);
//P4200105    CORBA::Long  cnt=1;
//P4200105    cassetteIDs[0].identifier = CIMFWStrDup(strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[0].destinationCassetteID.identifier);
//P4200105    for ( CORBA::Long i=1;i<nOutputLotLen;++i )
//P4200105    {
//P4200105        for( CORBA::Long  j=0; j < cnt; ++j )
//P4200105        {
//P4200105            if( CIMFWStrCmp(cassetteIDs[j].identifier,strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier) ==0 )
//P4200105            {
//P4200105                break;
//P4200105            }
//P4200105//P4100299            if( j = (cnt - 1 ))
//P4200105            if( j == (cnt - 1 ))               //P4100299
//P4200105            {
//P4200105                cassetteIDs[++cnt].identifier = CIMFWStrDup(strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier);
//P4200105
//P4200105            }
//P4200105        }
//P4200105
//P4200105    }
//P4200105    cassetteIDs.length(cnt);

    PPT_METHODTRACE_V1("","Try to waferSorter_slotMap_DeleteDR ");
    objWaferSorter_slotMap_DeleteDR_out  strWaferSorter_slotMap_DeleteDR_out;

    rc = waferSorter_slotMap_DeleteDR(strWaferSorter_slotMap_DeleteDR_out,
                                      strObjCommonIn,
                                      portGroup,
                                      equipmentID,
                                      cassetteIDs,
                                      requestTimeStamp,
                                      SP_Sorter_Requested,
                                      SP_Sorter_Direction_MM);

    //------------------------------------------------------
    // When Error Occures.
    //------------------------------------------------------
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","waferSorter_slotMap_DeleteDR() returned error");
        strWaferSorterOnEqpCancelReqResult.strResult = strWaferSorter_slotMap_DeleteDR_out.strResult ;
        return(rc);
    }

    //----------
    //   Return  
    //----------

    SET_MSG_RC(strWaferSorterOnEqpCancelReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("PPTManager_i:: txWaferSorterOnEqpCancelReq");
    return(RC_OK);
}
