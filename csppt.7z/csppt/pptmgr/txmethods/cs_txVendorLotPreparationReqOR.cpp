#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txVendorLotPreparationReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:40:10 [ 7/13/07 21:40:11 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: cs_txVendorLotPreparationReqOR.cpp
//

#include "cs_pptmgr.hpp"


// Class: CS_PPTManager
//
// Service: txVendorLotPreparationReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/10          O.Sugiyama     Initial Release
// 2000/09/09 P3000090 S.Kawabe       Add Logic to prepare Product Reques     
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize     
// 2002/06/28 P4200023 H.Adachi       Add object call of controlJob_relatedInfo_Update for WaferSorter EQP
// 2004/10/22 D6000025 K.Murakami     eBroker Migration.    //P6000640
// 2005/10/07 P6000640 M.Kase         Add logic to assign newWaferID when newWaferID is empty
//                                    Change history format for D6000025
// 2007/06/13 D9000005 H.Hotta        WaferSorter automation support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/12/04 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/14 INN-R170002  JQ.Shao        Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptVendorLotPreparationReqResult&   strVendorLotPreparationReqResult
//    const pptObjCommonIn&               strObjCommonIn
//    const objectIdentifier&             bankID
//    const char *                        lotType 
//    const char *                        subLotType 
//    const pptNewLotAttributes&          strNewLotAttributes 
//    const char *                        claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code: TXBKC012
//
CORBA::Long CS_PPTManager_i:: txVendorLotPreparationReq (
    pptVendorLotPreparationReqResult&   strVendorLotPreparationReqResult, 
    const pptObjCommonIn&               strObjCommonIn, 
    const objectIdentifier&             bankID, 
    const char *                        lotType, 
    const char *                        subLotType, 
    const pptNewLotAttributes&          strNewLotAttributes, 
//D6000025     const char *                        claimMemo, 
//D6000025     CORBA::Environment &                IT_env)
    const char *                        claimMemo  //D6000025
    CORBAENV_LAST_CPP)                             //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txVendorLotPreparationReq ");
    CORBA::Long rc = RC_OK ;

    //----------------------------------------------------
    // Copy input parameter and use tmpNewLotAttributes
    // inside of this method
    //----------------------------------------------------
    pptNewLotAttributes tmpNewLotAttributes;
    tmpNewLotAttributes = strNewLotAttributes;

//DSN000049350 Add Start
    objCassette_LocationInfo_GetDR_out  strCassette_LocationInfo_GetDR_out;
    PPT_METHODTRACE_V2( "", "calling cassette_LocationInfo_GetDR()", tmpNewLotAttributes.cassetteID.identifier );
    rc = cassette_LocationInfo_GetDR( strCassette_LocationInfo_GetDR_out,
                                      strObjCommonIn,
                                      tmpNewLotAttributes.cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "cassette_LocationInfo_GetDR() != RC_OK", rc );
        strVendorLotPreparationReqResult.strResult = strCassette_LocationInfo_GetDR_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "transferStatus", strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus );
    if ( 0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentIn) )
    {
        // Get required equipment lock mode
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXBKC012" ); // TxVendorLotPreparationReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strVendorLotPreparationReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

        objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
        objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );
        if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

            // Lock Equipment Main Object
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
            strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strVendorLotPreparationReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }

            // Lock Equipment LoadCassette Element (Write)
            stringSequence loadCastSeq;
            loadCastSeq.length(1);
            loadCastSeq[0] = tmpNewLotAttributes.cassetteID.identifier;
            strAdvanced_object_Lock_in.objectID   = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
            strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK && rc != RC_NOT_FOUND_SOME_OBJECT )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strVendorLotPreparationReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
    }
//DSN000049350 Add End

    //----------------------
    // Object Lock for cassette
    //----------------------
    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, 
                     tmpNewLotAttributes.cassetteID, 
                     SP_ClassName_PosCassette);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "object_Lock() != RC_OK");
        strVendorLotPreparationReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    //----------------------
    // Object Lock for source lot
    //----------------------
    CORBA::Long i = 0;
    CORBA::Long nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotPreparationReq", "nLen", nLen);
    for(i=0; i<nLen; i++)
    {
        rc = object_Lock(strObject_Lock_out, strObjCommonIn, 
                         tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID, 
                         SP_ClassName_PosLot);
        if (rc)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotPreparationReq", "object_Lock() != RC_OK", i);
            strVendorLotPreparationReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
    }

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyLotIDs, cassetteIDs;
    cassetteIDs.length(1);
    cassetteIDs[0] = tmpNewLotAttributes.cassetteID;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = cassetteIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyLotIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_DestCast);

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strVendorLotPreparationReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

    //PTR3000090 Start
    //----------------------
    // Prepare Product Request for New Vendor Lot
    //----------------------
    objProductRequest_forVendorLot_Release_out  strProductRequest_forVendorLot_Release_out;
    rc = productRequest_forVendorLot_Release(strProductRequest_forVendorLot_Release_out,
                                             strObjCommonIn,
                                             bankID,
                                             tmpNewLotAttributes.strNewWaferAttributes[0].sourceLotID,
                                             nLen,
                                             lotType,
                                             subLotType);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "productRequest_forVendorLot_Release() != RC_OK");
        strVendorLotPreparationReqResult.strResult = strProductRequest_forVendorLot_Release_out.strResult;
        return(rc);
    }

    //----------------------
    // Copy generated New Lot ID to structure
    //----------------------
    for(i=0; i<nLen; i++)
    {
        tmpNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier
         = strProductRequest_forVendorLot_Release_out.createdProductRequestID.identifier;
    }
    //PTR3000090 End

    //----------------------
    // Check input parameter
    //----------------------
    objLot_parameterForLotGeneration_Check_out strLot_parameterForLotGeneration_Check_out;
    strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred = FALSE; //P3000280
    rc = lot_parameterForLotGeneration_Check(strLot_parameterForLotGeneration_Check_out, strObjCommonIn,
                                             bankID, tmpNewLotAttributes);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "lot_parameterForLotGeneration_Check() != RC_OK");
        strVendorLotPreparationReqResult.strResult = strLot_parameterForLotGeneration_Check_out.strResult;
        return(rc);
    }
    if (strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred == TRUE)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "bWaferIDAssignRequred == TRUE");
        objLot_waferID_Generate_out strLot_waferID_Generate_out;
        rc = lot_waferID_Generate(strLot_waferID_Generate_out, strObjCommonIn,
                                  tmpNewLotAttributes);
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "lot_waferID_Generate() != RC_OK");
            strVendorLotPreparationReqResult.strResult = strLot_waferID_Generate_out.strResult;
            return(rc);
        }
        tmpNewLotAttributes = strLot_waferID_Generate_out.strNewLotAttributes;
    }
    //P6000640 add start
    nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    for (i=0; i<nLen; i++)
    {
        if( 0 == CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier)
         && 0 <  CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier))
        {
            tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID
             = tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID;
        }
    }
    //P6000640 add end

//INN-R170002 Add Start
    objectIdentifierSequence lotIDs;
    CORBA::Long lenLotIDSeq      = 0;
    CORBA::Long j_lot            = 0;
    lotIDs.length(0);
//INN-R170002 Add End

    //----------------------
    // Prepare wafer of source lot
    //----------------------
    i = 0;
    nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotPreparationReq", "nLen", nLen);
    for (i=0; i<nLen; i++)
    {
        if (CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier) == 0)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotPreparationReq", "sourceWaferID is null", i);
            objLot_wafer_Create_out strLot_wafer_Create_out;
            rc = lot_wafer_Create(strLot_wafer_Create_out, strObjCommonIn,
                                  tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                                  tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier);
            if (rc)
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotPreparationReq", "lot_wafer_Create() != RC_OK", i);
                strVendorLotPreparationReqResult.strResult = strLot_wafer_Create_out.strResult;
                return(rc);
            }
            tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = strLot_wafer_Create_out.newWaferID;

            PPT_METHODTRACE_V3("CS_PPTManager_i:: txVendorLotPreparationReq", "newWaferID", 
                               strLot_wafer_Create_out.newWaferID.identifier, i);

            objWafer_materialContainer_Change_out strWafer_materialContainer_Change_out;
            pptWafer strWafer;
            strWafer.waferID    = strLot_wafer_Create_out.newWaferID;
            strWafer.slotNumber =  tmpNewLotAttributes.strNewWaferAttributes[i].newSlotNumber;
            rc = wafer_materialContainer_Change(strWafer_materialContainer_Change_out, strObjCommonIn,
                                                tmpNewLotAttributes.cassetteID,
                                                strWafer);
            // newCassetteID = tmpNewLotAttributes.cassetteID
            // strWafer.waferID = strLot_wafer_Create_out.newWaferID
            // strWafer.slotNumber = tmpNewLotAttributes.strNewWaferAttributes[i].newSlotNumber
            if (rc)
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotPreparationReq", "wafer_materialContainer_Change() != RC_OK", i);
                strVendorLotPreparationReqResult.strResult = strWafer_materialContainer_Change_out.strResult;
                return(rc);
            }
        }

//INN-R170002 Add Start
        //------------------------------------------
        // Collect all lots for contamination check
        //------------------------------------------
        lenLotIDSeq++;
        lotIDs.length(lenLotIDSeq);
        lotIDs[lenLotIDSeq-1] = tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID;
//INN-R170002 Add End
    }

    //----------------------
    // Check source lot's condition    
    //----------------------
    objBank_lotPreparation_Check_out strBank_lotPreparation_Check_out;
    rc = bank_lotPreparation_Check(strBank_lotPreparation_Check_out, strObjCommonIn,
//P3000090                         bankID, lotType, subLotType, strNewLotAttributes);
                                   bankID, lotType, subLotType, tmpNewLotAttributes);    //P3000090
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "bank_lotPreparation_Check() != RC_OK");
        strVendorLotPreparationReqResult.strResult = strBank_lotPreparation_Check_out.strResult;
        return(rc);
    }

//INN-R170002 Add Start
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out strLot_ContaminationInfo_CheckForCarrierExchange_out; 
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in  strLot_ContaminationInfo_CheckForCarrierExchange_in;
    strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID = tmpNewLotAttributes.cassetteID;
    strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs    = lotIDs;
    rc = cs_lot_ContaminationInfo_CheckForCarrierExchange(strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                                          strObjCommonIn,
                                                          strLot_ContaminationInfo_CheckForCarrierExchange_in);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForCarrierExchange() != RC_OK", tmpNewLotAttributes.cassetteID.identifier);
        strVendorLotPreparationReqResult.strResult = strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult;
        return( rc );
    }
//INN-R170002 Add End

    //----------------------
    // Lot Preparation       
    //----------------------
    objBank_LotPreparation_out strBank_LotPreparation_out;
    rc = bank_lotPreparation(strBank_LotPreparation_out, strObjCommonIn,
//P3000090                   bankID, lotType, subLotType, strNewLotAttributes);
                             strProductRequest_forVendorLot_Release_out.createdProductRequestID, bankID, tmpNewLotAttributes);    //P3000090
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "bank_lotPreparation() != RC_OK");
        strVendorLotPreparationReqResult.strResult = strBank_LotPreparation_out.strResult;
        return(rc);
    }

    //----------------------
    // Copy created Lot ID to output structure
    //----------------------
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotPreparationReq", "createdLotID", 
                       strBank_LotPreparation_out.createdLotID.identifier);

    strVendorLotPreparationReqResult.lotID = strBank_LotPreparation_out.createdLotID;

    //----------------------
    // Copy Created New Lot Object Identifier
    //  in order to create History Data
    //----------------------
    for(i=0; i<nLen; i++)
    {
        tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strBank_LotPreparation_out.createdLotID;
    }

    //----------------------
    // Update cassette multi lot type
    //----------------------
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn,
//P3000090                            strNewLotAttributes.cassetteID);
                                      tmpNewLotAttributes.cassetteID);    //P3000090
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "cassette_multiLotType_Update() != RC_OK");
        strVendorLotPreparationReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
        return(rc);
    }

    //P4200023 Add Start
    //--------------------------------------------------------
    //   Maintain Loaded Cassette on Eqp Information
    //--------------------------------------------------------
    objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;

    objectIdentifierSequence cassetteIDSeq(1);
    cassetteIDSeq.length(1);
    cassetteIDSeq[0] = tmpNewLotAttributes.cassetteID;

    PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update Terget Cassette is", cassetteIDSeq[0].identifier);

    rc = controlJob_relatedInfo_Update( strControlJob_relatedInfo_Update_out,
                                        strObjCommonIn,
                                        cassetteIDSeq );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "controlJob_relatedInfo_Update() rc != RC_OK");
        strVendorLotPreparationReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
        return( rc );
    }
    //P4200023 Add End

    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/
    objLot_waferLotHistoryPointer_Update_out  strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn, 
                                           strBank_LotPreparation_out.createdLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "lot_waferLotHistoryPointer_Update() != RC_OK");
        SET_MSG_RC(strVendorLotPreparationReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return rc;
    }

    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make(strLotWaferMoveEvent_Make_out, strObjCommonIn,
//P3000090                      "TXBKC012", strNewLotAttributes, claimMemo);
                                "TXBKC012", tmpNewLotAttributes, claimMemo);    //P3000090
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotPreparationReq", "lotWaferMoveEvent_Make() != RC_OK");
        SET_MSG_RC(strVendorLotPreparationReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return(rc);                                                       
    }                                                                   

    //----------------
    // Return       
    //----------------
    SET_MSG_RC(strVendorLotPreparationReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txVendorLotPreparationReq ");
    return RC_OK ;
}
