#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txOpeLocateReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 16:15:46 [ 8/3/07 16:15:47 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txOpeLocateReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"
extern char* makeInhibitListFromEntityInhibits(const PosEntityInhibitSequence* entityInhibits);

// Class: CS_PPTManager
//
// Service: txOpeLocateReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/08          S.Kawabe       Initial Release (R30)
// 2000/09/07 P3000065 O.Sugiyama     Fix. Correct RC handling
// 2000/09/26 Q3000147 K.Matsuei      Add Check Lot's Control Job ID
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize
// 2001-01-11 D3000118 S.NAKATA       Lot Customization and Flexible Rework
// 2001-01-11 D3000119 S.NAKATA       Lot Customization and Flexible Rework
// 2001/02/27 P3100017 M.Shimizu      LC:Bug Fix to Locate by BRScript.
// 2001/03/01 P3100060 M.shimizu      All Merge Check  Bug Fix
// 2001/03/15 P3100043 M.Shimizu      LC:extendedOperationNumber for LC-subRoute
// 2001/03/21 P3100107 M.Shimizu      LC:called from BRScript: revise targetOperationNumber
// 2001/03/21 P3100107 M.Shimizu      LC:add hold condition when error of proces_LocateForLCFR(). (only when "0.0" Operation)
//                                       set SP_Reason_LCFR_Hold to Reason Code.
// 2001/06/14 P4000028 K.Kido         Add check Routin for txID
// 2001/07/25 D4000016 M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2002/01/15 D4100069 C.Tsuchiya     Drop LCFR logic
// 2002/01/15 D4100020 K.Kido         Change for EfficientModuleProcessRelease.
// 2002/02/05 D4100020 F.Masada       Change for EfficientModuleProcessRelease.
// 2002/02/08 D4100083 T.Michii       Enhancement Future Hold
// 2002/02/28 D4100069 M.Ameshita     Drop LCFR logic(0.02)
// 2002/02/28 D4100120 N.Minami       Future Action
// 2002/03/18 P4100231 H.Adachi       Add Check through at Xfer Stat COndition Check For TXTRC061,TXTRC055
// 2002/03/26 P4100029 M.Ameshita     Fix to set the reason code for waiting monitor hold.
// 2002/03/26 D4100035 M.Ameshita     Prohibit the monitor lot of monitor group from locating operation.
// 2002/03/25 D4100210 H.Adachi       Add InParameter CurrentRouteID & CurrentOperationNum For Check Condition
// 2002/06/14 P4100567 F.Masada       Check input data "processRef.modulePOS", not "processRef.processOperationSpecification(mainPOS)".
// 2002/07/26 D4200029 K.Kimura       Process Hold Control
// 2002/10/04 P4200214 H.Adachi       Skip Cassette Xfer Status Check for ForceOpeComp and ForceOpeCompForInternalBuffer.
// 2002/10/29 D4200062 K.Kido         Add : Check for backupOperation(Rel4.2).
// 2002/11/12 D4200190 K.Kido         Add : Check for backupOperation(Rel4.2).
// 2002/11/18 D4200197 K.Kido         Add : Reject FlowBatchSectionCheck for backupOperation(Rel4.2).
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2006/02/28 P7000087 H.Adachi       TX_ID(TXPCC013:TxMonitorLotSTBAfterProcessReq) is added for excepting Xfer Status Check. 
// 2007/06/08 D9000010 H.Murakami     TXTRC077(TxForceOpeLocateReq) is allowed to operation for the OnHold Lot. 
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/30 DSIV00000214 K.Kido         Multi Fab Transfer Support
// 2010/03/23 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2011/10/20 DSN000015229 M.Ogawa        Advanced Wafer Level Control
// 2011/11/09 PSN000024234 K.Yamaoku      Backward operation location  doesn't require to check schedule change reservation.
// 2013/01/23 DSN000050720 M.Ogawa        Skip cassette lock and hold locks for flow batch and related lots in Post Process parallel execution
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2016/03/07 PSN000101286 T.Ishida       Add check logic for target routeID and operationNo are same as processRef
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txOpeLocateReq
// 2017/09/12 INN-R170002  Thomas Song    Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptOpeLocateReqResult& strOpeLocateReqResult
//     const pptObjCommonIn& strObjCommonIn
//     CORBA::Boolean locateDirection
//     const objectIdentifier& lotID
//     const objectIdentifier& currentRouteID,       //D4100210
//     const char * currentOperationNumber,          //D4100210
//     const objectIdentifier& routeID
//     const objectIdentifier& operationID
//     const char * operationNumber
//     const char * objrefPOS
//     const char * objrefPF
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txOpeLocateReq (pptOpeLocateReqResult& strOpeLocateReqResult,
                                          const pptObjCommonIn& strObjCommonIn,
                                          CORBA::Boolean locateDirection,
                                          const objectIdentifier& lotID,
                                          const objectIdentifier& currentRouteID,       //D4100210
                                          const char * currentOperationNumber,          //D4100210
                                          const objectIdentifier& routeID,
                                          const objectIdentifier& operationID,
                                          const char * operationNumber,
//D4100020                                const char * objrefPOS,
//D4100020                                const char * objrefPF,
                                          const pptProcessRef& processRef,              //D4100020
                                          CORBA::Long  seqno,                           //D4100020
//D6000025                                           const char * claimMemo,
//D6000025                                           CORBA::Environment &IT_env)
                                          const char * claimMemo //D6000025
                                          CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txOpeLocateReq") ;

    PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "in-param's lotID           = ", lotID.identifier);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "in-param's Current RouteI  = ", currentRouteID.identifier);    //D4100210
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "in-param's Current OpeNum  = ", currentOperationNumber);       //D4100210
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "in-param's routeID         = ", routeID.identifier);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "in-param's operationID     = ", operationID.identifier);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "in-param's operationNumber = ", operationNumber);
//D4100020    PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "in-param's objrefPOS       = ", objrefPOS);
//D4100020    PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "in-param's objrefPF        = ", objrefPF);

    CORBA::Long rc = RC_OK ;

    objectIdentifier aLotID( lotID ) ;
    objectIdentifier aCassetteID ;
    objectIdentifier aRouteID( routeID ) ;
    objProcess_Locate_out strProcess_Locate_out ;    //P3100060
    strProcess_Locate_out.autoBankInFlag = FALSE;    //P3100060
//D4100020 start
    pptProcessRef aProcessRef ;
    PPT_METHODTRACE_V2("","in-param's processRef.processFlow", processRef.processFlow ) ;
    PPT_METHODTRACE_V2("","in-param's processRef.processOperationSpecification", processRef.processOperationSpecification) ;
    PPT_METHODTRACE_V2("","in-param's processRef.mainProcessFlow", processRef.mainProcessFlow ) ;
    PPT_METHODTRACE_V2("","in-param's processRef.moduleNumber", processRef.moduleNumber ) ;
    PPT_METHODTRACE_V2("","in-param's processRef.moduleProcessFlow", processRef.moduleProcessFlow ) ;
    PPT_METHODTRACE_V2("","in-param's processRef.modulePOS", processRef.modulePOS ) ;
    aProcessRef.processFlow = processRef.processFlow ;
    aProcessRef.processOperationSpecification = processRef.processOperationSpecification ;
    aProcessRef.mainProcessFlow = processRef.mainProcessFlow ;
    aProcessRef.moduleNumber = processRef.moduleNumber ;
    aProcessRef.moduleProcessFlow = processRef.moduleProcessFlow ;
    aProcessRef.modulePOS = processRef.modulePOS ;
//D4100020 end

//D4100069 //P3100107  add start
//D4100069     CORBA::String_var  extendedOperationNumber;
//D4100069    {
//D4100069        objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069        rc = lot_CheckForLCFR(strLot_CheckForLCFR_out, strObjCommonIn, aLotID, SP_LotCustomize_DBRECORD);
//D4100069        if ( rc == RC_OK)
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069            objLot_currentLCFRInfo_Get_out  strLot_currentLCFRInfo_Get_out;
//D4100069            rc = lot_currentLCFRInfo_Get( strLot_currentLCFRInfo_Get_out, strObjCommonIn, aLotID );
//D4100069            if (rc != RC_OK)
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i::txOpeLocateReq", "lot_currentLCFRInfo_Get() != RC_OK", rc);
//D4100069                strOpeLocateReqResult.strResult = strLot_currentLCFRInfo_Get_out.strResult;
//D4100069                return( rc );
//D4100069            }
//D4100069
//D4100069            char    workbuff[256];
//D4100069            char   *addr = NULL;
//D4100069            CIMFWStrCpy( workbuff, operationNumber );
//D4100069            addr = strrchr( workbuff, ':' );
//D4100069
//D4100069            if ( CIMFWStrCmp( strLot_currentLCFRInfo_Get_out.routeKind, SP_RouteKind_LCSUB ) == 0 &&
//D4100069                 CIMFWStrCmp( strLot_currentLCFRInfo_Get_out.routeID.identifier, routeID.identifier ) == 0 &&
//D4100069                 addr == NULL )
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i::txOpeLocateReq",
//D4100069                                   "(strLot_currentLCFRInfo_Get_out.routeKind == LCSUB) && (strLot_currentLCFRInfo_Get_out.routeID == routeID) && (\":\" doesn't exist.)", operationNumber);
//D4100069
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i::txOpeLocateReq",
//D4100069                                   "strLot_currentLCFRInfo_Get_out.exitOperationNumber ",
//D4100069                                   strLot_currentLCFRInfo_Get_out.exitOperationNumber);
//D4100069
//D4100069                char               workExtended[256];
//D4100069                CIMFWStrCpy( workExtended, strLot_currentLCFRInfo_Get_out.exitOperationNumber );
//D4100069                CIMFWStrCat( workExtended, ":" );
//D4100069                CIMFWStrCat( workExtended, operationNumber );
//D4100069                extendedOperationNumber = CIMFWStrDup( workExtended );
//D4100069
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i::txOpeLocateReq",
//D4100069                                   "extendedOperationNumber ", extendedOperationNumber);
//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i::txOpeLocateReq",
//D4100069                                   "** !( (strLot_currentLCFRInfo_Get_out.routeKind == LCSUB) && (strLot_currentLCFRInfo_Get_out.routeID == routeID) && (\":\" doesn't exist.) )", operationNumber);
//D4100069
//D4100069                extendedOperationNumber = operationNumber;
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i::txOpeLocateReq", "extendedOperationNumber ", extendedOperationNumber);
//D4100069            }
//D4100069        }
//D4100069    }
//D4100069 //P3100107  add end

//D4200062 add start
    CORBA::Boolean cassetteCheckFlag = TRUE ; 
    CORBA::Boolean backupOperationFlag = FALSE;        //D4200197 

    if ( 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXBOC009") )
    {
        backupOperationFlag = TRUE ;                   //D4200197

        objLot_finishedState_Get_out strLot_finishedState_Get_out;
        rc = lot_finishedState_Get( strLot_finishedState_Get_out, strObjCommonIn, aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_finishedState_Get() != RC_OK") ;
            strOpeLocateReqResult.strResult = strLot_finishedState_Get_out.strResult;
            return( rc );
        }

        if( 0 == CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState, CIMFW_Lot_FinishedState_Scrapped) )
        {
            PPT_METHODTRACE_V1(""," ##### cassetteCheckFlag = FALSE (backupOperation)");
            cassetteCheckFlag = FALSE;
        }
    }
//D4200062 add end
//DSN000050720 Add Start
    // Get PostProcForLotFlag from thread specific data
    CORBA::Boolean bParallelPostProcFlag = FALSE;
    char* methodName = NULL;
    CORBA::String_var strParallelPostProcFlag;
    try
    {
        methodName = CIMFWStrDup("getThreadSpecificDataString");
        strParallelPostProcFlag = getThreadSpecificDataString(SP_ThreadSpecificData_Key_PostProcParallelFlag);
        CORBA::string_free(methodName);
        methodName = NULL;
    }
    CATCH_GLOBAL_EXCEPTIONS(strOpeLocateReqResult, txOpeLocateReq, methodName);

    PPT_METHODTRACE_V2("", "strParallelPostProcFlag", strParallelPostProcFlag);

    if ( 0 == CIMFWStrCmp(strParallelPostProcFlag, SP_PostProcess_ParallelExecution_ON) )
    {
        PPT_METHODTRACE_V1("","strParallelPostProcFlag=SP_PostProcess_ParallelExecution_ON");
        bParallelPostProcFlag = TRUE;
    }
//DSN000050720 Add End
    if(cassetteCheckFlag)                                                               //D4200062
    {                                                                                   //D4200062
        /*-----------------------------------*/
        /*   Get cassette / lot connection   */
        /*-----------------------------------*/
        objLot_cassette_Get_out strLot_cassette_Get_out ;
        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_cassette_Get() != RC_OK") ;
            strOpeLocateReqResult.strResult = strLot_cassette_Get_out.strResult ;
            return(rc);
        }
        aCassetteID = strLot_cassette_Get_out.cassetteID ;

        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
        objObject_Lock_out strObject_Lock_out;

//DSN000050720 Add Start
        //----------------------------------------------------------//
        //   Skip cassette lock to increase parallel availability   //
        //   under PostProcess parallel execution                   //
        //----------------------------------------------------------//
        if( FALSE == bParallelPostProcFlag )
        {
            //PostProcess sequential execution
        PPT_METHODTRACE_V1("", "Lock cassette object.");
//DSN000050720 Add End
//DSN000050720 Indent Start
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, aCassetteID, SP_ClassName_PosCassette );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "CS_PPTManager_i:: txOpeLocateReq", "For Cassette, object_Lock() != RC_OK" ) ;
                strOpeLocateReqResult.strResult = strObject_Lock_out.strResult ;
                return( rc );
            }
//DSN000050720 Indent End
        }   //DSN000050720
    }//D4200062

    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aLotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txOpeLocateReq", "For Lot, object_Lock() != RC_OK" ) ;
        strOpeLocateReqResult.strResult = strObject_Lock_out.strResult ;
        return( rc );
    }

//DSN000050720 Add Start
    if ( TRUE == bParallelPostProcFlag )
    {
        PPT_METHODTRACE_V1("","bParallelPostProcFlag=TRUE");
        objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
        rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, aLotID );
        if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
        {
            //-----------------------------------------------------------------------------------//
            //   Lock FlowBatch to keep data inconsistency under PostProcess parallel execution  //
            //-----------------------------------------------------------------------------------//
            PPT_METHODTRACE_V2("", "lot_flowBatchID_Get() == RC_LOT_FLOW_BATCH_ID_FILLED", strLot_flowBatchID_Get_out.flowBatchID.identifier) ;
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, strLot_flowBatchID_Get_out.flowBatchID, SP_ClassName_PosFlowBatch );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "For FlowBatch, object_Lock() != RC_OK") ;
                strOpeLocateReqResult.strResult = strObject_Lock_out.strResult ;
                return( rc );
            }
        }
        else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
        {
            PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
            strOpeLocateReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
            return( rc );
        }
    }
//DSN000050720 Add End
    //D4100210 add start
    //--------------------------------------------------------------------------
    //   Check whether Lot is on the specified Route/Operation or Not
    //--------------------------------------------------------------------------
    PPT_METHODTRACE_V1("","Check whether Lot is on the specified Route/Operation or Not...");

    objectIdentifier  tmpCurrentRouteID         = currentRouteID;
    CORBA::String_var tmpCurrentOperationNumber = CIMFWStrDup(currentOperationNumber);

    if ((CIMFWStrLen(tmpCurrentRouteID.identifier) != 0)&&
        (CIMFWStrLen(tmpCurrentOperationNumber) != 0)) 
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Not Null. Begin to Check!!");

        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_currentOperationInfo_Get() != RC_OK");
            strOpeLocateReqResult.strResult  = strLot_currentOperationInfo_Get_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2("","In-parm's routeID            :", tmpCurrentRouteID.identifier );
        PPT_METHODTRACE_V2("","In-Parm's operationNumber    :", tmpCurrentOperationNumber    );

        PPT_METHODTRACE_V2("","Lot's currentRouteID         :", strLot_currentOperationInfo_Get_out.routeID.identifier );
        PPT_METHODTRACE_V2("","Lot's currentOperationNumber :", strLot_currentOperationInfo_Get_out.operationNumber    );

        if ( CIMFWStrCmp(tmpCurrentRouteID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier) == 0 &&
             CIMFWStrCmp(tmpCurrentOperationNumber   , strLot_currentOperationInfo_Get_out.operationNumber   ) == 0 )
        {
            PPT_METHODTRACE_V1("","Route/Operation check OK. Go ahead...");
        }
        else
        {
            PPT_METHODTRACE_V1("","Route/Operation check NG.");
            PPT_SET_MSG_RC_KEY2(strOpeLocateReqResult,
                                MSG_NOT_SAME_ROUTE,
                                RC_NOT_SAME_ROUTE,
                                "Input parameter's currentRouteID/currentOperationNumber",
                                "lot's current currentRouteID/currentOperationNumber");
            return( RC_NOT_SAME_ROUTE );
        } 
    }
    else
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Null. No Check!!");
    }
    //D4100210 add end
    /*------------------------------------------------------------------------*/
    /*   Check Condition                                                      */
    /*------------------------------------------------------------------------*/
    /*-------------------------------*/
    /*   Get and Check Lot's State   */
    /*-------------------------------*/
    if(cassetteCheckFlag)                                                               //D4200062
    {                                                                                   //D4200062
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out , strObjCommonIn , aLotID ) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_state_Get() != RC_OK") ;
            strOpeLocateReqResult.strResult = strLot_state_Get_out.strResult ;
            return(rc);
        }
        else if( CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active) != 0 )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq",
                               "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active) != 0") ;
            PPT_SET_MSG_RC_KEY( strOpeLocateReqResult,
                                MSG_INVALID_LOT_STAT,
                                RC_INVALID_LOT_STAT,
                                strLot_state_Get_out.lotState ) ;
            return(RC_INVALID_LOT_STAT);
        }
    }                                                                                   //D4200062

    objLot_holdState_Get_out strLot_holdState_Get_out ;
    rc = lot_holdState_Get( strLot_holdState_Get_out , strObjCommonIn , aLotID ) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_holdState_Get() != RC_OK") ;
        strOpeLocateReqResult.strResult = strLot_holdState_Get_out.strResult ;
        return(rc);
    }
    else if ( CIMFWStrCmp( strLot_holdState_Get_out.lotHoldState , CIMFW_Lot_HoldState_NotOnHold ) != 0 )
    {
//D9000010 Add Start
        if ( CIMFWStrCmp ( strObjCommonIn.transactionID, "TXTRC077" ) == 0 )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "if ( CIMFWStrCmp ( strObjCommonIn.transactionID, TXTRC077 ) == 0 )");
        }
        else
        {
//D9000010 Add End

            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq",
           "CIMFWStrCmp( strLot_holdState_Get_out.lotHoldState , CIMFW_Lot_HoldState_NotOnHold ) != 0") ;
            PPT_SET_MSG_RC_KEY2(strOpeLocateReqResult,
                                MSG_INVALID_LOT_HOLDSTAT,
                                RC_INVALID_LOT_HOLDSTAT,
                                aLotID.identifier,
                                strLot_holdState_Get_out.lotHoldState) ;
            return(RC_INVALID_LOT_HOLDSTAT);
        } //9000010
    }

    if(cassetteCheckFlag)                                                               //D4200062
    {                                                                                   //D4200062
        objLot_processState_Get_out strLot_processState_Get_out ;
        rc = lot_processState_Get( strLot_processState_Get_out , strObjCommonIn , aLotID );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_processState_Get() != RC_OK") ;
            strOpeLocateReqResult.strResult = strLot_processState_Get_out.strResult ;
            return(rc);
        }
        else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0 )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq",
                               "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0") ;
            PPT_SET_MSG_RC_KEY2(strOpeLocateReqResult,
                                MSG_INVALID_LOT_PROCSTAT,
                                RC_INVALID_LOT_PROCSTAT,
                                aLotID.identifier,
                                strLot_processState_Get_out.theLotProcessState) ;
            return(RC_INVALID_LOT_PROCSTAT);
        }
    }                                                                                   //D4200062

    objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
    rc = lot_inventoryState_Get(strLot_inventoryState_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_inventoryState_Get() != RC_OK") ;
        strOpeLocateReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq",
                           "CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0") ;
        PPT_SET_MSG_RC_KEY2(strOpeLocateReqResult,
                            MSG_INVALID_LOT_INVENTORYSTAT,
                            RC_INVALID_LOT_INVENTORYSTAT,
                            aLotID.identifier,
                            strLot_inventoryState_Get_out.lotInventoryState) ;
        return(RC_INVALID_LOT_INVENTORYSTAT);
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = aLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strOpeLocateReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strOpeLocateReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strOpeLocateReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                aLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

    /*-----------------------------------------*/
    /*   Get and Check Cassette's Xfer State   */
    /*-----------------------------------------*/
//P4000028    if ( CIMFWStrCmp(StrObjCommonIn.transactionID, "TXTRC003") != 0 &&
//P4000028         CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004") != 0 )
//P4100231    if ( CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC003") != 0 &&
//P4100231         CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004") != 0 &&
//P4100231         CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC014") != 0)                 //P4000028

    PPT_METHODTRACE_V2("","Requsted Transaction ID is ", strObjCommonIn.transactionID );       //P4100231

//P4200214    if ( CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC003") != 0 &&
//P4200214         CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004") != 0 &&
//P4200214         CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC014") != 0 &&
//P4200214         CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC061") != 0 &&
//P4200214         CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC055") != 0 )                          //P4100231

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1") ;
//DSN000071674 add end
        //P4200214 Add Transaction
        if ( CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC003") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC015") != 0 &&  //TxPartialOpeCompWithDataReq           //DSN000015229
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC014") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC061") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC010") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC011") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC055") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC016") != 0 &&  //TxPartialOpeCompForInternalBufferReq  //DSN000015229
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXBOC009") != 0 &&        //D4200062
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXPCC013") != 0 )         //P7000087
        {
            objCassette_transferState_Get_out  strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out, strObjCommonIn, aCassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "cassette_transferState_Get() != RC_OK") ;
                strOpeLocateReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return( rc );
            }
            if ( CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) == 0 )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq",
                                   "CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) == 0") ;
                PPT_SET_MSG_RC_KEY2( strOpeLocateReqResult,
                                     MSG_INVALID_CAST_XFERSTAT,
                                     RC_INVALID_CAST_XFERSTAT,
                                     strCassette_transferState_Get_out.transferState,
                                     aCassetteID.identifier ) ;
                return( RC_INVALID_CAST_XFERSTAT );
            }
        }
    } //DSN000071674

//D4100020    CORBA::String_var objrefPOSVar = objrefPOS ;
//D4100020    CORBA::String_var objrefPFVar  = objrefPF;

//(D3000118,D3000119)    if( objrefPOS == NULL || CIMFWStrCmp( objrefPOS, "" )==0 )       // objrefPOS, objrefPF are filled for Script Language
//P3100017 if( (objrefPOS == NULL || CIMFWStrCmp( objrefPOS, "" )==0) ||   //(D3000118,D3000119)
//P3100017     (objrefPF  == NULL || CIMFWStrCmp( objrefPF , "" )==0) )    //(D3000118,D3000119)
//D4100020    if( objrefPOS == NULL || CIMFWStrCmp( objrefPOS, "" )==0 )   // objrefPOS, objrefPF are filled for Script Language  //P3100017
    //P4100567 if( aProcessRef.processOperationSpecification == NULL || CIMFWStrCmp( aProcessRef.processOperationSpecification, "" ) == 0 )    //D4100020
    if( CIMFWStrLen( aProcessRef.modulePOS ) == 0 || CIMFWStrCmp( aProcessRef.modulePOS, "*" ) == 0 )    //P4100567
    {
         //P4100567 PPT_METHODTRACE_V1( "", "aProcessRef.processOperationSpecification == NULL || aProcessRef.processOperationSpecification =  BLANK " ) ;
         PPT_METHODTRACE_V1( "", "CIMFWStrLen( aProcessRef.modulePOS ) == 0 || CIMFWStrCmp( aProcessRef.modulePOS, * ) == 0" ) ; //P4100567 
//D4100069(0.02) /*==========================================*/                                           //(D3000118,D3000119)
//D4100069(0.02) /*   Seperate Taget Operation No.           */                                           //(D3000118,D3000119)
//D4100069(0.02) /*  [ex]                                    */                                           //(D3000118,D3000119)
//D4100069(0.02) /*  100.20:10.10 => 10.10                   */                                           //(D3000118,D3000119)
//D4100069(0.02) /*  100.20:      =>                         */                                           //(D3000118,D3000119)
//D4100069(0.02) /*  100.20       => 100.20                  */                                           //(D3000118,D3000119)
//D4100069(0.02) /*==========================================*/                                           //(D3000118,D3000119)
//D4100069(0.02) CORBA::String_var   targetOpeNo = CIMFWStrDup( operationNumber );                        //(D3000118,D3000119)
//D4100069(0.02) char    workbuff[256];                                                                   //(D3000118,D3000119)
//D4100069(0.02) char    *addr;                                                                           //(D3000118,D3000119)
//D4100069(0.02)                                                                                          //(D3000118,D3000119)
//D4100069(0.02) CIMFWStrCpy( workbuff, targetOpeNo );                                                    //(D3000118,D3000119)
//D4100069(0.02) addr = strrchr( workbuff, ':' );                                                         //(D3000118,D3000119)
//D4100069(0.02) if ( addr != NULL )                                                                      //(D3000118,D3000119)
//D4100069(0.02) {                                                                                        //(D3000118,D3000119)
//D4100069(0.02)      PPT_METHODTRACE_V2( "CS_PPTManager_i::txOpeLocateReq", "\":\" exists.", ( addr+1 ) );  //(D3000118,D3000119)
//D4100069(0.02)      targetOpeNo = CIMFWStrDup( ( addr+1 ) );                                            //(D3000118,D3000119)
//D4100069(0.02) }                                                                                        //(D3000118,D3000119)
//D4100069(0.02)
//D4100069(0.02) CORBA::Boolean locateDirectionConst = FALSE;                                             //(D3000118,D3000119)

         objProcess_GetTargetOperation_out strProcess_GetTargetOperation_out;
         PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "process_GetTargetOperation IN aLotID= ", aLotID.identifier ) ;
         PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "process_GetTargetOperation IN aRouteID= ", aRouteID.identifier ) ;
//D4100069(0.02) PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "process_GetTargetOperation IN targetOpeNo= ", targetOpeNo ) ;
         PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "process_GetTargetOperation IN targetOpeNo= ", operationNumber ) ;                        //D4100069

//D4100069(0.02) rc = process_GetTargetOperation(strProcess_GetTargetOperation_out, strObjCommonIn, locateDirectionConst, aLotID, aRouteID, targetOpeNo);    //(D3000118,D3000119)
         rc = process_GetTargetOperation( strProcess_GetTargetOperation_out, strObjCommonIn, locateDirection, aLotID, aRouteID, operationNumber );     //D4100069(0.02)
         if (rc != RC_OK)
         {
             PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "process_GetTargetOperation() != RC_OK") ;
             strOpeLocateReqResult.strResult = strProcess_GetTargetOperation_out.strResult ;
             return(rc);
         }

//D4100020         objrefPFVar  = CIMFWStrDup(strProcess_GetTargetOperation_out.objrefPF ) ;
//D4100020         objrefPOSVar = CIMFWStrDup(strProcess_GetTargetOperation_out.objrefPOS) ;
//D4100020         PPT_METHODTRACE_V2( "CS_PPTManager_i:: txOpeLocateReq", "objrefPFVar  = ", objrefPFVar ) ;
//D4100020         PPT_METHODTRACE_V2( "CS_PPTManager_i:: txOpeLocateReq", "objrefPOSVar = ", objrefPOSVar ) ;
         aProcessRef = strProcess_GetTargetOperation_out.processRef ;
         PPT_METHODTRACE_V2("","aProcessRef.processFlow", aProcessRef.processFlow ) ;
         PPT_METHODTRACE_V2("","aProcessRef.processOperationSpecification", aProcessRef.processOperationSpecification ) ;
         PPT_METHODTRACE_V2("","aProcessRef.mainProcessFlow", aProcessRef.mainProcessFlow ) ;
         PPT_METHODTRACE_V2("","aProcessRef.moduleNumber", aProcessRef.moduleNumber ) ;
         PPT_METHODTRACE_V2("","aProcessRef.moduleProcessFlow", aProcessRef.moduleProcessFlow ) ;
         PPT_METHODTRACE_V2("","aProcessRef.modulePOS", aProcessRef.modulePOS ) ;
    }
//PSN000101286 Add Start
    else
    {
        /*-----------------------------------------------*/
        /*   Check Target Operation same as processRef   */
        /*-----------------------------------------------*/
        objProcess_GetOperationByProcessRef_out strProcess_GetOperationByProcessRef_out;
        objProcess_GetOperationByProcessRef_in strProcess_GetOperationByProcessRef_in;

        strProcess_GetOperationByProcessRef_in.processRef = aProcessRef;

        rc = process_GetOperationByProcessRef( strProcess_GetOperationByProcessRef_out,
                                               strObjCommonIn,
                                               strProcess_GetOperationByProcessRef_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "process_GetOperationByProcessRef() != RC_OK" );
            strOpeLocateReqResult.strResult = strProcess_GetOperationByProcessRef_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2( "", "routeID",         strProcess_GetOperationByProcessRef_out.routeID.identifier );
        PPT_METHODTRACE_V2( "", "operationNumber", strProcess_GetOperationByProcessRef_out.operationNumber );

        if( ( CIMFWStrLen( aRouteID.identifier ) > 0 ) && ( CIMFWStrLen( operationNumber ) > 0 ) )
        {
            if( ( CIMFWStrCmp( strProcess_GetOperationByProcessRef_out.routeID.identifier, aRouteID.identifier   ) != 0 ) ||
                ( CIMFWStrCmp( strProcess_GetOperationByProcessRef_out.operationNumber,    operationNumber       ) != 0 ) )
            {
                PPT_METHODTRACE_V1( "", "Check Target Operation same as processRef NG." );
                PPT_SET_MSG_RC_KEY2( strOpeLocateReqResult,
                                     MSG_NOT_SAME_ROUTE,
                                     RC_NOT_SAME_ROUTE,
                                     "Input parameter's RouteID/OperationNumber",
                                     "Input parameter's processRef" );
                return( RC_NOT_SAME_ROUTE );
            }
        }
    }
//PSN000101286 Add End

//D4100069 //(D3000118,D3000119) start of add
//D4100069
//D4100069     /*----------------------------------------*/
//D4100069     /*   Check if Lot has FutureHold or not   */
//D4100069     /*----------------------------------------*/
//D4100069     objLot_CheckForLCFR_out strLot_CheckForLCFR_out ;
//D4100069     rc = lot_CheckForLCFR(strLot_CheckForLCFR_out, strObjCommonIn, aLotID, SP_LotCustomize_DBRECORD);
//D4100069     if ( rc != RC_OK)
//D4100069     {
//D4100069         PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_CheckForLCF != RC_OK")     ;
//D4100069         objLot_futureHoldRequests_CheckLocate_out strLot_futureHoldRequests_CheckLocate_out ;
//D4100069         rc = lot_futureHoldRequests_CheckLocate(strLot_futureHoldRequests_CheckLocate_out,
//D4100069                                     strObjCommonIn, locateDirection, aLotID,  objrefPFVar, objrefPOSVar) ;
//D4100069         if (rc != RC_OK )
//D4100069         {
//D4100069             PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_CheckLocate() rc != RC_OK") ;
//D4100069            // set returned strResult to strResult of out parameter
//D4100069             strOpeLocateReqResult.strResult = strLot_futureHoldRequests_CheckLocate_out.strResult ;
//D4100069             return rc ;
//D4100069         }
//D4100069     }
//D4100069     else
//D4100069     {
//D4100069         PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_CheckForLCF = RC_OK") ;
//D4100069         objLot_futureHoldRequests_CheckLocateForLCFR_out strLot_futureHoldRequests_CheckLocateForLCFR_out ;
//D4100069 //P3100107 rc = lot_futureHoldRequests_CheckLocateForLCFR(strLot_futureHoldRequests_CheckLocateForLCFR_out,
//D4100069 //P3100107                                                strObjCommonIn,locateDirection,
//D4100069 //P3100107                                                aLotID, routeID,operationNumber) ;
//D4100069
//D4100069 //P3100107  add start
//D4100069         rc = lot_futureHoldRequests_CheckLocateForLCFR(strLot_futureHoldRequests_CheckLocateForLCFR_out,
//D4100069                                                         strObjCommonIn,locateDirection,
//D4100069                                                         aLotID, routeID,extendedOperationNumber) ;
//D4100069 //P3100107  add end
//D4100069         if ( rc != RC_OK )
//D4100069         {
//D4100069             PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_CheckLocateForLCFR rc != RC_OK") ;
//D4100069             //set returned strResult to strResult of out parameter
//D4100069             strOpeLocateReqResult.strResult = strLot_futureHoldRequests_CheckLocateForLCFR_out.strResult ;
//D4100069             return(rc);
//D4100069         }
//D4100069     }

//D3000119   objLot_futureHoldRequests_CheckLocate_out strLot_futureHoldRequests_CheckLocate_out ;
//D3000119   rc = lot_futureHoldRequests_CheckLocate(strLot_futureHoldRequests_CheckLocate_out, strObjCommonIn,
//D3000119                                           locateDirection, aLotID, objrefPFVar, objrefPOSVar) ;
//D3000119   if (rc != RC_OK)
//D3000119   {
//D3000119        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_CheckLocate() != RC_OK") ;
//D3000119        strOpeLocateReqResult.strResult = strLot_futureHoldRequests_CheckLocate_out.strResult ;
//D3000119        return rc ;
//D3000119   }

//D4100069 restore start
    objLot_futureHoldRequests_CheckLocate_out strLot_futureHoldRequests_CheckLocate_out ;
//D4100020    rc = lot_futureHoldRequests_CheckLocate(strLot_futureHoldRequests_CheckLocate_out, strObjCommonIn,
//D4100020                                           locateDirection, aLotID, objrefPFVar, objrefPOSVar ) ;
    rc = lot_futureHoldRequests_CheckLocate(strLot_futureHoldRequests_CheckLocate_out, strObjCommonIn,
                                           locateDirection, aLotID, aProcessRef ) ;
    if (rc != RC_OK)
    {
         PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_CheckLocate() != RC_OK") ;
         strOpeLocateReqResult.strResult = strLot_futureHoldRequests_CheckLocate_out.strResult ;
         return rc ;
    }
//D4100069 restore end

//D4100069 //(D3000118,D3000119) end of  add

    if(backupOperationFlag==FALSE)                                                      //D4200197
    {                                                                                   //D4200197
        objLot_flowBatch_CheckLocate_out strLot_flowBatch_CheckLocate_out ;
//D4100020    rc = lot_flowBatch_CheckLocate(strLot_flowBatch_CheckLocate_out, strObjCommonIn,
//D4100020                                   locateDirection, aLotID, objrefPFVar, objrefPOSVar) ;
        rc = lot_flowBatch_CheckLocate(strLot_flowBatch_CheckLocate_out, strObjCommonIn,
                                       locateDirection, aLotID, aProcessRef ) ;    //D4100020
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "lot_flowBatch_CheckLocate() != RC_OK", rc) ;

            /*-------------------------------*/
            /*   Remove Lot from FlowBatch   */
            /*-------------------------------*/
            if (rc == RC_LOT_REMOVE_FROM_BATCH)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_flowBatch_CheckLocate() == RC_LOT_REMOVE_FROM_BATCH") ;

                objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
                rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, aLotID );
//P3000065            if ( rc == RC_LOT_BATCH_ID_FILLED )
                if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED ) //P3000065
                {
//DSN000050720 Add Start
                    if ( TRUE == bParallelPostProcFlag )
                    {
                        PPT_METHODTRACE_V1(" ", "call flowBatch_lot_Get()");
                        objFlowBatch_lot_Get_out  strFlowBatch_lot_Get_out;
                        rc = flowBatch_lot_Get( strFlowBatch_lot_Get_out, strObjCommonIn, strLot_flowBatchID_Get_out.flowBatchID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "flowBatch_lot_Get() != RC_OK", rc);
                            strOpeLocateReqResult.strResult = strFlowBatch_lot_Get_out.strResult;
                            return( rc );
                        }

                        CORBA::ULong flowBatchLotLen = strFlowBatch_lot_Get_out.strContainedLotsInFlowBatch.length();
                        for ( CORBA::ULong i = 0; i < flowBatchLotLen; i++ )
                        {
                            objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                            objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                            //---------------------------------------------------------------------------//
                            //   Read lock FlowBatch's lots to reactivate under multi thread execution   //
                            //---------------------------------------------------------------------------//
                            stringSequence dummySeq;
                            dummySeq.length(0);
                            strAdvanced_object_Lock_in.objectID   = strFlowBatch_lot_Get_out.strContainedLotsInFlowBatch[i].lotID;
                            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosLot );
                            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_Object );
                            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_READ;
                            strAdvanced_object_Lock_in.keySeq     = dummySeq;

                            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_Object );
                            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                                        strObjCommonIn,
                                                        strAdvanced_object_Lock_in );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                                strOpeLocateReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                                return( rc );
                            }
                        } // [i]
                    }
//DSN000050720 Add End
                    pptLotRemoveFromFlowBatchReqResult  strLotRemoveFromFlowBatchReqResult ;

                     pptRemoveCassetteSequence strRemoveCassette;
                     strRemoveCassette.length(1);

                     strRemoveCassette[0].lotID.length(1);
                     strRemoveCassette[0].lotID[0] = aLotID;
                     strRemoveCassette[0].cassetteID = aCassetteID;

                     rc = txLotRemoveFromFlowBatchReq( strLotRemoveFromFlowBatchReqResult,
                                                       strObjCommonIn,
                                                       strLot_flowBatchID_Get_out.flowBatchID,
                                                       strRemoveCassette,
                                                       claimMemo ) ;
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "CS_PPTManager_i:: txOpeLocateReq", "txLotRemoveFromFlowBatchReq() != RC_OK" ,rc ) ;
                        strOpeLocateReqResult.strResult = strLotRemoveFromFlowBatchReqResult.strResult ;
                        return( rc );
                    }
                }
//P3000065            else if ( rc != RC_LOT_BATCH_ID_BLANK )
                else if ( rc != RC_LOT_FLOW_BATCH_ID_BLANK ) //P3000065
                {
                    PPT_METHODTRACE_V2( "CS_PPTManager_i:: txOpeLocateReq", "lot_batchID_Get() != RC_LOT_BATCH_ID_BLANK" ,rc) ;
                    strOpeLocateReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
                    return( rc );
                }
            }
            else
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "rc") ;
                strOpeLocateReqResult.strResult = strLot_flowBatch_CheckLocate_out.strResult ;
                return rc ;
            }
        }

        objLot_bondingFlowSection_CheckLocate_out strLot_bondingFlowSection_CheckLocate_out;                                     //DSIV00001830
        rc = lot_bondingFlowSection_CheckLocate(strLot_bondingFlowSection_CheckLocate_out, strObjCommonIn, aLotID, aProcessRef); //DSIV00001830
        if( rc != RC_OK )                                                                                                        //DSIV00001830
        {                                                                                                                        //DSIV00001830
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "lot_bondingFlowSection_CheckLocate() != RC_OK", rc);            //DSIV00001830
            strOpeLocateReqResult.strResult = strLot_bondingFlowSection_CheckLocate_out.strResult;                               //DSIV00001830
            return rc;                                                                                                           //DSIV00001830
        }                                                                                                                        //DSIV00001830
    }//D4200197

    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, aLotID );
//Q3000147 start
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_controlJobID_Get() != RC_OK");
        strOpeLocateReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
//Q3000147 end
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "rc") ;
        PPT_SET_MSG_RC_KEY2( strOpeLocateReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             aLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }

    /*------------------------------------------------------------------------*/
    /*   Change State                                                         */
    /*------------------------------------------------------------------------*/
//D4100035    objMonitorGroup_DeleteComp_out strMonitorGroup_DeleteComp_out ;
//D4100035    rc = monitorGroup_DeleteComp(strMonitorGroup_DeleteComp_out, strObjCommonIn, aLotID) ;
//D4100035    if (rc != RC_OK)
//D4100035    {
//D4100035        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "rc != RC_OK") ;
//D4100035        strOpeLocateReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult ;
//D4100035        return(rc);
//D4100035    }
//D4100035
//D4100035    objectIdentifier aReasonCodeID ;
//D4100035    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_WaitingMonitorHoldRelease ) ;                          //P4100029
//D4100035
//D4100035    CORBA::Long nCompLotSeq = strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length() ;
//D4100035    PPT_METHODTRACE_V2( "CS_PPTManager_i:: txOpeLocateReq", "trMonitorGroup_DeleteComp_out.strMonitoredCompLots.length()",nCompLotSeq) ;
//D4100035
//D4100035    for(CORBA::Long i=0; i<nCompLotSeq; i++)
//D4100035    {
//D4100035        if( strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].strLotHoldReleaseReqList.length() > 0 )
//D4100035        {
//D4100035            pptHoldLotReleaseReqResult strHoldLotReleaseReqResult ;
//D4100035            rc = txHoldLotReleaseReq(strHoldLotReleaseReqResult,
//D4100035                                     strObjCommonIn,
//D4100035                                     strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].productLotID,
//D4100035                                     aReasonCodeID,
//D4100035                                     strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].strLotHoldReleaseReqList) ;
//D4100035            if (rc != RC_OK)
//D4100035            {
//D4100035                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "txHoldLotReleaseReq() != RC_OK") ;
//D4100035                strOpeLocateReqResult.strResult = strHoldLotReleaseReqResult.strResult ;
//D4100035                return rc ;
//D4100035            }
//D4100035        }
//D4100035    }

    objMonitorGroup_CheckExistance_out strMonitorGroup_CheckExistance_out ;                            //D4100035
    rc = monitorGroup_CheckExistance( strMonitorGroup_CheckExistance_out, strObjCommonIn, aLotID) ;    //D4100035
                                                                                                       //D4100035
    if (rc != RC_OK)                                                                                   //D4100035
    {                                                                                                  //D4100035
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "rc != RC_OK") ;                           //D4100035
        strOpeLocateReqResult.strResult = strMonitorGroup_CheckExistance_out.strResult ;               //D4100035
        return(rc);                                                                                    //D4100035
    }                                                                                                  //D4100035

//D4100083 Add Start
    objectIdentifier releaseReasonCodeID ;
    objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;
    pptEffectCondition strEffectCondition;
//D4100083 Add End
//D4100083    objLot_futureHoldRequests_DeleteEffected_out strLot_futureHoldRequests_DeleteEffected_out ;
    if( locateDirection == TRUE )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "locateDirection == TRUE") ;

//D4100069 //P3100043  add start
//D4100069         {
//D4100069             objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069             rc = lot_CheckForLCFR(  strLot_CheckForLCFR_out,strObjCommonIn,aLotID,SP_LotCustomize_DBRECORD );
//D4100069             if ( rc != RC_OK )
//D4100069             {
//D4100069                 PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "lot_CheckForLCFR() != RC_OK", rc);
//D4100069                 rc = lot_futureHoldRequests_DeleteEffected(strLot_futureHoldRequests_DeleteEffected_out, strObjCommonIn, aLotID) ;
//D4100069                 if(rc != RC_OK)
//D4100069                 {
//D4100069                     PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_DeleteEffected() != RC_OK") ;
//D4100069                     strOpeLocateReqResult.strResult = strLot_futureHoldRequests_DeleteEffected_out.strResult ;
//D4100069                     return(rc);
//D4100069                 }
//D4100069
//D4100069             }
//D4100069             else
//D4100069             {
//D4100069                 PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069                 objLot_futureHoldRequests_DeleteEffectedForLCFR_out  strLot_futureHoldRequests_DeleteEffectedForLCFR_out;
//D4100069                 rc = lot_futureHoldRequests_DeleteEffectedForLCFR( strLot_futureHoldRequests_DeleteEffectedForLCFR_out, strObjCommonIn, aLotID );
//D4100069                 if ( rc == RC_OK )
//D4100069                 {
//D4100069                     PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_DeleteEffectedForLCFR() == RC_OK");
//D4100069                     strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList = strLot_futureHoldRequests_DeleteEffectedForLCFR_out.strFutureHoldReleaseReqList;
//D4100069                 }
//D4100069                 else
//D4100069                 {
//D4100069                     PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_DeleteEffectedForLCFR() != RC_OK", rc);
//D4100069                     strOpeLocateReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedForLCFR_out.strResult;
//D4100069                     return( rc );
//D4100069                 }
//D4100069             }
//D4100069         }
//D4100069 //P3100043  add end

//P3100043        rc = lot_futureHoldRequests_DeleteEffected( strLot_futureHoldRequests_DeleteEffected_out , strObjCommonIn , aLotID ) ;
//P3100043        if (rc != RC_OK)
//P3100043        {
//P3100043            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_DeleteEffected() != RC_OK") ;
//P3100043            strOpeLocateReqResult.strResult = strLot_futureHoldRequests_DeleteEffected_out.strResult ;
//P3100043            return(rc);
//P3100043        }

//D4100069 restore start
//D4100083        rc = lot_futureHoldRequests_DeleteEffected( strLot_futureHoldRequests_DeleteEffected_out , strObjCommonIn , aLotID ) ;
//D4100083        if (rc != RC_OK)
//D4100083        {
//D4100083            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_DeleteEffected() != RC_OK") ;
//D4100083            strOpeLocateReqResult.strResult = strLot_futureHoldRequests_DeleteEffected_out.strResult ;
//D4100083            return(rc);
//D4100083        }
//D4100069 restore end
//D4100083 Add Start
        strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_ALL );
        strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

        rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                               strObjCommonIn,
                                                               aLotID,
                                                               strEffectCondition );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
            strOpeLocateReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
            return( rc );
        }
//D4100083 Add End

//D4100083        objectIdentifier releaseReasonCodeID ;

        if( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )  //D4100083
//D4100083        if( strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList.length() > 0 )
        {
            pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
            rc = txFutureHoldCancelReq(strFutureHoldCancelReqResult,
                                       strObjCommonIn,
                                       aLotID,
                                       releaseReasonCodeID,
                                       SP_EntryType_Remove,
                                       strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList) ;  //D4100083
//D4100083                                       strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList) ;
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "txFutureHoldCancelReq() != RC_OK") ;
                strOpeLocateReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
                return(rc);
            }
        }
//DSIV00000214 add start
        //---------------------------------------
        // Check interFabXferPlan existence
        //---------------------------------------
        objProcess_CheckInterFabXferPlanSkip_in strProcess_CheckInterFabXferPlanSkip_in;
        strProcess_CheckInterFabXferPlanSkip_in.lotID = aLotID;
        strProcess_CheckInterFabXferPlanSkip_in.currentRouteID = currentRouteID;
        strProcess_CheckInterFabXferPlanSkip_in.currentOpeNo = CIMFWStrDup(currentOperationNumber);
        strProcess_CheckInterFabXferPlanSkip_in.jumpingRouteID = routeID ;
        strProcess_CheckInterFabXferPlanSkip_in.jumpingOpeNo = CIMFWStrDup(operationNumber);

        objProcess_CheckInterFabXferPlanSkip_out strProcess_CheckInterFabXferPlanSkip_out;
        rc = process_CheckInterFabXferPlanSkip( strProcess_CheckInterFabXferPlanSkip_out,
                                                strObjCommonIn,
                                                strProcess_CheckInterFabXferPlanSkip_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_CheckInterFabXferPlanSkip() != RC_OK");
            strOpeLocateReqResult.strResult = strProcess_CheckInterFabXferPlanSkip_out.strResult;
            return( rc );
        }
//DSIV00000214 add end
//PSN000024234    }
//D4100120 Add Start
//PSN000024234 indent start
        /*-----------------------------------*/
        /*   Check Future Action Procedure   */
        /*-----------------------------------*/
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "schdlChangeReservation_CheckForFutureOperation");
        CORBA::String_var tmpRouteID = routeID.identifier;

        objSchdlChangeReservation_CheckForFutureOperation_out strSchdlChangeReservation_CheckForFutureOperation_out;
        rc = schdlChangeReservation_CheckForFutureOperation(strSchdlChangeReservation_CheckForFutureOperation_out,
                                                            strObjCommonIn,
                                                            lotID,
                                                            tmpRouteID,
                                                            operationNumber);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "schdlChangeReservation_CheckForFutureOperation() != RC_OK") ;
            strOpeLocateReqResult.strResult = strSchdlChangeReservation_CheckForFutureOperation_out.strResult;
            return(rc);
        }
//PSN000024234 indent end
    } //PSN000024234
//D4100120 Add End

//D4100069    //(D3000118,D3000119) add start
//D4100069    rc = lot_CheckForLCFR(strLot_CheckForLCFR_out, strObjCommonIn, aLotID, SP_LotCustomize_DBRECORD);  //ADD  (D3000118, D3000119)
//D4100069    if (rc != RC_OK)                                                                                   //ADD  (D3000118, D3000119)
//D4100069    {                                                                                                  //ADD  (D3000118, D3000119)
//D4100069        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReqq", "lot_CheckForLCFR() rc != RC_OK");        //ADD  (D3000118, D3000119)
//D4100069        rc = process_Locate(strProcess_Locate_out, strObjCommonIn, aLotID, objrefPFVar, objrefPOSVar) ;
//D4100069        if (rc != RC_OK)
//D4100069        {
//D4100069           PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "process_Locate() != RC_OK") ;
//D4100069           strOpeLocateReqResult.strResult = strProcess_Locate_out.strResult ;
//D4100069           return( rc) ;
//D4100069        }
//D4100069    }
//D4100069    else
//D4100069    {
//D4100069        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReqq", "lot_CheckForLCFR() == RC_OK");        //ADD  (D3000118, D3000119)
//D4100069
//D4100069        objProcess_LocateForLCFR_out strProcess_LocateForLCFR_out ;
//D4100069        strProcess_LocateForLCFR_out.autoBankInFlag = FALSE;
//D4100069 //P3100107 rc = process_LocateForLCFR(strProcess_LocateForLCFR_out, strObjCommonIn, aLotID, routeID, operationNumber) ;
//D4100069        rc = process_LocateForLCFR(strProcess_LocateForLCFR_out, strObjCommonIn, aLotID, routeID, extendedOperationNumber) ;  //P3100107
//D4100069        switch(rc)
//D4100069        {
//D4100069            case   RC_OK:
//D4100069
//D4100069                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "process_LocateForLCFR() == RC_OK") ;
//D4100069                strProcess_Locate_out.autoBankInFlag = strProcess_LocateForLCFR_out.autoBankInFlag ;
//D4100069                strProcess_Locate_out.oldCurrentPOS = strProcess_LocateForLCFR_out.oldCurrentPOS ;
//D4100069                break ;
//D4100069            case   RC_ROUTEID_DELETED :   //P3100107
//D4100069            case   RC_OPENO_DELETED   :   //P3100107
//D4100069
//D4100069 //P3100107              default:
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq",
//D4100069                                   "process_LocateForLCFR() == (RC_ROUTEID_DELETED || RC_OPENO_DELETED)", rc) ;
//D4100069
//P3100107                strOpeLocateReqResult.strResult = strOpeLocateReqResult.strResult ;

//P3100107  Hold Lot only when currentOperationNumber is LotCustomize_Dummy_OperationNumber.
//P3100107
//P3100107                pptHoldListSequence strLotHoldReqList ;
//P3100107                pptHoldLotReqResult strHoldLotReqResult ;
//P3100107                /*------------------------------------------------------------------------------------*/
//P3100107                /* parameter set                                                                         */
//P3100107                /*---------------------------------------------------------------------------------------*/
//P3100107                strLotHoldReqList.length( 1 ) ;
//P3100107                strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LCFR_Route_Deleted ) ;
//P3100107                strLotHoldReqList[0].holdReasonCodeID         = aReasonCodeID;
//P3100107                strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
//P3100107                strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
//P3100107                strLotHoldReqList[0].routeID                  = routeID ;
//P3100107                strLotHoldReqList[0].operationNumber          = CIMFWStrDup( SP_LotCustomize_Dummy_OperationNumber );
//P3100107                strLotHoldReqList[0].relatedLotID             = aLotID ;
//P3100107                strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "");
//P3100107                /*------------------------------------------------------------------------------------*/
//P3100107                /* parameter set                                                                         */
//P3100107                /*---------------------------------------------------------------------------------------*/
//P3100107                rc = txHoldLotReq(strHoldLotReqResult,strObjCommonIn, aLotID, strLotHoldReqList) ;
//P3100107                if (rc != RC_OK)
//P3100107                {
//P3100107                    PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "txHoldLotReq() != RC_OK") ;
//P3100107                    strOpeLocateReqResult.strResult = strHoldLotReqResult.strResult ;
//P3100107                    return rc ;
//P3100107                }

//D4100069 //P3100107  add start
//D4100069                /* ------------------------------------------------------- */
//D4100069                /* Only when current Operation is Dummy Operation,         */
//D4100069                /* execute HOLD LOT.                                       */
//D4100069                /* ------------------------------------------------------- */
//D4100069                /* --- Get Current OperationNumber --- */
//D4100069                CORBA::Long                     rc2 = RC_OK;
//D4100069                CORBA::String_var               currentOpeNo;
//D4100069                objLot_currentOpeNo_Get_out     strLot_currentOpeNo_Get_out;
//D4100069                rc2 = lot_currentOpeNo_Get( strLot_currentOpeNo_Get_out,
//D4100069                                            strObjCommonIn,
//D4100069                                            aLotID );
//D4100069                if ( rc2 == RC_OK )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2( "CS_PPTManager_i::txOpeLocateReq",
//D4100069                                        "lot_currentOpeNo_Get() == RC_OK ", strLot_currentOpeNo_Get_out.currentOperationNumber );
//D4100069
//D4100069                    currentOpeNo = strLot_currentOpeNo_Get_out.currentOperationNumber;
//D4100069                }
//D4100069                else
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2( "CS_PPTManager_i::txOpeLocateReq",
//D4100069                                        "lot_currentOpeNo_Get() != RC_OK : ", rc2 );
//D4100069                    strOpeLocateReqResult.strResult = strLot_currentOpeNo_Get_out.strResult;
//D4100069                    return( rc2 );
//D4100069                }
//D4100069                /* --- When current Operation is LotCustomize_Dummy_OperationNumber, Hold Lot. --- */
//D4100069                if ( CIMFWStrCmp( currentOpeNo, SP_LotCustomize_Dummy_OperationNumber ) == 0 )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1( "CS_PPTManager_i::txOpeLocateReq",
//D4100069                                        "currentOpeNo == SP_LotCustomize_Dummy_OperationNumber" );
//D4100069                    pptHoldListSequence strLotHoldReqList ;
//D4100069                    pptHoldLotReqResult strHoldLotReqResult ;
//D4100069                    /*------------------------------------------------------------------------------------*/
//D4100069                    /* parameter set                                                                      */
//D4100069                    /*------------------------------------------------------------------------------------*/
//D4100069                    strLotHoldReqList.length( 1 ) ;
//D4100069                    strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LCFR_Route_Deleted ) ;
//D4100069                    strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( SP_Reason_LCFR_Hold );
//D4100069                    strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
//D4100069                    strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
//D4100069                    strLotHoldReqList[0].routeID                  = routeID ;
//D4100069                    strLotHoldReqList[0].operationNumber          = CIMFWStrDup( SP_LotCustomize_Dummy_OperationNumber );
//D4100069                    strLotHoldReqList[0].relatedLotID             = aLotID ;
//D4100069                    strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "");
//D4100069                    /*------------------------------------------------------------------------------------*/
//D4100069                    /* Hold Request                                                                       */
//D4100069                    /*------------------------------------------------------------------------------------*/
//D4100069                    rc = txHoldLotReq(strHoldLotReqResult,strObjCommonIn, aLotID, strLotHoldReqList) ;
//D4100069                    if (rc != RC_OK)
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "txHoldLotReq() != RC_OK", rc) ;
//D4100069                        strOpeLocateReqResult.strResult = strHoldLotReqResult.strResult ;
//D4100069                        return rc ;
//D4100069                    }
//D4100069                }
//D4100069                else
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1( "CS_PPTManager_i::txOpeLocateReq",
//D4100069                                        "currentOpeNo != SP_LotCustomize_Dummy_OperationNumber" );
//D4100069                    strOpeLocateReqResult.strResult = strProcess_LocateForLCFR_out.strResult ;
//D4100069                    return( rc );
//D4100069                }
//D4100069 //P3100107  add end
//D4100069
//D4100069                break;
//D4100069            }
//D4100069
//D4100069 //P3100107  add start
//D4100069            default :
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq",
//D4100069                                   "process_LocateForLCFR() == default ", rc) ;
//D4100069                strOpeLocateReqResult.strResult = strProcess_LocateForLCFR_out.strResult ;
//D4100069                return( rc );
//D4100069 //P3100107  add end
//D4100069
//D4100069         }
//D4100069
//D4100069    }
//D4100069
//D4100069 //(D3000118,D3000119) add end

//(D3000118,D3000119)     objProcess_Locate_out strProcess_Locate_out ;
//(D3000118,D3000119)     strProcess_Locate_out.autoBankInFlag = FALSE; //P3000280

//(D3000118,D3000119)     rc = process_Locate(strProcess_Locate_out, strObjCommonIn, aLotID, objrefPFVar, objrefPOSVar) ;
//(D3000118,D3000119)     if (rc != RC_OK)
//(D3000118,D3000119)     {
//(D3000118,D3000119)         PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "process_Locate() != RC_OK") ;
//(D3000118,D3000119)         strOpeLocateReqResult.strResult = strProcess_Locate_out.strResult ;
//(D3000118,D3000119)         return rc ;
//(D3000118,D3000119)     }

//D4100069 restore start
//D4100020    rc = process_Locate(strProcess_Locate_out, strObjCommonIn, aLotID, objrefPFVar, objrefPOSVar) ;
    rc = process_Locate(strProcess_Locate_out, strObjCommonIn, aLotID, aProcessRef, seqno ) ;    //D4100020
    if (rc != RC_OK)
    {
         PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "process_Locate() != RC_OK") ;
         strOpeLocateReqResult.strResult = strProcess_Locate_out.strResult ;
         return rc ;
    }
//D4100069 restore end

//D4100069 //P3100043  add start
//D4100069    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;
//D4100069    {
//D4100069        objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069        rc = lot_CheckForLCFR(  strLot_CheckForLCFR_out,strObjCommonIn,aLotID,SP_LotCustomize_DBRECORD );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "lot_CheckForLCFR() != RC_OK", rc);
//D4100069            rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, aLotID) ;
//D4100069            if(rc != RC_OK)
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_Effect() != RC_OK") ;
//D4100069                strOpeLocateReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//D4100069                return(rc);
//D4100069            }
//D4100069
//D4100069        }
//D4100069        else
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069            objLot_futureHoldRequests_EffectForLCFR_out  strLot_futureHoldRequests_EffectForLCFR_out;
//D4100069            rc = lot_futureHoldRequests_EffectForLCFR( strLot_futureHoldRequests_EffectForLCFR_out, strObjCommonIn, aLotID );
//D4100069            if ( rc == RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_EffectForLCFR() == RC_OK");
//D4100069                strLot_futureHoldRequests_Effect_out.strLotHoldReqList = strLot_futureHoldRequests_EffectForLCFR_out.strLotHoldReqList;
//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_EffectForLCFR() != RC_OK", rc);
//D4100069                strOpeLocateReqResult.strResult = strLot_futureHoldRequests_EffectForLCFR_out.strResult;
//D4100069                return( rc );
//D4100069            }
//D4100069        }
//D4100069    }
//D4100069 //P3100043  add end

//P3100043
//P3100043    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;
//P3100043    rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out ,strObjCommonIn, aLotID) ;
//P3100043    if (rc != RC_OK)
//P3100043    {
//P3100043        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_Effect() != RC_OK") ;
//P3100043        strOpeLocateReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//P3100043        return(rc);
//P3100043    }

//D4100069 restore start
//D4100083    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;
//D4100083    rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out ,strObjCommonIn, aLotID) ;
//D4100083    if (rc != RC_OK)
//D4100083    {
//D4100083        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_Effect() != RC_OK") ;
//D4100083        strOpeLocateReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//D4100083        return(rc);
//D4100083    }
//D4100069 restore end
//D4100083 Add Start
    if( cassetteCheckFlag )    //D4200190
    {                          //D4200190
        strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
        strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

        objLot_futureHoldRequests_EffectByCondition_out strLot_futureHoldRequests_EffectByCondition_out;
        rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_out,
                                                       strObjCommonIn,
                                                       aLotID,
                                                       strEffectCondition);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
            strOpeLocateReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_out.strResult ;
            return( rc );
        }

        if( strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0 )
//D4100083 Add End
//D4100083     if( strLot_futureHoldRequests_Effect_out.strLotHoldReqList.length() > 0 )
        {
            pptHoldLotReqResult strHoldLotReqResult ;
            rc = txHoldLotReq(strHoldLotReqResult, strObjCommonIn, aLotID, strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList) ;  //D4100083
//D4100083        rc = txHoldLotReq(strHoldLotReqResult, strObjCommonIn, aLotID, strLot_futureHoldRequests_Effect_out.strLotHoldReqList) ;
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "txHoldLotReq() != RC_OK") ;
                strOpeLocateReqResult.strResult = strHoldLotReqResult.strResult ;
                return rc ;
            }
        }
    }//D4200190
//D4100083 Add Start
    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_SINGLE );

    rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                           strObjCommonIn,
                                                           aLotID,
                                                           strEffectCondition );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
        strOpeLocateReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
        return( rc );
    }

    if( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )
    {
        pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
        rc = txFutureHoldCancelReq(strFutureHoldCancelReqResult,
                                   strObjCommonIn,
                                   aLotID,
                                   releaseReasonCodeID,
                                   SP_EntryType_Remove,
                                   strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "txFutureHoldCancelReq() != RC_OK") ;
            strOpeLocateReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
            return(rc);
        }
    }
//D4100083 Add End

    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
    if(cassetteCheckFlag)                                                                                       //D4200062
    {                                                                                                           //D4200062
        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, aCassetteID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "cassette_multiLotType_Update() != RC_OK") ;
            strOpeLocateReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
            return(rc);
        }
    }                                                                                                           //D4200062

#if 1
//D4000016 Add Start
    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             aLotID );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strOpeLocateReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }
//D4000016 Add end
#endif

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = aLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = aCassetteID;
    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strOpeLocateReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        pptHoldLotReqResult strHoldLotReqResult;
        pptHoldListSequence strLotHoldReqList( 1 );
        strLotHoldReqList.length( 1 );

        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = claimMemo;

        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           aLotID,
                           strLotHoldReqList );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strOpeLocateReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End


//D4200029 Add Start
    //-------------------//
    // Process Hold      //
    //-------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                               strObjCommonIn,
                               lotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
        strOpeLocateReqResult.strResult = strProcessHoldExecReqResult.strResult ;
        return( rc );
    }
//D4200029 Add End

    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/
    objLotOperationMoveEvent_MakeLocate_out strLotOperationMoveEvent_MakeLocate_out;

//D9000010 Add Start

    if ( CIMFWStrCmp ( strObjCommonIn.transactionID, "TXTRC077" ) == 0 )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "if ( CIMFWStrCmp ( strObjCommonIn.transactionID, TXTRC077 ) == 0 )");

        rc = lotOperationMoveEvent_MakeLocate(strLotOperationMoveEvent_MakeLocate_out,
                                              strObjCommonIn,
                                              "TXTRC077",
                                              aLotID,
                                              locateDirection,
                                              strProcess_Locate_out.oldCurrentPOData,
                                              claimMemo) ;
    }
    else
    {

//D9000010 Add End

        rc = lotOperationMoveEvent_MakeLocate(strLotOperationMoveEvent_MakeLocate_out,
                                              strObjCommonIn,
                                              "TXTRC015",
                                              aLotID,
                                              locateDirection,
//D4100020                                    strProcess_Locate_out.oldCurrentPOS,
                                              strProcess_Locate_out.oldCurrentPOData,        //D4100020
                                              claimMemo) ;
    }                                                                                        //D9000010
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lotOperationMoveEvent_MakeLocate() != RC_OK") ;
//P5000145        PPT_SET_MSG_RC_KEY(strOpeLocateReqResult,MSG_FAIL_MAKE_HISTORY,rc,aLotID.identifier) ;
        SET_MSG_RC( strOpeLocateReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    if( strProcess_Locate_out.autoBankInFlag == TRUE )
    {
        objectIdentifierSequence lotIDx(1) ;
        lotIDx.length(1) ;
        lotIDx[0] = aLotID ;

        /*-----------------------------------------*/
        /*   Call txBankInReq() for Auto-Bank-In   */
        /*-----------------------------------------*/
        pptBankInReqResult strBankInReqResult ;
        strBankInReqResult.strBankInLotResult.length(1) ;
        rc = txBankInReq( strBankInReqResult , strObjCommonIn , 0 , lotIDx , claimMemo ) ;
        if( rc == RC_INVALID_LOT_HOLDSTAT )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq","txBankInReq == RC_INVALID_LOT_HOLDSTAT" ,rc) ;
//P5000145            PPT_SET_MSG_RC_KEY( strOpeLocateReqResult , MSG_OK , RC_OK , aLotID.identifier ) ;
            SET_MSG_RC( strOpeLocateReqResult , MSG_OK , RC_OK );        //P5000145
        }
        else if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeLocateReq","txBankInReq() != RC_OK" ,rc) ;
            strOpeLocateReqResult.strResult = strBankInReqResult.strResult ;
            return( rc );
        }
    }
    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strOpeLocateReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txOpeLocateReq") ;
    return(RC_OK);
}
