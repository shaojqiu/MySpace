#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txPartialReworkReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/5/07 14:05:20 [ 11/5/07 14:05:22 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txPartialReworkReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

// Class: CS_PPTManager
//
// Service: txPartialReworkReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2002/01/01 D4100021   Y.Nagamine     Initial Release
// 2002/01/21 D4100020   N.Maeda        Change oldCurrentPOS to oldCurrentPOData
// 2002/02/07 D4100083   T.Michii       Enhancement Future Hold
// 2002/02/19 D4100021-1 Y.Nagamine     TRUE -> 0
// 2002/02/21 D4100021-2 Y.Nagamine     Add transction ID logic
// 2002/02/22 D4100021-3 Y.Nagamine     Add check logic for first operation or not
// 2002/03/03 D4100021-4 Y.Nagamine     Change logic
// 2002/03/07 D4100021-5 T.Michii       Change & Add check logic
// 2002/03/12 D4100021-6 Y.Nagamine     Change message
// 2002/03/20 D4100021-7 T.Michii       Change logic 'Check first operation or not'
// 2002/06/03 D4100509   K.Kido         Add error handling logic.
// 2002/07/29 D4200029   K.Kimura       Process Hold Control
// 2002/11/13 P4200351   K.Matsuei      Add check return operation with Rework/Branch.
// 2003/01/16 P4200491   H.Adachi       Change Transaction ID for Operation History.
// 2003/05/30 D5000023   K.Kido         Wafer level control for Rework count (Rel5.0). Delete increment ReworkCount logic for parentLot.
// 2003/06/03 P5000060   K.Matsuei      TxReworkReq and TxBranchReq could not work correctly when These are called from Script.
// 2004/05/07 P5100188   M.Kase         Fix newWaferID and sourceWaferID for PosLotWaferMoveEvent.
// 2004/10/22 D6000025   K.Murakami     eBroker Migration.
// 2005/12/16 P7000058   Y.Kadowaki     Add check logic for carrier dispatch status.
// 2006/02/09 D7000173   H.Hasegawa     Add input parameter of process_OperationListForLot().
// 2006/11/01 D8000029   A.Tomari       Delete pptFutureHoldReqResult
// 2007/06/13 D9000005   H.Hotta        WaferSorter automation support.
// 2007/08/03 D9000056   H.Hotta        Add check logic for InPostProcessFlag.
// 2007/11/05 D9000001   K.Matsuei      64bit support.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/30 DSIV00000214 S.Miyata       Multi Fab Transfer Support
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2013/05/10 DSN000071674 Liuya          Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2014/07/29 DSN000085792 Sa Guo         Q-Time Improvements.
// 2015/11/11 DSN000096135 XF.Ming        process_OperationListForLot ==> process_OperationListForLot__160.
// 2017/02/08 DSN000104277 Q.Li           process_OperationListForLot__160 ==>  process_OperationProcessRefListForLot.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txPartialReworkReq
// 2017/09/12 INN-R170002  Thomas Song    Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptPartialReworkReqResult&        strPartialReworkReqResult
//    const pptObjCommonIn&             strObjCommonIn
//    const pptPartialReworkReq&        strPartialReworkReq,
//    const char *                      claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txPartialReworkReq (
    pptPartialReworkReqResult&      strPartialReworkReqResult,
    const pptObjCommonIn&           strObjCommonIn,
    const pptPartialReworkReq&      strPartialReworkReq,
//D6000025     const char *                    claimMemo,
//D6000025     CORBA::Environment &            IT_env)
    const char *                    claimMemo //D6000025
    CORBAENV_LAST_CPP)                        //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txPartialReworkReq ");
    CORBA::Long rc = RC_OK;

    PPT_METHODTRACE_V2("", "parentLotID           : ", strPartialReworkReq.parentLotID.identifier        ) ;
    PPT_METHODTRACE_V2("", "subRouteID            : ", strPartialReworkReq.subRouteID.identifier   ) ;
    PPT_METHODTRACE_V2("", "returnOperationNumber : ", strPartialReworkReq.returnOperationNumber   ) ;
    PPT_METHODTRACE_V2("", "reasonCodeID          : ", strPartialReworkReq.reasonCodeID.identifier ) ;
    PPT_METHODTRACE_V2("", "eventTxId             : ", strPartialReworkReq.eventTxId               ) ;
    PPT_METHODTRACE_V2("", "bForceRework          : ", strPartialReworkReq.bForceRework            ) ;
    PPT_METHODTRACE_V2("", "bDynamicRoute         : ", strPartialReworkReq.bDynamicRoute           ) ;

    //--------------------------------
    //   Lock objects to be updated
    //--------------------------------
    objLot_cassette_Get_out strLot_cassette_Get_out;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, strPartialReworkReq.parentLotID); // for Parent Lot
    if( rc )
    {
        PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK");
        strPartialReworkReqResult.strResult = strLot_cassette_Get_out.strResult;
        return(rc);
    }

    objObject_Lock_out strObject_Lock_out;

//DSN000071674 add start
    CORBA::String_var  txID;
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;

    if ( 0 == lotOperationEIcheck )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        strLot_cassette_Get_out.cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strPartialReworkReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       strLot_cassette_Get_out.cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strPartialReworkReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        if ( strPartialReworkReq.bForceRework == TRUE )
        {
            if ( strPartialReworkReq.bDynamicRoute == TRUE )
            {
                txID = CIMFWStrDup("TXEWC007");
            }
            else
            {
                txID = CIMFWStrDup("TXTRC047");
            }
        }
        else
        {
            if ( strPartialReworkReq.bDynamicRoute == TRUE )
            {
                txID = CIMFWStrDup("TXEWC006");
            }
            else
            {
                txID = CIMFWStrDup("TXTRC028");
            }
        }

        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( txID ); // TxPartialReworkReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strPartialReworkReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );
        if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
        {
            updateControlJobFlag = TRUE;

            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strPartialReworkReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = strLot_cassette_Get_out.cassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strPartialReworkReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strPartialReworkReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }
//PSN000083176        if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
//PSN000083176
//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            strLot_cassette_Get_out.cassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strPartialReworkReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;
//PSN000083176                if( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strPartialReworkReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end

    rc = object_Lock(strObject_Lock_out, strObjCommonIn, strLot_cassette_Get_out.cassetteID, SP_ClassName_PosCassette);  // for cassetteID returned from lot_cassette_Get()
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock(strLot_cassette_Get_out.cassetteID) != RC_OK");
        strPartialReworkReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

//PSN000083176 add start
    if ( 0 == lotOperationEIcheck )
    {
        if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            strLot_cassette_Get_out.cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strPartialReworkReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;
                if( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strPartialReworkReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end

    rc = object_Lock(strObject_Lock_out, strObjCommonIn, strPartialReworkReq.parentLotID, SP_ClassName_PosLot);  // for parent lot
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock(parentLotID) != RC_OK");
        strPartialReworkReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    //-------------------------------
    // Check lot transfer status
    //-------------------------------
    objLot_transferState_Get_out strLot_transferState_Get_out ;
//DSN000071674 add start
    if ( 1 == lotOperationEIcheck || ( 0 == lotOperationEIcheck && (0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn)) ) )
    {
//DSN000071674 add end
        rc = lot_transferState_Get(strLot_transferState_Get_out,strObjCommonIn,strPartialReworkReq.parentLotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strPartialReworkReqResult.strResult = strLot_transferState_Get_out.strResult ;
            return(rc);
        }

//DSN000071674 add start
        if ( 0 == lotOperationEIcheck )
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
            if ( 0 == CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )
            {
                PPT_METHODTRACE_V1("","Changed to EI by other operation");
                strPartialReworkReqResult.strResult = strLot_transferState_Get_out.strResult ;
                PPT_SET_MSG_RC_KEY(strPartialReworkReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                   strLot_cassette_Get_out.cassetteID.identifier);
                return( CS_RC_CAST_XFERSTATE_BE_CHANGED_BY_OTHER_OPERATION );
            }
        }
//DSN000071674 add end
        else if (CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 || CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
        {
            PPT_METHODTRACE_V1("","XFERSTAT is INVALID...");
            PPT_SET_MSG_RC_KEY2(strPartialReworkReqResult,
                                MSG_INVALID_LOT_XFERSTAT ,
                                RC_INVALID_LOT_XFERSTAT,
                                strPartialReworkReq.parentLotID.identifier,
                                strLot_transferState_Get_out.transferState);
            return( RC_INVALID_LOT_XFERSTAT );
        }
//DSN000071674 add start
    }
    if ( 0 == lotOperationEIcheck )
    {
        strLot_transferState_Get_out.transferState = strCassetteTransferState.transferState;
    }
//DSN000071674 add end

//DSIV00001830 add start
    //-------------------------
    // Check Bonding Group for parentLot
    //-------------------------
    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = strPartialReworkReq.parentLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strPartialReworkReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strPartialReworkReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    //-----------------------------------
    // Retrieve all state for parentLot
    //-----------------------------------
    objLot_allState_Get_out strLot_allState_Get_out;
    rc = lot_allState_Get(strLot_allState_Get_out, strObjCommonIn, strPartialReworkReq.parentLotID);
    if ( rc )
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() != RC_OK");
        strPartialReworkReqResult.strResult = strLot_allState_Get_out.strResult;
        return(rc);
    }

    //-----------------------------------
    // Check lot condition
    //-----------------------------------
    if (CIMFWStrCmp(strLot_allState_Get_out.holdState, CIMFW_Lot_HoldState_OnHold) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.holdState == CIMFW_Lot_HoldState_OnHold");
        SET_MSG_RC(strPartialReworkReqResult,
                   MSG_CANNOT_SPLIT_HELDLOT,
                   RC_CANNOT_SPLIT_HELDLOT);
        return( RC_CANNOT_SPLIT_HELDLOT );
    }
    if (CIMFWStrCmp(strLot_allState_Get_out.lotState, CIMFW_Lot_State_Active) != 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.lotState != CIMFW_Lot_State_Active");
        PPT_SET_MSG_RC_KEY(strPartialReworkReqResult,
                           MSG_INVALID_LOT_STAT,
                           RC_INVALID_LOT_STAT,
                           strLot_allState_Get_out.lotState);
        return( RC_INVALID_LOT_STAT );
    }
    if (CIMFWStrCmp(strLot_allState_Get_out.processState, SP_Lot_ProcState_Processing) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.processState == SP_Lot_ProcState_Processing");
        PPT_SET_MSG_RC_KEY2(strPartialReworkReqResult,
                            MSG_INVALID_LOT_PROCSTAT,
                            RC_INVALID_LOT_PROCSTAT,
                            strPartialReworkReq.parentLotID.identifier,
                            strLot_allState_Get_out.processState);
        return( RC_INVALID_LOT_PROCSTAT );
    }
    if (CIMFWStrCmp(strLot_allState_Get_out.productionState, CIMFW_Lot_ProductionState_InRework) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.productionState == CIMFW_Lot_ProductionState_InRework");
        PPT_SET_MSG_RC_KEY2(strPartialReworkReqResult,
                            MSG_INVALID_LOT_PRODSTAT,
                            RC_INVALID_LOT_PRODSTAT,
                            strPartialReworkReq.parentLotID.identifier,
                            strLot_allState_Get_out.productionState);
        return( RC_INVALID_LOT_PRODSTAT );
    }
    if (CIMFWStrCmp(strLot_allState_Get_out.inventoryState, SP_Lot_InventoryState_OnFloor) != 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.inventoryState != SP_Lot_InventoryState_OnFloor");
        PPT_SET_MSG_RC_KEY2(strPartialReworkReqResult,
                            MSG_INVALID_LOT_INVENTORYSTAT,
                            RC_INVALID_LOT_INVENTORYSTAT,
                            strPartialReworkReq.parentLotID.identifier,
                            strLot_allState_Get_out.inventoryState);
        return( RC_INVALID_LOT_INVENTORYSTAT );
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = strPartialReworkReq.parentLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strPartialReworkReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strPartialReworkReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strPartialReworkReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                strPartialReworkReq.parentLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

    //-----------------------------------
    // for parentLot
    //-----------------------------------
    objLot_contents_Get_out strLot_contents_Get_out;
    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn, strPartialReworkReq.parentLotID);
    if ( rc )
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get() != RC_OK");
        strPartialReworkReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }
    if (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer) != 0 &&
        CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Die  ) != 0 )
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get() !SP_ProdType_Wafer && !SP_ProdType_Die");
        PPT_SET_MSG_RC_KEY(strPartialReworkReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                           strPartialReworkReq.parentLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

    //---------------------------------
    //   Check Lot's Control Job ID
    //---------------------------------

    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, strPartialReworkReq.parentLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strPartialReworkReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strPartialReworkReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             strPartialReworkReq.parentLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }

//DSN000071674 add start
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
//P7000058 add start
        //-------------------------------
        // Check carrier dispatch status
        //-------------------------------
        objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
        strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE;
        rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn,
                                        strLot_cassette_Get_out.cassetteID);
        if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", "cassette_dispatchState_Get() dispatchReservedFlag == TRUE");
            strPartialReworkReqResult.strResult = strCassette_dispatchState_Get_out.strResult ;
            SET_MSG_RC(strPartialReworkReqResult, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST);
            return( RC_ALREADY_DISPATCH_RESVED_CST );
        }
//P7000058 add end
    } //DSN000071674

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyCastIDs, lotIDs;
    lotIDs.length(1);
    lotIDs[0] = strPartialReworkReq.parentLotID;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyCastIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = lotIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Lot);

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strPartialReworkReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

    //---------------------------------------------------------
    //   Converts input strPartialReworkReq.subrouteID if it has the version ##
    //---------------------------------------------------------
    objectIdentifier aSubRouteID ;

    objProcess_activeID_Get_out strProcess_activeID_Get_out ;
    rc = process_activeID_Get(strProcess_activeID_Get_out, strObjCommonIn, strPartialReworkReq.subRouteID);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_activeID_Get() != RC_OK") ;
        strPartialReworkReqResult.strResult = strProcess_activeID_Get_out.strResult ;
        return(rc);
    }

    aSubRouteID = strProcess_activeID_Get_out.activeID;

    PPT_METHODTRACE_V2("", "active subRouteID = ", aSubRouteID.identifier) ;

//D4100021-5 Add start
    //-----------------------------------
    //   Check first operation or not
    //-----------------------------------
    PPT_METHODTRACE_V1("", "Check first operation or not") ;

    CORBA::Boolean searchDirection = FALSE ;
    CORBA::Boolean posSearchFlag   = TRUE ;
    CORBA::Long searchCount        = 2 ;     //D4100021-7
    objectIdentifier   searchRouteID_dummy;                                                                           //D7000173
    CORBA::String_var  searchOperationNumber_dummy;                                                                   //D7000173
    CORBA::Boolean currentFlag     = TRUE ;  //D4100021-7
//D4100021-7    CORBA::Long searchCount        = 1 ;
//D4100021-7    CORBA::Boolean currentFlag     = FALSE ;

    searchRouteID_dummy.identifier = CIMFWStrDup( "" );                                                               //D7000173

//DSN000096135    objProcess_OperationListForLot_out strProcess_OperationListForLot_out ;
//DSN000096135    rc = process_OperationListForLot( strProcess_OperationListForLot_out, strObjCommonIn,
//DSN000096135                                      searchDirection, posSearchFlag, searchCount, searchRouteID_dummy,               //D7000173
//DSN000096135                                      searchOperationNumber_dummy, currentFlag, strPartialReworkReq.parentLotID );    //D7000173
//D7000173                                      searchDirection, posSearchFlag, searchCount, currentFlag, strPartialReworkReq.parentLotID ) ;

//DSN000104277//DSN000096135 add start
//DSN000104277    objProcess_OperationListForLot_out__160 strProcess_OperationListForLot_out;
//DSN000104277    objProcess_OperationListForLot_in__160 strProcess_OperationListForLot_in;
//DSN000104277    strProcess_OperationListForLot_in.searchDirection           = searchDirection;
//DSN000104277    strProcess_OperationListForLot_in.posSearchFlag             = posSearchFlag;
//DSN000104277    strProcess_OperationListForLot_in.searchCount               = searchCount;
//DSN000104277    strProcess_OperationListForLot_in.searchRouteID             = searchRouteID_dummy;
//DSN000104277    strProcess_OperationListForLot_in.searchOperationNumber     = CIMFWStrDup(searchOperationNumber_dummy);
//DSN000104277    strProcess_OperationListForLot_in.currentFlag               = currentFlag;
//DSN000104277    strProcess_OperationListForLot_in.lotID                     = strPartialReworkReq.parentLotID;
//DSN000104277    rc = process_OperationListForLot__160(strProcess_OperationListForLot_out, strObjCommonIn, strProcess_OperationListForLot_in);
//DSN000104277//DSN000096135 add end
//DSN000104277    if (rc != RC_OK)                                                                                                    //D4100509
//DSN000104277    {                                                                                                                   //D4100509
//DSN000104277//DSN000096135        PPT_METHODTRACE_V1("", "process_OperationListForLot() != RC_OK") ;             //D4100509
//DSN000104277        PPT_METHODTRACE_V1("", "process_OperationListForLot__160() != RC_OK") ;  //DSN000096135
//DSN000104277        strPartialReworkReqResult.strResult = strProcess_OperationListForLot_out.strResult ;                            //D4100509
//DSN000104277
//DSN000104277        return(rc);                                                                                                     //D4100509
//DSN000104277    }                                                                                                                   //D4100509
//DSN000104277
//DSN000104277    CORBA::Long lenNameAttributes = strProcess_OperationListForLot_out.strOperationNameAttributes.length();
//DSN000104277
//DSN000104277//D4100021-7    if ( lenNameAttributes == 0 )
//DSN000104277    if ( ( lenNameAttributes < 2 )                                                                                      //D4100021-7
//DSN000104277      || ( lenNameAttributes >= 2                                                                                       //D4100021-7
//DSN000104277        && 0 != CIMFWStrCmp( strProcess_OperationListForLot_out.strOperationNameAttributes[0].routeID.identifier,       //D4100021-7
//DSN000104277                             strProcess_OperationListForLot_out.strOperationNameAttributes[1].routeID.identifier ) ) )  //D4100021-7
//DSN000104277 add start
    objProcess_OperationProcessRefListForLot_out strProcess_OperationProcessRefListForLot_out;
    objProcess_OperationProcessRefListForLot_in strProcess_OperationProcessRefListForLot_in;
    strProcess_OperationProcessRefListForLot_in.searchDirection           = searchDirection;
    strProcess_OperationProcessRefListForLot_in.posSearchFlag             = posSearchFlag;
    strProcess_OperationProcessRefListForLot_in.searchCount               = searchCount;
    strProcess_OperationProcessRefListForLot_in.searchRouteID             = searchRouteID_dummy;
    strProcess_OperationProcessRefListForLot_in.searchOperationNumber     = CIMFWStrDup(searchOperationNumber_dummy);
    strProcess_OperationProcessRefListForLot_in.currentFlag               = currentFlag;
    strProcess_OperationProcessRefListForLot_in.lotID                     = strPartialReworkReq.parentLotID;
    rc = process_OperationProcessRefListForLot(strProcess_OperationProcessRefListForLot_out, strObjCommonIn, strProcess_OperationProcessRefListForLot_in);

    if (rc != RC_OK)                                                                                  
    {                                                                                                 
        PPT_METHODTRACE_V1("", "process_OperationProcessRefListForLot() != RC_OK") ;                  
        strPartialReworkReqResult.strResult = strProcess_OperationProcessRefListForLot_out.strResult ;
        return(rc);                                                                                   
    }                                                                                                 

    CORBA::Long lenNameAttributes = strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes.length();    
    if ( ( lenNameAttributes < 2 )                                                                                             
      || ( lenNameAttributes >= 2                                                                                                     
        && 0 != CIMFWStrCmp( strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes[0].routeID.identifier,     
                             strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes[1].routeID.identifier ) ) ) 
//DSN000104277 add end
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i::txPartialReworkReq", "lenNameAttributes == 0", lenNameAttributes );
        SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_REWORK_OPERATION ,RC_INVALID_REWORK_OPERATION);
        return( RC_INVALID_REWORK_OPERATION );
    }
//D4100021-5 Add End

    //-----------------------------------
    //   Check Route is Dynamic or Not
    //-----------------------------------
    if ( strPartialReworkReq.bDynamicRoute == TRUE )
    {
        objProcess_checkForDynamicRoute_out strProcess_checkForDynamicRoute_out;

        rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, aSubRouteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_checkForDynamicRoute() rc != RC_OK" ) ;
            strPartialReworkReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult ;
            return( rc );
        }

        if ( strProcess_checkForDynamicRoute_out.bDynamicRoute == FALSE )
        {
            PPT_METHODTRACE_V1("", "strProcess_checkForDynamicRoute_out.bDynamicRoute != strPartialReworkReqResult.bDynamicRoute" ) ;
            SET_MSG_RC( strPartialReworkReqResult, MSG_NOT_DYNAMIC_ROUTE ,RC_NOT_DYNAMIC_ROUTE) ; //D4100021-3
            return( RC_NOT_DYNAMIC_ROUTE );                                                       //D4100021-3
        }
//D4100021-5 Del start
//D4100021-3 start
//      CORBA::Boolean searchDirection = FALSE ;
//      CORBA::Boolean posSearchFlag   = TRUE ;
//      CORBA::Long searchCount        = 1 ;
//      CORBA::Boolean currentFlag     = FALSE ;
//
//      objProcess_OperationListForLot_out strProcess_OperationListForLot_out ;
//        rc = process_OperationListForLot(   strProcess_OperationListForLot_out, strObjCommonIn,
//                                            searchDirection, posSearchFlag, searchCount, currentFlag, strPartialReworkReq.parentLotID ) ;
//
//      CORBA::Long lenNameAttributes = strProcess_OperationListForLot_out.strOperationNameAttributes.length();
//      if ( lenNameAttributes == 0 )
//      {
//          PPT_METHODTRACE_V2("CS_PPTManager_i::txPartialReworkReq", "lenNameAttributes == 0", lenNameAttributes );
//          SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_REWORK_OPERATION ,RC_INVALID_REWORK_OPERATION);
//          return( RC_INVALID_REWORK_OPERATION );
//      }
//D4100021-3 end
//D4100021-5 Del End
    }

    //--------------------------------------
    //   Check Input return operation number
    //--------------------------------------
    CORBA::Boolean inputReturnOperationFlag = FALSE;
    CORBA::String_var returnOperationNumberVar;

    if( ( strPartialReworkReq.returnOperationNumber != NULL ) && ( CIMFWStrLen(strPartialReworkReq.returnOperationNumber)!=0 ) )
    {
        PPT_METHODTRACE_V1("", "Set inputReturnOperationFlag = TRUE" ) ;
        inputReturnOperationFlag = TRUE ;
    }

    //------------------------------------------------------------------------
    //   Check Input return operation number is exist in connected route list
    //------------------------------------------------------------------------
    CORBA::Boolean connectedRouteReturnOperationFlag = FALSE;
    CORBA::Boolean sameReturnOperationExistFlag = FALSE;

//P4200351 start
    objProcess_checkForDynamicRoute_out strProcess_checkForDynamicRoute_out;
    rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, aSubRouteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txPartialReworkReq", "process_checkForDynamicRoute() != RC_OK", rc);
        strPartialReworkReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult;
        return(rc);
    }
//D9000001    PPT_METHODTRACE_V2("CS_PPTManager_i:: txPartialReworkReq", "bDynamicRoute", (long)strProcess_checkForDynamicRoute_out.bDynamicRoute);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txPartialReworkReq", "bDynamicRoute", (CORBA::Long)strProcess_checkForDynamicRoute_out.bDynamicRoute); //D9000001
//P4200351 end

    objProcess_GetReturnOperation_out strProcess_GetReturnOperation_out;
    rc = process_GetReturnOperation( strProcess_GetReturnOperation_out, strObjCommonIn, strPartialReworkReq.parentLotID, aSubRouteID );

    if (rc == RC_NOT_FOUND_SUBROUTE )
    {
        PPT_METHODTRACE_V1("", "process_GetReturnOperation() == RC_NOT_FOUND_SUBROUTE") ;
    }
    else if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "Set connectedRouteReturnOperationFlag = TRUE") ;
        connectedRouteReturnOperationFlag = TRUE;

//D4100021-1        if ( CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, strPartialReworkReq.returnOperationNumber) ==TRUE )
        if ( CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, strPartialReworkReq.returnOperationNumber) == 0 ) //D4100021-1
        {
            PPT_METHODTRACE_V1("", "Set sameReturnOperationExistFlag = TRUE") ;
            sameReturnOperationExistFlag = TRUE;
        }
//P4200351 start
//P5000060        else if ( TRUE != strProcess_checkForDynamicRoute_out.bDynamicRoute )
        else if ( TRUE != strProcess_checkForDynamicRoute_out.bDynamicRoute && 0 < CIMFWStrLen(strPartialReworkReq.returnOperationNumber) ) //P5000060
        {
            PPT_METHODTRACE_V1("","return RC_INVALID_INPUT_PARM");
            SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }
//P4200351 end
    }
    else   // Error case
    {
        PPT_METHODTRACE_V2("", "process_GetReturnOperation() != RC_OK : ", rc) ;
        strPartialReworkReqResult.strResult = strProcess_GetReturnOperation_out.strResult ;
        return(rc);
    }


    //----------------------------------------------
    // Get Currrent Route ID and Operation Number
    //----------------------------------------------
    objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, strPartialReworkReq.parentLotID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK : ", rc) ;
        strPartialReworkReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
        return( rc );
    }
    PPT_METHODTRACE_V2("","currentRouteID         : ", strLot_currentOperationInfo_Get_out.routeID.identifier ) ;
    PPT_METHODTRACE_V2("","currentOperationNumber : ", strLot_currentOperationInfo_Get_out.operationNumber) ;

    //-------------------------------------------------
    // Decide return operation number using all flags
    //-------------------------------------------------
    if ( strPartialReworkReq.bDynamicRoute == TRUE )
    {
        PPT_METHODTRACE_V1("", "strPartialReworkReq.bDynamicRoute == TRUE") ;
        if ( inputReturnOperationFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "inputReturnOperationFlag == TRUE") ;
            returnOperationNumberVar = strPartialReworkReq.returnOperationNumber;
        }
        else  // inputReturnOperationFlag == FALSE
        {
            PPT_METHODTRACE_V1("", "inputReturnOperationFlag == FALSE") ;
            if ( connectedRouteReturnOperationFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;
            }
            else
            {
                PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strLot_currentOperationInfo_Get_out.operationNumber;
            }
        }
    }
    else  // strPartialReworkReq.bDynamicRoute == FALSE
    {
        PPT_METHODTRACE_V1("", "strPartialReworkReq.bDynamicRoute == FALSE") ;
//D4100021-5 Add Start
        if ( connectedRouteReturnOperationFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;

            if ( inputReturnOperationFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "inputReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strPartialReworkReq.returnOperationNumber;
            }
            else
            {
                PPT_METHODTRACE_V1("", "inputReturnOperationFlag ==FALSE" ) ;
                returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag ==FALSE" ) ;
//D4100021-6            SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//D4100021-6            return( RC_INVALID_BRANCH_ROUTEID );
            SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_ROUTE_ID,RC_INVALID_ROUTE_ID);//D4100021-6
            return( RC_INVALID_ROUTE_ID );                                                         //D4100021-6
        }
    }

//DSIV00000214 add start
    //---------------------------------------
    // Check interFabXferPlan existence
    //---------------------------------------
    objProcess_CheckInterFabXferPlanSkip_in strProcess_CheckInterFabXferPlanSkip_in;
    strProcess_CheckInterFabXferPlanSkip_in.lotID = strPartialReworkReq.parentLotID;
    strProcess_CheckInterFabXferPlanSkip_in.currentRouteID = strLot_currentOperationInfo_Get_out.routeID;
    strProcess_CheckInterFabXferPlanSkip_in.currentOpeNo = strLot_currentOperationInfo_Get_out.operationNumber;
    strProcess_CheckInterFabXferPlanSkip_in.jumpingRouteID = strLot_currentOperationInfo_Get_out.routeID;
    strProcess_CheckInterFabXferPlanSkip_in.jumpingOpeNo = strPartialReworkReq.returnOperationNumber;

    objProcess_CheckInterFabXferPlanSkip_out strProcess_CheckInterFabXferPlanSkip_out;
    rc = process_CheckInterFabXferPlanSkip( strProcess_CheckInterFabXferPlanSkip_out,
                                            strObjCommonIn,
                                            strProcess_CheckInterFabXferPlanSkip_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_CheckInterFabXferPlanSkip() != RC_OK");
        strPartialReworkReqResult.strResult = strProcess_CheckInterFabXferPlanSkip_out.strResult;
        return( rc );
    }
//DSIV00000214 add end

    //----------------------------------------------------
    //   Check ProcessDefinitionType is 'REWORK' or not
    //----------------------------------------------------
    PPT_METHODTRACE_V1("", "Check ProcessDefinitionType is 'REWORK' or not") ;

    if( CIMFWStrCmp( strProcess_GetReturnOperation_out.processDefinitionType, SP_MAINPDTYPE_REWORK ) != 0 )
    {
        PPT_METHODTRACE_V1("", "processDefinitionType != SP_MAINPDTYPE_REWORK") ;
//D4100021-6        SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//D4100021-6        return( RC_INVALID_BRANCH_ROUTEID );
        SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_ROUTE_TYPE,RC_INVALID_ROUTE_TYPE);//D4100021-6
        return( RC_INVALID_ROUTE_TYPE );                                                     //D4100021-6
    }

    //-----------------------------------------------------------
    //   Check decided return operation is exist on current route
    //-----------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check decided return operation is exist on current route") ;

    pptRouteOperationListForLotInqResult strRouteOperationListForLotInqResult;
    rc = txRouteOperationListForLotInq( strRouteOperationListForLotInqResult,
                                        strObjCommonIn,
                                        strPartialReworkReq.parentLotID);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txRouteOperationListForLotInq() != RC_OK" ) ;
        strPartialReworkReqResult.strResult = strRouteOperationListForLotInqResult.strResult ;
        return(rc);
    }

    PPT_METHODTRACE_V2("","returnOperationNumberVar : ", returnOperationNumberVar ) ;

    CORBA::Long opeLen = strRouteOperationListForLotInqResult.strOperationNameAttributes.length();

    for (CORBA::Long opeCnt=0; opeCnt < opeLen; opeCnt++ )
    {
        PPT_METHODTRACE_V2("","opeCnt : ", opeCnt ) ;
        PPT_METHODTRACE_V2("","strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber : ", strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber ) ;

        if( CIMFWStrCmp( strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber,
                         returnOperationNumberVar ) == 0 )
        {
            PPT_METHODTRACE_V1("", "return operation is exist on current route") ;
            break;
        }
        else if ( opeCnt == opeLen - 1 )
        {

            PPT_METHODTRACE_V1("", "opeCnt == opeLen - 1") ;
            PPT_SET_MSG_RC_KEY(strPartialReworkReqResult, MSG_NOT_FOUND_OPERATION, RC_NOT_FOUND_OPERATION, returnOperationNumberVar);
            return( RC_NOT_FOUND_OPERATION );
        }
    }
//D4100021-5 Add End
//D4100021-5 Del Start
//        if ( inputReturnOperationFlag ==TRUE )                                                                 //D4100021-3
//        {
//          PPT_METHODTRACE_V1("", "inputReturnOperationFlag ==TRUE") ;       //D4100021-3
//          returnOperationNumberVar = strPartialReworkReq.returnOperationNumber;                              //D4100021-3
//      }
//      else
//      {
////D4100021-4 start
//          if ( connectedRouteReturnOperationFlag == TRUE )
//          {
//                  PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;
//                returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;
//          }
//          else
////D4100021-4 end
//          {
//              PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag ==FALSE" ) ;
//              SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//              return( RC_INVALID_BRANCH_ROUTEID );
//          }
//      }
//  }
//
//
//  //-----------------------------------------------------------
//  //   Check decided return operation is exist on current route
//  //-----------------------------------------------------------
//  CORBA::Long searchCount = 1 ;
//  objProcess_operationListForRoute_out strProcess_operationListForRoute_out;
//  rc = process_operationListForRoute( strProcess_operationListForRoute_out,
//                                      strObjCommonIn,
//                                      strLot_currentOperationInfo_Get_out.routeID,
//                                      returnOperationNumberVar,
//                                      searchCount );
//  if( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1("", "process_operationListForRoute() != RC_OK" ) ;
//      strPartialReworkReqResult.strResult = strProcess_operationListForRoute_out.strResult ;
//      return(rc);
//  }
//D4100021-5 Del End
//    currentRouteID = strProcess_operationListForRoute_out.currentRouteID;

    /* ------------------------------------------------------------*/
    /* Check routeID confliction                                   */
    /*   return RC_INVALID_BRANCH_ROUTEID,                         */
    /*   when the same routeID is used in the following case       */
    /*       ex) Subroute --> The same SubRoute in the course      */
    /* ------------------------------------------------------------*/
    PPT_METHODTRACE_V1("", "lot_originalRouteList_Get IN ");
    objLot_originalRouteList_Get_out  strLot_originalRouteList_Get_out;
    rc = lot_originalRouteList_Get( strLot_originalRouteList_Get_out, strObjCommonIn, strPartialReworkReq.parentLotID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_originalRouteList_Get() != RC_OK", rc);
        strPartialReworkReqResult.strResult = strLot_originalRouteList_Get_out.strResult ;
        return( rc );
    }

    CORBA::Long kLen = strLot_originalRouteList_Get_out.originalRouteID.length();
    PPT_METHODTRACE_V2("", "strLot_originalRouteList_Get_out.originalRouteID.length=", kLen);

    //Check CurrentRoute VS SubRoute
    if(CIMFWStrCmp(strLot_currentOperationInfo_Get_out.routeID.identifier, aSubRouteID.identifier ) == 0)
    {
        PPT_METHODTRACE_V2("", "currentRouteID = subRouteID len =: ", kLen);
        SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
        return( RC_INVALID_BRANCH_ROUTEID );
    }

    //Check Afetr Route VS SubRoute
    for(CORBA::Long iLoop = 0;iLoop < kLen ;iLoop++)
    {
        PPT_METHODTRACE_V2("", "strLot_originalRouteList_Get_out.originalRouteID = ", strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier);

        if(CIMFWStrCmp(strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier,aSubRouteID.identifier ) == 0)
        {
            PPT_METHODTRACE_V2("", "OriginalRouteID[iLoop].identifier == subRouteID iLoop = ", iLoop);
            SET_MSG_RC( strPartialReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
            return( RC_INVALID_BRANCH_ROUTEID );
        }
    }

//D5000023    //-----------------------------------
//D5000023    // Check Rework Count if necessary
//D5000023    //-----------------------------------
//D5000023    if ( strPartialReworkReq.bForceRework == FALSE)
//D5000023    {
//D5000023        PPT_METHODTRACE_V1("", "bFourceRework == FALSE");
//D5000023
//D5000023        objProcess_reworkCount_Check_out strProcess_reworkCount_Check_out;
//D5000023        rc = process_reworkCount_Check(strProcess_reworkCount_Check_out, strObjCommonIn, strPartialReworkReq.parentLotID);
//D5000023        if( rc )
//D5000023        {
//D5000023            PPT_METHODTRACE_V1("", "process_reworkCount_Check() != RC_OK");
//D5000023            strPartialReworkReqResult.strResult = strProcess_reworkCount_Check_out.strResult;
//D5000023            return(rc);
//D5000023        }
//D5000023    }

    //-----------------------------------
    // Check for Future Hold
    //-----------------------------------
    PPT_METHODTRACE_V1("", "checkForLCFRRetCode != RC_OK");
    objLot_futureHoldRequests_CheckSplit_out strLot_futureHoldRequests_CheckSplit_out;
    rc = lot_futureHoldRequests_CheckSplit(strLot_futureHoldRequests_CheckSplit_out,
                                           strObjCommonIn,
                                           strPartialReworkReq.parentLotID,
                                           "",
                                           strPartialReworkReq.returnOperationNumber);
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_CheckSplit() != RC_OK");
        strPartialReworkReqResult.strResult = strLot_futureHoldRequests_CheckSplit_out.strResult;
        return(rc);
    }

    //-----------------------------------
    //  Split Lot
    //-----------------------------------
    objLot_SplitWaferLot_out strLot_SplitWaferLot_out;
    rc = lot_SplitWaferLot( strLot_SplitWaferLot_out,
                            strObjCommonIn,
                            strPartialReworkReq.parentLotID,
                            strPartialReworkReq.childWaferID);
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_SplitWaferLot() != RC_OK");
        strPartialReworkReqResult.strResult = strLot_SplitWaferLot_out.strResult;
        return(rc);
    }

    strPartialReworkReqResult.createdLotID = strLot_SplitWaferLot_out.childLotID;

//D5000023 add start
    //-----------------------------------
    // Check Rework Count if necessary
    //-----------------------------------
    if ( strPartialReworkReq.bForceRework == FALSE)
    {
        PPT_METHODTRACE_V1("", "bFourceRework == FALSE");

        objProcess_reworkCount_Check_out strProcess_reworkCount_Check_out;
        rc = process_reworkCount_Check(strProcess_reworkCount_Check_out, strObjCommonIn, strPartialReworkReqResult.createdLotID );
        if( rc )
        {
            PPT_METHODTRACE_V1("", "process_reworkCount_Check() != RC_OK");
            strPartialReworkReqResult.strResult = strProcess_reworkCount_Check_out.strResult;
            return(rc);
        }
    }
//D5000023 end start

//D5000023    //-----------------------------------
//D5000023    // Increment rework count of parent lot
//D5000023    //-----------------------------------
    objProcess_reworkCount_Increment_out strProcess_reworkCount_Increment_out;
//D5000023    rc = process_reworkCount_Increment( strProcess_reworkCount_Increment_out,
//D5000023                                        strObjCommonIn,
//D5000023                                        strPartialReworkReq.parentLotID );  // For parent Lot
//D5000023    if (rc)
//D5000023    {
//D5000023        PPT_METHODTRACE_V1("", "process_reworkCount_Increment(parentLotID) != RC_OK");
//D5000023        strPartialReworkReqResult.strResult = strProcess_reworkCount_Increment_out.strResult;
//D5000023        return(rc);
//D5000023    }

    //-----------------------------------
    // increment rework count of child lot
    //-----------------------------------
    rc = process_reworkCount_Increment(strProcess_reworkCount_Increment_out,
                                       strObjCommonIn,
                                       strPartialReworkReqResult.createdLotID);   // For child Lot
    if( rc )
    {
        PPT_METHODTRACE_V1("", "process_reworkCount_Increment(childLotID) != RC_OK");
        strPartialReworkReqResult.strResult = strProcess_reworkCount_Increment_out.strResult;
        return(rc);
    }
//DSN000085792 Add start
    objQTime_CheckConditionForReplaceTarget_in strQTime_CheckConditionForReplaceTarget_in;
    objQTime_CheckConditionForReplaceTarget_out strQTime_CheckConditionForReplaceTarget_out;
    strQTime_CheckConditionForReplaceTarget_in.lotID = strPartialReworkReqResult.createdLotID;
    rc = qTime_CheckConditionForReplaceTarget(strQTime_CheckConditionForReplaceTarget_out,strObjCommonIn,strQTime_CheckConditionForReplaceTarget_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "qTime_CheckConditionForReplaceTarget() != RC_OK") ;
        strPartialReworkReqResult.strResult = strQTime_CheckConditionForReplaceTarget_out.strResult ;
        return rc ;
    }
//DSN000085792 Add end
    //-----------------------------------
    // Branch child lot to sub route
    //-----------------------------------
    objProcess_BranchRoute_out strProcess_BranchRoute_out;
    rc = process_BranchRoute(strProcess_BranchRoute_out,
                             strObjCommonIn,
                             strPartialReworkReqResult.createdLotID,
                             aSubRouteID,
                             returnOperationNumberVar);   // For child Lot
    if( rc )
    {
        PPT_METHODTRACE_V1("", "process_BranchRoute() != RC_OK");
        strPartialReworkReqResult.strResult = strProcess_BranchRoute_out.strResult;
        return(rc);
    }

    //-----------------------------------
    // Check parent lot's situation
    // with Route Process Flow point of view
    //-----------------------------------
    objProcess_CompareCurrent_out strProcess_CompareCurrent_out;
    rc = process_CompareCurrent(strProcess_CompareCurrent_out,
                                strObjCommonIn,
                                strPartialReworkReq.parentLotID,
                                aSubRouteID,
                                returnOperationNumberVar);   // For parent Lot

    objectIdentifier reasonCodeID1;
    reasonCodeID1.identifier = CIMFWStrDup(SP_Reason_ReworkHold);

//D8000029    pptFutureHoldReqResult strFutureHoldReqResult;

    CORBA::String_var  extendedCurrentOperationNumber;
    CORBA::String_var  extendedReturnOperationNumber;

    if (rc == RC_CURRENTOPERATION_SAME || rc == RC_CURRENTOPERATION_LATE)
    {
        PPT_METHODTRACE_V1("", "rc == RC_CURRENTOPERATION_SAME || rc == RC_CURRENTOPERATION_LATE");

        pptHoldListSequence strLotHoldReqList;
        strLotHoldReqList.length(1);

        strLotHoldReqList[0].holdType                   = CIMFWStrDup( SP_HoldType_ReworkHold );
        strLotHoldReqList[0].holdReasonCodeID           = reasonCodeID1;
        strLotHoldReqList[0].holdUserID                 = strObjCommonIn.strUser.userID ;
        strLotHoldReqList[0].responsibleOperationMark   = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].routeID                    = aSubRouteID ;
        strLotHoldReqList[0].operationNumber            = CIMFWStrDup( returnOperationNumberVar );
        strLotHoldReqList[0].relatedLotID               = strPartialReworkReqResult.createdLotID;

        //-----------------------------------
        // Hold parent lot
        //-----------------------------------
        pptHoldLotReqResult strHoldLotReqResult;
        rc = txHoldLotReq(strHoldLotReqResult,
                          strObjCommonIn,
                          strPartialReworkReq.parentLotID,
                          strLotHoldReqList) ;
        if ( rc )
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
            strPartialReworkReqResult.strResult = strHoldLotReqResult.strResult;
            return(rc);
        }

        //-----------------------------------
        // Register Future Hold Record for parent lot
        //-----------------------------------
//        PPT_METHODTRACE_V2("", "checkForLCFRRetCode != RC_OK", checkForLCFRRetCode);
        extendedCurrentOperationNumber = strProcess_CompareCurrent_out.currentOperationNumber;
        extendedReturnOperationNumber  = returnOperationNumberVar;

//        PPT_METHODTRACE_V2("", "extendedCurrentOperationNumber ", extendedCurrentOperationNumber);
//        PPT_METHODTRACE_V2("", "extendedReturnOperationNumber  ", extendedReturnOperationNumber);

//D4100083        pptFutureHoldReqResult strFutureHoldReqResult;
//D4100083        rc = txFutureHoldReq(strFutureHoldReqResult, strObjCommonIn,
//D4100083                             SP_HoldType_ReworkHold,
//D4100083                             strPartialReworkReq.parentLotID,
//D4100083                             strProcess_CompareCurrent_out.currentRouteID,
//D4100083                             extendedCurrentOperationNumber,
//D4100083                             reasonCodeID1,
//D4100083                             strPartialReworkReqResult.createdLotID,
//D4100083                             NULL);
//D4100083 Add Start
        pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
        rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
                                      strObjCommonIn ,
                                      SP_HoldType_ReworkHold ,
                                      strPartialReworkReq.parentLotID,
                                      strProcess_CompareCurrent_out.currentRouteID,
                                      extendedCurrentOperationNumber,
                                      reasonCodeID1,
                                      strPartialReworkReqResult.createdLotID,
                                      FALSE,
                                      FALSE,
                                      NULL ) ;
//D4100083 Add End
            //  Input parameter
            //    - SP_HoldType_ReworkHold
            //    - parentLotID
            //    - strProcess_CompareCurrent_out.currentRouteID
            //    - extendedCurrentOperationNumber    //P3100043
            //    - reasonCodeID1
            //    - strPartialReworkReq.childLotID
            //    - FALSE    //D4100083
            //    - FALSE    //D4100083
            //    - NULL

//D4100083        if ( rc == RC_OK )
//D4100083        {
//D4100083            PPT_METHODTRACE_V1("", "txFutureHoldReq() rc == RC_OK");

            //-----------------------------------
            // Register Future Hold Record for child lot
            //-----------------------------------
//D4100083            rc = txFutureHoldReq(strFutureHoldReqResult, strObjCommonIn,
//D4100083                                 SP_HoldType_ReworkHold,
//D4100083                                 strPartialReworkReqResult.createdLotID,
//D4100083                                 strProcess_CompareCurrent_out.currentRouteID,
//D4100083                                 extendedCurrentOperationNumber,    //P3100043
//D4100083                                 reasonCodeID1,
//D4100083                                 strPartialReworkReq.parentLotID,
//D4100083                                 NULL);
//D4100083 Add Start
        if ( rc == RC_OK || rc == RC_DUPLICATE_FTHOLD_ENTRY)
        {
            PPT_METHODTRACE_V1("", "txFutureHoldReq() rc == RC_OK or RC_DUPLICATE_FTHOLD_ENTRY");
            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
                                          strObjCommonIn ,
                                          SP_HoldType_ReworkHold,
                                          strPartialReworkReqResult.createdLotID,
                                          strProcess_CompareCurrent_out.currentRouteID,
                                          extendedCurrentOperationNumber,    //P3100043
                                          reasonCodeID1,
                                          strPartialReworkReq.parentLotID,
                                          FALSE,
                                          FALSE,
                                          NULL ) ;
//D4100083 Add End
                //  Input parameter
                //    - SP_HoldType_ReworkHold
                //    - childLotID
                //    - strProcess_CompareCurrent_out.currentRouteID
                //    - extendedCurrentOperationNumber    //P3100043
                //    - reasonCodeID1
                //    - parentLotID
                //    - FALSE    //D4100083
                //    - FALSE    //D4100083
                //    - NULL
        }

        if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )  //D4100083
//D4100083        if ( rc )
        {
            PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY");
//D4100083            PPT_METHODTRACE_V1("", "txFutureHoldReq() != RC_OK");
            strPartialReworkReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;  //D4100083
//D4100083            strPartialReworkReqResult.strResult = strFutureHoldReqResult.strResult;
            return(rc);
        }
    }
    else if ( rc == RC_CURRENTOPERATION_EARLY )
    {
        PPT_METHODTRACE_V1("", "rc == RC_CURRENTOPERATION_EARLY");

//        PPT_METHODTRACE_V2("", "checkForLCFRRetCode != RC_OK", checkForLCFRRetCode);
        extendedCurrentOperationNumber = strProcess_CompareCurrent_out.currentOperationNumber;
        extendedReturnOperationNumber  = returnOperationNumberVar;

        PPT_METHODTRACE_V2("", "extendedCurrentOperationNumber ", extendedCurrentOperationNumber);
        PPT_METHODTRACE_V2("", "extendedReturnOperationNumber  ", extendedReturnOperationNumber);

        //-----------------------------------
        // Register Future Hold Record for parent lot
        //-----------------------------------
//D4100083        rc = txFutureHoldReq(strFutureHoldReqResult,
//D4100083                             strObjCommonIn,
//D4100083                             SP_HoldType_ReworkHold,
//D4100083                             strPartialReworkReq.parentLotID,
//D4100083                             strProcess_CompareCurrent_out.currentRouteID,
//D4100083                             extendedReturnOperationNumber,    //P3100043
//D4100083                             reasonCodeID1,
//D4100083                             strPartialReworkReqResult.createdLotID,
//D4100083                             NULL);
//D4100083 Add Start
        pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
        rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
                                      strObjCommonIn ,
                                      SP_HoldType_ReworkHold,
                                      strPartialReworkReq.parentLotID,
                                      strProcess_CompareCurrent_out.currentRouteID,
                                      extendedReturnOperationNumber,    //P3100043
                                      reasonCodeID1,
                                      strPartialReworkReqResult.createdLotID,
                                      FALSE,
                                      FALSE,
                                      NULL ) ;
//D4100083 Add End
            //  Input Parameter
            //      - SP_HoldType_ReworkHold
            //      - parentLotID
            //      - strProcess_CompareCurrent_out.currentRouteID
            //      - extendedReturnOperationNumber          //P3100043
            //      - reasonCodeID1
            //      - strPartialReworkReq.childLotID
            //      - FALSE    //D4100083
            //      - FALSE    //D4100083
            //      - NULL

//D4100083        if( rc == RC_OK )
//D4100083        {
//D4100083            PPT_METHODTRACE_V1("", "txFutureHoldReq() rc == RC_OK");

            //-----------------------------------
            // Register Future Hold Record for child lot
            //-----------------------------------
//D4100083            rc = txFutureHoldReq(strFutureHoldReqResult, strObjCommonIn,
//D4100083                                 SP_HoldType_ReworkHold,
//D4100083                                 strPartialReworkReqResult.createdLotID,
//D4100083                                 strProcess_CompareCurrent_out.currentRouteID,
//D4100083                                 extendedReturnOperationNumber,    //P3100043
//D4100083                                 reasonCodeID1,
//D4100083                                 strPartialReworkReq.parentLotID,
//D4100083                                 NULL);
//D4100083 Add Start
        if ( rc == RC_OK || rc == RC_DUPLICATE_FTHOLD_ENTRY)
        {
            PPT_METHODTRACE_V1("", "txFutureHoldReq() rc == RC_OK or RC_DUPLICATE_FTHOLD_ENTRY");
            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
                                          strObjCommonIn ,
                                          SP_HoldType_ReworkHold,
                                          strPartialReworkReqResult.createdLotID,
                                          strProcess_CompareCurrent_out.currentRouteID,
                                          extendedReturnOperationNumber,    //P3100043
                                          reasonCodeID1,
                                          strPartialReworkReq.parentLotID,
                                          FALSE,
                                          FALSE,
                                          NULL ) ;
//D4100083 Add End
                //  Input parameter
                //      - SP_HoldType_ReworkHold
                //      - strPartialReworkReq.childLotID
                //      - strProcess_CompareCurrent_out.currentRouteID
                //      - extendedReturnOperationNumber    //P3100043
                //      - reasonCodeID1
                //      - parentLotID
                //      - FALSE    //D4100083
                //      - FALSE    //D4100083
                //      - NULL
        }

        if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )  //D4100083
//D4100083        if ( rc )
        {
            PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY");  //D4100083
//D4100083            PPT_METHODTRACE_V1("", "txFutureHoldReq() != RC_OK");
            strPartialReworkReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;  //D4100083
//D4100083            strPartialReworkReqResult.strResult = strFutureHoldReqResult.strResult;
            return(rc);
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "process_CompareCurrent() != RC_OK");
        strPartialReworkReqResult.strResult = strProcess_CompareCurrent_out.strResult;
        return(rc);
    }

//DSN000071674 add start
    if ( TRUE == updateControlJobFlag )
    {
        //----------------------
        // Update control Job Info and
        // Machine Cassette info if information exist
        //----------------------
        objectIdentifierSequence tmpCassetteIDSeq;
        tmpCassetteIDSeq.length(1);
        tmpCassetteIDSeq[0] = strLot_cassette_Get_out.cassetteID;
        objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
        rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                           tmpCassetteIDSeq);
        if (rc)
        {
            PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
            strPartialReworkReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
            return(rc);
        }
    }
//DSN000071674 add end

//DSIV00001830 add start
    //-------------------------
    // Check Bonding Group for childLot
    //-------------------------
    PPT_METHODTRACE_V2("", "strProcess_CompareCurrent_out.currentRouteID", strProcess_CompareCurrent_out.currentRouteID.identifier);
    PPT_METHODTRACE_V2("", "returnOperationNumberVar", returnOperationNumberVar);
//DSN000096135    rc  = process_OperationListForLot( strProcess_OperationListForLot_out,
//DSN000096135                                       strObjCommonIn,
//DSN000096135                                       TRUE,                                         // search direction
//DSN000096135                                       TRUE,                                         // posSearchFlag
//DSN000096135                                       9999,                                         // search count
//DSN000096135                                       strProcess_CompareCurrent_out.currentRouteID, // search routeID
//DSN000096135                                       returnOperationNumberVar,                     // search operation Number
//DSN000096135                                       TRUE,                                         // currentFlag
//DSN000096135                                       strPartialReworkReq.parentLotID );
//DSN000104277//DSN000096135 add start
//DSN000104277    objProcess_OperationListForLot_in__160 strProcess_OperationListForLot_in_1;
//DSN000104277    strProcess_OperationListForLot_in_1.searchDirection           = TRUE;
//DSN000104277    strProcess_OperationListForLot_in_1.posSearchFlag             = TRUE;
//DSN000104277    strProcess_OperationListForLot_in_1.searchCount               = 9999;
//DSN000104277    strProcess_OperationListForLot_in_1.searchRouteID             = strProcess_CompareCurrent_out.currentRouteID;
//DSN000104277    strProcess_OperationListForLot_in_1.searchOperationNumber     = CIMFWStrDup(returnOperationNumberVar);
//DSN000104277    strProcess_OperationListForLot_in_1.currentFlag               = TRUE;
//DSN000104277    strProcess_OperationListForLot_in_1.lotID                     = strPartialReworkReq.parentLotID;
//DSN000104277    rc = process_OperationListForLot__160(strProcess_OperationListForLot_out, strObjCommonIn, strProcess_OperationListForLot_in_1);
//DSN000104277//DSN000096135 add end
//DSN000104277    if( rc != RC_OK )
//DSN000104277    {
//DSN000104277//DSN000096135        PPT_METHODTRACE_V1("", "process_OperationListForLot() != RC_OK") ;
//DSN000104277        PPT_METHODTRACE_V1("", "process_OperationListForLot__160() != RC_OK") ;      //DSN000096135
//DSN000104277        strPartialReworkReqResult.strResult = strProcess_OperationListForLot_out.strResult;
//DSN000104277 add start
    objProcess_OperationProcessRefListForLot_in strProcess_OperationProcessRefListForLot_in_1;
    strProcess_OperationProcessRefListForLot_in_1.searchDirection           = TRUE;
    strProcess_OperationProcessRefListForLot_in_1.posSearchFlag             = TRUE;
    strProcess_OperationProcessRefListForLot_in_1.searchCount               = 9999;
    strProcess_OperationProcessRefListForLot_in_1.searchRouteID             = strProcess_CompareCurrent_out.currentRouteID;
    strProcess_OperationProcessRefListForLot_in_1.searchOperationNumber     = CIMFWStrDup(returnOperationNumberVar);
    strProcess_OperationProcessRefListForLot_in_1.currentFlag               = TRUE;
    strProcess_OperationProcessRefListForLot_in_1.lotID                     = strPartialReworkReq.parentLotID;
    rc = process_OperationProcessRefListForLot(strProcess_OperationProcessRefListForLot_out, strObjCommonIn, strProcess_OperationProcessRefListForLot_in_1);

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_OperationProcessRefListForLot() != RC_OK") ;                   
        strPartialReworkReqResult.strResult = strProcess_OperationProcessRefListForLot_out.strResult;  
//DSN000104277 add end

        return rc;
    }
//DSN000104277    CORBA::ULong operationCountForLot = strProcess_OperationListForLot_out.strOperationNameAttributes.length();
    CORBA::ULong operationCountForLot = strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes.length();    //DSN000104277
    if( operationCountForLot >= 1 )
    {
        objLot_bondingFlowSection_CheckLocate_out strLot_bondingFlowSection_CheckLocate_out;
        rc = lot_bondingFlowSection_CheckLocate( strLot_bondingFlowSection_CheckLocate_out,
                                                 strObjCommonIn,
                                                 strLot_SplitWaferLot_out.childLotID,
                                                 strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes[operationCountForLot-1].processRef );  //DSN000104277
//DSN000104277                                                 strProcess_OperationListForLot_out.strOperationNameAttributes[operationCountForLot-1].processRef );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_bondingFlowSection_CheckLocate() rc != RC_OK");
            strPartialReworkReqResult.strResult = strLot_bondingFlowSection_CheckLocate_out.strResult;
            return rc;
        }
    }
//DSIV00001830 add end

//P3100371 start
    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, strLot_cassette_Get_out.cassetteID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
        strPartialReworkReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
        return(rc);
    }
//P3100371 end

    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             strPartialReworkReqResult.createdLotID );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strPartialReworkReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }

//D4200029 Add Start

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = strPartialReworkReqResult.createdLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = strLot_cassette_Get_out.cassetteID;
    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strPartialReworkReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        pptHoldLotReqResult strHoldLotReqResult;
        pptHoldListSequence strLotHoldReqList( 1 );
        strLotHoldReqList.length( 1 );

        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = claimMemo;

        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           strPartialReworkReqResult.createdLotID,
                           strLotHoldReqList );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strPartialReworkReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End

    //-------------------------------------//
    //     Process Hold for Child Lot      //
    //-------------------------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq() for Child Lot");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult_Child;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult_Child,
                               strObjCommonIn,
                               strPartialReworkReqResult.createdLotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() for Child Lot != RC_OK", rc );
        strPartialReworkReqResult.strResult = strProcessHoldExecReqResult_Child.strResult ;
        return( rc );
    }
//D4200029 Add End

//DSN000085792 Add Start
    //--------------------------------------------------------------------------------------------------
    // Replace Target Operation for rework route
    //--------------------------------------------------------------------------------------------------
    objQTime_targetOpe_Replace_out strQTime_targetOpe_Replace_out;
    objQTime_targetOpe_Replace_in  strQTime_targetOpe_Replace_in;
    strQTime_targetOpe_Replace_in.lotID               = strPartialReworkReqResult.createdLotID;
    strQTime_targetOpe_Replace_in.specificControlFlag = FALSE;
    rc = qTime_targetOpe_Replace( strQTime_targetOpe_Replace_out,
                                  strObjCommonIn,
                                  strQTime_targetOpe_Replace_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "qTime_targetOpe_Replace() != RC_OK", rc);
        strPartialReworkReqResult.strResult = strQTime_targetOpe_Replace_out.strResult;
        return rc;
    }
//DSN000085792 Add End

    //------------------------------------------------------------------------
    //   Make History
    //------------------------------------------------------------------------
    objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                           strPartialReworkReq.parentLotID);    // for parent Lot
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
        SET_MSG_RC(strPartialReworkReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return( rc );
    }

    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                           strPartialReworkReqResult.createdLotID);    // for child lot(strPartialReworkReqResult.createdLotID)
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
        SET_MSG_RC(strPartialReworkReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return( rc );
    }

    //-----------------------------------
    // Create History Data
    //-----------------------------------

//D4100021-2 add
    //--------------------------------
    //   Decide TX_ID
    //--------------------------------

    CORBA::String_var  strTransactionID;

//P4200491    if ( CIMFWStrLen(strPartialReworkReq.eventTxId) >0 )
//P4200491    {
//P4200491        strTransactionID = strPartialReworkReq.eventTxId;
//P4200491        PPT_METHODTRACE_V2("", "TX ID (Use Input TX ID )   : ", strTransactionID      ) ;
//P4200491    }
//P4200491    else
//P4200491    {

    if ( strPartialReworkReq.bForceRework == TRUE )
    {
        if ( strPartialReworkReq.bDynamicRoute == TRUE )
        {
            strTransactionID = CIMFWStrDup("TXEWC007");
            PPT_METHODTRACE_V2("", "TX ID (Special Dynamic Partial Rework) : ", strTransactionID      ) ;
        }
        else
        {
            strTransactionID = CIMFWStrDup("TXTRC047");
            PPT_METHODTRACE_V2("", "TX ID (Special Partial Rework) : ", strTransactionID      ) ;
        }
    }
    else
    {
        if ( strPartialReworkReq.bDynamicRoute == TRUE )
        {
            strTransactionID = CIMFWStrDup("TXEWC006");
            PPT_METHODTRACE_V2("", "TX ID ( Dynamic Partial Rework) : ", strTransactionID      ) ;
        }
        else
        {
            strTransactionID = CIMFWStrDup("TXTRC028");
            PPT_METHODTRACE_V2("", "TX ID ( Partial Rework ) : ", strTransactionID      ) ;
        }
    }

//P4200491    }
//D4100021-2 end



    objLot_waferMap_Get_out strLot_waferMap_Get_out;
    rc = lot_waferMap_Get(strLot_waferMap_Get_out, strObjCommonIn,
                          strPartialReworkReqResult.createdLotID);     // for child lot
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_waferMap_Get() != RC_OK");
        strPartialReworkReqResult.strResult = strLot_waferMap_Get_out.strResult;
        return(rc);
    }

    CORBA::Long i = 0;
    CORBA::Long nLen = strLot_waferMap_Get_out.strLotWaferMap.length();
    pptNewLotAttributes strNewLotAttributes;
    strNewLotAttributes.cassetteID = strLot_cassette_Get_out.cassetteID;
    strNewLotAttributes.strNewWaferAttributes.length(nLen) ;
    PPT_METHODTRACE_V2("", "nLen", nLen);
    for (i=0 ; i<nLen; i++)
    {
        strNewLotAttributes.strNewWaferAttributes[i].newLotID       = strLot_SplitWaferLot_out.childLotID;
//P5100188        strNewLotAttributes.strNewWaferAttributes[i].newWaferID     = strPartialReworkReq.childWaferID[i];
        strNewLotAttributes.strNewWaferAttributes[i].newWaferID     = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;  //P5100188
        strNewLotAttributes.strNewWaferAttributes[i].newSlotNumber  = strLot_waferMap_Get_out.strLotWaferMap[i].slotNumber;
        strNewLotAttributes.strNewWaferAttributes[i].sourceLotID    = strPartialReworkReq.parentLotID;
//P5100188        strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID  = strPartialReworkReq.childWaferID[i];
        strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID  = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;  //P5100188

        PPT_METHODTRACE_V2("", "newLotID",      strLot_SplitWaferLot_out.childLotID.identifier);
//P5100188        PPT_METHODTRACE_V2("", "newWaferID",    strPartialReworkReq.childWaferID[i].identifier);
        PPT_METHODTRACE_V2("", "newWaferID",    strLot_waferMap_Get_out.strLotWaferMap[i].waferID.identifier);  //P5100188
        PPT_METHODTRACE_V2("", "newSlotNumber", strLot_waferMap_Get_out.strLotWaferMap[i].slotNumber);
        PPT_METHODTRACE_V2("", "sourceLotID",   strPartialReworkReq.parentLotID.identifier);
//P5100188        PPT_METHODTRACE_V2("", "sourceWaferID", strPartialReworkReq.childWaferID[i].identifier);
        PPT_METHODTRACE_V2("", "sourceWaferID", strLot_waferMap_Get_out.strLotWaferMap[i].waferID.identifier);  //P5100188
    }

    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make(strLotWaferMoveEvent_Make_out, strObjCommonIn,
                                strTransactionID, strNewLotAttributes, claimMemo);
        //      - use strTransactionID
        //  strNewLotAttributes.cassetteID = cassetteID which is returned from lot_cassette_Get()
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].newLotID = childLotID which is returned from lot_SplitWaferLot()
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].newWaferID = childWaferID[]
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].newSlotNumber = slot number which is returned from lot_waferMap_Get()
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].sourceLotID = parentLotID
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].sourceWaferID = childWaferID[]
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lotWaferMoveEvent_Make() rc != RC_OK");
        strPartialReworkReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult;
        SET_MSG_RC(strPartialReworkReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return( rc );
    }

    objLotReworkEvent_Make_out strLotReworkEvent_Make_out;
    rc = lotReworkEvent_Make(strLotReworkEvent_Make_out, strObjCommonIn,
                             strTransactionID,
                             strLot_SplitWaferLot_out.childLotID,
                             strPartialReworkReq.reasonCodeID,
//                           strProcess_BranchRoute_out.oldCurrentPOS,                              //D4100020 Delete
                             strProcess_BranchRoute_out.oldCurrentPOData,                           //D4100020 Add
                             claimMemo);
        //  Input parameter
        //      - use strTransactionID
        //      - childLotID
        //      - reasonCodeID
        //      - strProcess_BranchRoute_out.oldCurrentPOS
        //      - claimMemo
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lotReworkEvent_Make() rc != RC_OK");
        strPartialReworkReqResult.strResult = strLotReworkEvent_Make_out.strResult;
        SET_MSG_RC(strPartialReworkReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return( rc );
    }

    //------------------------------------------------------------------------
    //   Return
    //------------------------------------------------------------------------
    SET_MSG_RC(strPartialReworkReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txPartialReworkReq ")
    return RC_OK ;
}

