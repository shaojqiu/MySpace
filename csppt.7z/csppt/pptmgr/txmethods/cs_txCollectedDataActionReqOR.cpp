#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/txCollectedDataActionReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:15:49 [ 7/13/07 21:15:50 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txCollectedDataActionReqOR.cpp
//

//INN-R170009 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-R170009

// Class: CS_PPTManager
//
// Service: txCollectedDataActionReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2006/02/28 D7000178 M.Murata       Initial Release (R701)
// 2006/04/12 P7000126 H.Mutoh        Fix number of cases of Mail and same Contents.
// 2006/07/11 P7000348 M.Kase         Call process_dataCollectionInformation_Update method finally.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/03 DSIV00000214 H.Mutoh        Multi Fab Transfer Support.
// 2009/09/07 DSIV00001021 H.Nonaka       Multiple Corresponding Operations Support
// 2009/10/02 DSIV00001365 R.Okano        Entity Inhibit Improvement. (R101)
// 2010-04-20 DSIV00001830 R.Iriguchi     Wafer Stacking Operation Support.
// 2010-06-22 PSIV00002109 R.Iriguchi     Remove unnecessary Code in DSIV00001830.
// 2011/09/09 DSN000015229 K.Yamaoku      Advanced Wafer Level Control support
// 2013/09/06 DSN000081739 Sa Guo         Equipment Monitor Automation Support
// 2015/09/15 DSN000096135 T.Ishida       Virtual Operation
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/18 INN-R170009  Qufd           Send Data Collection to APC
//
// Description:
//This function performs SPEC Check and SPC Check, and performs action to the entities specified based on the check result.
//The actions are Entity Inhibition and Hold.
//If the target Lot belongs to Monitor Group and it is the representative Lot,
//the Monitor Group and Hold of Monitored Lot are released according to a setup of the previous operation of Lot.
//And then, if the monitored Lot's operation which moved by Hold release is measurement, measurement operation is passed.
//At last, PO's collected data information is stored with data conversion.    //P7000348
//
// Return:
//     long
//
// Parameter:
// pptCollectedDataActionReqResult&       strCollectedDataActionReqResult
// const pptObjCommonIn&                  strObjCommonIn
// const pptCollectedDataActionReqInParm& strCollectedDataActionReqInParm
// const char*                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//DSN000015229 Add start
//-------------------------------------------
// Temporary LotInCassette index struct
//-------------------------------------------
typedef struct tmpLotInCassetteIndex_struct
{
    longSequence*  specCheckIndexSeq;
    CORBA::ULong   specCheckIndexLen;
} tmpLotInCassetteIndex;

//-------------------------------------------
// Temporary StartCassette index struct
//-------------------------------------------
typedef struct tmpStartCassetteIndex_struct
{
    tmpLotInCassetteIndex*  lotInCassetteSeq;
    CORBA::ULong            lotInCassetteLen;
} tmpStartCassetteIndex;

#define FREE_TMP_START_CASSETTE_INDEX(theStartCassetteIdxSeq, theStartCassetteIdxLen)\
{\
    if ( NULL != theStartCassetteIdxSeq )\
    {\
        PPT_METHODTRACE_V1("", "NULL != theStartCassetteIdxSeq");\
        for ( CORBA::ULong nFreeStartCassetteNum = 0; nFreeStartCassetteNum < theStartCassetteIdxLen; nFreeStartCassetteNum++ )\
        {\
            PPT_METHODTRACE_V2("", "nFreeStartCassetteNum", nFreeStartCassetteNum);\
            for ( CORBA::ULong nFreeLotInCassetteNum = 0; nFreeLotInCassetteNum < theStartCassetteIdxSeq[nFreeStartCassetteNum].lotInCassetteLen; nFreeLotInCassetteNum++ )\
            {\
                PPT_METHODTRACE_V2("", "nFreeLotInCassetteNum", nFreeLotInCassetteNum);\
                if ( 0 < theStartCassetteIdxSeq[nFreeStartCassetteNum].lotInCassetteSeq[nFreeLotInCassetteNum].specCheckIndexLen )\
                {\
                    PPT_METHODTRACE_V1("", "delete [] specCheckIndexSeq");\
                    delete [] theStartCassetteIdxSeq[nFreeStartCassetteNum].lotInCassetteSeq[nFreeLotInCassetteNum].specCheckIndexSeq;\
                }\
            }\
            if ( 0 < theStartCassetteIdxSeq[nFreeStartCassetteNum].lotInCassetteLen )\
            {\
                PPT_METHODTRACE_V1("", "delete [] lotInCassetteSeq");\
                delete [] theStartCassetteIdxSeq[nFreeStartCassetteNum].lotInCassetteSeq;\
            }\
        }\
        if ( 0 < theStartCassetteIdxLen )\
        {\
            PPT_METHODTRACE_V1("", "delete [] theStartCassetteIdxSeq");\
            delete [] theStartCassetteIdxSeq;\
        }\
    }\
}
//DSN000015229 Add end

//INN-R170009 CORBA::Long PPTManager_i::txCollectedDataActionReq ( pptCollectedDataActionReqResult&       strCollectedDataActionReqResult,
CORBA::Long CS_PPTManager_i::txCollectedDataActionReq ( pptCollectedDataActionReqResult&       strCollectedDataActionReqResult,//INN-R170009
                                                     const pptObjCommonIn&                  strObjCommonIn,
                                                     const pptCollectedDataActionReqInParm& strCollectedDataActionReqInParm,
                                                     const char*                            claimMemo
                                                     CORBAENV_LAST_CPP )
{

//INN-R170009    PPT_METHODTRACE_ENTRY("PPTManager_i:: txCollectedDataActionReq ");
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txCollectedDataActionReq ");//INN-R170009
    PPT_METHODTRACE_V3("", "equipmentID and controlJobID ", strCollectedDataActionReqInParm.equipmentID.identifier,strCollectedDataActionReqInParm.controlJobID.identifier);

    //---------------------------------//
    // Initialize variable             //
    //---------------------------------//
    CORBA::Long i=0, j=0, k=0, l=0;   // For loop counter.
    CORBA::Long nCastLen    = 0;      // For StartCassetteLen
    CORBA::Long nLotCastLen = 0;      // For LotInCassetteLen
    CORBA::Long nDCDefLen   = 0;      // For DCDefLen
    CORBA::Long nDCitemLen  = 0;      // For DCItemLen
    CORBA::Long rc          = 0;      // For return value.
    pptStartCassetteSequence  tmpStartCassette;  // StartCassette

    /*=============================================================================*/
    /*                                                                             */
    /* Check Process                                                               */
    /*                                                                             */
    /*=============================================================================*/

    // Check strStartCassette length of InParameter.
    if( 0 < strCollectedDataActionReqInParm.strStartCassette.length())
    {
        PPT_METHODTRACE_V1("", "There is StartCassette length of inparmeter.");
        tmpStartCassette = strCollectedDataActionReqInParm.strStartCassette;
    }
    else
    {
        PPT_METHODTRACE_V1("", "There is no StartCassette length of inparmeter. Try to get StartCassette with controlJob.");
        //-----------------------------------------------------------------------//
        //   Get Started Lot information which is specified with ControlJob ID   //
        //-----------------------------------------------------------------------//
        objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
        rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out, strObjCommonIn,
                                                     strCollectedDataActionReqInParm.controlJobID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK");
            strCollectedDataActionReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult;
            return( rc );
        }

        tmpStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;
    }

    // Recheck StartCassette length.
    if( 0 >= tmpStartCassette.length() )
    {
        PPT_SET_MSG_RC_KEY(strCollectedDataActionReqResult, MSG_NOT_FOUND_CASSETTE, RC_NOT_FOUND_CASSETTE, "(There is no started cassette.)");
        return RC_NOT_FOUND_CASSETTE;
    }

    /*=============================================================================*/
    /*                                                                             */
    /* Object Lock Process                                                         */
    /*                                                                             */
    /*=============================================================================*/
    //--------------------------------//
    //   Lock Machine object          //
    //--------------------------------//
    PPT_METHODTRACE_V1("", "Object Lock Process....");
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCollectedDataActionReqInParm.equipmentID, SP_ClassName_PosMachine );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock() != RC_OK");
        strCollectedDataActionReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }

    //--------------------------------//
    //   Lock Cassette / Lot Object   //
    //--------------------------------//
    nCastLen = tmpStartCassette.length();
    PPT_METHODTRACE_V2("", "tmpStartCassette.length", nCastLen);

    for ( i = 0; i < nCastLen; i++ )
    {
        //--------------------------//
        //   Lock Cassette Object   //
        //--------------------------//
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, tmpStartCassette[i].cassetteID, SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock() != RC_OK");
            strCollectedDataActionReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }

        nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V2("", "tmpStartCassette[i].strLotInCassette.length", nLotCastLen);

        for ( j = 0; j < nLotCastLen; j++ )
        {
            //---------------------------//
            //   Omit Not-OpeStart Lot   //
            //---------------------------//
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");
                continue;
            }

            //---------------------//
            //   Lock Lot Object   //
            //---------------------//
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, tmpStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK");
                strCollectedDataActionReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        }
    }

//DSN000096135 Add Start
    CORBA::Boolean virtualOperationFlag = FALSE;

    objVirtualOperation_CheckByStartCassette_out strVirtualOperation_CheckByStartCassette_out;
    objVirtualOperation_CheckByStartCassette_in  strVirtualOperation_CheckByStartCassette_in;

    strVirtualOperation_CheckByStartCassette_in.strStartCassette = tmpStartCassette;

    rc = virtualOperation_CheckByStartCassette( strVirtualOperation_CheckByStartCassette_out, strObjCommonIn, strVirtualOperation_CheckByStartCassette_in );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "virtualOperation_CheckByStartCassette() != RC_OK" );
        strCollectedDataActionReqResult.strResult = strVirtualOperation_CheckByStartCassette_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "virtualOperationFlag = ", strVirtualOperation_CheckByStartCassette_out.virtualOperationFlag );
    virtualOperationFlag = strVirtualOperation_CheckByStartCassette_out.virtualOperationFlag;
//DSN000096135 Add End

    /*=============================================================================*/
    /*                                                                             */
    /* Main Process                                                                */
    /*                                                                             */
    /*=============================================================================*/

    //--------------------------------------------------------------------------------//
    // If this Tx is invoked as the Post-Process of TxTempDataRpt,                    //
    // txDataSpecCheckReq and the following processes should be invoked absolutely.   //
    // To do that OperationMode is set to Auto forcedly.                              //
    //--------------------------------------------------------------------------------//
    objPortResource_currentOperationMode_Get_out  strPortResource_currentOperationMode_Get_out;

    // TXDCR004 is TxTempDataRpt. TXDCC005 is TxCollecteDataActionReq.
    if( CIMFWStrCmp( strObjCommonIn.transactionID, "TXDCR004") == 0 || CIMFWStrCmp( strObjCommonIn.transactionID, "TXDCC005") == 0 )
    {
        PPT_METHODTRACE_V1("", "OperationMode is set to Auto forcedly.");
        strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode = CIMFWStrDup(SP_Eqp_CompMode_Auto );
    }
    else
    {
        if( virtualOperationFlag == FALSE )    //DSN000096135
        {                                      //DSN000096135
            PPT_METHODTRACE_V1("", "Check whether OperationMode is Auto or other.");
            //---------------------------------//
            //   Get Equipment's Online Mode   //
            //---------------------------------//
            rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out, strObjCommonIn,
                                                        strCollectedDataActionReqInParm.equipmentID,
                                                        tmpStartCassette[0].unloadPortID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "portResource_currentOperationMohde_Get() != RC_OK");
//DSN000096135                strCollectedDataActionReqResult.strOpeCompWithDataReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
                strCollectedDataActionReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;    //DSN000096135
                return( rc );
            }
        }                                      //DSN000096135
    }
//DSN000015229 Add Start
    //----------------------------------------------//
    //   If Eqp's OperationCompMode is Auto Mode,   //
    //   Store already executed action list         //
    //----------------------------------------------//
    CORBA::Boolean bPJDataExistFlag = FALSE;
    tmpStartCassetteIndex* strStartCassetteIndexSeq = NULL;
    CORBA::Long strStartCassetteIndexLen = 0;

    pptStartCassetteSequence strExpandStartCassetteSeq;

    if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode ,SP_Eqp_CompMode_Auto ) )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode, SP_Eqp_CompMode_Auto ) == 0");

        CORBA::Boolean bExistAsteriskItemFlag = FALSE;
        nCastLen = tmpStartCassette.length();
        strExpandStartCassetteSeq.length(nCastLen);
        for ( i = 0; i < nCastLen; i++ )
        {
            PPT_METHODTRACE_V2("", "i", i);

            nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V2("", "tmpStartCassette[i].strLotInCassette.length", nLotCastLen);
            strExpandStartCassetteSeq[i].strLotInCassette.length(nLotCastLen);

            for ( j = 0; j < nLotCastLen; j++ )
            {
                PPT_METHODTRACE_V2("", "j", j);

                PPT_METHODTRACE_V2("", "operationStartFlag ", tmpStartCassette[i].strLotInCassette[j].operationStartFlag )
                if ( FALSE == tmpStartCassette[i].strLotInCassette[j].operationStartFlag )
                {
                    PPT_METHODTRACE_V1("", "FALSE == operationStartFlag");
                    continue;
                }

                /*=============================================================================*/
                /*                                                                             */
                /* Check Reported PJ Data Item                                                 */
                /*                                                                             */
                /*=============================================================================*/
                objProcessOperation_DataCondition_GetDR_out  strProcessOperation_DataCondition_GetDR_out;
                objProcessOperation_DataCondition_GetDR_in   strProcessOperation_DataCondition_GetDR_in;
                strProcessOperation_DataCondition_GetDR_in.lotID    = tmpStartCassette[i].strLotInCassette[j].lotID;
                strProcessOperation_DataCondition_GetDR_in.category = CIMFWStrDup(SP_DataConditionCategory_SpecCheckResult);

                PPT_METHODTRACE_V1( "", "calling processOperation_DataCondition_GetDR()" );
                rc = processOperation_DataCondition_GetDR( strProcessOperation_DataCondition_GetDR_out,
                                                           strObjCommonIn,
                                                           strProcessOperation_DataCondition_GetDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "","processOperation_DataCondition_GetDR() != RC_OK", rc );
                    strCollectedDataActionReqResult.strResult = strProcessOperation_DataCondition_GetDR_out.strResult;
                    return( rc );
                }
                if ( FALSE == bPJDataExistFlag && 0 < strProcessOperation_DataCondition_GetDR_out.count )
                {
                    PPT_METHODTRACE_V1( "", "0 < strProcessOperation_DataCondition_GetDR_out.count" );
                    bPJDataExistFlag = TRUE;
                }
                PPT_METHODTRACE_V2( "", "bPJDataExistFlag", (int)bPJDataExistFlag );

                pptDCDefSequence& strInitDCDefSeq = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef;
                nDCDefLen = strInitDCDefSeq.length();
                strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef.length(nDCDefLen);

                /*=============================================================================*/
                /*                                                                             */
                /* Get Expand Derived Data Item                                                */
                /*                                                                             */
                /*=============================================================================*/
                strProcessOperation_DataCondition_GetDR_in.category = CIMFWStrDup(SP_DataConditionCategory_ExpandDerivedData);

                PPT_METHODTRACE_V1( "", "calling processOperation_DataCondition_GetDR()" );
                rc = processOperation_DataCondition_GetDR( strProcessOperation_DataCondition_GetDR_out,
                                                           strObjCommonIn,
                                                           strProcessOperation_DataCondition_GetDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "","processOperation_DataCondition_GetDR() != RC_OK", rc );
                    strCollectedDataActionReqResult.strResult = strProcessOperation_DataCondition_GetDR_out.strResult;
                    return( rc );
                }

                pptDCDefSequence& strExpandDerivedDCDef = strProcessOperation_DataCondition_GetDR_out.strExpandDerivedDCDef;
                CORBA::ULong nExpandDCDefLen = strExpandDerivedDCDef.length();
                PPT_METHODTRACE_V2( "", "nExpandDCDefLen", nExpandDCDefLen );

                for ( CORBA::ULong nDCDefCnt = 0; nDCDefCnt < nDCDefLen; nDCDefCnt++ )
                {
                    PPT_METHODTRACE_V2("", "nDCDefCnt", nDCDefCnt);
                    for ( CORBA::ULong nExpandDCDefNum = 0; nExpandDCDefNum < nExpandDCDefLen; nExpandDCDefNum++ )
                    {
                        PPT_METHODTRACE_V2("", "nExpandDCDefNum", nExpandDCDefNum);
                        if ( 0 == CIMFWStrCmp(strInitDCDefSeq[nDCDefCnt].dataCollectionDefinitionID.identifier, strExpandDerivedDCDef[nExpandDCDefNum].dataCollectionDefinitionID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "strInitDCDefSeq[nDCDefCnt].dataCollectionDefinitionID == strExpandDerivedDCDef[nExpandDCDefNum].dataCollectionDefinitionID");
                            strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[nDCDefCnt].strDCItem = strExpandDerivedDCDef[nExpandDCDefNum].strDCItem;
                            break;
                        }
                    }
                }
                if ( FALSE == bExistAsteriskItemFlag && 0 < strProcessOperation_DataCondition_GetDR_out.count )
                {
                    PPT_METHODTRACE_V1( "", "0 < strProcessOperation_DataCondition_GetDR_out.count" );
                    bExistAsteriskItemFlag = TRUE;
                }
                PPT_METHODTRACE_V2( "", "bExistAsteriskItemFlag", (int)bExistAsteriskItemFlag );
            }
        }

        if ( TRUE == bPJDataExistFlag || TRUE == bExistAsteriskItemFlag )
        {
            PPT_METHODTRACE_V1( "", "TRUE == bPJDataExistFlag || TRUE == bExistAsteriskItemFlag" );

            nCastLen = tmpStartCassette.length();
            PPT_METHODTRACE_V2("", "nCastLen", nCastLen )
            strStartCassetteIndexLen = nCastLen;
            strStartCassetteIndexSeq = new tmpStartCassetteIndex[strStartCassetteIndexLen];
            for ( i = 0; i < nCastLen; i++ )
            {
                PPT_METHODTRACE_V2("", "i",i);
                nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
                PPT_METHODTRACE_V2("", "tmpStartCassette[i].strLotInCassette.length() ", nLotCastLen )
                strStartCassetteIndexSeq[i].lotInCassetteLen = nLotCastLen;
                if ( 0 < strStartCassetteIndexSeq[i].lotInCassetteLen )
                {
                    PPT_METHODTRACE_V1("", "0 < strStartCassetteIndexSeq[i].lotInCassetteLen");
                    strStartCassetteIndexSeq[i].lotInCassetteSeq = new tmpLotInCassetteIndex[strStartCassetteIndexSeq[i].lotInCassetteLen];
                }
                for ( j = 0; j < nLotCastLen; j++ )
                {
                    PPT_METHODTRACE_V2("", "j", j);
                    strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexLen = 0;
                    PPT_METHODTRACE_V2("", "operationStartFlag ", tmpStartCassette[i].strLotInCassette[j].operationStartFlag )
                    if ( FALSE == tmpStartCassette[i].strLotInCassette[j].operationStartFlag )
                    {
                        PPT_METHODTRACE_V1("", "FALSE == operationStartFlag");
                        continue;
                    }

                    nDCDefLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                    PPT_METHODTRACE_V2("", "nDCDefLen ", nDCDefLen);
                    strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexLen = nDCDefLen;
                    if ( 0 < strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexLen )
                    {
                        PPT_METHODTRACE_V1("", "0 < strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexLen");
                        strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexSeq = new longSequence[strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexLen];
                    }
                    for ( k = 0; k < nDCDefLen; k++ )
                    {
                        PPT_METHODTRACE_V2("", "k ", k);
                        strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexSeq[k].length(0);

                        pptDCDef& strTmpDCDef = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k];
                        if ( 0 == CIMFWStrLen( strTmpDCDef.dataCollectionSpecificationID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "dataCollectionSpecificationID length is 0");
                            continue;
                        }
                        PPT_METHODTRACE_V2("", "strTmpDCDef.dataCollectionDefinitionID ", strTmpDCDef.dataCollectionDefinitionID.identifier);

                        CORBA::ULong nExpandDCItemLen = strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem.length();
                        PPT_METHODTRACE_V2("", "nExpandDCItemLen ", nExpandDCItemLen );

                        nDCitemLen = strTmpDCDef.strDCItem.length();
                        PPT_METHODTRACE_V2("", "nDCitemLen ", nDCitemLen );
                        strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexSeq[k].length(nDCitemLen + nExpandDCItemLen);
                        CORBA::ULong nChkd = 0;

                        pptDCItemSequence strNewDCItemSeq;
                        strNewDCItemSeq.length(nDCitemLen + nExpandDCItemLen);

                        CORBA::ULong nDCItemCnt = 0;
                        CORBA::ULong nExpandDCItemCurrPos = 0;
                        CORBA::String_var expandCurrDCItemName = CIMFWStrDup("");
                        CORBA::String_var expandCurrMeasType = CIMFWStrDup("");
                        CORBA::String_var expandCurrSitePos = CIMFWStrDup("");
                        for ( l = 0; l < nDCitemLen; l++ )
                        {
                            PPT_METHODTRACE_V2("", "l ",l );
                            CORBA::Boolean bCheckedFlag = FALSE;

                            PPT_METHODTRACE_V2("", "strTmpDCDef.strDCItem[l].measurementType", strTmpDCDef.strDCItem[l].measurementType);
                            if ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJ,          strTmpDCDef.strDCItem[l].measurementType )
                              || 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWafer,     strTmpDCDef.strDCItem[l].measurementType )
                              || 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWaferSite, strTmpDCDef.strDCItem[l].measurementType ) )
                            {
                                PPT_METHODTRACE_V1("", "DCItem by PJ");

                                /*=============================================================================*/
                                /*                                                                             */
                                /* Expand Derived Data Item                                                    */
                                /*                                                                             */
                                /*=============================================================================*/
                                if ( 0 < nExpandDCItemLen
                                  && ( 0 == CIMFWStrCmp( SP_DCDef_Item_Derived,      strTmpDCDef.strDCItem[l].itemType )
                                    || 0 == CIMFWStrCmp( SP_DCDef_Item_UserFunction, strTmpDCDef.strDCItem[l].itemType ) ) )
                                {
                                    PPT_METHODTRACE_V1("", "0 < nExpandDCItemLen and itemType == Derived");

                                    if ( 0 == CIMFWStrLen( expandCurrDCItemName ) )
                                    {
                                        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen( expandCurrDCItemName )");
                                        expandCurrDCItemName = strTmpDCDef.strDCItem[l].dataCollectionItemName;
                                        expandCurrMeasType   = strTmpDCDef.strDCItem[l].measurementType;
                                        expandCurrSitePos    = strTmpDCDef.strDCItem[l].sitePosition;
                                    }

                                    if ( 0 == CIMFWStrCmp( expandCurrDCItemName, strTmpDCDef.strDCItem[l].dataCollectionItemName )
                                      && 0 == CIMFWStrCmp( expandCurrMeasType,   strTmpDCDef.strDCItem[l].measurementType )
                                      && 0 == CIMFWStrCmp( expandCurrSitePos,    strTmpDCDef.strDCItem[l].sitePosition ) )
                                    {
                                        PPT_METHODTRACE_V1("", "Start of the expansion");

                                        CORBA::ULong nExpandDCItemCnt = 0;
                                        for ( nExpandDCItemCnt = nExpandDCItemCurrPos; nExpandDCItemCnt < nExpandDCItemLen; nExpandDCItemCnt++ )
                                        {
                                            PPT_METHODTRACE_V3("", "nExpandDCItemLen/nExpandDCItemCnt", nExpandDCItemLen, nExpandDCItemCnt);

                                            if ( 0 == CIMFWStrCmp( expandCurrDCItemName, strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[nExpandDCItemCnt].dataCollectionItemName )
                                              && 0 == CIMFWStrCmp( expandCurrMeasType,   strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[nExpandDCItemCnt].measurementType )
                                              && 0 == CIMFWStrCmp( expandCurrSitePos,    strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[nExpandDCItemCnt].sitePosition ) )
                                            {
                                                PPT_METHODTRACE_V4("", "Add Expand Item", expandCurrDCItemName, expandCurrMeasType, expandCurrSitePos);
                                                strNewDCItemSeq[nDCItemCnt] = strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[nExpandDCItemCnt];
                                                strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexSeq[k][nChkd] = nDCItemCnt;
                                                nChkd++;
                                                nDCItemCnt++;
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V1("", "End of the expansion");
                                                expandCurrDCItemName = strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[nExpandDCItemCnt].dataCollectionItemName;
                                                expandCurrMeasType   = strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[nExpandDCItemCnt].measurementType;
                                                expandCurrSitePos    = strExpandStartCassetteSeq[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[nExpandDCItemCnt].sitePosition;
                                                break;
                                            }
                                        } // nExpandDCItemCnt loop end
                                        nExpandDCItemCurrPos = nExpandDCItemCnt;
                                    }
                                }

                                if ( ( 0 == CIMFWStrCmp( SP_DCDef_Item_Derived,      strTmpDCDef.strDCItem[l].itemType )
                                    || 0 == CIMFWStrCmp( SP_DCDef_Item_UserFunction, strTmpDCDef.strDCItem[l].itemType ) )
                                  && 0 == CIMFWStrCmp( strTmpDCDef.strDCItem[l].waferPosition, "*" ) )
                                {
                                    PPT_METHODTRACE_V1("", "itemType == Derived and waferPosition == '*'");
                                    continue;
                                }
                                strNewDCItemSeq[nDCItemCnt] = strTmpDCDef.strDCItem[l];

                                PPT_METHODTRACE_V2("", "strTmpDCDef.strDCItem[l].specCheckResult", strTmpDCDef.strDCItem[l].specCheckResult);
                                if ( ( 0 == CIMFWStrCmp ( SP_SpecCheckResult_OK,                strTmpDCDef.strDCItem[l].specCheckResult ) )
                                  || ( 0 == CIMFWStrCmp ( SP_SpecCheckResult_UpperControlLimit, strTmpDCDef.strDCItem[l].specCheckResult ) )
                                  || ( 0 == CIMFWStrCmp ( SP_SpecCheckResult_LowerControlLimit, strTmpDCDef.strDCItem[l].specCheckResult ) )
                                  || ( 0 == CIMFWStrCmp ( SP_SpecCheckResult_UpperSpecLimit,    strTmpDCDef.strDCItem[l].specCheckResult ) )
                                  || ( 0 == CIMFWStrCmp ( SP_SpecCheckResult_LowerSpecLimit,    strTmpDCDef.strDCItem[l].specCheckResult ) )
                                  || ( 0 == CIMFWStrCmp ( SP_SpecCheckResult_UpperScreenLimit,  strTmpDCDef.strDCItem[l].specCheckResult ) )
                                  || ( 0 == CIMFWStrCmp ( SP_SpecCheckResult_LowerScreenLimit,  strTmpDCDef.strDCItem[l].specCheckResult ) )
                                  || ( 0 == CIMFWStrCmp ( SP_SpecCheckResult_APCError,          strTmpDCDef.strDCItem[l].specCheckResult ) ) )
                                {
                                    PPT_METHODTRACE_V1("", "Exist PJ report specCheckResult");
                                    bCheckedFlag = TRUE;
                                }
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "DCItem by CJ");
                                strNewDCItemSeq[nDCItemCnt] = strTmpDCDef.strDCItem[l];
                            }
                            if ( FALSE == bCheckedFlag )
                            {
                                PPT_METHODTRACE_V1("", "FALSE == bCheckedFlag");
                                strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexSeq[k][nChkd] = nDCItemCnt;
                                nChkd++;
                            }
                            nDCItemCnt++;
                        }
                        strNewDCItemSeq.length(nDCItemCnt);
                        strTmpDCDef.strDCItem = strNewDCItemSeq;

                        strStartCassetteIndexSeq[i].lotInCassetteSeq[j].specCheckIndexSeq[k].length(nChkd);
                    }
                }
            }
        }
    }
//DSN000015229 Add End

    //----------------------------------------------//
    //   If Eqp's OperationCompMode is Auto Mode,   //
    //   Call txSpecCheckDataReq                    //
    //----------------------------------------------//
    CORBA::Boolean spcCheckRequiredFlag = FALSE;

    if (CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode ,SP_Eqp_CompMode_Auto ) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode, SP_Eqp_CompMode_Auto ) == 0");

        //-------------------------------------------------------------------------------------------//
        //   Do Spec Check                                                                           //
        //      - Calculate the derived value and Set them to PO if calculationRequiredFlag is TRUE  //
        //      - Set spec  check result to PO if speckCheckRequiredFlag is TRUE.                    //
        //-------------------------------------------------------------------------------------------//
        pptDataSpecCheckReqResult strDataSpecCheckReqResult;
        rc = txDataSpecCheckReq( strDataSpecCheckReqResult, strObjCommonIn,
                                 strCollectedDataActionReqInParm.equipmentID,
                                 strCollectedDataActionReqInParm.controlJobID,
                                 tmpStartCassette );

        //----------------------------------------------//
        //  Replace ReturnCode for SPCCheckRequired.    //
        //----------------------------------------------//
        if ( rc == RC_OK )
        {
            rc = RC_NO_NEED_SPEC_CHECK;
            nCastLen = strDataSpecCheckReqResult.strStartCassette.length();
            for ( i = 0; i < nCastLen; i++ )
            {
                nLotCastLen = strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette.length();
                for ( j = 0; j < nLotCastLen; j++ )
                {
                    if ( strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                    {
                        continue;
                    }

                    nDCDefLen = strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                    for ( k = 0; k < nDCDefLen; k++ )
                    {
                        if ( 0 == CIMFWStrCmp( strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].dataCollectionSpecificationID.identifier, "" ) )
                        {
                            continue;
                        }

                        nDCitemLen = strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem.length();
                        for ( l = 0; l < nDCitemLen; l++ )
                        {
                            if( 0 != CIMFWStrCmp(strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].specCheckResult, "*") &&
                                0 != CIMFWStrCmp(strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].specCheckResult, "") )
                            {
                                rc = RC_OK;
                                break;
                            }
                        }
                        if( rc == RC_OK )
                        {
                            break;
                        }
                    }
                    if( rc == RC_OK )
                    {
                        break;
                    }
                }
                if( rc == RC_OK )
                {
                    break;
                }
            }
        }

        if ( rc == RC_OK )
        {
            PPT_METHODTRACE_V1( "", "txDataSpecCheckReq() == RC_OK" );

            //-------------------------------------------------------------------------------//
            //   Get Started Lot information in order to get the derived / delta datavalues  //
            //   and also specCheckResult in case that CompletionMode is Auto.               //
            //-------------------------------------------------------------------------------//
            objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
            rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out, strObjCommonIn,
                                                         strCollectedDataActionReqInParm.controlJobID);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK");
                strCollectedDataActionReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult;
                FREE_TMP_START_CASSETTE_INDEX(strStartCassetteIndexSeq, strStartCassetteIndexLen)  //DSN000015229
                return( rc );
            }
            //Reset StartCassette.
            tmpStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;
            spcCheckRequiredFlag = TRUE;
        }
        else if ( rc == RC_NO_NEED_SPEC_CHECK )
        {
            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() == RC_NO_NEED_TO_SPECCHECK");
            rc = RC_OK;
            //-------------------------------------------------------------------------------//
            //   Get Started Lot information in order to get the derived / delta datavalues  //
            //   and also specCheckResult in case that CompletionMode is Auto.               //
            //-------------------------------------------------------------------------------//
            objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
            rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out, strObjCommonIn,
                                                         strCollectedDataActionReqInParm.controlJobID);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK");
                strCollectedDataActionReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult;
                FREE_TMP_START_CASSETTE_INDEX(strStartCassetteIndexSeq, strStartCassetteIndexLen)  //DSN000015229
                return( rc );
            }
            //Reset StartCassette.
            tmpStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() != RC_OK");
            strCollectedDataActionReqResult.strResult = strDataSpecCheckReqResult.strResult;
            FREE_TMP_START_CASSETTE_INDEX(strStartCassetteIndexSeq, strStartCassetteIndexLen)  //DSN000015229
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "OperationMode is not Auto.");

//DSN000015229 Add Start
        //------------------------------------------//
        //   Replace specCheckResult from 1X to X   //
        //------------------------------------------//
        CORBA::Boolean bReplaceExistFlag = FALSE;
        nCastLen = tmpStartCassette.length();
        PPT_METHODTRACE_V2("", "nCastLen", nCastLen);
        for ( CORBA::ULong i = 0; i < nCastLen; i++ )
        {
            PPT_METHODTRACE_V2("", "i  ", i);
            nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V2("", "nLotCastLen  ", nLotCastLen);
            for ( CORBA::ULong j = 0; j < nLotCastLen; j++ )
            {
                PPT_METHODTRACE_V2("", "j  ", j);
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "operationStartFlag == FALSE");
                    continue;
                }

                nDCDefLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                PPT_METHODTRACE_V2("", "nDCDefLen ", nDCDefLen);
                for ( CORBA::ULong k = 0; k < nDCDefLen; k++ )
                {
                    PPT_METHODTRACE_V2("", "k  ", k);
                    nDCitemLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem.length();
                    PPT_METHODTRACE_V2("", "nDCitemLen ", nDCitemLen);
                    for (CORBA::ULong l = 0; l < nDCitemLen; l++ )
                    {
                        PPT_METHODTRACE_V2("", "l  ", l);
                        pptDCItem& strTmpDCItem = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l];
                        PPT_METHODTRACE_V2("", "strTmpDCItem.specCheckResult ", strTmpDCItem.specCheckResult);
                        if ( 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_OK, strTmpDCItem.specCheckResult) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_OK");
                            strTmpDCItem.specCheckResult = CIMFWStrDup(SP_SpecCheckResult_OK);
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_UpperControlLimit, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_UpperControlLimit");
                            strTmpDCItem.specCheckResult = CIMFWStrDup(SP_SpecCheckResult_UpperControlLimit);
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_LowerControlLimit, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_LowerControlLimit");
                            strTmpDCItem.specCheckResult = CIMFWStrDup(SP_SpecCheckResult_LowerControlLimit);
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_UpperSpecLimit, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_UpperSpecLimit");
                            strTmpDCItem.specCheckResult = CIMFWStrDup(SP_SpecCheckResult_UpperSpecLimit);
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_LowerSpecLimit, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_LowerSpecLimit");
                            strTmpDCItem.specCheckResult = CIMFWStrDup(SP_SpecCheckResult_LowerSpecLimit);
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_UpperScreenLimit, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_UpperScreenLimit");
                            strTmpDCItem.specCheckResult = CIMFWStrDup(SP_SpecCheckResult_UpperScreenLimit);
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_LowerScreenLimit, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_LowerScreenLimit");
                            strTmpDCItem.specCheckResult = CIMFWStrDup(SP_SpecCheckResult_LowerScreenLimit);
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_APCError, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_APCError");
                            strTmpDCItem.specCheckResult = CIMFWStrDup(SP_SpecCheckResult_APCError);
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_Asterisk, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_Asterisk");
                            strTmpDCItem.specCheckResult = CIMFWStrDup("*");
                            bReplaceExistFlag = TRUE;
                        }
                        else if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_Pound, strTmpDCItem.specCheckResult ) )
                        {
                            PPT_METHODTRACE_V1("", "SP_SpecCheckResult_1X_Pound");
                            strTmpDCItem.specCheckResult = CIMFWStrDup("#");
                            bReplaceExistFlag = TRUE;
                        }
                        else
                        {
                            // Not replace specCheckResult
                            PPT_METHODTRACE_V1("", "Not replace specCheckResult");
                        }
                    }
                }
            }
        }

        //-----------------------------------------------------------//
        //   If specCheckResult is replaced, update PO information   //
        //-----------------------------------------------------------//
        if (TRUE == bReplaceExistFlag)
        {
            PPT_METHODTRACE_V1("","calling processOperation_tempData_Set()");
            objProcessOperation_tempData_Set_out strProcessOperation_tempData_Set_out;
            rc = processOperation_tempData_Set( strProcessOperation_tempData_Set_out,
                                                strObjCommonIn,
                                                strCollectedDataActionReqInParm.controlJobID,
                                                tmpStartCassette );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","processOperation_tempData_Set() != RC_OK", rc );
                strCollectedDataActionReqResult.strResult = strProcessOperation_tempData_Set_out.strResult;
                FREE_TMP_START_CASSETTE_INDEX(strStartCassetteIndexSeq, strStartCassetteIndexLen)
                return rc;
            }
        }
//DSN000015229 Add End

        //----------------------------------------//
        //   Judge SPC-Check is Required or Not   //
        //----------------------------------------//
        nCastLen = 0; // Initialize for recycling.
        nCastLen = tmpStartCassette.length();

        for ( i = 0; i < nCastLen; i++ )
        {
            nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
            for ( j = 0; j < nLotCastLen; j++ )
            {
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                nDCDefLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                for ( k=0; k < nDCDefLen; k++ )
                {
                    if ( tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].specCheckRequiredFlag == TRUE )
                    {
                        spcCheckRequiredFlag = TRUE;
                        break;
                    }
                }
                //===== quit [j] Loop =====//
                if ( spcCheckRequiredFlag == TRUE )
                {
                    break;
                }
            }
            //===== quit [i] Loop =====//
            if ( spcCheckRequiredFlag == TRUE )
            {
                break;
            }
        }
    }

//DSIV00001830 Add Start
    //----------------------------------------------------------------
    // Bonding Map Info Get
    //----------------------------------------------------------------
    objBondingGroup_infoByEqp_GetDR_out strBondingGroup_infoByEqp_GetDR_out;
    objBondingGroup_infoByEqp_GetDR_in strBondingGroup_infoByEqp_GetDR_in;
    strBondingGroup_infoByEqp_GetDR_in.equipmentID        = strCollectedDataActionReqInParm.equipmentID;
    strBondingGroup_infoByEqp_GetDR_in.controlJobID       = strCollectedDataActionReqInParm.controlJobID;
    strBondingGroup_infoByEqp_GetDR_in.bondingMapInfoFlag = TRUE;

    PPT_METHODTRACE_V1( "", "calling bondingGroup_infoByEqp_GetDR()" );
    rc = bondingGroup_infoByEqp_GetDR( strBondingGroup_infoByEqp_GetDR_out,
                                       strObjCommonIn,
                                       strBondingGroup_infoByEqp_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "","bondingGroup_infoByEqp_GetDR() != RC_OK", rc );
        strCollectedDataActionReqResult.strResult = strBondingGroup_infoByEqp_GetDR_out.strResult;
        FREE_TMP_START_CASSETTE_INDEX(strStartCassetteIndexSeq, strStartCassetteIndexLen)  //DSN000015229
        return rc;
    }
    const CORBA::Long topLotLen = strBondingGroup_infoByEqp_GetDR_out.topLotIDSeq.length();
    PPT_METHODTRACE_V2( "", "topLotLen", topLotLen );

    if ( topLotLen > 0 )
    {
        PPT_METHODTRACE_V1("", "There is Top Lot." );

        //----------------------------------------//
        //   Clear SpecCheckResult for Top Lot    //
        //----------------------------------------//
        nCastLen = tmpStartCassette.length();

        for ( i = 0; i < nCastLen; i++ )
        {
            nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
            for ( j = 0; j < nLotCastLen; j++ )
            {
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                CORBA::Boolean isTopLot = FALSE;
                for ( CORBA::Long topLotCnt = 0; topLotCnt < topLotLen; topLotCnt++ )
                {
                    if ( CIMFWStrCmp( tmpStartCassette[i].strLotInCassette[j].lotID.identifier,
                                      strBondingGroup_infoByEqp_GetDR_out.topLotIDSeq[topLotCnt].identifier ) == 0 )
                    {
                        PPT_METHODTRACE_V2( "","isTopLot", topLotCnt );
                        isTopLot = TRUE;
                        break;
                    }
                }
                if ( isTopLot )
                {
                    PPT_METHODTRACE_V2( "", "Lot is Top Lot. Clearing Action.", tmpStartCassette[i].strLotInCassette[j].lotID.identifier );
                    pptDCDefSequence& strDCDef = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef;
                    CORBA::Long defLen = strDCDef.length();
                    for ( CORBA::Long defCnt = 0; defCnt < defLen; defCnt++ )
                    {
//PSIV00002109                        strDCDef[defCnt].specCheckRequiredFlag = FALSE;

                        CORBA::Long itmLen = strDCDef[defCnt].strDCItem.length();
                        for ( CORBA::Long itmCnt = 0; itmCnt < itmLen; itmCnt++ )
                        {
                            strDCDef[defCnt].strDCItem[itmCnt].actionCode.length( 0 );
                            strDCDef[defCnt].strDCItem[itmCnt].specCheckResult = CIMFWStrDup( "" );
                        }
                    }
                }
            }
        }
    }
//DSIV00001830 Add End

    //-------------------------//
    //                         //
    //   SPC Check Procedure   //
    //                         //
    //-------------------------//
    PPT_METHODTRACE_V2("", "spcCheckRequiredFlag is ", spcCheckRequiredFlag );
//DSIV00001021    pptSpcCheckReqResult strSpcCheckReqResult;
//DSIV00001021    objSPCMgr_SendSPCCheckReq_out strSPCMgr_SendSPCCheckReq_out;  //P7000126
//DSIV00001021    if ( spcCheckRequiredFlag == TRUE )
//DSIV00001021    {
//DSIV00001021        //----------------------------//
//DSIV00001021        //   Send SPC Check Request   //
//DSIV00001021        //----------------------------//
//P7000126        rc = txSpcCheckReq(strSpcCheckReqResult, strObjCommonIn,
//P7000126                           strCollectedDataActionReqInParm.equipmentID,
//P7000126                           strCollectedDataActionReqInParm.controlJobID,
//P7000126                           tmpStartCassette);
//P7000126
//P7000126        if ( rc == RC_OK || rc == RC_NO_NEED_TO_SPCCHECK )
//P7000126        {
//P7000126            PPT_METHODTRACE_V1("", "txSpcCheckReq() == RC_OK || RC_NO_NEED_TO_SPCCHECK") ;
//P7000126            rc = RC_OK;
//P7000126        }
//P7000126        else
//P7000126        {
//P7000126            PPT_METHODTRACE_V1("", "txSpcCheckReq() != RC_OK") ;
//P7000126            strCollectedDataActionReqResult.strResult = strSpcCheckReqResult.strResult ;
//P7000126            return( rc );
//P7000126        }
//P7000126 add start
//DSIV00001021        rc = SPCMgr_SendSPCCheckReq( strSPCMgr_SendSPCCheckReq_out,
//DSIV00001021                                     strObjCommonIn,
//DSIV00001021                                     strCollectedDataActionReqInParm.equipmentID,
//DSIV00001021                                     strCollectedDataActionReqInParm.controlJobID,
//DSIV00001021                                     tmpStartCassette );
//DSIV00001021        if ( rc == RC_OK || rc == RC_NO_NEED_TO_SPCCHECK )
//DSIV00001021        {
//DSIV00001021            PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq() == RC_OK || RC_NO_NEED_TO_SPCCHECK") ;
//DSIV00001021            rc = RC_OK;
//DSIV00001021        }
//DSIV00001021        else
//DSIV00001021        {
//DSIV00001021            PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq() != RC_OK") ;
//DSIV00001021            strCollectedDataActionReqResult.strResult = strSPCMgr_SendSPCCheckReq_out.strResult ;
//DSIV00001021            return( rc );
//DSIV00001021        }
//DSIV00001021 add start
    pptSpcCheckReqResult__101 strSpcCheckReqResult;
    objSPCMgr_SendSPCCheckReq_out__101 strSPCMgr_SendSPCCheckReq_out;
    if ( spcCheckRequiredFlag == TRUE )
    {
        //----------------------------//
        //   Send SPC Check Request   //
        //----------------------------//
        rc = SPCMgr_SendSPCCheckReq__101( strSPCMgr_SendSPCCheckReq_out,
                                     strObjCommonIn,
                                     strCollectedDataActionReqInParm.equipmentID,
                                     strCollectedDataActionReqInParm.controlJobID,
                                     tmpStartCassette );
        if ( rc == RC_OK || rc == RC_NO_NEED_TO_SPCCHECK )
        {
            PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq__101() == RC_OK || RC_NO_NEED_TO_SPCCHECK");
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq__101() != RC_OK");
            strCollectedDataActionReqResult.strResult = strSPCMgr_SendSPCCheckReq_out.strResult;
            FREE_TMP_START_CASSETTE_INDEX(strStartCassetteIndexSeq, strStartCassetteIndexLen)  //DSN000015229
            return( rc );
        }
        strSpcCheckReqResult = strSPCMgr_SendSPCCheckReq_out.strSpcCheckReqResult;
//DSIV00001021 add end
//P7000126 add end
    }

    //-----------------------------------------------------------------//
    //   Summary Action Items to Lot based on the Spec Check Result    //
    //-----------------------------------------------------------------//
//DSIV00000214    objStartLot_actionList_EffectSpecCheck_out strStartLot_actionList_EffectSpecCheck_out;
//DSIV00000214    rc = startLot_actionList_EffectSpecCheck(  strStartLot_actionList_EffectSpecCheck_out, strObjCommonIn,
//DSIV00000214                                               tmpStartCassette,
//DSIV00000214                                               strCollectedDataActionReqInParm.equipmentID);
//DSIV00000214    if ( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "startLot_actionList_EffectSpecCheck() != RC_OK") ;
//DSIV00000214        strCollectedDataActionReqResult.strResult = strStartLot_actionList_EffectSpecCheck_out.strResult ;
//DSIV00000214        return( rc );
//DSIV00000214    }
//DSIV00000214 add start
//DSIV00001021    objStartLot_actionList_EffectSpecCheck_out__100 strStartLot_actionList_EffectSpecCheck_out;
//DSIV00001021    objStartLot_actionList_EffectSpecCheck_in__100  strStartLot_actionList_EffectSpecCheck_in;
//DSIV00001021    strStartLot_actionList_EffectSpecCheck_in.strStartCassette = tmpStartCassette;
//DSIV00001021    strStartLot_actionList_EffectSpecCheck_in.equipmentID      = strCollectedDataActionReqInParm.equipmentID;
//DSIV00001021    pptInterFabMonitorGroupActionInfoSequence strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    strStartLot_actionList_EffectSpecCheck_in.strInterFabMonitorGroupActionInfoSequence = strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    rc = startLot_actionList_EffectSpecCheck__100( strStartLot_actionList_EffectSpecCheck_out, strObjCommonIn,
//DSIV00001021                                                   strStartLot_actionList_EffectSpecCheck_in );
//DSIV00001021    if( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V2("", "startLot_actionList_EffectSpecCheck__100() != RC_OK", rc);
//DSIV00001021        strCollectedDataActionReqResult.strResult = strStartLot_actionList_EffectSpecCheck_out.strResult;
//DSIV00001021        return rc;
//DSIV00001021    }
//DSIV00000214 add end
//DSIV00001021 add start
//DSN000015229 Add Start
    pptStartCassetteSequence tmpStartCassetteNewAction;
    tmpStartCassetteNewAction = tmpStartCassette;

    if ( TRUE == bPJDataExistFlag )
    {
        PPT_METHODTRACE_V1("", "TRUE == bPJDataExistFlag");
        //-----------------------------------------------------------------//
        //   Remove already executed action from startCassette             //
        //-----------------------------------------------------------------//
        for ( CORBA::ULong nStartCassetteNum = 0; nStartCassetteNum < strStartCassetteIndexLen; nStartCassetteNum++ )
        {
            PPT_METHODTRACE_V2("", "nStartCassetteNum", nStartCassetteNum);
            for ( CORBA::ULong nLotInCassetteNum = 0; nLotInCassetteNum < strStartCassetteIndexSeq[nStartCassetteNum].lotInCassetteLen; nLotInCassetteNum++ )
            {
                PPT_METHODTRACE_V2("", "nLotInCassetteNum", nLotInCassetteNum);
                for ( CORBA::ULong dcDefIndexNum = 0; dcDefIndexNum < strStartCassetteIndexSeq[nStartCassetteNum].lotInCassetteSeq[nLotInCassetteNum].specCheckIndexLen; dcDefIndexNum++ )
                {
                    PPT_METHODTRACE_V2("", "dcDefIndexNum", dcDefIndexNum);
                    longSequence& specCheckIndex = strStartCassetteIndexSeq[nStartCassetteNum].lotInCassetteSeq[nLotInCassetteNum].specCheckIndexSeq[dcDefIndexNum];
                    CORBA::ULong specCheckIndexCnt = specCheckIndex.length();
                    pptDCItemSequence& strSourceDCItemSeq = tmpStartCassette[nStartCassetteNum].strLotInCassette[nLotInCassetteNum].strStartRecipe.strDCDef[dcDefIndexNum].strDCItem;
                    pptDCItemSequence& strTargetDCItemSeq = tmpStartCassetteNewAction[nStartCassetteNum].strLotInCassette[nLotInCassetteNum].strStartRecipe.strDCDef[dcDefIndexNum].strDCItem;
                    strTargetDCItemSeq.length(specCheckIndexCnt);
                    for ( CORBA::Long dcItemIndexNum = 0; dcItemIndexNum < specCheckIndexCnt; dcItemIndexNum++ )
                    {
                        PPT_METHODTRACE_V2("", "dcItemIndexNum", dcItemIndexNum);
                        CORBA::Long sourceIndex = specCheckIndex[dcItemIndexNum];
                        PPT_METHODTRACE_V2("", "sourceIndex", sourceIndex);
                        if ( sourceIndex >= strSourceDCItemSeq.length() )
                        {
                            PPT_METHODTRACE_V1("", "index >= strDCItem.length()");
                            SET_MSG_RC(strCollectedDataActionReqResult, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                            FREE_TMP_START_CASSETTE_INDEX(strStartCassetteIndexSeq, strStartCassetteIndexLen)
                            return( RC_SYSTEM_ERROR );
                        }
                        strTargetDCItemSeq[dcItemIndexNum] = strSourceDCItemSeq[sourceIndex];
                    }
                }
            }
        }
    }
    FREE_TMP_START_CASSETTE_INDEX(strStartCassetteIndexSeq, strStartCassetteIndexLen)
//DSN000015229 Add End

    objStartLot_actionList_EffectSpecCheck_out__101 strStartLot_actionList_EffectSpecCheck_out;
    objStartLot_actionList_EffectSpecCheck_in__101  strStartLot_actionList_EffectSpecCheck_in;
//DSN000015229    strStartLot_actionList_EffectSpecCheck_in.strStartCassette = tmpStartCassette;
    strStartLot_actionList_EffectSpecCheck_in.strStartCassette = tmpStartCassetteNewAction;         //DSN000015229
    strStartLot_actionList_EffectSpecCheck_in.equipmentID      = strCollectedDataActionReqInParm.equipmentID;
    pptInterFabMonitorGroupActionInfoSequence strInterFabMonitorGroupActionInfoSequence;
    strStartLot_actionList_EffectSpecCheck_in.strInterFabMonitorGroupActionInfoSequence = strInterFabMonitorGroupActionInfoSequence;
    pptDCActionLotResultSequence strDCActionLotResult;
    strStartLot_actionList_EffectSpecCheck_in.strDCActionLotResult = strDCActionLotResult;
    rc = startLot_actionList_EffectSpecCheck__101( strStartLot_actionList_EffectSpecCheck_out, strObjCommonIn,
                                                   strStartLot_actionList_EffectSpecCheck_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "startLot_actionList_EffectSpecCheck__101() != RC_OK", rc);
        strCollectedDataActionReqResult.strResult = strStartLot_actionList_EffectSpecCheck_out.strResult;
        return rc;
    }
//DSIV00001021 add end

    //-----------------------------------------------------------------//
    //   Register Entity Inhibition as the result of SPEC Check        //
    //-----------------------------------------------------------------//
    CORBA::Long nCheckLen = strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length();
    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length()", nCheckLen );

//DSIV00001365    pptEntityInhibitReqResult strEntityInhibitReqResult;
    pptEntityInhibitReqResult__101 strEntityInhibitReqResult;    //DSIV00001365

    for ( i = 0; i < nCheckLen; i++ )
    {
//DSIV00001365        rc = txEntityInhibitReq(strEntityInhibitReqResult, strObjCommonIn,
//DSIV00001365                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[i],
//DSIV00001365                                claimMemo);
//DSIV00001365
//DSIV00001365        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))
//DSIV00001365        {
//DSIV00001365            PPT_METHODTRACE_V1("", "txEntityInhibitReq() != RC_OK") ;
//DSIV00001365            strCollectedDataActionReqResult.strResult = strEntityInhibitReqResult.strResult ;
//DSIV00001365            return( rc );
//DSIV00001365        }
//DSIV00001365        PPT_METHODTRACE_V2("", "txEntityInhibitReq() rc = ", rc);
//DSIV00001365 add start
        rc = txEntityInhibitReq__101(strEntityInhibitReqResult, strObjCommonIn,
                                     strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[i],
                                     claimMemo);

        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))
        {
            PPT_METHODTRACE_V1("", "txEntityInhibitReq__101() != RC_OK");
            strCollectedDataActionReqResult.strResult = strEntityInhibitReqResult.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "txEntityInhibitReq__101() rc = ", rc);
//DSIV00001365 add end
    }

    //-----------------------------------------------//
    //   Send a message as the result of SPEC Check  //
    //-----------------------------------------------//
    CORBA::Long nMsgLen = strStartLot_actionList_EffectSpecCheck_out.strMessageList.length();
    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSpecCheck_out.strMessageList.length()",nMsgLen);

    objMessageDistributionMgr_PutMessage_out   strMessageDistributionMgr_PutMessage_out;

    for( i=0; i < nMsgLen; i++ )
    {
        rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out, strObjCommonIn,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].messageID,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].lotID,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].lotStatus,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].equipmentID,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].routeID,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].operationNumber,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].reasonCode,
                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].messageText);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK");
            strCollectedDataActionReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult;
            return( rc );
        }
    }

//DSIV00000214 add start
    //-------------------------------------------------------------------------//
    //   Register Entity Inhibition as the result of Spec Check(SaR request)   //
    //-------------------------------------------------------------------------//
    objEntityInhibit_RequestForMultiFab_out strEntityInhibit_RequestForMultiFab_out;
//DSIV00001365    objEntityInhibit_RequestForMultiFab_in  strEntityInhibit_RequestForMultiFab_in;
    objEntityInhibit_RequestForMultiFab_in__101  strEntityInhibit_RequestForMultiFab_in;    //DSIV00001365
    strEntityInhibit_RequestForMultiFab_in.strEntityInhibitionsWithFabInfo = strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo;
    strEntityInhibit_RequestForMultiFab_in.claimMemo = CIMFWStrDup("");
//DSIV00001365    rc = entityInhibit_RequestForMultiFab( strEntityInhibit_RequestForMultiFab_out, strObjCommonIn,
//DSIV00001365                                           strEntityInhibit_RequestForMultiFab_in );
//DSIV00001365    if( rc != RC_OK )
//DSIV00001365    {
//DSIV00001365        PPT_METHODTRACE_V2("", "entityInhibit_RequestForMultiFab() != RC_OK", rc);
//DSIV00001365        strCollectedDataActionReqResult.strResult = strEntityInhibit_RequestForMultiFab_out.strResult;
//DSIV00001365        return rc;
//DSIV00001365    }
//DSIV00001365 add start
    rc = entityInhibit_RequestForMultiFab__101( strEntityInhibit_RequestForMultiFab_out, strObjCommonIn,
                                                strEntityInhibit_RequestForMultiFab_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "entityInhibit_RequestForMultiFab__101() != RC_OK", rc);
        strCollectedDataActionReqResult.strResult = strEntityInhibit_RequestForMultiFab_out.strResult;
        return rc;
    }
//DSIV00001365 add end
//DSIV00000214 add end

    //-----------------------------------------------------------------//
    //   Summary Action Items to Lot based on the SPC Check Result     //
    //-----------------------------------------------------------------//
//DSIV00000214    objStartLot_actionList_EffectSPCCheck_out   strStartLot_actionList_EffectSPCCheck_out;
//DSIV00000214    rc = startLot_actionList_EffectSPCCheck(strStartLot_actionList_EffectSPCCheck_out, strObjCommonIn,
//DSIV00000214                                            strSpcCheckReqResult.strSpcCheckLot,
//DSIV00000214                                            strSPCMgr_SendSPCCheckReq_out.strSpcIFParm,          //P7000126
//DSIV00000214                                            strCollectedDataActionReqInParm.equipmentID);
//DSIV00000214    if ( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "strStartLot_actionList_EffectSPCCheck_out() != RC_OK") ;
//DSIV00000214        strCollectedDataActionReqResult.strResult = strStartLot_actionList_EffectSPCCheck_out.strResult ;
//DSIV00000214        return( rc );
//DSIV00000214    }
//DSIV00000214 add start
//DSIV00001021    objStartLot_actionList_EffectSPCCheck_out__100 strStartLot_actionList_EffectSPCCheck_out;
//DSIV00001021    objStartLot_actionList_EffectSPCCheck_in__100  strStartLot_actionList_EffectSPCCheck_in;
//DSIV00001021    strStartLot_actionList_EffectSPCCheck_in.strSpcCheckLot = strSpcCheckReqResult.strSpcCheckLot;
//DSIV00001021    strStartLot_actionList_EffectSPCCheck_in.strSpcIFParm   = strSPCMgr_SendSPCCheckReq_out.strSpcIFParm;
//DSIV00001021    strStartLot_actionList_EffectSPCCheck_in.equipmentID    = strCollectedDataActionReqInParm.equipmentID;
//DSIV00001021    strStartLot_actionList_EffectSPCCheck_in.strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSpecCheck_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    rc = startLot_actionList_EffectSPCCheck__100( strStartLot_actionList_EffectSPCCheck_out, strObjCommonIn,
//DSIV00001021                                                  strStartLot_actionList_EffectSPCCheck_in );
//DSIV00001021    if( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V2("", "startLot_actionList_EffectSPCCheck__100() != RC_OK", rc);
//DSIV00001021        strCollectedDataActionReqResult.strResult = strStartLot_actionList_EffectSPCCheck_out.strResult;
//DSIV00001021        return rc;
//DSIV00001021    }
//DSIV00000214 add end
//DSIV00001021 add start
    objStartLot_actionList_EffectSPCCheck_out__101 strStartLot_actionList_EffectSPCCheck_out;
    objStartLot_actionList_EffectSPCCheck_in__101  strStartLot_actionList_EffectSPCCheck_in;
    strStartLot_actionList_EffectSPCCheck_in.strSpcCheckLot = strSpcCheckReqResult.strSpcCheckLot;
    strStartLot_actionList_EffectSPCCheck_in.strSpcIFParm   = strSPCMgr_SendSPCCheckReq_out.strSpcIFParm;
    strStartLot_actionList_EffectSPCCheck_in.equipmentID    = strCollectedDataActionReqInParm.equipmentID;
    strStartLot_actionList_EffectSPCCheck_in.strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSpecCheck_out.strInterFabMonitorGroupActionInfoSequence;
    strStartLot_actionList_EffectSPCCheck_in.strDCActionLotResult = strStartLot_actionList_EffectSpecCheck_out.strDCActionLotResult;
    rc = startLot_actionList_EffectSPCCheck__101( strStartLot_actionList_EffectSPCCheck_out, strObjCommonIn,
                                                  strStartLot_actionList_EffectSPCCheck_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "startLot_actionList_EffectSPCCheck__101() != RC_OK", rc);
        strCollectedDataActionReqResult.strResult = strStartLot_actionList_EffectSPCCheck_out.strResult;
        return rc;
    }
//DSIV00001021 add end

    //-----------------------------------------------------------------------//
    //   Register Entity Inhibition as the result of SPC Check               //
    //-----------------------------------------------------------------------//
    nCheckLen = 0; // Initialize for recycling.
    nCheckLen = strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length();
    PPT_METHODTRACE_V2("",  "strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length()", nCheckLen);

//DSIV00001365    pptEntityInhibitReqResult strSpcEntityInhibitReqResult;
    pptEntityInhibitReqResult__101 strSpcEntityInhibitReqResult;    //DSIV00001365

    for( i=0; i < nCheckLen; i++ )
    {
//DSIV00001365        rc = txEntityInhibitReq(strSpcEntityInhibitReqResult, strObjCommonIn,
//DSIV00001365                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[i],
//DSIV00001365                                claimMemo);
//DSIV00001365
//DSIV00001365        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))
//DSIV00001365        {
//DSIV00001365            PPT_METHODTRACE_V1("", "txEntityInhibitReq() != RC_OK") ;
//DSIV00001365            strCollectedDataActionReqResult.strResult = strSpcEntityInhibitReqResult.strResult ;
//DSIV00001365            return( rc );
//DSIV00001365        }
//DSIV00001365        PPT_METHODTRACE_V2("", "txEntityInhibitReq() rc = ", rc) ;
//DSIV00001365 add start
        rc = txEntityInhibitReq__101(strSpcEntityInhibitReqResult, strObjCommonIn,
                                     strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[i],
                                     claimMemo);

        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))
        {
            PPT_METHODTRACE_V1("", "txEntityInhibitReq__101() != RC_OK");
            strCollectedDataActionReqResult.strResult = strSpcEntityInhibitReqResult.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "txEntityInhibitReq__101() rc = ", rc);
//DSIV00001365 add end
    }

    //-----------------------------------------------//
    //   Send a message as the result of SPC Check   //
    //-----------------------------------------------//
    nMsgLen = 0; // Initialize for recycling.
    nMsgLen = strStartLot_actionList_EffectSPCCheck_out.strMessageList.length();
    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSPCCheck_out.strMessageList.length()", nMsgLen);

    for( i=0; i < nMsgLen; i++ )
    {
        PPT_METHODTRACE_V2("", "messageText", strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageText);

        rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out, strObjCommonIn,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageID,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].lotID,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].lotStatus,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].equipmentID,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].routeID,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].operationNumber,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].reasonCode,
                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageText);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK");
            strCollectedDataActionReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult;
            return( rc );
        }
    }

//DSIV00000214 add start
    //------------------------------------------------------------------------//
    //   Register Entity Inhibition as the result of SPC Check(SaR request)   //
    //------------------------------------------------------------------------//
    objEntityInhibit_RequestForMultiFab_out strEntityInhibit_RequestForMultiFab_outForSPC;
//DSIV00001365    objEntityInhibit_RequestForMultiFab_in  strEntityInhibit_RequestForMultiFab_inForSPC;
    objEntityInhibit_RequestForMultiFab_in__101  strEntityInhibit_RequestForMultiFab_inForSPC;    //DSIV00001365
    strEntityInhibit_RequestForMultiFab_inForSPC.strEntityInhibitionsWithFabInfo = strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitionsWithFabInfo;
    strEntityInhibit_RequestForMultiFab_inForSPC.claimMemo = CIMFWStrDup("");
//DSIV00001365    rc = entityInhibit_RequestForMultiFab( strEntityInhibit_RequestForMultiFab_outForSPC, strObjCommonIn,
//DSIV00001365                                           strEntityInhibit_RequestForMultiFab_inForSPC );
//DSIV00001365    if( rc != RC_OK )
//DSIV00001365    {
//DSIV00001365        PPT_METHODTRACE_V2("", "entityInhibit_RequestForMultiFab() != RC_OK", rc);
//DSIV00001365        strCollectedDataActionReqResult.strResult = strEntityInhibit_RequestForMultiFab_outForSPC.strResult;
//DSIV00001365        return rc;
//DSIV00001365    }
//DSIV00001365 add start
    rc = entityInhibit_RequestForMultiFab__101( strEntityInhibit_RequestForMultiFab_outForSPC, strObjCommonIn,
                                                strEntityInhibit_RequestForMultiFab_inForSPC );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "entityInhibit_RequestForMultiFab__101() != RC_OK", rc);
        strCollectedDataActionReqResult.strResult = strEntityInhibit_RequestForMultiFab_outForSPC.strResult;
        return rc;
    }
//DSIV00001365 add end

    //----------------------------------------------------------------------------//
    //   Send a message per chart owner as the result of SPC Check(SaR request)   //
    //----------------------------------------------------------------------------//
    objSystemMessage_RequestForMultiFab_out strSystemMessage_RequestForMultiFab_out;
    objSystemMessage_RequestForMultiFab_in  strSystemMessage_RequestForMultiFab_in;
    pptMessageAttributesWithFabInfoSequence tmpMessageAttributesWithFabInfoSeq;
    CORBA::Long mailLen = strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo.length();
    tmpMessageAttributesWithFabInfoSeq.length(1);
    for( i=0; i<mailLen; i++ )
    {
        tmpMessageAttributesWithFabInfoSeq[0].fabID = strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[i].fabID;
        tmpMessageAttributesWithFabInfoSeq[0].strMessageAttributes = strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[i].strMailSend.messageAttributes;
        pptObjCommonIn tmpObjCommonIn;
        tmpObjCommonIn.strUser.userID.identifier = strStartLot_actionList_EffectSPCCheck_out.strMailSendListWithFabInfo[i].strMailSend.chartMailAdderess;

        strSystemMessage_RequestForMultiFab_in.strMessageListWithFabInfo = tmpMessageAttributesWithFabInfoSeq;
        rc = systemMessage_RequestForMultiFab( strSystemMessage_RequestForMultiFab_out, strObjCommonIn,
                                               strSystemMessage_RequestForMultiFab_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "systemMessage_RequestForMultiFab() != RC_OK", rc);
            strCollectedDataActionReqResult.strResult = strSystemMessage_RequestForMultiFab_out.strResult;
            return rc;
        }
    }
//DSIV00000214 add end

    //---------------------------------------------------------------------------
    //   Execute Lot Hold Action based on SpecCheck and also SPC Check result.
    //---------------------------------------------------------------------------

    //-------------------------------------//
    //   Effect The Result of SPEC Check   //
    //-------------------------------------//
//DSIV00000214    objLot_holdRecord_EffectSpecCheckResult_out strLot_holdRecord_EffectSpecCheckResult_out;
//DSIV00000214    rc = lot_holdRecord_EffectSpecCheckResult(  strLot_holdRecord_EffectSpecCheckResult_out, strObjCommonIn, tmpStartCassette);
//DSIV00000214    if ( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSpecCheckResult() != RC_OK") ;
//DSIV00000214        strCollectedDataActionReqResult.strResult = strLot_holdRecord_EffectSpecCheckResult_out.strResult ;
//DSIV00000214        return( rc );
//DSIV00000214    }
//DSIV00000214 add start
//DSIV00001021    objLot_holdRecord_EffectSpecCheckResult_out__100 strLot_holdRecord_EffectSpecCheckResult_out;
//DSIV00001021    objLot_holdRecord_EffectSpecCheckResult_in__100  strLot_holdRecord_EffectSpecCheckResult_in;
//DSIV00001021    strLot_holdRecord_EffectSpecCheckResult_in.strStartCassette = tmpStartCassette;
//DSIV00001021    strLot_holdRecord_EffectSpecCheckResult_in.strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSPCCheck_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    rc = lot_holdRecord_EffectSpecCheckResult__100( strLot_holdRecord_EffectSpecCheckResult_out, strObjCommonIn,
//DSIV00001021                                                    strLot_holdRecord_EffectSpecCheckResult_in );
//DSIV00001021    if( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSpecCheckResult__100() != RC_OK", rc);
//DSIV00001021        strCollectedDataActionReqResult.strResult = strLot_holdRecord_EffectSpecCheckResult_out.strResult;
//DSIV00001021        return rc;
//DSIV00001021    }
//DSIV00000214 add end
//DSIV00001021 add start
    objLot_holdRecord_EffectSpecCheckResult_out__101 strLot_holdRecord_EffectSpecCheckResult_out;
    objLot_holdRecord_EffectSpecCheckResult_in__101  strLot_holdRecord_EffectSpecCheckResult_in;
    strLot_holdRecord_EffectSpecCheckResult_in.strStartCassette = tmpStartCassette;
    strLot_holdRecord_EffectSpecCheckResult_in.strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSPCCheck_out.strInterFabMonitorGroupActionInfoSequence;
    strLot_holdRecord_EffectSpecCheckResult_in.strDCActionLotResult = strStartLot_actionList_EffectSPCCheck_out.strDCActionLotResult;
    rc = lot_holdRecord_EffectSpecCheckResult__101( strLot_holdRecord_EffectSpecCheckResult_out, strObjCommonIn,
                                                    strLot_holdRecord_EffectSpecCheckResult_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSpecCheckResult__101() != RC_OK", rc);
        strCollectedDataActionReqResult.strResult = strLot_holdRecord_EffectSpecCheckResult_out.strResult;
        return rc;
    }
//DSIV00001021 add end

    //--------------//
    // Lot Hold     //
    //--------------//
    CORBA::Long nSpecLotHoldEffectListLen = 0;
    nSpecLotHoldEffectListLen = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length();
    if ( nSpecLotHoldEffectListLen  > 0 )
    {
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length()", nSpecLotHoldEffectListLen);

        pptHoldLotReqResult strHoldLotReqResult;

        pptHoldListSequence strLotHoldReqList;
        strLotHoldReqList.length( 1 );

        for( i = 0; i < nSpecLotHoldEffectListLen; i++ )
        {
            strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].holdType;
            strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].reasonCodeID;
            strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].userID;
            strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].responsibleOperationMark;
            strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].routeID;
            strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].operationNumber;
            strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].relatedLotID;
            strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].claimMemo;

            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn , strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].lotID , strLotHoldReqList );
            if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
                strCollectedDataActionReqResult.strResult = strHoldLotReqResult.strResult;
                return( rc );
            }
        }
    }

    //--------------//
    // Future Hold  //
    //--------------//
    CORBA::Long nSpecFutureHoldEffectLen = 0;
    nSpecFutureHoldEffectLen = strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length();
    if ( nSpecFutureHoldEffectLen  > 0 )
    {
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length()", nSpecFutureHoldEffectLen);

        for( i=0; i < nSpecFutureHoldEffectLen; i++ )
        {
            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult, strObjCommonIn ,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].holdType ,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].lotID,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].routeID,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].operationNumber,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
                                          TRUE,
                                          TRUE,
                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].claimMemo );
            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
            {
                PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY");
                strCollectedDataActionReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
                return( rc );
            }
        }
    }

    //------------------------------------//
    //   Effect The Result of SPC Check   //
    //------------------------------------//
//DSIV00000214    objLot_holdRecord_EffectSPCCheckResult_out strLot_holdRecord_EffectSPCCheckResult_out;
//DSIV00000214    rc = lot_holdRecord_EffectSPCCheckResult(  strLot_holdRecord_EffectSPCCheckResult_out, strObjCommonIn, strSpcCheckReqResult.strSpcCheckLot );
//DSIV00000214    if ( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSPCCheckResult() != RC_OK") ;
//DSIV00000214        strCollectedDataActionReqResult.strResult = strLot_holdRecord_EffectSPCCheckResult_out.strResult ;
//DSIV00000214        return( rc );
//DSIV00000214    }
//DSIV00000214 add start
//DSIV00001021    objLot_holdRecord_EffectSPCCheckResult_out__100 strLot_holdRecord_EffectSPCCheckResult_out;
//DSIV00001021    objLot_holdRecord_EffectSPCCheckResult_in__100  strLot_holdRecord_EffectSPCCheckResult_in;
//DSIV00001021    strLot_holdRecord_EffectSPCCheckResult_in.strSpcCheckLot = strSpcCheckReqResult.strSpcCheckLot;
//DSIV00001021    strLot_holdRecord_EffectSPCCheckResult_in.strInterFabMonitorGroupActionInfoSequence = strLot_holdRecord_EffectSpecCheckResult_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00001021    rc = lot_holdRecord_EffectSPCCheckResult__100( strLot_holdRecord_EffectSPCCheckResult_out, strObjCommonIn,
//DSIV00001021                                                   strLot_holdRecord_EffectSPCCheckResult_in );
//DSIV00001021    if( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSPCCheckResult__100() != RC_OK", rc);
//DSIV00001021        strCollectedDataActionReqResult.strResult = strLot_holdRecord_EffectSPCCheckResult_out.strResult;
//DSIV00001021        return rc;
//DSIV00001021    }
//DSIV00000214 add end
//DSIV00001021 add start
    objLot_holdRecord_EffectSPCCheckResult_out__101 strLot_holdRecord_EffectSPCCheckResult_out;
    objLot_holdRecord_EffectSPCCheckResult_in__101  strLot_holdRecord_EffectSPCCheckResult_in;
    strLot_holdRecord_EffectSPCCheckResult_in.strSpcCheckLot = strSpcCheckReqResult.strSpcCheckLot;
    strLot_holdRecord_EffectSPCCheckResult_in.strInterFabMonitorGroupActionInfoSequence = strLot_holdRecord_EffectSpecCheckResult_out.strInterFabMonitorGroupActionInfoSequence;
    strLot_holdRecord_EffectSPCCheckResult_in.strDCActionLotResult = strLot_holdRecord_EffectSpecCheckResult_out.strDCActionLotResult;
    rc = lot_holdRecord_EffectSPCCheckResult__101( strLot_holdRecord_EffectSPCCheckResult_out, strObjCommonIn,
                                                   strLot_holdRecord_EffectSPCCheckResult_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSPCCheckResult__101() != RC_OK", rc);
        strCollectedDataActionReqResult.strResult = strLot_holdRecord_EffectSPCCheckResult_out.strResult;
        return rc;
    }
//DSIV00001021 add end

    CORBA::Long nSPCLotHoldEffectListLen = 0;
    nSPCLotHoldEffectListLen = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList.length();
    if ( nSPCLotHoldEffectListLen  > 0 )
    {
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList.length()", nSPCLotHoldEffectListLen);

        pptHoldLotReqResult strHoldLotReqResult;

        pptHoldListSequence strLotHoldReqList;
        strLotHoldReqList.length( 1 );

        for( i = 0; i < nSPCLotHoldEffectListLen; i++ )
        {
            strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].holdType;
            strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].reasonCodeID;
            strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].userID;
            strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].responsibleOperationMark;
            strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].routeID;
            strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].operationNumber;
            strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].relatedLotID;
            strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].claimMemo;

            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].lotID , strLotHoldReqList );
            if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
                strCollectedDataActionReqResult.strResult = strHoldLotReqResult.strResult;
                return( rc );
            }
        }
    }

    CORBA::Long nSPCFutureHoldEffectLen = 0;
    nSPCFutureHoldEffectLen = strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList.length();
    if ( nSPCFutureHoldEffectLen  > 0 )
    {
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList.length()", nSPCFutureHoldEffectLen);

        for( i=0; i< nSPCFutureHoldEffectLen; i++ )
        {
            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult, strObjCommonIn ,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].holdType ,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].lotID,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].routeID,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].operationNumber,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
                                          TRUE,
                                          TRUE,
                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].claimMemo );
            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
            {
                PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY");
                strCollectedDataActionReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
                return( rc );
            }
        }
    }

//DSIV00000214 add start
    pptInterFabMonitorGroupActionInfoSequence tmpInterFabMonitorGroupActionInfoSequence;
    tmpInterFabMonitorGroupActionInfoSequence = strLot_holdRecord_EffectSPCCheckResult_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00000214 add end

    //---------------------------------------------------------------//
    //   Cut Monitor Relation for ProcessMonitorLot and ProcessLot   //
    //---------------------------------------------------------------//
    nCastLen = 0;                          // Initialize for recycling.
    nCastLen = tmpStartCassette.length();
    CORBA::Long holdReleasedLotCount = 0;
    objectIdentifierSequence holdReleasedLotIDs;

    objectIdentifier monitorLotID;
    for ( i=0; i < nCastLen; i++ )
    {
        nLotCastLen = tmpStartCassette[i].strLotInCassette.length();
        for ( j=0; j < nLotCastLen; j++ )
        {
            //---------------------------//
            //   Omit Not-OpeStart Lot   //
            //---------------------------//
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            //-----------------------------//
            //   Delete Monitor Grouping   //
            //-----------------------------//
//DSIV00000214            objMonitorGroup_DeleteComp_out  strMonitorGroup_DeleteComp_out;
//DSIV00000214            rc = monitorGroup_DeleteComp( strMonitorGroup_DeleteComp_out, strObjCommonIn,
//DSIV00000214                                          tmpStartCassette[i].strLotInCassette[j].lotID);
//DSIV00000214            if ( rc != RC_OK )
//DSIV00000214            {
//DSIV00000214                PPT_METHODTRACE_V1("", "monitorGroup_DeleteComp() != RC_OK") ;
//DSIV00000214                strCollectedDataActionReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult ;
//DSIV00000214                return( rc );
//DSIV00000214            }
//DSIV00000214 add start
            objMonitorGroup_DeleteComp_out__100 strMonitorGroup_DeleteComp_out;
            objMonitorGroup_DeleteComp_in__100  strMonitorGroup_DeleteComp_in;
            strMonitorGroup_DeleteComp_in.lotID = tmpStartCassette[i].strLotInCassette[j].lotID;
            strMonitorGroup_DeleteComp_in.strInterFabMonitorGroupActionInfoSequence = tmpInterFabMonitorGroupActionInfoSequence;
            rc = monitorGroup_DeleteComp__100( strMonitorGroup_DeleteComp_out, strObjCommonIn,
                                               strMonitorGroup_DeleteComp_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "monitorGroup_DeleteComp__100() != RC_OK", rc);
                strCollectedDataActionReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult;
                return rc;
            }

            tmpInterFabMonitorGroupActionInfoSequence = strMonitorGroup_DeleteComp_out.strInterFabMonitorGroupActionInfoSequence;
//DSIV00000214 add end

            CORBA::Long nMonitorCompLotsLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length();

            if( nMonitorCompLotsLen != 0 )
            {
                // Preparing for HoldRelease.
                pptHoldLotReleaseReqResult strHoldLotReleaseReqResult;
                objectIdentifier aReasonCodeID;
                aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_WaitingMonitorHoldRelease );

                holdReleasedLotIDs.length(holdReleasedLotCount + nMonitorCompLotsLen);

                for( k = 0; k < nMonitorCompLotsLen; k++ )
                {
                    CORBA::Long nLotHoldLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].strLotHoldReleaseReqList.length();
                    if ( nLotHoldLen > 0 )
                    {
                        rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn,
                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID,
                                                  aReasonCodeID,
                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].strLotHoldReleaseReqList );
                        if( rc != RC_OK)
                        {
                            PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK");
                            strCollectedDataActionReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                            return (rc);
                        }

                        //----------------------------------------
                        //Return Hold Released LotID for Caller
                        //----------------------------------------
                        holdReleasedLotIDs[holdReleasedLotCount] = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID;

                        PPT_METHODTRACE_V3("","Hold Released LotID", holdReleasedLotCount,  holdReleasedLotIDs[holdReleasedLotCount].identifier );
                        holdReleasedLotCount++;

                        //------------------------------------------
                        //  Check Lot Type of Monitoring Lot
                        //------------------------------------------
                        if( CIMFWStrCmp( SP_Lot_Type_ProductionLot, tmpStartCassette[i].strLotInCassette[j].lotType ) == 0 )
                        {
                            while( 1 )
                            {
                                //------------------------------------------
                                //  Check whether GatePass is required
                                //------------------------------------------
                                PPT_METHODTRACE_V2("", "===== repeatGatePass_CheckCondition() ========",tmpStartCassette[i].strLotInCassette[j].lotID.identifier);

                                objRepeatGatePass_CheckCondition_out  strRepeatGatePass_CheckCondition_out;
                                strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag = TRUE;
                                rc = repeatGatePass_CheckCondition( strRepeatGatePass_CheckCondition_out, strObjCommonIn,
                                                                    tmpStartCassette[i].strLotInCassette[j].lotID,
                                                                    strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID );
                                if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "repeatGatePass_CheckCondition() != RC_OK", rc);
                                    strCollectedDataActionReqResult.strResult = strRepeatGatePass_CheckCondition_out.strResult;
                                    return( rc );
                                }
                                if( strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag == FALSE )
                                {
                                    PPT_METHODTRACE_V1("", "gatePassRequiredFlag == FALSE");
                                    break;  // break while loop.
                                }

                                //--------------------------------
                                //  Get Monitored Lot's Info
                                //--------------------------------
                                objLot_currentOperationInfo_Get_out  strLot_currentOperationInfo_Get_out;
                                rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn,
                                                                   strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID );
                                if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK", rc);
                                    strCollectedDataActionReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
                                    return( rc );
                                }

                                //------------------------------------------
                                //  Call txGatePassReq
                                //------------------------------------------
                                pptGatePassReqResult        strGatePassReqResult;
                                CORBA::Long                 seqIndex = 0;
                                pptGatePassLotInfoSequence  strGatePassLotInfo;
                                objectIdentifierSequence    dummyLotIDs;            //for Return, but it's dummy.

                                strGatePassReqResult.strGatePassLotsResult.length( 1 );
                                strGatePassLotInfo.length( 1 );
                                strGatePassLotInfo[0].lotID                  = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID;
                                strGatePassLotInfo[0].currentRouteID         = strLot_currentOperationInfo_Get_out.routeID;
                                strGatePassLotInfo[0].currentOperationNumber = CIMFWStrDup( strLot_currentOperationInfo_Get_out.operationNumber );

                                rc = txGatePassReq( strGatePassReqResult,strObjCommonIn,
                                                    seqIndex, strGatePassLotInfo, claimMemo, dummyLotIDs );
                                if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "txGatePassReq() != RC_OK", rc);
                                    strCollectedDataActionReqResult.strResult = strGatePassReqResult.strResult;
                                    return( rc );
                                }
                            } // while loop
                        }
                        else
                        {
                            // Lot Type is not SP_Lot_Type_ProductionLot.
                            continue;
                        }
                    } // Monitor Hold Released Lot List.
                } // MonitorCompLotsLen Loop
            } // MonitorCompLotsLen != 0
        } // Start Lot In Cassette Len
    } // Start Cassette Len

//DSIV00000214 add start
    //------------------------------------------------------------------------------------//
    //   MonitorGroupRelease, Hold and SpecOver/SPCViolation mail Request for other Fab   //
    //------------------------------------------------------------------------------------//
    CORBA::Long monRelLen = tmpInterFabMonitorGroupActionInfoSequence.length();
    PPT_METHODTRACE_V2("", "monitoringLots count", monRelLen);
    for( i=0; i<monRelLen; i++ )
    {
        PPT_METHODTRACE_V1("","monitorGroupRelease required flag for other fab is TRUE.");
        objMonitorGroupRelease_RequestForMultiFab_out strMonitorGroupRelease_RequestForMultiFab_out;
        objMonitorGroupRelease_RequestForMultiFab_in  strMonitorGroupRelease_RequestForMultiFab_in;
        strMonitorGroupRelease_RequestForMultiFab_in.strInterFabMonitorGroupActionInfo = tmpInterFabMonitorGroupActionInfoSequence[i];
        rc = monitorGroupRelease_RequestForMultiFab( strMonitorGroupRelease_RequestForMultiFab_out,
                                                     strObjCommonIn,
                                                     strMonitorGroupRelease_RequestForMultiFab_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "monitorGroupRelease_RequestForMultiFab() != RC_OK", rc);
            strCollectedDataActionReqResult.strResult = strMonitorGroupRelease_RequestForMultiFab_out.strResult;
            return rc;
        }
    }
//DSIV00000214 add end

    // Resize HoldReleasedLotIDs length.
    holdReleasedLotIDs.length(holdReleasedLotCount);
    PPT_METHODTRACE_V2("","HoldReleased Lot Count is", holdReleasedLotCount );

    // Set HoldReleasedLots to return structure.
    strCollectedDataActionReqResult.holdReleasedLotIDs = holdReleasedLotIDs;

//P7000348 add start
    //----------------------------------------------------//
    //   Update PO's collected data information finally   //
    //----------------------------------------------------//
    PPT_METHODTRACE_V1("", "Update PO's collected data information finally.");
//DSIV00001021    objProcess_dataCollectionInformation_Update_out strProcess_dataCollectionInformation_Update_out;
//DSIV00001021    rc = process_dataCollectionInformation_Update( strProcess_dataCollectionInformation_Update_out, strObjCommonIn, tmpStartCassette );
//DSIV00001021    if ( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V1("", "process_dataCollectionInformation_Update() != RC_OK");
//DSIV00001021        strCollectedDataActionReqResult.strResult = strProcess_dataCollectionInformation_Update_out.strResult;
//DSIV00001021        return( rc );
//DSIV00001021    }
//P7000348 add end
//DSIV00001021 add start
    objProcess_dataCollectionInformation_Update_out__101 strProcess_dataCollectionInformation_Update_out;
    rc = process_dataCollectionInformation_Update__101( strProcess_dataCollectionInformation_Update_out, strObjCommonIn, tmpStartCassette, strLot_holdRecord_EffectSPCCheckResult_out.strDCActionLotResult );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_dataCollectionInformation_Update__101() != RC_OK");
        strCollectedDataActionReqResult.strResult = strProcess_dataCollectionInformation_Update_out.strResult;
        return( rc );
    }
//DSIV00001021 add end
//INN-R170009 add start
    CORBA::String_var APCAvailable = CIMFWStrDup(getenv(SP_APC_Available));
    if (CIMFWStrCmp(APCAvailable, SP_CheckFlag_On) == 0 )
    {
        PPT_METHODTRACE_V1("", "if (CIMFWStrCmp(APCAvailable, SP_CheckFlag_On) == 0 )");

        csObjAPCMgr_SendLithoMetrologyInfoReq_out  strObjAPCMgr_SendLithoMetrologyInfoReq_out;
        csObjAPCMgr_SendLithoMetrologyInfoReq_in   strObjAPCMgr_SendLithoMetrologyInfoReq_in;
        strObjAPCMgr_SendLithoMetrologyInfoReq_in.equipmentID      = strCollectedDataActionReqInParm.equipmentID;
        strObjAPCMgr_SendLithoMetrologyInfoReq_in.strStartCassette = tmpStartCassette;
        rc = cs_APCMgr_SendLithoMetrologyInfoReq( strObjAPCMgr_SendLithoMetrologyInfoReq_out,
                                                  strObjCommonIn,
                                                  strObjAPCMgr_SendLithoMetrologyInfoReq_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_APCMgr_SendLithoMetrologyInfoReq() != RC_OK");
            strCollectedDataActionReqResult.strResult = strObjAPCMgr_SendLithoMetrologyInfoReq_out.strResult;
            return ( rc );
        }
    }
//INN-R170009 add end

//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
//DSN000015229 Add End

//DSN000015229 Indent Start
        //---------------------------------------------//
        //   Delete Control Job From Lot and Cassette  //
        //---------------------------------------------//
        PPT_METHODTRACE_V1( "", "Delete controlJob from Lot and Cassette.");
        pptControlJobManageReqResult strControlJobManageReqResult;
        pptControlJobCreateRequest   dummyControlJobCreateRequest;
        rc = txControlJobManageReq( strControlJobManageReqResult, strObjCommonIn,
                                    strCollectedDataActionReqInParm.controlJobID,
                                    SP_ControlJobAction_Type_delete_From_LotAndCassette,
                                    dummyControlJobCreateRequest,
                                    claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
            strCollectedDataActionReqResult.strResult = strControlJobManageReqResult.strResult;
            return( rc );
        }
//DSN000015229 Indent End
    }   //DSN000015229

    //---------------------------------------------------------------//
    //   New Action by SPC Check result                              //
    //---------------------------------------------------------------//
    pptSpcActionExecuteReqResult strSpcActionExecuteReqResult;
    rc = txSpcActionExecuteReq( strSpcActionExecuteReqResult, strObjCommonIn,
                                strStartLot_actionList_EffectSPCCheck_out.strBankMoveList,
                                strStartLot_actionList_EffectSPCCheck_out.strMailSendList,
                                strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList,
                                claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txSpcActionExecuteReq() != RC_OK");
        strCollectedDataActionReqResult.strResult = strSpcActionExecuteReqResult.strResult;
        return(rc);
    }

    //--------------------------//
    //                          //
    //   Set Return Structure   //
    //                          //
    //--------------------------//
//DSIV00001021    objEquipment_FillInTxTRC004_out   strEquipment_FillInTxTRC004_out;
//DSIV00001021    rc = equipment_FillInTxTRC004( strEquipment_FillInTxTRC004_out, strObjCommonIn, tmpStartCassette, strSpcCheckReqResult.strSpcCheckLot);
//DSIV00001021    if ( rc != RC_OK )
//DSIV00001021    {
//DSIV00001021        PPT_METHODTRACE_V1("", "equipment_FillInTxTRC004() != RC_OK") ;
//DSIV00001021        strCollectedDataActionReqResult.strResult = strEquipment_FillInTxTRC004_out.strResult ;
//DSIV00001021        return(rc);
//DSIV00001021    }
//DSIV00001021 add start
    objEquipment_FillInTxTRC004_out__101   strEquipment_FillInTxTRC004_out;
    rc = equipment_FillInTxTRC004__101( strEquipment_FillInTxTRC004_out, strObjCommonIn, tmpStartCassette, strSpcCheckReqResult.strSpcCheckLot);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_FillInTxTRC004__101() != RC_OK");
        strCollectedDataActionReqResult.strResult = strEquipment_FillInTxTRC004_out.strResult;
        return(rc);
    }
//DSIV00001021 add end
//DSN000081739 Add Start
    CORBA::Long eqpMonitorSwitch = atoi( getenv(SP_EQPMONITOR_SWITCH) );
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        for ( CORBA::ULong iCnt=0; iCnt<strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot.length(); iCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot.length()", iCnt);
            objLot_lotType_Get_out strLot_lotType_Get_out;
            objLot_lotType_Get_in  strLot_lotType_Get_in;
            strLot_lotType_Get_in.lotID = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].lotID;
            rc = lot_lotType_Get( strLot_lotType_Get_out,
                                  strObjCommonIn,
                                  strLot_lotType_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
                strCollectedDataActionReqResult.strResult = strLot_lotType_Get_out.strResult;
                return rc;
            }

            if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
              || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot) )
            {
                PPT_METHODTRACE_V1("", "strLot_lotType_Get_out.lotType is Equipment Monitor or Dummy");
                if ( (0 != CIMFWStrCmp(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].specCheckResult, SP_SpecCheckResult_OK)
                   && 0 < CIMFWStrLen(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].specCheckResult)
                   && 0 != CIMFWStrCmp(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].specCheckResult, SP_SpecCheckResult_1Asterisk))
                  || 0 == CIMFWStrCmp(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].spcCheckResult, SP_SPCCheck_HoldLimitOff)
                  || 0 == CIMFWStrCmp(strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].spcCheckResult, SP_SPCCheck_WarningLimitOff) )
                {
                    PPT_METHODTRACE_V1("", "Call eqpMonitorJob_lot_Update");
                    //Update information of EqpMonitor job lot
                    objEqpMonitorJob_lot_Update_out strEqpMonitorJob_lot_Update_out;
                    objEqpMonitorJob_lot_Update_in  strEqpMonitorJob_lot_Update_in;
                    strEqpMonitorJob_lot_Update_in.lotID     = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot[iCnt].lotID;
                    strEqpMonitorJob_lot_Update_in.operation = CIMFWStrDup(SP_EqpMonitorJob_OpeCategory_SpecCheck);
                    rc = eqpMonitorJob_lot_Update( strEqpMonitorJob_lot_Update_out,
                                                   strObjCommonIn,
                                                   strEqpMonitorJob_lot_Update_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "eqpMonitorJob_lot_Update() != RC_OK", rc);
                        strCollectedDataActionReqResult.strResult = strEqpMonitorJob_lot_Update_out.strResult;
                        return rc;
                    }
                }
            }
        }
    }
//DSN000081739 Add End
    strCollectedDataActionReqResult.strOpeCompWithDataReqResult = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult;

    //------------------
    // Return to Main
    //------------------
    SET_MSG_RC(strCollectedDataActionReqResult, MSG_OK, RC_OK);
//INN-R170009    PPT_METHODTRACE_EXIT("PPTManager_i::txCollectedDataActionReq");
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txCollectedDataActionReq"); //INN-R170009
    return( RC_OK );
}
