//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txDurableOpeCompForInternalBufferReq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txDurableOpeCompForInternalBufferReq
(
    csDurableOpeCompForInternalBufferReqResult&         strDurableOpeCompForInternalBufferReqResult,
    const pptObjCommonIn&                               strObjCommonIn,
    const csDurableOpeCompForInternalBufferReqInParam&  strDurableOpeCompForInternalBufferReqInParam,
    const char *                                        claimMemo
    CORBAENV_LAST_CPP
)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txDurableOpeCompForInternalBufferReq");

    /*--------------------------------------------*/
    /*                                            */
    /*      Pre Process                           */
    /*                                            */
    /*--------------------------------------------*/
    // Initialize
    CORBA::Long rc = RC_OK;

    /*--------------------------------------------*/
    /*                                            */
    /*      In-Parameter Trace                    */
    /*                                            */
    /*--------------------------------------------*/
    const csDurableOpeCompForInternalBufferReqInParam& strInParm = strDurableOpeCompForInternalBufferReqInParam;
    PPT_METHODTRACE_V2("", "in-parm equipmentID          ", strInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "in-parm durableControlJobID  ", strInParm.durableControlJobID.identifier);

    if ( 0 >= CIMFWStrLen(strInParm.durableControlJobID.identifier) )
    {
        PPT_METHODTRACE_V1("", "durableControlJobID is empty.");
        SET_MSG_RC( strDurableOpeCompForInternalBufferReqResult, MSG_DURABLECTRLJOBID_BLANK, RC_DURABLECTRLJOBID_BLANK );
        return RC_DURABLECTRLJOBID_BLANK;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Tx ID Check                           */
    /*                                            */
    /*--------------------------------------------*/
    objEquipment_SpecialControlVsTxID_CheckCombination_out strEquipment_SpecialControlVsTxID_CheckCombination_out;
    objEquipment_SpecialControlVsTxID_CheckCombination_in  strEquipment_SpecialControlVsTxID_CheckCombination_in;
    strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID = strInParm.equipmentID;
    rc = equipment_SpecialControlVsTxID_CheckCombination( strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                                          strObjCommonIn,
                                                          strEquipment_SpecialControlVsTxID_CheckCombination_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_SpecialControlVsTxID_CheckCombination() != RC_OK", rc);
        strDurableOpeCompForInternalBufferReqResult.strResult = strEquipment_SpecialControlVsTxID_CheckCombination_out.strResult;
        return rc;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Object Lock Process                   */
    /*                                            */
    /*--------------------------------------------*/
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = strInParm.equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "CSPDC010" );  //CS_TxDurableOpeCompForInternalBufferReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strDurableOpeCompForInternalBufferReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return rc;
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = strInParm.equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2("", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject);
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return rc;
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode == SP_EQP_LOCK_MODE_WRITE");
        PPT_METHODTRACE_V1("", "#### Machine Object Lock ");

        // Machine Object Lock Process
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          strInParm.equipmentID,
                          SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return rc;
        }
    }

    objDurableControlJob_startReserveInformation_Get_out strDurableControlJob_startReserveInformation_Get_out;
    objDurableControlJob_startReserveInformation_Get_in  strDurableControlJob_startReserveInformation_Get_in;
    strDurableControlJob_startReserveInformation_Get_in.durableControlJobID = strInParm.durableControlJobID;
    rc = durableControlJob_startReserveInformation_Get( strDurableControlJob_startReserveInformation_Get_out,
                                                        strObjCommonIn,
                                                        strDurableControlJob_startReserveInformation_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durableControlJob_startReserveInformation_Get() != RC_OK", rc);
        strDurableOpeCompForInternalBufferReqResult.strResult = strDurableControlJob_startReserveInformation_Get_out.strResult;
        return rc;
    }

    CORBA::String_var durableCategory = strDurableControlJob_startReserveInformation_Get_out.durableCategory;
    if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
        PPT_SET_MSG_RC_KEY( strDurableOpeCompForInternalBufferReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            durableCategory );
        return RC_INVALID_DURABLE_CATEGORY ;
    }

    pptStartDurableSequence strStartDurables;
    strStartDurables = strDurableControlJob_startReserveInformation_Get_out.strStartDurables;
    pptDurableStartRecipe strDurableStartRecipe;
    strDurableStartRecipe = strDurableControlJob_startReserveInformation_Get_out.strDurableStartRecipe;
    CORBA::ULong durableLen = strStartDurables.length();
    CORBA::ULong durableCnt = 0;

    if ( lockMode == SP_EQP_LOCK_MODE_WRITE )
    {
        // Lock All Port Object for internal Buffer Equipment.
        objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
        rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                        strObjCommonIn,
                                                        strInParm.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
            strDurableOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
            return rc;
        }

        CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
        for( CORBA::Long indI = 0 ; indI < lenPortInfo ; indI++ )
        {
            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  strInParm.equipmentID,
                                                  strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[indI].portID,
                                                  SP_ClassName_PosPortResource );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource () rc != RC_OK", rc);
                strDurableOpeCompForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
                return rc;
            }

            PPT_METHODTRACE_V2("", "Locked port object : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[indI].portID.identifier);
        }
    }

    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        // Lock Material Location
        for ( durableCnt = 0 ; durableCnt < durableLen ; durableCnt++ )
        {
            PPT_METHODTRACE_V2( "", "calling advanced_object_LockForEquipmentResource()", SP_ClassName_PosMaterialLocation_ByCastID );

            objAdvanced_object_LockForEquipmentResource_in strAdvanced_object_LockForEquipmentResource_in;
            strAdvanced_object_LockForEquipmentResource_in.equipmentID            = strInParm.equipmentID;
            strAdvanced_object_LockForEquipmentResource_in.className              = CIMFWStrDup( SP_ClassName_PosMaterialLocation_ByCastID );
            strAdvanced_object_LockForEquipmentResource_in.objectID               = strStartDurables[durableCnt].durableID;
            strAdvanced_object_LockForEquipmentResource_in.objectLockType         = SP_ObjectLock_LockType_WRITE;
            strAdvanced_object_LockForEquipmentResource_in.bufferResourceName     = strStartDurables[durableCnt].strStartDurablePort.loadPurposeType;
            strAdvanced_object_LockForEquipmentResource_in.bufferResourceLockType = SP_ObjectLock_LockType_READ;

            objAdvanced_object_LockForEquipmentResource_out strAdvanced_object_LockForEquipmentResource_out;
            rc =  advanced_object_LockForEquipmentResource( strAdvanced_object_LockForEquipmentResource_out,
                                                            strObjCommonIn,
                                                            strAdvanced_object_LockForEquipmentResource_in );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_LockForEquipmentResource() != RC_OK", rc);
                strDurableOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_LockForEquipmentResource_out.strResult ;
                return rc;
            }
        }
    }

    // Lock DurableControlJob Object Process
    rc = object_Lock( strObject_Lock_out,
                      strObjCommonIn,
                      strInParm.durableControlJobID,
                      SP_ClassName_PosDurableControlJob );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
        strDurableOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }

    objectIdentifierSequence durableIDs;
    durableIDs.length(durableLen);
    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
        durableIDs[durableCnt] = strStartDurables[durableCnt].durableID;
    }

    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosCassette);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosReticlePod);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosReticlePod );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosProcessDurable);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosProcessDurable );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }

    /*---------------------------------------------------*/
    /*                                                   */
    /*        Durable OnRoute                            */
    /*                                                   */
    /*---------------------------------------------------*/
    CORBA::Boolean onRouteFlag = TRUE;
    CORBA::Boolean tmpOnRouteFlag = TRUE;

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "durable loop index", durableCnt);

        //---------------------------------------
        //  Check Durable OnRoute
        //---------------------------------------
        objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
        objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
        strDurable_OnRoute_Check_in.durableCategory = durableCategory;
        strDurable_OnRoute_Check_in.durableID       = strStartDurables[durableCnt].durableID;
        rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
        if(durableCnt == 0)
        {
            if( rc != RC_DURABLE_ONROUTE )
            {
                onRouteFlag = FALSE;
            }
            PPT_METHODTRACE_V3("", "the first durable OnRoute state",
                               (onRouteFlag?"TRUE":"FALSE"),
                               strStartDurables[durableCnt].durableID.identifier);
        }
        else
        {
            if( rc != RC_DURABLE_ONROUTE )
            {
                PPT_METHODTRACE_V2("", "durable OnRoute state is FALSE", strStartDurables[durableCnt].durableID.identifier);
                tmpOnRouteFlag = FALSE;
            }
            else
            {
                PPT_METHODTRACE_V2("", "durable OnRoute state is TRUE", strStartDurables[durableCnt].durableID.identifier);
                tmpOnRouteFlag = TRUE;
            }

            if(tmpOnRouteFlag != onRouteFlag)
            {
                PPT_METHODTRACE_V1("", "all durable OnRoute state is not same");
                SET_MSG_RC( strDurableOpeCompForInternalBufferReqResult, MSG_DURABLE_ONROUTE_STAT_NOT_SAME, RC_DURABLE_ONROUTE_STAT_NOT_SAME );
                return( RC_DURABLE_ONROUTE_STAT_NOT_SAME );
            }
        }
    }

    CORBA::String_var onlineMode;
    CORBA::String_var accessMode;
    objectIdentifier operationMode;
    if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette) )
    {
        // Get and Check Cassette on Port
        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                     strObjCommonIn,
                                     strInParm.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_portInfo_Get() != RC_OK");
            strDurableOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
            return rc;
        }

        if ( 0 >= strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length() )
        {
            PPT_SET_MSG_RC_KEY( strDurableOpeCompForInternalBufferReqResult,
                                MSG_NOT_FOUND_PORT,
                                RC_NOT_FOUND_PORT,
                                "(This equipment does not have any port.)");
            return RC_NOT_FOUND_PORT;
        }

        // Get Equipment's Online Mode
        objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
        rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                    strObjCommonIn,
                                                    strInParm.equipmentID,
                                                    strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[0].portID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "portResource_currentOperationMode_Get() != RC_OK" );
            strDurableOpeCompForInternalBufferReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
            return rc;
        }

        onlineMode    = strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode;
        accessMode    = strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode;
        operationMode = strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode;
    }
    else
    {
        PPT_METHODTRACE_V1("", "durableCategory != SP_DurableCat_Cassette");

        objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
        rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out,
                                       strObjCommonIn,
                                       strInParm.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
            return rc;
        }

        onlineMode = strEquipment_onlineMode_Get_out.onlineMode;

        if ( 0 == CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod) )
        {
            PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");

            objReticlePodPortResource_currentAccessMode_Get_out strReticlePodPortResource_currentAccessMode_Get_out;
            objReticlePodPortResource_currentAccessMode_Get_in  strReticlePodPortResource_currentAccessMode_Get_in;
            strReticlePodPortResource_currentAccessMode_Get_in.equipmentID      = strInParm.equipmentID;
            strReticlePodPortResource_currentAccessMode_Get_in.reticlePodPortID = strStartDurables[0].strStartDurablePort.unloadPortID;
            rc = reticlePodPortResource_currentAccessMode_Get( strReticlePodPortResource_currentAccessMode_Get_out,
                                                               strObjCommonIn,
                                                               strReticlePodPortResource_currentAccessMode_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "reticlePodPortResource_currentAccessMode_Get() != RC_OK" ,rc);
                strDurableOpeCompForInternalBufferReqResult.strResult = strReticlePodPortResource_currentAccessMode_Get_out.strResult;
                return rc;
            }

            accessMode = strReticlePodPortResource_currentAccessMode_Get_out.accessMode;
        }
    }

    PPT_METHODTRACE_V3("", "onlineMode = Offline or accessMode = Auto", onlineMode, accessMode);

    /*--------------------------------------------*/
    /*                                            */
    /*        Check Process for Durables          */
    /*                                            */
    /*--------------------------------------------*/
    csObjDurable_CheckConditionForOperationForInternalBuffer_in strDurable_CheckConditionForOperationForInternalBuffer_in;
    strDurable_CheckConditionForOperationForInternalBuffer_in.operation             = CIMFWStrDup( SP_Operation_OperationComp );
    strDurable_CheckConditionForOperationForInternalBuffer_in.equipmentID           = strInParm.equipmentID;
    strDurable_CheckConditionForOperationForInternalBuffer_in.durableCategory       = durableCategory;
    strDurable_CheckConditionForOperationForInternalBuffer_in.strStartDurables      = strStartDurables;
    strDurable_CheckConditionForOperationForInternalBuffer_in.strDurableStartRecipe = strDurableStartRecipe;

    csObjDurable_CheckConditionForOperationForInternalBuffer_out strDurable_CheckConditionForOperationForInternalBuffer_out;
    rc = cs_durable_CheckConditionForOperationForInternalBuffer( strDurable_CheckConditionForOperationForInternalBuffer_out,
                                                                 strObjCommonIn,
                                                                 strDurable_CheckConditionForOperationForInternalBuffer_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_durable_CheckConditionForOperationForInternalBuffer() != RC_OK", rc);
        strDurableOpeCompForInternalBufferReqResult.strResult = strDurable_CheckConditionForOperationForInternalBuffer_out.strResult;
        return rc;
    }

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
        objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
        objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
        strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup( SP_Operation_OperationComp );
        strDurable_status_CheckForOperation_in.durableID       = strStartDurables[durableCnt].durableID;
        strDurable_status_CheckForOperation_in.durableCategory = durableCategory;
        rc = durable_status_CheckForOperation( strDurable_status_CheckForOperation_out,
                                               strObjCommonIn,
                                               strDurable_status_CheckForOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_status_CheckForOperation() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
            return rc;
        }
    }

    /*---------------------------------------------------------------*/
    /*                                                               */
    /*        Check Equipment Port for Durable Operation             */
    /*                                                               */
    /*---------------------------------------------------------------*/
    if( 0 == CIMFWStrCmp(onlineMode, SP_Eqp_OnlineMode_Offline)
     || 0 == CIMFWStrCmp(accessMode, SP_Eqp_AccessMode_Auto   ) )
    {
        PPT_METHODTRACE_V3("", "onlineMode = Offline or accessMode = Auto", onlineMode, accessMode);

        csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in;
        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.operation        = CIMFWStrDup( SP_Operation_OperationComp );
        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.equipmentID      = strInParm.equipmentID;
        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.durableCategory  = durableCategory;
        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.strStartDurables = strStartDurables;

        csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out;
        rc = cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                                                   strObjCommonIn,
                                                                                   strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult;
            return rc;
        }
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Main process                        */
    /*                                            */
    /*--------------------------------------------*/
    //---------------------------------------------
    // Update Process Operation
    //---------------------------------------------
    objDurableProcess_actualCompInformation_Set_out strDurableProcess_actualCompInformation_Set_out;
    objDurableProcess_actualCompInformation_Set_in  strDurableProcess_actualCompInformation_Set_in;
    strDurableProcess_actualCompInformation_Set_in.durableCategory  = durableCategory;
    strDurableProcess_actualCompInformation_Set_in.strStartDurables = strStartDurables;
    rc = durableProcess_actualCompInformation_Set( strDurableProcess_actualCompInformation_Set_out,
                                                   strObjCommonIn,
                                                   strDurableProcess_actualCompInformation_Set_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durableProcess_actualCompInformation_Set() != RC_OK", rc);
        strDurableOpeCompForInternalBufferReqResult.strResult = strDurableProcess_actualCompInformation_Set_out.strResult;
        return rc;
    }

    //---------------------------------------------
    // Change durable Process State to Waiting
    //---------------------------------------------
    if(onRouteFlag == TRUE)
    {
        PPT_METHODTRACE_V1("", "onRouteFlag == TRUE");
        objDurable_processState_MakeWaiting_out strDurable_processState_MakeWaiting_out;
        objDurable_processState_MakeWaiting_in  strDurable_processState_MakeWaiting_in;
        strDurable_processState_MakeWaiting_in.durableCategory  = durableCategory;
        strDurable_processState_MakeWaiting_in.strStartDurables = strStartDurables;
        rc = durable_processState_MakeWaiting(strDurable_processState_MakeWaiting_out,
                                              strObjCommonIn,
                                              strDurable_processState_MakeWaiting_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_processState_MakeWaiting() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strDurable_processState_MakeWaiting_out.strResult;
            return rc;
        }
    }

    //---------------------------------------------
    // Procedure for PO Moving
    //---------------------------------------------
    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strStartDurables.length()", durableCnt);
        objDurableProcess_Move_out strDurableProcess_Move_out;
        objDurableProcess_Move_in  strDurableProcess_Move_in;
        strDurableProcess_Move_in.durableCategory = durableCategory;
        strDurableProcess_Move_in.durableID       = strStartDurables[durableCnt].durableID;
        rc = durableProcess_Move( strDurableProcess_Move_out,
                                  strObjCommonIn,
                                  strDurableProcess_Move_in );

        if (rc == RC_ADDTOQUEUE_FAIL)
        {
            PPT_METHODTRACE_V2("", "durableProcess_Move() == RC_ADDTOQUEUE_FAIL", rc);
            objDurable_currentOperationInfo_Get_out strDurable_currentOperationInfo_Get_out;
            objDurable_currentOperationInfo_Get_in  strDurable_currentOperationInfo_Get_in;
            strDurable_currentOperationInfo_Get_in.durableCategory = durableCategory;
            strDurable_currentOperationInfo_Get_in.durableID       = strStartDurables[durableCnt].durableID;
            rc = durable_currentOperationInfo_Get( strDurable_currentOperationInfo_Get_out,
                                                   strObjCommonIn,
                                                   strDurable_currentOperationInfo_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "durable_currentOperationInfo_Get() != RC_OK", rc);
                strDurableOpeCompForInternalBufferReqResult.strResult = strDurable_currentOperationInfo_Get_out.strResult;
                return rc;
            }

            pptHoldDurableReqResult    strHoldDurableReqResult;
            pptHoldDurableReqInParam   strHoldDurableReqInParam;
            objectIdentifier           dummyDurableID;
            pptDurableHoldListSequence strDurableHoldList;
            strDurableHoldList.length(1);
            strDurableHoldList[0].holdType                 = CIMFWStrDup(SP_HoldType_AddToQueueErrHold);
            strDurableHoldList[0].holdReasonCodeID.identifier = CIMFWStrDup(SP_Reason_AddToQueueErrHold);
            strDurableHoldList[0].holdUserID               = strObjCommonIn.strUser.userID;
            strDurableHoldList[0].responsibleOperationMark = CIMFWStrDup(SP_ResponsibleOperation_Current);
            strDurableHoldList[0].routeID                  = strDurable_currentOperationInfo_Get_out.routeID;
            strDurableHoldList[0].operationNumber          = strDurable_currentOperationInfo_Get_out.operationNumber;
            strDurableHoldList[0].relatedDurableID         = dummyDurableID;
            strDurableHoldList[0].relatedDurableCategory   = CIMFWStrDup("");
            strDurableHoldList[0].claimMemo                = CIMFWStrDup("");
            strHoldDurableReqInParam.durableCategory    = durableCategory;
            strHoldDurableReqInParam.durableID          = strStartDurables[durableCnt].durableID;
            strHoldDurableReqInParam.strDurableHoldList = strDurableHoldList;
            rc = txHoldDurableReq(strHoldDurableReqResult, strObjCommonIn, strHoldDurableReqInParam, claimMemo);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txHoldDurableReq() != RC_OK", rc);
                strDurableOpeCompForInternalBufferReqResult.strResult = strHoldDurableReqResult.strResult;
                return rc;
            }
        }

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durableProcess_Move() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strDurableProcess_Move_out.strResult;
            return rc;
        }
    }

    //---------------------------------------------
    // Maintain Eqp's Status when OFF-LINE Mode
    //---------------------------------------------
    if ( 0 == CIMFWStrCmp(onlineMode, SP_Eqp_OnlineMode_Offline) )
    {
        PPT_METHODTRACE_V1("", "onlineMode == SP_Eqp_OnlineMode_Offline");

        /*-----------------------------------------------*/
        /*   Change Equipment's Status to 'PRODUCTIVE'   */
        /*-----------------------------------------------*/

        /*===== get StateChageableFlag ===*/
        objEquipment_currentState_CheckToManufacturing_out strEquipment_currentState_CheckToManufacturing_out;
        strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag = FALSE;
        rc = equipment_currentState_CheckToManufacturing( strEquipment_currentState_CheckToManufacturing_out,
                                                          strObjCommonIn,
                                                          strInParm.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_currentState_GetManufacturing() != RC_OK", rc);
            strDurableOpeCompForInternalBufferReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult;
            return rc;
        }

        if ( TRUE == strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag )
        {
            PPT_METHODTRACE_V1("", "ManufacturingStateChangeableFlag == TRUE");

            /*===== get Defaclt Status Code for Productive / Standby ===*/
            objEquipment_recoverState_GetManufacturingForDurable_out strEquipment_recoverState_GetManufacturingForDurable_out;
            objEquipment_recoverState_GetManufacturingForDurable_in strEquipment_recoverState_GetManufacturingForDurable_in;
            strEquipment_recoverState_GetManufacturingForDurable_in.operationType = CIMFWStrDup(SP_Operation_OperationComp);
            strEquipment_recoverState_GetManufacturingForDurable_in.equipmentID = strInParm.equipmentID;
            strEquipment_recoverState_GetManufacturingForDurable_in.durableControlJobID = strInParm.durableControlJobID;
            rc = equipment_recoverState_GetManufacturingForDurable( strEquipment_recoverState_GetManufacturingForDurable_out,
                                                                    strObjCommonIn,
                                                                    strEquipment_recoverState_GetManufacturingForDurable_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_recoverState_GetManufacturingForDurable() != RC_OK", rc);
                strDurableOpeCompForInternalBufferReqResult.strResult = strEquipment_recoverState_GetManufacturingForDurable_out.strResult;
                return rc;
            }

            /*---------------------------------*/
            /*   Call txEqpStatusChangeReq()   */
            /*---------------------------------*/
            pptEqpStatusChangeReqResult strEqpStatusChangeReqResult;
            rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult,
                                       strObjCommonIn,
                                       strInParm.equipmentID,
                                       strEquipment_recoverState_GetManufacturingForDurable_out.equipmentStatusCode,
                                       claimMemo );
            if ( rc != RC_OK && rc != RC_CURRSTATE_SAME )
            {
                PPT_METHODTRACE_V2("", "txEqpStatusChangeReq() != RC_OK", rc);
                strDurableOpeCompForInternalBufferReqResult.strResult = strEqpStatusChangeReqResult.strResult;
                return rc;
            }
        }
    }

    /*--------------------------------------*/
    /*   Equipment Usage Limitation Check   */
    /*--------------------------------------*/
    objEquipment_usageLimitation_Check_out strEquipment_usageLimitation_Check_out;
    strEquipment_usageLimitation_Check_out.usageLimitOverFlag = FALSE;
    rc = equipment_usageLimitation_Check( strEquipment_usageLimitation_Check_out,
                                          strObjCommonIn,
                                          strInParm.equipmentID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_usageLimitation_Check() != RC_OK", rc) ;
        strDurableOpeCompForInternalBufferReqResult.strResult = strEquipment_usageLimitation_Check_out.strResult ;
        return rc;
    }

    if ( TRUE == strEquipment_usageLimitation_Check_out.usageLimitOverFlag )
    {
        PPT_METHODTRACE_V1("", "strEquipment_usageLimitation_Check_out.usageLimitOverFlag == TRUE");

        /*-------------------------*/
        /*   Call System Message   */
        /*-------------------------*/
        pptSystemMsgRptResult strSystemMsgRptResult;
        objectIdentifier      dummy;

        rc = txSystemMsgRpt( strSystemMsgRptResult,
                             strObjCommonIn,
                             SP_SubSystemID_MM,
                             SP_SystemMsgCode_EqpUsageLimitOver,
                             strEquipment_usageLimitation_Check_out.messageText,
                             TRUE,
                             strInParm.equipmentID,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             dummy,
                             "",
                             strObjCommonIn.strTimeStamp.reportTimeStamp,
                             "" );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
            strDurableOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
            return rc;
        }
    }

    //-----------------------------------
    // Delete Durable Control Job
    //-----------------------------------
    pptDurableControlJobManageReqResult  strDurableControlJobManageReqResult;
    pptDurableControlJobManageReqInParam strDurableControlJobManageReqInParam;
    strDurableControlJobManageReqInParam.durableControlJobID               = strInParm.durableControlJobID;
    strDurableControlJobManageReqInParam.controlJobAction                  = CIMFWStrDup( SP_DurableControlJobAction_Type_delete );
    pptDurableControlJobCreateRequest strDurableControlJobCreateRequest;
    strDurableControlJobCreateRequest.equipmentID      = strInParm.equipmentID;
    strDurableControlJobCreateRequest.durableCategory  = durableCategory;
    strDurableControlJobCreateRequest.strStartDurables = strStartDurables;
    strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest = strDurableControlJobCreateRequest;
    rc = txDurableControlJobManageReq( strDurableControlJobManageReqResult,
                                       strObjCommonIn,
                                       strDurableControlJobManageReqInParam,
                                       claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txDurableControlJobManageReq() != RC_OK", rc);
        strDurableOpeCompForInternalBufferReqResult.strResult = strDurableControlJobManageReqResult.strResult;
        return rc;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Create Event                        */
    /*                                            */
    /*--------------------------------------------*/
    objDurableOperationCompleteEvent_MakeOpeComp_out strDurableOperationCompleteEvent_MakeOpeComp_out;
    objDurableOperationCompleteEvent_MakeOpeComp_in  strDurableOperationCompleteEvent_MakeOpeComp_in;
    strDurableOperationCompleteEvent_MakeOpeComp_in.equipmentID           = strInParm.equipmentID;
    strDurableOperationCompleteEvent_MakeOpeComp_in.operationMode         = operationMode.identifier;
    strDurableOperationCompleteEvent_MakeOpeComp_in.durableControlJobID   = strInParm.durableControlJobID;
    strDurableOperationCompleteEvent_MakeOpeComp_in.durableCategory       = durableCategory;
    strDurableOperationCompleteEvent_MakeOpeComp_in.strStartDurables      = strStartDurables;
    strDurableOperationCompleteEvent_MakeOpeComp_in.strDurableStartRecipe = strDurableStartRecipe;
    strDurableOperationCompleteEvent_MakeOpeComp_in.claimMemo             = claimMemo;
    rc = durableOperationCompleteEvent_MakeOpeComp( strDurableOperationCompleteEvent_MakeOpeComp_out,
                                                    strObjCommonIn,
                                                    strDurableOperationCompleteEvent_MakeOpeComp_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durableOperationCompleteEvent_MakeOpeComp() != RC_OK", rc);
        strDurableOpeCompForInternalBufferReqResult.strResult = strDurableOperationCompleteEvent_MakeOpeComp_out.strResult;
        return rc;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Execute BR Script                   */
    /*                                            */
    /*--------------------------------------------*/
    if(onRouteFlag == TRUE)
    {
        PPT_METHODTRACE_V1("", "onRouteFlag == TRUE");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            pptRunDurableBRScriptReqResult  strRunDurableBRScriptReqResult;
            pptRunDurableBRScriptReqInParam strRunDurableBRScriptReqInParam;
            strRunDurableBRScriptReqInParam.phase           = CIMFWStrDup(SP_BRScript_Post);
            strRunDurableBRScriptReqInParam.durableCategory = durableCategory;
            strRunDurableBRScriptReqInParam.durableID       = strStartDurables[durableCnt].durableID;
            strRunDurableBRScriptReqInParam.equipmentID     = strInParm.equipmentID;
            rc = txRunDurableBRScriptReq(strRunDurableBRScriptReqResult, strObjCommonIn, strRunDurableBRScriptReqInParam, claimMemo);

            if(rc != RC_OK && rc != RC_NOT_FOUND_SCRIPT)
            {
                PPT_METHODTRACE_V2("", "txRunDurableBRScriptReq() != RC_OK", rc);
                strDurableOpeCompForInternalBufferReqResult.strResult = strRunDurableBRScriptReqResult.strResult;
                return rc;
            }
        }
    }

    /*---------------------------------------------------------*/
    /*                                                         */
    /*        Send DurableOpeCompReq() to TCS                  */
    /*                                                         */
    /*---------------------------------------------------------*/
    CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0;
    CORBA::Long retryCountValue = 0;

    if ( 0 == CIMFWStrLen(tmpSleepTimeValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = atoi(tmpSleepTimeValue);
    }

    if ( 0 == CIMFWStrLen(tmpRetryCountValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("", "env value of SP_BIND_SLEEP_TIME_TCS  = ", sleepTimeValue);
    PPT_METHODTRACE_V2("", "env value of SP_BIND_RETRY_COUNT_TCS = ", retryCountValue);

    objTCSMgr_SendDurableOpeCompReq_out strTCSMgr_SendDurableOpeCompReq_out;
    objTCSMgr_SendDurableOpeCompReq_in  strTCSMgr_SendDurableOpeCompReq_in;
    strTCSMgr_SendDurableOpeCompReq_in.strDurableOpeCompReqInParam.equipmentID         = strInParm.equipmentID;
    strTCSMgr_SendDurableOpeCompReq_in.strDurableOpeCompReqInParam.durableControlJobID = strInParm.durableControlJobID;
    strTCSMgr_SendDurableOpeCompReq_in.claimMemo                                       = claimMemo;

    //'retryCountValue + 1' means first try plus retry count
    for ( CORBA::ULong retryNum=0; retryNum < (retryCountValue + 1); retryNum++ )
    {
        PPT_METHODTRACE_V2("", "loop to retryCountValue + 1", retryNum);
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        rc = TCSMgr_SendDurableOpeCompReq( strTCSMgr_SendDurableOpeCompReq_out,
                                           strObjCommonIn,
                                           strTCSMgr_SendDurableOpeCompReq_in );

        PPT_METHODTRACE_V2("", "rc = ", rc);

        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL
               || rc == RC_EXT_SERVER_NIL_OBJ
               || rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("", "TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...", retryNum);
            PPT_METHODTRACE_V2("", "now sleeping... ", sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendDurableOpeCompReq() != RC_OK");
            strDurableOpeCompForInternalBufferReqResult.strResult = strTCSMgr_SendDurableOpeCompReq_out.strResult;
            return rc;
        }
    }

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "TCSMgr_SendDurableOpeCompReq() != RC_OK");
        strDurableOpeCompForInternalBufferReqResult.strResult = strTCSMgr_SendDurableOpeCompReq_out.strResult;
        return rc;
    }

    // Set Return Structure
    strDurableOpeCompForInternalBufferReqResult.durableCategory  = durableCategory;
    strDurableOpeCompForInternalBufferReqResult.strStartDurables = strStartDurables;

    // Return to caller
    SET_MSG_RC( strDurableOpeCompForInternalBufferReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txDurableOpeCompForInternalBufferReq");
    return RC_OK;
}
