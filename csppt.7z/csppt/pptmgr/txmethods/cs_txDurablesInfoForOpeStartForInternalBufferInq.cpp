//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txDurablesInfoForOpeStartForInternalBufferInq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txDurablesInfoForOpeStartForInternalBufferInq
(
    csDurablesInfoForOpeStartForInternalBufferInqResult&        strDurablesInfoForOpeStartForInternalBufferInqResult,
    const pptObjCommonIn&                                       strObjCommonIn,
    const csDurablesInfoForOpeStartForInternalBufferInqInParam& strDurablesInfoForOpeStartForInternalBufferInqInParam
    CORBAENV_LAST_CPP
)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txDurablesInfoForOpeStartForInternalBufferInq");

    /*--------------------------------------------*/
    /*                                            */
    /*      Pre Process                           */
    /*                                            */
    /*--------------------------------------------*/
    // Initialize
    CORBA::Long rc = RC_OK;

    CORBA::ULong i = 0;
    CORBA::ULong j = 0;
    CORBA::ULong durableLen = strDurablesInfoForOpeStartForInternalBufferInqInParam.durableIDs.length();

    /*--------------------------------------------------------------------------------*/
    /* 1.Transaction ID and SpecialControls of Equipment Category consistency Check.  */
    /*--------------------------------------------------------------------------------*/
    objEquipment_SpecialControlVsTxID_CheckCombination_out strEquipment_SpecialControlVsTxID_CheckCombination_out;
    objEquipment_SpecialControlVsTxID_CheckCombination_in  strEquipment_SpecialControlVsTxID_CheckCombination_in;
    strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID = strDurablesInfoForOpeStartForInternalBufferInqInParam.equipmentID;
    rc = equipment_SpecialControlVsTxID_CheckCombination( strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                                          strObjCommonIn,
                                                          strEquipment_SpecialControlVsTxID_CheckCombination_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_SpecialControlVsTxID_CheckCombination() != RC_OK", rc);
        strDurablesInfoForOpeStartForInternalBufferInqResult.strResult = strEquipment_SpecialControlVsTxID_CheckCombination_out.strResult;
        return rc;
    }

    /*---------------------------------------------*/
    /* 2.Get reserved durable control job list.    */
    /*---------------------------------------------*/
    objEquipment_reservedDurableControlJobID_GetDR_out strEquipment_reservedDurableControlJobID_GetDR_out;
    objEquipment_reservedDurableControlJobID_GetDR_in  strEquipment_reservedDurableControlJobID_GetDR_in;
    strEquipment_reservedDurableControlJobID_GetDR_in.equipmentID = strDurablesInfoForOpeStartForInternalBufferInqInParam.equipmentID;
    rc = equipment_reservedDurableControlJobID_GetDR( strEquipment_reservedDurableControlJobID_GetDR_out,
                                                      strObjCommonIn,
                                                      strEquipment_reservedDurableControlJobID_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_reservedDurableControlJobID_GetDR() != RC_OK", rc);
        strDurablesInfoForOpeStartForInternalBufferInqResult.strResult = strEquipment_reservedDurableControlJobID_GetDR_out.strResult;
        return rc;
    }

    CORBA::ULong reservedDCJLen = strEquipment_reservedDurableControlJobID_GetDR_out.reservedDurableControlJobIDs.length();
    PPT_METHODTRACE_V2("", "strEquipment_reservedDurableControlJobID_GetDR_out.reservedDurableControlJobIDs.length()", reservedDCJLen);

    /*---------------------------------------------*/
    /* 3.Get durable control job list.             */
    /*---------------------------------------------*/
    objDurableControlJobList_GetDR_out strDurableControlJobList_GetDR_out;
    objDurableControlJobList_GetDR_in  strDurableControlJobList_GetDR_in;
    strDurableControlJobList_GetDR_in.equipmentID     = strDurablesInfoForOpeStartForInternalBufferInqInParam.equipmentID;
    strDurableControlJobList_GetDR_in.durableJobID    = strDurablesInfoForOpeStartForInternalBufferInqInParam.durableControlJobID;
    strDurableControlJobList_GetDR_in.durableInfoFlag = FALSE;
    rc = durableControlJobList_GetDR( strDurableControlJobList_GetDR_out, strObjCommonIn, strDurableControlJobList_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durableControlJobList_GetDR() != RC_OK", rc);
        strDurablesInfoForOpeStartForInternalBufferInqResult.strResult = strDurableControlJobList_GetDR_out.strResult;
        return rc;
    }

    CORBA::ULong dcjListLen = strDurableControlJobList_GetDR_out.strDurableControlJobListInfoSeq.length();
    PPT_METHODTRACE_V2("", "strDurableControlJobList_GetDR_out.strDurableControlJobListInfoSeq.length()", dcjListLen);

    if ( 0 >= dcjListLen )
    {
        SET_MSG_RC( strDurablesInfoForOpeStartForInternalBufferInqResult, MSG_DURABLECTRLJOBID_BLANK, RC_DURABLECTRLJOBID_BLANK);
        return RC_DURABLECTRLJOBID_BLANK;
    }

    /*-------------------------------------------------------------------------------------------------------*/
    /* 4.If durables durableControlJobID is not exist in equipment reserved durableControlJobs, error return */
    /*-------------------------------------------------------------------------------------------------------*/
    for ( j=0; j<dcjListLen; j++)
    {
        CORBA::Boolean findFlag = FALSE;

        for ( CORBA::ULong k=0; k<reservedDCJLen; k++)
        {
            if ( 0 == CIMFWStrCmp(strDurableControlJobList_GetDR_out.strDurableControlJobListInfoSeq[j].durableControlJobID.identifier,
                                  strEquipment_reservedDurableControlJobID_GetDR_out.reservedDurableControlJobIDs[k].identifier) )
            {
                findFlag = TRUE;
                break;
            }
        }

        if ( findFlag == FALSE )
        {
            PPT_METHODTRACE_V1( "", "findFlag == FALSE" );
            SET_MSG_RC( strDurablesInfoForOpeStartForInternalBufferInqResult, MSG_NOT_RESERVED_DCTRLJOB_PORTGRP, RC_NOT_RESERVED_DCTRLJOB_PORTGRP);
            return RC_NOT_RESERVED_DCTRLJOB_PORTGRP;
        }
    }

    /*--------------------------------------------------------------*/
    /* 5.Get start reservation information of durable control job.  */
    /*--------------------------------------------------------------*/
    objDurableControlJob_startReserveInformation_Get_out strDurableControlJob_startReserveInformation_Get_out;
    objDurableControlJob_startReserveInformation_Get_in  strDurableControlJob_startReserveInformation_Get_in;
    strDurableControlJob_startReserveInformation_Get_in.durableControlJobID = strDurablesInfoForOpeStartForInternalBufferInqInParam.durableControlJobID;
    rc = durableControlJob_startReserveInformation_Get( strDurableControlJob_startReserveInformation_Get_out,
                                                        strObjCommonIn,
                                                        strDurableControlJob_startReserveInformation_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durableControlJob_startReserveInformation_Get() != RC_OK", rc);
        strDurablesInfoForOpeStartForInternalBufferInqResult.strResult = strDurableControlJob_startReserveInformation_Get_out.strResult;
        return rc;
    }

    /*-----------------------------------------------------*/
    /* 6.Check all carrier of control job is input or not  */
    /*-----------------------------------------------------*/
    CORBA::Long nDCJDurableLen = strDurableControlJob_startReserveInformation_Get_out.strStartDurables.length();
    CORBA::Long nInputDurableLen = strDurablesInfoForOpeStartForInternalBufferInqInParam.durableIDs.length();
    for ( i = 0; i < nDCJDurableLen; i++ )
    {
        CORBA::Boolean bFound = FALSE;
        for ( j = 0; j < nInputDurableLen; j++ )
        {
            if ( 0 == CIMFWStrCmp( strDurableControlJob_startReserveInformation_Get_out.strStartDurables[i].durableID.identifier,
                                   strDurablesInfoForOpeStartForInternalBufferInqInParam.durableIDs[j].identifier ) )
            {
                bFound = TRUE;
                break;
            }
        }

        if ( bFound == FALSE )
        {
            PPT_METHODTRACE_V1( "", "all of durables in the durable control job is not input." );

            SET_MSG_RC( strDurablesInfoForOpeStartForInternalBufferInqResult,
                        CS_MSG_MISSING_DURABLE_OF_DRBCTRLJOB,
                        CS_RC_MISSING_DURABLE_OF_DRBCTRLJOB );
            return CS_RC_MISSING_DURABLE_OF_DRBCTRLJOB;
        }
    }

    /*---------------------------------------------------*/
    /* 7.Set following informations to Return Structure. */
    /*---------------------------------------------------*/
    strDurablesInfoForOpeStartForInternalBufferInqResult.equipmentID           = strDurableControlJob_startReserveInformation_Get_out.equipmentID;
    strDurablesInfoForOpeStartForInternalBufferInqResult.durableCategory       = CIMFWStrDup(strDurableControlJob_startReserveInformation_Get_out.durableCategory);
    strDurablesInfoForOpeStartForInternalBufferInqResult.strStartDurables      = strDurableControlJob_startReserveInformation_Get_out.strStartDurables;
    strDurablesInfoForOpeStartForInternalBufferInqResult.strDurableStartRecipe = strDurableControlJob_startReserveInformation_Get_out.strDurableStartRecipe;

    SET_MSG_RC( strDurablesInfoForOpeStartForInternalBufferInqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txDurablesInfoForOpeStartForInternalBufferInq");
    return RC_OK;
}
