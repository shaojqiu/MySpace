#ifndef lint
static char *sccsid =  "@(#) 1.9 superpos/src/spppt/source/posppt/pptmgr/txmethods/txReticleJustInOutRpt.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:32:38 [ 7/13/07 21:32:39 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_txReticleJustInOutRpt.cpp
//

#include "cs_pptmgr.hpp"
// Class: PPTSvcMgr
//
// Service: cs_txReticleJustInOutRpt()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001-02-15          M.Mori         Initial Release        (D3100008)
// 2004-10-22 D6000025 K.Murakami     eBroker Migration.
// 2017/09/19 INN-R170003  Joan Zhou      INN-R170003:Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//            pptReticleJustInOutRptResult&   strReticleJustInOutRptResult
//            const pptObjCommonIn&           strObjCommonIn
//            const pptUser&                  requestUserID
//            const char *                    moveDirection  //SP_MoveDirection_JustIn, or SP_MoveDirection_JustOut
//            const objectIdentifier&         reticlePodID
//            const pptMoveReticlesSequence&  strMoveReticles
//            const char *                    claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txReticleJustInOutRpt(
            pptReticleJustInOutRptResult&    strReticleJustInOutRptResult,
            const pptObjCommonIn&            strObjCommonIn,
            const pptUser&                   requestUserID,
            const char *                     moveDirection,
            const objectIdentifier&          reticlePodID,
            const pptMoveReticlesSequence&   strMoveReticles,
//D6000025             const char *                     claimMemo,
//D6000025             CORBA::Environment &             IT_env )
            const char *                     claimMemo //D6000025
            CORBAENV_LAST_CPP )                        //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txReticleJustInOutRpt");

    CORBA::Long rc = RC_OK;

    //---------------------------------------
    // Check input parameter
    //---------------------------------------
    objJustInOut_reticleTransferInfo_Verify_out strJustInOut_reticleTransferInfo_Verify_out;
    rc = justInOut_reticleTransferInfo_Verify( strJustInOut_reticleTransferInfo_Verify_out,
                                               strObjCommonIn,
                                               moveDirection,
                                               reticlePodID,
                                               strMoveReticles );

    if (rc)
    {
        PPT_METHODTRACE_V1( "PPTManager_i::txReticleJustInOutRpt", "justInOut_reticleTransferInfo_Verify() rc != RC_OK");
        strReticleJustInOutRptResult.strResult = strJustInOut_reticleTransferInfo_Verify_out.strResult;
        return( rc );
    }


    CORBA::Long nrLen = strMoveReticles.length();

    PPT_METHODTRACE_V2( "PPTManager_i::txReticleJustInOutRpt", "strMoveReticles.length = ", nrLen );
    for (CORBA::Long i=0; i<nrLen; i++)
    {
        if ( CIMFWStrCmp(moveDirection, SP_MoveDirection_JustIn) == 0 )
        {
            PPT_METHODTRACE_V1( "PPTManager_i::txReticleJustInOutRpt", "moveDirection == SP_MoveDirection_JustIn");

            objReticle_materialContainer_JustIn_out strReticle_materialContainer_JustIn_out;
            rc = reticle_materialContainer_JustIn( strReticle_materialContainer_JustIn_out,
                                                   strObjCommonIn,
                                                   reticlePodID,
                                                   strMoveReticles[i].reticleID,
                                                   strMoveReticles[i].slotNumber);
            if (rc)
            {
                PPT_METHODTRACE_V2( "PPTManager_i::txReticleJustInOutRpt", "reticle_materialContainer_JustIn() rc != RC_OK", i );
                strReticleJustInOutRptResult.strResult = strReticle_materialContainer_JustIn_out.strResult;
                return( rc );
            }
        }
        else if ( CIMFWStrCmp(moveDirection, SP_MoveDirection_JustOut) == 0 )
        {
            PPT_METHODTRACE_V1( "PPTManager_i::txReticleJustInOutRpt", "moveDirection == SP_MoveDirection_JustOut");

            objReticle_materialContainer_JustOut_out strReticle_materialContainer_JustOut_out;
            rc = reticle_materialContainer_JustOut( strReticle_materialContainer_JustOut_out,
                                                   strObjCommonIn,
                                                   reticlePodID,
                                                   strMoveReticles[i].reticleID,
                                                   strMoveReticles[i].slotNumber);
            if (rc)
            {
                PPT_METHODTRACE_V2( "PPTManager_i::txReticleJustInOutRpt", "reticle_materialContainer_JustOut() rc != RC_OK", i );
                strReticleJustInOutRptResult.strResult = strReticle_materialContainer_JustOut_out.strResult;
                return( rc );
            }
        }
    }
//INN-R170003 Add Start
    csObjReticlePod_Empty_Check_in       strObjReticlePod_Empty_Check_in;
    csObjReticlePod_Empty_Check_out      strObjReticlePod_Empty_Check_out;
    strObjReticlePod_Empty_Check_in.reticlePodID = reticlePodID;
    rc = cs_reticlePod_Empty_Check(strObjReticlePod_Empty_Check_out, strObjCommonIn, strObjReticlePod_Empty_Check_in);
    if (rc)
    {
        PPT_METHODTRACE_V2("", "cs_reticlePod_Empty_Check() rc != RC_OK", rc);
        strReticleJustInOutRptResult.strResult = strObjReticlePod_Empty_Check_out.strResult;
        return(rc);
    }
    /*----------------------------------*/
    /*  Get Current Durable Sub-Status  */
    /*----------------------------------*/
    objDurable_subState_Get_in        strDurable_subState_Get_in;
    objDurable_subState_Get_out       strDurable_subState_Get_out;
    strDurable_subState_Get_in.durableCategory = CIMFWStrDup (SP_DurableCat_ReticlePod);
    strDurable_subState_Get_in.durableID = reticlePodID;
    rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "durable_subState_Get() != RC_OK");
        strReticleJustInOutRptResult.strResult = strDurable_subState_Get_out.strResult;
        return  rc;
    }
    pptDurableStatusMultiChangeReqResult        strDurableStatusMultiChangeReqResult;
    pptDurableStatusMultiChangeReqInParm        strDurableStatusMultiChangeReqInParm;
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq.length(1);
    if (strObjReticlePod_Empty_Check_out.isEmpty == TRUE)
    {
        PPT_METHODTRACE_V1("", "ReticlePod is Empty--------------------------");
        if (CIMFWStrCmp(strDurable_subState_Get_out.durableSubStatus.identifier, CS_RETICLEPOD_DURABLE_SUB_STATE_WAITUSE) != 0)
        {
            PPT_METHODTRACE_V1("", "strDurable_subState_Get_out.durableSubStatus is not CS_RETICLEPOD_DURABLE_SUB_STATE_WAITUSE");

            strDurableStatusMultiChangeReqInParm.durableStatus               = CIMFWStrDup(CIMFW_Durable_Available);
            strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier = CIMFWStrDup(CS_RETICLEPOD_DURABLE_SUB_STATE_WAITUSE);
            strDurableStatusMultiChangeReqInParm.durableCategory             = CIMFWStrDup(SP_DurableCat_ReticlePod);

            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID                   = reticlePodID;
            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus               = CIMFWStrDup(strDurable_subState_Get_out.durableStatus);
            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier = CIMFWStrDup(strDurable_subState_Get_out.durableSubStatus.identifier);
    
            PPT_METHODTRACE_V2("", "strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID",strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID.identifier);
            PPT_METHODTRACE_V2("", "strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus",strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus);
            PPT_METHODTRACE_V2("", "strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier",strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier);

            rc = txDurableStatusMultiChangeReq(strDurableStatusMultiChangeReqResult, strObjCommonIn, strDurableStatusMultiChangeReqInParm, claimMemo);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "txDurableStatusMultiChangeReq() != RC_OK");
                strReticleJustInOutRptResult.strResult = strDurableStatusMultiChangeReqResult.strResult;
                return  rc;
            }
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "ReticlePod is not Empty--------------------------");
        if (CIMFWStrCmp(strDurable_subState_Get_out.durableSubStatus.identifier, CS_RETICLEPOD_DURABLE_SUB_STATE_INUSE) != 0)
        {
            PPT_METHODTRACE_V1("", "strDurable_subState_Get_out.durableSubStatus is not CS_RETICLEPOD_DURABLE_SUB_STATE_INUSE");

            strDurableStatusMultiChangeReqInParm.durableStatus               = CIMFWStrDup(CIMFW_Durable_InUse);
            strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier = CIMFWStrDup(CS_RETICLEPOD_DURABLE_SUB_STATE_INUSE);
            strDurableStatusMultiChangeReqInParm.durableCategory             = CIMFWStrDup(SP_DurableCat_ReticlePod);

            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID                   = reticlePodID;
            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus               = CIMFWStrDup(strDurable_subState_Get_out.durableStatus);
            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier = CIMFWStrDup(strDurable_subState_Get_out.durableSubStatus.identifier);

            PPT_METHODTRACE_V2("", "strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID",strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID.identifier);
            PPT_METHODTRACE_V2("", "strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus",strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus);
            PPT_METHODTRACE_V2("", "strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier",strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier);

            rc = txDurableStatusMultiChangeReq(strDurableStatusMultiChangeReqResult, strObjCommonIn, strDurableStatusMultiChangeReqInParm, claimMemo);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "txDurableStatusMultiChangeReq() != RC_OK");
                strReticleJustInOutRptResult.strResult = strDurableStatusMultiChangeReqResult.strResult;
                return  rc;
            }
        }
    }
//INN-R170003 Add End

    SET_MSG_RC(strReticleJustInOutRptResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("PPTManager_i::txReticleJustInOutRpt");
    return(RC_OK);
}
