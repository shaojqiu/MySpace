//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txReticleUsedDurationResetReq.cpp
//

#include "cs_pptmgr.hpp"

//
//
// Subsystem Name      : CS_PPT Service Manager
//
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/28 INN-R170003 Helios Zhen    INN-R170003:Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     csReticleUsedDurationResetReqResult& strReticleUsedDurationResetReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& reticleID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txReticleUsedDurationResetReq(
    csReticleUsedDurationResetReqResult&	strReticleUsedDurationResetReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&					reticleID,
    const char*                             claimMemo
	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txReticleUsedDurationResetReq")
    CORBA::Long rc = RC_OK ;


    //------------------------------
    // Object Lock for Reticle
    //------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, reticleID, SP_ClassName_PosReticle);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strReticleUsedDurationResetReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }

    /*------------------------------------------------*/
    /*   Reset reticle used duration information      */
    /*------------------------------------------------*/
	csObjReticle_UsedDuration_Reset_out strReticle_UsedDuration_Reset_out;
    rc = cs_reticle_UsedDuration_Reset(strReticle_UsedDuration_Reset_out,strObjCommonIn,reticleID,claimMemo);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_reticle_UsedDuration_Reset() rc != RC_OK", rc)
        strReticleUsedDurationResetReqResult.strResult = strReticle_UsedDuration_Reset_out.strResult ;
        return( rc );
    }

    /*------------------------------------------------*/
    /*   Set EquipmentIn Time if Xfer State is EI     */
    /*------------------------------------------------*/
	objReticle_detailInfo_GetDR_out__170 strReticle_detailInfo_GetDR_out;
	objReticle_detailInfo_GetDR_in__160  strReticle_detailInfo_GetDR_in;
	strReticle_detailInfo_GetDR_in.reticleID = reticleID ;
    rc = reticle_detailInfo_GetDR__170(strReticle_detailInfo_GetDR_out, strObjCommonIn, strReticle_detailInfo_GetDR_in);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "reticle_detailInfo_GetDR__170() rc != RC_OK", rc)
        strReticleUsedDurationResetReqResult.strResult = strReticle_detailInfo_GetDR_out.strResult ;
        return( rc );
    }

    if ( CIMFWStrCmp ( strReticle_detailInfo_GetDR_out.strReticleStatusInqResult.reticleStatusInfo.transferStatus, SP_TransState_EquipmentIn ) == 0 )
    {
        //---------------------------------------------
        // Get object
        //---------------------------------------------
        objObject_Get_out strObject_Get_out;
        objObject_Get_in  strObject_Get_in;
        strObject_Get_in.className                    = CIMFWStrDup(SP_ClassName_PosReticle);
        strObject_Get_in.strHashedInfoSeq.length(1);
        strObject_Get_in.strHashedInfoSeq[0].hashKey  = CIMFWStrDup(SP_HashData_DRBL_ID);
        strObject_Get_in.strHashedInfoSeq[0].hashData = reticleID.identifier;

        PPT_METHODTRACE_V1("", "call object_Get()");

        rc = object_Get( strObject_Get_out,
                         strObjCommonIn,
                         strObject_Get_in );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "object_Get() rc != RC_OK" );
            strReticleUsedDurationResetReqResult.strResult = strObject_Get_out.strResult;
            return rc;
        }
        PPT_METHODTRACE_V2("", "reticle stringifiedObjectReference", strObject_Get_out.stringifiedObjectReference);

        pptUserData strUserData;
        strUserData.name         = CIMFWStrDup ( CS_M_DRBL_EQUIPMENTIN_TIME );
        strUserData.type         = CIMFWStrDup ( CS_UDATA_TYPE_STRING );
        strUserData.value        = strObjCommonIn.strTimeStamp.reportTimeStamp ;
        strUserData.originator   = CIMFWStrDup ( SP_USERDATA_ORIG_MM );

        PPT_METHODTRACE_V2("", "reportTimeStamp", strObjCommonIn.strTimeStamp.reportTimeStamp);

        objObject_UserData_Set_out  strObject_UserData_Set_out;
        rc = object_userData_Set(strObject_UserData_Set_out, strObjCommonIn, strUserData, strObject_Get_out.stringifiedObjectReference);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_userData_Set() rc != RC_OK", rc)
            strReticleUsedDurationResetReqResult.strResult = strObject_UserData_Set_out.strResult ;
            return( rc );
        }
    }
    /*---------------------------------------------*/
    /*   Create Durable Change Event               */
    /*---------------------------------------------*/
    objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
    rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                 strObjCommonIn,
                                 "TXPDC007",
                                 reticleID,
                                 SP_DurableCat_Reticle,
                                 CS_DURABLE_EVENT_ACTION_USED_DURATION_RESET,
                                 claimMemo) ;

    if( rc )
    {
        PPT_METHODTRACE_V2("", "durableChangeEvent_Make() rc != RC_OK",rc)
        strReticleUsedDurationResetReqResult.strResult = strDurableChangeEvent_Make_out.strResult ;
        SET_MSG_RC( strReticleUsedDurationResetReqResult, MSG_FAIL_MAKE_HISTORY, rc );
        return rc ;
    }

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    strReticleUsedDurationResetReqResult.reticleID = reticleID ;

    SET_MSG_RC(strReticleUsedDurationResetReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txReticleUsedDurationResetReq")
    return( RC_OK );

}
