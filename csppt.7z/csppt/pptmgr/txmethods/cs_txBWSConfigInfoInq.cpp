// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
//
// SiView
// Name: cs_txBWSConfigInfoInq.cpp
//
// Modeficaiton History:
// Date       Defect        Name          Description
// ---------- ------------- ------------- ----------------------------------------------
// 2017/10/20 INN-R170017   ChengLi      BWS Config Info inquiry
//
// Class: PPTServiceManager
//
// Service: cs_txBWSConfigInfoInq()
//
// Description:
//<Method Summary>
//
//</Method Summary>
//
// Return:
//     long
//
// Parameter:
//
//     csBWSConfigInfoInqResult&              strBWSConfigInfoInqResult,
//     const pptObjCommonIn&                  strObjCommonIn,
//     const csBWSConfigInfoInqInParm&        strBWSConfigInfoInqInParm
//
#include "cs_pptmgr.hpp"
CORBA::Long CS_PPTManager_i::cs_txBWSConfigInfoInq(
        csBWSConfigInfoInqResult&              strBWSConfigInfoInqResult,
        const pptObjCommonIn&                  strObjCommonIn,
        const csBWSConfigInfoInqInParm&        strBWSConfigInfoInqInParm
        CORBAENV_LAST_CPP)
{


    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txBWSConfigInfoInq")
    CORBA::Long rc = RC_OK ;

    //------------------------------------
    // get BWS config info
    //------------------------------------
    csObjBWS_Config_GetDR_out strBWS_Config_GetDR_out;
    csObjBWS_Config_GetDR_in strBWS_Config_GetDR_in;
    strBWS_Config_GetDR_in.BWSID = strBWSConfigInfoInqInParm.BWSID;
    strBWS_Config_GetDR_in.zoneID = strBWSConfigInfoInqInParm.zoneID;

    rc = cs_BWS_Config_GetDR(strBWS_Config_GetDR_out,
                             strObjCommonIn,
                             strBWS_Config_GetDR_in);

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "","cs_BWS_Config_GetDR != RC_OK", rc );
        strBWSConfigInfoInqResult.strResult = strBWS_Config_GetDR_out.strResult;
        return rc;
    }

    CORBA::Long bwsConfigLen = strBWS_Config_GetDR_out.strBWSConfigInfoSeq.length();
    PPT_METHODTRACE_V2( "","strBWS_Config_GetDR_out.strBWSConfigInfoSeq length is ", bwsConfigLen );
    if(bwsConfigLen == 0)
    {
        PPT_METHODTRACE_V1("", "NOT FOUND BWS CONFIG");
    }
    else
    {

       CORBA::Long bwsWaferCount;
       CORBA::Long bwsMaxCapacity;
       CORBA::Long availableBWSCapacity;
       csObjBWS_WaferCount_GetDR_in strBWS_WaferCount_GetDR_in;

       for(CORBA::Long i = 0; i < bwsConfigLen; i++)
        {
           //-------------------------------------
           // get BWS wafer count
           // ------------------------------------
           strBWS_WaferCount_GetDR_in.BWSID = strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].BWSID;
           strBWS_WaferCount_GetDR_in.zoneID = strBWSConfigInfoInqInParm.zoneID;
           PPT_METHODTRACE_V2("", "start call cs_BWS_WaferCount_GetDR , times ", i + 1 );
           csObjBWS_WaferCount_GetDR_out strBWS_WaferCount_GetDR_out;
           rc = cs_BWS_WaferCount_GetDR(strBWS_WaferCount_GetDR_out,
                                        strObjCommonIn,
                                        strBWS_WaferCount_GetDR_in);

           if (rc != RC_OK) 
            {
                PPT_METHODTRACE_V2("", "cs_BWS_WaferCount_GetDR != RC_OK", rc);
                strBWSConfigInfoInqResult.strResult = strBWS_WaferCount_GetDR_out.strResult;
                return rc;
            }

           //----------------------------------------
           // get wafer count and bws capacity
           //----------------------------------------
           bwsWaferCount = strBWS_WaferCount_GetDR_out.strBWSWaferCount.waferCount;
           bwsMaxCapacity = strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].maxCapacity;
           PPT_METHODTRACE_V4("", "Compare BWS Config BWS MaxCapacity and BWS Wafer Count ", 
                              strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].BWSID.identifier,
                              bwsMaxCapacity, 
                              bwsWaferCount);
           //-------------------------------------------
           // Compare BWS MaxCapacity and Wafer Count
           //-------------------------------------------
           if (bwsMaxCapacity < bwsWaferCount)
            {
                PPT_METHODTRACE_V2("", "BWS Max Capacity is not big than Wafer Count", rc);
                CS_SET_MSG_RC(strBWSConfigInfoInqResult,
                          CS_MSG_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                          CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
                return (CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
            }
           else
            {
               //-----------------------------------------------------
               // SET BWS Available Capacity
               //-----------------------------------------------------
               availableBWSCapacity = bwsMaxCapacity - bwsWaferCount;
               strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].availableCapacity = availableBWSCapacity;

               CORBA::Long zoneMaxCapacity;
               CORBA::Long zoneWaferCount;
               CORBA::Long availableZoneCapacity;
               CORBA::Long zoneConfigLen = strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq.length();
               CORBA::Long zoneWaferLen = strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq.length();

               for( CORBA::Long j = 0; j < zoneConfigLen; j++ )
                {
                   //------------------------------------------------
                   // Get BWS Zone MaxCapacity
                   //-------------------------------------------------
                   CORBA::Boolean hasZoneWaferCount = FALSE;
                   zoneMaxCapacity = strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].maxCapacity;

                   for(CORBA::Long k = 0; k < zoneWaferLen; k++ )
                    {

                       //------------------------------------------------
                       // Get BWS Zone Wafer Count
                       //-------------------------------------------------
                       if(0 == CIMFWStrCmp(strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].zoneID,
                                           strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq[k].zoneID))
                        {
                            hasZoneWaferCount = TRUE;
                            zoneWaferCount = strBWS_WaferCount_GetDR_out.strBWSWaferCount.strZoneWaferCountSeq[k].waferCount;
                           
                            PPT_METHODTRACE_V5("", "Compare BWS Config Zone MaxCapacity to its BWS Wafer Zone Count ", 
                                               strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].BWSID.identifier,
                                               strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].zoneID,
                                               zoneMaxCapacity, 
                                               zoneWaferCount);
                           //------------------------------------------------
                           // Compare BWS Zone Wafer Count and MaxCapacity
                           //-------------------------------------------------
                           if(zoneMaxCapacity < zoneWaferCount)
                            {
                                PPT_METHODTRACE_V2("", "BWS Zone Max Capacity is not big than Wafer Count", rc);
                                CS_SET_MSG_RC(strBWSConfigInfoInqResult,
                                           CS_MSG_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY,
                                           CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY);
                                return (CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY);
                            }
                           else
                            {
                               //-----------------------------------------------------
                               // SET BWS Zone Available Capacity
                               //-----------------------------------------------------
                               availableZoneCapacity = zoneMaxCapacity - zoneWaferCount;
                               strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].availableCapacity = availableZoneCapacity;
                            }
                           break;
                        }
                    }
                   if(TRUE != hasZoneWaferCount)
                   {
                       // SET BWS Zone Available Capacity
                       strBWS_Config_GetDR_out.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].availableCapacity = zoneMaxCapacity;
                   }
                }
            }

        }

        strBWSConfigInfoInqResult.strBWSConfigInfoSeq = strBWS_Config_GetDR_out.strBWSConfigInfoSeq;
        SET_MSG_RC(strBWSConfigInfoInqResult, MSG_OK, RC_OK);
    }
    return rc;
}