//
// (c) Copyright: IBM Taiwan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txVendorLotReserveCancelReq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/07/25 INN-R170084  Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txVendorLotReserveCancelReq (
    csVendorLotReserveCancelReqResult&                strVendorLotReserveCancelReqResult,
    const pptObjCommonIn&                             strObjCommonIn,
    const objectIdentifier&                           cassetteID
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txVendorLotReserveCancelReq");

    CORBA::Long rc = RC_OK;
    
    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    // check input carrier
    if( CIMFWStrLen(cassetteID.identifier) == 0 )
    {
        PPT_SET_MSG_RC_KEY( strVendorLotReserveCancelReqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "cassetteID" );
        return RC_BLANK_INPUT_PARAMETER;
    }

    // Call cs_vendorLotReserve_DelDR
    csObjVendorLotReserve_DelDR_out strVendorLotReserve_DelDR_out ;
    rc = cs_vendorLotReserve_DelDR( strVendorLotReserve_DelDR_out,
                                    strObjCommonIn,
                                    cassetteID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_vendorLotReserve_DelDR() rc != RC_OK", rc);
        strVendorLotReserveCancelReqResult.strResult = strVendorLotReserve_DelDR_out.strResult ;
        return(rc);
    }
    
    /*-----------------------------------------------------------------------*/
    /*   Return to Caller                                                    */
    /*-----------------------------------------------------------------------*/
    strVendorLotReserveCancelReqResult.strResult = strVendorLotReserve_DelDR_out.strResult;
    
    SET_MSG_RC( strVendorLotReserveCancelReqResult, MSG_OK, RC_OK ) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txVendorLotReserveCancelReq");
    return RC_OK;
}
