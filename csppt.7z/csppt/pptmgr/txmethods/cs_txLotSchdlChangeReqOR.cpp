 #ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/txLotSchdlChangeReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 14:16:45 [ 8/3/07 14:16:46 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: txLotSchdlChangeReq.cpp
//

//INN-R170003 Modify start
//#include "pptmgr.hpp"
#include "cs_pptmgr.hpp"
//INN-R170003 Modify end

#include "pcas.hh"     //P3100315
#include "pctrlj.hh"   //P3100315

#include "plot.hh"     //D4100120
#include "ppcflw.hh"   //D4100120
#include "ppcflwx.hh"  //D4100120
#include "ppcopsp.hh"  //D4100120

// Class: PPTManager
//
// Service: txLotSchdlChangeReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/18          S.Kawabe       Initial Release (R30)
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize
// 2000/12/07 P3000366 S.Tokumasu     Bug Fix
// 2001/02/05 D3000118 K.Muguruma     For Lot Customize
// 2001/02/05 D3000119 K.Muguruma     For Flexible Rework
// 2001/03/15 D3000119 M.Shimizu      Remove D3000118&D3000119
// 2001/05/08 P3100315 K.Matsuei      Add Check Logic for LotSchdlChangeReq,
//                                    LotMfgOrderChangeReq, txCassetteUsageCountResetReq
// 2001/07/12 D4000016 M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001/08/13 P4000090 K.Kido         Set return structure in sequence
// 2001/09/19 D4000177 M.Ameshita     Add to make reticle set chnage event.
// 2002/01/21 D4100020 N.Maeda        Change oldCurrentPOS to oldCurrentPOData
// 2002/02/28 D4100120 N.Minami       Future Action
// 2002/06/04 D4100292 K.Kimura       Change Logic of Lot Schedule Change after checking Control Job ID.
// 2002/07/24 D4200066 H.Adachi       Add txHoldLotReq, txFutureHoldCancelReq calling.
// 2002/07/30 D4200029 K.Kimura       Process Hold Control
// 2002/10/04 D4200124 Y.Iwasaki      Add object_Lock(PosLot) logic.
// 2002/10/08 D4200039 H.Adachi       Replace Direct FW Calling.
// 2002/10/23 P4200271 K.Kido         Add : Check lot's inventry state.
// 2002/11/19 D4200210 K.Kido         Add : Check lot's backup state.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2003/12/09 P5100062 H.Adachi       Restoe lot_CassetteCategory_UpdateForContaminationControl calling.
// 2004/10/22 D6000025 K.Murakami     eBroker Migration.
// 2005/03/09 P6000264 H.Hasegawa     Added condition to judge need of Future Hold.
// 2005/11/18 D7000021 M.Murata       Add : Check lot's hold state. (LOCK)
// 2006/05/10 P7000218 K.Kido         Add check for specified product validity.
// 2006/07/14 P7000304 M.Kase         Change the value of input parameter : priorityClass for lotChangeEvent_Make method.
// 2006/10/20 D8000028 K.Kido         Change cassette_representLot_Get ==> cassette_lotList_GetWithPriorityOrder
// 2006/10/26 D7000354 H.Hasegawa     Add the logic which resets Q-Time actions
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/05/28 P9000007 S.Yamamoto     Fix : Lot Schedule Change aren't allowed under NonProBank state
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/30 DSIV00000214 K.Kido         Multi Fab Transfer Support
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2010/11/02 PSIV00002561 M.Ogawa        Change target operation of schedule change reservation
// 2010/11/04 PSIV00002567 M.Ogawa        Modify logic getting control job
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2017/09/27 INN-R170003  SF.Peng        Add new transfer state PI/PO to control FOUP location
//
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptLotSchdlChangeReqResult& strLotSchdlChangeReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const pptRescheduledLotAttributesSequence& strRescheduledLotAttributes
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//INN-R170003 Modify start
//CORBA::Long PPTManager_i::txLotSchdlChangeReq (pptLotSchdlChangeReqResult& strLotSchdlChangeReqResult,
CORBA::Long CS_PPTManager_i::txLotSchdlChangeReq (pptLotSchdlChangeReqResult& strLotSchdlChangeReqResult,
//INN-R170003 Modify end
                                               const pptObjCommonIn& strObjCommonIn,
                                               const pptRescheduledLotAttributesSequence& strRescheduledLotAttributes,
//D6000025                                                const char * claimMemo,
//D6000025                                                CORBA::Environment &IT_env)
                                               const char * claimMemo //D6000025
                                               CORBAENV_LAST_CPP)     //D6000025
{
//INN-R170003 Modify start
//    PPT_METHODTRACE_ENTRY("PPTManager_i:: txLotSchdlChangeReq ") ;
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txLotSchdlChangeReq ") ;
//INN-R170003 Modify end
    CORBA::Long rc = RC_OK;

    CORBA::Long nLen = strRescheduledLotAttributes.length();
    PPT_METHODTRACE_V2("", "strRescheduledLotAttributes.length()",nLen) ;

//P3100315 start
    PPT_METHODTRACE_V1("", "P3100315 start ##################################################");
    char * methodName = NULL;
    objectIdentifier lotID;
    objectIdentifier cassetteID;

//D4100120 Add Start
    CORBA::Boolean errorFlag = False;

    //Get Current_Date
    CORBA::Long strLen = CIMFWStrLen(strObjCommonIn.strTimeStamp.reportTimeStamp);
//D9000001    char* aCurrentTimeStamp = CORBA::string_alloc(strLen + 1);
    char* aCurrentTimeStamp = CORBA::string_alloc(CORBA::ULong(strLen + 1));    //D9000001
    CIMFWStrCpy( aCurrentTimeStamp , strObjCommonIn.strTimeStamp.reportTimeStamp );
    CORBA::String_var currentTimeStamp_var = aCurrentTimeStamp;

    char currentDate[11];
    memset(currentDate,'\0', sizeof(currentDate));
    CIMFWStrnCpy( currentDate , aCurrentTimeStamp , 10 );
    PPT_METHODTRACE_V2("", "currentDate", currentDate);

    //Get Current_Time
    aCurrentTimeStamp += 11 ; //Move forward by 11 characters.

    char currentTime[9];
    memset(currentTime,'\0', sizeof(currentTime));
    CIMFWStrnCpy( currentTime , aCurrentTimeStamp , 8 );
    PPT_METHODTRACE_V2("", "currentTime", currentTime);
//D4100120 Add End
//DSIV00000201 Add Start
    objectIdentifierSequence userGroupIDs;
    userGroupIDs.length(0);
    CORBA::ULong userGroupIDsLen = userGroupIDs.length();

//DSIV00000201 Add End

    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );  //DSN000071674

    for (CORBA::Long j=0; j < nLen; j++)
    {
        PPT_METHODTRACE_V2("", "-----------------------------round", j);

        //D4200124 add start
        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          strRescheduledLotAttributes[j].lotID, SP_ClassName_PosLot );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock(lotID) rc != RC_OK");
            strLotSchdlChangeReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "Lot object Locked ! ", strRescheduledLotAttributes[j].lotID.identifier);
        //D4200124 add end

//D7000021 add start
        //------------------------------------
        // Check LOCK Hold.
        //------------------------------------
        PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
        objectIdentifierSequence lotIDSeq;
        lotIDSeq.length(1);
        lotIDSeq[0] = strRescheduledLotAttributes[j].lotID;
        objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
        rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", lotIDSeq[0].identifier );
            strLotSchdlChangeReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
            return ( rc );
        }
//D7000021 add end

//D9000056 add start
        PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
        objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = strRescheduledLotAttributes[j].lotID;

        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strLotSchdlChangeReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            return( rc );
        }

        //----------------------------------------------
        //  If Lot is in post process, returns error
        //----------------------------------------------
        if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
        {
            PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
            if (userGroupIDsLen == 0)
            {
                /*---------------------------*/
                /* Get UserGroupID By UserID */
                /*---------------------------*/
                objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
                rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                                 strObjCommonIn,
                                                 strObjCommonIn.strUser.userID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                    strLotSchdlChangeReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
                    return( rc );
                }
                userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
                userGroupIDsLen = userGroupIDs.length();
                PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
            }
            CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
            PPT_METHODTRACE_V2("", "extPostProc", extPostProc);

            CORBA::ULong nCnt = 0;
            for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                {
                    PPT_METHODTRACE_V1("", "# External Post Process User!");
                    break;
                }

            }
            if (nCnt == userGroupIDsLen)
            {
                PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                PPT_SET_MSG_RC_KEY( strLotSchdlChangeReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    strRescheduledLotAttributes[j].lotID.identifier );
                return( RC_LOT_INPOSTPROCESS );
            }   //DSIV00000201

        }
//D9000056 add end

//DSIV00000214 add start
        if( 0 == CIMFWStrCmp(strRescheduledLotAttributes[j].originalRouteID, strRescheduledLotAttributes[j].routeID.identifier ) )
        {
            //---------------------------------------
            //   Check interFabXferPlan existence
            //---------------------------------------
            PPT_METHODTRACE_V2("", "call process_CheckInterFabXferPlanSkip()", strRescheduledLotAttributes[j].lotID.identifier);

            objProcess_CheckInterFabXferPlanSkip_in strProcess_CheckInterFabXferPlanSkip_in;
            strProcess_CheckInterFabXferPlanSkip_in.lotID = strRescheduledLotAttributes[j].lotID;
            strProcess_CheckInterFabXferPlanSkip_in.currentRouteID.identifier = strRescheduledLotAttributes[j].originalRouteID;
            strProcess_CheckInterFabXferPlanSkip_in.currentOpeNo = strRescheduledLotAttributes[j].originalOperationNumber;
            strProcess_CheckInterFabXferPlanSkip_in.jumpingRouteID = strRescheduledLotAttributes[j].routeID;
            strProcess_CheckInterFabXferPlanSkip_in.jumpingOpeNo = strRescheduledLotAttributes[j].currentOperationNumber;

            PPT_METHODTRACE_V2("", "  currentRouteID", strProcess_CheckInterFabXferPlanSkip_in.currentRouteID.identifier);
            PPT_METHODTRACE_V2("", "  currentOpeNo  ", strProcess_CheckInterFabXferPlanSkip_in.currentOpeNo);
            PPT_METHODTRACE_V2("", "  jumpingRouteID", strProcess_CheckInterFabXferPlanSkip_in.jumpingRouteID.identifier);
            PPT_METHODTRACE_V2("", "  jumpingOpeNo  ", strProcess_CheckInterFabXferPlanSkip_in.jumpingOpeNo);

            objProcess_CheckInterFabXferPlanSkip_out strProcess_CheckInterFabXferPlanSkip_out;
            rc = process_CheckInterFabXferPlanSkip( strProcess_CheckInterFabXferPlanSkip_out,
                                                    strObjCommonIn,
                                                    strProcess_CheckInterFabXferPlanSkip_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### process_CheckInterFabXferPlanSkip () rc != RC_OK", rc)
                strLotSchdlChangeReqResult.strResult = strProcess_CheckInterFabXferPlanSkip_out.strResult;
                return( rc );
            }
        }
//DSIV00000214 add end

        lotID = strRescheduledLotAttributes[j].lotID;
        objLot_cassette_Get_out strLot_cassette_Get_out;

        PPT_METHODTRACE_V2("", "lotID ",lotID.identifier)

        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, lotID);
        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "lot_cassette_Get() == RC_OK") ;
            cassetteID = strLot_cassette_Get_out.cassetteID ;

//PSIV00002567//D4200039 Add Start
//PSIV00002567            objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
//PSIV00002567
//PSIV00002567            rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, cassetteID);
//PSIV00002567
//PSIV00002567            if ( rc != RC_OK )
//PSIV00002567            {
//PSIV00002567                PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() rc != RC_OK")
//PSIV00002567                strLotSchdlChangeReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSIV00002567                return( rc );
//PSIV00002567            }
//PSIV00002567            else
//PSIV00002567            {
//PSIV00002567                //------------------------------
//PSIV00002567                // Cassette Control Job ID Check
//PSIV00002567                //------------------------------
//PSIV00002567                if (CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) == 0 )
//PSIV00002567                {
//PSIV00002567                    PPT_METHODTRACE_V1( "", "strCassette_controlJobID_Get_out.controlJobID.identifier == 0" );
//PSIV00002567                }
//PSIV00002567                else
//PSIV00002567                {
//PSIV00002567                    PPT_METHODTRACE_V1( "", "strCassette_controlJobID_Get_out.controlJobID.identifier != 0" );
//PSIV00002567//D4200039 Add End
//PSIV00002567 Add Start
            PPT_METHODTRACE_V1("", "call lot_bondingGroupID_GetDR")
            objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
            rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, lotID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_controlJobID_Get() rc != RC_OK")
                strLotSchdlChangeReqResult.strResult = strLot_controlJobID_Get_out.strResult;
                return( rc );
            }
            else
            {
                //------------------------------
                // Lot Control Job ID Check
                //------------------------------
                if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0 )
                {
                    PPT_METHODTRACE_V1( "", "strLot_controlJobID_Get_out.controlJobID.identifier == 0" );
                }
                else
                {
                    PPT_METHODTRACE_V1( "", "strLot_controlJobID_Get_out.controlJobID.identifier != 0" );
//PSIV00002567 Add End

//D4200039            PosCassette_var aPosCassette;
//D4200039            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, cassetteID,
//D4200039                                                   strLotSchdlChangeReqResult, txLotSchdlChangeReq );
//D4200039
//D4200039            if ( ! CORBA::is_nil( aPosCassette ) )
//D4200039            {
//D4200039                PPT_METHODTRACE_V1("", "aPosCassette is not nil");
//D4100120 Add Start
//D4200039                /*------------------------*/
//D4200039                /*   check controlJobID   */
//D4200039                /*------------------------*/
//D4200039                PPT_METHODTRACE_V1("", "-----------check controlJobID-----------");
//D4200039                PosControlJob_var aPosControlJob;
//D4200039                try
//D4200039                {
//D4200039                    aPosControlJob = aPosCassette->getControlJob();
//D4200039                }
//D4200039                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//D4200039
//D4200039                if ( ! CORBA::is_nil(aPosControlJob) )
//D4200039                {
//D4200039                    PPT_METHODTRACE_V1("", "##### aPosControlJob is not nil");

                    //D4100292 Add Start
                    if ( 0 == CIMFWStrCmp(getenv(SP_LOT_SCHDCHANGE_RESERVE), "1") )
                    {
                        PPT_METHODTRACE_V1("", "##### Lot Schedule Change Reservation Flag is ON.");
                    //D4100292 Add End
                        /*----------------------------*/
                        /*   Future Action Data Set   */
                        /*----------------------------*/
                        //Get Next OpeNo.
//D4200039                        PosLot_var aLot;
//D4200039                        PPT_CONVERT_LOTID_TO_LOT_OR ( aLot,
//D4200039                                                      lotID,
//D4200039                                                      strLotSchdlChangeReqResult,
//D4200039                                                      txLotSchdlChangeReq )
//D4200039
//D4200039                        PosProcessFlowContext_var aProcessFlowContext;
//D4200039                        try
//D4200039                        {
//D4200039                            aProcessFlowContext = aLot->getProcessFlowContext();
//D4200039                        }
//D4200039                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);
//D4200039
//D4200039                        if ( CORBA::is_nil(aProcessFlowContext) )
//D4200039                        {
//D4200039                            PPT_METHODTRACE_V1("", "aProcessFlowContext is nil");
//D4200039                            SET_MSG_RC( strLotSchdlChangeReqResult,
//D4200039                                        MSG_CAST_CTRLJOBID_FILLED,
//D4200039                                        RC_CAST_CTRLJOBID_FILLED );
//D4200039                            return RC_CAST_CTRLJOBID_FILLED;
//D4200039                        }
//D4200039
//D4200039                        PosProcessOperationSpecification_var aModulePOS ;
//D4200039                        PosProcessFlow_var outModulePF, outMainPF ;
//D4200039                        CORBA::String_var outModuleNo ;
//D4200039                        try
//D4200039                        {
//D4200039                            aModulePOS = aProcessFlowContext->getNextProcessOperationSpecificationOnCurrentRoute( outMainPF, outModuleNo, outModulePF ) ;
//D4200039                        }
//D4200039                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getNextProcessOperationSpecificationOnCurrentRoute)
//D4200039
//D4200039                        if( CORBA::is_nil( aModulePOS ) )
//D4200039                        {
//D4200039                            PPT_METHODTRACE_V1("", "aModulePOS is nil");
//D4200039                            SET_MSG_RC( strLotSchdlChangeReqResult,
//D4200039                                        MSG_CAST_CTRLJOBID_FILLED,
//D4200039                                        RC_CAST_CTRLJOBID_FILLED );
//D4200039
//D4200039                            return RC_CAST_CTRLJOBID_FILLED;
//D4200039                        }
//D4200039
//D4200039                        if(CORBA::is_nil(outMainPF))
//D4200039                        {
//D4200039                            PPT_METHODTRACE_V1("", "outMainPF is nil");
//D4200039                            PPT_SET_MSG_RC_KEY(strLotSchdlChangeReqResult,
//D4200039                                               MSG_NOT_FOUND_PF,
//D4200039                                               RC_NOT_FOUND_PF,
//D4200039                                               "");
//D4200039                            return RC_NOT_FOUND_PF;
//D4200039                        }
//D4200039
//D4200039                        ProcessDefinition_var outMainPD;
//D4200039                        try
//D4200039                        {
//D4200039                            outMainPD = outMainPF->getRootProcessDefinition();
//D4200039                        }
//D4200039                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlow::getRootProcessDefinition)
//D4200039
//D4200039                        if(CORBA::is_nil(outMainPD))
//D4200039                        {
//D4200039                            PPT_METHODTRACE_V1("", "outMainPD is nil");
//D4200039                            PPT_SET_MSG_RC_KEY(strLotSchdlChangeReqResult,
//D4200039                                               MSG_NOT_FOUND_POS_FOR_LOT,
//D4200039                                               RC_NOT_FOUND_POS,
//D4200039                                               "");
//D4200039                            return RC_NOT_FOUND_POS;
//D4200039                        }
//D4200039
//D4200039                        CORBA::String_var targetRouteID;
//D4200039                        try
//D4200039                        {
//D4200039                            targetRouteID = outMainPD->getIdentifier() ;
//D4200039                        }
//D4200039                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getIdentifier)
//D4200039
//D4200039                        PPT_METHODTRACE_V2("", "targetRouteID", targetRouteID);
//D4200039
//D4200039                        CORBA::String_var aModuleOpeNo ;
//D4200039                        try
//D4200039                        {
//D4200039                            aModuleOpeNo = aModulePOS->getOperationNumber() ;
//D4200039                        }
//D4200039                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getOperationNumber)
//D4200039
//D4200039                        CORBA::String_var targetOperationNumber;
//D4200039                        PPT_CONVERT_MODULEOPENO_TO_OPENO( targetOperationNumber, outModuleNo, aModuleOpeNo ) ;

                        //D4200039 Add Start
//DSIV00002561                        objLot_nextOperation_Get_out strLot_nextOperation_Get_out;
//DSIV00002561
//DSIV00002561                        rc = lot_nextOperation_Get( strLot_nextOperation_Get_out, strObjCommonIn, lotID );
//DSIV00002561
//DSIV00002561                        if ( rc != RC_OK )
//DSIV00002561                        {
//DSIV00002561                            PPT_METHODTRACE_V1( "", "lot_nextOperation_Get() rc != RC_OK" );
//DSIV00002561                            strLotSchdlChangeReqResult.strResult = strLot_nextOperation_Get_out.strResult;
//DSIV00002561
//DSIV00002561                            return ( rc );
//DSIV00002561                        }
//DSIV00002561 add start
                        PPT_METHODTRACE_V1("", "call lot_currentOperationInfo_Get");
                        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                           strObjCommonIn,
                                                           lotID );
                        if (rc != RC_OK)
                        {
                            PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc) ;
                            strLotSchdlChangeReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult ;
                            return (rc) ;
                        }
//DSIV00002561 add end

                        CORBA::String_var targetRouteID;
                        CORBA::String_var targetOperationNumber;

//DSIV00002561                        targetRouteID         = strLot_nextOperation_Get_out.routeID;
//DSIV00002561                        targetOperationNumber = strLot_nextOperation_Get_out.operationNumber;
                        targetRouteID         = strLot_currentOperationInfo_Get_out.routeID.identifier;         //DSIV00002561
                        targetOperationNumber = strLot_currentOperationInfo_Get_out.operationNumber;            //DSIV00002561

                        PPT_METHODTRACE_V2("", "targetRouteID", targetRouteID);
                        //D4200039 Add End

                        PPT_METHODTRACE_V2("", "targetOperationNumber", targetOperationNumber);

                        pptSchdlChangeReservation strSchdlChangeReservation;
                        strSchdlChangeReservation.objectID                                 = lotID;
                        strSchdlChangeReservation.objectType                               = CIMFWStrDup(SP_SCHDL_CHG_OBJTYPE_LOT);
                        strSchdlChangeReservation.targetRouteID.identifier                 = targetRouteID;
                        strSchdlChangeReservation.targetRouteID.stringifiedObjectReference = CIMFWStrDup("");
                        strSchdlChangeReservation.targetOperationNumber                    = targetOperationNumber;
                        strSchdlChangeReservation.productID                                = strRescheduledLotAttributes[j].productID;
                        strSchdlChangeReservation.routeID                                  = strRescheduledLotAttributes[j].routeID;
                        strSchdlChangeReservation.operationNumber                          = strRescheduledLotAttributes[j].currentOperationNumber;
                        strSchdlChangeReservation.startDate                                = CIMFWStrDup(currentDate);
                        strSchdlChangeReservation.startTime                                = CIMFWStrDup(currentTime);
                        strSchdlChangeReservation.endDate                                  = CIMFWStrDup("9999-12-31");
                        strSchdlChangeReservation.endTime                                  = CIMFWStrDup("23.59.59");
                        strSchdlChangeReservation.eraseAfterUsedFlag                       = True;
                        strSchdlChangeReservation.maxLotCnt                                = 1;

                        /*-----------------------------*/
                        /*   Future Action Procedure   */
                        /*-----------------------------*/
                        PPT_METHODTRACE_V1("", "Future Action Procedure");

                        objSchdlChangeReservation_Create_out strSchdlChangeReservation_Create_out;
                        rc = schdlChangeReservation_CreateDR(strSchdlChangeReservation_Create_out,
                                                             strObjCommonIn,
                                                             strSchdlChangeReservation);

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("PPTManager_i:: txSchdlChangeReservationCreateReq", "schdlChangeReservation_CreateDR() != RC_OK") ;
                            strLotSchdlChangeReqResult.strResult = strSchdlChangeReservation_Create_out.strResult;
                            return (rc);
                        }

                        PPT_SET_MSG_RC_KEY(strLotSchdlChangeReqResult,
                                           MSG_SOMELOT_SCHEDULE_CHANGE_ERROR,
                                           RC_OK,
                                           lotID.identifier);

                        errorFlag = True;
                        continue;
                    //D4100292 Add Start
                    }
                    else if ( 0 == CIMFWStrCmp(getenv(SP_LOT_SCHDCHANGE_RESERVE), "0") )
                    {
                        PPT_METHODTRACE_V1("", "##### Lot Schedule Change Reservation Flag is OFF.");
//PSIV00002567                        SET_MSG_RC( strLotSchdlChangeReqResult,
//PSIV00002567                                    MSG_CAST_CTRLJOBID_FILLED,
//PSIV00002567                                    RC_CAST_CTRLJOBID_FILLED );
//PSIV00002567 add start
                        PPT_SET_MSG_RC_KEY2( strLotSchdlChangeReqResult,
                                             MSG_LOT_CTLJOBID_FILLED,
                                             RC_LOT_CTLJOBID_FILLED,
                                             lotID.identifier,
                                             strLot_controlJobID_Get_out.controlJobID.identifier );
//PSIV00002567 add end

                        return RC_CAST_CTRLJOBID_FILLED;
                    }
                    //D4100292 Add End
                }
//D4200039                else
//D4200039                {
//D4200039                    PPT_METHODTRACE_V1("", "aPosControlJob is nil");
//D4200039                }

//DSN000071674 add start
                if ( 1 == lotOperationEIcheck )
                {
//DSN000071674 add end
                    /*----------------------*/
                    /*   check XferStetus   */
                    /*----------------------*/
                    PPT_METHODTRACE_V1("", "-----------check XferStetus-----------");
                    CORBA::String_var strCassetteXferState;

                    //D4200039 Add Start
                    objCassette_transferState_Get_out strCassette_transferState_Get_out;
                    rc = cassette_transferState_Get(strCassette_transferState_Get_out, strObjCommonIn, cassetteID);
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "cassette_transferState_Get() rc != RC_OK")
                        strLotSchdlChangeReqResult.strResult = strCassette_transferState_Get_out.strResult;
                        return(rc);
                    }
                    strCassetteXferState = strCassette_transferState_Get_out.transferState;
                    //D4200039 Add End

//D4200039                try
//D4200039                {
//D4200039                    strCassetteXferState = aPosCassette->getTransportState();
//D4200039                }
//D4200039                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

                    PPT_METHODTRACE_V2("", "strCassetteXferState--->", strCassetteXferState);
//INN-R170003 Modify start
//                    if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
                if( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) ||
                    0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut) ||
                    0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) )
//INN-R170003 Modify end
                    {
                        PPT_METHODTRACE_V1("", "##### strCassetteXferState == SP_TransState_EquipmentIn");
                        PPT_SET_MSG_RC_KEY2( strLotSchdlChangeReqResult,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             strCassetteXferState,
                                             cassetteID.identifier );

                        return RC_INVALID_CAST_XFERSTAT;
                    }
                }//DSN000071674
//D4100120 Add End

//D4100120 Del Start
//                /*----------------------*/
//                /*   check XferStetus   */
//                /*----------------------*/
//                PPT_METHODTRACE_V1("", "-----------check XferStetus-----------");
//                CORBA::String_var strCassetteXferState;
//                try
//                {
//                    strCassetteXferState = aPosCassette->getTransportState();
//                }
//                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//
//                PPT_METHODTRACE_V2("", "strCassetteXferState--->", strCassetteXferState);
//                if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
//                {
//                    PPT_METHODTRACE_V1("", "##### strCassetteXferState == SP_TransState_EquipmentIn");
//                    PPT_SET_MSG_RC_KEY2( strLotSchdlChangeReqResult,
//                                         MSG_INVALID_CAST_XFERSTAT,
//                                         RC_INVALID_CAST_XFERSTAT,
//                                         strCassetteXferState,
//                                         cassetteID.identifier );
//
//                    strLotSchdlChangeReqResult.strChangeLotSchdlReturn[j].returnCode = ConvertLongtoString(RC_INVALID_CAST_XFERSTAT) ;        //P4000090
//                    return RC_INVALID_CAST_XFERSTAT;
//                }
//
//                /*------------------------*/
//                /*   check controlJobID   */
//                /*------------------------*/
//                PPT_METHODTRACE_V1("", "-----------check controlJobID-----------");
//                PosControlJob_var aPosControlJob;
//                try
//                {
//                    aPosControlJob = aPosCassette->getControlJob();
//                }
//                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//
//                if ( ! CORBA::is_nil(aPosControlJob) )
//                {
//                    PPT_METHODTRACE_V1("", "##### aPosControlJob is not nil");
//
//                    SET_MSG_RC( strLotSchdlChangeReqResult,
//                                MSG_CAST_CTRLJOBID_FILLED,
//                                RC_CAST_CTRLJOBID_FILLED );
//
//                    strLotSchdlChangeReqResult.strChangeLotSchdlReturn[j].returnCode = ConvertLongtoString(RC_CAST_CTRLJOBID_FILLED) ;        //P4000090
//                    return RC_CAST_CTRLJOBID_FILLED;
//                }
//                else
//                {
//                    PPT_METHODTRACE_V1("", "aPosControlJob is nil");
//                }
//D4100120 Del End
            }
//D4200039            else
//D4200039            {
//D4200039                PPT_METHODTRACE_V1("", "aPosCassette is nil") ;
//D4200039            }

        }    //End of lot_cassette_Get () rc == RC_OK
    }    //End of strRescheduledLotAttributes Loop

    PPT_METHODTRACE_V1("", "P3100315 end ####################################################");
//P3100315 end

//D4100120 Add Start
    if(errorFlag == True)
    {
        PPT_METHODTRACE_V1("", "Error SchduleChange");
        PPT_METHODTRACE_EXIT("PPTManager_i:: txLotSchdlChangeReq ") ;
        return( RC_SOMELOTID_DATA_ERROR );
    }
//D4100120 Add End

    for (CORBA::Long seqIx=0; seqIx<nLen; seqIx++)
    {

//(D3000118,D3000119) add start
//        /*-------------------------------------------------------------------------*/
//        /* This function is not applicable to Lot-Customized Lot                   */
//        /*-------------------------------------------------------------------------*/
//        objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//        rc = lot_CheckForLCFR(strLot_CheckForLCFR_out, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID, SP_LotCustomize_LC_DBRECORD);
//        if (rc == RC_OK)
//        {
//            PPT_METHODTRACE_V2("PPTManager_i:: txReworkPartialWaferLotReq", "lot_CheckForLCFR() rc == RC_OK",
//                               strRescheduledLotAttributes[seqIx].lotID.identifier);
//            // set returned strResult to strResult of out parameter
//            SET_MSG_RC(strLot_CheckForLCFR_out, MSG_INVALID_OPE_TO_LCLOT, RC_INVALID_OPE_TO_LCLOT);
//            strLotSchdlChangeReqResult.strResult = strLot_CheckForLCFR_out.strResult;
//            return (RC_INVALID_OPE_TO_LCLOT);
//        }
//(D3000118,D3000119) add end


//D4100120        strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].lotID = strRescheduledLotAttributes[seqIx].lotID;
        /*------------------------------------------------------------------------*/
        /*   Check Lot Process State                                              */
        /*------------------------------------------------------------------------*/
        objLot_processState_Get_out       strLot_processState_Get_out;
        rc = lot_processState_Get(strLot_processState_Get_out,strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_processState_Get() != RC_OK", seqIx) ;
            strLotSchdlChangeReqResult.strResult =  strLot_processState_Get_out.strResult ;
//D4100120            strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }
        else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0 )
        {
            PPT_METHODTRACE_V2("", "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0", seqIx) ;
            PPT_SET_MSG_RC_KEY2( strLotSchdlChangeReqResult,
                                 MSG_INVALID_LOT_PROCSTAT,
                                 RC_INVALID_LOT_PROCSTAT,
                                 strRescheduledLotAttributes[seqIx].lotID.identifier,
                                 strLot_processState_Get_out.theLotProcessState ) ;
//D4100120            strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_LOT_PROCSTAT) ;
            return(RC_INVALID_LOT_PROCSTAT);
        }

//DSIV00001830 add start
        /*------------------------------------------------------------------------*/
        /*   Check Lot Finished State                                             */
        /*------------------------------------------------------------------------*/
        objLot_finishedState_Get_out strLot_finishedState_Get_out;
        rc = lot_finishedState_Get(strLot_finishedState_Get_out, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_finishedState_Get() != RC_OK", seqIx);
            strLotSchdlChangeReqResult.strResult = strLot_finishedState_Get_out.strResult;
            return rc;
        }
        else if( CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0 )
        {
            PPT_METHODTRACE_V2("", "CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0", seqIx);
            PPT_SET_MSG_RC_KEY( strLotSchdlChangeReqResult,
                                MSG_INVALID_LOT_FINISHSTAT,
                                RC_INVALID_LOT_FINISHSTAT,
                                strLot_finishedState_Get_out.lotFinishedState );
        
            return RC_INVALID_LOT_FINISHSTAT;
        }

        /*------------------------------------------------------------------------*/
        /*   Check Bonding Group                                                  */
        /*------------------------------------------------------------------------*/
        objLot_bondingGroupID_GetDR_in strLot_bondingGroupID_GetDR_in;
        strLot_bondingGroupID_GetDR_in.lotID = strRescheduledLotAttributes[seqIx].lotID;

        objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
        rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
            strLotSchdlChangeReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
            return rc;
        }
        if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
            PPT_SET_MSG_RC_KEY2( strLotSchdlChangeReqResult,
                                 MSG_LOT_HAS_BONDINGGROUP,
                                 RC_LOT_HAS_BONDINGGROUP,
                                 strLot_bondingGroupID_GetDR_in.lotID.identifier,
                                 strLot_bondingGroupID_GetDR_out.bondingGroupID );
            return RC_LOT_HAS_BONDINGGROUP;
        }
//DSIV00001830 add end

//P4200271 add end
        /*------------------------------------------------------------------------*/
        /*   Check Lot Inventory State                                            */
        /*------------------------------------------------------------------------*/
        if( (CIMFWStrLen(strRescheduledLotAttributes[seqIx].routeID.identifier)     > 0)  &&
            (CIMFWStrLen(strRescheduledLotAttributes[seqIx].currentOperationNumber) > 0) )
        {
            objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
            rc = lot_inventoryState_Get( strLot_inventoryState_Get_out,strObjCommonIn,strRescheduledLotAttributes[seqIx].lotID );
            if (rc != RC_OK)
            {
                strLotSchdlChangeReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
                return( rc );
            }
//P9000007            else if (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0)
            else if ( (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0) &&   //P9000007
                      (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_NonProBank) != 0) ) //P9000007
            {
                PPT_SET_MSG_RC_KEY2( strLotSchdlChangeReqResult,
                                     MSG_INVALID_LOT_INVENTORYSTAT,
                                     RC_INVALID_LOT_INVENTORYSTAT,
                                     strRescheduledLotAttributes[seqIx].lotID.identifier,
                                     strLot_inventoryState_Get_out.lotInventoryState );
                return(RC_INVALID_LOT_INVENTORYSTAT);
            }
        }
//P4200271 add end

//D4200210 add start
        /*------------------------------------------------------------------------*/
        /*   Check Lot's backup State                                             */
        /*------------------------------------------------------------------------*/
        objLot_backupInfo_Get_out strLot_backupInfo_Get_out;
        rc = lot_backupInfo_Get( strLot_backupInfo_Get_out, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID );

        if( rc != RC_OK )
        {
            strLotSchdlChangeReqResult.strResult = strLot_backupInfo_Get_out.strResult ;
            return( rc );
        }
        else if(strLot_backupInfo_Get_out.strLotBackupInfo.backupProcessingFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", " ##### lot's backupProcessingFlag == TRUE ");
            if( 0 != CIMFWStrLen(strRescheduledLotAttributes[seqIx].productID.identifier))
            {
                PPT_SET_MSG_RC_KEY( strLotSchdlChangeReqResult,
                                    MSG_LOT_BACKUP_ON_BACKUPSITE,
                                    RC_LOT_BACKUP_ON_BACKUPSITE,
                                    strRescheduledLotAttributes[seqIx].lotID.identifier );
                return( RC_LOT_BACKUP_ON_BACKUPSITE );
            }

            objLot_currentRouteID_Get_out strLot_currentRouteID_Get_out;
            rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out,strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID );

            if( rc != RC_OK )
            {
                strLotSchdlChangeReqResult.strResult = strLot_currentRouteID_Get_out.strResult ;
                return( rc );
            }
            else if( 0 != CIMFWStrCmp(strLot_currentRouteID_Get_out.currentRouteID.identifier, strRescheduledLotAttributes[seqIx].routeID.identifier))
            {
                PPT_SET_MSG_RC_KEY( strLotSchdlChangeReqResult,
                                    MSG_LOT_BACKUP_ON_BACKUPSITE,
                                    RC_LOT_BACKUP_ON_BACKUPSITE,
                                    strRescheduledLotAttributes[seqIx].lotID.identifier );
                return( RC_LOT_BACKUP_ON_BACKUPSITE );
            }
        }
//D4200210 add end
//P7000218 add start
        /*------------------------------------------------------------------------*/
        /*   Check specified Product validity                                     */
        /*------------------------------------------------------------------------*/
        if( 0 != CIMFWStrLen(strRescheduledLotAttributes[seqIx].productID.identifier))
        {
            PPT_METHODTRACE_V2( "", "strRescheduledLotAttributes[seqIx].productID.identifier = ", strRescheduledLotAttributes[seqIx].productID.identifier );
            objLot_productID_Get_out strLot_productID_Get_out;
            rc = lot_productID_Get( strLot_productID_Get_out,
                                    strObjCommonIn,
                                    strRescheduledLotAttributes[seqIx].lotID );
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2( "","lot_productID_Get != RC_OK", rc );
                strLotSchdlChangeReqResult.strResult = strLot_productID_Get_out.strResult;
                return(rc);
            }

            /*-----------------------------------------------------------------------------------*/
            /*   If lots product and specified product are different, then check product status  */
            /*-----------------------------------------------------------------------------------*/
            if( 0 != CIMFWStrCmp(strLot_productID_Get_out.productID.identifier, strRescheduledLotAttributes[seqIx].productID.identifier))
            {
                PPT_METHODTRACE_V2( "", "strLot_productID_Get_out.productID.identifier = ", strLot_productID_Get_out.productID.identifier );
                /*------------------------------------------------------------------------------------------------------*/
                /*   In this method, the existence of specified Product and validity of Production State are checked.   */
                /*   Following statuses are rejected.                                                                   */
                /*    - SP_ProductSpecification_State_Obsolete                                                          */
                /*    - SP_ProductSpecification_State_Draft                                                             */
                /*------------------------------------------------------------------------------------------------------*/
                objProduct_existence_Check_out strProduct_existence_Check_out;
                rc = product_existence_Check( strProduct_existence_Check_out,
                                              strObjCommonIn,
                                              strRescheduledLotAttributes[seqIx].productID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "","product_existence_Check != RC_OK", rc );
                    strLotSchdlChangeReqResult.strResult = strProduct_existence_Check_out.strResult;
                    return( rc );
                }
            }
        }
//P7000218 add end

        /*------------------------------------------------------------------------*/
        /*   Register Product Request                                             */
        /*------------------------------------------------------------------------*/
        objLot_ChangeSchedule_out  strLot_ChangeSchedule_out;
        strLot_ChangeSchedule_out.opehsMoveFlag = FALSE; //P3000280
        rc = lot_ChangeSchedule(strLot_ChangeSchedule_out,strObjCommonIn,strRescheduledLotAttributes[seqIx]);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_ChangeSchedule() != RC_OK", seqIx);
            strLotSchdlChangeReqResult.strResult =  strLot_ChangeSchedule_out.strResult ;
//D4100120            strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }

        /*------------------------------------------------------------------------*/
        /*   Delete all qtime restrictions for previous route                     */
        /*------------------------------------------------------------------------*/
        if( strLot_ChangeSchedule_out.opehsMoveFlag == TRUE )
        {
            PPT_METHODTRACE_V2("", "strLot_ChangeSchedule_out.opehsMoveFlag == TRUE", seqIx);
            objQtime_AllClearByRouteChange_out strQtime_AllClearByRouteChange_out ;
            rc = qtime_AllClearByRouteChange( strQtime_AllClearByRouteChange_out , strObjCommonIn , strRescheduledLotAttributes[seqIx].lotID);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "qtime_AllClearByRouteChange() != RC_OK", seqIx);
                strLotSchdlChangeReqResult.strResult =  strQtime_AllClearByRouteChange_out.strResult ;
//D4100120                strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString( rc );
                return(rc);
            }

            //D7000354 Add Start
            //--------------------------------------------------
            // Reset Q-Time actions
            //--------------------------------------------------
            objectIdentifier  resetReasonCodeID;
            resetReasonCodeID.identifier = CIMFWStrDup( SP_Reason_QTimeClear );

            //----- Lot Hold Actions -------//
            if( strQtime_AllClearByRouteChange_out.strLotHoldReleaseList.length() > 0 )
            {
                PPT_METHODTRACE_V1("", "The lot hold actions to reset was found.");

                pptHoldLotReleaseReqResult  strHoldLotReleaseReqResult;
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID,
                                          resetReasonCodeID, strQtime_AllClearByRouteChange_out.strLotHoldReleaseList );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK");
                    strLotSchdlChangeReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return rc;
                }
            }

            //----- Future Hold Actions -------//
            if( strQtime_AllClearByRouteChange_out.strFutureHoldCancelList.length() > 0 )
            {
                PPT_METHODTRACE_V1("", "The future hold actions to cancel was found.");

                pptFutureHoldCancelReqResult  strFutureHoldCancelReqResult;
                rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID, resetReasonCodeID,
                                            SP_EntryType_Cancel, strQtime_AllClearByRouteChange_out.strFutureHoldCancelList );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK");
                    strLotSchdlChangeReqResult.strResult = strFutureHoldCancelReqResult.strResult;
                    return rc;
                }
            }

            //----- Future Rework Actions -------//
            CORBA::Long  cancelLen = strQtime_AllClearByRouteChange_out.strFutureReworkCancelList.length();
            if( cancelLen > 0 )
            {
                PPT_METHODTRACE_V2("", "The future rework actions to cancel was found.", cancelLen);

                for( CORBA::Long  cancelCnt = 0; cancelCnt < cancelLen; cancelCnt++ )
                {
                    pptFutureReworkInfo  strFutureRework = strQtime_AllClearByRouteChange_out.strFutureReworkCancelList[cancelCnt];

                    pptFutureReworkCancelReqResult  strFutureReworkCancelReqResult;
                    rc = txFutureReworkCancelReq( strFutureReworkCancelReqResult, strObjCommonIn, strFutureRework.lotID, strFutureRework.routeID,
                                                  strFutureRework.operationNumber, strFutureRework.strFutureReworkDetailInfoSeq, "" );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureReworkCancelReq() != RC_OK");
                        strLotSchdlChangeReqResult.strResult = strFutureReworkCancelReqResult.strResult;
                        return rc;
                    }
                }
            }
            //D7000354 Add End
        }

        //D4200066 Add Start
        //----------------------------------------------------
        // Future Hold
        //----------------------------------------------------
//P6000264        if( strLot_ChangeSchedule_out.opehsMoveFlag == TRUE )
        if( strLot_ChangeSchedule_out.opehsMoveFlag == TRUE                                                                                                 &&     //P6000264
            ( CIMFWStrCmp( strRescheduledLotAttributes[seqIx].routeID.identifier,     strRescheduledLotAttributes[seqIx].originalRouteID         ) != 0 ||         //P6000264
              CIMFWStrCmp( strRescheduledLotAttributes[seqIx].currentOperationNumber, strRescheduledLotAttributes[seqIx].originalOperationNumber ) != 0   )   )    //P6000264
        {
            pptEffectCondition strEffectCondition;

            strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
            strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

            objLot_futureHoldRequests_EffectByCondition_out strLot_futureHoldRequests_EffectByCondition_out;
            rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_out,
                                                           strObjCommonIn,
                                                           lotID,
                                                           strEffectCondition);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
                strLotSchdlChangeReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_out.strResult ;
                return( rc );
            }

            if( strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0 )
            {
                pptHoldLotReqResult strHoldLotReqResult ;
                rc = txHoldLotReq(strHoldLotReqResult, strObjCommonIn, lotID, strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList) ;

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strLotSchdlChangeReqResult.strResult = strHoldLotReqResult.strResult ;
                    return rc ;
                }
            }

            objectIdentifier releaseReasonCodeID ;
            releaseReasonCodeID.identifier = CIMFWStrDup( "" ) ;

            strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
            strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_SINGLE );

            objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;
            rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                                   strObjCommonIn,
                                                                   lotID,
                                                                   strEffectCondition );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
                strLotSchdlChangeReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
                return( rc );
            }

            if ( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )
            {
                pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
                rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult,
                                            strObjCommonIn,
                                            lotID,
                                            releaseReasonCodeID,
                                            SP_EntryType_Remove,
                                            strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK") ;
                    strLotSchdlChangeReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
                    return( rc );
                }
            }
        }
        //D4200066 Add End

//P5100062#if 0
        //D4000016 Add Start
        //--------------------------------------------------------------------------------------------------
        // UpDate RequiredCassetteCategory
        //--------------------------------------------------------------------------------------------------
        objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
        rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                   strObjCommonIn,
                                                   lotID );

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
            strLotSchdlChangeReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
            return rc;
        }
        //D4000016 Add end
//P5100062#endif

//D4200029 Add Start
    //-----------------------//
    //     Process Hold      //
    //-----------------------//
    if( strLot_ChangeSchedule_out.opehsMoveFlag == TRUE )
    {
        CORBA::Long nLen=0;
        nLen = strRescheduledLotAttributes.length();

        for( CORBA::Long i=0; i<nLen ;i++)
        {
            if( (CIMFWStrLen( strRescheduledLotAttributes[i].routeID.identifier     )>0 ) &&
                (CIMFWStrLen( strRescheduledLotAttributes[i].currentOperationNumber )>0 ))
            {
                PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
                pptProcessHoldExecReqResult strProcessHoldExecReqResult;

                rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                                           strObjCommonIn,
                                           strRescheduledLotAttributes[i].lotID,
                                           claimMemo );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
                    strLotSchdlChangeReqResult.strResult = strProcessHoldExecReqResult.strResult ;
                    return( rc );
                }
            }
        }
    }
//D4200029 Add End

        /*------------------------------------------------------------------------*/
        /*   Make History                                                         */
        /*------------------------------------------------------------------------*/
        if(strLot_ChangeSchedule_out.opehsAddFlag == TRUE)
        {
            PPT_METHODTRACE_V2("", "strLot_ChangeSchedule_out.opehsAddFlag == TRUE", seqIx);
            objLotOperationMoveEvent_MakeChangeRoute_out  strLotOperationMoveEvent_MakeChangeRoute_out;
            rc = lotOperationMoveEvent_MakeChangeRoute(strLotOperationMoveEvent_MakeChangeRoute_out,
                                                       strObjCommonIn,
                                                       "TXOMC004",
                                                       strRescheduledLotAttributes[seqIx].lotID,
//                                                     strLot_ChangeSchedule_out.oldCurrentPOS,                     //D4100020 Delete
                                                       strLot_ChangeSchedule_out.oldCurrentPOData,                  //D4100020 Add
                                                       claimMemo);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "lotOperationMoveEvent_MakeChangeRoute() != RC_OK", seqIx) ;
//P5000145                PPT_SET_MSG_RC_KEY(strLotSchdlChangeReqResult,MSG_FAIL_MAKE_HISTORY ,rc,strRescheduledLotAttributes[seqIx].lotID.identifier) ;
                SET_MSG_RC( strLotSchdlChangeReqResult, MSG_FAIL_MAKE_HISTORY ,rc );        //P5000145
//D4100120                strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
                return(rc);
            }
        }

        objLotChangeEvent_Make_out strLotChangeEvent_Make_out;
        rc = lotChangeEvent_Make(strLotChangeEvent_Make_out, strObjCommonIn,
                                 "TXOMC004",
                                 strRescheduledLotAttributes[seqIx].lotID.identifier,
                                 "0",
                                 "",
                                 "",
                                 "",
                                 "",
//P7000304                                 "0",
                                 strRescheduledLotAttributes[seqIx].priorityClass,    //P7000304
                                 strRescheduledLotAttributes[seqIx].productID.identifier,
                                 strLot_ChangeSchedule_out.previousProductID.identifier,
                                 strRescheduledLotAttributes[seqIx].plannedStartTime,
                                 strRescheduledLotAttributes[seqIx].plannedFinishTime,
                                 claimMemo) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "lotChangeEvent_Make() != RC_OK", seqIx) ;
//P5000145            PPT_SET_MSG_RC_KEY(strLotSchdlChangeReqResult, MSG_FAIL_MAKE_HISTORY ,rc ,strRescheduledLotAttributes[seqIx].lotID.identifier) ;
            SET_MSG_RC( strLotSchdlChangeReqResult, MSG_FAIL_MAKE_HISTORY ,rc );        //P5000145
//D4100120            strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].lotID = strRescheduledLotAttributes[seqIx].lotID ;
//D4100120            strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
        }

        objLotReticleSetChangeEvent_Make_out strLotReticleSetChangeEvent_Make_out;                               //D4000177
        rc = lotReticleSetChangeEvent_Make( strLotReticleSetChangeEvent_Make_out,                                //D4000177
                                            strObjCommonIn,                                                      //D4000177
                                            "TXOMC004",                                                          //D4000177
                                            strRescheduledLotAttributes[seqIx].lotID,                            //D4000177
                                            claimMemo);                                                          //D4000177
        if (rc != RC_OK)                                                                                         //D4000177
        {                                                                                                        //D4000177
            PPT_METHODTRACE_V2("", "lotReticleSetChangeEvent_Make() != RC_OK", seqIx) ;                          //D4000177
//P5000145            PPT_SET_MSG_RC_KEY( strLotSchdlChangeReqResult, MSG_FAIL_MAKE_HISTORY, rc , strRescheduledLotAttributes[seqIx].lotID.identifier ) ;  //D4000177
            SET_MSG_RC( strLotSchdlChangeReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
//D4100120            strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].lotID = strRescheduledLotAttributes[seqIx].lotID;                          //D4000177
//D4100120            strLotSchdlChangeReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);      //D4000177
            return(rc);                                                                                          //D4000177
        }                                                                                                        //D4000177
    }

    /*------------------------------------------*/
    /*   AMHS I/F for Priority Change Request   */
    /*------------------------------------------*/
    PPT_METHODTRACE_V1("", "Start AMHS I/F")

    CORBA::Long cLen=0;

    pptPriorityChangeReq priorityChangeReq;

    objectIdentifier aLotID ;
    objectIdentifier aCassetteID ;

    for (CORBA::Long i=0; i<nLen; i++)
    {
    /* Start P3000366 */
        PPT_METHODTRACE_V2("", "Lot Loop Count ",i)
        /*------------------------------------------------------------------------*/
        /*   Get cassette / lot connection                                        */
        /*------------------------------------------------------------------------*/
        aLotID = strRescheduledLotAttributes[i].lotID;
        objLot_cassette_Get_out strLot_cassette_Get_out ;

        PPT_METHODTRACE_V2("", "aLotID ",aLotID.identifier)

        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "lot_cassette_Get() == RC_OK") ;
            aCassetteID = strLot_cassette_Get_out.cassetteID ;

            PPT_METHODTRACE_V2("", "aCassetteID ",aCassetteID.identifier)
            /*----------------------------------------------*/
            /*   Check the representative lotID             */
            /*----------------------------------------------*/
            PPT_METHODTRACE_V1("PPTManager_i:: txEqpPortStatusChangeRpt", "Check the representative lotID");

//D8000028  objCassette_representLot_Get_out strCassette_representLot_Get_out;
//D8000028
//D8000028  rc = cassette_representLot_Get( strCassette_representLot_Get_out, strObjCommonIn, aCassetteID );
//D8000028  if (rc == RC_OK)
//D8000028  {
//D8000028      PPT_METHODTRACE_V2("", "cassette_representLot_Get().lotID ",strCassette_representLot_Get_out.lotID.identifier)
//D8000028      if(0 == CIMFWStrCmp(aLotID.identifier,strCassette_representLot_Get_out.lotID.identifier))
//D8000028      {
//D8000028          PPT_METHODTRACE_V1("", "cassette_representLot_Get() == RC_OK")
//D8000028          priorityChangeReq.priorityInfoData.length(cLen+1);
//D8000028          priorityChangeReq.priorityInfoData[cLen].priority = strRescheduledLotAttributes[i].priorityClass;
//D8000028          priorityChangeReq.priorityInfoData[cLen].carrierID= aCassetteID;
//D8000028          PPT_METHODTRACE_V2("", "priorityInfoData.length",cLen+1)
//D8000028          PPT_METHODTRACE_V2("", "priorityInfoData[cLen].priority",priorityChangeReq.priorityInfoData[cLen].priority)
//D8000028          PPT_METHODTRACE_V2("", "priorityInfoData[cLen].carrierID",priorityChangeReq.priorityInfoData[cLen].carrierID.identifier)
//D8000028          cLen++;
//D8000028      }
//D8000028  }
//D8000028  else
//D8000028  {
//D8000028      PPT_METHODTRACE_V1("", "cassette_representLot_Get() != RC_OK")
//D8000028  }
//D8000028 add start
            objCassette_lotList_GetWithPriorityOrder_out strCassette_lotList_GetWithPriorityOrder_out;
            rc = cassette_lotList_GetWithPriorityOrder( strCassette_lotList_GetWithPriorityOrder_out, strObjCommonIn, aCassetteID );

            if (rc == RC_OK && 0 < strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq.length() )
            {
                PPT_METHODTRACE_V2("", "cassette_lotList_GetWithPriorityOrder.lotID ",strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID.identifier)
                if(0 == CIMFWStrCmp( aLotID.identifier,strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID.identifier ))
                {
                    priorityChangeReq.priorityInfoData.length(cLen+1);
                    priorityChangeReq.priorityInfoData[cLen].priority = strRescheduledLotAttributes[i].priorityClass ;
                    priorityChangeReq.priorityInfoData[cLen].carrierID = aCassetteID ;
                    PPT_METHODTRACE_V2("", "### priorityInfoData.length = ",cLen+1);
                    PPT_METHODTRACE_V2("", "### priorityInfoData[cLen].priority  = ",priorityChangeReq.priorityInfoData[cLen].priority);
                    PPT_METHODTRACE_V2("", "### priorityInfoData[cLen].carrierID = ",priorityChangeReq.priorityInfoData[cLen].carrierID.identifier);
                    cLen++;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "cassette_lotList_GetWithPriorityOrder() != RC_OK")
            }
//D8000028 add end
        }
        else
        {
            PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK")
        }
    }

    CORBA::Long xLen = priorityChangeReq.priorityInfoData.length();
    PPT_METHODTRACE_V2("", "xLen",xLen)

    if (0 < xLen)
    {
        PPT_METHODTRACE_V1("", "Call XMSMgr_SendPriorityChangeReq")

        objXMSMgr_SendPriorityChangeReq_out strXMSMgr_SendPriorityChangeReq_out;
        rc = XMSMgr_SendPriorityChangeReq(strXMSMgr_SendPriorityChangeReq_out,
                                          strObjCommonIn,
                                          strObjCommonIn.strUser,
                                          priorityChangeReq);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "XMSMgr_SendPriorityChangeReq() != RC_OK") ;
//            strLotSchdlChangeReqResult.strResult =  strXMSMgr_SendPriorityChangeReq_out.strResult ;
//            return(rc);
        }
    }
    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
//D4100120 Del Start
//    for (i=0; i<nLen; i++)
//    {
//        strLotSchdlChangeReqResult.strChangeLotSchdlReturn[i].returnCode = ConvertLongtoString( RC_OK );
//        strLotSchdlChangeReqResult.strChangeLotSchdlReturn[i].lotID = strRescheduledLotAttributes[i].lotID ;
//    }
//D4100120 Del End

    SET_MSG_RC(strLotSchdlChangeReqResult, MSG_OK, RC_OK) ;
//INN-R170003 Modify start
//    PPT_METHODTRACE_EXIT("PPTManager_i:: txLotSchdlChangeReq ") ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txLotSchdlChangeReq ") ;
//INN-R170003 Modify end
    return RC_OK ;
}
