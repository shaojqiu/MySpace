//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: cs_txSortJobCancelReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txSortJobCancelReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2007/06/14 D9000005   M.Murata       Initial ( R9.0 )
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/12/03 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
// 2013/06/19 PSN000078594 W.Zhang        add retry for TCSMgr_SendSortJobCancelNotificationReq
// 
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017/11/08 INN-R170016   JJ.Zhang       Equipment monitor enhancement
// 2017/11/11 INN-R170017   Evie Su        BWS Management
//
// Description:
//  This fuction deletes Sort Job or Sort Component Job.
//  When Sort Job is deleted, the deleted information is sent to TCS.
//
// Return:
//   long
//
// Parameter:
//        pptSortJobCancelReqResult&          strSortJobCancelReqResult
//        const pptObjCommonIn&               strObjCommonIn
//        const objectIdentifier&             sorterJobID
//        const objectIdentifierSequence&     sorterComponentJobIDseq
//        CORBA::Boolean                      notifyToTCSFlag,
//        const char *                        claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//INN-R170016 CORBA::Long PPTManager_i::txSortJobCancelReq(
CORBA::Long CS_PPTManager_i::txSortJobCancelReq( //INN-R170016
        pptSortJobCancelReqResult&          strSortJobCancelReqResult,
        const pptObjCommonIn&               strObjCommonIn,
        const objectIdentifier&             sorterJobID,
        const objectIdentifierSequence&     sorterComponentJobIDseq,
        CORBA::Boolean                      notifyToTCSFlag,
        const char *                        claimMemo
        CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txSortJobCancelReq");
    CORBA::Long  rc = RC_OK;

    PPT_METHODTRACE_V2("", "in para userID            ", strObjCommonIn.strUser.userID.identifier);
    PPT_METHODTRACE_V2("", "in para sorterJobID       ", sorterJobID.identifier                  );

    //------------------------------------------------------------------
    //  Sorter Job Exist Check
    //------------------------------------------------------------------
    PPT_METHODTRACE_V1("", "### Check Process for Sorter Job Cancel.");
    PPT_METHODTRACE_V2("", "sorterJobID.length()            ", CIMFWStrLen(sorterJobID.identifier));
    PPT_METHODTRACE_V2("", "sorterComponentJobIDseq.length()", sorterComponentJobIDseq.length()   );

    if( 0 >= CIMFWStrLen(sorterJobID.identifier))
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(sorterJobID.identifier) <= 0 && sorterComponentJobIDseq.length() <= 0");
        PPT_SET_MSG_RC_KEY( strSortJobCancelReqResult, MSG_NOT_FOUND_SORTERJOB, RC_NOT_FOUND_SORTERJOB, "(it's blank.)" );
        return ( RC_NOT_FOUND_SORTERJOB );
    }

//DSN000049350 Add Start
    CORBA::Long sorterJobLockFlag = atoi( getenv(SP_SORTERJOB_LOCK_FLAG) );
    PPT_METHODTRACE_V2("","sorterJobLockFlag", sorterJobLockFlag);

    if ( 1 == sorterJobLockFlag )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

        //---------------------------------
        // Lock Sort Jobs
        //---------------------------------
        objectIdentifier dummyID;
        objSorter_sorterJob_LockDR_out strSorter_sorterJob_LockDR_out;
        objSorter_sorterJob_LockDR_in strSorter_sorterJob_LockDR_in;
        strSorter_sorterJob_LockDR_in.sorterJobID          = sorterJobID;
        strSorter_sorterJob_LockDR_in.sorterComponentJobID = dummyID;
        strSorter_sorterJob_LockDR_in.cassetteID           = dummyID;
        strSorter_sorterJob_LockDR_in.lockType             = SP_ObjectLock_LockType_WRITE;

        PPT_METHODTRACE_V1( "", "calling sorter_sorterJob_LockDR()" );
        rc = sorter_sorterJob_LockDR ( strSorter_sorterJob_LockDR_out,
                                       strObjCommonIn,
                                       strSorter_sorterJob_LockDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "sorter_sorterJob_LockDR() != RC_OK", rc);
            strSortJobCancelReqResult.strResult = strSorter_sorterJob_LockDR_out.strResult;
            return( rc );
        }
    }
//DSN000049350 Add End

    //-----------------------------------------
    // Get Sorter Job Information
    //-----------------------------------------
    PPT_METHODTRACE_V2("", "Get Sorter Job Information. ", sorterJobID.identifier );
    objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;
    objSorter_jobList_GetDR_in  strSorter_jobList_GetDR_in;
    strSorter_jobList_GetDR_in.sorterJobID = sorterJobID;

    rc = sorter_jobList_GetDR(strSorter_jobList_GetDR_out, strObjCommonIn, strSorter_jobList_GetDR_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "sorter_jobList_GetDR() rc != RC_OK", rc);
        strSortJobCancelReqResult.strResult = strSorter_jobList_GetDR_out.strResult;
        return rc;
    }
    if( 0 >= strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length() )
    {
        PPT_METHODTRACE_V1("", "strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length() <= 0");
        PPT_SET_MSG_RC_KEY( strSortJobCancelReqResult, MSG_NOT_FOUND_SORTERJOB, RC_NOT_FOUND_SORTERJOB, sorterJobID.identifier );
        return ( RC_NOT_FOUND_SORTERJOB );
    }

    //Copy
    pptSortJobListAttributes strSortJobListAttributes;
    strSortJobListAttributes = strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0];

    //------------------------------------------------------------------
    //                                                                  
    //  Object Lock Process                                             
    //                                                                  
    //------------------------------------------------------------------
    //---------------------
    // Equipment 
    //---------------------
//DSN000049350 Add Start
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = SP_EQP_LOCK_MODE_WRITE;
    if ( 1 == sorterJobLockFlag )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

        // Get required equipment lock mode
        strObject_lockMode_Get_in.objectID           = strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0].equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( SP_FunctionCategory_SorterTxID ); // SorterTxID
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0].equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strSortJobCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }
        lockMode = strObject_lockMode_Get_out.lockMode;
    }
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );

    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = strSortJobListAttributes.equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strSortJobCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }

        if ( 0 != CIMFWStrCmp( SP_SorterJobStatus_Wait_To_Executing, strSortJobListAttributes.sorterJobStatus ) )
        {
            PPT_METHODTRACE_V1("", "strSortJobListAttributes.sorterJobStatus != SP_SorterJobStatus_Wait_To_Executing");

            objectIdentifier dummyID;
            objEquipment_portGroupInfo_Get_out strEquipment_portGroupInfo_Get_out;
            objEquipment_portGroupInfo_Get_in strEquipment_portGroupInfo_Get_in;
            strEquipment_portGroupInfo_Get_in.equipmentID = strSortJobListAttributes.equipmentID;
            strEquipment_portGroupInfo_Get_in.portGroupID = strSortJobListAttributes.portGroupID.identifier;
            strEquipment_portGroupInfo_Get_in.portID = dummyID;

            PPT_METHODTRACE_V1( "", "calling equipment_portGroupInfo_Get()" );
            rc = equipment_portGroupInfo_Get( strEquipment_portGroupInfo_Get_out,
                                              strObjCommonIn,
                                              strEquipment_portGroupInfo_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_portGroupInfo_Get() != RC_OK", rc);
                strSortJobCancelReqResult.strResult = strEquipment_portGroupInfo_Get_out.strResult;
                return( rc );
            }

            CORBA::ULong lenEqpPort = strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq.length();
            PPT_METHODTRACE_V2("", "lenEqpPort", lenEqpPort);
            for ( CORBA::ULong ii = 0; ii < lenEqpPort; ii++ )
            {
                objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;

                PPT_METHODTRACE_V2( "", "calling object_LockForEquipmentResource()", SP_ClassName_PosPortResource );
                rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                      strObjCommonIn,
                                                      strSortJobListAttributes.equipmentID,
                                                      strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[ii].portID,
                                                      SP_ClassName_PosPortResource );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[ii].portID.identifier) ;
                    strSortJobCancelReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                    return( rc );
                }
                PPT_METHODTRACE_V2("", "Locked port object  : ", strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[ii].portID.identifier) ;
            }
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        PPT_METHODTRACE_V2("", "Object Lock .. Equipment.", strSortJobListAttributes.equipmentID.identifier );
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, strSortJobListAttributes.equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V3("", "object_Lock() != RC_OK",rc, strSortJobListAttributes.equipmentID.identifier );
            strSortJobCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

    //---------------------
    // Carrier
    //---------------------
    PPT_METHODTRACE_V1("", "Object Lock .. Carrier." );
    //Gathering carrier no-duplicated.
    CORBA::Long srtCmpLen  = strSortJobListAttributes.strSorterComponentJobListAttributesSeq.length();
    CORBA::Long srtCmpCnt  = 0;
    CORBA::Long slotMapLen = 0;
    CORBA::Long slotMapCnt = 0;
    CORBA::Long lotIDLen   = 0;
    objectIdentifierSequence orgCarrierIDs;
    objectIdentifierSequence dstCarrierIDs;
    objectIdentifierSequence lotIDs;
    orgCarrierIDs.length(0);
    dstCarrierIDs.length(0);
    lotIDs.length(0);
    CORBA::Long orgCarrierCnt = 0 ;
    CORBA::Long dstCarrierCnt = 0 ;
    CORBA::Long lotIDCnt      = 0 ;
    CORBA::Long i = 0;
    CORBA::Long j = 0;
    CORBA::Boolean bBWSOutFlag = FALSE; //INN-R170016
    CORBA::Boolean bBWSInFlag = FALSE; //INN-R170017
    for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
    {
        //originalCarrier
        CORBA::Boolean orgFoundFlag = FALSE;
        for( i = 0; i<orgCarrierCnt; i++)
        {
            if( 0 == CIMFWStrCmp(strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].originalCarrierID.identifier, orgCarrierIDs[i].identifier ))
            {
                orgFoundFlag = TRUE;
                break;
            }
        }
        if( FALSE == orgFoundFlag )
        {
            orgCarrierIDs.length( orgCarrierCnt + 1 );
            orgCarrierIDs[orgCarrierCnt++] = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].originalCarrierID;
            PPT_METHODTRACE_V3("", "Original Carrier    ", orgCarrierCnt, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].originalCarrierID.identifier );
        }

        //destinationCarrier
        CORBA::Boolean dstFoundFlag = FALSE;
        for( i = 0; i<dstCarrierCnt; i++)
        {
            if( 0 == CIMFWStrCmp(strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].destinationCarrierID.identifier, dstCarrierIDs[i].identifier ))
            {
                dstFoundFlag = TRUE;
                break;
            }
        }
        if( FALSE == dstFoundFlag )
        {
            dstCarrierIDs.length( dstCarrierCnt + 1 );
            dstCarrierIDs[dstCarrierCnt++] = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].destinationCarrierID;
            PPT_METHODTRACE_V3("", "Destination Carrier ", orgCarrierCnt, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].destinationCarrierID.identifier );
        }

        slotMapLen = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].strWaferSorterSlotMapSequence.length();
        for(slotMapCnt = 0; slotMapCnt<slotMapLen; slotMapCnt++)
        {
            CORBA::Boolean lotFoundFlag = FALSE;
            lotIDLen     = lotIDs.length();
            for(j=0; j<lotIDLen; j++)
            {
                if( 0 == CIMFWStrCmp(lotIDs[j].identifier, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID.identifier ) )
                {
                    lotFoundFlag = TRUE;
                    break;
                }
            }
            if( FALSE == lotFoundFlag )
            {
                lotIDs.length( lotIDCnt + 1 );
                lotIDs[lotIDCnt++] = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID;
            }
//INN-R170016 Add Start
            if( !bBWSOutFlag && (0 == CIMFWStrCmp(CS_WaferTransfer_BWSOut, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].actionCode)) )
            {
                PPT_METHODTRACE_V1("", "actionCode=BWSOut" );
                bBWSOutFlag = TRUE;
            }
//INN-R170016 Add End

//INN-R170017 Add Start
            if( !bBWSInFlag && (0 == CIMFWStrCmp(CS_WaferTransfer_BWSIn, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].strWaferSorterSlotMapSequence[slotMapCnt].actionCode)) )
            {
                PPT_METHODTRACE_V1("", "actionCode=BWSIn" );
                bBWSInFlag = TRUE;
            }
//INN-R170017 Add End
        }
    }

    CORBA::Long orgCarrierLen = orgCarrierIDs.length();
    CORBA::Long dstCarrierLen = dstCarrierIDs.length();
    CORBA::Long allCarrierLen = orgCarrierIDs.length() + dstCarrierIDs.length();
    CORBA::Long allCarrierCnt = 0 ;
    objectIdentifierSequence allCarrierIDs;
    allCarrierIDs.length(allCarrierLen);

    for(i=0; i<orgCarrierLen; i++)    allCarrierIDs[allCarrierCnt++] = orgCarrierIDs[i];
    for(i=0; i<dstCarrierLen; i++)    allCarrierIDs[allCarrierCnt++] = dstCarrierIDs[i];

    for(i=0; i<orgCarrierLen; i++)
    {
        PPT_METHODTRACE_V2("", "Object Lock .. Original Carrier.", orgCarrierIDs[i].identifier );
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, orgCarrierIDs[i], SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V3("", "object_Lock() != RC_OK",rc, orgCarrierIDs[i].identifier );
            strSortJobCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }

    for(i=0; i<dstCarrierLen; i++)
    {
        PPT_METHODTRACE_V2("", "Object Lock .. Destination Carrier.", dstCarrierIDs[i].identifier );
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, dstCarrierIDs[i], SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V3("", "object_Lock() != RC_OK",rc, dstCarrierIDs[i].identifier );
            strSortJobCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }

    //---------------------
    // Lot                 
    //---------------------
    PPT_METHODTRACE_V1("", "Object Lock .. Lot " );
    lotIDLen = lotIDs.length();
    for(lotIDCnt = 0; lotIDCnt<lotIDLen; lotIDCnt++)
    {
        PPT_METHODTRACE_V2("", "Object Lock .. Lot.", lotIDs[lotIDCnt].identifier );
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, lotIDs[lotIDCnt], SP_ClassName_PosLot );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V3("", "object_Lock() != RC_OK",rc, lotIDs[lotIDCnt].identifier );
            strSortJobCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }

    //--------------------------------------------
    // Check Inpara.componentJobID existence
    //--------------------------------------------
    PPT_METHODTRACE_V1("", "Check Inpara.sorterComponentJobID existence.");
    CORBA::Long compIDLen = sorterComponentJobIDseq.length();
    for(i=0; i<compIDLen; i++)
    {
        PPT_METHODTRACE_V3("", "sorterComponentJobIDseq...    ", i, sorterComponentJobIDseq[i].identifier );
        CORBA::Boolean compIDFoundFlag = FALSE;
        for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
        {
            if( 0 == CIMFWStrCmp( sorterComponentJobIDseq[i].identifier, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].sorterComponentJobID.identifier ))
            {
                compIDFoundFlag = TRUE;
                break;
            }
        }
        if( FALSE == compIDFoundFlag )
        {
            PPT_METHODTRACE_V1("", "input sorterComponentJobID does NOT exist.");
            PPT_SET_MSG_RC_KEY( strSortJobCancelReqResult, MSG_NOT_FOUND_SORTERJOB_COMPONENT, RC_NOT_FOUND_SORTERJOB_COMPONENT, sorterComponentJobIDseq[i].identifier );
            return RC_NOT_FOUND_SORTERJOB_COMPONENT;
        }
        PPT_METHODTRACE_V3("", "sorterComponentJobIDseq...FOUND", i, sorterComponentJobIDseq[i].identifier );
    }

    //--------------------------------------------------------------------------------------------
    // Judgement for deletion.                                                                    
    //                                                                                            
    //  SorterJobStatus  ComponentJobStatus     Can delete SortJob?    Can delete CompJob?        
    //  ------------------------------------------------------------------------------------      
    //  WaitToExecuting  WaitToExecuting        OK                     OK                         
    //  Executing        Xfer                   NG                     NG                         
    //  Executing        Executing              NG                     NG                         
    //  Executing        Wait To Executing      NG                     OK                         
    //  Executing        Completed              NG                     NG                         
    //  Error            Error                  OK                     OK                         
    //  Completed        Completed              OK                     OK                         
    //--------------------------------------------------------------------------------------------
    CORBA::Boolean srtDELFlag = FALSE;
    CORBA::Boolean cmpDELFlag = FALSE;

    PPT_METHODTRACE_V3("", "srtCmpLen, compIDLen", srtCmpLen, compIDLen );
    //Delete SortJob ? or Delete ComponentJob ?
    if( srtCmpLen == compIDLen )
    {
        //----------------------------------------
        // Delete Sort Job Information ?
        //----------------------------------------
        PPT_METHODTRACE_V1("", "Delete Sort Job Information? ( srtCmpLen == compIDLen ) ");
        srtDELFlag = TRUE;
       
        // If Component Job Status is Xfer or Executing. Sort Job can not be deleted.
        for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
        {
            PPT_METHODTRACE_V3("", "Component Job ID, Component Job Status.. ", 
                                   strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].sorterComponentJobID.identifier,
                                   strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus);
            if( 0 == CIMFWStrCmp( SP_SorterComponentJobStatus_Xfer,      strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus ) 
             || 0 == CIMFWStrCmp( SP_SorterComponentJobStatus_Executing, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus ))
            {
                PPT_METHODTRACE_V2("", "Can not delete Sort Job Information because of Component job Status is ", strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus );
                PPT_SET_MSG_RC_KEY4( strSortJobCancelReqResult, MSG_INVALID_COMPONENTJOB_STATUS, RC_INVALID_COMPONENTJOB_STATUS, 
                                     strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].sorterComponentJobID.identifier,
                                     strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus,
                                     sorterJobID.identifier, strSortJobListAttributes.sorterJobStatus);

                return ( RC_INVALID_COMPONENTJOB_STATUS );
            }
        }//Loop of Component Job
    }
    else if( 0 == compIDLen ) 
    {
 
        //----------------------------------------
        // Delete Sort Job Information ?
        //----------------------------------------
        PPT_METHODTRACE_V1("", "Delete Sort Job Information?  ( 0 == compIDLen ) ");
        srtDELFlag = TRUE;
        //SortJobStatus is not Executing? WaitToExecuting , Error, Completed can be deleted.
        if( 0 == CIMFWStrCmp( SP_SorterJobStatus_Executing, strSortJobListAttributes.sorterJobStatus ) )
        {
            PPT_METHODTRACE_V2("", "Can not delete Sort Job Information because of Sort job Status is ", strSortJobListAttributes.sorterJobStatus );
            PPT_SET_MSG_RC_KEY2( strSortJobCancelReqResult, MSG_INVALID_SORTER_JOB_STATUS, RC_INVALID_SORTER_JOB_STATUS, sorterJobID.identifier, strSortJobListAttributes.sorterJobStatus );
            return ( RC_INVALID_SORTER_JOB_STATUS );
        }
    }
    else
    {
        //----------------------------------------
        // Delete Component Job Information ?     
        //----------------------------------------
        PPT_METHODTRACE_V1("", "Delete Component Job Information? other ");
        cmpDELFlag = TRUE;

        for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
        {
            PPT_METHODTRACE_V3("", "Component Job ID, Component Job Status.. ", 
                                   strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].sorterComponentJobID.identifier,
                                   strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus);

            if( 0 == CIMFWStrCmp( SP_SorterComponentJobStatus_Xfer,      strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus ) 
             || 0 == CIMFWStrCmp( SP_SorterComponentJobStatus_Executing, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus ) 
             || 0 == CIMFWStrCmp( SP_SorterComponentJobStatus_Completed, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus ))
            {
                if( 0 == CIMFWStrCmp( SP_SorterComponentJobStatus_Completed, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus )
                 && 0 == CIMFWStrCmp( SP_SorterJobStatus_Completed,          strSortJobListAttributes.sorterJobStatus ))
                {
                   //OK
                    PPT_METHODTRACE_V1("", "Sort Job Status and Component Job Staus are Completed. OK.");
                }
                else
                {
                    PPT_METHODTRACE_V2("", "Can not delete Component Job Information because of Component job Status is ", strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus );
                    PPT_SET_MSG_RC_KEY4( strSortJobCancelReqResult, MSG_INVALID_COMPONENTJOB_STATUS, RC_INVALID_COMPONENTJOB_STATUS, 
                                         strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].sorterComponentJobID.identifier,
                                         strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].componentSorterJobStatus,
                                         sorterJobID.identifier, strSortJobListAttributes.sorterJobStatus);

                    return ( RC_INVALID_COMPONENTJOB_STATUS );
                }
            }
        }//Loop of Component 
    }

    PPT_METHODTRACE_V3("","Delete SortJob?/Delete ComponentJob?",(srtDELFlag?"True":"False"), (cmpDELFlag?"True":"False"));
    //---------------------------------------------
    // Get Sort Job by the Equipment.              
    //---------------------------------------------
    PPT_METHODTRACE_V2("", "Get Sorter Job Information. ", sorterJobID.identifier );
    objSorter_jobList_GetDR_out   strSorter_jobList_GetDR_out_EQP;
    objSorter_jobList_GetDR_in    strSorter_jobList_GetDR_in_EQP;
    strSorter_jobList_GetDR_in_EQP.equipmentID = strSortJobListAttributes.equipmentID;

    rc = sorter_jobList_GetDR(strSorter_jobList_GetDR_out_EQP, strObjCommonIn, strSorter_jobList_GetDR_in_EQP);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "sorter_jobList_GetDR() rc != RC_OK", rc);
        strSortJobCancelReqResult.strResult = strSorter_jobList_GetDR_out_EQP.strResult;
        return rc;
    }

    pptSortJobListAttributesSequence   strSortJobListAttributesSeq_EQP;
    strSortJobListAttributesSeq_EQP  = strSorter_jobList_GetDR_out_EQP.strSortJobListAttributesSeq;

    //------------------------------------------
    // Delete Sort Job Information
    //------------------------------------------
    if( TRUE == srtDELFlag )
    {
        //Delete Slot Map , Component Job Information.
        objSorter_componentJob_DeleteDR_out strSorter_componentJob_DeleteDR_out;
        objSorter_componentJob_DeleteDR_in  strSorter_componentJob_DeleteDR_in;
        strSorter_componentJob_DeleteDR_in.sorterJobID       = sorterJobID;

        rc = sorter_componentJob_DeleteDR( strSorter_componentJob_DeleteDR_out, strObjCommonIn, strSorter_componentJob_DeleteDR_in );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "sorter_componentJob_DeleteDR() rc != RC_OK");
            strSortJobCancelReqResult.strResult = strSorter_componentJob_DeleteDR_out.strResult;
            return rc;
        }

        //Delete Sorter Job Information.
        objSorter_sorterJob_DeleteDR_out strSorter_sorterJob_DeleteDR_out;
        objSorter_sorterJob_DeleteDR_in  strSorter_sorterJob_DeleteDR_in;
        strSorter_sorterJob_DeleteDR_in.sorterJobID = sorterJobID;

        rc = sorter_sorterJob_DeleteDR( strSorter_sorterJob_DeleteDR_out, strObjCommonIn, strSorter_sorterJob_DeleteDR_in );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "sorter_sorterJob_DeleteDR() rc != RC_OK");
            strSortJobCancelReqResult.strResult = strSorter_sorterJob_DeleteDR_out.strResult;
            return rc;
        }

        //Adjust order sequence of remained Sort Job .
        CORBA::Long remainSortJobLen = strSortJobListAttributesSeq_EQP.length();
        objectIdentifierSequence remainSortJobIDs;
        CORBA::Long              remainSortJobCnt = 0;
        remainSortJobIDs.length( remainSortJobCnt );

        for(i=0; i<remainSortJobLen; i++)
        {
            if( 0 != CIMFWStrCmp( sorterJobID.identifier, strSortJobListAttributesSeq_EQP[i].sorterJobID.identifier ))
            {
                remainSortJobIDs.length( remainSortJobCnt + 1 );
                remainSortJobIDs[remainSortJobCnt++] = strSortJobListAttributesSeq_EQP[i].sorterJobID;
            }
        }

        //--------------------------------------------
        // Change priority of remained Sort Job.      
        //--------------------------------------------
        if (remainSortJobIDs.length() > 0)
        {
            PPT_METHODTRACE_V1("", "### Chage priority for remain sorterJobID.");
            objSorter_linkedJobUpdateDR_out strSorter_linkedJobUpdateDR_out;
            objSorter_linkedJobUpdateDR_in  strSorter_linkedJobUpdateDR_in;
            strSorter_linkedJobUpdateDR_in.jobIDs  = remainSortJobIDs;
            strSorter_linkedJobUpdateDR_in.jobType = CIMFWStrDup( SP_Sorter_Job_Type_SorterJob );
            rc = sorter_linkedJobUpdateDR( strSorter_linkedJobUpdateDR_out, strObjCommonIn, strSorter_linkedJobUpdateDR_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "sorter_linkedJobUpdateDR() rc != RC_OK");
                strSortJobCancelReqResult.strResult = strSorter_linkedJobUpdateDR_out.strResult;
                return rc;
            }
        }
    }
    //------------------------------------------
    // Delete Component Job Information
    //------------------------------------------
    else if( TRUE == cmpDELFlag )
    {
        //Delete Slot Map, Component Job Information.
        objSorter_componentJob_DeleteDR_out strSorter_componentJob_DeleteDR_out;
        objSorter_componentJob_DeleteDR_in  strSorter_componentJob_DeleteDR_in;
        strSorter_componentJob_DeleteDR_in.sorterJobID       = sorterJobID;
        strSorter_componentJob_DeleteDR_in.componentJobIDseq = sorterComponentJobIDseq;
        rc = sorter_componentJob_DeleteDR( strSorter_componentJob_DeleteDR_out, strObjCommonIn, strSorter_componentJob_DeleteDR_in );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "sorter_componentJob_DeleteDR() rc != RC_OK");
            strSortJobCancelReqResult.strResult = strSorter_componentJob_DeleteDR_out.strResult;
            return rc;
        }

        //Adjust order sequence of remained Component Job .
        CORBA::Long remainComponentJobLen = strSortJobListAttributes.strSorterComponentJobListAttributesSeq.length();
        objectIdentifierSequence remainComponentJobIDs;
        CORBA::Long              remainComponentJobCnt = 0;
        remainComponentJobIDs.length( remainComponentJobCnt );

        for(i=0; i<remainComponentJobLen; i++)
        {
            compIDLen = sorterComponentJobIDseq.length();
            for(j=0; j<compIDLen; j++)
            {
                if( 0 != CIMFWStrCmp( sorterComponentJobIDseq[j].identifier, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[i].sorterComponentJobID.identifier ))
                {
                    remainComponentJobIDs.length( remainComponentJobCnt + 1 );
                    remainComponentJobIDs[remainComponentJobCnt++] = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[i].sorterComponentJobID;
                }
            }
        }

        //--------------------------------------------
        // Change priority of remained Component Job. 
        //--------------------------------------------
        if (remainComponentJobIDs.length() > 0)
        {
            PPT_METHODTRACE_V1("", "### Chage priority for remain sorter Component Job.");
            objSorter_linkedJobUpdateDR_out strSorter_linkedJobUpdateDR_out;
            objSorter_linkedJobUpdateDR_in  strSorter_linkedJobUpdateDR_in;
            strSorter_linkedJobUpdateDR_in.jobIDs  = remainComponentJobIDs;
            strSorter_linkedJobUpdateDR_in.jobType = CIMFWStrDup( SP_Sorter_Job_Type_ComponentJob );
            rc = sorter_linkedJobUpdateDR( strSorter_linkedJobUpdateDR_out, strObjCommonIn, strSorter_linkedJobUpdateDR_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "sorter_linkedJobUpdateDR() rc != RC_OK");
                strSortJobCancelReqResult.strResult = strSorter_linkedJobUpdateDR_out.strResult;
                return rc;
            }
        }
    }
    //--------------------------------------------------------------
    //  Call TxSendSortJobCancelNotificationReq
    //--------------------------------------------------------------
    PPT_METHODTRACE_V2("", "Notify Sort Job Cancel to TCS ", (notifyToTCSFlag?"TRUE":"FALSE"));
    if( TRUE == notifyToTCSFlag )
    {
        PPT_METHODTRACE_V1("", "### Sorter Job Cancel Notice to TCS. notifyToTCSFlag == TRUE");

        //PSN000078594 objTCSMgr_SendSortJobCancelNotificationReq_out strTCSMgr_SendSortJobCancelNotificationReq_out;
        //PSN000078594 objTCSMgr_SendSortJobCancelNotificationReq_in  strTCSMgr_SendSortJobCancelNotificationReq_in;
        //PSN000078594 strTCSMgr_SendSortJobCancelNotificationReq_in.requestUserID = strObjCommonIn.strUser;
        //PSN000078594 strTCSMgr_SendSortJobCancelNotificationReq_in.equipmentID   = strSortJobListAttributes.equipmentID;
        //PSN000078594 strTCSMgr_SendSortJobCancelNotificationReq_in.sorterJobID   = strSortJobListAttributes.sorterJobID;
        //PSN000078594 strTCSMgr_SendSortJobCancelNotificationReq_in.claimMemo     = CIMFWStrDup( claimMemo );
        //PSN000078594 
        //PSN000078594 rc = TCSMgr_SendSortJobCancelNotificationReq( strTCSMgr_SendSortJobCancelNotificationReq_out, strObjCommonIn, strTCSMgr_SendSortJobCancelNotificationReq_in );
        //PSN000078594 add start
        CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
        CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
        CORBA::Long sleepTimeValue = 0;
        CORBA::Long retryCountValue = 0;

        if (CIMFWStrLen(tmpSleepTimeValue) == 0)
        {
            sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
        }
        else
        {
            sleepTimeValue = atoi(tmpSleepTimeValue) ;
        }

        if (CIMFWStrLen(tmpRetryCountValue) == 0)
        {
            retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
        }
        else
        {
            retryCountValue = atoi(tmpRetryCountValue);
        }

        PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
        PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

        objTCSMgr_SendSortJobCancelNotificationReq_out strTCSMgr_SendSortJobCancelNotificationReq_out;
        objTCSMgr_SendSortJobCancelNotificationReq_in  strTCSMgr_SendSortJobCancelNotificationReq_in;
        strTCSMgr_SendSortJobCancelNotificationReq_in.requestUserID = strObjCommonIn.strUser;
        strTCSMgr_SendSortJobCancelNotificationReq_in.equipmentID   = strSortJobListAttributes.equipmentID;
        strTCSMgr_SendSortJobCancelNotificationReq_in.sorterJobID   = strSortJobListAttributes.sorterJobID;
        strTCSMgr_SendSortJobCancelNotificationReq_in.claimMemo     = CIMFWStrDup( claimMemo );

        //'retryCountValue + 1' means first try plus retry count
        for( CORBA::ULong retryNum = 0 ; retryNum < (retryCountValue + 1) ; retryNum++ )
        {
            /*--------------------------*/
            /*    Send Request to TCS   */
            /*--------------------------*/
            PPT_METHODTRACE_V1("", "call TCSMgr_SendSortJobCancelNotificationReq()");
            rc = TCSMgr_SendSortJobCancelNotificationReq( strTCSMgr_SendSortJobCancelNotificationReq_out, strObjCommonIn, strTCSMgr_SendSortJobCancelNotificationReq_in );

            PPT_METHODTRACE_V2("","rc = ",rc);

            if(rc == RC_OK)
            {
                PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                break;
            }
            else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                      rc == RC_EXT_SERVER_NIL_OBJ   ||
                      rc == RC_TCS_NO_RESPONSE )
            {
                PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",retryNum);
                PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                sleep(sleepTimeValue);
                continue;
            }
            else
            {
                PPT_METHODTRACE_V1("", "TCSMgr_SendSortJobCancelNotificationReq() rc != RC_OK");
                strSortJobCancelReqResult.strResult = strTCSMgr_SendSortJobCancelNotificationReq_out.strResult;
                return rc;
            }
        }
        //PSN000078594 add end

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendSortJobCancelNotificationReq() rc != RC_OK");
            strSortJobCancelReqResult.strResult = strTCSMgr_SendSortJobCancelNotificationReq_out.strResult;
            return rc;
        }
    }

    //------------------------
    // NPWReserve Cancel
    //------------------------
    allCarrierLen = allCarrierIDs.length();
    objectIdentifierSequence NPWRsvCanCarrierIDs;
    objectIdentifierSequence NPWRsvLoadPortIDs;
    CORBA::Long NPWRsvCnt = 0;
    NPWRsvCanCarrierIDs.length(NPWRsvCnt);
    NPWRsvLoadPortIDs.length(NPWRsvCnt);
    for(allCarrierCnt =0; allCarrierCnt<allCarrierLen; allCarrierCnt++)
    {
        PPT_METHODTRACE_V2("", "Carrier has 'NPW Reserve ' ? ", allCarrierIDs[allCarrierCnt].identifier );
        objectIdentifier loadPortID;
        if( TRUE == srtDELFlag )
        {
            for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
            {
                if( 0 == CIMFWStrCmp( allCarrierIDs[allCarrierCnt].identifier, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].originalCarrierID.identifier ))
                {
                    loadPortID = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].originalPortID;
                    break;
                }
                else if( 0 == CIMFWStrCmp( allCarrierIDs[allCarrierCnt].identifier, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].destinationCarrierID.identifier ))
                {
                    loadPortID = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].destinationPortID;
                    break;
                }
            }
        }
        else if( TRUE == cmpDELFlag )
        {
            CORBA::Boolean carrierFoundFlag = FALSE;
            compIDLen = sorterComponentJobIDseq.length();
            for(i=0; i<compIDLen; i++)
            {
                for(srtCmpCnt = 0; srtCmpCnt<srtCmpLen; srtCmpCnt++)            //Component
                {
                    if( 0 == CIMFWStrCmp( sorterComponentJobIDseq[i].identifier, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].sorterComponentJobID.identifier ))
                    {
                        if( 0 == CIMFWStrCmp( allCarrierIDs[allCarrierCnt].identifier, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].originalCarrierID.identifier ))
                        {
                            loadPortID = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].originalPortID;
                            carrierFoundFlag = TRUE;
                            break;
                        }
                        else if( 0 == CIMFWStrCmp( allCarrierIDs[allCarrierCnt].identifier, strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].destinationCarrierID.identifier ))
                        {
                            loadPortID = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[srtCmpCnt].destinationPortID;
                            carrierFoundFlag = TRUE;
                            break;
                        }
                    }
                }
                if( TRUE == carrierFoundFlag ) break;
            }
            if( FALSE == carrierFoundFlag )
            {
                //not found.
                PPT_METHODTRACE_V2(""," carrierFoundFlag == FALSE .continue.",allCarrierIDs[allCarrierCnt].identifier );
                continue;
            }
        }

        //---------------------------------------
        // Carrier is reserved for dispatching?
        //---------------------------------------
        objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
        strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE;         //Initialize.
        rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn, allCarrierIDs[allCarrierCnt] );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_dispatchState_Get() rc != RC_OK");
            strSortJobCancelReqResult.strResult = strCassette_dispatchState_Get_out.strResult;
            return rc;
        }

        PPT_METHODTRACE_V3("", "Carrier is reserved for dispatching ?", (strCassette_dispatchState_Get_out.dispatchReservedFlag? "True":"False"), allCarrierIDs[allCarrierCnt].identifier  );
        if( TRUE == strCassette_dispatchState_Get_out.dispatchReservedFlag )
        {
            PPT_METHODTRACE_V1("", "cassette_dispatchState_Get cassette is reserved");
            NPWRsvCanCarrierIDs.length( NPWRsvCnt + 1 );
            NPWRsvLoadPortIDs.length( NPWRsvCnt + 1 );

            NPWRsvCanCarrierIDs[NPWRsvCnt] = allCarrierIDs[allCarrierCnt];
            NPWRsvLoadPortIDs[NPWRsvCnt++]     = loadPortID;
        }
//INN-R170016 Add Start
        //----------------------------------
        // delete BWSOut slotMap for carrier
        //----------------------------------
        if (TRUE == bBWSOutFlag)
        {
            PPT_METHODTRACE_V2("","call cs_BWSOutSTB_slotMap_DeleteDR()", allCarrierIDs[allCarrierCnt].identifier);

            csObjBWSOutSTB_slotMap_DeleteDR_in strBWSOutSTB_slotMap_DeleteDR_in;
            strBWSOutSTB_slotMap_DeleteDR_in.carrierID = allCarrierIDs[allCarrierCnt];

            csObjBWSOutSTB_slotMap_DeleteDR_out strBWSOutSTB_slotMap_DeleteDR_out;
            rc = cs_BWSOutSTB_slotMap_DeleteDR(strBWSOutSTB_slotMap_DeleteDR_out, strObjCommonIn, strBWSOutSTB_slotMap_DeleteDR_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("","cs_BWSOutSTB_slotMap_DeleteDR() rc != RC_OK", rc);
                strSortJobCancelReqResult.strResult = strBWSOutSTB_slotMap_DeleteDR_out.strResult;
                return(rc);
            }
        }
//INN-R170016 Add End
    }
    
    //INN-R170017 add start
    //------------------------------------
    //  Delete wafer UData : M_WAFER_BWSJob_ZoneID
    //------------------------------------
    if( ( bBWSInFlag == TRUE || bBWSOutFlag == TRUE ) )
    {        
        CORBA::Long lnLenAttr = strSortJobListAttributes.strSorterComponentJobListAttributesSeq.length();
        for( CORBA::Long ix=0; ix<lnLenAttr; ix++ )
        {
            CORBA::Long lnLenSlotMap = strSortJobListAttributes.strSorterComponentJobListAttributesSeq[ix].strWaferSorterSlotMapSequence.length();                                    
            for( CORBA::Long jx=0; jx<lnLenSlotMap; jx++ )
            {
                PPT_METHODTRACE_V2( "", "waferID", strSortJobListAttributes.strSorterComponentJobListAttributesSeq[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier );

                // make input data
                pptUserDataUpdateReqInParm strUserDataUpdateReqInParm;
                strUserDataUpdateReqInParm.stringifiedObjectReference   = CIMFWStrDup("");
                strUserDataUpdateReqInParm.className                    = CIMFWStrDup(SP_ClassName_PosWafer);
                strUserDataUpdateReqInParm.strHashedInfoSeq.length(1);
                strUserDataUpdateReqInParm.strHashedInfoSeq[0].hashKey  = CIMFWStrDup(SP_HashData_WAFER_ID);
                strUserDataUpdateReqInParm.strHashedInfoSeq[0].hashData = CIMFWStrDup(strSortJobListAttributes.strSorterComponentJobListAttributesSeq[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier);                
                strUserDataUpdateReqInParm.actionCode                   = CIMFWStrDup(SP_UserDataUpdateReq_ActionCode_Delete);
                strUserDataUpdateReqInParm.strUserDataSeq.length(2);
                strUserDataUpdateReqInParm.strUserDataSeq[0].name       = CIMFWStrDup(CS_M_WAFER_BWSJob_ZoneID);
                strUserDataUpdateReqInParm.strUserDataSeq[0].type       = CIMFWStrDup("String");
                strUserDataUpdateReqInParm.strUserDataSeq[0].value      = CIMFWStrDup("");
                strUserDataUpdateReqInParm.strUserDataSeq[0].originator = CIMFWStrDup(SP_USERDATA_ORIG_MM);
                strUserDataUpdateReqInParm.strUserDataSeq[1].name       = CIMFWStrDup(CS_M_WAFER_BWSJob_ActionCode);
                strUserDataUpdateReqInParm.strUserDataSeq[1].type       = CIMFWStrDup("String");
                strUserDataUpdateReqInParm.strUserDataSeq[1].value      = CIMFWStrDup("");
                strUserDataUpdateReqInParm.strUserDataSeq[1].originator = CIMFWStrDup(SP_USERDATA_ORIG_MM);
                                
                // delete wafer UData
                PPT_METHODTRACE_V2( "", "calling txUserDataUpdateReq() for waferID ", strSortJobListAttributes.strSorterComponentJobListAttributesSeq[ix].strWaferSorterSlotMapSequence[jx].waferID.identifier );
                pptUserDataUpdateReqResult strUserDataUpdateReqResult;
                rc = txUserDataUpdateReq( strUserDataUpdateReqResult,
                                          strObjCommonIn,
                                          strUserDataUpdateReqInParm,
                                          "" );
                                          
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "", "txUserDataUpdateReq() rc != RC_OK, rc=", rc );
                    strSortJobCancelReqResult.strResult = strUserDataUpdateReqResult.strResult;
                    return rc;
                }      
            }            
        } 
    }
    //INN-R170017 add end

    //----------------------------------------
    // Call txArrivalCarrierCancelReq__090    
    //----------------------------------------
    CORBA::Long NPWRsvLen = NPWRsvCanCarrierIDs.length();
    PPT_METHODTRACE_V2("", "NPW Reserve Cancel ." , NPWRsvLen );
    if( 0 < NPWRsvLen )
    {
        pptArrivalCarrierCancelReqResult__090 strArrivalCarrierCancelReqResult__090;
        pptNPWXferCassetteSequence            strNPWXferCassette;

        strNPWXferCassette.length(NPWRsvLen);

        for(NPWRsvCnt=0; NPWRsvCnt<NPWRsvLen; NPWRsvCnt++)
        {
            PPT_METHODTRACE_V2("", "NPW Reserve Cancel Cassette " , NPWRsvCanCarrierIDs[NPWRsvCnt].identifier );
            PPT_METHODTRACE_V2("", "NPW Reserve Cancel LoatPort " , NPWRsvLoadPortIDs[NPWRsvCnt].identifier );
            strNPWXferCassette[NPWRsvCnt].cassetteID = NPWRsvCanCarrierIDs[NPWRsvCnt];
            strNPWXferCassette[NPWRsvCnt].loadPortID = NPWRsvLoadPortIDs[NPWRsvCnt];
        }

        rc = txArrivalCarrierCancelReq__090( strArrivalCarrierCancelReqResult__090, strObjCommonIn, strSortJobListAttributes.equipmentID, 
                                        strSortJobListAttributes.portGroupID.identifier, strNPWXferCassette, notifyToTCSFlag, claimMemo );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txArrivalCarrierCancelReq__090() rc != RC_OK");
            strSortJobCancelReqResult.strResult = strArrivalCarrierCancelReqResult__090.strResult;
            return rc;
        }
    }

    // Caller is TxWaferSorterOnEqpRpt
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRR009" ))
    {
        //Create History Event
        objSorter_sorterJobEvent_Make_out   strSorter_sorterJobEvent_Make_out;
        objSorter_sorterJobEvent_Make_in    strSorter_sorterJobEvent_Make_in;
        strSorter_sorterJobEvent_Make_in.action                      = CIMFWStrDup( SP_Sorter_Job_Action_SortJobDeleted );
        strSorter_sorterJobEvent_Make_in.transactionID               = strObjCommonIn.transactionID;
        strSorter_sorterJobEvent_Make_in.strSortJobListAttributes    = strSortJobListAttributes;

        rc = sorter_sorterJobEvent_Make(strSorter_sorterJobEvent_Make_out, strObjCommonIn, strSorter_sorterJobEvent_Make_in);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "sorter_sorterJobEvent_Make() rc != RC_OK");
            strSortJobCancelReqResult.strResult = strSorter_sorterJobEvent_Make_out.strResult;
            return rc;
        }
    }


    SET_MSG_RC( strSortJobCancelReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txSortJobCancelReq");
    return RC_OK;
}

