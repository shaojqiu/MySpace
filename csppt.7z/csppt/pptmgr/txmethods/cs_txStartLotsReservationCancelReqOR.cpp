#ifndef lint
static char *sccsid =  "@(#) 1.6 superpos/src/spppt/source/posppt/pptmgr/txmethods/txStartLotsReservationCancelReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 3/10/08 14:02:38 [ 3/10/08 14:02:39 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: txStartLotsReservationCancelReq.cpp
//

#include "cs_pptmgr.hpp"

#include "unistd.h"

//=============================================================================
// For TXTRC042 : txStartLotsReservationCancelReq
//=============================================================================
// Class: PPTManager
//
// Service: txStartLotsReservationCancelReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/21          O.Sugiyama     Initial Release
// 2000/08/24 0.01     O.Sugiyama     add Check Process & Main Process
// 2000/09/08 P3000078 O.Sugiyama     loadPurposeType not use CIMFWStrDup
// 2000/09/10 0.02     Y.Iwasaki      Bug fix (In-correct obj call)
// 2001/01/10 D3000093 M.Mori         Add change "Required" logic
// 2001/07/05 D4000015 H.Katoh        Add Equipment Category Check Logic because of
//                                    Internal Buffer Support
// 2001-08-28 D4000116 Y.Iwasaki      Change condition for calling 'equipment_dispatchState_Change()'
// 2001/09/07 D4000060 K.Kido         Add retry TCS request logic
// 2004/08/09 D51M0000 M.Murata       APC I/F Enhance for Interface Spec-B
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/09/09 D6000418 M.Murata       Lock Port Object.
// 2005/10/31 D7000006 T.Ohsaki       exchange "controlJob_Delete()" to "txControlJobManageReq()"
// 2006/01/20 D7000182 H.Mutoh        Enhancement of re-sending APCControlJobInformation.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/06/05 D9000003 M.Nakano       Modify logic to get controlJob info to include processJobExecFlag info.
// 2008/02/22 D9000175 K.Kido         Support takeOutInf transfer function.
// 2008/06/24 DSIV00000099 K.Matsuei  SLM(Small Lot Manufacturing) Support.
// 2010/04/16 DSIV00001830 R.Okano    Wafer Stacking Operation Support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/10/18 DSIV00002435 M.Ogawa        Support SubLotType change by Schedule Change Reservation
// 2012/11/27 DSN000049350 F.Chen         Equipment parallel processing support (P2)
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptStartLotsReservationCancelReqResult& strStartLotsReservationCancelReqResult
//    const pptObjCommonIn&                   strObjCommonIn
//    const objectIdentifier&                 equipmentID
//    const objectIdentifier&                 controlJobID
//    const char *                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txStartLotsReservationCancelReq (
    pptStartLotsReservationCancelReqResult& strStartLotsReservationCancelReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 equipmentID,
    const objectIdentifier&                 controlJobID,
//D6000025     const char *                            claimMemo,
//D6000025     CORBA::Environment &                    IT_env)
//D7000182    const char *                            claimMemo  //D6000025
    const char *                            claimMemo,             //D7000182
    char *&                                 APCIFControlStatus     //D7000182
    CORBAENV_LAST_CPP)                                 //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txStartLotsReservationCancelReq");
    CORBA::Long rc = RC_OK ;

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC042" ); // TxStartLotsReservationCancelReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strStartLotsReservationCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;
    
    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strStartLotsReservationCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*-------------------------*/
        /*   Lock Machine Object   */
        /*-------------------------*/
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "object_Lock() != RC_OK" );
            strStartLotsReservationCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

//DSN000049350 Move to later session
//DSN000049350//DSIV00000099 start
//DSN000049350    //-----------------------------------------------
//DSN000049350    //   Lock Equipment Container Position Objects
//DSN000049350    //-----------------------------------------------
//DSN000049350    PPT_METHODTRACE_V1("", "call object_LockForEquipmentContainerPosition()");
//DSN000049350    objObject_LockForEquipmentContainerPosition_out strObject_LockForEquipmentContainerPosition_out;
//DSN000049350    objObject_LockForEquipmentContainerPosition_in strObject_LockForEquipmentContainerPosition_in;
//DSN000049350
//DSN000049350    strObject_LockForEquipmentContainerPosition_in.equipmentID = equipmentID;
//DSN000049350    strObject_LockForEquipmentContainerPosition_in.controlJobID = controlJobID;
//DSN000049350
//DSN000049350    rc = object_LockForEquipmentContainerPosition(
//DSN000049350                strObject_LockForEquipmentContainerPosition_out,
//DSN000049350                strObjCommonIn,
//DSN000049350                strObject_LockForEquipmentContainerPosition_in );
//DSN000049350
//DSN000049350    if ( rc != RC_OK )
//DSN000049350    {
//DSN000049350        PPT_METHODTRACE_V2("","object_LockForEquipmentContainerPosition() != RC_OK", rc);
//DSN000049350        strStartLotsReservationCancelReqResult.strResult = strObject_LockForEquipmentContainerPosition_out.strResult;
//DSN000049350        return (rc);
//DSN000049350    }
//DSN000049350//DSIV00000099 end
//DSN000049350 Move End

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //D4000015 Start
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strStartLotsReservationCancelReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //D4000015 End

    /*-------------------------*/
    /*   Get ControlJob Info   */
    /*-------------------------*/
//D9000003 delete start
//    objControlJob_containedLot_Get_out strControlJob_containedLot_Get_out;
//    rc = controlJob_containedLot_Get( strControlJob_containedLot_Get_out, strObjCommonIn,
//                                      controlJobID );
//    if ( rc != RC_OK )
//    {
//        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "controlJob_containedLot_Get() != RC_OK" );
//        strStartLotsReservationCancelReqResult.strResult = strControlJob_containedLot_Get_out.strResult;
//        return( rc );
//    }
//D9000003 delete end
//D9000003 add start
    objControlJob_startReserveInformation_Get_out strControlJob_startReserveInformation_Get_out;
    rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out, strObjCommonIn,
                                      controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txStartLotsReservationCancelReq", "controlJob_startReserveInformation_Get() rc != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult;
        return( rc );
    }
//D9000003 add end


    /*---------------------------------------------------*/
    /*   Prepare strStartCassette for Working-Valiable   */
    /*---------------------------------------------------*/

    CORBA::Long scLen = 0;
    CORBA::Long lcLen = 0;

//D9000003    scLen = strControlJob_containedLot_Get_out.strControlJobCassette.length();
    pptStartCassetteSequence  strStartCassette;
//D9000003    strStartCassette.length(scLen);

    CORBA::Long i = 0;
//D9000003 delete start
//    PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "scLen", scLen);
//    for ( i=0 ; i<scLen ; i++ )
//    {
//        strStartCassette[i].loadSequenceNumber = strControlJob_containedLot_Get_out.strControlJobCassette[i].loadSequenceNumber;
//        strStartCassette[i].cassetteID         = strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID;
////P3000078 strStartCassette[i].loadPurposeType    = CIMFWStrDup(strControlJob_containedLot_Get_out.strControlJobCassette[i].loadPurposeType);
//        strStartCassette[i].loadPurposeType    = strControlJob_containedLot_Get_out.strControlJobCassette[i].loadPurposeType; //P3000078
//        strStartCassette[i].loadPortID         = strControlJob_containedLot_Get_out.strControlJobCassette[i].loadPortID;
//        strStartCassette[i].unloadPortID       = strControlJob_containedLot_Get_out.strControlJobCassette[i].unloadPortID;
//
//        PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "strControlJobCassette[i]", i);
//        PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "[loadSequenceNumber]", strControlJob_containedLot_Get_out.strControlJobCassette[i].loadSequenceNumber);
//        PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "[cassetteID        ]", strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID.identifier);
//        PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "[loadPurposeType   ]", strControlJob_containedLot_Get_out.strControlJobCassette[i].loadPurposeType);
//        PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "[loadPortID        ]", strControlJob_containedLot_Get_out.strControlJobCassette[i].loadPortID.identifier);
//        PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "[unloadPortID      ]", strControlJob_containedLot_Get_out.strControlJobCassette[i].unloadPortID.identifier);
//
//        lcLen = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot.length();
//        strStartCassette[i].strLotInCassette.length(lcLen);
//
//        CORBA::Long j = 0;
//        PPT_METHODTRACE_V3( "PPTManager_i:: txStartLotsReservationCancelReq ", "lcLen", lcLen, i);
//        for ( j=0 ; j<lcLen ; j++ )
//        {
//            strStartCassette[i].strLotInCassette[j].operationStartFlag = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].operationStartFlag;
//            strStartCassette[i].strLotInCassette[j].monitorLotFlag     = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag;
//            strStartCassette[i].strLotInCassette[j].lotID              = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].lotID;
//        }
//    }
//D9000003 delete end
//D9000003 add start
    strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette ;
    scLen = strStartCassette.length();
//D9000003 add end

//D6000418 add start
    /*--------------------------------------------*/
    /*                                            */
    /*        Port Object Lock Process            */
    /*                                            */
    /*--------------------------------------------*/
    PPT_METHODTRACE_V1("", "#### Port Object Lock ");
    /*--------------------------------*/
    /*   Lock Port object (To)        */
    /*--------------------------------*/
    /*----------------------------------------------------------*/
    /*   Get All Ports being in the same Port Group as ToPort   */
    /*----------------------------------------------------------*/
    objPortResource_allPortsInSameGroup_Get_out strPortResource_allPortsInSameGroup_Get_out;
    rc = portResource_allPortsInSameGroup_Get( strPortResource_allPortsInSameGroup_Get_out,
                                               strObjCommonIn,
                                               equipmentID,
                                               strStartCassette[0].loadPortID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "portResource_allPortsInSameGroup_Get() rc != RC_OK", rc);
        strStartLotsReservationCancelReqResult.strResult = strPortResource_allPortsInSameGroup_Get_out.strResult;
        return( rc );
    }

    /*---------------------------------------------------------*/
    /* Lock All Ports being in the same Port Group as ToPort   */
    /*---------------------------------------------------------*/
    CORBA::Long lenToPort = strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length();
    for ( CORBA::Long ii=0 ; ii < lenToPort ; ii++ )
    {
        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[ii].portID,
                                              SP_ClassName_PosPortResource );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[ii].portID.identifier) ;
            strStartLotsReservationCancelReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "Locked port object(to)  : ", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[ii].portID.identifier);
    }

    /*--------------------------------*/
    /*   Lock Port object (From)      */
    /*--------------------------------*/
    for ( ii=0 ; ii<scLen ; ii++ )
    {
        /*-----------------------------------*/
        /*  Check cassette transfer status   */
        /*-----------------------------------*/
        PPT_METHODTRACE_V1( "", "Check cassette transfer status");
        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                         strObjCommonIn,
                                         strStartCassette[ii].cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_transferState_Get != RC_OK", rc);
            strStartLotsReservationCancelReqResult.strResult = strCassette_transferState_Get_out.strResult;
            return( rc );
        }

        if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
        {
            PPT_METHODTRACE_V2( "", "Cassette's transferState == EI ", strStartCassette[ii].cassetteID.identifier);
            /*------------------------------------*/
            /*   Get Cassette Info in Equipment   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1( "","Get Cassette Info in Equipment");
            objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
            rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                           strObjCommonIn,
                                           strStartCassette[ii].cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
                strStartLotsReservationCancelReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2( "", "equipmentID == ", strCassette_equipmentID_Get_out.equipmentID.identifier);

            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                         strObjCommonIn,
                                         strCassette_equipmentID_Get_out.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "equipment_portInfo_Get != RC_OK", rc);
                strStartLotsReservationCancelReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return( rc );
            }

            /*----------------------------------------------------------*/
            /*  Lock port object which has the specified cassette.      */
            /*----------------------------------------------------------*/
            CORBA::Long lenFromPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            for ( CORBA::Long jj=0 ; jj < lenFromPort ; jj++ )
            {
                if ( 0 == CIMFWStrCmp( strStartCassette[ii].cassetteID.identifier,
                                       strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[jj].loadedCassetteID.identifier) )
                {
                    objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                    rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                          strObjCommonIn,
                                                          strCassette_equipmentID_Get_out.equipmentID,
                                                          strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[jj].portID,
                                                          SP_ClassName_PosPortResource );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
                        strStartLotsReservationCancelReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                        return( rc );
                    }
                    PPT_METHODTRACE_V2("", "Locked port object(to)  : ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
                }
            }// lenFromPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        }// 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn )
    }// scLen = strStartCassette.length();
//D6000418 add end

//DSN000049350 Add Start
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        /*------------------------------*/
        /*   Lock ControlJob Object     */
        /*------------------------------*/
        PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosControlJob );
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          controlJobID,
                          SP_ClassName_PosControlJob );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strStartLotsReservationCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }
//DSN000049350 Add End

    /*--------------------------------*/
    /*   Lock Cassette / Lot Object   */
    /*--------------------------------*/
//DSN000049350 Add Start
    objectIdentifierSequence lotIDs;
    objectIdentifierSequence cassetteIDs;
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_lotIDLen    = extendLen;
    CORBA::ULong lotIDCnt      = 0;
    lotIDs.length(t_lotIDLen);
    cassetteIDs.length(scLen);
//DSN000049350 Add End

    for ( i=0 ; i<scLen ; i++ )
    {

//DSN000049350        /*--------------------------*/
//DSN000049350        /*   Lock Cassette Object   */
//DSN000049350        /*--------------------------*/
//DSN000049350        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350                          strStartCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350        if ( rc != RC_OK )
//DSN000049350        {
//DSN000049350            PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "object_Lock() != RC_OK", i);
//DSN000049350            strStartLotsReservationCancelReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350            return( rc );
//DSN000049350        }

        cassetteIDs[i] = strStartCassette[i].cassetteID;  //DSN000049350

        CORBA::Long j = 0;
        lcLen = strStartCassette[i].strLotInCassette.length();
        for ( j=0 ; j<lcLen ; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

//DSN000049350            /*---------------------*/
//DSN000049350            /*   Lock Lot Object   */
//DSN000049350            /*---------------------*/
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350                              strStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V3( "PPTManager_i:: txStartLotsReservationCancelReq ", "object_Lock() != RC_OK", i, j);
//DSN000049350                strStartLotsReservationCancelReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350                return( rc );
//DSN000049350            }
//DSN000049350 Add Start
            if( lotIDCnt >= t_lotIDLen )
            {
                PPT_METHODTRACE_V1("", "lotIDCnt >= t_lotIDLen");
                t_lotIDLen += extendLen;
                lotIDs.length( t_lotIDLen );
            }
            lotIDs[lotIDCnt++] = strStartCassette[i].strLotInCassette[j].lotID;
//DSN000049350 Add End
            
        }
    }
    lotIDs.length(lotIDCnt);                        //DSN000049350
    PPT_METHODTRACE_V2( "", "lotIDCnt", lotIDCnt);  //DSN000049350

//DSIV00000099 start
    //--------------------------------------------------
    //   Lock Destination Cassette by SLM Reserved
    //--------------------------------------------------
    PPT_METHODTRACE_V1( "", "Lock Destination Cassette by SLM Reserved");

    objEquipmentContainer_info_GetDR_out strEquipmentContainer_info_GetDR_out;
    objEquipmentContainer_info_GetDR_in strEquipmentContainer_info_GetDR_in;

    strEquipmentContainer_info_GetDR_in.equipmentID = equipmentID;

    PPT_METHODTRACE_V1("", "call equipmentContainer_info_GetDR()");
    rc = equipmentContainer_info_GetDR( strEquipmentContainer_info_GetDR_out,
                                        strObjCommonIn,
                                        strEquipmentContainer_info_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "##### equipmentContainer_info_GetDR != RC_OK", rc);
        strStartLotsReservationCancelReqResult.strResult = strEquipmentContainer_info_GetDR_out.strResult;
        return rc;
    }

    const pptEqpContainerSequence& strEqpContSeq = strEquipmentContainer_info_GetDR_out.strEqpContainerInfo.strEqpContainerSeq;

    CORBA::Long lenEqpCont = strEqpContSeq.length();
    PPT_METHODTRACE_V2("", "lenEqpCont", lenEqpCont);

    for ( CORBA::Long nCst=0; nCst < scLen; nCst++ )
    {
        for ( CORBA::Long nECT=0; nECT < lenEqpCont; nECT++ )
        {
            CORBA::Long lenEqpContPos = strEqpContSeq[nECT].strEqpContainerPositionSeq.length();
            PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);

            for ( CORBA::Long nECP=0; nECP < lenEqpContPos; nECP++ )
            {
                const pptEqpContainerPosition& strCtnPstInfo = strEqpContSeq[nECT].strEqpContainerPositionSeq[nECP];

                if ( 0 == CIMFWStrCmp(strStartCassette[nCst].cassetteID.identifier, strCtnPstInfo.srcCassetteID.identifier)
                  && ( 0 < CIMFWStrLen(strCtnPstInfo.destCassetteID.identifier)
                    && 0 != CIMFWStrCmp(strCtnPstInfo.srcCassetteID.identifier, strCtnPstInfo.destCassetteID.identifier) ) )
                {
                    PPT_METHODTRACE_V2("", "Source Cassette", strCtnPstInfo.srcCassetteID.identifier);
                    PPT_METHODTRACE_V2("", "object_Lock Destination Cassette", strCtnPstInfo.destCassetteID.identifier);

                    rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                                      strCtnPstInfo.destCassetteID, SP_ClassName_PosCassette );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### object_Lock() != RC_OK", rc);
                        strStartLotsReservationCancelReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            } //[nECP]
        } //[nECT]
    } //[nCst]
//DSIV00000099 end

//DSN000049350 Add Start
    /*------------------------------*/
    /*   Lock Cassette/Lot Object   */
    /*-------------------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strStartLotsReservationCancelReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosLot );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              lotIDs,
                              SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strStartLotsReservationCancelReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

//DSN000049350 Move from earlier session
//DSIV00000099 start
    //-----------------------------------------------
    //   Lock Equipment Container Position Objects
    //-----------------------------------------------
    PPT_METHODTRACE_V1("", "call object_LockForEquipmentContainerPosition()");
    objObject_LockForEquipmentContainerPosition_out strObject_LockForEquipmentContainerPosition_out;
    objObject_LockForEquipmentContainerPosition_in strObject_LockForEquipmentContainerPosition_in;

    strObject_LockForEquipmentContainerPosition_in.equipmentID = equipmentID;
    strObject_LockForEquipmentContainerPosition_in.controlJobID = controlJobID;

    rc = object_LockForEquipmentContainerPosition(
                strObject_LockForEquipmentContainerPosition_out,
                strObjCommonIn,
                strObject_LockForEquipmentContainerPosition_in );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_LockForEquipmentContainerPosition() != RC_OK", rc);
        strStartLotsReservationCancelReqResult.strResult = strObject_LockForEquipmentContainerPosition_out.strResult;
        return (rc);
    }
//DSIV00000099 end
//DSN000049350 Move End

//D3000093 add start

//D9000175 add start
    /*--------------------------------------------------------*/
    /*   Check equipment availability of TakeOutIn transfer   */
    /*--------------------------------------------------------*/
    objEquipment_TakeOutInMode_Check_out strEquipment_TakeOutInMode_Check_out;
    objEquipment_TakeOutInMode_Check_in strEquipment_TakeOutInMode_Check_in;
    strEquipment_TakeOutInMode_Check_in.equipmentID = equipmentID;
    rc = equipment_TakeOutInMode_Check( strEquipment_TakeOutInMode_Check_out, strObjCommonIn,
                                        strEquipment_TakeOutInMode_Check_in);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "equipment_TakeOutInMode_Check() != RC_OK" );
        strStartLotsReservationCancelReqResult.strResult = strEquipment_TakeOutInMode_Check_out.strResult;
        return( rc );
    }

    CORBA::Long eqpTakeOutInSupport = strEquipment_TakeOutInMode_Check_out.eqpTakeOutInSupport;
    PPT_METHODTRACE_V2( "", "eqpTakeOutInSupport = ",eqpTakeOutInSupport );
//D9000175 add end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Port Status Change Process    (To Equipment)                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    for ( i=0 ; i<scLen ; i++ )
    {
        PPT_METHODTRACE_V3( "PPTManager_i:: txStartLotsReservationCancelReq ", "loadPortID", strStartCassette[i].loadPortID.identifier, i);
        CORBA::Long basePGNo = 0;

        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                     strObjCommonIn,
                                     equipmentID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "equipment_portInfo_Get() != RC_OK" );
            strStartLotsReservationCancelReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
            return( rc );
        }

        CORBA::Long lenPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "strEqpPortStatus.length", lenPortInfo);

        for ( CORBA::Long j=0 ; j<lenPortInfo ; j++ )
        {
            PPT_METHODTRACE_V3( "PPTManager_i:: txStartLotsReservationCancelReq ", "strEqpPortStatus[j].portID", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier, j);
            PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "strEqpPortStatus[j].dispatchState", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState);

            if ( 0 != CIMFWStrCmp( strStartCassette[i].loadPortID.identifier,
                                   strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier) )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "Not same portID, continue...");
                continue;
            }

            if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "dispatchState == Dispatched");

//D4000116      if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq) ||
//D4000116           0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) )
                if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq   ) || //D4000116
                     0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq ) || //D4000116
                     0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_Unknown   ) )  //D4000116
                {
//D4000116          PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "portState == LoadReq or UnloadReq");
                    PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "portState == LoadReq or UnloadReq or '-'"); //D4000116

                    /*------------------------*/
                    /*   change to Required   */
                    /*------------------------*/
                    objectIdentifier dummyOI;
                    objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out ;
                    rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                         strObjCommonIn,
                                                         equipmentID,
                                                         strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                         SP_PortRsc_DispatchState_Required,
                                                         dummyOI,
                                                         dummyOI,
                                                         dummyOI,
                                                         dummyOI );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "equipment_dispatchState_Change() != RC_OK");
                        strStartLotsReservationCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                        return( rc );
                    }
//D9000175 add start
                    if(  1 == eqpTakeOutInSupport
                      && CIMFWStrLen(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchUnloadCassetteID.identifier)
                      )
                    {
                        PPT_METHODTRACE_V1( " ", "### This reservation is TakeOutIn mode!!!");
                        /*-----------------------------------------------------------------------------------------------------*/
                        /*   This port has TakeOutIn reservation. Dispatch status should be re-changed for take out carrier    */
                        /*    1. Dispatch State ==> Dispatched.                                                                */
                        /*    2. Dispatch Unload Carrier ==> dispUnLoadCastID.                                                 */
                        /*-----------------------------------------------------------------------------------------------------*/
                        rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                             strObjCommonIn,
                                                             equipmentID,
                                                             strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                             SP_PortRsc_DispatchState_Dispatched,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI,
                                                             strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchUnloadCassetteID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1( "", "equipment_dispatchState_Change() != RC_OK");
                            strStartLotsReservationCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                            return( rc );
                        }
                    }
//D9000175 add end
                }

                basePGNo = j;
                break;
            }
        }

        /*--------------------------*/
        /*   find Same Port Group   */
        /*--------------------------*/
        for ( j=0 ; j<lenPortInfo ; j++ )
        {
            PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "loop to strEqpPortStatus", j);

            /*===== Omit Base Port =====*/
            if ( j == basePGNo )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "j == basePGNo, continue...");
                continue;
            }
            /*===== Omit Different Group's Port =====*/
            if ( 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portGroup, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[basePGNo].portGroup) )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "Not same portGroup, continue...");
                continue;
            }

            /*===== Check portState =====*/
//D4000116  if ( 0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq) &&
//D4000116       0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) )
            if ( 0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq  ) && //D4000116
                 0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) && //D4000116
                 0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_Unknown  ) )  //D4000116
            {
//D4000116      PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "portState != LoadReq or UnloadReq, continue...");
                PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "portState != LoadReq or UnloadReq or '-', continue...");  //D4000116
                continue;
            }

            /*===== Check dispatchState =====*/
            if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched ) ||
                 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_NotDispatched ) )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "Same PortGroup == Dispatched or NotDispatched");
                PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "dispatchState", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState);

                /*------------------------*/
                /*   change to Required   */
                /*------------------------*/
                objectIdentifier dummyOI;
                objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out ;
                rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                     strObjCommonIn,
                                                     equipmentID,
                                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                     SP_PortRsc_DispatchState_Required,
                                                     dummyOI,
                                                     dummyOI,
                                                     dummyOI,
                                                     dummyOI );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "equipment_dispatchState_Change() != RC_OK");
                    strStartLotsReservationCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                    return( rc );
                }
//D9000175 add start
                if(  1 == eqpTakeOutInSupport
                  && CIMFWStrLen(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchUnloadCassetteID.identifier)
                  )
                {
                    PPT_METHODTRACE_V1( " ", "### This reservation is TakeOutIn mode!!!");
                    /*-----------------------------------------------------------------------------------------------------*/
                    /*   This port has TakeOutIn reservation. Dispatch status should be re-changed for take out carrier    */
                    /*    1. Dispatch State ==> Dispatched.                                                                */
                    /*    2. Dispatch Unload Carrier ==> dispUnLoadCastID.                                                 */
                    /*-----------------------------------------------------------------------------------------------------*/
                    rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                         strObjCommonIn,
                                                         equipmentID,
                                                         strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                         SP_PortRsc_DispatchState_Dispatched,
                                                         dummyOI,
                                                         dummyOI,
                                                         dummyOI,
                                                         strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchUnloadCassetteID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "", "equipment_dispatchState_Change() != RC_OK");
                        strStartLotsReservationCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                        return( rc );
                    }
                }
//D9000175 add end
            }
        }
    }


    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Port Status Change Process    (From Equipment)                      */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    for ( i=0 ; i<scLen ; i++ )
    {
        PPT_METHODTRACE_V3( "PPTManager_i:: txStartLotsReservationCancelReq ", "strStartCassette[i].cassetteID", strStartCassette[i].cassetteID.identifier, i);

        /*-----------------------------------*/
        /*  Check cassette transfer status   */
        /*-----------------------------------*/
        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "Check cassette transfer status");

        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                         strObjCommonIn,
                                         strStartCassette[i].cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "cassette_transferState_Get != RC_OK");
            strStartLotsReservationCancelReqResult.strResult = strCassette_transferState_Get_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "transferState", strCassette_transferState_Get_out.transferState);

        if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "transferState == EI");

            /*------------------------------------*/
            /*   Get Cassette Info in Equipment   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1( "PPTManager_i::txStartLotsReservationCancelReq ","Get Cassette Info in Equipment");

            objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
            rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                           strObjCommonIn,
                                           strStartCassette[i].cassetteID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "cassette_equipmentID_Get != RC_OK");
                strStartLotsReservationCancelReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                return( rc );
            }

            PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "equipmentID", strCassette_equipmentID_Get_out.equipmentID.identifier);

//D9000175 add start
            /*--------------------------------------------------------*/
            /*   Check equipment availability of TakeOutIn transfer   */
            /*--------------------------------------------------------*/
            objEquipment_TakeOutInMode_Check_out strEquipment_TakeOutInMode_Check_out;
            objEquipment_TakeOutInMode_Check_in strEquipment_TakeOutInMode_Check_in;
            strEquipment_TakeOutInMode_Check_in.equipmentID = strCassette_equipmentID_Get_out.equipmentID;
            rc = equipment_TakeOutInMode_Check( strEquipment_TakeOutInMode_Check_out, strObjCommonIn,
                                                strEquipment_TakeOutInMode_Check_in);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "equipment_TakeOutInMode_Check() != RC_OK" );
                strStartLotsReservationCancelReqResult.strResult = strEquipment_TakeOutInMode_Check_out.strResult;
                return( rc );
            }

            CORBA::Long fromEqpTakeOutInSupport = strEquipment_TakeOutInMode_Check_out.eqpTakeOutInSupport;
            PPT_METHODTRACE_V2( "", "fromEqpTakeOutInSupport = ",fromEqpTakeOutInSupport );
//D9000175 add end

            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                         strObjCommonIn,
                                         strCassette_equipmentID_Get_out.equipmentID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "PPTManager_i::txStartLotsReservationCancelReq ", "equipment_portInfo_Get != RC_OK");
                strStartLotsReservationCancelReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return( rc );
            }


            CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            for ( CORBA::Long j=0; j < lenEqpPort; j++ )
            {
                PPT_METHODTRACE_V3( "PPTManager_i::txStartLotsReservationCancelReq ", "strEqpPortStatus[j].loadedCassetteID",
                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier, j);

                if ( 0 == CIMFWStrCmp( strStartCassette[i].cassetteID.identifier,
                                       strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                {
                    PPT_METHODTRACE_V1( "PPTManager_i::txStartLotsReservationCancelReq ", "cassetteID == loadedCassetteID");

                    if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) &&
                         0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
                    {
                        PPT_METHODTRACE_V1( "PPTManager_i::txStartLotsReservationCancelReq ", "(portState == UnloadReq) && (dispatchState == Dispatched)");

                        /*------------------------*/
                        /*   change to Required   */
                        /*------------------------*/
                        objectIdentifier dummyOI;
                        objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out;
                        rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                             strObjCommonIn,
                                                             strCassette_equipmentID_Get_out.equipmentID,
                                                             strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                             SP_PortRsc_DispatchState_Required,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "equipment_dispatchState_Change() != RC_OK");
                            strStartLotsReservationCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                            return( rc );
                        }
//D9000175 add start
                        if(  1 == fromEqpTakeOutInSupport
                          && CIMFWStrLen(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchLoadCassetteID.identifier)
                          )
                        {
                            /*-----------------------------------------------------------------------------------------------------*/
                            /*   This port has TakeOutIn reservation. Dispatch status should be re-changed for take in carrier     */
                            /*    1. Dispatch State ==> Dispatched.                                                                */
                            /*    2. Dispatch load Carrier ==> dispLoadCastID.                                                     */
                            /*-----------------------------------------------------------------------------------------------------*/
                            rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                                 strObjCommonIn,
                                                                 equipmentID,
                                                                 strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                                 SP_PortRsc_DispatchState_Dispatched,
                                                                 dummyOI,
                                                                 strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchLoadCassetteID,
                                                                 dummyOI,
                                                                 dummyOI );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1( "", "equipment_dispatchState_Change() != RC_OK");
                                strStartLotsReservationCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                                return( rc );
                            }
                        }
//D9000175 add end
                    }
                }
            }
        }
    }
//D3000093 add end


//D51M0000 add start
    /*-------------------------------------------------*/
    /*   call cassette_APCInformation_GetDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", " call cassette_APCInformation_GetDR");
    objCassette_APCInformation_GetDR_out strCassette_APCInformation_GetDR_out;
    rc = cassette_APCInformation_GetDR ( strCassette_APCInformation_GetDR_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         strStartCassette );
    if ( rc == RC_SYSTEM_ERROR )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() == RC_SYSTEM_ERROR");
        strStartLotsReservationCancelReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
        return ( rc ) ;
    }
    else if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
    }
//D51M0000 add end


    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//0.01 add start
    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - dispatchState                                                     */
    /*   - controlJobID                                                      */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objCassette_CheckConditionForStartReserveCancel_out strCassette_CheckConditionForStartReserveCancel_out;
    rc = cassette_CheckConditionForStartReserveCancel( strCassette_CheckConditionForStartReserveCancel_out, strObjCommonIn,
                                                       controlJobID, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "cassette_CheckConditionForStartReserveCancel() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strCassette_CheckConditionForStartReserveCancel_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - lotProcessState                                                   */
    /*   - controlJobID                                                      */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objLot_CheckConditionForStartReserveCancel_out strLot_CheckConditionForStartReserveCancel_out;
    rc = lot_CheckConditionForStartReserveCancel( strLot_CheckConditionForStartReserveCancel_out, strObjCommonIn,
                                                  controlJobID, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "lot_CheckConditionForStartReserveCancel() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strLot_CheckConditionForStartReserveCancel_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Equipment                                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - reservedControlJobID                                              */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//  objEquipment_CheckConditionForOpeStartCancel_out strEquipment_CheckConditionForOpeStartCancel_out;
//  rc = equipment_CheckConditionForOpeStartCancel( strEquipment_CheckConditionForOpeStartCancel_out, strObjCommonIn,
//                                                  equipmentID, strStartCassette /* controlJobID */);
//  if ( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "equipment_CheckConditionForOpeStartCancel() != RC_OK");
//      strStartLotsReservationCancelReqResult.strResult = strEquipment_CheckConditionForOpeStartCancel_out.strResult;
//      return( rc );
//  }
    objEquipment_CheckConditionForStartReserveCancel_out strEquipment_CheckConditionForStartReserveCancel_out;
    rc = equipment_CheckConditionForStartReserveCancel( strEquipment_CheckConditionForStartReserveCancel_out,
                                                        strObjCommonIn,
                                                        equipmentID,
                                                        controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "equipment_CheckConditionForStartReserveCancel() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strEquipment_CheckConditionForStartReserveCancel_out.strResult;
        return( rc );
    }

    /*---------------------------------*/
    /*   Get Equipment's Online Mode   */
    /*---------------------------------*/
    objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out, strObjCommonIn,
                                                equipmentID, strStartCassette[0].unloadPortID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "portResource_currentOperationMode_Get() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
        return( rc );
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process (Reverse Order of StartReserve Procedure)              */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*--------------------------------------------------------*/
    /*   Clear ActualStart Info in Each Lots' PO              */
    /*                                                        */
    /*   - Clear controlJobID of each cassette.               */
    /*   - Clear controlJobID of each lot.                    */
    /*   - Clear control job info of each lot's cunrrent PO.  */
    /*--------------------------------------------------------*/
    objProcess_startReserveInformation_Clear_out strProcess_startReserveInformation_Clear_out;
    rc = process_startReserveInformation_Clear( strProcess_startReserveInformation_Clear_out, strObjCommonIn,
                                                controlJobID, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "process_startReserveInformation_clear() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strProcess_startReserveInformation_Clear_out.strResult;
        return( rc );
    }

    /*----------------------------------------------------*/
    /*   Clear Start Reserved Control Job in Equipment    */
    /*----------------------------------------------------*/
    objEquipment_reservedControlJobID_Clear_out strEquipment_reservedControlJobID_Clear_out;
    rc = equipment_reservedControlJobID_Clear( strEquipment_reservedControlJobID_Clear_out, strObjCommonIn,
                                               equipmentID, controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "equipment_reservedControlJobID_Clear() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strEquipment_reservedControlJobID_Clear_out.strResult;
        return( rc );
    }

//DSIV00000099 start
    //-----------------------------------------------------
    //   Clear Reserved SLM Information
    //-----------------------------------------------------
    PPT_METHODTRACE_V1("", "call equipment_reservedControlJob_ClearForSLM()");
    objEquipment_reservedControlJob_ClearForSLM_out strEquipment_reservedControlJob_ClearForSLM_out;
    objEquipment_reservedControlJob_ClearForSLM_in strEquipment_reservedControlJob_ClearForSLM_in;

    strEquipment_reservedControlJob_ClearForSLM_in.equipmentID = equipmentID;
    strEquipment_reservedControlJob_ClearForSLM_in.controlJobID = controlJobID;

    rc = equipment_reservedControlJob_ClearForSLM(
                    strEquipment_reservedControlJob_ClearForSLM_out,
                    strObjCommonIn,
                    strEquipment_reservedControlJob_ClearForSLM_in );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_reservedControlJob_ClearForSLM() != RC_OK", rc);
        strStartLotsReservationCancelReqResult.strResult = strEquipment_reservedControlJob_ClearForSLM_out.strResult;
        return( rc );
    }
//DSIV00000099 end

//DSIV00001830 add start
    //-----------------------------------------------------------//
    //  Wafer Stacking Operation                                 //
    //    If Equipment Category is SP_Mc_Category_WaferBonding,  //
    //    update Bonding Group Information                       //
    //-----------------------------------------------------------//
    objLot_bondingGroup_UpdateByOperation_out strLot_bondingGroup_UpdateByOperation_out;
    objLot_bondingGroup_UpdateByOperation_in strLot_bondingGroup_UpdateByOperation_in;
    strLot_bondingGroup_UpdateByOperation_in.equipmentID = equipmentID;
    strLot_bondingGroup_UpdateByOperation_in.controlJobID = controlJobID;
    strLot_bondingGroup_UpdateByOperation_in.strStartCassette = strStartCassette;
    strLot_bondingGroup_UpdateByOperation_in.operation = CIMFWStrDup( SP_Operation_StartReservationCancel );
    
    PPT_METHODTRACE_V1("", "call lot_bondingGroup_UpdateByOperation()");
    rc = lot_bondingGroup_UpdateByOperation( strLot_bondingGroup_UpdateByOperation_out, strObjCommonIn, strLot_bondingGroup_UpdateByOperation_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "lot_bondingGroup_UpdateByOperation() != RC_OK", rc );
        strStartLotsReservationCancelReqResult.strResult = strLot_bondingGroup_UpdateByOperation_out.strResult;
        return (rc);
    }
//DSIV00001830 add end
//DSIV00002435 add start
    for ( i = 0 ; i < scLen ; i++ )
    {
        PPT_METHODTRACE_V2("", "Loop count i :", i);
        CORBA::Long j = 0;
        lcLen = strStartCassette[i].strLotInCassette.length();

        for ( j = 0; j < lcLen; j++ )
        {
            PPT_METHODTRACE_V3("", "Loop count j. LotID :", j, strStartCassette[i].strLotInCassette[j].lotID.identifier);
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE" );
                continue;
            }

            //---------------------------------------------------------------------------------------//
            //  Check if schedule change by lot information change is reserved for this operation    //
            //  If schedule change is reserved, delete the reservation and send e-mail to lot owner  //
            //---------------------------------------------------------------------------------------//
            PPT_METHODTRACE_V1("", "call lot_currentOperationInfo_Get()");
            objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
            rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "lot_currentOperationInfo_Get() != RC_OK", rc );
                strStartLotsReservationCancelReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
                return (rc);
            }

            CORBA::String_var targetRouteID;
            CORBA::String_var targetOperationNumber;

            targetRouteID         = strLot_currentOperationInfo_Get_out.routeID.identifier;
            targetOperationNumber = strLot_currentOperationInfo_Get_out.operationNumber;

            PPT_METHODTRACE_V2("", "targetRouteID         : ", targetRouteID);
            PPT_METHODTRACE_V2("", "targetOperationNumber : ", targetOperationNumber);


            objSchdlChangeReservation_GetListDR_out__110 strSchdlChangeReservation_GetListDR_out;
            objSchdlChangeReservation_GetListDR_in__110  strSchdlChangeReservation_GetListDR_in;
            strSchdlChangeReservation_GetListDR_in.objectID              = strStartCassette[i].strLotInCassette[j].lotID.identifier;
            strSchdlChangeReservation_GetListDR_in.objectType            = SP_SCHDL_CHG_OBJTYPE_LOT;
            strSchdlChangeReservation_GetListDR_in.targetRouteID         = targetRouteID;
            strSchdlChangeReservation_GetListDR_in.targetOperationNumber = targetOperationNumber;
            strSchdlChangeReservation_GetListDR_in.lotInfoChangeFlag     = 2;                   //2: LOTINFO_CHANGE_FLAG is 1

            PPT_METHODTRACE_V1("", "call schdlChangeReservation_GetListDR()");
            rc = schdlChangeReservation_GetListDR__110( strSchdlChangeReservation_GetListDR_out, strObjCommonIn, strSchdlChangeReservation_GetListDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "schdlChangeReservation_GetListDR() != RC_OK", rc );
                strStartLotsReservationCancelReqResult.strResult = strSchdlChangeReservation_GetListDR_out.strResult;
                return (rc);
            }

            CORBA::Long rsvLength = 0;
            rsvLength = strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations.length();
            if( 0 < rsvLength )
            {
                PPT_METHODTRACE_V2("", "rsvLength:", rsvLength);
                for( CORBA::Long k = 0; k < rsvLength; k++ )
                {
                    PPT_METHODTRACE_V2("", "Loop count k :", k);
                    PPT_METHODTRACE_V1("", "call schdlChangeReservation_DeleteDR()");
                    objSchdlChangeReservation_Delete_out        strSchdlChangeReservation_Delete_out;
                    objSchdlChangeReservation_DeleteDR_in__110  strSchdlChangeReservation_DeleteDR_in;
                    strSchdlChangeReservation_DeleteDR_in.strSchdlChangeReservation = strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k];

                    rc = schdlChangeReservation_DeleteDR__110( strSchdlChangeReservation_Delete_out, strObjCommonIn, strSchdlChangeReservation_DeleteDR_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "", "schdlChangeReservation_DeleteDR() != RC_OK", rc );
                        strStartLotsReservationCancelReqResult.strResult = strSchdlChangeReservation_Delete_out.strResult;
                        return (rc);
                    }

                    /*------------------------*/
                    /*   Send e-mail          */
                    /*------------------------*/
                    PPT_METHODTRACE_V1("", "Send e-mail");
                    ostrstream  ostrMessage;
                    ostrMessage << "This message was sent because reservation for \"Lot Information Change\" is canceled.\n";
                    ostrMessage << "Schedule Change Reservation Info.\n";
                    ostrMessage << "LotID      : " << strStartCassette[i].strLotInCassette[j].lotID.identifier << "\n";
                    ostrMessage << "Product ID : " << strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k].productID.identifier << "\n";
                    ostrMessage << "Route ID   : " << strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k].routeID.identifier << "\n";
                    ostrMessage << "Ope.No     : " << strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k].operationNumber << "\n";
                    ostrMessage << "SubLotType : " << strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k].subLotType << "\n";
                    ostrMessage << ends;

                    PPT_METHODTRACE_V2("", " MessageDistributionMgr_PutMessage() ", i);
                    objMessageDistributionMgr_PutMessage_out strMessageDistributionMgr_PutMessage_out;
                    objectIdentifier messageID;
                    messageID.identifier = CIMFWStrDup(SP_SystemMsgCode_SCRNotice);
                    rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out,
                                                            strObjCommonIn,
                                                            messageID,
                                                            strStartCassette[i].strLotInCassette[j].lotID,
                                                            "",                                                     //lotStatus
                                                            equipmentID,
                                                            strLot_currentOperationInfo_Get_out.routeID,
                                                            strLot_currentOperationInfo_Get_out.operationNumber,
                                                            "",                                                     //reasonCode
                                                            ostrMessage.str() );
                    ostrMessage.rdbuf()->freeze(0);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK") ;
                        strStartLotsReservationCancelReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult ;
                        return( rc );
                    }
                } //end of [k]
            } //end of [if( 0 < rsvLength )]
        } //end of [j]
    } //end of [i]
//DSIV00002435 add end

    /*------------------------*/
    /*   Delete Control Job   */
    /*------------------------*/
//D7000006    objControlJob_Delete_out strControlJob_Delete_out;
//D7000006    rc = controlJob_Delete( strControlJob_Delete_out, strObjCommonIn,
//D7000006                            controlJobID );
//D7000006    if ( rc != RC_OK )
//D7000006    {
//D7000006        PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "controlJob_Delete() != RC_OK");
//D7000006        strStartLotsReservationCancelReqResult.strResult = strControlJob_Delete_out.strResult;
//D7000006        return( rc );
//D7000006    }
    //D7000006 Add Start
    pptControlJobManageReqResult strControlJobManageReqResult;
    pptControlJobCreateRequest   dummyControlJobCreateRequest;
    rc = txControlJobManageReq( strControlJobManageReqResult,
                                strObjCommonIn,
                                controlJobID,
                                SP_ControlJobAction_Type_delete,
                                dummyControlJobCreateRequest,
                                claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strControlJobManageReqResult.strResult;
        return( rc );
    }
    //D7000006 Add End

    /*---------------------------------------------------*/
    /*                                                   */
    /*   Cassette Related Information Update Procedure   */
    /*                                                   */
    /*---------------------------------------------------*/
    CORBA::Long nILen = strStartCassette.length();
    PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "nILen", nILen);
    for ( i=0 ; i<nILen ; i++ )
    {

        /*-----------------------------------------------*/
        /*   Change Cassette's Dispatch State to FALSE   */
        /*-----------------------------------------------*/
        objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
        rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out, strObjCommonIn,
                                            strStartCassette[i].cassetteID, FALSE );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "PPTManager_i:: txStartLotsReservationCancelReq ", "cassette_dispatchState_Change() != RC_OK", i);
            strStartLotsReservationCancelReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
            return( rc );
        }
    }

    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send StartLotsReservationCancelReq() to TCS Procedure                */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
//D4000060     objTCSMgr_SendStartLotsReservationCancelReq_out strTCSMgr_SendStartLotsReservationCancelReq_out;
//D4000060     rc = TCSMgr_SendStartLotsReservationCancelReq( strTCSMgr_SendStartLotsReservationCancelReq_out, strObjCommonIn,
//D4000060                                                    strObjCommonIn.strUser,
//D4000060                                                    equipmentID,
//D4000060                                                    controlJobID,
//D4000060                                                    claimMemo );
//D4000060     if ( rc != RC_OK )
//D4000060     {
//D4000060         PPT_METHODTRACE_V1( "PPTManager_i:: txStartLotsReservationCancelReq ", "TCSMgr_SendStartLotsReservationCancelReq() != RC_OK");
//D4000060         strStartLotsReservationCancelReqResult.strResult = strTCSMgr_SendStartLotsReservationCancelReq_out.strResult;
//D4000060         return( rc );
//D4000060     }
//D4000060 add start
    CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue;
    CORBA::Long retryCountValue;

    if (CIMFWStrLen(tmpSleepTimeValue) == 0)
    {
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
//D9000001        sleepTimeValue = atol(tmpSleepTimeValue) ;
        sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
    }

    if (CIMFWStrLen(tmpRetryCountValue) == 0)
    {
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
//D9000001        retryCountValue = atol(tmpRetryCountValue);
        retryCountValue = atoi(tmpRetryCountValue);    //D9000001
    }

    PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
    PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

    objTCSMgr_SendStartLotsReservationCancelReq_out strTCSMgr_SendStartLotsReservationCancelReq_out;

    //'retryCountValue + 1' means first try plus retry count
    for(i = 0 ; i < (retryCountValue + 1) ; i++)
    {
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        rc = TCSMgr_SendStartLotsReservationCancelReq( strTCSMgr_SendStartLotsReservationCancelReq_out,
                                                       strObjCommonIn,
                                                       strObjCommonIn.strUser,
                                                       equipmentID,
                                                       controlJobID,
                                                       claimMemo );
        PPT_METHODTRACE_V2("","rc = ",rc);

        if(rc == RC_OK)
        {
            PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                  rc == RC_EXT_SERVER_NIL_OBJ   ||
                  rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
            PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendStartLotsReservationCancelReq() != RC_OK");
            strStartLotsReservationCancelReqResult.strResult = strTCSMgr_SendStartLotsReservationCancelReq_out.strResult;
            return( rc );
        }

     }

     if ( rc != RC_OK )
     {
        PPT_METHODTRACE_V1("", "TCSMgr_SendStartLotsReservationCancelReq() != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strTCSMgr_SendStartLotsReservationCancelReq_out.strResult;
        return( rc );
     }
//D4000060 add end
//0.01 add end

//D51M0000 add start
    /*-------------------------------------------------*/
    /*   call APCRuntimeCapability_DeleteDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call  APCRuntimeCapability_DeleteDR ");
    objAPCRuntimeCapability_DeleteDR_out strAPCRuntimeCapability_DeleteDR_out;
    rc = APCRuntimeCapability_DeleteDR ( strAPCRuntimeCapability_DeleteDR_out,
                                         strObjCommonIn,
                                         controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1(""," APCRuntimeCapability_DeleteDR() rc != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strAPCRuntimeCapability_DeleteDR_out.strResult;
        return( rc );
    }

//   Wafer information in APCBaseCassette is not necessary for reserve cancel,
//   but it is required by wrapper for process xml which satisfy dtd.
//   So, now we add dummy wafer data into strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList.

    CORBA::Long bcLen = strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList.length();
    CORBA::Long bcIdx = 0;
    for( bcIdx = 0; bcIdx < bcLen; bcIdx++ )
    {
        CORBA::Long blLen = strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot.length();
        CORBA::Long blIdx = 0;
        for( blIdx = 0; blIdx < blLen; blIdx++ )
        {
            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer.length(1);

            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].waferID              = CIMFWStrDup("");
            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].slotNumber           = 0;
            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].controlWaferFlag     = FALSE;
            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].sendAheadWaferFlag   = FALSE;
            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].processFlag          = FALSE;
            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].experimentSplitWafer = FALSE;
        }
    }

    /*-------------------------------------------------*/
    /*   call APCMgr_SendControlJobInformationDR       */
    /*-------------------------------------------------*/
     PPT_METHODTRACE_V1("", " call APCMgr_SendControlJobInformationDR");
    objAPCMgr_SendControlJobInformationDR_out strAPCMgr_SendControlJobInformationDR_out;
    rc = APCMgr_SendControlJobInformationDR ( strAPCMgr_SendControlJobInformationDR_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              controlJobID,
                                              SP_APC_ControlJobStatus_Canceled,
                                              strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList );
//D7000182    if ( rc != RC_OK )
    if ( rc != RC_OK  && rc != RC_OK_NO_IF )    //D7000182
    {
        PPT_METHODTRACE_V1(""," APCMgr_SendControlJobInformationDR() rc != RC_OK");
        strStartLotsReservationCancelReqResult.strResult = strAPCMgr_SendControlJobInformationDR_out.strResult;
        return( rc );
    }

//D7000182 add start
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCControlJobInformation was sent normally.");
        CORBA::String_var tmpString = APCIFControlStatus;
        APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Created);
    }
//D7000182 add end
//D51M0000 add end

    /*--------------------------*/
    /*                          */
    /*   Set Return Structure   */
    /*                          */
    /*--------------------------*/
    strStartLotsReservationCancelReqResult.strStartCassette = strStartCassette;

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/
    SET_MSG_RC ( strStartLotsReservationCancelReqResult, MSG_OK, RC_OK );

    PPT_METHODTRACE_EXIT("PPTManager_i:: txStartLotsReservationCancelReq");
    return( RC_OK );
}
