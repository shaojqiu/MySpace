#ifndef lint
static char *sccsid =  "@(#) 1.10 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txReworkReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/20/07 19:56:12 [ 11/20/07 19:56:13 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txReworkReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txReworkReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2002/01/01 D4100021   Y.Nagamine     Initial Release
// 2002/01/21 D4100020   N.Maeda        Change oldCurrentPOS to oldCurrentPOData
// 2002/02/05 D4100036   S.Tokumasu     Add limitaion for flowbatch
// 2002/02/19 D4100021-1 Y.Nagamine     TRUE -> 0
// 2002/02/21 D4100021-2 Y.Nagamine     Add transction ID logic
// 2002/02/22 D4100021-3 Y.Nagamine     Add check logic for first operation or not
// 2002/02/28 D4100120   N.Minami       Future Action
// 2002/03/07 D4100021-4 T.Michii       Change & Add check logic
// 2002/03/12 D4100021-5 Y.Nagamine     Change message
// 2002/03/20 D4100021-6 T.Michii       Change logic 'Check first operation or not'
// 2002/03/25 D4100210   H.Adachi       Add InParameter CurrentRouteID & CurrentOperationNum For Check Condition
// 2002/07/29 D4200029   K.Kimura       Process Hold Control
// 2002/10/23 P4200263   K.Kido         Chg : Invalid message when lot has hold.
// 2002/11/13 P4200351   K.Matsuei      Add check return operation with Rework/Branch.
// 2003/01/16 P4200491   H.Adachi       Change Transaction ID for Operation History.
// 2003/06/03 P5000060   K.Matsuei      TxReworkReq and TxBranchReq could not work correctly when These are called from Script.
// 2003/09/09 P5000145   H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04   D6000025   K.Murakami     eBroker Migration.
// 2006/02/09 D7000173   H.Hasegawa     Add input parameter of process_OperationListForLot().
// 2006/04/25 D7000213   Y.Kadowaki     Add a check for transfer status of cassette.
// 2006/05/18 D7000092   Y.Kadowaki     Add object lock for cassette.
// 2007/08/03 D9000056   H.Hotta        Add check logic for InPostProcessFlag.
// 2007/09/20 D9000079   D.Tamura       FlowBatch Enhancement.
// 2007/11/05 D9000001   K.Matsuei      64bit support.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/30 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2010/03/19 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2011/10/20 DSN000015229 M.Ogawa        Advanced Wafer Level Control
// 2013/01/23 DSN000050720 M.Ogawa        Skip cassette lock in Post Process parallel execution
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/07/28 DSN000085792 Sa Guo         Q-Time Improvements.
// 2015/11/11 DSN000096135 XF.Ming        process_OperationListForLot ==> process_OperationListForLot__160.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txReworkReq
// 2017/09/12 INN-R170002  Thomas Song    Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptReworkReqResult& strReworkReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const pptReworkReq& strReworkReq
//     const char * claimMemo
//
//
//      typedef struct pptReworkReq_struct {
//          objectIdentifier    lotID;
//          objectIdentifier    subRouteID;
//          string              returnOperationNumber;
//          objectIdentifier    reasonCodeID;
//          string              eventTxId;
//          boolean             bForceRework;
//          boolean             bDynamicRoute;
//          any                 siInfo;
//      } pptReworkReq;
//
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
// For Route ID
// 1. Check Active Version Control or not.
// 2. If input route id is active version (XXXX.##) then convert normal route id.
// 3. Use converted route id after from here.
//
// For Return Opetaion Number
//
// 1. inputReturnOperationFlag            if exist TRUE
// 2. connectedRouteReturnOperationFlag   if exist TRUE
// 3. bDynamicRouteFlag
// 4. Check return operation is exist on the current route( from route ).
//
//

CORBA::Long CS_PPTManager_i::txReworkReq (pptReworkReqResult& strReworkReqResult,
                                       const pptObjCommonIn& strObjCommonIn,
                                       const pptReworkReq& strReworkReq,
//D6000025                                        const char * claimMemo,
//D6000025                                        CORBA::Environment &IT_env)
                                       const char * claimMemo //D6000025
                                       CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txReworkReq ") ;
    CORBA::Long rc = RC_OK ;

    PPT_METHODTRACE_V2("", "lotID                 : ", strReworkReq.lotID.identifier        ) ;
    PPT_METHODTRACE_V2("", "CurrentOperationNum   : ", strReworkReq.currentOperationNumber  ) ;        //D4100210
    PPT_METHODTRACE_V2("", "CurrentRouteID        : ", strReworkReq.currentRouteID.identifier   ) ;    //D4100210
    PPT_METHODTRACE_V2("", "subRouteID            : ", strReworkReq.subRouteID.identifier   ) ;
    PPT_METHODTRACE_V2("", "returnOperationNumber : ", strReworkReq.returnOperationNumber   ) ;
    PPT_METHODTRACE_V2("", "reasonCodeID          : ", strReworkReq.reasonCodeID.identifier ) ;
    PPT_METHODTRACE_V2("", "eventTxId             : ", strReworkReq.eventTxId               ) ;
    PPT_METHODTRACE_V2("", "bForceRework          : ", strReworkReq.bForceRework            ) ;
    PPT_METHODTRACE_V2("", "bDynamicRoute         : ", strReworkReq.bDynamicRoute           ) ;

//D4100021-2 add
    //--------------------------------
    //   Decide TX_ID
    //--------------------------------

    CORBA::String_var  txID;
    if ( CIMFWStrLen(strReworkReq.eventTxId) >0 )
    {
        txID = strReworkReq.eventTxId;
        PPT_METHODTRACE_V2("", "TX ID (Use Input TX ID )   : ", txID      ) ;
    }
    else
    {
        //Special Rework case
        if ( strReworkReq.bForceRework == TRUE )
        {
            if ( strReworkReq.bDynamicRoute == TRUE )
            {
                txID = CIMFWStrDup("TXEWC005");
                PPT_METHODTRACE_V2("", "TX ID (Special Dynamic Rework) : ", txID      ) ;
            }
            else
            {
                txID = CIMFWStrDup("TXTRC046");
                PPT_METHODTRACE_V2("", "TX ID (Special Rework) : ", txID      ) ;
            }
        }
        else
        {
        //Rework case
            if ( strReworkReq.bDynamicRoute == TRUE )
            {
                txID = CIMFWStrDup("TXEWC004");
                PPT_METHODTRACE_V2("", "TX ID ( Dynamic Rework) : ", txID      ) ;
            }
            else
            {
                txID = CIMFWStrDup("TXTRC026");
                PPT_METHODTRACE_V2("", "TX ID ( Rework ) : ", txID      ) ;
            }
        }
    }
//D4100021-2 end
    //-----------------------------------------------------------------------
    //   Get cassette / lot connection
    //-----------------------------------------------------------------------
    objLot_cassette_Get_out strLot_cassette_Get_out ;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, strReworkReq.lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK") ;
        strReworkReqResult.strResult = strLot_cassette_Get_out.strResult ;
        return(rc);
    }

//D7000213 add start
    objectIdentifier  aCassetteID = strLot_cassette_Get_out.cassetteID;

//D7000092 add start
    objObject_Lock_out  strObject_Lock_out;
//DSN000050720 Add Start
    // Get PostProcForLotFlag from thread specific data
    char* methodName = NULL;
    CORBA::String_var strParallelPostProcFlag;
    try
    {
        methodName = CIMFWStrDup("getThreadSpecificDataString");
        strParallelPostProcFlag = getThreadSpecificDataString(SP_ThreadSpecificData_Key_PostProcParallelFlag);
        CORBA::string_free(methodName);
        methodName = NULL;
    }
    CATCH_GLOBAL_EXCEPTIONS(strReworkReqResult, txReworkReq, methodName);

    PPT_METHODTRACE_V2("", "strParallelPostProcFlag", strParallelPostProcFlag);

    //----------------------------------------------------------//
    //   Skip cassette lock to increase parallel availability   //
    //   under PostProcess parallel execution                   //
    //----------------------------------------------------------//
    if ( 0 != CIMFWStrCmp(strParallelPostProcFlag, SP_PostProcess_ParallelExecution_ON) )
    {
        //PostProcess sequential execution
        PPT_METHODTRACE_V1("", "Lock cassette object.");
//DSN000050720 Add End
//DSN000050720 Indent Start
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, aCassetteID, SP_ClassName_PosCassette );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
            strReworkReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
//DSN000050720 Indent End
    }   //DSN000050720
//D7000092 add end

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1") ;
//DSN000071674 add end    
        //------------------------------------------------------------------------------------------------
        // TransferState should not be EI except when called from BRScript with OpeComp/OpeStartCancel.
        //------------------------------------------------------------------------------------------------
        if( CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004") != 0 &&  //TxOpeCompWithDataReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC055") != 0 &&  //TxOpeCompForInternalBufferReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC015") != 0 &&  //TxPartialOpeCompWithDataReq           //DSN000015229
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC016") != 0 &&  //TxPartialOpeCompForInternalBufferReq  //DSN000015229
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC010") != 0 &&  //TxForceOpeCompReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC011") != 0 &&  //TxForceOpeCompForInternalBufferReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC003") != 0 &&  //TxOpeStartCancelReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC061") != 0 )   //TxOpeStartCancelForInternalBufferReq
        {
            objCassette_transferState_Get_out  strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out, strObjCommonIn, aCassetteID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_transferState_Get() != RC_OK", rc);
                strReworkReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return( rc );
            }

            if( CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
            {
                PPT_METHODTRACE_V1("", "TransferState of cassette is EI");
                PPT_SET_MSG_RC_KEY2( strReworkReqResult,
                                     MSG_INVALID_CAST_XFERSTAT,
                                     RC_INVALID_CAST_XFERSTAT,
                                     SP_TransState_EquipmentIn,
                                     aCassetteID.identifier );
                return( RC_INVALID_CAST_XFERSTAT );
            }
        }
    } //DSN000071674
//D7000213 add end.

    //-------------------------------
    //   Lock objects to be updated
    //-------------------------------
//D7000092    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, strReworkReq.lotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock() rc != RC_OK" ) ;
        strReworkReqResult.strResult = strObject_Lock_out.strResult ;
        return( rc );
    }

    //D4100210 add start
    //--------------------------------------------------------------------------
    //   Check whether Lot is on the specified Route/Operation or Not
    //--------------------------------------------------------------------------
    PPT_METHODTRACE_V1("","Check whether Lot is on the specified Route/Operation or Not...");

    objectIdentifier  tmpCurrentRouteID         = strReworkReq.currentRouteID;
    CORBA::String_var tmpCurrentOperationNumber = CIMFWStrDup(strReworkReq.currentOperationNumber);
    objectIdentifier  aLotID = strReworkReq.lotID;

    if ((CIMFWStrLen(tmpCurrentRouteID.identifier) != 0)&&
        (CIMFWStrLen(tmpCurrentOperationNumber) != 0))
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Not Null. Begin to Check!!");

        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_currentOperationInfo_Get() != RC_OK");
            strReworkReqResult.strResult  = strLot_currentOperationInfo_Get_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2("","In-parm's routeID            :", tmpCurrentRouteID.identifier );
        PPT_METHODTRACE_V2("","In-Parm's operationNumber    :", tmpCurrentOperationNumber    );

        PPT_METHODTRACE_V2("","Lot's currentRouteID         :", strLot_currentOperationInfo_Get_out.routeID.identifier );
        PPT_METHODTRACE_V2("","Lot's currentOperationNumber :", strLot_currentOperationInfo_Get_out.operationNumber    );

        if ( CIMFWStrCmp(tmpCurrentRouteID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier) == 0 &&
             CIMFWStrCmp(tmpCurrentOperationNumber   , strLot_currentOperationInfo_Get_out.operationNumber   ) == 0 )
        {
            PPT_METHODTRACE_V1("","Route/Operation check OK. Go ahead...");
        }
        else
        {
            PPT_METHODTRACE_V1("","Route/Operation check NG.");
            PPT_SET_MSG_RC_KEY2(strReworkReqResult,
                                MSG_NOT_SAME_ROUTE,
                                RC_NOT_SAME_ROUTE,
                                "Input parameter's currentRouteID/currentOperationNumber",
                                "lot's current currentRouteID/currentOperationNumber");
            return( RC_NOT_SAME_ROUTE );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Null. No Check!!");
    }
    //D4100210 add end
    //-----------------------------------
    // Retrieve all state for tLot
    //-----------------------------------
    objLot_allState_Get_out strLot_allState_Get_out;
    rc = lot_allState_Get(strLot_allState_Get_out, strObjCommonIn, strReworkReq.lotID);
    if ( rc )
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() != RC_OK");
        strReworkReqResult.strResult = strLot_allState_Get_out.strResult;
        return(rc);
    }

    //-----------------------------------
    // Check lot condition
    //-----------------------------------
    if (CIMFWStrCmp(strLot_allState_Get_out.holdState, CIMFW_Lot_HoldState_OnHold) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.holdState == CIMFW_Lot_HoldState_OnHold");
//P4200263        SET_MSG_RC(strReworkReqResult,
//P4200263                   MSG_CANNOT_SPLIT_HELDLOT,
//P4200263                   RC_CANNOT_SPLIT_HELDLOT);
//P4200263        return( RC_CANNOT_SPLIT_HELDLOT );
//P4200263 add start
        PPT_SET_MSG_RC_KEY2( strReworkReqResult,
                             MSG_INVALID_LOT_HOLDSTAT,
                             RC_INVALID_LOT_HOLDSTAT,
                             strReworkReq.lotID.identifier,
                             strLot_allState_Get_out.holdState );
        return( RC_INVALID_LOT_HOLDSTAT );
//P4200263 add end
    }
    if (CIMFWStrCmp(strLot_allState_Get_out.lotState, CIMFW_Lot_State_Active) != 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.lotState != CIMFW_Lot_State_Active");
        PPT_SET_MSG_RC_KEY(strReworkReqResult,
                           MSG_INVALID_LOT_STAT,
                           RC_INVALID_LOT_STAT,
                           strLot_allState_Get_out.lotState);
        return( RC_INVALID_LOT_STAT );
    }
    if (CIMFWStrCmp(strLot_allState_Get_out.processState, SP_Lot_ProcState_Processing) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.processState == SP_Lot_ProcState_Processing");
        PPT_SET_MSG_RC_KEY2(strReworkReqResult,
                            MSG_INVALID_LOT_PROCSTAT,
                            RC_INVALID_LOT_PROCSTAT,
                            strReworkReq.lotID.identifier,
                            strLot_allState_Get_out.processState);
        return( RC_INVALID_LOT_PROCSTAT );
    }
    if (CIMFWStrCmp(strLot_allState_Get_out.productionState, CIMFW_Lot_ProductionState_InRework) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.productionState == CIMFW_Lot_ProductionState_InRework");
        PPT_SET_MSG_RC_KEY2(strReworkReqResult,
                            MSG_INVALID_LOT_PRODSTAT,
                            RC_INVALID_LOT_PRODSTAT,
                            strReworkReq.lotID.identifier,
                            strLot_allState_Get_out.productionState);
        return( RC_INVALID_LOT_PRODSTAT );
    }
    if (CIMFWStrCmp(strLot_allState_Get_out.inventoryState, SP_Lot_InventoryState_OnFloor) != 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.inventoryState != SP_Lot_InventoryState_OnFloor");
        PPT_SET_MSG_RC_KEY2(strReworkReqResult,
                            MSG_INVALID_LOT_INVENTORYSTAT,
                            RC_INVALID_LOT_INVENTORYSTAT,
                            strReworkReq.lotID.identifier,
                            strLot_allState_Get_out.inventoryState);
        return( RC_INVALID_LOT_INVENTORYSTAT );
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = strReworkReq.lotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strReworkReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strReworkReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strReworkReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                strReworkReq.lotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

//DSIV00000214 add start
    //---------------------------------------
    // Check interFabXferPlan existence
    //---------------------------------------
    objProcess_CheckInterFabXferPlanSkip_in strProcess_CheckInterFabXferPlanSkip_in;
    strProcess_CheckInterFabXferPlanSkip_in.lotID = strReworkReq.lotID;
    strProcess_CheckInterFabXferPlanSkip_in.currentRouteID = strReworkReq.currentRouteID;
    strProcess_CheckInterFabXferPlanSkip_in.currentOpeNo = strReworkReq.currentOperationNumber;
    strProcess_CheckInterFabXferPlanSkip_in.jumpingRouteID = strReworkReq.currentRouteID;;
    strProcess_CheckInterFabXferPlanSkip_in.jumpingOpeNo = strReworkReq.returnOperationNumber;

    objProcess_CheckInterFabXferPlanSkip_out strProcess_CheckInterFabXferPlanSkip_out;
    rc = process_CheckInterFabXferPlanSkip( strProcess_CheckInterFabXferPlanSkip_out,
                                            strObjCommonIn,
                                            strProcess_CheckInterFabXferPlanSkip_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_CheckInterFabXferPlanSkip() != RC_OK");
        strReworkReqResult.strResult = strProcess_CheckInterFabXferPlanSkip_out.strResult;
        return( rc );
    }
//DSIV00000214 add end

    //---------------------------------
    //   Check Lot's Control Job ID
    //---------------------------------
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, strReworkReq.lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strReworkReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strReworkReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             strReworkReq.lotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }


    //---------------------------------------------------------
    //   Converts input strReworkReq.subrouteID if it has the version ##
    //---------------------------------------------------------
    objectIdentifier aSubRouteID ;

    objProcess_activeID_Get_out strProcess_activeID_Get_out ;
    rc = process_activeID_Get(strProcess_activeID_Get_out, strObjCommonIn, strReworkReq.subRouteID);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_activeID_Get() != RC_OK") ;
        strReworkReqResult.strResult = strProcess_activeID_Get_out.strResult ;
        return(rc);
    }

    aSubRouteID = strProcess_activeID_Get_out.activeID;

    PPT_METHODTRACE_V2("", "active subRouteID = ", aSubRouteID.identifier) ;

//D4100021-4 Del start
    //-----------------------------------
    //   Check first operation or not
    //-----------------------------------
    PPT_METHODTRACE_V1("", "Check first operation or not") ;

    CORBA::Boolean searchDirection = FALSE ;
    CORBA::Boolean posSearchFlag   = TRUE ;
    CORBA::Long searchCount        = 2 ;      //D4100021-6
    objectIdentifier   searchRouteID_dummy;                                                                  //D7000173
    CORBA::String_var  searchOperationNumber_dummy;                                                          //D7000173
    CORBA::Boolean currentFlag     = TRUE ;  //D4100021-6
//D4100021-6    CORBA::Long searchCount        = 1 ;
//D4100021-6    CORBA::Boolean currentFlag     = FALSE ;

    searchRouteID_dummy.identifier = CIMFWStrDup( "" );                                                      //D7000173

//DSN000096135    objProcess_OperationListForLot_out strProcess_OperationListForLot_out ;
//DSN000096135    rc = process_OperationListForLot(   strProcess_OperationListForLot_out, strObjCommonIn,
//DSN000096135                                        searchDirection, posSearchFlag, searchCount, searchRouteID_dummy,    //D7000173
//DSN000096135                                        searchOperationNumber_dummy, currentFlag, strReworkReq.lotID );      //D7000173
//D7000173                                        searchDirection, posSearchFlag, searchCount, currentFlag, strReworkReq.lotID ) ;
//DSN000096135 add start
    objProcess_OperationListForLot_out__160 strProcess_OperationListForLot_out;
    objProcess_OperationListForLot_in__160 strProcess_OperationListForLot_in;
    strProcess_OperationListForLot_in.searchDirection           = searchDirection;
    strProcess_OperationListForLot_in.posSearchFlag             = posSearchFlag;
    strProcess_OperationListForLot_in.searchCount               = searchCount;
    strProcess_OperationListForLot_in.searchRouteID             = searchRouteID_dummy;
    strProcess_OperationListForLot_in.searchOperationNumber     = CIMFWStrDup(searchOperationNumber_dummy);
    strProcess_OperationListForLot_in.currentFlag               = currentFlag;
    strProcess_OperationListForLot_in.lotID                     = strReworkReq.lotID;
    rc = process_OperationListForLot__160(strProcess_OperationListForLot_out, strObjCommonIn, strProcess_OperationListForLot_in);
//DSN000096135 add end
    CORBA::Long lenNameAttributes = strProcess_OperationListForLot_out.strOperationNameAttributes.length();
//D4100021-6    if ( lenNameAttributes == 0 )
    if ( ( lenNameAttributes < 2 )                                                                                      //D4100021-6
      || ( lenNameAttributes >= 2                                                                                       //D4100021-6
        && 0 != CIMFWStrCmp( strProcess_OperationListForLot_out.strOperationNameAttributes[0].routeID.identifier,       //D4100021-6
                             strProcess_OperationListForLot_out.strOperationNameAttributes[1].routeID.identifier ) ) )  //D4100021-6
    {
        PPT_METHODTRACE_V2("", "lenNameAttributes == 0", lenNameAttributes );
        SET_MSG_RC( strReworkReqResult, MSG_INVALID_REWORK_OPERATION ,RC_INVALID_REWORK_OPERATION);
        return( RC_INVALID_REWORK_OPERATION );
    }
//D4100021-4 Del End

    //-----------------------------------
    //   Check Route is Dynamic or Not
    //-----------------------------------
    if ( strReworkReq.bDynamicRoute == TRUE )
    {
        objProcess_checkForDynamicRoute_out strProcess_checkForDynamicRoute_out;

        rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, aSubRouteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_checkForDynamicRoute() rc != RC_OK" ) ;
            strReworkReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult ;
            return( rc );
        }

        if ( strProcess_checkForDynamicRoute_out.bDynamicRoute == FALSE )
        {
            PPT_METHODTRACE_V1("", "strProcess_checkForDynamicRoute_out.bDynamicRoute != strReworkResultReq.bDynamicRoute" ) ;
            SET_MSG_RC( strReworkReqResult, MSG_NOT_DYNAMIC_ROUTE ,RC_NOT_DYNAMIC_ROUTE);    //D4100021-3
            return( RC_NOT_DYNAMIC_ROUTE );                                                  //D4100021-3
        }

//D4100021-4 Del start
//D4100021-3 start
//      CORBA::Boolean searchDirection = FALSE ;
//      CORBA::Boolean posSearchFlag   = TRUE ;
//      CORBA::Long searchCount        = 1 ;
//      CORBA::Boolean currentFlag     = FALSE ;
//
//      objProcess_OperationListForLot_out strProcess_OperationListForLot_out ;
//        rc = process_OperationListForLot(   strProcess_OperationListForLot_out, strObjCommonIn,
//                                            searchDirection, posSearchFlag, searchCount, currentFlag, strReworkReq.lotID ) ;
//
//      CORBA::Long lenNameAttributes = strProcess_OperationListForLot_out.strOperationNameAttributes.length();
//      if ( lenNameAttributes == 0 )
//      {
//          PPT_METHODTRACE_V2("", "lenNameAttributes == 0", lenNameAttributes );
//          SET_MSG_RC( strReworkReqResult, MSG_INVALID_REWORK_OPERATION ,RC_INVALID_REWORK_OPERATION);
//          return( RC_INVALID_REWORK_OPERATION );
//      }
//D4100021-3 end
//D4100021-4 Del End
    }

    //--------------------------------------
    //   Check Input return operation number
    //--------------------------------------
    CORBA::Boolean inputReturnOperationFlag = FALSE;
    CORBA::String_var returnOperationNumberVar;

    if( ( strReworkReq.returnOperationNumber != NULL ) && ( CIMFWStrLen(strReworkReq.returnOperationNumber)!=0 ) )
    {
        PPT_METHODTRACE_V1("", "Set inputReturnOperationFlag = TRUE" ) ;
        inputReturnOperationFlag = TRUE ;
    }

    //------------------------------------------------------------------------
    //   Check Input return operation number is exist in connected route list
    //------------------------------------------------------------------------
    CORBA::Boolean connectedRouteReturnOperationFlag = FALSE;
    CORBA::Boolean sameReturnOperationExistFlag = FALSE;

//P4200351 start
    objProcess_checkForDynamicRoute_out strProcess_checkForDynamicRoute_out;
    rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, aSubRouteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txReworkReq", "process_checkForDynamicRoute() != RC_OK", rc);
        strReworkReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult;
        return(rc);
    }
//D9000001    PPT_METHODTRACE_V2("CS_PPTManager_i:: txReworkReq", "bDynamicRoute", (long)strProcess_checkForDynamicRoute_out.bDynamicRoute);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txReworkReq", "bDynamicRoute", (CORBA::Long)strProcess_checkForDynamicRoute_out.bDynamicRoute); //D9000001
//P4200351 end

    objProcess_GetReturnOperation_out strProcess_GetReturnOperation_out;
    rc = process_GetReturnOperation( strProcess_GetReturnOperation_out, strObjCommonIn, strReworkReq.lotID, aSubRouteID );

    if (rc == RC_NOT_FOUND_SUBROUTE )
    {
        PPT_METHODTRACE_V1("", "process_GetReturnOperation() == RC_NOT_FOUND_SUBROUTE") ;
    }
    else if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "Set connectedRouteReturnOperationFlag = TRUE") ;
        connectedRouteReturnOperationFlag = TRUE;

//D4100021-1        if ( CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, strReworkReq.returnOperationNumber) == TRUE  )
        if ( CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, strReworkReq.returnOperationNumber) == 0  )    //D4100021-1
        {
            PPT_METHODTRACE_V1("", "Set sameReturnOperationExistFlag = TRUE") ;
            sameReturnOperationExistFlag = TRUE;
        }
//P4200351 start
//P5000060        else if ( TRUE != strProcess_checkForDynamicRoute_out.bDynamicRoute )
        else if ( TRUE != strProcess_checkForDynamicRoute_out.bDynamicRoute && 0 < CIMFWStrLen(strReworkReq.returnOperationNumber) ) //P5000060
        {
            PPT_METHODTRACE_V1("","return RC_INVALID_INPUT_PARM");
            SET_MSG_RC( strReworkReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }
//P4200351 end
    }
    else   // Error case
    {
        PPT_METHODTRACE_V2("", "process_GetReturnOperation() != RC_OK : ", rc) ;
        strReworkReqResult.strResult = strProcess_GetReturnOperation_out.strResult ;
        return(rc);
    }

    //----------------------------------------------
    // Get Currrent Route ID and Operation Number
    //----------------------------------------------
    objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, strReworkReq.lotID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK : ", rc) ;
        strReworkReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
        return( rc );
    }
    PPT_METHODTRACE_V2("","currentRouteID         : ", strLot_currentOperationInfo_Get_out.routeID.identifier ) ;
    PPT_METHODTRACE_V2("","currentOperationNumber : ", strLot_currentOperationInfo_Get_out.operationNumber) ;

    //-------------------------------------------------
    // Decide return operation number using all flags
    //-------------------------------------------------
    if ( strReworkReq.bDynamicRoute == TRUE )
    {
        PPT_METHODTRACE_V1("", "strReworkReq.bDynamicRoute == TRUE") ;
        if ( inputReturnOperationFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "inputReturnOperationFlag == TRUE") ;
            returnOperationNumberVar = strReworkReq.returnOperationNumber;
        }
        else  // inputReturnOperationFlag == FALSE
        {
            PPT_METHODTRACE_V1("", "inputReturnOperationFlag == FALSE") ;
            if ( connectedRouteReturnOperationFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;
            }
            else
            {
                PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strLot_currentOperationInfo_Get_out.operationNumber;
            }
        }
    }
    else  // strReworkReq.bDynamicRoute == FALSE
    {
        PPT_METHODTRACE_V1("", "strReworkReq.bDynamicRoute == FALSE") ;
//D4100021-4 Add Start
        if ( connectedRouteReturnOperationFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;

            if ( inputReturnOperationFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "inputReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strReworkReq.returnOperationNumber;
            }
            else
            {
                PPT_METHODTRACE_V1("", "inputReturnOperationFlag ==FALSE" ) ;
                returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag ==FALSE" ) ;
//D4100021-5            SET_MSG_RC( strReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//D4100021-5            return( RC_INVALID_BRANCH_ROUTEID );
            SET_MSG_RC( strReworkReqResult, MSG_INVALID_ROUTE_ID,RC_INVALID_ROUTE_ID);
            return( RC_INVALID_ROUTE_ID );
        }
    }

    //----------------------------------------------------
    //   Check ProcessDefinitionType is 'REWORK' or not
    //----------------------------------------------------
    PPT_METHODTRACE_V1("", "Check ProcessDefinitionType is 'REWORK' or not") ;

    if( CIMFWStrCmp( strProcess_GetReturnOperation_out.processDefinitionType, SP_MAINPDTYPE_REWORK ) != 0 )
    {
        PPT_METHODTRACE_V1("", "processDefinitionType != SP_MAINPDTYPE_REWORK") ;
//D4100021-5        SET_MSG_RC( strReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//D4100021-5        return( RC_INVALID_BRANCH_ROUTEID );
        SET_MSG_RC( strReworkReqResult, MSG_INVALID_ROUTE_TYPE,RC_INVALID_ROUTE_TYPE);
        return( RC_INVALID_ROUTE_TYPE );
    }

    //-----------------------------------------------------------
    //   Check decided return operation is exist on current route
    //-----------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check decided return operation is exist on current route") ;

    pptRouteOperationListForLotInqResult strRouteOperationListForLotInqResult;
    rc = txRouteOperationListForLotInq( strRouteOperationListForLotInqResult,
                                        strObjCommonIn,
                                        strReworkReq.lotID);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txRouteOperationListForLotInq() != RC_OK" ) ;
        strReworkReqResult.strResult = strRouteOperationListForLotInqResult.strResult ;
        return(rc);
    }

    PPT_METHODTRACE_V2("","returnOperationNumberVar : ", returnOperationNumberVar ) ;

    CORBA::Long opeLen = strRouteOperationListForLotInqResult.strOperationNameAttributes.length();

    for (CORBA::Long opeCnt=0; opeCnt < opeLen; opeCnt++ )
    {
        PPT_METHODTRACE_V2("","opeCnt : ", opeCnt ) ;
        PPT_METHODTRACE_V2("","strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber : ", strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber ) ;

        if( CIMFWStrCmp( strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber,
                         returnOperationNumberVar ) == 0 )
        {
            PPT_METHODTRACE_V1("", "return operation is exist on current route") ;
            break;
        }
        else if ( opeCnt == opeLen - 1 )
        {

            PPT_METHODTRACE_V1("", "opeCnt == opeLen - 1") ;
            PPT_SET_MSG_RC_KEY(strReworkReqResult, MSG_NOT_FOUND_OPERATION, RC_NOT_FOUND_OPERATION, returnOperationNumberVar);
            return( RC_NOT_FOUND_OPERATION );
        }
    }
//D4100021-4 Add End
//D4100021-4 Del Start
//      if ( inputReturnOperationFlag ==TRUE )                                                                     //D4100021-3
//      {
//            PPT_METHODTRACE_V1("", "inputReturnOperationFlag ==TRUE") ;                  //D4100021-3
//          returnOperationNumberVar = strReworkReq.returnOperationNumber;                                         //D4100021-3
//      }
//      else
//      {
//          if ( connectedRouteReturnOperationFlag == TRUE )
//          {
//                  PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;
//                returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;
//          }
//          else
//          {
//              PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag ==FALSE" ) ;
//              SET_MSG_RC( strReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//              return( RC_INVALID_BRANCH_ROUTEID );
//          }
//      }
//  }
//
//  //-----------------------------------------------------------
//  //   Check decided return operation is exist on current route
//  //-----------------------------------------------------------
//  CORBA::Long searchCount = 1 ;
//  objProcess_operationListForRoute_out strProcess_operationListForRoute_out;
//  rc = process_operationListForRoute( strProcess_operationListForRoute_out,
//                                      strObjCommonIn,
//                                      strLot_currentOperationInfo_Get_out.routeID,
//                                      returnOperationNumberVar,
//                                      searchCount );
//  if( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1("", "process_operationListForRoute() != RC_OK" ) ;
//      strReworkReqResult.strResult = strProcess_operationListForRoute_out.strResult ;
//      return(rc);
//  }
//D4100021-4 Del End

    // -----------------------------------------------------------
    // Check routeID confliction
    //   return RC_INVALID_BRANCH_ROUTEID,
    //   when the same routeID is used in the following case
    //       ex) Subroute --> The same SubRoute in the course
    // -----------------------------------------------------------
    PPT_METHODTRACE_V1("", "lot_originalRouteList_Get IN ");

    objLot_originalRouteList_Get_out  strLot_originalRouteList_Get_out;
    rc = lot_originalRouteList_Get( strLot_originalRouteList_Get_out, strObjCommonIn, strReworkReq.lotID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_originalRouteList_Get() != RC_OK", rc);
        strReworkReqResult.strResult = strLot_originalRouteList_Get_out.strResult ;
        return( rc );
    }

    CORBA::Long kLen = strLot_originalRouteList_Get_out.originalRouteID.length();
    PPT_METHODTRACE_V2("", "strLot_originalRouteList_Get_out.originalRouteID.length=", kLen);

    //Check CurrentRoute VS SubRoute
    if(CIMFWStrCmp(strLot_currentOperationInfo_Get_out.routeID.identifier, aSubRouteID.identifier ) == 0)
    {
        PPT_METHODTRACE_V2("", "currentRouteID = subRouteID len =: ", kLen);
        SET_MSG_RC( strReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
        return( RC_INVALID_BRANCH_ROUTEID );
    }

    //Check Return Route ID VS SubRoute
    for(CORBA::Long iLoop = 0;iLoop < kLen ;iLoop++)
    {
        PPT_METHODTRACE_V2("", "strLot_originalRouteList_Get_out.originalRouteID = ", strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier);

        if(CIMFWStrCmp(strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier, aSubRouteID.identifier ) == 0)
        {
            PPT_METHODTRACE_V2("", "iLoop                             = ", iLoop);
            PPT_METHODTRACE_V2("", "OriginalRouteID[iLoop].identifier = ", strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier );
            SET_MSG_RC( strReworkReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
            return( RC_INVALID_BRANCH_ROUTEID );
        }
    }

    //---------------------------------
    //   Check Max Rework Count
    //---------------------------------
    if ( strReworkReq.bForceRework == FALSE )
    {
        objProcess_reworkCount_Check_out strProcess_reworkCount_Check_out ;
        rc = process_reworkCount_Check( strProcess_reworkCount_Check_out, strObjCommonIn,  strReworkReq.lotID ) ;
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "process_reworkCount_Check() != RC_OK") ;
            strReworkReqResult.strResult = strProcess_reworkCount_Check_out.strResult ;
            return(rc);
        }
    }

    //---------------------------------
    //   Check Future Hold
    //---------------------------------

    objLot_futureHoldRequests_CheckBranch_out strLot_futureHoldRequests_CheckBranch_out ;
    rc = lot_futureHoldRequests_CheckBranch(strLot_futureHoldRequests_CheckBranch_out,
                                            strObjCommonIn, strReworkReq.lotID,
                                            returnOperationNumberVar) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_CheckBranch() != RC_OK") ;
        strReworkReqResult.strResult = strLot_futureHoldRequests_CheckBranch_out.strResult ;
        return(rc);
    }

//D4100120 Add Start
    /*-----------------------------------*/
    /*   Check Future Action Procedure   */
    /*-----------------------------------*/
    PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForFutureOperation");
    CORBA::String_var tmpRouteID = strLot_currentOperationInfo_Get_out.routeID.identifier;
    PPT_METHODTRACE_V2("","tmpRouteID",tmpRouteID);
    PPT_METHODTRACE_V2("","operationNumber",returnOperationNumberVar) ;

    objSchdlChangeReservation_CheckForFutureOperation_out strSchdlChangeReservation_CheckForFutureOperation_out;
    rc = schdlChangeReservation_CheckForFutureOperation(strSchdlChangeReservation_CheckForFutureOperation_out,
                                                        strObjCommonIn,
                                                        strReworkReq.lotID,
                                                        tmpRouteID,
                                                        returnOperationNumberVar);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForFutureOperation() != RC_OK") ;
        strReworkReqResult.strResult = strSchdlChangeReservation_CheckForFutureOperation_out.strResult;
        return(rc);
    }
//D4100120 Add End
//D9000079 add start
    //--------------------------------------------------------------------------------------------------
    // Check Flow Batch Condition.
    //
    // FlowBatched Lot :
    //   Can NOT Branch on a Branch Route which returns outside the flow batch section.
    //   Can NOT Branch on a Branch Route which returns to the operation beyond a target process.
    // Not FlowBatched Lot :
    //   Can NOT Branch on a Branch Route which returns to the flow batch section.
    //--------------------------------------------------------------------------------------------------
    objLot_CheckFlowBatchConditionForRework_out strLot_CheckFlowBatchConditionForRework_out;
    objLot_CheckFlowBatchConditionForRework_in  strLot_CheckFlowBatchConditionForRework_in;
    strLot_CheckFlowBatchConditionForRework_in.strReworkReq = strReworkReq;

        /* ------------------------------------------ */
        /*  Check input parameters are empty or not.  */
        /* ------------------------------------------ */
    if ( 0 == CIMFWStrLen( strReworkReq.currentRouteID.identifier ))
    {
        PPT_METHODTRACE_V1("", "strReworkReq.currentRouteID is empty.") ;
        strLot_CheckFlowBatchConditionForRework_in.strReworkReq.currentRouteID = strLot_currentOperationInfo_Get_out.routeID ;
    }
    if ( 0 == CIMFWStrLen( strReworkReq.currentOperationNumber ))
    {
        PPT_METHODTRACE_V1("", "strReworkReq.currentOperationNumber is empty.") ;
        strLot_CheckFlowBatchConditionForRework_in.strReworkReq.currentOperationNumber = strLot_currentOperationInfo_Get_out.operationNumber ;
    }
    if ( 0 == CIMFWStrLen( strReworkReq.returnOperationNumber ))
    {
        PPT_METHODTRACE_V1("", "strReworkReq.returnOperationNumber is empty.") ;
        strLot_CheckFlowBatchConditionForRework_in.strReworkReq.returnOperationNumber = strProcess_GetReturnOperation_out.operationNumber ;
    }

    rc = lot_CheckFlowBatchConditionForRework( strLot_CheckFlowBatchConditionForRework_out,
                                               strObjCommonIn,
                                               strLot_CheckFlowBatchConditionForRework_in);

    if ( rc == RC_NOT_LOCATETO_BATCHOPE || rc == RC_LOT_REMOVE_FROM_BATCH || rc == RC_NOT_LOCATETO_OVERTARGET )
    {
        PPT_METHODTRACE_V2("", "lot_flowBatch_CheckLocate() != RC_OK", rc) ;
        ostrstream  errorMsg;
        if ( rc == RC_NOT_LOCATETO_BATCHOPE )
        {
            errorMsg << "Return point of the rework operation is in a FlowBatch Section.";
        }
        else if ( rc == RC_LOT_REMOVE_FROM_BATCH )
        {
            errorMsg << "FlowBatched lots cannot go out of the FlowBatch Section.";
        }
        else if ( rc == RC_NOT_LOCATETO_OVERTARGET )
        {
            errorMsg << "FlowBatched lots cannot step over the target operation in the FlowBatch Section. ";
        }
        errorMsg << ends;

        PPT_METHODTRACE_V2( "", "ErrorMsg ->", errorMsg.str()) ;
        PPT_SET_MSG_RC_KEY( strLot_CheckFlowBatchConditionForRework_out, MSG_NOT_REWORK_BATCHOPE, RC_NOT_REWORK_BATCHOPE, errorMsg.str());
        strReworkReqResult.strResult = strLot_CheckFlowBatchConditionForRework_out.strResult ;
        errorMsg.rdbuf()->freeze(0);
        return RC_NOT_REWORK_BATCHOPE ;
    }
    else if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_CheckFlowBatchConditionForRework() != RC_OK") ;
        strReworkReqResult.strResult = strLot_CheckFlowBatchConditionForRework_out.strResult ;
        return(rc);
    }
//D9000079 add end

//DSIV00001830 add start
    //--------------------------------------------------------------------------------------------------
    // Check Bonding Flow Condition.
    //--------------------------------------------------------------------------------------------------
    objLot_CheckBondingFlowSectionForRework_out strLot_CheckBondingFlowSectionForRework_out;
    objLot_CheckBondingFlowSectionForRework_in  strLot_CheckBondingFlowSectionForRework_in;
    strLot_CheckBondingFlowSectionForRework_in.strReworkReq = strReworkReq;

    /* ------------------------------------------ */
    /*  Check input parameters are empty or not.  */
    /* ------------------------------------------ */
    if( 0 == CIMFWStrLen(strReworkReq.currentRouteID.identifier) )
    {
        PPT_METHODTRACE_V1("", "strReworkReq.currentRouteID is empty.");
        strLot_CheckBondingFlowSectionForRework_in.strReworkReq.currentRouteID = strLot_currentOperationInfo_Get_out.routeID ;
    }
    if( 0 == CIMFWStrLen(strReworkReq.currentOperationNumber) )
    {
        PPT_METHODTRACE_V1("", "strReworkReq.currentOperationNumber is empty.");
        strLot_CheckBondingFlowSectionForRework_in.strReworkReq.currentOperationNumber = CIMFWStrDup(strLot_currentOperationInfo_Get_out.operationNumber);
    }
    if( 0 == CIMFWStrLen(strReworkReq.returnOperationNumber) )
    {
        PPT_METHODTRACE_V1("", "strReworkReq.returnOperationNumber is empty.");
        strLot_CheckBondingFlowSectionForRework_in.strReworkReq.returnOperationNumber = CIMFWStrDup(strProcess_GetReturnOperation_out.operationNumber);
    }

    rc = lot_CheckBondingFlowSectionForRework(strLot_CheckBondingFlowSectionForRework_out, strObjCommonIn, strLot_CheckBondingFlowSectionForRework_in);
    if( rc == RC_NOT_LOCATETO_BONDINGFLOWSECTION )
    {
        PPT_METHODTRACE_V2("", "lot_flowBatch_CheckLocate() != RC_OK", rc);
        ostrstream  errorMsg;
        errorMsg << "Return point of the rework operation is in a bonding flow Section.";
        errorMsg << ends;

        PPT_METHODTRACE_V2( "", "ErrorMsg ->", errorMsg.str());
        PPT_SET_MSG_RC_KEY( strLot_CheckBondingFlowSectionForRework_out, MSG_NOT_REWORK_BONDINGFLOW, RC_NOT_REWORK_BONDINGFLOW, errorMsg.str());
        strReworkReqResult.strResult = strLot_CheckBondingFlowSectionForRework_out.strResult;
        errorMsg.rdbuf()->freeze(0);
        return RC_NOT_REWORK_BONDINGFLOW;
    }
    else if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_CheckBondingFlowSectionForRework() != RC_OK");
        strReworkReqResult.strResult = strLot_CheckBondingFlowSectionForRework_out.strResult;
        return rc;
    }
//DSIV00001830 add end

    //-----------------------------------------------------------------------
    //   Change State
    //-----------------------------------------------------------------------
    objProcess_reworkCount_Increment_out strProcess_reworkCount_Increment_out ;
    rc = process_reworkCount_Increment(strProcess_reworkCount_Increment_out, strObjCommonIn,  strReworkReq.lotID) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_reworkCount_Increment() != RC_OK") ;
        strReworkReqResult.strResult = strProcess_reworkCount_Increment_out.strResult ;
        return(rc);
    }
//DSN000085792 Add start
    objQTime_CheckConditionForReplaceTarget_in strQTime_CheckConditionForReplaceTarget_in;
    objQTime_CheckConditionForReplaceTarget_out strQTime_CheckConditionForReplaceTarget_out;
    strQTime_CheckConditionForReplaceTarget_in.lotID = strReworkReq.lotID;
    rc = qTime_CheckConditionForReplaceTarget(strQTime_CheckConditionForReplaceTarget_out,strObjCommonIn,strQTime_CheckConditionForReplaceTarget_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "qTime_CheckConditionForReplaceTarget() != RC_OK") ;
        strReworkReqResult.strResult = strQTime_CheckConditionForReplaceTarget_out.strResult ;
        return rc ;
    }
//DSN000085792 Add end
    objProcess_BranchRoute_out strProcess_BranchRoute_out ;
    rc = process_BranchRoute( strProcess_BranchRoute_out, strObjCommonIn, strReworkReq.lotID, aSubRouteID, returnOperationNumberVar ) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_BranchRoute() != RC_OK") ;
        strReworkReqResult.strResult = strProcess_BranchRoute_out.strResult ;
        return(rc);
    }

//D9000079    //------------------------------
//D9000079    //   Remove Lot from FlowBatch
//D9000079    //------------------------------
//D9000079    objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
//D9000079    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, strReworkReq.lotID );
//D9000079
//D9000079    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
//D9000079    {
//D9000079       PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//D9000079       //D4100036 Start
//D9000079//P5000145       PPT_SET_MSG_RC_KEY( strReworkReqResult,
//D9000079//P5000145                           MSG_FLOW_BATCH_LIMITATION,
//D9000079//P5000145                           RC_FLOW_BATCH_LIMITATION,
//D9000079//P5000145                           "");
//D9000079       SET_MSG_RC( strReworkReqResult,                 //P5000145
//D9000079                   MSG_FLOW_BATCH_LIMITATION,          //P5000145
//D9000079                   RC_FLOW_BATCH_LIMITATION );         //P5000145
//D9000079
//D9000079       return RC_FLOW_BATCH_LIMITATION;
//D9000079       //D4100036 End
//D9000079//D4100036       pptLotRemoveFromFlowBatchReqResult strLotRemoveFromFlowBatchReqResult ;
//D9000079//D4100036       pptRemoveCassetteSequence strRemoveCassette;
//D9000079//D4100036       strRemoveCassette.length(1);
//D9000079//D4100036       strRemoveCassette[0].lotID.length(1);
//D9000079//D4100036       strRemoveCassette[0].lotID[0]   = strReworkReq.lotID;
//D9000079//D4100036       strRemoveCassette[0].cassetteID = strLot_cassette_Get_out.cassetteID;
//D9000079//D4100036
//D9000079//D4100036       rc = txLotRemoveFromFlowBatchReq( strLotRemoveFromFlowBatchReqResult,
//D9000079//D4100036                                     strObjCommonIn,
//D9000079//D4100036                                     strLot_flowBatchID_Get_out.flowBatchID,
//D9000079//D4100036                                     strRemoveCassette,
//D9000079//D4100036                                     claimMemo ) ;
//D9000079//D4100036       if (rc != RC_OK)
//D9000079//D4100036       {
//D9000079//D4100036           PPT_METHODTRACE_V1("", "txLotRemoveFromFlowBatchReq() != RC_OK") ;
//D9000079//D4100036           strReworkReqResult.strResult = strLotRemoveFromFlowBatchReqResult.strResult ;
//D9000079//D4100036           return( rc );
//D9000079//D4100036       }
//D9000079    }
//D9000079    else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
//D9000079    {
//D9000079        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//D9000079    }
//D9000079    else
//D9000079    {
//D9000079        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
//D9000079        strReworkReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
//D9000079        return( rc );
//D9000079    }

    //--------------------------------------
    //   Update Cassette's MultiLotType
    //--------------------------------------
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out,
                                      strObjCommonIn,
                                      strLot_cassette_Get_out.cassetteID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
        strReworkReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
        return(rc);
    }

    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             strReworkReq.lotID );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strReworkReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }

//D4200029 Add Start

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = strReworkReq.lotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = strLot_cassette_Get_out.cassetteID;
    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strReworkReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        pptHoldLotReqResult strHoldLotReqResult;
        pptHoldListSequence strLotHoldReqList( 1 );
        strLotHoldReqList.length( 1 );

        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = claimMemo;

        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           strReworkReq.lotID,
                           strLotHoldReqList );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strReworkReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End

    //-----------------------//
    //     Process Hold      //
    //-----------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                               strObjCommonIn,
                               strReworkReq.lotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
        strReworkReqResult.strResult = strProcessHoldExecReqResult.strResult ;
        return( rc );
    }

//D4200029 Add End

//DSN000085792 Add Start
    //--------------------------------------------------------------------------------------------------
    // Replace Target Operation for rework route
    //--------------------------------------------------------------------------------------------------
    objQTime_targetOpe_Replace_out strQTime_targetOpe_Replace_out;
    objQTime_targetOpe_Replace_in  strQTime_targetOpe_Replace_in;
    strQTime_targetOpe_Replace_in.lotID               = strReworkReq.lotID;
    strQTime_targetOpe_Replace_in.specificControlFlag = FALSE;
    rc = qTime_targetOpe_Replace( strQTime_targetOpe_Replace_out,
                                  strObjCommonIn,
                                  strQTime_targetOpe_Replace_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "qTime_targetOpe_Replace() != RC_OK", rc);
        strReworkReqResult.strResult = strQTime_targetOpe_Replace_out.strResult;
        return rc;
    }
//DSN000085792 Add End

    //-----------------------------------------------------------------------
    //   Make History
    //-----------------------------------------------------------------------
    objLotReworkEvent_Make_out  strLotReworkEvent_Make_out;
    rc = lotReworkEvent_Make(strLotReworkEvent_Make_out,
                             strObjCommonIn,
//                             "TXTRC026",
//P4200491                             txID,                                                                       //D4100021-2
                             "TXEWC004",                                                                 //P4200491
                             strReworkReq.lotID,
                             strReworkReq.reasonCodeID,
//                           strProcess_BranchRoute_out.oldCurrentPOS,                                   //D4100020 Delete
                             strProcess_BranchRoute_out.oldCurrentPOData,
                             claimMemo);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lotReworkEvent_Make() != RC_OK") ;
        strReworkReqResult.strResult = strLotReworkEvent_Make_out.strResult ;
//P5000145        PPT_SET_MSG_RC_KEY(strReworkReqResult, MSG_FAIL_MAKE_HISTORY, rc, strReworkReq.lotID.identifier) ;
        SET_MSG_RC( strReworkReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    //-----------------------------------------------------------------------
    //   Return
    //-----------------------------------------------------------------------
    SET_MSG_RC(strReworkReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txReworkReq ") ;
    return RC_OK ;
}
