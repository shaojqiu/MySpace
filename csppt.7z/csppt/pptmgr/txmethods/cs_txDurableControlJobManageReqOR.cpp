//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: cs_txDurableControlJobManageReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txDurableControlJobManageReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2014/12/04 DSN000085770 C.Mo           Initial Release (R151)
//
// Innotron change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Support durable on route for internal buffer
//
// Description:
//  This function changes the specified Durable Control Job's Status.
//  When this function is claimed with "create" or "delete",
//  this function create a Durable Control Job /delete the specified Durable Control Job.
//
//  Return Code from txDurableControlJobManageReq
//  Return Code                               Messsage ID
//  ----------------------------------------- ------------------------------------------------
//  RC_OK                                     MSG_OK
//  RC_NOT_FOUND_DCTRLJOB                     MSG_NOT_FOUND_DCTRLJOB
//  RC_CALLED_FROM_INVALID_TRANSACTION        MSG_CALLED_FROM_INVALID_TRANSACTION
//  RC_INVALID_CONTROLJOBACTION_TYPE          MSG_INVALID_CONTROLJOBACTION_TYPE
//  RC_INVALID_DCTRLJOBACTION_FOR_DCJSTATUS   MSG_INVALID_DCTRLJOBACTION_FOR_DCJSTATUS
//  RC_INVALID_EQP_MODE                       MSG_INVALID_EQP_MODE
//
// Parameter:
//     pptDurableControlJobManageReqResult        & strDurableControlJobManageReqResult
//     const pptObjCommonIn                       & strObjCommonIn
//     const pptDurableControlJobManageReqInParam & strDurableControlJobManageReqInParam
//     const char                                 * claimMemo
//
// Environmental Variables:
//     export SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK=00000
//     11111   bitmask  1:create history  0:no history
//     -----------------------------
//     |||||
//     ||||+---- Deleted	(4)
//     |||+----- Completed	(3)
//     ||+------ Executing	(2)
//     |+------- Queued		(1)
//     +-------- Created	(0)
//
//     This SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK is used to define which CJ status to be logged as History.
//     History tables are [FHDRBLOPEHS],[FHDRBLOPEHS_RPARM].[FHDCJSCHS],[FHDCJSCHS_DRBL]
//     Corresponding Event tables are [FREVDRBLPFX],[FREVDCJSC],[FREVDCJSC_DRBLS],[FREVDRBLOPST],[FREVDRBLOPST_RPARM],[FREVDRBLOPCP],[FREVDRBLOPCP_RPARM].
//
// Pseudo code:
//     1. Check Environmental Variable (SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK) is set as specification.
//     2. Check claimed DCJ Action.
//        At the same time, set 2 flags(whether to make Event, whether to check current CJ status).
//        CORBA::Boolean   bNeedtoMakeEvent = FALSE;
//        CORBA::Boolean   bNeedtoCheckCJStatus = FALSE;
//        +------------------------------------------------------------------+
//        | Claimed CJ  | EventMake | CJ Status check      | Call TCS method |
//        | Action      |           | Status should be...  |                 |
//        | -----------------------------------------------------------------|
//        | CJ create   | Depend on | N/A                  | No              |
//        | CJ queue    | Depend on | Not needed           | No              |
//        | CJ execute  | Depend on | Not needed           | No              |
//        | CJ complete | Depend on | Not needed           | No              |
//        | CJ delete   | Depend on | Not needed           | No              |
//        | CJ abort    | Necessary | "Queued"/"Executing" | Yes             |
//        | CJ stop     | Necessary | "Queued"/"Executing" | Yes             |
//        +------------------------------------------------------------------+
//                  * "Depend on" the SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK
//     3. If current CJ Status check is needed, get current CJ status and check it.
//        If the result of "CJ Status check" is OK, call TCS method.
//     4. Change CJ status
//     5. Create event if EventMake is needed.
//
CORBA::Long CS_PPTManager_i::txDurableControlJobManageReq (
    pptDurableControlJobManageReqResult&         strDurableControlJobManageReqResult,
    const pptObjCommonIn&                        strObjCommonIn,
    const pptDurableControlJobManageReqInParam&  strDurableControlJobManageReqInParam,
    const char *                                 claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txDurableControlJobManageReq");
    CORBA::Long rc = RC_OK;
    CORBA::ULong i = 0;

    const char* durableCategory = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.durableCategory;
    if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
        PPT_SET_MSG_RC_KEY( strDurableControlJobManageReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            durableCategory );
        return RC_INVALID_DURABLE_CATEGORY ;
    }

    //---------------------------------------
    // Check Durable ControlJob ID
    //---------------------------------------
    if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_create) != 0 )
    {
        if( CIMFWStrLen(strDurableControlJobManageReqInParam.durableControlJobID.identifier) == 0 )
        {
            PPT_METHODTRACE_V1("", "Request of DurableControlJobID is null");
            SET_MSG_RC(strDurableControlJobManageReqResult, MSG_NOT_FOUND_DCTRLJOB, RC_NOT_FOUND_DCTRLJOB);
            return( RC_NOT_FOUND_DCTRLJOB );
        }

        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock(strObject_Lock_out, strObjCommonIn, strDurableControlJobManageReqInParam.durableControlJobID, SP_ClassName_PosDurableControlJob);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strDurableControlJobManageReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }

    //---------------------------------------
    // Lock durable objects for update.
    //---------------------------------------
    CORBA::ULong durableLen = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.strStartDurables.length();
    PPT_METHODTRACE_V2("", "strDurableControlJobCreateRequest.strStartDurables.length()", durableLen);

    objectIdentifierSequence durableIDs;
    durableIDs.length(durableLen);
    for ( i = 0; i < durableLen; i++ )
    {
        durableIDs[i] = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.strStartDurables[i].durableID;
    }

    objObjectSequence_Lock_out strObjectSequence_Lock_out;
    if( CIMFWStrCmp(strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.durableCategory, SP_DurableCat_Cassette) == 0 )
    {
        PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
        rc = objectSequence_Lock( strObjectSequence_Lock_out, strObjCommonIn, durableIDs, SP_ClassName_PosCassette );
    }
    else if( CIMFWStrCmp(strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.durableCategory, SP_DurableCat_ReticlePod) == 0 )
    {
        PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosReticlePod );
        rc = objectSequence_Lock( strObjectSequence_Lock_out, strObjCommonIn, durableIDs, SP_ClassName_PosReticlePod );
    }
    else if( CIMFWStrCmp(strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.durableCategory, SP_DurableCat_Reticle) == 0 )
    {
        PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosProcessDurable );
        rc = objectSequence_Lock( strObjectSequence_Lock_out, strObjCommonIn, durableIDs, SP_ClassName_PosProcessDurable );
    }

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strDurableControlJobManageReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

//INN-R170003    //---------------------------------------
//INN-R170003    // Call durable_CheckConditionForOperation
//INN-R170003    //---------------------------------------
//INN-R170003    objDurable_CheckConditionForOperation_out strDurable_CheckConditionForOperation_out;
//INN-R170003    objDurable_CheckConditionForOperation_in  strDurable_CheckConditionForOperation_in;
//INN-R170003    strDurable_CheckConditionForOperation_in.operation        = CIMFWStrDup(SP_Operation_DurableControlJobManage);
//INN-R170003    strDurable_CheckConditionForOperation_in.equipmentID      = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.equipmentID;
//INN-R170003    strDurable_CheckConditionForOperation_in.durableCategory  = CIMFWStrDup(strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.durableCategory);
//INN-R170003    strDurable_CheckConditionForOperation_in.strStartDurables = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.strStartDurables;
//INN-R170003    rc = durable_CheckConditionForOperation(strDurable_CheckConditionForOperation_out, strObjCommonIn, strDurable_CheckConditionForOperation_in);
//INN-R170003    if( rc != RC_OK )
//INN-R170003    {
//INN-R170003        PPT_METHODTRACE_V2("", "durable_CheckConditionForOperation() != RC_OK", rc);
//INN-R170003        strDurableControlJobManageReqResult.strResult = strDurable_CheckConditionForOperation_out.strResult;
//INN-R170003        return( rc );
//INN-R170003    }

    //---------------------------------------
    // Call durable_status_CheckForOperation
    //---------------------------------------
    objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
    for ( i = 0; i < durableLen; i++ )
    {
        objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
        strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup(SP_Operation_DurableControlJobManage);
        strDurable_status_CheckForOperation_in.durableID       = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.strStartDurables[i].durableID;
        strDurable_status_CheckForOperation_in.durableCategory = CIMFWStrDup(strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.durableCategory);
        rc = durable_status_CheckForOperation(strDurable_status_CheckForOperation_out, strObjCommonIn, strDurable_status_CheckForOperation_in);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_status_CheckForOperation() != RC_OK", rc);
            strDurableControlJobManageReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
            return( rc );
        }
    }

    //-------------------------------------------------------
    // Get Environmental Variables for Event_Make
    //-------------------------------------------------------
    CORBA::String_var tmpControlJobStatusChangeHistoryMask = CIMFWStrDup(getenv(SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK));
    CORBA::ULong      counter = 0;
    if( CIMFWStrLen(tmpControlJobStatusChangeHistoryMask) == 5 )
    {
        for( counter = 0; counter < 5; counter++ )
        {
            if( tmpControlJobStatusChangeHistoryMask[counter] == '0' ||
                tmpControlJobStatusChangeHistoryMask[counter] == '1' )
            {
                continue;
            }
            else
            {
                break;
            }
        }
        if( counter != 5 )
        {
            PPT_METHODTRACE_V1("","Environment variable was set to the default value of 00000 because of the invalid input.");
            tmpControlJobStatusChangeHistoryMask = CIMFWStrDup("00000");
        }
        else
        {
            // normal case. continue to the following procedure.
        }
    }
    else
    {
        PPT_METHODTRACE_V1("","Environment variable was set to the default value of 00000 because of the invalid input.");
        tmpControlJobStatusChangeHistoryMask = CIMFWStrDup("00000");
    }

    //-------------------------------------------------------
    //
    // Check Input Parameter
    //
    //-------------------------------------------------------
    CORBA::String_var controlJobStatus;
    objectIdentifier  saveControlJobID;
    CORBA::Boolean    bNeedtoCheckCJStatus = FALSE;
    CORBA::Boolean    bNeedtoMakeEvent     = FALSE;
    PPT_METHODTRACE_V3("",
                       "txDurableControlJobManageReq was claimed with : ",
                       strDurableControlJobManageReqInParam.durableControlJobID.identifier,
                       strDurableControlJobManageReqInParam.controlJobAction);

    if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_create) == 0 )
    {
        PPT_METHODTRACE_V1("", "ControlJobAction type : create");
        if( CIMFWStrCmp( strObjCommonIn.transactionID , "TXPDC045" ) == 0 )
        {
            PPT_METHODTRACE_V2("",
                               "Request of ControlJobAction type : create is not supported to the specified transaction : ",
                               strObjCommonIn.transactionID);
            PPT_SET_MSG_RC_KEY(strDurableControlJobManageReqResult, MSG_CALLED_FROM_INVALID_TRANSACTION, RC_CALLED_FROM_INVALID_TRANSACTION, strObjCommonIn.transactionID);
            return( RC_CALLED_FROM_INVALID_TRANSACTION );
        }
        else
        {
            //continue to the following procedure
        }

        objDurableControlJob_Create_out strDurableControlJob_Create_out;
        objDurableControlJob_Create_in  strDurableControlJob_Create_in;
        strDurableControlJob_Create_in.equipmentID      = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.equipmentID;
        strDurableControlJob_Create_in.durableCategory  = CIMFWStrDup(strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.durableCategory);
        strDurableControlJob_Create_in.strStartDurables = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.strStartDurables;

        rc = durableControlJob_Create(strDurableControlJob_Create_out, strObjCommonIn, strDurableControlJob_Create_in);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "durableControlJob_Create() rc != RC_OK");
            strDurableControlJobManageReqResult.strResult = strDurableControlJob_Create_out.strResult;
            return( rc );
        }

        if(tmpControlJobStatusChangeHistoryMask[0] == '1')
        {
            bNeedtoMakeEvent = TRUE;
        }
        else
        {
            bNeedtoMakeEvent = FALSE;
        }
        controlJobStatus = CIMFWStrDup(SP_ControlJobStatus_Created);
        strDurableControlJobManageReqResult.durableControlJobID = strDurableControlJob_Create_out.durableControlJobID;
        saveControlJobID = strDurableControlJob_Create_out.durableControlJobID;

        objDurable_durableControlJobID_Set_out strDurable_durableControlJobID_Set_out;
        for ( i = 0; i < durableLen; i++ )
        {
            PPT_METHODTRACE_V3("", "loop to durables.length()", durableLen, i);
            objDurable_durableControlJobID_Set_in strDurable_durableControlJobID_Set_in;
            strDurable_durableControlJobID_Set_in.durableCategory     = CIMFWStrDup(strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.durableCategory);
            strDurable_durableControlJobID_Set_in.durableID           = strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest.strStartDurables[i].durableID;
            strDurable_durableControlJobID_Set_in.durableControlJobID = strDurableControlJob_Create_out.durableControlJobID;

            rc = durable_durableControlJobID_Set(strDurable_durableControlJobID_Set_out, strObjCommonIn, strDurable_durableControlJobID_Set_in);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "durable_durableControlJobID_Set() rc != RC_OK");
                strDurableControlJobManageReqResult.strResult = strDurable_durableControlJobID_Set_out.strResult;
                return( rc );
            }
        }
    }
    else if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_queue) == 0 )
    {
        PPT_METHODTRACE_V1("", "ControlJobAction type : queue");
        if(tmpControlJobStatusChangeHistoryMask[1] == '1')
        {
            bNeedtoMakeEvent = TRUE;
        }
        else
        {
            bNeedtoMakeEvent = FALSE;
        }
        controlJobStatus = CIMFWStrDup(SP_ControlJobStatus_Queued);
        saveControlJobID = strDurableControlJobManageReqInParam.durableControlJobID;
    }
    else if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_execute) == 0 )
    {
        PPT_METHODTRACE_V1("", "ControlJobAction type : execute");
        if(tmpControlJobStatusChangeHistoryMask[2] == '1')
        {
            bNeedtoMakeEvent = TRUE;
        }
        else
        {
            bNeedtoMakeEvent = FALSE;
        }
        controlJobStatus = CIMFWStrDup(SP_ControlJobStatus_Executing);
        saveControlJobID = strDurableControlJobManageReqInParam.durableControlJobID;
    }
    else if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_complete) == 0 )
    {
        PPT_METHODTRACE_V1("", "ControlJobAction type : complete");
        if(tmpControlJobStatusChangeHistoryMask[3] == '1')
        {
            bNeedtoMakeEvent = TRUE;
        }
        else
        {
            bNeedtoMakeEvent = FALSE;
        }
        controlJobStatus = CIMFWStrDup(SP_ControlJobStatus_Completed);
        saveControlJobID = strDurableControlJobManageReqInParam.durableControlJobID;
    }
    else if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_delete) == 0 )
    {
        PPT_METHODTRACE_V2("", "ControlJobAction type : ", SP_ControlJobAction_Type_delete);
        if( CIMFWStrCmp( strObjCommonIn.transactionID , "TXPDC045" ) == 0 )
        {
            PPT_METHODTRACE_V2("", "Request of ControlJobAction type : delete is not supported to the specified transaction : ", strObjCommonIn.transactionID);
            PPT_SET_MSG_RC_KEY(strDurableControlJobManageReqResult, MSG_CALLED_FROM_INVALID_TRANSACTION, RC_CALLED_FROM_INVALID_TRANSACTION, strObjCommonIn.transactionID);
            return( RC_CALLED_FROM_INVALID_TRANSACTION );
        }
        else
        {
            //continue to the following procedure
        }

        if(tmpControlJobStatusChangeHistoryMask[4] == '1')
        {
            bNeedtoMakeEvent = TRUE;
        }
        else
        {
            bNeedtoMakeEvent = FALSE;
        }
        controlJobStatus = CIMFWStrDup(SP_ControlJobStatus_Deleted);
        saveControlJobID = strDurableControlJobManageReqInParam.durableControlJobID;
    }
    else if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_stop) == 0 )
    {
        PPT_METHODTRACE_V1("", "ControlJobAction type : stop");
        bNeedtoMakeEvent = TRUE;
        bNeedtoCheckCJStatus = TRUE;
        controlJobStatus = CIMFWStrDup(SP_ControlJobStatus_Stopped);
        saveControlJobID = strDurableControlJobManageReqInParam.durableControlJobID;
    }
    else if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_abort) == 0 )
    {
        PPT_METHODTRACE_V1("", "ControlJobAction type : abort");
        bNeedtoMakeEvent = TRUE;
        bNeedtoCheckCJStatus = TRUE;
        controlJobStatus = CIMFWStrDup(SP_ControlJobStatus_Aborted);
        saveControlJobID = strDurableControlJobManageReqInParam.durableControlJobID;
    }
    else
    {
        PPT_METHODTRACE_V2("", "Invalid ControlJob Action : ", strDurableControlJobManageReqInParam.controlJobAction);
        PPT_SET_MSG_RC_KEY(strDurableControlJobManageReqResult,
                           MSG_INVALID_CONTROLJOBACTION_TYPE,
                           RC_INVALID_CONTROLJOBACTION_TYPE,
                           strDurableControlJobManageReqInParam.controlJobAction);
        return( RC_INVALID_CONTROLJOBACTION_TYPE );
    }

    //-------------------------------------------------------
    //
    //   Call TCSMgr's method for "Abort"/"Stop".
    //   Event_Make is at the same time ( if needed ).
    //
    //-------------------------------------------------------
    if( bNeedtoCheckCJStatus == TRUE || bNeedtoMakeEvent == TRUE )
    {
        //---------------------------------------------------------------------------
        // Get common information between calling TCSMgr's method and Event_Make
        //---------------------------------------------------------------------------
        objDurableControlJob_startReserveInformation_Get_out strDurableControlJob_startReserveInformation_Get_out;
        objDurableControlJob_startReserveInformation_Get_in  strDurableControlJob_startReserveInformation_Get_in;
        strDurableControlJob_startReserveInformation_Get_in.durableControlJobID = saveControlJobID;
        rc = durableControlJob_startReserveInformation_Get(strDurableControlJob_startReserveInformation_Get_out, strObjCommonIn, strDurableControlJob_startReserveInformation_Get_in);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "durableControlJob_startReserveInformation_Get() != RC_OK");
            strDurableControlJobManageReqResult.strResult = strDurableControlJob_startReserveInformation_Get_out.strResult;
            return( rc );
        }

        //-------------------------------------------------------
        // Check current CJ status to before calling TCSMgr's method
        //-------------------------------------------------------
        if( bNeedtoCheckCJStatus == TRUE )
        {
            //-------------------------------------------------------
            // Get current status of the specified CJ
            //-------------------------------------------------------
            objDurableControlJob_status_Get_out strDurableControlJob_status_Get_out;
            objDurableControlJob_status_Get_in  strDurableControlJob_status_Get_in;
            strDurableControlJob_status_Get_in.durableControlJobID = saveControlJobID;
            rc = durableControlJob_status_Get(strDurableControlJob_status_Get_out, strObjCommonIn, strDurableControlJob_status_Get_in);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "durableControlJob_status_Get() != RC_OK");
                strDurableControlJobManageReqResult.strResult = strDurableControlJob_status_Get_out.strResult;
                return( rc );
            }

            //-------------------------------------------------------
            // Current status vs. required CJ Action
            //-------------------------------------------------------
            if( CIMFWStrCmp( strDurableControlJob_status_Get_out.durableControlJobStatus, SP_ControlJobStatus_Queued ) == 0 ||
                CIMFWStrCmp( strDurableControlJob_status_Get_out.durableControlJobStatus, SP_ControlJobStatus_Executing ) == 0 )
            {
                // OK. Nothing to do.
            }
            else
            {
                PPT_METHODTRACE_V3("","Invalid ControlJobAction for : ", saveControlJobID.identifier, strDurableControlJob_status_Get_out.durableControlJobStatus);
                PPT_SET_MSG_RC_KEY2(strDurableControlJobManageReqResult,
                                    MSG_INVALID_DCTRLJOBACTION_FOR_DCJSTATUS,
                                    RC_INVALID_DCTRLJOBACTION_FOR_DCJSTATUS,
                                    strDurableControlJob_status_Get_out.durableControlJobStatus,
                                    saveControlJobID.identifier);
                return( RC_INVALID_DCTRLJOBACTION_FOR_DCJSTATUS );
            }

            //-----------------------------------------------------------
            // Get Eqp Port Information
            //-----------------------------------------------------------
            PPT_METHODTRACE_V1("", "Get Eqp Port Information");
            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                         strObjCommonIn,
                                         strDurableControlJob_startReserveInformation_Get_out.equipmentID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_portInfo_Get() != RC_OK");
                strDurableControlJobManageReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return( rc );
            }

            //-----------------------------------------------------------
            // Check On-line mode of EQP to call TCSMgr's method
            //-----------------------------------------------------------
            if( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[0].onlineMode, SP_Eqp_OnlineMode_Offline) == 0 )
            {
                PPT_METHODTRACE_V1("", "onlineMode == SP_Eqp_OnlineMode_Offline");
                PPT_SET_MSG_RC_KEY2( strDurableControlJobManageReqResult,
                                     MSG_INVALID_EQP_MODE,
                                     RC_INVALID_EQP_MODE,
                                     strDurableControlJob_startReserveInformation_Get_out.equipmentID.identifier,
                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[0].onlineMode );
                return( RC_INVALID_EQP_MODE );
            }
            else
            {
                // Continue to the following procedure
            }

            //-------------------------------------------------------
            // Call TxControlJobActionReq of TCSMgr
            //-------------------------------------------------------
            CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
            CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
            CORBA::Long sleepTimeValue = 0;
            CORBA::Long retryCountValue = 0;

            if(CIMFWStrLen(tmpSleepTimeValue) == 0)
            {
                sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
            }
            else
            {
                sleepTimeValue = atoi(tmpSleepTimeValue) ;
            }

            if(CIMFWStrLen(tmpRetryCountValue) == 0)
            {
                retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
            }
            else
            {
                retryCountValue = atoi(tmpRetryCountValue);
            }

            PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
            PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

            objTCSMgr_SendDurableControlJobActionReq_out strTCSMgr_SendDurableControlJobActionReq_out;

            //'retryCountValue + 1' means first try plus retry count
            for ( CORBA::ULong retryNum = 0; retryNum < (retryCountValue + 1); retryNum++ )
            {
                /*--------------------------*/
                /*    Send Request to TCS   */
                /*--------------------------*/
                objTCSMgr_SendDurableControlJobActionReq_in strTCSMgr_SendDurableControlJobActionReq_in;
                strTCSMgr_SendDurableControlJobActionReq_in.equipmentID         = strDurableControlJob_startReserveInformation_Get_out.equipmentID;
                strTCSMgr_SendDurableControlJobActionReq_in.durableControlJobID = saveControlJobID;
                strTCSMgr_SendDurableControlJobActionReq_in.actionCode          = CIMFWStrDup(strDurableControlJobManageReqInParam.controlJobAction);
                strTCSMgr_SendDurableControlJobActionReq_in.claimMemo           = CIMFWStrDup(claimMemo);

                PPT_METHODTRACE_V1("CS_PPTManager_i::txDurableControlJobManageReq", "Send ControlJobActionReq() to TCS Procedure" );
                rc = TCSMgr_SendDurableControlJobActionReq( strTCSMgr_SendDurableControlJobActionReq_out,
                                                            strObjCommonIn,
                                                            strTCSMgr_SendDurableControlJobActionReq_in );

                PPT_METHODTRACE_V2("","rc = ",rc);

                if(rc == RC_OK)
                {
                    PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                    break;
                }
                else if( rc == RC_EXT_SERVER_BIND_FAIL ||
                         rc == RC_EXT_SERVER_NIL_OBJ   ||
                         rc == RC_TCS_NO_RESPONSE )
                {
                    PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...", retryNum);
                    PPT_METHODTRACE_V2("","now sleeping... ", sleepTimeValue);
                    sleep(sleepTimeValue);
                    continue;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "TCSMgr_SendDurableControlJobActionReq() != RC_OK");
                    strDurableControlJobManageReqResult.strResult = strTCSMgr_SendDurableControlJobActionReq_out.strResult;
                    return( rc );
                }
            }

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "TCSMgr_SendDurableControlJobActionReq() != RC_OK");
                strDurableControlJobManageReqResult.strResult = strTCSMgr_SendDurableControlJobActionReq_out.strResult;
                return( rc );
            }
        }

        //-------------------------------------------------------
        // Event Make
        //-------------------------------------------------------
        if( bNeedtoMakeEvent ==  TRUE )
        {
            objDurableControlJobStatusChangeEvent_Make_out strDurableControlJobStatusChangeEvent_Make_out;
            objDurableControlJobStatusChangeEvent_Make_in  strDurableControlJobStatusChangeEvent_Make_in;
            strDurableControlJobStatusChangeEvent_Make_in.transactionID           = CIMFWStrDup(strObjCommonIn.transactionID);
            strDurableControlJobStatusChangeEvent_Make_in.durableControlJobID     = saveControlJobID;
            strDurableControlJobStatusChangeEvent_Make_in.durableControlJobStatus = CIMFWStrDup(controlJobStatus);
            strDurableControlJobStatusChangeEvent_Make_in.durableCategory         = CIMFWStrDup(strDurableControlJob_startReserveInformation_Get_out.durableCategory);
            strDurableControlJobStatusChangeEvent_Make_in.strStartDurables        = strDurableControlJob_startReserveInformation_Get_out.strStartDurables;
            strDurableControlJobStatusChangeEvent_Make_in.claimMemo               = CIMFWStrDup(claimMemo);

            rc = durableControlJobStatusChangeEvent_Make(strDurableControlJobStatusChangeEvent_Make_out, strObjCommonIn, strDurableControlJobStatusChangeEvent_Make_in);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "durableControlJobStatusChangeEvent_Make() != RC_OK");
                strDurableControlJobManageReqResult.strResult = strDurableControlJobStatusChangeEvent_Make_out.strResult;
                return( rc );
            }
        }
        else
        {
            // Continue to the following procedure
        }
    }
    else
    {
        // Continue to the following procedure
    }

    //-------------------------------------------------------
    //
    // Change ControlJob Status
    //
    //-------------------------------------------------------
    objDurableControlJob_status_Change_out strDurableControlJob_status_Change_out;
    objDurableControlJob_status_Change_in  strDurableControlJob_status_Change_in;
    strDurableControlJob_status_Change_in.durableControlJobID     = saveControlJobID;
    strDurableControlJob_status_Change_in.durableControlJobStatus = CIMFWStrDup(controlJobStatus);
    rc = durableControlJob_status_Change(strDurableControlJob_status_Change_out, strObjCommonIn, strDurableControlJob_status_Change_in);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "durableControlJob_status_Change() != RC_OK");
        strDurableControlJobManageReqResult.strResult = strDurableControlJob_status_Change_out.strResult;
        return( rc );
    }

    //-------------------------------------------------------
    //
    //   Delete ControlJob when deletion of CJ is claimed
    //   Method call for deleting ControlJob should be at the end.
    //   ControlJob needs to be alive during above procedure.
    //
    //-------------------------------------------------------
    if( CIMFWStrCmp(strDurableControlJobManageReqInParam.controlJobAction, SP_ControlJobAction_Type_delete) == 0 )
    {
        objDurableControlJob_Delete_out strDurableControlJob_Delete_out;
        objDurableControlJob_Delete_in  strDurableControlJob_Delete_in;
        strDurableControlJob_Delete_in.durableControlJobID = saveControlJobID;
        strDurableControlJob_Delete_in.actionType = CIMFWStrDup(strDurableControlJobManageReqInParam.controlJobAction);
        rc = durableControlJob_Delete(strDurableControlJob_Delete_out, strObjCommonIn, strDurableControlJob_Delete_in);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "durableControlJob_Delete() rc != RC_OK");
            strDurableControlJobManageReqResult.strResult = strDurableControlJob_Delete_out.strResult;
            return( rc );
        }
    }
    else
    {
        //noting to do.
    }

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txDurableControlJobManageReq");
    return( RC_OK );
}
