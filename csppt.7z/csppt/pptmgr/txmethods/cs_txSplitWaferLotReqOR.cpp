#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txSplitWaferLotReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/16/07 18:57:58 [ 11/16/07 18:57:59 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txSplitWaferLotReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txSplitWaferLotReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000/08/11            O.Sugiyama     Initial Release
// 2000/09/26 Q3000147   S.Kawabe       Add Check Lot's Control Job ID
// 2000/10/23 P3000280   S.Kawabe       Boolean variable initialize
// 2001-01-16 D3000118   S.NAKATA       Lot Customization and Flexible Rework
// 2001-01-16 D3000119   S.NAKATA       Lot Customization and Flexible Rework
// 2001-03-01 P3100060   M.Shimizu      All Merge Check Bug Fix
// 2001-03-16 P3100128   K.Muguruma     LC:Add checking RouteID. (exitRouteID, returnRotueID of Flexible Rework)
// 2001-04-10 P3100123   K.Muguruma     LC:add check whether ReturnOperationNumber exist on OperationList.
// 2001/06/15 P4000023   M.Shimizu      Control branch to SubRoute/ReworkRoute
// 2001/07/02 P4000037   K.Kido         Add XferState Check
// 2001/07/12 D4000016   M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001/08/01 P4000079   K.Kido         Change Xfer State check logic
// 2002/01/15 D4100069   C.Tsuchiya     Drop LCFR logic
// 2002/01/21 D4100020   N.Maeda        Change oldCurrentPOS to oldCurrentPOData
// 2002/01/23 D4100091   H.Adachi       EWR Experimental Lot Control Merge From R4.0a
//                                      Change Xfer State check logic For EWR-Experimental Lot Control
//                                      Add FREQP_CAST_LOT maintain logic for Experimental Lot Control
// 2002/02/08 D4100083   T.Michii       Enhancement Future Hold
// 2002/02/25 P4100151   H.Adachi       Add Lot State Check for Shipped Lot
// 2002/03/02 D4100036   K.Matsuei      FlowBatch Control.
// 2002/07/05 P4200026   H.Adachi       Fix wrong waferID setting For Event Make
// 2002/07/30 D4200029   K.Kimura       Process Hold Control
// 2003/09/09 P5000145   H.Adachi       Fix Message and Message Macro mismatch.
// 2004/10/22 D6000025   K.Murakami     eBroker Migration.
// 2004/11/08 P6000017   S.Yamamoto     Fix : Object Lock missing or delay.
// 2005/12/14 D7000067   F.Masada       Add check logic of return operation by process_GetReturnOperation().
// 2007/06/12 D9000005   H.Hotta        WaferSorter automation support.
// 2007/06/15 D9000038   D.Tamura       Remove In-Cassette Limitation.
// 2007/08/03 D9000056   H.Hotta        Add check logic for InPostProcessFlag.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/08 DSIV00000099 M.Ogawa        SLM support (R10.0).
// 2008/08/27 PSIV00000186 H.Mutoh        Fix using claim memo. 
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2010/07/15 PSIV00002201 S.Kawabe       Fail to split the lot in bank, when there exists ProcessHold on the final operation of the route
// 2011/08/23 DSN000015229 Sa Guo         Allow split when lot is EI with controlJob for Advanced Wafer Level Control
// 2013/05/08 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2014/10/14 DSN000085792 K.Yamaoku      Q-Time Improvements.
// 2017/03/30 PSN000104668 XF.Ming        Split & Branch is executed normally even lot is COMPLETED
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/12 INN-R170002  Thomas Song    Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptSplitWaferLotReqResult&              strSplitWaferLotReqResult
//    const pptObjCommonIn&                   strObjCommonIn
//    const objectIdentifier&                 parentLotID
//    const objectIdentifierSequence&         childWaferID
//    CORBA::Boolean                          futureMergeFlag
//    const objectIdentifier&                 mergedRouteID
//    const char *                            mergedOperationNumber
//    CORBA::Boolean                          branchingRouteSpecifyFlag
//    const objectIdentifier&                 subRouteID
//    const char *                            returnOperationNumber
//    const char *                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txSplitWaferLotReq (
    pptSplitWaferLotReqResult&              strSplitWaferLotReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 parentLotID,
    const objectIdentifierSequence&         childWaferID,
    CORBA::Boolean                          futureMergeFlag,
    const objectIdentifier&                 mergedRouteID,
    const char *                            mergedOperationNumber,
    CORBA::Boolean                          branchingRouteSpecifyFlag,
    const objectIdentifier&                 subRouteID,
    const char *                            returnOperationNumber,
//D6000025     const char *                            claimMemo,
//D6000025     CORBA::Environment &                    IT_env)
    const char *                            claimMemo //D6000025
    CORBAENV_LAST_CPP)                                //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txSplitWaferLotReq");
    CORBA::Long rc = RC_OK ;
    CORBA::Long checkForLCFRRetCord = RC_OK ;             //add  (D3000118 D3000119)

    //P6000017 start
    /*------------------------------------------------------------------------*/
    /*   Check Condition                                                      */
    /*------------------------------------------------------------------------*/
    objLot_cassette_Get_out strLot_cassette_Get_out ;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn,
                          parentLotID);
//D9000038    if (rc)
    if ( rc != RC_OK && rc != RC_NOT_FOUND_CST ) //D9000038
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "cassette_lot_Get() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_cassette_Get_out.strResult ;
        return(rc);
    }

    objectIdentifier aParentCassetteID;
    aParentCassetteID = strLot_cassette_Get_out.cassetteID;

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;
    objObject_Lock_out strObject_Lock_out;

    if ( 0 == lotOperationEIcheck && 0 < CIMFWStrLen( aParentCassetteID.identifier ) )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        aParentCassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strSplitWaferLotReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       aParentCassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strSplitWaferLotReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC019" ); // TxSplitWaferLotReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strSplitWaferLotReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );
        if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
        {
            updateControlJobFlag = TRUE;
            PPT_METHODTRACE_V1("PPTManager_i:: txSplitWaferLotReq", "transferState == EO/PI");
            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strSplitWaferLotReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = aParentCassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strSplitWaferLotReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strSplitWaferLotReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }

//PSN000083176        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            aParentCassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strSplitWaferLotReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;

//PSN000083176                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strSplitWaferLotReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end

    /*--------------------------------*/
    /*   Lock objects to be updated   */
    /*--------------------------------*/
//DSN000071674    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     aParentCassetteID, SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq ", "object_Lock() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strObject_Lock_out.strResult ;
        return( rc );
    }
//PSN000083176 add start
    if ( 0 == lotOperationEIcheck && 0 < CIMFWStrLen( aParentCassetteID.identifier ) )
    {
        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            aParentCassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strSplitWaferLotReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;

                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strSplitWaferLotReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end
    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     parentLotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq ", "object_Lock() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strObject_Lock_out.strResult ;
        return( rc );
    }
    //P6000017 end

//D9000005 add start
    if( 0 != CIMFWStrCmp(strObjCommonIn.strUser.userID.identifier, SP_SorterWatchDog_Person) )
    {
        /*-------------------------------*/
        /*   Check SorterJob existence   */
        /*-------------------------------*/
        pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
        objectIdentifierSequence dummyCastIDs, lotIDs;
        lotIDs.length(1);
        lotIDs[0] = parentLotID;

        objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
        objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
        strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
        strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyCastIDs;
        strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = lotIDs;
        strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Lot);

        rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                      strObjCommonIn,
                                                      strWaferSorter_sorterJob_CheckForOperation_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
            strSplitWaferLotReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
            return( rc );
        }
    }
//D9000005 add end

    {//P4000023 Add Start
        /*----------------------------------------------------*/
        /*Currrent Route ID Get For routeID confliction-Check */
        /*----------------------------------------------------*/
        objLot_currentRouteID_Get_out strLot_currentRouteID_Get_out;
        rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out, strObjCommonIn, parentLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq ","lot_currentRouteID_Get() != RC_OK : ", rc) ;
            strSplitWaferLotReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
            return( rc );
        }

        objectIdentifier    currentRouteID;
        currentRouteID = strLot_currentRouteID_Get_out.currentRouteID;

        /* ------------------------------------------------------------*/
        /* Check routeID confliction                                   */
        /*   return RC_INVALID_BRANCH_ROUTEID,                         */
        /*   when the same routeID is used in the following case       */
        /*       ex) Subroute --> The same SubRoute in the course      */
        /* ------------------------------------------------------------*/
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_originalRouteList_Get IN ");
        objLot_originalRouteList_Get_out  strLot_originalRouteList_Get_out;
        rc = lot_originalRouteList_Get( strLot_originalRouteList_Get_out,
                                        strObjCommonIn,parentLotID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "lot_originalRouteList_Get() != RC_OK", rc);
            strSplitWaferLotReqResult.strResult = strLot_originalRouteList_Get_out.strResult ;
            return( rc );
        }

        CORBA::Long kLen = strLot_originalRouteList_Get_out.originalRouteID.length();
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "strLot_originalRouteList_Get_out.originalRouteID.length=", kLen);

        //Check CurrentRoute VS SubRoute
        if(CIMFWStrCmp(currentRouteID.identifier,subRouteID.identifier ) == 0)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "currentRouteID = subRouteID len =: ", kLen);
            SET_MSG_RC( strSplitWaferLotReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
            return( RC_INVALID_BRANCH_ROUTEID );
        }

        //Check Afetr Route VS SubRoute
        for(CORBA::Long iLoop = 0;iLoop < kLen ;iLoop++)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq",
                               "strLot_originalRouteList_Get_out.originalRouteID = ", strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier);

            if(CIMFWStrCmp(strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier,subRouteID.identifier ) == 0)
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "OriginalRouteID[iLoop].identifier == subRouteID iLoop = ", iLoop);
                SET_MSG_RC( strSplitWaferLotReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
                return( RC_INVALID_BRANCH_ROUTEID );
            }
        }
    }//P4000023 Add End

    //P4100151 Add Start
    //========================================
    // LotStatus should be Not Shipped
    //========================================

    objLot_state_Get_out strLot_state_Get_out ;
    rc = lot_state_Get(strLot_state_Get_out,strObjCommonIn, parentLotID) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "lot_state_Get() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_state_Get_out.strResult ;
        return(rc);
    }
    else if(CIMFWStrCmp(strLot_state_Get_out.lotState, CIMFW_Lot_State_Shipped) == 0)
    {
        PPT_METHODTRACE_V1("", "Lot State Shipped is Invalid !!!");
        PPT_SET_MSG_RC_KEY(strSplitWaferLotReqResult, MSG_INVALID_LOT_STAT ,RC_INVALID_LOT_STAT, strLot_state_Get_out.lotState);
        return(RC_INVALID_LOT_STAT);
    }
    //P4100151 Add End

//P6000017    /*------------------------------------------------------------------------*/
//P6000017    /*   Check Condition                                                      */
//P6000017    /*------------------------------------------------------------------------*/
//P6000017    objLot_cassette_Get_out strLot_cassette_Get_out ;
//P6000017    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn,
//P6000017                          parentLotID);
//P6000017    if (rc)
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "cassette_lot_Get() rc != RC_OK");
//P6000017        strSplitWaferLotReqResult.strResult = strLot_cassette_Get_out.strResult ;
//P6000017        return(rc);
//P6000017    }
//P6000017
//P6000017    objectIdentifier aParentCassetteID;
//P6000017    aParentCassetteID = strLot_cassette_Get_out.cassetteID;
//P6000017
//P6000017    /*--------------------------------*/
//P6000017    /*   Lock objects to be updated   */
//P6000017    /*--------------------------------*/
//P6000017    objObject_Lock_out strObject_Lock_out;
//P6000017    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
//P6000017                     aParentCassetteID, SP_ClassName_PosCassette );
//P6000017    if ( rc != RC_OK )
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq ", "object_Lock() rc != RC_OK");
//P6000017        strSplitWaferLotReqResult.strResult = strObject_Lock_out.strResult ;
//P6000017        return( rc );
//P6000017    }
//P6000017
//P6000017    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
//P6000017                     parentLotID, SP_ClassName_PosLot );
//P6000017    if ( rc != RC_OK )
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq ", "object_Lock() rc != RC_OK");
//P6000017        strSplitWaferLotReqResult.strResult = strObject_Lock_out.strResult ;
//P6000017        return( rc );
//P6000017    }

    /*------------------------------------------------------------------------*/
    /*   Check Condition                                                      */
    /*------------------------------------------------------------------------*/
    objLot_contents_Get_out strLot_contents_Get_out ;
    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn,
                          parentLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_contents_Get() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_contents_Get_out.strResult ;
        return(rc);
    }
    else if ( (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer)) &&
              (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Die)) )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "CIMFWStrCmp(strLot_contents_Get_out.theLotContents,SP_ProdType_*)");
        PPT_SET_MSG_RC_KEY(strSplitWaferLotReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS, parentLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

    objLot_holdState_Get_out strLot_holdState_Get_out ;
    rc = lot_holdState_Get(strLot_holdState_Get_out, strObjCommonIn,
                           parentLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_holdState_Get() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_holdState_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_OnHold) == 0");
        SET_MSG_RC(strSplitWaferLotReqResult, MSG_CANNOT_SPLIT_HELDLOT, RC_CANNOT_SPLIT_HELDLOT);
        return(RC_CANNOT_SPLIT_HELDLOT);
    }

    objLot_finishedState_Get_out strLot_finishedState_Get_out ;
    rc = lot_finishedState_Get(strLot_finishedState_Get_out, strObjCommonIn,
                               parentLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_finishedState_Get() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_finishedState_Get_out.strResult ;
        return(rc);
    }
    else if ( (CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState, CIMFW_Lot_FinishedState_Scrapped) == 0 ) ||
              (CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState, CIMFW_Lot_FinishedState_Emptied ) == 0 ) ||
              (CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState, SP_LOT_FINISHED_STATE_STACKED )   == 0 ) ) //DSIV00001830
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_*)");
        PPT_SET_MSG_RC_KEY(strSplitWaferLotReqResult, MSG_INVALID_LOT_STAT, RC_INVALID_LOT_STAT, strLot_finishedState_Get_out.lotFinishedState);
        return( RC_INVALID_LOT_STAT );
    }

//DSIV00001830 add start
    //-------------------------
    // Check Bonding Group
    //-------------------------
    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = parentLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strSplitWaferLotReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    objLot_processState_Get_out strLot_processState_Get_out ;
    rc = lot_processState_Get(strLot_processState_Get_out, strObjCommonIn,
                              parentLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_processState_Get() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_processState_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) == 0)
    {
//DSN000015229 Add Start
        if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
          && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
        {
//DSN000015229 Add End
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Processing) == 0");
            PPT_SET_MSG_RC_KEY2(strSplitWaferLotReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                                parentLotID.identifier, strLot_processState_Get_out.theLotProcessState);
            return(RC_INVALID_LOT_PROCSTAT);
        }   //DSN000015229
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = parentLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strSplitWaferLotReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strSplitWaferLotReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                parentLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end
    //D7000067 add start
    /*------------------------------------------------------------------------*/
    /*   Check SubRouteID and return oepration                                */
    /*------------------------------------------------------------------------*/
    if ( CIMFWStrLen(subRouteID.identifier) > 0 ) // if subRouteID is specified, check it.
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "CIMFWStrLen(subRouteID.identifier) > 0" );
        
//PSN000104668 Add Start
        //----------------------------------------//
        //    Call lot_inventoryState_Get         //
        //----------------------------------------//
        objLot_inventoryState_Get_out strParentLot_inventoryState_Get_out;
        rc = lot_inventoryState_Get( strParentLot_inventoryState_Get_out, strObjCommonIn, parentLotID);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inventoryState_Get() != RC_OK");
            strSplitWaferLotReqResult.strResult = strParentLot_inventoryState_Get_out.strResult;
            return( rc );
        }
        else if( CIMFWStrCmp( strParentLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_InBank ) == 0 )
        {
            PPT_METHODTRACE_V1("", "strParentLot_inventoryState_Get_out.lotInventoryState is InBank") ;
            PPT_SET_MSG_RC_KEY2( strSplitWaferLotReqResult,
                                 MSG_INVALID_LOT_INVENTORYSTAT,
                                 RC_INVALID_LOT_INVENTORYSTAT,
                                 parentLotID.identifier,
                                 strParentLot_inventoryState_Get_out.lotInventoryState ) ;
            return(RC_INVALID_LOT_INVENTORYSTAT);
        }
        else
        {
            PPT_METHODTRACE_V1("", "strParentLot_inventoryState_Get_out.lotInventoryState is not InBank") ;
        }
//PSN000104668 Add End

        objProcess_checkForDynamicRoute_out strProcess_checkForDynamicRoute_out;
        rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, subRouteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "process_checkForDynamicRoute() != RC_OK", rc);
            strSplitWaferLotReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult;
            return(rc);
        }

        if ( strProcess_checkForDynamicRoute_out.bDynamicRoute != TRUE )  // if subRouteID is not dynamic route, check the return operation.
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "strProcess_checkForDynamicRoute_out.bDynamicRoute != TRUE" );

            objProcess_GetReturnOperation_out strProcess_GetReturnOperation_out;
            rc = process_GetReturnOperation( strProcess_GetReturnOperation_out, strObjCommonIn, parentLotID, subRouteID );

            if (rc == RC_OK)
            {
                if ( CIMFWStrLen( returnOperationNumber ) >0  &&
                     CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, returnOperationNumber) != 0 )
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_INPUT_PARM");
                    SET_MSG_RC( strSplitWaferLotReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
                    return RC_INVALID_INPUT_PARM;
                }
            }
            else   // Error case and RC_NOT_FOUND_SUBROUTE
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "process_GetReturnOperation() != RC_OK : ", rc) ;
                strSplitWaferLotReqResult.strResult = strProcess_GetReturnOperation_out.strResult ;
                return(rc);
            }
        }
    }
    //D7000067 add end

//D4100069//(D3000118 D3000119)  add start
//D4100069
//D4100069    /**------------------------------------------------------------------**/
//D4100069    /**   Lot_CheckForLCFR                                               **/
//D4100069    /**------------------------------------------------------------------**/
//D4100069    objLot_CheckForLCFR_out strLot_CheckForLCFR_out;                                               //(D3000118 D3000119)
//D4100069    checkForLCFRRetCord = lot_CheckForLCFR(strLot_CheckForLCFR_out,
//D4100069                                         strObjCommonIn,parentLotID,
//D4100069                                         SP_LotCustomize_DBRECORD);                                 // (D3000118 D3000119)
//D4100069    if ( checkForLCFRRetCord != RC_OK)                                                             //  (D3000118 D3000119)
//D4100069    {
//D4100069        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "Lot_CheckForLCFR() rc = RC_OK");
    objProcess_CheckSplit_out  strProcess_CheckSplit_out;
    rc = process_CheckSplit(strProcess_CheckSplit_out, strObjCommonIn,
                        mergedRouteID, mergedOperationNumber, returnOperationNumber);
    if (rc != RC_OK)
    {
       PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "process_CheckSplit() rc != RC_OK");
       strSplitWaferLotReqResult.strResult = strProcess_CheckSplit_out.strResult ;
       return(rc);
    }
//D4100069    }
//D4100069    else
//D4100069    {
//D4100069        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "Lot_CheckForLCFR()  rc != RC_OK");
//D4100069        objProcess_CheckSplitForLCFR_out  strProcess_CheckSplitForLCFR_out;                              //(D3000118 D3000119)
//D4100069        rc = process_CheckSplitForLCFR(strProcess_CheckSplitForLCFR_out,
//D4100069                                       strObjCommonIn,parentLotID, mergedRouteID,
//D4100069                                       mergedOperationNumber,returnOperationNumber);             //(D3000118 D3000119)  x
//D4100069
//D4100069       if (rc != RC_OK )                                                              //(D3000118 D3000119)
//D4100069       {
//D4100069           PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "process_CheckSplitForLCFR() rc != RC_OK"); //(D3000118 D3000119)
//D4100069           strSplitWaferLotReqResult.strResult = strProcess_CheckSplitForLCFR_out.strResult ;           //  (D3000118 D3000119)
//D4100069           return(rc);
//D4100069       }
//D4100069    }
//D4100069
//D4100069//P3100123  add start
//D4100069//P3100123      add to check whether ReturnOperationNumber that is defined by conventional SplitBranchToSubRoute function exist or not.
//D4100069//P3100123      When returnOperation is skipped by LotCustomized, return to caller.
//D4100069
//D4100069    /* Lot is for LCFR and specify the subRouteID and returnOperationNumber. */
//D4100069    if ( checkForLCFRRetCord == RC_OK &&
//D4100069         ( CIMFWStrLen( subRouteID.identifier ) > 0 && CIMFWStrLen( returnOperationNumber ) > 0 ) )
//D4100069    {
//D4100069        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "checkForLCFRRetCord == RC_OK : check routeList");
//D4100069        /* -------------------------------------------------------------*/
//D4100069        /*  get MainRouteID.                                            */
//D4100069        /* -------------------------------------------------------------*/
//D4100069        objectIdentifier            mainRouteID;
//D4100069        objLot_mainRouteID_Get_out  strLot_mainRouteID_Get_out;
//D4100069        rc = lot_mainRouteID_Get( strLot_mainRouteID_Get_out, strObjCommonIn, parentLotID );
//D4100069        if ( rc == RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "lot_mainRouteID_Get() == RC_OK ",
//D4100069                               strLot_mainRouteID_Get_out.mainRouteID.identifier);
//D4100069            mainRouteID = strLot_mainRouteID_Get_out.mainRouteID;
//D4100069        }
//D4100069        else
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "lot_mainRouteID_Get() != RC_OK ", rc);
//D4100069            strSplitWaferLotReqResult.strResult = strLot_mainRouteID_Get_out.strResult ;
//D4100069            return( rc );
//D4100069        }
//D4100069
//D4100069        /*-----------------------------------------------------*/
//D4100069        /*Currrent Route ID Get For  routeID confliction-Check */
//D4100069        /*-----------------------------------------------------*/
//D4100069        objLot_currentRouteID_Get_out   strLot_currentRouteID_Get_out;
//D4100069        rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out, strObjCommonIn, parentLotID );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                               "lot_currentRouteID_Get() != RC_OK : ", rc) ;
//D4100069            strSplitWaferLotReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
//D4100069            return( rc );
//D4100069        }
//D4100069
//D4100069        objectIdentifier    currentRouteID;
//D4100069        currentRouteID = strLot_currentRouteID_Get_out.currentRouteID;
//D4100069
//D4100069        /* -------------------------------------------------------------*/
//D4100069        /*  check whether lot is on MainRoute or not.                   */
//D4100069        /*                                                              */
//D4100069        /*  if lot is on MainRoute, get LotCustomized OperationList.    */
//D4100069        /*                                                              */
//D4100069        /*  if lot is not on MainRoute, get OperationList of            */
//D4100069        /*  currentRoute.                                               */
//D4100069        /* -------------------------------------------------------------*/
//D4100069        if ( CIMFWStrCmp( currentRouteID.identifier, mainRouteID.identifier ) == 0 ) /* lot is on MainRoute. */
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "currentRouteID == mainRouteID");
//D4100069
//D4100069            /* -------------------------------------------------------------*/
//D4100069            /*  get all LotCustomized data.                                 */
//D4100069            /* -------------------------------------------------------------*/
//D4100069            objLctable_routeList_LoadDR_out  strLctable_routeList_LoadDR_out;
//D4100069            rc = lctable_routeList_LoadDR( strLctable_routeList_LoadDR_out, strObjCommonIn, strObjCommonIn.strUser.userID, parentLotID );
//D4100069            if ( rc != RC_OK && rc != RC_NOT_FOUND_ENTRY_W )
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                   "lctable_routeList_LoadDR() != (rc != RC_OK && rc != RC_NOT_FOUND_ENTRY_W) ", rc);
//D4100069                strSplitWaferLotReqResult.strResult = strLctable_routeList_LoadDR_out.strResult ;
//D4100069                return( rc );
//D4100069            }
//D4100069
//D4100069            /* -------------------------------------------------------------*/
//D4100069            /*  when LotCustomized data exist, check returnOperationNumber. */
//D4100069            /* -------------------------------------------------------------*/
//D4100069            if ( rc == RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                   "lctable_routeList_LoadDR() == RC_OK");
//D4100069                /* -------------------------------------------------------------*/
//D4100069                /*  get LotCustomized all OperationList.                        */
//D4100069                /* -------------------------------------------------------------*/
//D4100069                objectIdentifier   fromRouteID;
//D4100069                objectIdentifier   toRouteID;
//D4100069                CORBA::String_var  fromOpeNo = CIMFWStrDup( "" );
//D4100069                CORBA::String_var  toOpeNo   = CIMFWStrDup( "" );
//D4100069                CORBA::Long        fromMode  = SP_LotCustomize_MAY_BRANCH;
//D4100069
//D4100069                fromRouteID.identifier = CIMFWStrDup( "" );
//D4100069                toRouteID.identifier = CIMFWStrDup( "" );
//D4100069
//D4100069                objLctable_OperationListForRoute_out    strLctable_OperationListForRoute_out;
//D4100069                rc = lctable_OperationListForRoute( strLctable_OperationListForRoute_out,
//D4100069                                                    strObjCommonIn,
//D4100069                                                    strLctable_routeList_LoadDR_out.strLotCustomizeInfo,
//D4100069                                                    parentLotID,
//D4100069                                                    fromRouteID,
//D4100069                                                    fromOpeNo,
//D4100069                                                    fromMode,
//D4100069                                                    toRouteID,
//D4100069                                                    toOpeNo );
//D4100069                if ( rc != RC_OK )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                       "lctable_OperationListForRoute() != RC_OK ", rc);
//D4100069                    strSplitWaferLotReqResult.strResult = strLctable_OperationListForRoute_out.strResult;
//D4100069                    return( rc );
//D4100069                }
//D4100069
//D4100069                /* -------------------------------------------------------------*/
//D4100069                /*  check whether returnOperationNumber exist on MainRoute.     */
//D4100069                /* -------------------------------------------------------------*/
//D4100069                CORBA::Boolean    returnOnMainRouteFlag = FALSE;
//D4100069                CORBA::Long       lenLctableOperationListForRoute = strLctable_OperationListForRoute_out.strOperationNameAttributes.length();
//D4100069                for ( CORBA::Long i=0; i<lenLctableOperationListForRoute; i++ )
//D4100069                {
//D4100069
//D4100069                    PPT_METHODTRACE_V3("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                       "returnOperationNumber check ", i, strLctable_OperationListForRoute_out.strOperationNameAttributes[i].operationNumber);
//D4100069                    /* -------------------------------------------------------------*/
//D4100069                    /*  check only on MainRoute.                                    */
//D4100069                    /* -------------------------------------------------------------*/
//D4100069                    if ( CIMFWStrCmp( strLctable_OperationListForRoute_out.strOperationNameAttributes[i].routeID.identifier,
//D4100069                                      mainRouteID.identifier ) != 0 )
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V3("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                           "strLctable_OperationListForRoute_out.strOperationNameAttributes[i].routeID != mainRouteID",
//D4100069                                           strLctable_OperationListForRoute_out.strOperationNameAttributes[i].routeID.identifier,
//D4100069                                           mainRouteID.identifier);
//D4100069                        continue;
//D4100069                    }
//D4100069
//D4100069                    /* -------------------------------------------------------------*/
//D4100069                    /*  check whether returnOperationNumber exists or not.          */
//D4100069                    /* -------------------------------------------------------------*/
//D4100069                    if ( CIMFWStrCmp( returnOperationNumber,
//D4100069                                      strLctable_OperationListForRoute_out.strOperationNameAttributes[i].operationNumber ) == 0 )
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                           "strLctable_OperationListForRoute_out.strOperationNameAttributes[i].operationNumber == returnOperationNumber");
//D4100069                        returnOnMainRouteFlag = TRUE;
//D4100069                        break;
//D4100069                    }
//D4100069                }
//D4100069                /* -------------------------------------------------------------*/
//D4100069                /*  returnOperationNumber doesn't exist on MainRoute,           */
//D4100069                /*  return to caller.                                           */
//D4100069                /* -------------------------------------------------------------*/
//D4100069                if ( returnOnMainRouteFlag == FALSE )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                       "returnOnMainRouteFlag == FALSE" );
//D4100069                    PPT_SET_MSG_RC_KEY(strSplitWaferLotReqResult, MSG_NOT_FOUND_RETURN_OPERATION, RC_NOT_FOUND_RETURN_OPERATION,
//D4100069                                       returnOperationNumber);
//D4100069                    return( RC_NOT_FOUND_RETURN_OPERATION );
//D4100069                }
//D4100069            }
//D4100069            /* -------------------------------------------------------------*/
//D4100069            /*  when LotCustomized data doesn't exist.                      */
//D4100069            /* -------------------------------------------------------------*/
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                   "lctable_routeList_LoadDR() != RC_OK", rc);
//D4100069            }
//D4100069        }
//D4100069        /* -------------------------------------------------------------*/
//D4100069        /*  when lot is not on MainRoute.                               */
//D4100069        /* -------------------------------------------------------------*/
//D4100069        else /* lot is not on MainRoute. */
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "currentRouteID != mainRouteID");
//D4100069        }
//D4100069
//D4100069    }
//D4100069
//D4100069//P3100123  add end


//D4100069    if ( checkForLCFRRetCord != RC_OK)                                                                   //(D3000118 D3000119)
//D4100069    {                                                                                                    //(D3000118 D3000119)
//D4100069        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "Lot_CheckForLCFR() checkForLCFRRetCord != RC_OK");
    objLot_futureHoldRequests_CheckSplit_out strLot_futureHoldRequests_CheckSplit ;
    rc = lot_futureHoldRequests_CheckSplit(strLot_futureHoldRequests_CheckSplit,
                                           strObjCommonIn,
                                           parentLotID,
                                           mergedOperationNumber,
                                           returnOperationNumber);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_futureHoldRequests_CheckSplit() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_futureHoldRequests_CheckSplit.strResult ;
        return(rc);
    }
//D4100069     }
//D4100069     else                                                                               //add  (D3000118 D3000119)
//D4100069     {
//D4100069           PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", " checkForLCFRRetCord  == RC_OK");
//D4100069           objLot_futureHoldRequests_CheckSplitForLCFR_out strLot_futureHoldRequests_CheckSplitForLCFR ; //(D3000118 D3000119)
//D4100069           rc = lot_futureHoldRequests_CheckSplitForLCFR(strLot_futureHoldRequests_CheckSplitForLCFR,
//D4100069                                                       strObjCommonIn, parentLotID,mergedRouteID,
//D4100069                                                       mergedOperationNumber, returnOperationNumber);    //(D3000118 D3000119)
//D4100069           if(rc != RC_OK)                                                                               //(D3000118 D3000119)
//D4100069           {
//D4100069               PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                  "lot_futureHoldRequests_CheckSplitForLCFR() rc != RC_OK");             //(D3000118 D3000119)
//D4100069               strSplitWaferLotReqResult.strResult = strLot_futureHoldRequests_CheckSplitForLCFR.strResult ; //(D3000118 D3000119)
//D4100069             return(rc);                                                                                 //(D3000118 D3000119)
//D4100069         }                                                                                               //(D3000118 D3000119)
//D4100069     }
//D4100069
//D4100069//(D3000118 D3000119) add end

//D4100036 start
    /*-------------------------------*/
    /*   Check FlowBatch Condition   */
    /*-------------------------------*/
    PPT_METHODTRACE_V1("", "Check FlowBatch Condition  [ParentLot]") ;
    objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, parentLotID );

    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//P5000145        PPT_SET_MSG_RC_KEY( strSplitWaferLotReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION, "");
        SET_MSG_RC( strSplitWaferLotReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );        //P5000145
        return RC_FLOW_BATCH_LIMITATION;
    }
    else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
    }
    else
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
        strSplitWaferLotReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
        return( rc );
    }
//D4100036 end

//DSN000015229 add start
     if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC015")    //TxPartialOpeCompWithDataReq
       && 0 != CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC016") )  //TxPartialOpeCompForInternalBufferReq
     {
//DSN000015229 add end
//DSIV00000099 add start
//DSN000015229 indent start
        /*------------------------------------------------------------------------*/
        /*   Check if the wafers in lot don't have machine container position     */
        /*------------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("", "call equipmentContainerPosition_info_GetByLotDR()");
        objEquipmentContainerPosition_info_GetByLotDR_out strEquipmentContainerPosition_info_GetByLotDR_out;
        objEquipmentContainerPosition_info_GetByLotDR_in  strEquipmentContainerPosition_info_GetByLotDR_in;
        strEquipmentContainerPosition_info_GetByLotDR_in.lotID = parentLotID;
        rc = equipmentContainerPosition_info_GetByLotDR( strEquipmentContainerPosition_info_GetByLotDR_out,
                                                         strObjCommonIn,
                                                         strEquipmentContainerPosition_info_GetByLotDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_GetByLotDR() != RC_OK", rc);
            strSplitWaferLotReqResult.strResult = strEquipmentContainerPosition_info_GetByLotDR_out.strResult;
            return ( rc );
        }

        CORBA::Long lenEqpContPos = strEquipmentContainerPosition_info_GetByLotDR_out.strEqpContainerPositionSeq.length();
        PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);
        if ( 0 < lenEqpContPos )
        {
            PPT_METHODTRACE_V1("", "Some wafers contained in this lot have equipment container positions.");
            PPT_SET_MSG_RC_KEY( strSplitWaferLotReqResult,
                                MSG_WAFER_IN_LOT_HAVE_CONTAINER_POSITION, RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION,
                                parentLotID.identifier );
            return( RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION );
        }
//DSN000015229 indent end
//DSIV00000099 add end
    } //DSN000015229

//Q3000147 add start
    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, parentLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_controlJobID_Get() != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
//DSN000015229 Add Start
        if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
          && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
        {
//DSN000015229 Add End
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "CIMFWStrLen(controlJobID.identifier) > 0") ;
            PPT_SET_MSG_RC_KEY2( strSplitWaferLotReqResult,
                                 MSG_LOT_CTLJOBID_FILLED,
                                 RC_LOT_CTLJOBID_FILLED,
                                 parentLotID.identifier,
                                 strLot_controlJobID_Get_out.controlJobID.identifier ) ;
            return( RC_LOT_CTLJOBID_FILLED );
        }   //DSN000015229
    }
//Q3000147 add end

    //-------------------------------
    // Check carrier transfer status
    //-------------------------------
    objCassette_transferState_Get_out strCassette_transferState_Get_out;
//D9000038 add start
    if( CIMFWStrLen( aParentCassetteID.identifier ) > 0)
    {
//D9000038 add end
//DSN000071674 add start
        PPT_METHODTRACE_V1("", "CIMFWStrLen( aParentCassetteID.identifier ) > 0");
        if ( 1 == lotOperationEIcheck|| ( 0 == lotOperationEIcheck &&  (0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ) ) )
        {
//DSN000071674 add end
            PPT_METHODTRACE_V1("lotOperationEIcheck", "lotOperationEIcheck_transferState != E0/PI");
            rc = cassette_transferState_Get(strCassette_transferState_Get_out, strObjCommonIn,
                                            aParentCassetteID);
//P4000037    if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut     ) == 0 ||
//P4000037        CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)
//P4000037    {
//P4000037        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "cassette_transferState_Get() !SP_TransState_BayOut || !SP_TransState_EquipmentIn");
//P4000037        strSplitWaferLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
//P4000037        PPT_SET_MSG_RC_KEY2(strSplitWaferLotReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
//P4000037                            strCassette_transferState_Get_out.transferState,
//P4000037                            aParentCassetteID.identifier);
//P4000037        return( RC_INVALID_CAST_XFERSTAT );
//P4000037    }

//P4000037 add start
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "rc != RC_OK");
                strSplitWaferLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                return(rc);
            }
//P4000079    else if(!(CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_EquipmentOut)    == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ManualOut)       == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_IntermediateOut) == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ShelfOut)        == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_UNDEFINED_STATE)            == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_AbnormalOut)     == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_StationOut)      == 0) )
//D4100091    else if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||
//D4100091             CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)         //P4000079

//DSN000071674 add start
            if ( 0 == lotOperationEIcheck )
            {
                PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
                if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )
//D4100091
                {
                    PPT_METHODTRACE_V1("","Changed to EI by other operation");
                    strSplitWaferLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                    PPT_SET_MSG_RC_KEY(strSplitWaferLotReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                       aParentCassetteID.identifier);
                    return( RC_CHANGED_TO_EI_BY_OTHER_OPERATION );
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
                if (( CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut     ) == 0) ||
                    ((CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ) &&
                     (CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004") != 0 ) &&
                     (CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC015") != 0 ) &&    //TxPartialOpeCompWithDataReq              //DSN000015229
                     (CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC016") != 0 ) &&    //TxPartialOpeCompForInternalBufferReq     //DSN000015229
                     (CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC055") != 0 )))                                                     //D4100091
                {
                    PPT_METHODTRACE_V1("","XferState is invalid...");
                    strSplitWaferLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                    PPT_SET_MSG_RC_KEY2(strSplitWaferLotReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                        strCassette_transferState_Get_out.transferState,
                                        aParentCassetteID.identifier);
                    return( RC_INVALID_CAST_XFERSTAT );
                }
//DSN000071674 add start
            }
        }
        if ( 0 == lotOperationEIcheck )
        {
            strCassette_transferState_Get_out = strCassetteTransferState;
        }
//DSN000071674 add end
//P4000037 add end
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "The cassetteID is empty. Skip cassette_transferState_Get().");
    }
//D9000038 add end

//DSN000071674 add start
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
        //-------------------------------
        // Check carrier dispatch status
        //-------------------------------
//D9000038 add start
        if( CIMFWStrLen( aParentCassetteID.identifier ) > 0)
        {
//D9000038 add end
            objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
            strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE; //P3000280
            rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn,
                                            aParentCassetteID);
            if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "cassette_dispatchState_Get() dispatchReservedFlag == TRUE");
                strSplitWaferLotReqResult.strResult = strCassette_dispatchState_Get_out.strResult ;
                SET_MSG_RC(strSplitWaferLotReqResult, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST);
                return( RC_ALREADY_DISPATCH_RESVED_CST );
            }
//D9000038 add start
        }
        else
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "The cassetteID is empty. Skip cassette_dispatchState_Get().");
        }
//D9000038 add end
    } //DSN000071674

    //-------------------------------
    // Check carrier reserved flag
    //-------------------------------
//D9000038 add start
    if( CIMFWStrLen( aParentCassetteID.identifier ) > 0)
    {
//D9000038 add end
        objCassette_reservedState_Get_out strCassette_reservedState_Get_out;
        strCassette_reservedState_Get_out.transferReserved = FALSE; //P3000280
        rc = cassette_reservedState_Get(strCassette_reservedState_Get_out, strObjCommonIn,
                                        aParentCassetteID);
        if (strCassette_reservedState_Get_out.transferReserved == TRUE )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "cassette_reservedState_Get() transferReserved == TRUE");
            strSplitWaferLotReqResult.strResult = strCassette_reservedState_Get_out.strResult ;
            SET_MSG_RC(strSplitWaferLotReqResult, MSG_ALREADY_RESERVED_CST, RC_ALREADY_RESERVED_CST);
            return( RC_ALREADY_RESERVED_CST );
        }
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "The cassetteID is empty. Skip cassette_reservedState_Get().");
    }
//D9000038 add end

    /*------------------------------------------------------------------------*/
    /*   Change State                                                         */
    /*------------------------------------------------------------------------*/
    objLot_SplitWaferLot_out strLot_SplitWaferLot_out ;
    rc = lot_SplitWaferLot(strLot_SplitWaferLot_out, strObjCommonIn,
                           parentLotID, childWaferID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_SplitWaferLot() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_SplitWaferLot_out.strResult ;
        return(rc);
    }
//D4100069 //(D3000118,D3000119) add start
//D4100069   // objLot_CheckForLCFR_out strLot_CheckForLCFR_out ;                                                         //(D3000118 D3000119)
//D4100069   // rc = lot_CheckForLCFR(strLot_CheckForLCFR_out, strObjCommonIn, parentLotID, SP_LotCustmize_DBRECORD);     //(D3000118 D3000119)
//D4100069    if (checkForLCFRRetCord == RC_OK)                                                                           //(D3000118 D3000119)
//D4100069    {                                                                                                           //(D3000118 D3000119)
//D4100069        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_CheckForLCFR() rc == RC_OK");              //(D3000118 D3000119)
//D4100069                                                                                                                //(D3000118 D3000119)
//D4100069        objectIdentifierSequence childLotSeq;                                                                   //(D3000118 D3000119)
//D4100069        childLotSeq.length(1);                                                                                  //(D3000118 D3000119)
//D4100069        childLotSeq[0] = strLot_SplitWaferLot_out.childLotID;                                                   //(D3000118 D3000119)
//D4100069                                                                                                                //(D3000118 D3000119)
//D4100069        objLot_SplitWaferLotForLCFR_out strLot_SplitWaferLotForLCFR_out ;                                       //(D3000118 D3000119)
//D4100069        rc = lot_SplitWaferLotForLCFR(strLot_SplitWaferLotForLCFR_out,                                          //(D3000118 D3000119)
//D4100069                                      strObjCommonIn,                                                           //(D3000118 D3000119)
//D4100069                                      parentLotID,                                                              //(D3000118 D3000119)
//D4100069                                      childLotSeq);                                                             //(D3000118 D3000119)
//D4100069        if ( rc != RC_OK)
//D4100069        {
//D4100069             PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_SplitWaferLotForLCFR() rc != RC_OK"); //(D3000118 D3000119)
//D4100069             //set returned strResult to strResult of out parameter                                             //(D3000118 D3000119)
//D4100069             strSplitWaferLotReqResult.strResult = strLot_SplitWaferLotForLCFR_out.strResult ;                  //(D3000118 D3000119)
//D4100069             return(rc);
//D4100069        }
//D4100069    }
//D4100069    else
//D4100069    {
//D4100069         PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_CheckForLCFR() rc != RC_OK");
//D4100069    }
//D4100069
//D4100069//(D3000118,D3000119) add END

    objectIdentifier aLotID ; // Child Lot ID
    aLotID = strLot_SplitWaferLot_out.childLotID;
    strSplitWaferLotReqResult.childLotID = strLot_SplitWaferLot_out.childLotID;

    objProcess_BranchRoute_out strProcess_BranchRoute_out ;
    if ( branchingRouteSpecifyFlag )
    {

//D4100069    //(D3000118,D3000119) ADD START  01/02/09 P3100060 ADD
//D4100069        /*---------------------------------------------*/
//D4100069        /* Get currentRouteID Check routeID confliction*/
//D4100069        /*---------------------------------------------*/
//D4100069        objLot_currentRouteID_Get_out   strLot_currentRouteID_Get_out;
//D4100069        rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out, strObjCommonIn, aLotID );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069             PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq ",
//D4100069                           "lot_currentRouteID_Get() != RC_OK : ", rc) ;
//D4100069            /* set returned strResult to strResult of out parameter */
//D4100069            strSplitWaferLotReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
//D4100069            return( rc );
//D4100069        }
//D4100069        objectIdentifier    currentRouteID;
//D4100069        currentRouteID = strLot_currentRouteID_Get_out.currentRouteID;
//D4100069
//D4100069        if ( checkForLCFRRetCord == RC_OK)
//D4100069        {
//D4100069            /* ------------------------------------------------------------*/
//D4100069            /* Check routeID confliction                                   */
//D4100069            /*   return RC_INVALID_ROUTEID,                                */
//D4100069            /*   when the same routeID is used in the following case       */
//D4100069            /*       ex) LC-Subroute --> conventional subroute             */
//D4100069            /*       ex) LC-Subroute --> FR-Subroute                       */
//D4100069            /* ------------------------------------------------------------*/
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_originalRouteList_Get IN ");
//D4100069            objLot_originalRouteList_Get_out    strLot_originalRouteList_Get_out;
//D4100069            rc = lot_originalRouteList_Get( strLot_originalRouteList_Get_out,
//D4100069                                            strObjCommonIn,
//D4100069                                            parentLotID);
//D4100069            if ( rc != RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "lot_originalRouteList_Get() != RC_OK", rc);
//D4100069                strSplitWaferLotReqResult.strResult = strLot_originalRouteList_Get_out.strResult ;
//D4100069                return( rc );
//D4100069            }
//D4100069
//D4100069            CORBA::Long kLen = strLot_originalRouteList_Get_out.originalRouteID.length();
//D4100069            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "kLen", kLen);
//D4100069            if( kLen >= 1)
//D4100069            {
//D4100069                 PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "kLen >= 1");
//D4100069                 if(CIMFWStrCmp(strLot_originalRouteList_Get_out.returnOperationNumber[kLen-1] , SP_LotCustomize_Dummy_OperationNumber) ==0)
//D4100069                 {
//D4100069                     PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                        "strLot_originalRouteList_Get_out.returnOperationNumber[kLen-1] == SP_LotCustomize_Dummy_OperationNumber");
//D4100069                     if (kLen >=2)
//D4100069                     {
//D4100069                         PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "kLen >= 2");
//D4100069
//D4100069                         if(CIMFWStrCmp(strLot_originalRouteList_Get_out.originalRouteID[kLen - 2].identifier,subRouteID.identifier ) == 0)
//D4100069                         {
//D4100069                              PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                               "strLot_originalRouteList_Get_out.originalRouteID[kLen - 2] == subRouteID");
//D4100069                              SET_MSG_RC( strSplitWaferLotReqResult, MSG_INVALID_ROUTEID,RC_INVALID_ROUTEID);
//D4100069                              return( RC_INVALID_ROUTEID );
//D4100069                          }
//D4100069                      }
//D4100069                      else
//D4100069                      {
//D4100069                           PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "kLen < 2");
//D4100069                           if(CIMFWStrCmp(currentRouteID.identifier,subRouteID.identifier ) == 0)
//D4100069                           {
//D4100069                              PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq",
//D4100069                                                 "currentRouteID == subRouteID");
//D4100069                              SET_MSG_RC( strSplitWaferLotReqResult, MSG_INVALID_ROUTEID,RC_INVALID_ROUTEID);
//D4100069                              return( RC_INVALID_ROUTEID );
//D4100069                            }
//D4100069                       }
//D4100069                  }
//D4100069             }

//D4100069//P3100128  add start
//D4100069            /* -------------------------------------------------------------------- */
//D4100069            /* If SplitWafer is executed, check returnRouteID and exitRouteID.      */
//D4100069            /* If same RouteID is used as BranchSubRoute,can't execute              */
//D4100069            /* SplitWafer.                                                          */
//D4100069            /* -------------------------------------------------------------------- */
//D4100069            /* --- Get Flexible Rework Data --- */
//D4100069            objFrtable_dbRecord_SelectDR_out    strFrtable_dbRecord_SelectDR_out;
//D4100069            rc = frtable_dbRecord_SelectDR( strFrtable_dbRecord_SelectDR_out,
//D4100069                                                strObjCommonIn,
//D4100069                                                strObjCommonIn.strUser.userID,
//D4100069                                                parentLotID );
//D4100069            /* --- System Error happens, return. --- */
//D4100069            if ( rc == RC_SYSTEM_ERROR )
//D4100069            {
//D4100069                PPT_METHODTRACE_V2( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                    "frtable_dbRecord_SelectDR() != (rc == RC_SYSTEM_ERROR || rc == RC_LOCKED_BY_ANOTHER)",rc );
//D4100069                SET_MSG_RC(strSplitWaferLotReqResult, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
//D4100069                return( RC_SYSTEM_ERROR );
//D4100069            }
//D4100069            else if ( rc == RC_LOCKED_BY_ANOTHER )
//D4100069            {
//D4100069                PPT_METHODTRACE_V2( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                    "frtable_dbRecord_SelectDR() != (rc == RC_SYSTEM_ERROR || rc == RC_LOCKED_BY_ANOTHER)",rc );
//D4100069                SET_MSG_RC(strSplitWaferLotReqResult, MSG_LOCKED_BY_ANOTHER, RC_LOCKED_BY_ANOTHER);
//D4100069                return( RC_LOCKED_BY_ANOTHER );
//D4100069            }
//D4100069            /* --- When Flexible Rework Data exist, check exitRouteID & returnRouteID. --- */
//D4100069            if ( rc != RC_NOT_FOUND_FLEXIBLEREWORK_REC )
//D4100069            {
//D4100069                PPT_METHODTRACE_V1( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                    "frtable_dbRecord_SelectDR() != RC_NOT_FOUND_FLEXIBLEREWORK_REC" );
//D4100069                /* --- Compare returnRouteID of FRWK and subRouteID to Branch. --- */
//D4100069                if ( CIMFWStrCmp( strFrtable_dbRecord_SelectDR_out.returnRouteID.identifier, subRouteID.identifier ) == 0 )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                        "strFrtable_dbRecord_SelectDR_out.returnRouteID == subRouteID" );
//D4100069                    SET_MSG_RC( strSplitWaferLotReqResult, MSG_INVALID_ROUTEID,RC_INVALID_ROUTEID );
//D4100069                    return( RC_INVALID_ROUTEID );
//D4100069                }
//D4100069                else
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2( "CS_PPTManager_i::txSplitWaferLotReq", "parentLotID", parentLotID.identifier );
//D4100069                    PPT_METHODTRACE_V2( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                        "strFrtable_dbRecord_SelectDR_out.returnRouteID",
//D4100069                                        strFrtable_dbRecord_SelectDR_out.returnRouteID.identifier );
//D4100069                    PPT_METHODTRACE_V2( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                        "subRouteID", subRouteID.identifier );
//D4100069                }
//D4100069                /* --- Compare exitRouteID of FRWK and subRouteID to Branch. It is able to execute FRWK only on MainRoute or LC SubRoute.--- */
//D4100069                if ( CIMFWStrCmp( strFrtable_dbRecord_SelectDR_out.exitRouteID.identifier, subRouteID.identifier ) == 0 )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                        "strFrtable_dbRecord_SelectDR_out.exitRouteID == subRouteID" );
//D4100069                    SET_MSG_RC( strSplitWaferLotReqResult, MSG_INVALID_ROUTEID,RC_INVALID_ROUTEID );
//D4100069                    return( RC_INVALID_ROUTEID );
//D4100069                }
//D4100069                else
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2( "CS_PPTManager_i::txSplitWaferLotReq", "parentLotID", parentLotID.identifier );
//D4100069                    PPT_METHODTRACE_V2( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                        "strFrtable_dbRecord_SelectDR_out.exitRouteID",
//D4100069                                        strFrtable_dbRecord_SelectDR_out.exitRouteID.identifier );
//D4100069                    PPT_METHODTRACE_V2( "CS_PPTManager_i::txSplitWaferLotReq",
//D4100069                                        "subRouteID", subRouteID.identifier );
//D4100069                }
//D4100069            }
//D4100069
//D4100069//P3100128  add end

//D4100069        }
//D4100069        //(D3000118,D3000119) ADD END   01/02/09 P3100060 ADD
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "branchingRouteSpecifyFlag")

//DSN000085792 Add start
        objQTime_CheckConditionForReplaceTarget_in strQTime_CheckConditionForReplaceTarget_in;
        objQTime_CheckConditionForReplaceTarget_out strQTime_CheckConditionForReplaceTarget_out;
        strQTime_CheckConditionForReplaceTarget_in.lotID = strLot_SplitWaferLot_out.childLotID;
        rc = qTime_CheckConditionForReplaceTarget(strQTime_CheckConditionForReplaceTarget_out,strObjCommonIn,strQTime_CheckConditionForReplaceTarget_in);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "qTime_CheckConditionForReplaceTarget() != RC_OK") ;
            strSplitWaferLotReqResult.strResult = strQTime_CheckConditionForReplaceTarget_out.strResult ;
            return rc ;
        }
//DSN000085792 Add end

        rc = process_BranchRoute(strProcess_BranchRoute_out, strObjCommonIn,
                                 aLotID, subRouteID, returnOperationNumber);
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "process_BranchRoute() rc != RC_OK");
            strSplitWaferLotReqResult.strResult = strProcess_BranchRoute_out.strResult ;
            return(rc);
        }

//DSN000085792 Add Start
        //--------------------------------------------------------------------------------------------------
        // Replace Target Operation for sub route
        //--------------------------------------------------------------------------------------------------
        objQTime_targetOpe_Replace_out strQTime_targetOpe_Replace_out;
        objQTime_targetOpe_Replace_in  strQTime_targetOpe_Replace_in;
        strQTime_targetOpe_Replace_in.lotID               = strLot_SplitWaferLot_out.childLotID;
        strQTime_targetOpe_Replace_in.specificControlFlag = FALSE;
        rc = qTime_targetOpe_Replace( strQTime_targetOpe_Replace_out,
                                      strObjCommonIn,
                                      strQTime_targetOpe_Replace_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "qTime_targetOpe_Replace() != RC_OK", rc);
            strSplitWaferLotReqResult.strResult = strQTime_targetOpe_Replace_out.strResult;
            return rc;
        }
//DSN000085792 Add End
    }

    // Initialising the Child LotID

    objectIdentifier reasonCodeID ;
    reasonCodeID.identifier = CIMFWStrDup(SP_Reason_MergeHold) ;

    if (futureMergeFlag)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "futureMergeFlag")

//D4100083 Add Start
        pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
        rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
                                      strObjCommonIn ,
                                      SP_HoldType_MergeHold,
                                      parentLotID,
                                      mergedRouteID,
                                      mergedOperationNumber,
                                      reasonCodeID,
                                      aLotID,
                                      FALSE,
                                      FALSE,
                                      NULL ) ;

        if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "txEnhancedFutureHoldReq : rc", rc)
            strSplitWaferLotReqResult.strResult = strEnhancedFutureHoldReqResult.strResult ;
            return rc ;
        }

        pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult1;
        rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult1,
                                      strObjCommonIn ,
                                      SP_HoldType_MergeHold,
                                      aLotID,
                                      mergedRouteID,
                                      mergedOperationNumber,
                                      reasonCodeID,
                                      parentLotID,
                                      FALSE,
                                      FALSE,
                                      NULL ) ;

        if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "txEnhancedFutureHoldReq : rc", rc)
            strSplitWaferLotReqResult.strResult = strEnhancedFutureHoldReqResult1.strResult ;
            return rc ;
        }
//D4100083 Add End

//D4100083        pptFutureHoldReqResult strFutureHoldReqResult ;
// txFutureHoldReq (
//    pptFutureHoldReqResult& strFutureHoldReqResult,
//    const pptObjCommonIn&   strObjCommonIn,
//    const char *            holdType,
//    const objectIdentifier& lotID,
//    const objectIdentifier& routeID,
//    const char *            operationNumber,
//    const objectIdentifier& reasonCodeID,
//    const objectIdentifier& relatedLotID,
//    const char *            claimMemo,
//    CORBA::Environment &IT_env) ;

//D4100083        rc = txFutureHoldReq(strFutureHoldReqResult, strObjCommonIn,
//D4100083                             SP_HoldType_MergeHold, parentLotID, mergedRouteID,
//D4100083                             mergedOperationNumber, reasonCodeID,
//D4100083                             aLotID, NULL);
//D4100083        if( rc )
//D4100083        {
//D4100083            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "txFutureHoldReq : rc", rc)
//D4100083            strSplitWaferLotReqResult.strResult = strFutureHoldReqResult.strResult ;
//D4100083            return rc ;
//D4100083        }
//D4100083        pptFutureHoldReqResult strFutureHoldReqResult1 ;
//D4100083        rc = txFutureHoldReq(strFutureHoldReqResult1, strObjCommonIn,
//D4100083                             SP_HoldType_MergeHold, aLotID, mergedRouteID,
//D4100083                             mergedOperationNumber, reasonCodeID,
//D4100083                             parentLotID, NULL);
//D4100083        if( rc )
//D4100083        {
//D4100083            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "txFutureHoldReq : rc", rc)
//D4100083            strSplitWaferLotReqResult.strResult = strFutureHoldReqResult1.strResult ;
//D4100083            return rc ;
//D4100083        }
    }


    // CORBA::Long lot_MergeHold_Flag = FALSE ;
    objProcess_CompareCurrent_out strProcess_CompareCurrent_out ;
    rc = process_CompareCurrent(strProcess_CompareCurrent_out, strObjCommonIn,
                                parentLotID, mergedRouteID, mergedOperationNumber ) ;
    if( rc == RC_CURRENTOPERATION_SAME )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "process_CompareCurrent() rc == RC_CURRENTOPERATION_SAME");

        pptHoldLotReqResult strHoldLotReqResult ;
        pptHoldListSequence strLotHoldReqList( 1 ) ;
        strLotHoldReqList.length( 1 ) ;

        strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_MergeHold ) ;
        strLotHoldReqList[0].holdReasonCodeID         = reasonCodeID;
        strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].routeID                  = mergedRouteID ;
        strLotHoldReqList[0].operationNumber          = CIMFWStrDup( mergedOperationNumber );
        strLotHoldReqList[0].relatedLotID             = aLotID ;
//PSIV00000186        strLotHoldReqList[0].claimMemo                = CIMFWStrDup( claimMemo );
        strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "" );    //PSIV00000186

        rc = txHoldLotReq(strHoldLotReqResult, strObjCommonIn,
                          parentLotID, strLotHoldReqList) ;
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "txHoldLotReq() rc != RC_OK");
            strSplitWaferLotReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }

        if (!branchingRouteSpecifyFlag)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "!branchingRouteSpecifyFlag");

            strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_MergeHold ) ;
            strLotHoldReqList[0].holdReasonCodeID         = reasonCodeID;
            strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
            strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
            strLotHoldReqList[0].routeID                  = mergedRouteID ;
            strLotHoldReqList[0].operationNumber          = CIMFWStrDup( mergedOperationNumber );
            strLotHoldReqList[0].relatedLotID             = parentLotID ;
//PSIV00000186            strLotHoldReqList[0].claimMemo                = CIMFWStrDup( claimMemo );
            strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "" );    //PSIV00000186

            rc = txHoldLotReq(strHoldLotReqResult, strObjCommonIn,
                              aLotID, strLotHoldReqList) ;
            if (rc)
            {
               PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "txHoldLotReq() rc != RC_OK");
               strSplitWaferLotReqResult.strResult = strHoldLotReqResult.strResult ;
               return rc ;
            }
        }
    }

    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
//D9000038 add start
    if( CIMFWStrCmp( aParentCassetteID.identifier, "") != 0 )
    {
//D9000038 add end
        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn,
                                          aParentCassetteID);
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "cassette_multiLotType_Update() : rc != RC_OK");
            strSplitWaferLotReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
            return(rc);
        }
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "The parent cassetteID is empty. Skip cassette_multiLotType_Update().");
    }
//D9000038 add end

#if 1
//D4000016 Add Start
    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             strLot_SplitWaferLot_out.childLotID );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }
//D4000016 Add end
#endif

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = strLot_SplitWaferLot_out.childLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = aParentCassetteID;

    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        pptHoldListSequence strLotHoldReqList;
        strLotHoldReqList.length( 1 );
        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = CIMFWStrDup("");

        pptHoldLotReqResult strHoldLotReqResult;
        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           strLot_SplitWaferLot_out.childLotID,
                           strLotHoldReqList );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strSplitWaferLotReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End

    //D4100091 add start
    //--------------------------------------------------------
    //   Maintain Loaded Cassette on Eqp Information
    //--------------------------------------------------------
//DSN000015229 Add Start
    if ( 0 < CIMFWStrLen( strLot_controlJobID_Get_out.controlJobID.identifier ) )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0") ;

        // ------------ WARNING --------------------
        // it is assumed that this is called from Partial Operation Completion.
        // So the equipment object is considered locked before this method is called
        // ------------ WARNING --------------------
        objControlJob_attributeInfo_Get_out strControlJob_attributeInfo_Get_out;
        objControlJob_attributeInfo_Get_in  strControlJob_attributeInfo_Get_in;
        strControlJob_attributeInfo_Get_in.controlJobID = strLot_controlJobID_Get_out.controlJobID;

        PPT_METHODTRACE_V1("", "call controlJob_attributeInfo_Get()");
        rc = controlJob_attributeInfo_Get( strControlJob_attributeInfo_Get_out,
                                           strObjCommonIn,
                                           strControlJob_attributeInfo_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "controlJob_attributeInfo_Get() != RC_OK", rc);
            strSplitWaferLotReqResult.strResult = strControlJob_attributeInfo_Get_out.strResult;
            return rc;
        }

        // Update equipment related information
        objEquipment_relatedInfo_UpdateForLotSplitOnEqp_out strEquipment_relatedInfo_UpdateForLotSplitOnEqp_out;
        objEquipment_relatedInfo_UpdateForLotSplitOnEqp_in strEquipment_relatedInfo_UpdateForLotSplitOnEqp_in;
        strEquipment_relatedInfo_UpdateForLotSplitOnEqp_in.equipmentID = strControlJob_attributeInfo_Get_out.strControlJobAttributeInfo.machineID;
        strEquipment_relatedInfo_UpdateForLotSplitOnEqp_in.parentLotID = parentLotID;
        strEquipment_relatedInfo_UpdateForLotSplitOnEqp_in.childLotID  = strLot_SplitWaferLot_out.childLotID;

        rc = equipment_relatedInfo_UpdateForLotSplitOnEqp( strEquipment_relatedInfo_UpdateForLotSplitOnEqp_out,
                                                           strObjCommonIn,
                                                           strEquipment_relatedInfo_UpdateForLotSplitOnEqp_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","equipment_relatedInfo_UpdateForLotSplitOnEqp() != RC_OK", rc);
            strSplitWaferLotReqResult.strResult = strEquipment_relatedInfo_UpdateForLotSplitOnEqp_out.strResult;
            return rc;
        }
    }
//DSN000015229 Add End
//D9000038 add start
    if( CIMFWStrLen( aParentCassetteID.identifier ) > 0)
    {
//D9000038 add end
        PPT_METHODTRACE_V1("", "Maintain Loaded Cassette on Eqp Information...");

//DSN000071674        if ( CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
//DSN000071674 add start
        if ( TRUE == updateControlJobFlag
          || 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )
//DSN000071674 add end
        {
            PPT_METHODTRACE_V1("", "strCassette_transferState_Get_out.transferState is 'EI'...");

            objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;

            objectIdentifierSequence cassetteIDSeq(1);
            cassetteIDSeq.length(1);
            cassetteIDSeq[0] = aParentCassetteID;

            rc = controlJob_relatedInfo_Update( strControlJob_relatedInfo_Update_out,
                                                strObjCommonIn,
                                                cassetteIDSeq );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "controlJob_relatedInfo_Update() rc != RC_OK");
                strSplitWaferLotReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
                return( rc );
            }
        }
    //D4100091 add end
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "The parent cassetteID is empty. Skip controlJob_relatedInfo_Update().");
    }
//D9000038 add end

//PSIV00002201 add start
    //----------------------------------------//
    //    Call lot_inventoryState_Get         //
    //----------------------------------------//
    objLot_inventoryState_Get_out strLot_inventoryState_Get_out;
    rc = lot_inventoryState_Get( strLot_inventoryState_Get_out, strObjCommonIn, aLotID);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inventoryState_Get() != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_inventoryState_Get_out.strResult;
        return( rc );
    }
    else if( CIMFWStrCmp( strLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_InBank ) == 0 )
    {
        PPT_METHODTRACE_V1("", "Lot's inventory state is 'InBank'.")
    }
    else
    {
        PPT_METHODTRACE_V1("", "Lot's inventory state is not 'InBank'. So, txProcessHoldExecReq() is called.")

//D4200029 Add Start
        //------------------------------------//
        //     Process Hold for Child Lot     //
        //------------------------------------//
        PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
        pptProcessHoldExecReqResult strProcessHoldExecReqResult;

        rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                                   strObjCommonIn,
                                   aLotID,
                                   claimMemo );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
            strSplitWaferLotReqResult.strResult = strProcessHoldExecReqResult.strResult ;
            return( rc );
        }
//D4200029 Add End
    }
//PSIV00002201 add end

    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/

    objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                           parentLotID);  //for Parent lot
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult ;
        SET_MSG_RC(strSplitWaferLotReqResult,MSG_FAIL_MAKE_HISTORY, rc) ;
        return(rc);
    }

    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                           aLotID);  //for Child lot
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult ;
        SET_MSG_RC(strSplitWaferLotReqResult,MSG_FAIL_MAKE_HISTORY, rc) ;
        return(rc);
    }

    // 0.01 Start
    //-----------------------------------------------------
    // Prepare input parameter of lotWaferMoveEvent_Make()
    //-----------------------------------------------------
//D9000038    objLot_waferMap_Get_out strLot_waferMap_Get_out;
//D9000038    rc = lot_waferMap_Get(strLot_waferMap_Get_out, strObjCommonIn,
//D9000038                          aLotID);     // for child lot
//D9000038 add start
    objLot_materials_GetWafers_out strLot_materials_GetWafers_out;
    rc = lot_materials_GetWafers( strLot_materials_GetWafers_out,
                                  strObjCommonIn,
                                  aLotID ); // for child lot
//D9000038 add end
    if (rc)
    {
//D9000038         PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_waferMap_Get() rc != RC_OK");
//D9000038         strSplitWaferLotReqResult.strResult = strLot_waferMap_Get_out.strResult ;
//D9000038 add start
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lot_waferMap_Get() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLot_materials_GetWafers_out.strResult ;
//D9000038 add end
        return(rc);
    }

    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
    pptNewLotAttributes           strNewLotAttributes;

    strNewLotAttributes.cassetteID = strLot_cassette_Get_out.cassetteID;
    CORBA::Long i = 0;
//D9000038    CORBA::Long nLen = strLot_waferMap_Get_out.strLotWaferMap.length();
    CORBA::Long nLen = strLot_materials_GetWafers_out.strLotWaferAttributes.length();//D9000038
    strNewLotAttributes.strNewWaferAttributes.length(nLen);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSplitWaferLotReq", "nLen", nLen);
    for (i=0; i<nLen; i++)
    {
        strNewLotAttributes.strNewWaferAttributes[i].newLotID      = strLot_SplitWaferLot_out.childLotID;
//P4200026        strNewLotAttributes.strNewWaferAttributes[i].newWaferID    = childWaferID[i];
//D9000038        strNewLotAttributes.strNewWaferAttributes[i].newWaferID    = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;        //P4200026
//D9000038        strNewLotAttributes.strNewWaferAttributes[i].newSlotNumber = strLot_waferMap_Get_out.strLotWaferMap[i].slotNumber;
        strNewLotAttributes.strNewWaferAttributes[i].newWaferID    = strLot_materials_GetWafers_out.strLotWaferAttributes[i].waferID;    //D9000038
        strNewLotAttributes.strNewWaferAttributes[i].newSlotNumber = strLot_materials_GetWafers_out.strLotWaferAttributes[i].slotNumber; //D9000038
        strNewLotAttributes.strNewWaferAttributes[i].sourceLotID   = parentLotID;
//P4200026        strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = childWaferID[i];
//D9000038        strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;        //P4200026
        strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = strLot_materials_GetWafers_out.strLotWaferAttributes[i].waferID;    //D9000038

        PPT_METHODTRACE_V2("","NewLotID For Event Make ",strNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier);    //P4200026
        PPT_METHODTRACE_V2("","WaferID  For Event Make ",strNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier);  //P4200026
        PPT_METHODTRACE_V2("","SlotNum  For Event Make ",strNewLotAttributes.strNewWaferAttributes[i].newSlotNumber);          //P4200026
        PPT_METHODTRACE_V2("","SrcLot   For Event Make ",strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier); //P4200026
    }
    rc = lotWaferMoveEvent_Make(strLotWaferMoveEvent_Make_out, strObjCommonIn,
                                "TXTRC019",
                                strNewLotAttributes,
                                claimMemo);      //for Child lot  (normalSplit)

        //  transactionID = "TXTRC019"
        //  strNewLotAttributes.cassetteID = cassetteID which is returned from lot_cassette_Get()
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].newLotID = childLotID which is returned from lot_SplitWaferLot()
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].newWaferID = childWaferID[]
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].newSlotNumber = slot number which is returned from lot_waferMap_Get()
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].sourceLotID = parentLotID
        //  strNewLotAttributes.pptNewWaferAttributesSequence[].sourceWaferID = childWaferID[]
        //

    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lotWaferMoveEvent_Make() rc != RC_OK");
        strSplitWaferLotReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult;
        SET_MSG_RC(strSplitWaferLotReqResult,MSG_FAIL_MAKE_HISTORY, rc);
        return(rc);
    }
    // 0.01 End

    if (branchingRouteSpecifyFlag)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "branchingRouteSpecifyFlag");
        //for Child lot
        objLotOperationMoveEvent_MakeBranch_out strLotOperationMoveEvent_MakeBranch_out;
        rc = lotOperationMoveEvent_MakeBranch(strLotOperationMoveEvent_MakeBranch_out, strObjCommonIn,
                                              "TXTRC019", aLotID,
//                                            strProcess_BranchRoute_out.oldCurrentPOS,                        //D4100020 delete
                                              strProcess_BranchRoute_out.oldCurrentPOData,
                                              claimMemo) ;
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSplitWaferLotReq", "lotOperationMoveEvent_MakeBranch() rc != RC_OK");
            SET_MSG_RC(strSplitWaferLotReqResult, MSG_FAIL_MAKE_HISTORY, rc);
            return rc ;
        }
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/

    SET_MSG_RC(strSplitWaferLotReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txSplitWaferLotReq");
    return(RC_OK);
}