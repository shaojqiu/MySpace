#ifndef lint
static char *sccsid =  "@(#) 1.9 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txOpeStartCancelReq__120.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 5/7/08 14:13:04 [ 5/7/08 14:13:05 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: txOpeStartCancelReq__120.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

#include <unistd.h>

// Class: PPTManager
//
// Service: txOpeStartCancelReq__120()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000/08/21            O.Sugiyama     Initial Release
// 2000/09/08 P3000078   O.Sugiyama     loadPurposeType set use =
// 2000/09/21 P3000209   Y.Iwasaki      Change logic for EmptyCassette judgement
// 2000/09/25 P3000223   Y.Iwasaki      Change check condition for lot
// 2000/10/23 P3000280   S.Kawabe       Boolean variable initialize
// 2001/05/23 P3100372   K.Matsuei      Process Monitor Lot can not Ope-Start-Cancel in Batch Eqp.
// 2001/07/05 D4000015   H.Katoh        Add Equipment Category Check Logic because of
//                                      Internal Buffer Support
// 2001/09/03 D4000060   K.Kido         Add retry TCS request logic
// 2002/06/11 P4100536   T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025   T.Nishimura    Source Check : return without message.
// 2004/04/07 D5100232   K.Matsuei      Initial Release. Add DCS Interfact to MM.
// 2004/04/19 D5100088   M.Kase         Add logic for clearing wafer-chamber information
// 2004/08/09 D51M0000   M.Murata       APC I/F Enhance for Interface Spec-B
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/10/31 D7000006   T.Ohsaki       exchange "controlJob_Delete()" to "txControlJobManageReq()"
// 2006/01/19 D7000180   S.Kano         Move "Send to DCS" logic after "Send TCS" logic
// 2006/01/20 D7000182   H.Mutoh        Enhancement of re-sending APCControlJobInformation.
// 2007/04/20 D9000001   H.Murakami     64bit support.
// 2007/06/05 D9000003   M.Nakano       Modify logic to get controlJob info to include processJobExecFlag info.
// 2007/08/01 D9000058   K.Kido         Add logic for clearing process resorce wafer position information
// 2008/05/07 P9000261   M.Ogawa        Change check targets in Off Line-1 mode.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/15 DSIV00000099 F.Chen         SLM(Small Lot Manufacturing) Support.
// 2010/04/16 DSIV00001830 R.Okano        Wafer Stacking Operation Support.
// 2010/10/18 DSIV00002435 M.Ogawa        Support SubLotType change by Schedule Change Reservation
// 2011/08/11 DSN000015229 Sa Guo         equipment_brInfo_GetDR__100 ==> equipment_brInfo_GetDR__120
//                                        Do not delete controlJob object if it is called from partial operation completion
//                                        Do not report controlJob information to APC if it is called from partial operation completion
// 2012/11/28 DSN000049350 F.Chen         Equipment parallel processing support (P2)
// 2013/09/02 DSN000081739 Sa Guo         Equipment Monitor Automation Support
// 2015/07/01 PSN000099815 T.Ishida       Should be clear UsedFlag by OperationStartCancel
// 2015/08/04 DSN000096135 T.Ishida       Virtual Operation
// 2017/05/11 PSN000105025 K.Yamaoku      ImmediateHold is not performed after Operation Start Cancel
// 2017/09/14 INN-R170003  Joan Zhou      INN-R170003:Durable Management Enhancement
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/28 INN-R170003  Joan Zhou      Record WaferCount Decrement
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptOpeStartCancelReqResult&     strOpeStartCancelReqResult
//    const pptObjCommonIn&           strObjCommonIn
//    const objectIdentifier&         equipmentID
//    const objectIdentifier&         controlJobID
//    const char *                    claimMemo
//    pptAPCBaseCassetteSequence&     strAPCBaseCassetteListForOpeStartCancel  //DSN000015229
//    char *&                         APCIFControlStatus
//    char *&                         DCSIFControlStatus
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txOpeStartCancelReq__120 (
    pptOpeStartCancelReqResult&     strOpeStartCancelReqResult,
    const pptObjCommonIn&           strObjCommonIn,
    const objectIdentifier&         equipmentID,
    const objectIdentifier&         controlJobID,
//D6000025     const char *                    claimMemo,
//D6000025     CORBA::Environment &            IT_env)
//D7000182    const char *                    claimMemo  //D6000025
    const char *                    claimMemo,           //D7000182
    pptAPCBaseCassetteSequence&     strAPCBaseCassetteListForOpeStartCancel, //DSN000015229
    char *&                         APCIFControlStatus,  //D7000182
    char *&                         DCSIFControlStatus   //D7000182
    CORBAENV_LAST_CPP)                         //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txOpeStartCancelReq__120");
    CORBA::Long rc = RC_OK ;

    //D4000015 Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strOpeStartCancelReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //D4000015 End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC003" ); // TxOpeStartCancelReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strOpeStartCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strOpeStartCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");

//DSN000049350 Add End
        /*-------------------------*/
        /*   Lock Machine Object   */
        /*-------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Lock Machine Object");

//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "object_Lock() rc != RC_OK");
            strOpeStartCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

//DSIV00000099 add start
    CORBA::Boolean SLMCapabilityFlag = FALSE;
    /*--------------------------------------*/
    /*   Get SLM Switch for the equipment   */
    /*--------------------------------------*/
//DSN000015229    objEquipment_brInfo_GetDR_out__100 strEquipment_brInfo_GetDR_out;
//DSN000015229    objEquipment_brInfo_GetDR_in__100 strEquipment_brInfo_GetDR_in;
//DSN000015229    strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
//DSN000015229    rc = equipment_brInfo_GetDR__100( strEquipment_brInfo_GetDR_out,
//DSN000015229                                      strObjCommonIn,
//DSN000015229                                      strEquipment_brInfo_GetDR_in );
//DSN000015229    if ( rc != RC_OK )
//DSN000015229    {
//DSN000015229        PPT_METHODTRACE_V2("", "##### equipment_brInfo_GetDR__100 != RC_OK", rc);
//DSN000015229        strOpeStartCancelReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
//DSN000015229        return rc;
//DSN000015229    }
//DSN000015229 Add Start
    objEquipment_brInfo_GetDR_out__120 strEquipment_brInfo_GetDR_out;
    objEquipment_brInfo_GetDR_in__100 strEquipment_brInfo_GetDR_in;
    strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
    rc = equipment_brInfo_GetDR__120( strEquipment_brInfo_GetDR_out,
                                      strObjCommonIn,
                                      strEquipment_brInfo_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "##### equipment_brInfo_GetDR__120 != RC_OK", rc);
        strOpeStartCancelReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
        return rc;
    }
//DSN000015229 Add End
    PPT_METHODTRACE_V2("", "SLMCapabilityFlag ", (strEquipment_brInfo_GetDR_out.equipmentBRInfo.SLMCapabilityFlag?"TRUE":"FALSE"));

    // Check SLM Capability
    if( strEquipment_brInfo_GetDR_out.equipmentBRInfo.SLMCapabilityFlag == TRUE)
    {
        PPT_METHODTRACE_V1("", "SLM Capability is TRUE. ");
        SLMCapabilityFlag = TRUE;
    }
    PPT_METHODTRACE_V2("", "##### SLMCapabilityFlag = ", SLMCapabilityFlag );

    if (SLMCapabilityFlag == TRUE)
    {
        //----------------------------------------------------------------
        //  object_Lock for Equipment Container Position by ControlJob
        //----------------------------------------------------------------
        objectIdentifier         dummyID;
        pptStartCassetteSequence dummyStartCassetteSeq;

        objObject_LockForEquipmentContainerPosition_in strObject_LockForEquipmentContainerPosition_in;
        strObject_LockForEquipmentContainerPosition_in.equipmentID         = equipmentID;
        strObject_LockForEquipmentContainerPosition_in.strStartCassette    = dummyStartCassetteSeq;
        strObject_LockForEquipmentContainerPosition_in.controlJobID        = controlJobID;
        strObject_LockForEquipmentContainerPosition_in.destCassetteID      = dummyID;
        strObject_LockForEquipmentContainerPosition_in.waferID             = dummyID;

        PPT_METHODTRACE_V1("", "call object_LockForEquipmentContainerPosition()");
        objObject_LockForEquipmentContainerPosition_out strObject_LockForEquipmentContainerPosition_out;
        rc = object_LockForEquipmentContainerPosition( strObject_LockForEquipmentContainerPosition_out,
                                                       strObjCommonIn,
                                                       strObject_LockForEquipmentContainerPosition_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_LockForEquipmentContainerPosition() rc != RC_OK, rc = ", rc);
            strOpeStartCancelReqResult.strResult = strObject_LockForEquipmentContainerPosition_out.strResult;
            return( rc );
        }
        //----------------------------------------------------------
        //  Get equipmentContainer position objects by controlJobID
        //----------------------------------------------------------
        objEquipmentContainerPosition_info_Get_in strEquipmentContainerPosition_info_Get_in;
        strEquipmentContainerPosition_info_Get_in.equipmentID = equipmentID;
        strEquipmentContainerPosition_info_Get_in.key         = controlJobID;
        strEquipmentContainerPosition_info_Get_in.keyCategory = CIMFWStrDup( SP_SLM_KeyCategory_ControlJob );

        PPT_METHODTRACE_V1("", "call equipmentContainerPosition_info_Get()");
        objEquipmentContainerPosition_info_Get_out strEquipmentContainerPosition_info_Get_out;
        rc = equipmentContainerPosition_info_Get( strEquipmentContainerPosition_info_Get_out,
                                                  strObjCommonIn,
                                                  strEquipmentContainerPosition_info_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_Get() rc != RC_OK, rc = ", rc);
            strOpeStartCancelReqResult.strResult = strEquipmentContainerPosition_info_Get_out.strResult;
            return( rc );
        }

        CORBA::ULong pstLen = 0;
        CORBA::ULong nCnt1  = 0;
        CORBA::ULong nCnt2  = 0;
        pstLen = strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq.length();
        PPT_METHODTRACE_V2("", "pstLen = ", pstLen);

//DSN000015229 add start
        if ( 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC015")    //TxPartialOpeCompWithDataReq
          || 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC016") )  //TxPartialOpeCompForInternalBufferReq
        {
            PPT_METHODTRACE_V2("", "PartialOpeComp : TxID == ",strObjCommonIn.transactionID);
            //----------------------------------------------------------
            //  Filtering for Partial OpeComp
            //----------------------------------------------------------
            pptEqpContainerPositionSequence strEqpContainerPositionSeq;
            CORBA::ULong nEqpContainerPositionCnt = 0;
            strEqpContainerPositionSeq.length(pstLen);
            for( nCnt1 = 0; nCnt1 < pstLen; nCnt1++ )
            {
                PPT_METHODTRACE_V2("", "# Loop[nCnt1], nCnt1 = ", nCnt1);
                if ( 0 < CIMFWStrLen( strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq[nCnt1].controlJobID.identifier ) )
                {
                    PPT_METHODTRACE_V2("", "0 < CIMFWStrLen(controlJobID.identifier)", strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq[nCnt1].waferID.identifier);
                    strEqpContainerPositionSeq[nEqpContainerPositionCnt++] = strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq[nCnt1];
                }
            }
            strEqpContainerPositionSeq.length(nEqpContainerPositionCnt);
            strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq = strEqpContainerPositionSeq;

            pstLen = strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq.length();
            PPT_METHODTRACE_V2("", "pstLen", pstLen);
        }
//DSN000015229 add end

        if (pstLen > 0)
        {
            PPT_METHODTRACE_V2("", "pstLen", pstLen);
            pptEqpContainerPosition tmpStrEqpContainerPosition;

            // --------------------------------------------------------------
            // If all wafers in a lot are "Stored" and equipment is online,
            // destination cassette is required
            // --------------------------------------------------------------

            objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
            PPT_METHODTRACE_V1("", "call equipment_portInfo_GetDR()...");
            rc = equipment_portInfo_GetDR(strEquipment_portInfo_GetDR_out, strObjCommonIn, equipmentID);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "equipment_portInfo_GetDR() != RC_OK" );
                strOpeStartCancelReqResult.strResult = strEquipment_portInfo_GetDR_out.strResult;
                return( rc );
            }
            if (CIMFWStrCmp(strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[0].onlineMode, SP_Eqp_OnlineMode_Offline) != 0)
            {
                PPT_METHODTRACE_V1("", "equipment is NOT offline");
                objectIdentifierSequence checkedLotList;
                CORBA::ULong checkedLotListLen = 0;
                checkedLotList.length(checkedLotListLen);

                pptEqpContainerPosition tmpStrEqpContainerPosition2;

                for( nCnt1 = 0; nCnt1 < pstLen; nCnt1++ )
                {
                    PPT_METHODTRACE_V2("", "# Loop[nCnt1], nCnt1 = ", nCnt1);
                    tmpStrEqpContainerPosition = strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq[nCnt1];
                    for( nCnt2 = 0; nCnt2 < checkedLotListLen; nCnt2++ )
                    {
                        PPT_METHODTRACE_V3("", "## Loop[nCnt2], lotID = ", nCnt2, checkedLotList[nCnt2].identifier);
                        if (CIMFWStrCmp (checkedLotList[nCnt2].identifier, tmpStrEqpContainerPosition.lotID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V2("", "## lot is already in list", checkedLotList[nCnt2].identifier);
                            break;
                        }
                    }
                    if (nCnt2 == checkedLotListLen)
                    {
                        // this is a not checked lot
                        PPT_METHODTRACE_V2("", "# New Lot = ", tmpStrEqpContainerPosition.lotID.identifier);
                        if (CIMFWStrCmp(tmpStrEqpContainerPosition.SLMState, SP_SLMState_Stored) == 0)
                        {
                            // check if all wafers in this lot is stored
                            for( nCnt2 = 0; nCnt2 < pstLen; nCnt2++ )
                            {
                                PPT_METHODTRACE_V2("", "## Loop[nCnt2], nCnt2 = ", nCnt2);
                                tmpStrEqpContainerPosition2 = strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq[nCnt2];
                                if (CIMFWStrCmp (tmpStrEqpContainerPosition.lotID.identifier, tmpStrEqpContainerPosition2.lotID.identifier) == 0)
                                {
                                    PPT_METHODTRACE_V2("", "## found lot", tmpStrEqpContainerPosition.lotID.identifier);
                                    if (CIMFWStrCmp(tmpStrEqpContainerPosition2.SLMState, SP_SLMState_Stored) != 0)
                                    {
                                        // not all wafers in this lot are stored
                                        PPT_METHODTRACE_V2("", "## Not all wafers in this lot are stored", tmpStrEqpContainerPosition.lotID.identifier);
                                        break;
                                    }
                                }
                            }
                            if (nCnt2 == pstLen)
                            {
                                // all wafers in this lot are stored
                                PPT_METHODTRACE_V2("", "# All wafers in this lot are stored", tmpStrEqpContainerPosition.lotID.identifier);
                                if (CIMFWStrLen(tmpStrEqpContainerPosition.destCassetteID.identifier) == 0)
                                {
                                    PPT_METHODTRACE_V2("", "# destCast is NOT registered for lot, lotID = ", tmpStrEqpContainerPosition.lotID.identifier);
                                    PPT_SET_MSG_RC_KEY(strOpeStartCancelReqResult,
                                                       MSG_SLM_DEST_CAST_UNDEFINED, RC_SLM_DEST_CAST_UNDEFINED,
                                                       tmpStrEqpContainerPosition.lotID.identifier);
                                    return RC_SLM_DEST_CAST_UNDEFINED;
                                }
                                else
                                {
                                    PPT_METHODTRACE_V3("", "# destCast is registered for lot, lotID; destCastID ",
                                                            tmpStrEqpContainerPosition.lotID.identifier,
                                                            tmpStrEqpContainerPosition.destCassetteID.identifier);
                                }
                            }
                        }
                        PPT_METHODTRACE_V2("", "# Add Lot to checkedLotList = ", tmpStrEqpContainerPosition.lotID.identifier);
                        checkedLotListLen++;
                        checkedLotList.length(checkedLotListLen);
                        checkedLotList[checkedLotListLen-1] = tmpStrEqpContainerPosition.lotID;
                    }
                }
            }

            // --------------------------------------------------------------
            // Get Destination Cassette List.
            // These cassettes should be locked before update
            // --------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Get Destination Cassette List");
            objectIdentifierSequence destCassetteList;
            CORBA::ULong destCassetteListLen = 0;
            destCassetteList.length(destCassetteListLen);

            for( nCnt1 = 0; nCnt1 < pstLen; nCnt1++ )
            {
                PPT_METHODTRACE_V2("", "# Loop[nCnt1], nCnt1 = ", nCnt1);
                tmpStrEqpContainerPosition = strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq[nCnt1];
                if (CIMFWStrLen(tmpStrEqpContainerPosition.destCassetteID.identifier) > 0)
                {
                    PPT_METHODTRACE_V2("", "# destCassetteID = ", tmpStrEqpContainerPosition.destCassetteID.identifier);
                    // destination cassette is assigned
                    if (CIMFWStrCmp(tmpStrEqpContainerPosition.SLMState, SP_SLMState_Reserved) == 0 ||
                        CIMFWStrCmp(tmpStrEqpContainerPosition.SLMState, SP_SLMState_Retrieved) == 0)
                    {
                        for( nCnt2 = 0; nCnt2 < destCassetteListLen; nCnt2++ )
                        {
                            PPT_METHODTRACE_V3("", "## Loop[nCnt2], cassetteID = ", nCnt2, destCassetteList[nCnt2].identifier);
                            if (CIMFWStrCmp (destCassetteList[nCnt2].identifier, tmpStrEqpContainerPosition.destCassetteID.identifier) == 0)
                            {
                                // found destnationCast
                                PPT_METHODTRACE_V2("", "## destinationCast is already in list", destCassetteList[nCnt2].identifier);
                                break;
                            }
                        }
                        if (nCnt2 == destCassetteListLen)
                        {
                            PPT_METHODTRACE_V1("", "# nCnt2 == destCassetteListLen ");

                            // new destcassette
                            destCassetteListLen++;
                            destCassetteList.length(destCassetteListLen);
                            destCassetteList[destCassetteListLen-1] = tmpStrEqpContainerPosition.destCassetteID;
                        }
                    }
                }
            }

            // Object Lock
            for( nCnt1 = 0; nCnt1 < destCassetteListLen; nCnt1++ )
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt1], cassetteID = ", nCnt1, destCassetteList[nCnt1].identifier);
                // lock the cassette
                objObject_Lock_out strCast_Object_Lock_out;
                rc = object_Lock( strCast_Object_Lock_out, strObjCommonIn, destCassetteList[nCnt1], SP_ClassName_PosCassette );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "# object_Lock(tmpDestCassetteID) != RC_OK" );
                    strOpeStartCancelReqResult.strResult = strCast_Object_Lock_out.strResult;
                    return( rc );
                }
            }

            //----------------------------------------------------------------
            //  Update equipment container position for operationCancel
            //----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "call equipmentContainerPosition_UpdateForOpeStartCancel()");
            objEquipmentContainerPosition_UpdateForOpeStartCancel_in strEquipmentContainerPosition_UpdateForOpeStartCancel_in;
            strEquipmentContainerPosition_UpdateForOpeStartCancel_in.equipmentID    = equipmentID;
            strEquipmentContainerPosition_UpdateForOpeStartCancel_in.controlJobID   = controlJobID;

            objEquipmentContainerPosition_UpdateForOpeStartCancel_out strEquipmentContainerPosition_UpdateForOpeStartCancel_out;
            rc = equipmentContainerPosition_UpdateForOpeStartCancel( strEquipmentContainerPosition_UpdateForOpeStartCancel_out,
                                                                     strObjCommonIn,
                                                                     strEquipmentContainerPosition_UpdateForOpeStartCancel_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipmentContainerPosition_UpdateForOpeStartCancel() rc != RC_OK, rc = ", rc);
                strOpeStartCancelReqResult.strResult = strEquipmentContainerPosition_UpdateForOpeStartCancel_out.strResult;
                return( rc );
            }
        } //if (pstLen > 0)

    }
//DSIV00000099 Add End

    /*-------------------------*/
    /*   Get ControlJob Info   */
    /*-------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Get ControlJob Info");

//D9000003 delete start
//    objControlJob_containedLot_Get_out strControlJob_containedLot_Get_out;
//    rc = controlJob_containedLot_Get( strControlJob_containedLot_Get_out, strObjCommonIn,
//                                      controlJobID );
//    if ( rc != RC_OK )
//    {
//        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq", "controlJob_containedLot_Get() rc != RC_OK");
//        strOpeStartCancelReqResult.strResult = strControlJob_containedLot_Get_out.strResult;
//        return( rc );
//    }
//D9000003 delete end
//D9000003 add start
    objControlJob_startReserveInformation_Get_out strControlJob_startReserveInformation_Get_out;
    rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out, strObjCommonIn,
                                      controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "controlJob_startReserveInformation_Get() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult;
        return( rc );
    }
//D9000003 add end

    /*---------------------------------------------------*/
    /*   Prepare strStartCassette for Working-Valiable   */
    /*---------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Prepare strStartCassette for Working-Valiable");

    CORBA::Long scLen = 0;
    CORBA::Long lcLen = 0;

//D9000003    scLen = strControlJob_containedLot_Get_out.strControlJobCassette.length();
    pptStartCassetteSequence  strStartCassette;
//D9000003 delete start
//    strStartCassette.length(scLen);
//
//    //P4100536 add start
//    // Check length of Cassette
//    if(0 >= strStartCassette.length())
//    {
//        PPT_SET_MSG_RC_KEY(strOpeStartCancelReqResult, MSG_NOT_FOUND_CASSETTE, RC_NOT_FOUND_CASSETTE, "(There is no started cassette.)"); //P4200025 add
//        return RC_NOT_FOUND_CASSETTE;
//    }
//    //P4100536 add end
//D9000003 delete end
    CORBA::Long i = 0;
//D9000003 delete start
//    PPT_METHODTRACE_V2("PPTManager_i:: txOpeStartCancelReq", "scLen = ", scLen);
//    for ( i=0 ; i<scLen ; i++ )
//    {
//        strStartCassette[i].loadSequenceNumber = strControlJob_containedLot_Get_out.strControlJobCassette[i].loadSequenceNumber;
//        strStartCassette[i].cassetteID         = strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID;
////P3000078  CIMFWStrCpy(strStartCassette[i].loadPurposeType, strControlJob_containedLot_Get_out.strControlJobCassette[i].loadPurposeType);
//        strStartCassette[i].loadPurposeType    = strControlJob_containedLot_Get_out.strControlJobCassette[i].loadPurposeType; //P3000078
//        strStartCassette[i].loadPortID         = strControlJob_containedLot_Get_out.strControlJobCassette[i].loadPortID;
//        strStartCassette[i].unloadPortID       = strControlJob_containedLot_Get_out.strControlJobCassette[i].unloadPortID;
//
//        lcLen = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot.length();
//        strStartCassette[i].strLotInCassette.length(lcLen);
//
//        CORBA::Long j = 0;
//        PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq", "lcLen = ", lcLen, i);
//        for ( j=0 ; j<lcLen ; j++ )
//        {
//            strStartCassette[i].strLotInCassette[j].operationStartFlag = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].operationStartFlag;
//            strStartCassette[i].strLotInCassette[j].monitorLotFlag     = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag;
//            strStartCassette[i].strLotInCassette[j].lotID              = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].lotID;
//        }
//    }
//D9000003 delete end
//D9000003 add start
    strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette ;
    scLen = strStartCassette.length();
//D9000003 add end

//DSN000096135 Add Start
    CORBA::Boolean virtualOperationFlag = FALSE;

    objVirtualOperation_CheckByStartCassette_out strVirtualOperation_CheckByStartCassette_out;
    objVirtualOperation_CheckByStartCassette_in  strVirtualOperation_CheckByStartCassette_in;

    strVirtualOperation_CheckByStartCassette_in.strStartCassette = strStartCassette;

    rc = virtualOperation_CheckByStartCassette( strVirtualOperation_CheckByStartCassette_out, strObjCommonIn, strVirtualOperation_CheckByStartCassette_in );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "virtualOperation_CheckByStartCassette() != RC_OK" );
        strOpeStartCancelReqResult.strResult = strVirtualOperation_CheckByStartCassette_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "virtualOperationFlag = ", strVirtualOperation_CheckByStartCassette_out.virtualOperationFlag );
    virtualOperationFlag = strVirtualOperation_CheckByStartCassette_out.virtualOperationFlag;

//DSN000096135 Add End

    /*--------------------------------*/
    /*   Lock Cassette / Lot Object   */
    /*--------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Lock Cassette / Lot Object");
    PPT_METHODTRACE_V2("PPTManager_i:: txOpeStartCancelReq__120", "scLen = ", scLen);

//DSN000049350 Add Start
    objectIdentifierSequence lotIDs;
    objectIdentifierSequence cassetteIDs;
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_lotIDLen    = extendLen;
    CORBA::ULong lotIDCnt      = 0;
    CORBA::ULong cassetteIDCnt = 0;
    lotIDs.length(t_lotIDLen);
    cassetteIDs.length(scLen);
//DSN000049350 Add End

    for ( i=0 ; i<scLen ; i++ )
    {
        if (CIMFWStrLen(strStartCassette[i].cassetteID.identifier) != 0 || SLMCapabilityFlag == FALSE)  //DSIV00000099
        {                                                                                               //DSIV00000099
//DSN000049350            /*--------------------------*/
//DSN000049350            /*   Lock Cassette Object   */
//DSN000049350            /*--------------------------*/
//DSN000049350            PPT_METHODTRACE_V2("PPTManager_i:: txOpeStartCancelReq__120", "Lock Cassette Object", i);
//DSN000049350
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350                              strStartCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V2("PPTManager_i:: txOpeStartCancelReq__120", "object_Lock() rc != RC_OK", i);
//DSN000049350                strOpeStartCancelReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350                return( rc );
//DSN000049350            }

            cassetteIDs[cassetteIDCnt++] = strStartCassette[i].cassetteID;  //DSN000049350
        }                                                                                               //DSIV00000099

        CORBA::Long j = 0;
        lcLen = strStartCassette[i].strLotInCassette.length();
        for ( j=0 ; j<lcLen ; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Omit Not-OpeStart Lot", i, j);

            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

//DSN000049350            /*---------------------*/
//DSN000049350            /*   Lock Lot Object   */
//DSN000049350            /*---------------------*/
//DSN000049350            PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Lock Lot Object", i, j);
//DSN000049350
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350                              strStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "object_Lock() rc != RC_OK", i, j);
//DSN000049350                strOpeStartCancelReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350                return( rc );
//DSN000049350            }
//DSN000049350 Add Start
            if( lotIDCnt >= t_lotIDLen )
            {
                PPT_METHODTRACE_V1("", "lotIDCnt >= t_lotIDLen");
                t_lotIDLen += extendLen;
                lotIDs.length( t_lotIDLen );
            }
            lotIDs[lotIDCnt++] = strStartCassette[i].strLotInCassette[j].lotID;
//DSN000049350 Add End
        }
    }
    cassetteIDs.length(cassetteIDCnt);                          //DSN000049350
    lotIDs.length(lotIDCnt);                                    //DSN000049350
    PPT_METHODTRACE_V2( "", "cassetteIDCnt  ", cassetteIDCnt);  //DSN000049350
    PPT_METHODTRACE_V2( "", "lotIDCnt       ", lotIDCnt);       //DSN000049350

//DSN000049350 Add Start
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
        rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out, strObjCommonIn, equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
            strOpeStartCancelReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
            return rc;
        }
        
        if ( 0 == CIMFWStrCmp( strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline ) )
        {
            // Lock Equipment ProcLot Element (Count)
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_COUNT;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                       strObjCommonIn,
                                       strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strOpeStartCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
        // Lock Equipment ProcLot Element (Write)
        CORBA::ULong lotIDLen = lotIDs.length();
        stringSequence procLotSeq;
        procLotSeq.length(lotIDLen);
        for (i=0; i<lotIDLen; i++)
        {
            procLotSeq[i] = lotIDs[i].identifier;
        }
        
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
        strAdvanced_object_Lock_in.keySeq     = procLotSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strOpeStartCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }   
             
        CORBA::ULong cassetteLen = cassetteIDs.length();
        cassetteIDCnt = 0;
        stringSequence loadCastSeq;
        loadCastSeq.length(cassetteLen);
        
        for ( i = 0; i < cassetteLen; i++ )
        {
            objCassette_LocationInfo_GetDR_out  strCassette_LocationInfo_GetDR_out;
            PPT_METHODTRACE_V2( "", "calling cassette_LocationInfo_GetDR()", cassetteIDs[i].identifier );
            rc = cassette_LocationInfo_GetDR( strCassette_LocationInfo_GetDR_out,
                                              strObjCommonIn,
                                              cassetteIDs[i]);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "cassette_LocationInfo_GetDR() != RC_OK", rc );
                strOpeStartCancelReqResult.strResult = strCassette_LocationInfo_GetDR_out.strResult;
                return( rc );
            }
            
            PPT_METHODTRACE_V2( "", "transferStatus", strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus );
            if (0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentIn)
                && 0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID.identifier,equipmentID.identifier))
            {
                // this cassette is load on equipment
                loadCastSeq[cassetteIDCnt++] = cassetteIDs[i].identifier;
            }
        }
        loadCastSeq.length(cassetteIDCnt);
        // Lock Equipment LoadCassette Element (Read)
        if ( 0 < loadCastSeq.length() )
        {
            PPT_METHODTRACE_V2( "", "loadCastSeq.length", loadCastSeq.length() );
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_READ;
            strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strOpeStartCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }

        /*------------------------------*/
        /*   Lock ControlJob Object     */
        /*------------------------------*/
        PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosControlJob );
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          controlJobID,
                          SP_ClassName_PosControlJob );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strOpeStartCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }  
    }
    /*------------------------------*/
    /*   Lock Cassette/Lot Object   */
    /*-------------------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strOpeStartCancelReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosLot );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              lotIDs,
                              SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strOpeStartCancelReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

//DSN000081739 Add Start
    CORBA::Long eqpMonitorSwitch = atoi( getenv(SP_EQPMONITOR_SWITCH) );
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        objectIdentifierSequence eqpMonitorList;
        CORBA::ULong eqpMonitorCnt = 0;
        CORBA::ULong eqpMonitorLen = 5;
        eqpMonitorList.length(eqpMonitorLen);
        pptEqpMonitorJobInfoSequence strEqpMonitorJobInfoSeq;
        CORBA::ULong eqpMonJobCnt = 0;
        CORBA::ULong eqpMonJobLen = 5;
        strEqpMonitorJobInfoSeq.length(eqpMonJobLen);
        CORBA::ULong castLen = strStartCassette.length();
        for ( i=0; i<castLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop to strStartCassette.length()", i);
            CORBA::ULong lotLen = strStartCassette[i].strLotInCassette.length();
            for ( CORBA::ULong j=0; j<lotLen; j++ )
            {
                PPT_METHODTRACE_V2("", "loop to strStartCassette[i].strLotInCassette.length()", j);
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if ( FALSE == strStartCassette[i].strLotInCassette[j].operationStartFlag )
                {
                    PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE, continue");
                    continue;
                }

                if ( 0 != CIMFWStrCmp(strStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_EquipmentMonitorLot)
                  && 0 != CIMFWStrCmp(strStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_DummyLot) )
                {
                    PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].lotType is not Equipment Monitor and Dummy, continue");
                    continue;
                }

                objLot_eqpMonitorSectionInfo_GetForJob_out strLot_eqpMonitorSectionInfo_GetForJob_out;
                objLot_eqpMonitorSectionInfo_GetForJob_in  strLot_eqpMonitorSectionInfo_GetForJob_in;
                strLot_eqpMonitorSectionInfo_GetForJob_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;
                rc = lot_eqpMonitorSectionInfo_GetForJob( strLot_eqpMonitorSectionInfo_GetForJob_out,
                                                          strObjCommonIn,
                                                          strLot_eqpMonitorSectionInfo_GetForJob_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_eqpMonitorSectionInfo_GetForJob() != RC_OK", rc);
                    strOpeStartCancelReqResult.strResult = strLot_eqpMonitorSectionInfo_GetForJob_out.strResult;
                    return rc;
                }

                if ( 0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier )");
                    if ( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor) )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor");
                        CORBA::Boolean bNewEqpMonitor = TRUE;
                        for ( CORBA::ULong iCnt1=0; iCnt1<eqpMonitorCnt; iCnt1++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to eqpMonitorCnt", iCnt1);
                            if ( 0 == CIMFWStrCmp(eqpMonitorList[iCnt1].identifier, strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonitorList[iCnt1].identifier == strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier");
                                bNewEqpMonitor = FALSE;
                                break;
                            }
                        }

                        if ( TRUE == bNewEqpMonitor )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == bNewEqpMonitor");
                            if ( eqpMonitorCnt > eqpMonitorLen )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonitorCnt > eqpMonitorLen");
                                eqpMonitorLen = eqpMonitorLen + 5;
                                eqpMonitorList.length(eqpMonitorLen);
                            }
                            eqpMonitorList[eqpMonitorCnt] = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;

                            eqpMonitorCnt++;
                        }
                    }

                    if ( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor)
                      || TRUE == strLot_eqpMonitorSectionInfo_GetForJob_out.exitFlag )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor or strLot_eqpMonitorSectionInfo_GetForJob_out.exitFlag is TRUE");
                        CORBA::Boolean bNewEqpMonJob = TRUE;
                        for ( CORBA::ULong iCnt2=0; iCnt2<eqpMonJobCnt; iCnt2++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to eqpMonJobCnt", iCnt2);
                            if ( 0 == CIMFWStrCmp(strEqpMonitorJobInfoSeq[iCnt2].eqpMonitorJobID.identifier,
                                                  strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "strEqpMonitorJobInfoSeq[iCnt2].eqpMonitorJobID.identifier == strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier");
                                bNewEqpMonJob = FALSE;
                                break;
                            }
                        }

                        if ( TRUE == bNewEqpMonJob )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == bNewEqpMonJob");
                            if ( eqpMonJobCnt > eqpMonJobLen )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonJobCnt > eqpMonJobLen");
                                eqpMonJobLen = eqpMonJobLen + 5;
                                strEqpMonitorJobInfoSeq.length(eqpMonJobLen);
                            }
                            strEqpMonitorJobInfoSeq[eqpMonJobCnt].eqpMonitorJobID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID;
                            strEqpMonitorJobInfoSeq[eqpMonJobCnt].eqpMonitorID    = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;

                            eqpMonJobCnt++;
                        }
                    }
                }
            }
        }
        eqpMonitorList.length(eqpMonitorCnt);
        strEqpMonitorJobInfoSeq.length(eqpMonJobCnt);
        for ( CORBA::ULong iCnt3=0; iCnt3<eqpMonitorCnt; iCnt3++ )
        {
            PPT_METHODTRACE_V2("", "loop to eqpMonitorCnt", iCnt3);
            //Lock EqpMonitor object
            objObject_Lock_out strObject_Lock_out;
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, eqpMonitorList[iCnt3], SP_ClassName_PosEqpMonitor );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2(" ", "##### RC_OK != object_Lock()", rc);
                strOpeStartCancelReqResult.strResult = strObject_Lock_out.strResult;
                return rc;
            }
        }

        for ( CORBA::ULong iCnt4=0; iCnt4<eqpMonJobCnt; iCnt4++ )
        {
            PPT_METHODTRACE_V2("", "loop to eqpMonJobCnt", iCnt4);
            //Lock EqpMonitor job object
            objObject_LockForEqpMonitorJob_out strObject_LockForEqpMonitorJob_out;
            objObject_LockForEqpMonitorJob_in  strObject_LockForEqpMonitorJob_in;
            strObject_LockForEqpMonitorJob_in.eqpMonitorID    = strEqpMonitorJobInfoSeq[iCnt4].eqpMonitorID;
            strObject_LockForEqpMonitorJob_in.eqpMonitorJobID = strEqpMonitorJobInfoSeq[iCnt4].eqpMonitorJobID;
            rc = object_LockForEqpMonitorJob( strObject_LockForEqpMonitorJob_out,
                                              strObjCommonIn,
                                              strObject_LockForEqpMonitorJob_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEqpMonitorJob() != RC_OK", rc);
                strOpeStartCancelReqResult.strResult = strObject_LockForEqpMonitorJob_out.strResult;
                return rc;
            }
        }
    }
//DSN000081739 Add End

//D51M0000 add start
    /*-----------------------------------------*/
    /*   call cassette_APCInformation_GetDR    */
    /*-----------------------------------------*/
    PPT_METHODTRACE_V1("", " call cassette_APCInformation_GetDR");
    objCassette_APCInformation_GetDR_out strCassette_APCInformation_GetDR_out;
    rc = cassette_APCInformation_GetDR(  strCassette_APCInformation_GetDR_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         strStartCassette);
    if ( rc == RC_SYSTEM_ERROR )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() == RC_SYSTEM_ERROR");
        strOpeStartCancelReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
        return ( rc );
    }
    else if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() != RC_OK");
        strOpeStartCancelReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
    }
//D51M0000 add end

//DSIV00000099 Add Start
    CORBA::String_var accessMode = CIMFWStrDup ("");
    CORBA::String_var onlineMode = CIMFWStrDup ("");
    objectIdentifier operationMode;

    if (CIMFWStrLen(strStartCassette[0].cassetteID.identifier) > 0)
    {
//DSIV00000099 Add End
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Check Process                                                       */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        if( virtualOperationFlag == FALSE )    //DSN000096135
        {                                      //DSN000096135
            //P3000223 add start (move)
            /*---------------------------------*/
            /*   Get Equipment's Online Mode   */
            /*---------------------------------*/
            objPortResource_currentOperationMode_Get_out  strPortResource_currentOperationMode_Get_out;
            rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                        strObjCommonIn,
                                                        equipmentID,
                                                        strStartCassette[0].unloadPortID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txOpeStartCancelReq__120", "portResource_currentOperationMode_Get() != RC_OK" );
                strOpeStartCancelReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
                return( rc );
            }
            //P3000223 add end
//DSIV00000099 Add Start
            accessMode = strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode;
            onlineMode = strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode;
            operationMode = strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode;
        }                                      //DSN000096135
    }
    else
    {
        objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
        PPT_METHODTRACE_V1("", "call equipment_portInfo_GetDR()...");
        rc = equipment_portInfo_GetDR(strEquipment_portInfo_GetDR_out, strObjCommonIn, equipmentID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "equipment_portInfo_GetDR() != RC_OK" );
            strOpeStartCancelReqResult.strResult = strEquipment_portInfo_GetDR_out.strResult;
            return( rc );
        }
        onlineMode = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[0].onlineMode;
    }
//DSIV00000099 Add End

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - transferState                                                     */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Check Process for Cassette");

    /*--------------------------------*/                                                                                          //P3000223
    /*   Check Port's OperationMode   */                                                                                          //P3000223
    /*--------------------------------*/                                                                                          //P3000223
//P9000261    if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode,SP_Eqp_OnlineMode_Offline) == 0 ||  //P3000223
//P9000261         CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,SP_Eqp_AccessMode_Auto   ) == 0)    //P3000223
//P9000261    {                                                                                                                             //P3000223
//P9000261 add start
//DSIV00000099     if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,SP_Eqp_AccessMode_Auto   ) == 0)    //P9000261
//DSIV00000099     {                                                                                                                             //P9000261
    if ( CIMFWStrCmp(accessMode,SP_Eqp_AccessMode_Auto) == 0 || SLMCapabilityFlag == TRUE )                              //DSIV00000099
    {                                                                                                                       //DSIV00000099

        objCassette_CheckConditionForOpeStartCancel_out strCassette_CheckConditionForOpeStartCancel_out;
        rc = cassette_CheckConditionForOpeStartCancel( strCassette_CheckConditionForOpeStartCancel_out, strObjCommonIn,
                                                       strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "cassette_CheckConditionForOpeStartCancel() rc != RC_OK");
            strOpeStartCancelReqResult.strResult = strCassette_CheckConditionForOpeStartCancel_out.strResult;
            return( rc );
        }
    }                                                                                                                            //P3000223

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - lotProcessState                                                   */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Check Process for Lot");

    objLot_CheckConditionForOpeStartCancel_out strLot_CheckConditionForOpeStartCancel_out;
    rc = lot_CheckConditionForOpeStartCancel( strLot_CheckConditionForOpeStartCancel_out, strObjCommonIn,
                                              strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "lot_CheckConditionForOpeStartCancel() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strLot_CheckConditionForOpeStartCancel_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Equipment                                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - All lof lot, which is contained in controlJob, must be existing   */
    /*     in the equipment's processing information.                        */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Check Process for Equipment");

    /*--------------------------------*/                                                                                         //P3000223
    /*   Check Port's OperationMode   */                                                                                         //P3000223
    /*--------------------------------*/                                                                                         //P3000223
//P9000261    if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode,SP_Eqp_OnlineMode_Offline) == 0 || //P3000223
//P9000261         CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,SP_Eqp_AccessMode_Auto   ) == 0)   //P3000223
//P9000261    {                                                                                                                            //P3000223
//DSIV00000099     if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,SP_Eqp_AccessMode_Auto   ) == 0)   //P9000261
//DSIV00000099     {                                                                                                                            //P9000261
    if ( CIMFWStrCmp(accessMode,SP_Eqp_AccessMode_Auto) == 0 || SLMCapabilityFlag == TRUE)                                   //DSIV00000099
    {                                                                                                                           //DSIV00000099
        objEquipment_CheckConditionForOpeStartCancel_out strEquipment_CheckConditionForOpeStartCancel_out;
        rc = equipment_CheckConditionForOpeStartCancel( strEquipment_CheckConditionForOpeStartCancel_out, strObjCommonIn,
                                                        equipmentID, strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "equipment_CheckConditionForOpeStartCancel() rc != RC_OK");
            strOpeStartCancelReqResult.strResult = strEquipment_CheckConditionForOpeStartCancel_out.strResult;
            return( rc );
        }
    }                                                                                                                            //P3000223

//P3000223 delete start (move)
//  /*---------------------------------*/
//  /*   Get Equipment's Online Mode   */
//  /*---------------------------------*/
//  PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq", "Get Equipment's Online Mode");
//
//  objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
//  rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out, strObjCommonIn,
//                                              equipmentID, strStartCassette[0].unloadPortID );
//  if ( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq", "portResource_currentOperationMode_Get() rc != RC_OK");
//      strOpeStartCancelReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
//      return( rc );
//  }
//P3000223 delete end (move)

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Equipment Port for OpeStartCancel                             */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - All of Cassette, which is contained in controlJob, must be on     */
    /*     the equipment's unloadingPort.                                    */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Check Equipment Port for OpeStartCancel");

    /*--------------------------------*/                                                                                          //P3000223
    /*   Check Port's OperationMode   */                                                                                          //P3000223
    /*--------------------------------*/                                                                                          //P3000223
//P9000261    if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode,SP_Eqp_OnlineMode_Offline) == 0 ||  //P3000223
//P9000261         CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,SP_Eqp_AccessMode_Auto   ) == 0)    //P3000223
//P9000261    {                                                                                                                             //P3000223
//DSIV00000099     if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,SP_Eqp_AccessMode_Auto   ) == 0)    //P9000261
//DSIV00000099     {
    if ( CIMFWStrCmp(accessMode,SP_Eqp_AccessMode_Auto) == 0 || SLMCapabilityFlag == TRUE)                                   //DSIV00000099
    {                                                                                                                           //DSIV00000099
        objEquipment_portState_CheckForOpeStartCancel_out strEquipment_portState_CheckForOpeStartCancel_out;
        rc = equipment_portState_CheckForOpeStartCancel( strEquipment_portState_CheckForOpeStartCancel_out, strObjCommonIn,
                                                         equipmentID, strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "equipment_portState_CheckForOpeStartCancel() rc != RC_OK");
            strOpeStartCancelReqResult.strResult = strEquipment_portState_CheckForOpeStartCancel_out.strResult;
            return( rc );
        }
    }                                                                                                                             //P3000223
//P9000261 add end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process (Reverse Order of OpeStart Procedure)                  */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*--------------------------------*/
    /*                                */
    /*   CP Test Function Procedure   */
    /*                                */
    /*--------------------------------*/
    for ( i=0 ; i<scLen ; i++ )
    {

//P3000209 /*-------------------------*/
//P3000209 /*   Omit Empty Cassette   */
//P3000209 /*-------------------------*/
//P3000209 PPT_METHODTRACE_V2("PPTManager_i:: txOpeStartCancelReq", "Omit Empty Cassette", i);
//P3000209
//P3000209 if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
//P3000209 {
//P3000209     continue;
//P3000209 }

        CORBA::Long j = 0;
        lcLen = strStartCassette[i].strLotInCassette.length();
        for ( j=0 ; j<lcLen ; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Omit Not-OpeStart Lot", i, j);
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            /*-----------------------------------------*/
            /*   Check Test Type of Current Process    */
            /*-----------------------------------------*/
            PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Check Test Type of Current Process", i, j);

            objLot_testTypeID_Get_out strLot_testTypeID_Get_out;
            rc = lot_testTypeID_Get( strLot_testTypeID_Get_out, strObjCommonIn,
                                     strStartCassette[i].strLotInCassette[j].lotID );
            if ( rc != RC_OK && rc != RC_NOT_FOUND_TESTTYPE )
            {
                PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "lot_testTypeID_Get() rc != RC_OK", i, j);
                strOpeStartCancelReqResult.strResult = strLot_testTypeID_Get_out.strResult;
                return( rc );
            }

            if (CIMFWStrLen(strLot_testTypeID_Get_out.testTypeID.identifier) != 0)
            {

                /*------------------------------------------*/
                /*   Update binReportCount of Bin Summary   */
                /*------------------------------------------*/
                PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Update binReportCount of Bin Summary", i, j);

                objBinSummary_binRptCount_SetDR_out strBinSummary_binRptCount_SetDR_out;
                rc = binSummary_binRptCount_SetDR( strBinSummary_binRptCount_SetDR_out, strObjCommonIn,
                                                   strStartCassette[i].strLotInCassette[j].lotID,
                                                   strLot_testTypeID_Get_out.testTypeID.identifier,
                                                   "0" );
                if ( rc != RC_OK && rc != RC_NOT_FOUND_BINSUM )
                {
                    PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "binSummary_binRptCount_SetDR() rc != RC_OK", i, j);
                    strOpeStartCancelReqResult.strResult = strBinSummary_binRptCount_SetDR_out.strResult;
                    return( rc );
                }
            }
        }
    }

    /*------------------------------------------------------------*/
    /*                                                            */
    /*   Reticle / Fixture Related Information Update Procedure   */
    /*                                                            */
    /*------------------------------------------------------------*/

    /*--------------------------------------------------------*/
    /*   Check ProcessDurable was Used for Operation or Not   */
    /*--------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Check ProcessDurable was Used for Operation or Not");

    objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
    rc = equipment_processDurableRequiredFlag_Get(strEquipment_processDurableRequiredFlag_Get_out, strObjCommonIn,
                                                  equipmentID);
    CORBA::Long saveRC = rc;
    if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "rc == RC_EQP_PROCDRBL_NOT_REQD");
        rc = RC_OK;
    }
    else if ( rc == RC_EQP_PROCDRBL_RTCL_REQD ||
              rc == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");
        for ( i=0 ; i<scLen ; i++ )
        {

//P3000209  if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
//P3000209  {
//P3000209      continue;
//P3000209  }

            CORBA::Long j = 0;
            lcLen = strStartCassette[i].strLotInCassette.length();
            for ( j=0 ; j<lcLen ; j++ )
            {

                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }
                //INN-R170003
                CORBA::Long lngWfrCnt = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                {

                    /*-------------------------------*/
                    /*   Get Used Reticles for Lot   */
                    /*-------------------------------*/
                    PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Get Used Reticles for Lot", i, j);
                    objProcess_assignedReticle_Get_out strProcess_assignedReticle_Get_out;
                    rc = process_assignedReticle_Get( strProcess_assignedReticle_Get_out, strObjCommonIn,
                                                      strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "process_assignedReticle_Get() rc != RC_OK", i, j);
                        strOpeStartCancelReqResult.strResult = strProcess_assignedReticle_Get_out.strResult;
                        return( rc );
                    }

                    /*--------------------------------------*/
                    /*   Update Reticle Usage Information   */
                    /*--------------------------------------*/
                    PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Update Reticle Usage Information", i, j);

                    CORBA::Long k = 0;
                    CORBA::Long nKLen = strProcess_assignedReticle_Get_out.strStartReticle.length();
                    for ( k=0 ; k<nKLen ; k++ )
                    {
                        //INN-R170003 Start
                        //objReticle_UsageCount_Decrement_out strReticle_UsageCount_Decrement_out;
                        //rc = reticle_UsageCount_Decrement( strReticle_UsageCount_Decrement_out, strObjCommonIn,
                        //                                   strProcess_assignedReticle_Get_out.strStartReticle[k].reticleID );
                        //if ( rc != RC_OK )
                        //{
                        //    PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "reticle_UsageCount_Decrement() rc != RC_OK", i, j);
                        //    strOpeStartCancelReqResult.strResult = strReticle_UsageCount_Decrement_out.strResult;
                        //    return( rc );
                        //}
                        csObjReticle_WaferCount_Decrement_out      strReticle_WaferCount_Decrement_out;
                        csObjReticle_WaferCount_Decrement_in       strReticle_WaferCount_Decrement_in;
                        strReticle_WaferCount_Decrement_in.waferCount = lngWfrCnt;
                        strReticle_WaferCount_Decrement_in.reticleID = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
                        rc = cs_reticle_WaferCount_Decrement(strReticle_WaferCount_Decrement_out, strObjCommonIn, strReticle_WaferCount_Decrement_in);
                        if (rc != RC_OK)
                        {
                            PPT_METHODTRACE_V2("", "cs_reticle_WaferCount_Decrement() != RC_OK ", rc);
                            strOpeStartCancelReqResult.strResult = strReticle_WaferCount_Decrement_out.strResult;
                            return rc;
                        }
                        //INN-R170003 End

                    }
                }
                else
                {

                    /*------------------------------*/
                    /*   Get Used Fixture for Lot   */
                    /*------------------------------*/
                    PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Get Used Fixture for Lot", i, j);

                    objProcess_assignedFixture_Get_out strProcess_assignedFixture_Get_out;
                    rc = process_assignedFixture_Get( strProcess_assignedFixture_Get_out, strObjCommonIn,
                                                      strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "process_assignedFixture_Get() rc != RC_OK", i, j);
                        strOpeStartCancelReqResult.strResult = strProcess_assignedFixture_Get_out.strResult;
                        return( rc );
                    }

                    /*--------------------------------------*/
                    /*   Update Fixture Usage Information   */
                    /*--------------------------------------*/
                    PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Update Fixture Usage Information", i, j);

                    CORBA::Long k = 0;
                    CORBA::Long nKLen = strProcess_assignedFixture_Get_out.strStartFixture.length();
                    for ( k=0 ; k<nKLen ; k++ )
                    {
                        objFixture_UsageCount_Decrement_out strFixture_UsageCount_Decrement_out;
                        rc = fixture_UsageCount_Decrement( strFixture_UsageCount_Decrement_out, strObjCommonIn,
                                                           strStartCassette[i].strLotInCassette[j].lotID,
                                                           strProcess_assignedFixture_Get_out.strStartFixture[k].fixtureID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "fixture_UsageCount_Decrement() rc != RC_OK", i, j);
                            strOpeStartCancelReqResult.strResult = strFixture_UsageCount_Decrement_out.strResult;
                            return( rc );
                        }
                    }
                }
            }
        }
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "equipment_processDurableRequiredFlag_Get() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult;
        return( rc );
    }

    /*----------------------------------------------*/
    /*                                              */
    /*   Lot Related Information Update Procedure   */
    /*                                              */
    /*----------------------------------------------*/

    /*-----------------------------------------*/
    /*   Change Lot Process State to Waiting   */
    /*-----------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Change Lot Process State to Waiting");

    objLot_processState_MakeWaiting_out strLot_processState_MakeWaiting_out;
    rc = lot_processState_MakeWaiting( strLot_processState_MakeWaiting_out, strObjCommonIn,
                                       strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "lot_processState_MakeWaiting() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strLot_processState_MakeWaiting_out.strResult;
        return( rc );
    }

//DSN000081739 Add Start
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        for ( i=0; i<scLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop to scLen", i);
            lcLen = strStartCassette[i].strLotInCassette.length();
            for ( CORBA::ULong j=0; j<lcLen; j++ )
            {
                PPT_METHODTRACE_V2("", "loop to lcLen", j);
                if ( FALSE == strStartCassette[i].strLotInCassette[j].operationStartFlag )
                {
                    PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE, continue");
                    continue;
                }

                if ( 0 != CIMFWStrCmp(strStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_EquipmentMonitorLot)
                  && 0 != CIMFWStrCmp(strStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_DummyLot) )
                {
                    PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].lotType is not Equipment Monitor and Dummy, continue");
                    continue;
                }

                objLot_eqpMonitorSectionInfo_GetForJob_out strLot_eqpMonitorSectionInfo_GetForJob_out;
                objLot_eqpMonitorSectionInfo_GetForJob_in  strLot_eqpMonitorSectionInfo_GetForJob_in;
                strLot_eqpMonitorSectionInfo_GetForJob_in.lotID  = strStartCassette[i].strLotInCassette[j].lotID;
                rc = lot_eqpMonitorSectionInfo_GetForJob( strLot_eqpMonitorSectionInfo_GetForJob_out,
                                                          strObjCommonIn,
                                                          strLot_eqpMonitorSectionInfo_GetForJob_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_eqpMonitorSectionInfo_GetForJob() != RC_OK", rc);
                    strOpeStartCancelReqResult.strResult = strLot_eqpMonitorSectionInfo_GetForJob_out.strResult;
                    return rc;
                }

                if ( 0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier )");
                    //Update information of EqpMonitor job lot
                    objEqpMonitorJob_lot_Update_out strEqpMonitorJob_lot_Update_out;
                    objEqpMonitorJob_lot_Update_in  strEqpMonitorJob_lot_Update_in;
                    strEqpMonitorJob_lot_Update_in.lotID     = strStartCassette[i].strLotInCassette[j].lotID;
                    strEqpMonitorJob_lot_Update_in.operation = CIMFWStrDup(SP_EqpMonitorJob_OpeCategory_OpeStartCancel);
                    rc = eqpMonitorJob_lot_Update( strEqpMonitorJob_lot_Update_out,
                                                   strObjCommonIn,
                                                   strEqpMonitorJob_lot_Update_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "eqpMonitorJob_lot_Update() != RC_OK", rc);
                        strOpeStartCancelReqResult.strResult = strEqpMonitorJob_lot_Update_out.strResult;
                        return rc;
                    }

                    //Get EqpMonitorJob Information
                    objEqpMonitorJob_info_Get_out strEqpMonitorJob_info_Get_out;
                    objEqpMonitorJob_info_Get_in  strEqpMonitorJob_info_Get_in;
                    strEqpMonitorJob_info_Get_in.eqpMonitorID    = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;
                    strEqpMonitorJob_info_Get_in.eqpMonitorJobID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID;
                    rc = eqpMonitorJob_info_Get( strEqpMonitorJob_info_Get_out,
                                                 strObjCommonIn,
                                                 strEqpMonitorJob_info_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "eqpMonitorJob_info_Get() != RC_OK", rc);
                        strOpeStartCancelReqResult.strResult = strEqpMonitorJob_info_Get_out.strResult;
                        return rc;
                    }

                    if( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor) )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor");
                        CORBA::Boolean eqpMonitorJobStatusChg = TRUE;
                        for ( CORBA::ULong k=0; k<strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq.length(); k++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq.length()", k);
                            if ( 0 == CIMFWStrCmp(strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq[k].monitorLotStatus, SP_EqpMonitor_LotStatus_Executing) )
                            {
                                PPT_METHODTRACE_V1("", "strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].strEqpMonitorLotInfoSeq[k].monitorLotStatus is Executing");
                                eqpMonitorJobStatusChg = FALSE;
                                break;
                            }
                        }

                        if ( TRUE == eqpMonitorJobStatusChg )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == eqpMonitorJobStatusChg");
                            //Status of EqpMonitor job is updated to "Ready"
                            pptEqpMonitorJobStatusChangeRptResult strEqpMonitorJobStatusChangeRptResult;
                            pptEqpMonitorJobStatusChangeRptInParm strEqpMonitorJobStatusChangeRptInParm;
                            strEqpMonitorJobStatusChangeRptInParm.equipmentID      = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].equipmentID;
                            strEqpMonitorJobStatusChangeRptInParm.eqpMonitorID     = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].eqpMonitorID;
                            strEqpMonitorJobStatusChangeRptInParm.eqpMonitorJobID  = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].eqpMonitorJobID;
                            strEqpMonitorJobStatusChangeRptInParm.monitorJobStatus = CIMFWStrDup(SP_EqpMonitorJob_Status_Ready);
                            rc = txEqpMonitorJobStatusChangeRpt( strEqpMonitorJobStatusChangeRptResult,
                                                                 strObjCommonIn,
                                                                 strEqpMonitorJobStatusChangeRptInParm,
                                                                 claimMemo );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "txEqpMonitorJobStatusChangeRpt() != RC_OK", rc);
                                strOpeStartCancelReqResult.strResult = strEqpMonitorJobStatusChangeRptResult.strResult;
                                return rc;
                            }
                        }
                    }
                }
            }
        }
    }
//DSN000081739 Add End

    /*----------------------------*/
    /*   Stop Q-Time Management   */
    /*----------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Stop Q-Time Management");

    objQtime_ReSetByOpeStartCancel_out strQtime_ReSetByOpeStartCancel_out;
    rc = qtime_ReSetByOpeStartCancel( strQtime_ReSetByOpeStartCancel_out, strObjCommonIn,
                                      strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "qtime_ReSetByOpeStartCancel() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strQtime_ReSetByOpeStartCancel_out.strResult;
        return( rc );
    }

    /*---------------------------------------------------------------*/
    /*   Cut Monitor Relation for ProcessMonitorLot and ProcessLot   */
    /*---------------------------------------------------------------*/

//P3000209    /*-----------------------------------*/
//P3000209    /*   Get LotID's for Each Purpose    */
//P3000209    /*-----------------------------------*/
//P3000209    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq", "Get LotID's for Each Purpose");
//P3000209
//P3000209    objOperationStartLot_lotCount_GetByLoadPurposeType_out strOperationStartLot_lotCount_GetByLoadPurposeType_out;
//P3000209    rc = operationStartLot_lotCount_GetByLoadPurposeType( strOperationStartLot_lotCount_GetByLoadPurposeType_out, strObjCommonIn,
//P3000209                                                          strStartCassette );
//P3000209    if ( rc != RC_OK )
//P3000209    {
//P3000209        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq", "operationStartLot_lotCount_GetByLoadPurposeType() rc != RC_OK");
//P3000209        strOpeStartCancelReqResult.strResult = strOperationStartLot_lotCount_GetByLoadPurposeType_out.strResult;
//P3000209        return( rc );
//P3000209    }

//P3000209 add start
    /*------------------------------------------------------------*/
    /*   Get Monitor Lot ID in strStartCassette[].strStartLot[]   */
    /*------------------------------------------------------------*/
    objectIdentifier monitorLotID;

    for ( i=0 ; i<scLen ; i++ )
    {
        lcLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0 ; j<lcLen ; j++ )
        {
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE &&
                 strStartCassette[i].strLotInCassette[j].monitorLotFlag     == TRUE )
            {
                monitorLotID = strStartCassette[i].strLotInCassette[j].lotID;
                break;
            }
        }
    }
//P3000209 add end

//P3000209    if (CIMFWStrLen(strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID.identifier) != 0)
    if (CIMFWStrLen(monitorLotID.identifier) != 0)
    {
        /*------------------------------------------------*/
        /*    Call txCancelRelationMonitorProdLotsReq()   */
        /*------------------------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Call txCancelRelationMonitorProdLotsReq()");

//P3000209        objectIdentifier bummyCassetteID;
        pptCancelRelationMonitorProdLotsReqResult strCancelRelationMonitorProdLotsReqResult;
//P3000209        rc = txCancelRelationMonitorProdLotsReq( strCancelRelationMonitorProdLotsReqResult, strObjCommonIn,
//P3000209                                                 strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID);
        rc = txCancelRelationMonitorProdLotsReq( strCancelRelationMonitorProdLotsReqResult, strObjCommonIn, monitorLotID ); //P3000209
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "txCancelRelationMonitorProdLotsReq() rc != RC_OK");

//P3100372            strOpeStartCancelReqResult.strResult = strCancelRelationMonitorProdLotsReqResult.strResult;
//P3100372            return( rc );
        }
    }
//DSIV00002435 add start
    for ( i = 0 ; i < scLen ; i++ )
    {
        PPT_METHODTRACE_V2("", "Loop count i :", i);
        CORBA::Long j = 0;
        lcLen = strStartCassette[i].strLotInCassette.length();

        for ( j = 0; j < lcLen; j++ )
        {
            PPT_METHODTRACE_V3("", "Loop count j. LotID :", j, strStartCassette[i].strLotInCassette[j].lotID.identifier);
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE" );
                continue;
            }

            //---------------------------------------------------------------------------------------//
            //  Check if schedule change by lot information change is reserved for this operation    //
            //  If schedule change is reserved, delete the reservation and send e-mail to lot owner  //
            //---------------------------------------------------------------------------------------//
            PPT_METHODTRACE_V1("", "call lot_currentOperationInfo_Get()");
            objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
            rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "lot_currentOperationInfo_Get() != RC_OK", rc );
                strOpeStartCancelReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
                return (rc);
            }

            CORBA::String_var targetRouteID;
            CORBA::String_var targetOperationNumber;

            targetRouteID         = strLot_currentOperationInfo_Get_out.routeID.identifier;
            targetOperationNumber = strLot_currentOperationInfo_Get_out.operationNumber;

            PPT_METHODTRACE_V2("", "targetRouteID         : ", targetRouteID);
            PPT_METHODTRACE_V2("", "targetOperationNumber : ", targetOperationNumber);


            objSchdlChangeReservation_GetListDR_out__110 strSchdlChangeReservation_GetListDR_out;
            objSchdlChangeReservation_GetListDR_in__110  strSchdlChangeReservation_GetListDR_in;
            strSchdlChangeReservation_GetListDR_in.objectID              = strStartCassette[i].strLotInCassette[j].lotID.identifier;
            strSchdlChangeReservation_GetListDR_in.objectType            = SP_SCHDL_CHG_OBJTYPE_LOT;
            strSchdlChangeReservation_GetListDR_in.targetRouteID         = targetRouteID;
            strSchdlChangeReservation_GetListDR_in.targetOperationNumber = targetOperationNumber;
            strSchdlChangeReservation_GetListDR_in.lotInfoChangeFlag     = 2;                   //2: LOTINFO_CHANGE_FLAG is 1

            PPT_METHODTRACE_V1("", "call schdlChangeReservation_GetListDR()");
            rc = schdlChangeReservation_GetListDR__110( strSchdlChangeReservation_GetListDR_out, strObjCommonIn, strSchdlChangeReservation_GetListDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "schdlChangeReservation_GetListDR() != RC_OK", rc );
                strOpeStartCancelReqResult.strResult = strSchdlChangeReservation_GetListDR_out.strResult;
                return (rc);
            }
            
            CORBA::Long rsvLength = 0;
            rsvLength = strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations.length();
            if( 0 < rsvLength )
            {
                PPT_METHODTRACE_V2("", "rsvLength:", rsvLength);
                for( CORBA::Long k = 0; k < rsvLength; k++ )
                {
                    PPT_METHODTRACE_V2("", "Loop count k :", k);
                    PPT_METHODTRACE_V1("", "call schdlChangeReservation_DeleteDR()");
                    objSchdlChangeReservation_Delete_out        strSchdlChangeReservation_Delete_out;
                    objSchdlChangeReservation_DeleteDR_in__110  strSchdlChangeReservation_DeleteDR_in;
                    strSchdlChangeReservation_DeleteDR_in.strSchdlChangeReservation = strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k];

                    rc = schdlChangeReservation_DeleteDR__110( strSchdlChangeReservation_Delete_out, strObjCommonIn, strSchdlChangeReservation_DeleteDR_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "", "schdlChangeReservation_DeleteDR() != RC_OK", rc );
                        strOpeStartCancelReqResult.strResult = strSchdlChangeReservation_Delete_out.strResult;
                        return (rc);
                    }

                    /*------------------------*/
                    /*   Send e-mail          */
                    /*------------------------*/
                    PPT_METHODTRACE_V1("", "Send e-mail");
                    ostrstream  ostrMessage;
                    ostrMessage << "This message was sent because reservation for \"Lot Information Change\" is canceled.\n";
                    ostrMessage << "Schedule Change Reservation Info.\n";
                    ostrMessage << "LotID      : " << strStartCassette[i].strLotInCassette[j].lotID.identifier << "\n";
                    ostrMessage << "Product ID : " << strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k].productID.identifier << "\n";
                    ostrMessage << "Route ID   : " << strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k].routeID.identifier << "\n";
                    ostrMessage << "Ope.No     : " << strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k].operationNumber << "\n";
                    ostrMessage << "SubLotType : " << strSchdlChangeReservation_GetListDR_out.strSchdlChangeReservations[k].subLotType << "\n";
                    ostrMessage << ends;

                    PPT_METHODTRACE_V2("", " MessageDistributionMgr_PutMessage() ", i);
                    objMessageDistributionMgr_PutMessage_out strMessageDistributionMgr_PutMessage_out;
                    objectIdentifier messageID;
                    messageID.identifier = CIMFWStrDup(SP_SystemMsgCode_SCRNotice);
                    rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out,
                                                            strObjCommonIn,
                                                            messageID,
                                                            strStartCassette[i].strLotInCassette[j].lotID,
                                                            "",                                                     //lotStatus
                                                            equipmentID,
                                                            strLot_currentOperationInfo_Get_out.routeID,
                                                            strLot_currentOperationInfo_Get_out.operationNumber,
                                                            "",                                                     //reasonCode
                                                            ostrMessage.str() );
                    ostrMessage.rdbuf()->freeze(0);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK") ;
                        strOpeStartCancelReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult ;
                        return( rc );
                    }
                } //end of [k]
            } //end of [if( 0 < rsvLength )]
        } //end of [j]
    } //end of [i]
//DSIV00002435 add end

    /*---------------------------------------------------*/
    /*                                                   */
    /*   Cassette Related Information Update Procedure   */
    /*                                                   */
    /*---------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Cassette Related Information Update Procedure");

    scLen = strStartCassette.length();
    for ( i=0 ; i<scLen ; i++ )
    {
//DSIV00000099 add start
        if (CIMFWStrLen(strStartCassette[i].cassetteID.identifier) == 0 && SLMCapabilityFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", "### SLMCapabilityFlag is TRUE, and castID is blank.");
            continue;
        }
//DSIV00000099 add end
        /*------------------------------------------*/
        /*   Update Casssette's Usage Information   */
        /*------------------------------------------*/
        PPT_METHODTRACE_V2("PPTManager_i:: txOpeStartCancelReq__120", "Update Casssette's Usage Information", i);

        objCassette_usageCount_Decrement_out strCassette_usageCount_Decrement_out;
        rc = cassette_usageCount_Decrement( strCassette_usageCount_Decrement_out, strObjCommonIn,
                                            strStartCassette[i].cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("PPTManager_i:: txOpeStartCancelReq__120", "cassette_usageCount_Decrement() rc != RC_OK", i);
            strOpeStartCancelReqResult.strResult = strCassette_usageCount_Decrement_out.strResult;
            return( rc );
        }
    }

    /*------------------------------------------------------*/
    /*                                                      */
    /*     FlowBatch Related Information Update Procedure   */
    /*                                                      */
    /*------------------------------------------------------*/

    /*----------------------------------------------------------*/
    /*   Update FlowBatch Information of Equipment              */
    /*                                                          */
    /*   If lots to be canceled are on the target operation     */
    /*   of FlowBatch section, equipment's reservedFlowBatchID  */
    /*   is set-back again. In this case, Flow-Batch's          */
    /*   reservedEquipmentID is re-set, too.                    */
    /*----------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Update FlowBatch Information of Equipment");

    objFlowBatch_Information_UpdateByOpeStartCancel_out strFlowBatch_information_UpdateByOpeStartCancel_out;
    rc = flowBatch_Information_UpdateByOpeStartCancel( strFlowBatch_information_UpdateByOpeStartCancel_out, strObjCommonIn,
                                                       equipmentID, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "flowBatch_information_UpdateByOpeStartCancel() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strFlowBatch_information_UpdateByOpeStartCancel_out.strResult;
        return( rc );
    }

    /*----------------------------------------------------*/
    /*                                                    */
    /*   Equipment Related Information Update Procedure   */
    /*                                                    */
    /*----------------------------------------------------*/

    /*----------------------------------------------------------------*/
    /*   Remove ControlJobLot from EqpInfo's ProcessingLot Sequence   */
    /*----------------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Remove ControlJobLot from EqpInfo's ProcessingLot Sequence");

    objEquipment_processingLot_Delete_out strEquipment_processingLot_Delete_out;

    if( virtualOperationFlag == FALSE )    //DSN000096135
    {                                      //DSN000096135
        rc = equipment_processingLot_Delete( strEquipment_processingLot_Delete_out, strObjCommonIn,
                                             equipmentID, strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "equipment_processingLot_Delete() rc != RC_OK");
            strOpeStartCancelReqResult.strResult = strEquipment_processingLot_Delete_out.strResult;
            return( rc );
        }
    }                                      //DSN000096135

    /*---------------------------------------------*/
    /*   Maintain Eqp's Status for OFF-LINE Mode   */
    /*---------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Maintain Eqp's Status for OFF-LINE Mode");

//DSIV00000099     if (CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline) == 0)
//DSIV00000099     {
    if (CIMFWStrCmp(onlineMode, SP_Eqp_OnlineMode_Offline) == 0)            //DSIV00000099
    {                                                                       //DSIV00000099
        /*--------------------------------------------*/
        /*   Change Equipment's Status to 'STANDBY'   */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Change Equipment's Status to 'STANDBY'");

        /*===== get StateChangeableFlag ===*/
        objEquipment_currentState_CheckToManufacturing_out strEquipment_currentState_CheckToManufacturing_out;
        strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag = FALSE; //P3000280
        rc = equipment_currentState_CheckToManufacturing( strEquipment_currentState_CheckToManufacturing_out, strObjCommonIn,
                                                      equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "equipment_currentState_GetManufacturing() rc != RC_OK");
            strOpeStartCancelReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult;
            return( rc );
        }

        if ( strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag == TRUE )
        {

            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "ManufacturingStateChangeableFlag == TRUE");
            /*===== get Defaclt Status Code for Productive / Standby ===*/
            objEquipment_recoverState_GetManufacturing_out strEquipment_recoverState_GetManufacturing_out;
            rc = equipment_recoverState_GetManufacturing( strEquipment_recoverState_GetManufacturing_out, strObjCommonIn,
                                                          equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "equipment_recoverState_GetManufacturing() rc != RC_OK");
                strOpeStartCancelReqResult.strResult = strEquipment_recoverState_GetManufacturing_out.strResult;
                return( rc );
            }

            /*---------------------------------*/
            /*   Call txEqpStatusChangeReq()   */
            /*---------------------------------*/
            PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Call txEqpStatusChangeReq()");

            pptEqpStatusChangeReqResult strEqpStatusChangeReqResult;
            rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult, strObjCommonIn,
                                       equipmentID, strEquipment_recoverState_GetManufacturing_out.equipmentStatusCode,
                                       claimMemo );
            if ( rc != RC_OK && rc != RC_CURRSTATE_SAME )
            {
                PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "txEqpStatusChangeReq() rc != RC_OK");
                strOpeStartCancelReqResult.strResult = strEqpStatusChangeReqResult.strResult;
                return( rc );
            }
        }
    }

    /*------------------------------------------*/
    /*   Update Equipment's Usage Information   */
    /*------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Update Equipment's Usage Information");

    objEquipment_usageCount_Decrement_out strEquipment_usageCount_Decrement_out;
    rc = equipment_usageCount_Decrement( strEquipment_usageCount_Decrement_out, strObjCommonIn,
                                          equipmentID, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "equipment_usageCount_Decrement() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strEquipment_usageCount_Decrement_out.strResult;
        return( rc );
    }

//DSIV00001830 add start
    //-----------------------------------------------------------//
    //  Wafer Stacking Operation                                 //
    //    If Equipment Category is SP_Mc_Category_WaferBonding,  //
    //    update Bonding Group Information                       //
    //-----------------------------------------------------------//
    //------------------------------//
    //   Check Equipment Category   //
    //------------------------------//
    PPT_METHODTRACE_V2("", "equipmentCategory", strEquipment_brInfo_GetDR_out.equipmentBRInfo.equipmentCategory)

    if ( 0 == CIMFWStrCmp( strEquipment_brInfo_GetDR_out.equipmentBRInfo.equipmentCategory, SP_Mc_Category_WaferBonding) )
    {
        PPT_METHODTRACE_V1("", "##### Equipment Category is  SP_Mc_Category_WaferBonding")
        
        objLot_bondingGroup_UpdateByOperation_out strLot_bondingGroup_UpdateByOperation_out;
        objLot_bondingGroup_UpdateByOperation_in strLot_bondingGroup_UpdateByOperation_in;
        strLot_bondingGroup_UpdateByOperation_in.equipmentID = equipmentID;
        strLot_bondingGroup_UpdateByOperation_in.controlJobID = controlJobID;
        strLot_bondingGroup_UpdateByOperation_in.strStartCassette = strStartCassette;
        strLot_bondingGroup_UpdateByOperation_in.operation = CIMFWStrDup( SP_Operation_OpeStartCancel );
        
        PPT_METHODTRACE_V1("", "call lot_bondingGroup_UpdateByOperation()");
        rc = lot_bondingGroup_UpdateByOperation( strLot_bondingGroup_UpdateByOperation_out, strObjCommonIn, strLot_bondingGroup_UpdateByOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "lot_bondingGroup_UpdateByOperation() != RC_OK", rc );
            strOpeStartCancelReqResult.strResult = strLot_bondingGroup_UpdateByOperation_out.strResult;
            return (rc);
        }
    }
//DSIV00001830 add end

    /*----------------------------------------------------*/
    /*                                                    */
    /*   ControlJob Related Information Update Proceure   */
    /*                                                    */
    /*----------------------------------------------------*/

    /*--------------------------------------------------------*/
    /*   Clear ActualStart Info in Each Lots' PO              */
    /*                                                        */
    /*   - Clear controlJobID of each cassette.               */
    /*   - Clear controlJobID of each lot.                    */
    /*   - Clear control job info of each lot's cunrrent PO.  */
    /*--------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Clear ActualStart Info in Each Lots' PO");

    objProcess_startReserveInformation_Clear_out strProcess_startReserveInformation_Clear_out;
    rc = process_startReserveInformation_Clear( strProcess_startReserveInformation_Clear_out, strObjCommonIn,
                                                controlJobID, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "process_startReserveInformation_clear() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strProcess_startReserveInformation_Clear_out.strResult;
        return( rc );
    }

//D5100088 add start
    /*-------------------------------------------*/
    /*   Clear Wafer-Chamber Information in PO   */
    /*-------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Clear Wafer-Chamber Information in PO.");

    objProcess_waferChamberInformation_Clear_out strProcess_waferChamberInformation_Clear_out;
    rc = process_waferChamberInformation_Clear( strProcess_waferChamberInformation_Clear_out,
                                                strObjCommonIn,
                                                strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "process_waferChamberInformation_Clear() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strProcess_waferChamberInformation_Clear_out.strResult;
        return( rc );
    }
//D5100088 add end
//D9000058 add start
    /*-------------------------------------------------------------*/
    /*   Clear Process resource Wafer position information in PO   */
    /*-------------------------------------------------------------*/
    PPT_METHODTRACE_V1("", "Clear Process resource Wafer position information in PO.");

    objProcess_waferPositionInProcessResourceInformation_Clear_out strProcess_waferPositionInProcessResourceInformation_Clear_out;
    objProcess_waferPositionInProcessResourceInformation_Clear_in strProcess_waferPositionInProcessResourceInformation_Clear_in;
    strProcess_waferPositionInProcessResourceInformation_Clear_in.strStartCassette = strStartCassette;

    rc = process_waferPositionInProcessResourceInformation_Clear( strProcess_waferPositionInProcessResourceInformation_Clear_out,
                                                                  strObjCommonIn,
                                                                  strProcess_waferPositionInProcessResourceInformation_Clear_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_waferPositionInProcessResourceInformation_Clear() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strProcess_waferPositionInProcessResourceInformation_Clear_out.strResult;
        return( rc );
    }
//D9000058 add end

    /*------------------------*/
    /*   Delete Control Job   */
    /*------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Delete Control Job");

//D7000006    objControlJob_Delete_out strControlJob_Delete_out;
//D7000006    rc = controlJob_Delete( strControlJob_Delete_out, strObjCommonIn,
//D7000006                            controlJobID );
//D7000006    if ( rc != RC_OK )
//D7000006    {
//D7000006        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq", "controlJob_Delete() rc != RC_OK");
//D7000006        strOpeStartCancelReqResult.strResult = strControlJob_Delete_out.strResult;
//D7000006        return( rc );
//D7000006    }
//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
        PPT_METHODTRACE_V1("", "Call txControlJobManageReq()...");
//DSN000015229 Add End
//DSN000015229 Indent Start
        //D7000006 Add Start
        pptControlJobManageReqResult strControlJobManageReqResult;
        pptControlJobCreateRequest   dummyControlJobCreateRequest;
        rc = txControlJobManageReq( strControlJobManageReqResult,
                                    strObjCommonIn,
                                    controlJobID,
                                    SP_ControlJobAction_Type_delete,
                                    dummyControlJobCreateRequest,
                                    claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
            strOpeStartCancelReqResult.strResult = strControlJobManageReqResult.strResult;
            return( rc );
        }
        //D7000006 Add End
//DSN000015229 Indent End
    }   //DSN000015229

//DSN000015229 Add Start
    CORBA::String_var eventTxID;
    if ( 0 == CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      || 0 == CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID == TXEWC015 || TXEWC016");
        eventTxID = strObjCommonIn.transactionID;
    }
    else
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID != TXEWC015 && TXEWC016");
        eventTxID = CIMFWStrDup("TXTRC003");
    }
//DSN000015229 Add End

//PSN000099815 Add Start
    /*----------------------------------------------------*/
    /*   Clear UsedFlag in EntityInhibit Exception Lot    */
    /*----------------------------------------------------*/
    PPT_METHODTRACE_V1( "", "Clear UsedFlag in EntityInhibit Exception Lot" );
    for( i=0 ; i<scLen ; i++ )
    {
        lcLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::ULong j=0 ; j<lcLen ; j++ )
        {
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            // Update Entity Inhibit Exception UsedFlag
            objEntityInhibit_FilterExceptionLot_out strEntityInhibit_FilterExceptionLot_out;
            objEntityInhibit_FilterExceptionLot_in strEntityInhibit_FilterExceptionLot_in;

            strEntityInhibit_FilterExceptionLot_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;

            rc = entityInhibit_FilterExceptionLot( strEntityInhibit_FilterExceptionLot_out,
                                                   strObjCommonIn,
                                                   strEntityInhibit_FilterExceptionLot_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( ""," #### entityInhibit_FilterExceptionLot() != RC_OK : rc = ", rc );
                strOpeStartCancelReqResult.strResult = strEntityInhibit_FilterExceptionLot_out.strResult;
                return rc;
            }
        }
    }
//PSN000099815 Add End

//PSN000105025 add start
    /*---------------------------------------------------------------------------------*/
    /*                                                                                 */
    /*   Get of the FutureHold information by ImmediateHold for OperationStartCancel   */
    /*                                                                                 */
    /*---------------------------------------------------------------------------------*/
    objectIdentifier releaseReasonCodeID;
    for( i=0 ; i<scLen ; i++ )
    {
        lcLen = strStartCassette[i].strLotInCassette.length();
        for( CORBA::ULong j=0 ; j<lcLen ; j++ )
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( FALSE == strStartCassette[i].strLotInCassette[j].operationStartFlag )
            {
                continue;
            }

            /*-------------------------------------------*/
            /*   Get of the FutureHold information       */
            /*-------------------------------------------*/
            objLot_futureHoldRequests_EffectForOpeStartCancel_out strLot_futureHoldRequests_EffectForOpeStartCancel_out;
            objLot_futureHoldRequests_EffectForOpeStartCancel_in  strLot_futureHoldRequests_EffectForOpeStartCancel_in;
            strLot_futureHoldRequests_EffectForOpeStartCancel_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;

            rc = lot_futureHoldRequests_EffectForOpeStartCancel( strLot_futureHoldRequests_EffectForOpeStartCancel_out,
                                                                 strObjCommonIn,
                                                                 strLot_futureHoldRequests_EffectForOpeStartCancel_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_futureHoldRequests_EffectForOpeStartCancel() != RC_OK", rc) ;
                strOpeStartCancelReqResult.strResult = strLot_futureHoldRequests_EffectForOpeStartCancel_out.strResult ;
                return rc;
            }

            /*---------------------------------------------------------------------*/
            /*   FutureHold(POST) registered by ImmediateHold action is released   */
            /*---------------------------------------------------------------------*/
            const pptHoldListSequence& strFutureHoldReleaseReqList = strLot_futureHoldRequests_EffectForOpeStartCancel_out.strFutureHoldReleaseReqList;
            if( strFutureHoldReleaseReqList.length() > 0 )
            {
                pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
                rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult,
                                            strObjCommonIn,
                                            strLot_futureHoldRequests_EffectForOpeStartCancel_out.lotID,
                                            releaseReasonCodeID,
                                            SP_EntryType_Remove,
                                            strFutureHoldReleaseReqList );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txFutureHoldCancelReq() != RC_OK", rc) ;
                    strOpeStartCancelReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
                    return rc;
                }
            }

            /*--------------------------------------------------*/
            /*   FutureHold is performed immediately            */
            /*--------------------------------------------------*/
            const pptHoldListSequence& strLotHoldReqList = strLot_futureHoldRequests_EffectForOpeStartCancel_out.strLotHoldReqList;
            if( strLotHoldReqList.length() > 0 )
            {
                pptHoldLotReqResult strHoldLotReqResult ;
                rc = txHoldLotReq( strHoldLotReqResult,
                                   strObjCommonIn,
                                   strLot_futureHoldRequests_EffectForOpeStartCancel_out.lotID,
                                   strLotHoldReqList );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txHoldLotReq() != RC_OK", rc) ;
                    strOpeStartCancelReqResult.strResult = strHoldLotReqResult.strResult ;
                    return rc;
                }
            }
        }
    }
//PSN000105025 add end

    /*--------------------------*/
    /*                          */
    /*   Event Make Procedure   */
    /*                          */
    /*--------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Event Make Procedure");
    for ( i=0 ; i<scLen ; i++ )
    {

//P3000209 /*-------------------------*/
//P3000209 /*   Omit Empty Cassette   */
//P3000209 /*-------------------------*/
//P3000209 if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
//P3000209 {
//P3000209     continue;
//P3000209 }

        CORBA::Long j = 0;
        lcLen = strStartCassette[i].strLotInCassette.length();
        for ( j=0 ; j<lcLen ; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Omit Not-OpeStart Lot", i, j);
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            /*--------------------------------------------------------------------*/
            /*   Make OperationMoveEvent for Operation History - OpeStartCancel   */
            /*--------------------------------------------------------------------*/
            PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "Make OperationMoveEvent for Operation History - OpeStartCancel", i, j);
            objLotOperationMoveEvent_MakeOpeStartCancel_out strLotOperationMoveEvent_MakeOpeStartCancel_out;
            rc = lotOperationMoveEvent_MakeOpeStartCancel( strLotOperationMoveEvent_MakeOpeStartCancel_out, strObjCommonIn,
//DSN000015229                                                           "TXTRC003",
                                                           eventTxID,    //DSN000015229
                                                           equipmentID,
//DSIV00000099                                                            strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier,
                                                           operationMode.identifier,        //DSIV00000099
                                                           controlJobID,
                                                           strStartCassette[i].cassetteID,
                                                           strStartCassette[i].strLotInCassette[j],
                                                           claimMemo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V3("PPTManager_i:: txOpeStartCancelReq__120", "lotOperationMoveEvent_MakeOpeStartCancel() rc != RC_OK", i, j);
                strOpeStartCancelReqResult.strResult = strLotOperationMoveEvent_MakeOpeStartCancel_out.strResult;
                return( rc );
            }
        }
    }

//D7000180 start (move to lower)
//D7000180//D5100232 start
//D7000180    /*------------------------------------------------------------------------*/
//D7000180    /*                                                                        */
//D7000180    /*   Send OpeComp Report to DCS Procedure                                 */
//D7000180    /*                                                                        */
//D7000180    /*------------------------------------------------------------------------*/
//D7000180    CORBA::Boolean bDCSAvailable = FALSE;
//D7000180    CORBA::String_var DCSAvailable = CIMFWStrDup(getenv(SP_DCS_Available));
//D7000180    PPT_METHODTRACE_V2("", "DCSAvailable", DCSAvailable);
//D7000180    if (CIMFWStrCmp(DCSAvailable, "1") == 0 )
//D7000180    {
//D7000180        PPT_METHODTRACE_V1("", "DCS Interface Available");
//D7000180        bDCSAvailable = TRUE;
//D7000180    }
//D7000180
//D7000180    if ( 0 != CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline)
//D7000180      && TRUE == bDCSAvailable )
//D7000180    {
//D7000180        PPT_METHODTRACE_V1("", "Send OpeComp Report to DCS");
//D7000180
//D7000180        CORBA::String_var IgnoreErr = CIMFWStrDup(getenv(SP_DCS_Ignore_OpeStartCancel_Result));
//D7000180        PPT_METHODTRACE_V2("", "SP_DCS_IGNORE_OPESTARTCANCEL_RESULT", IgnoreErr);
//D7000180
//D7000180        objDCSMgr_SendOperationStartCancelRpt_out strDCSMgr_SendOperationStartCancelRpt_out;
//D7000180        rc = DCSMgr_SendOperationStartCancelRpt( strDCSMgr_SendOperationStartCancelRpt_out, strObjCommonIn, controlJobID );
//D7000180
//D7000180        if ( rc != RC_OK && 0 != CIMFWStrCmp(IgnoreErr, "1") )
//D7000180        {
//D7000180            PPT_METHODTRACE_V2("", "##### DCSMgr_SendOperationStartCancelRpt() != RC_OK", rc);
//D7000180            strOpeStartCancelReqResult.strResult = strDCSMgr_SendOperationStartCancelRpt_out.strResult;
//D7000180            return( rc );
//D7000180        }
//D7000180    }
//D7000180//D5100232 end
//D7000180 end (move to lower)

    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send OpeStartCancel Request to TCS Procedure                         */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq__120", "Send OpeStartCancel Request to TCS Procedure");

//D4000060    objTCSMgr_SendOpeStartCancelReq_out strTCSMgr_SendOpeStartCancelReq_out;
//D4000060    rc = TCSMgr_SendOpeStartCancelReq( strTCSMgr_SendOpeStartCancelReq_out, strObjCommonIn,
//D4000060                                       strObjCommonIn.strUser,
//D4000060                                       equipmentID,
//D4000060                                       controlJobID,
//D4000060                                       claimMemo );
//D4000060    if ( rc != RC_OK )
//D4000060    {
//D4000060        PPT_METHODTRACE_V1("PPTManager_i:: txOpeStartCancelReq", "TCSMgr_SendOpeStartCancelReq() rc != RC_OK");
//D4000060        strOpeStartCancelReqResult.strResult = strTCSMgr_SendOpeStartCancelReq_out.strResult;
//D4000060        return( rc );
//D4000060    }
//D4000060
//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID != TXEWC015 && TXEWC016");
//DSN000015229 Add End
//DSN000015229 Indent Start

    //D4000060 add start
        CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
        CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
        CORBA::Long sleepTimeValue;
        CORBA::Long retryCountValue;

        if (CIMFWStrLen(tmpSleepTimeValue) == 0)
        {
            sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
        }
        else
        {
    //D9000001        sleepTimeValue = atol(tmpSleepTimeValue) ;
            sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
        }

        if (CIMFWStrLen(tmpRetryCountValue) == 0)
        {
            retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
        }
        else
        {
    //D9000001        retryCountValue = atol(tmpRetryCountValue);
            retryCountValue = atoi(tmpRetryCountValue);    //D9000001
        }

        PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
        PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

        objTCSMgr_SendOpeStartCancelReq_out strTCSMgr_SendOpeStartCancelReq_out;

        //'retryCountValue + 1' means first try plus retry count
        for(i = 0 ; i < (retryCountValue + 1) ; i++)
        {
            /*--------------------------*/
            /*    Send Request to TCS   */
            /*--------------------------*/
            rc = TCSMgr_SendOpeStartCancelReq( strTCSMgr_SendOpeStartCancelReq_out, strObjCommonIn,
                                               strObjCommonIn.strUser,
                                               equipmentID,
                                               controlJobID,
                                               claimMemo );
            PPT_METHODTRACE_V2("","rc = ",rc);

            if(rc == RC_OK)
            {
                PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                break;
            }
            else if ( rc == RC_TCS_MM_FETCH_CJ_ERROR        ||      //D7000180
                      rc == RC_TCS_MM_ALREADY_OPE_COMPLETED ||      //D7000180
                      rc == RC_TCS_MM_ALREADY_OPE_CANCELED )        //D7000180
            {                                                       //D7000180
                PPT_METHODTRACE_V2("","TCS returns -> RC_OK", rc);  //D7000180
                rc = RC_OK;                                         //D7000180
                break;                                              //D7000180
            }                                                       //D7000180
            else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                      rc == RC_EXT_SERVER_NIL_OBJ   ||
                      rc == RC_TCS_NO_RESPONSE )
            {
                PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
                PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                sleep(sleepTimeValue);
                continue;
            }
            else
            {
                PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartCancelReq() != RC_OK");
                strOpeStartCancelReqResult.strResult = strTCSMgr_SendOpeStartCancelReq_out.strResult;
                return( rc );
            }

         }

         if ( rc != RC_OK )
         {
            PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartCancelReq() != RC_OK");
            strOpeStartCancelReqResult.strResult = strTCSMgr_SendOpeStartCancelReq_out.strResult;
            return( rc );
         }
    //D4000060 add end
//DSN000015229 Indent End
    }   //DSN000015229
//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID != TXEWC015 && TXEWC016");
//DSN000015229 Add End
//DSN000015229 Indent Start
    
    //D7000180 start (move from upper)
        /*------------------------------------------------------------------------*/
        /*                                                                        */
        /*   Send OpeComp Report to DCS Procedure                                 */
        /*                                                                        */
        /*------------------------------------------------------------------------*/
        CORBA::Boolean bDCSAvailable = FALSE;
        CORBA::String_var DCSAvailable = CIMFWStrDup(getenv(SP_DCS_Available));
        PPT_METHODTRACE_V2("", "DCSAvailable", DCSAvailable);
        if (CIMFWStrCmp(DCSAvailable, "1") == 0 )
        {
            PPT_METHODTRACE_V1("", "DCS Interface Available");
            bDCSAvailable = TRUE;
        }

    //DSIV00000099     if ( 0 != CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline)
    //DSIV00000099       && TRUE == bDCSAvailable )
        if ( 0 != CIMFWStrCmp(onlineMode, SP_Eqp_OnlineMode_Offline)            //DSIV00000099
          && TRUE == bDCSAvailable )                                            //DSIV00000099
        {
            PPT_METHODTRACE_V1("", "Send OpeComp Report to DCS");

            CORBA::String_var IgnoreErr = CIMFWStrDup(getenv(SP_DCS_Ignore_OpeStartCancel_Result));
            PPT_METHODTRACE_V2("", "SP_DCS_IGNORE_OPESTARTCANCEL_RESULT", IgnoreErr);

            objDCSMgr_SendOperationStartCancelRpt_out strDCSMgr_SendOperationStartCancelRpt_out;
            rc = DCSMgr_SendOperationStartCancelRpt( strDCSMgr_SendOperationStartCancelRpt_out, strObjCommonIn, controlJobID );

            if ( rc != RC_OK && 0 != CIMFWStrCmp(IgnoreErr, "1") )
            {
                PPT_METHODTRACE_V2("", "##### DCSMgr_SendOperationStartCancelRpt() != RC_OK", rc);
                strOpeStartCancelReqResult.strResult = strDCSMgr_SendOperationStartCancelRpt_out.strResult;
                return( rc );
            }
        }
    //D7000180 end (move from upper)
//DSN000015229 Indent End
    }   //DSN000015229

//D51M0000 add start
    /*-------------------------------------------------*/
    /*   call APCRuntimeCapability_DeleteDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call  APCRuntimeCapability_DeleteDR ");
    objAPCRuntimeCapability_DeleteDR_out strAPCRuntimeCapability_DeleteDR_out;
    rc = APCRuntimeCapability_DeleteDR ( strAPCRuntimeCapability_DeleteDR_out,
                                         strObjCommonIn,
                                         controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", " APCRuntimeCapability_DeleteDR() rc != RC_OK");
        strOpeStartCancelReqResult.strResult = strAPCRuntimeCapability_DeleteDR_out.strResult;
        return( rc );
    }

//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
//DSN000015229 Add End
//DSN000015229 Indent Start
//      Wafer information in APCBaseCassette is not necessary for reserve cancel,
//      but it is required by wrapper for process xml which satisfy dtd.
//      So, now we add dummy wafer data into strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList.

        CORBA::Long bcLen = strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList.length();
        CORBA::Long bcIdx = 0;
        for( bcIdx = 0; bcIdx < bcLen; bcIdx++ )
        {
            CORBA::Long blLen = strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot.length();
            CORBA::Long blIdx = 0;
            for( blIdx = 0; blIdx < blLen; blIdx++ )
            {
                strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer.length(1);
                strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].waferID              = CIMFWStrDup("");
                strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].slotNumber           = 0;
                strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].controlWaferFlag     = FALSE;
                strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].sendAheadWaferFlag   = FALSE;
                strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].processFlag          = FALSE;
                strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList[bcIdx].strAPCBaseLot[blIdx].strAPCBaseWafer[0].experimentSplitWafer = FALSE;
            }
        }

        /*-------------------------------------------------*/
        /*   call APCMgr_SendControlJobInformationDR       */
        /*-------------------------------------------------*/
        PPT_METHODTRACE_V1("", "call  APCMgr_SendControlJobInformationDR ");
        objAPCMgr_SendControlJobInformationDR_out strAPCMgr_SendControlJobInformationDR_out;
        rc = APCMgr_SendControlJobInformationDR ( strAPCMgr_SendControlJobInformationDR_out,
                                                  strObjCommonIn,
                                                  equipmentID,
                                                  controlJobID,
                                                  SP_APC_ControlJobStatus_Canceled,
                                                  strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList );
    //D7000182    if ( rc != RC_OK )
        if ( rc != RC_OK && rc != RC_OK_NO_IF )    //D7000182
        {
            PPT_METHODTRACE_V1("", " APCMgr_SendControlJobInformationDR() rc != RC_OK");
            strOpeStartCancelReqResult.strResult = strAPCMgr_SendControlJobInformationDR_out.strResult;
            return( rc );
        }

    //D7000182 add start
        if( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "APCControlJobInformation was sent normally.");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Executing);
        }
    //D7000182 add end
//DSN000015229 Indent End
//DSN000015229 Add Start
    }
    else
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID == TXEWC015 || TXEWC016");
        // set the strAPCBaseCassetteList as return
        strAPCBaseCassetteListForOpeStartCancel = strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList;
    }
//DSN000015229 Add End
//D51M0000 add end

    /*--------------------------*/
    /*                          */
    /*   Set Return Structure   */
    /*                          */
    /*--------------------------*/
    strOpeStartCancelReqResult.strStartCassette = strStartCassette;

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/
    SET_MSG_RC( strOpeStartCancelReqResult, MSG_OK, RC_OK );

    PPT_METHODTRACE_EXIT("PPTManager_i:: txOpeStartCancelReq__120");
    return( RC_OK );
}
