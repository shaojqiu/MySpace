#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/txUnloadingLotForInternalBufferRpt.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:39:16 [ 7/13/07 21:39:17 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: txUnloadingLotForInternalBufferRpt.cpp
//

#include "cs_pptmgr.hpp"
#include "cs_posconst.hpp"

// Class: PPTManager
//
// Service: txUnloadingLotForInternalBufferRpt()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/08/01 0.00     S.Tokumasu     Initial Release
// 2001/08/24 D4000103 S.Tokumasu     Add equipment_loadLot_DeleteForInternalBuffer
// 2001/08/29 P4000125 S.Tokumasu     Add to check location.
// 2002/02/04 D4100110 S.Tokumasu     Add timeStamp into xferStatusChangeRpt
// 10/22/04   D6000025 K.Murakami     eBroker Migration.
// 2004/12/07 P6000027 K.Matsuei      UnloadingLotRpt fails in InternalBuffer.
// 2005/10/19 D6000479 K.Kido         Lock Port Object.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/11/30 DSN000049350 S.Liu          Equipment parallel processing support (P2)
// 2015/11/10 PSN000081321 XF.Ming        txLotCassetteXferStatusChangeRpt ==> txLotCassetteXferStatusChangeRpt__160
//
// ---------- -------- ---------------- ----------------------------------------------
// 2017/09/04 INN-R170003  Li Hejing      Durable Management Enhancement
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptUnloadingLotForInternalBufferRptResult&   strUnloadingLotForInternalBufferRptResult
//    const pptObjCommonIn&       strObjCommonIn
//    const objectIdentifier&     equipmentID
//    const objectIdentifier&     cassetteID
//    const objectIdentifier&     portID
//    const char *                claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//    1)Lock Equipment
//    2)Lock Cassette
//    3)Get Online Mode(portResource_currentOperationMode_Get)
//    4)Check TransferStatus="EI"(cassette_CheckConditionForUnloading)
//    5)When OperationMode=Mode_Offline&accessMode=Auto.
//        a)Get ControlJobID of Cassette(cassette_controlJobID_Get)
//        b)All Cassette Information(controlJob_containedLot_Get)
//        c)Lot of Cassette(cassette_GetLotList)
//        d)Check processState of All Lot that should be not equal to "Processing"(lot_CheckConditionForUnloading)
//    6)Check Unload Casstte On Port(equipment_portState_CheckForUnloading)
//        a)Check Port existance.
//        b)Check Cassette existance.
//    7)Delete Lots on Equipment(equipment_loadLot_Delete)
//        aMachine
//        aCassette
//        machineCassette = aMachine->findCassetteNamed(cassetteID.identifier);
//        aMachine->removeCassette(aCassette);
//        aMtrlLoc = aCassette->getLocation();
//        aMtrlLoc->materialSent();
//
//    8)Update TransferStatus of Cassette to "EO"(txLotCassetteXferStatusChangeRpt)
//

CORBA::Long CS_PPTManager_i:: txUnloadingLotForInternalBufferRpt (
    pptUnloadingLotForInternalBufferRptResult&   strUnloadingLotForInternalBufferRptResult, 
    const pptObjCommonIn&       strObjCommonIn, 
    const objectIdentifier&     equipmentID, 
    const objectIdentifier&     cassetteID, 
    const objectIdentifier&     portID, 
//D6000025     const char *                claimMemo, 
//D6000025     CORBA::Environment &        IT_env)
    const char *                claimMemo  //D6000025
    CORBAENV_LAST_CPP)                     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txUnloadingLotForInternalBufferRpt ");

    CORBA::Long rc = RC_OK ;

    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strUnloadingLotForInternalBufferRptResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRR006" ); // TxUnloadingLotForInternalBufferRpt
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strUnloadingLotForInternalBufferRptResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;
    
    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Advanced Mode
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strUnloadingLotForInternalBufferRptResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
        
        // Lock Equipment LoadCassette Element (Write)
        stringSequence loadCastSeq;
        loadCastSeq.length(1);
        loadCastSeq[0] = cassetteID.identifier;
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strUnloadingLotForInternalBufferRptResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "object_Lock(equipmentID) != RC_OK" );
            strUnloadingLotForInternalBufferRptResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

//D6000479 add start
    /**********************************************************/
    /*  Lock All Port Object for internal Buffer Equipment.   */
    /**********************************************************/
    objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
    rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                    strObjCommonIn,
                                                    equipmentID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
        strUnloadingLotForInternalBufferRptResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
        return( rc );
    }

    CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
    for( CORBA::Long i = 0 ; i < lenPortInfo ; i++ )
    {
//DSN000049350 Add Start
        if ( lockMode != SP_EQP_LOCK_MODE_WRITE && 
              0 != CIMFWStrCmp(strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier, portID.identifier))
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
            continue;
        }
//DSN000049350 Add End
        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[i].portID,
                                              SP_ClassName_PosPortResource );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource () rc != RC_OK", rc);
            strUnloadingLotForInternalBufferRptResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "Locked port object : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier);
    }
//D6000479 add end

    rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                      cassetteID, SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "object_Lock(cassetteID) != RC_OK" );
        strUnloadingLotForInternalBufferRptResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//--start P4000125
    /*-----------------------------------*/
    /*   Get Location                    */
    /*-----------------------------------*/
//P6000027    objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
//P6000027    PPT_METHODTRACE_V1("CS_PPTManager_i:: txUnloadingLotForInternalBufferRpt", "call equipment_portInfoForInternalBuffer_GetDR()...");
//P6000027
//P6000027    rc = equipment_portInfoForInternalBuffer_GetDR(strEquipment_portInfoForInternalBuffer_GetDR_out, strObjCommonIn, equipmentID);
//P6000027    if ( rc != RC_OK )
//P6000027    {
//P6000027        PPT_METHODTRACE_V2("CS_PPTManager_i:: txUnloadingLotForInternalBufferRpt", "rc = ",rc);
//P6000027        PPT_METHODTRACE_V1("CS_PPTManager_i:: txUnloadingLotForInternalBufferRpt", "equipment_portInfoForInternalBuffer_GetDR() rc != RC_OK");
//P6000027        strUnloadingLotForInternalBufferRptResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
//P6000027        return( rc );
//P6000027    }
//P6000027 start
    PPT_METHODTRACE_V1("", "call equipment_allCassetteOnPortForInternalBuffer_GetDR()");
    objEquipment_allCassetteOnPortForInternalBuffer_GetDR_out strEquipment_allCassetteOnPortForInternalBuffer_GetDR_out;
    rc = equipment_allCassetteOnPortForInternalBuffer_GetDR( strEquipment_allCassetteOnPortForInternalBuffer_GetDR_out, strObjCommonIn, equipmentID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "##### RC_OK != equipment_allCassetteOnPortForInternalBuffer_GetDR()",rc);
        strUnloadingLotForInternalBufferRptResult.strResult = strEquipment_allCassetteOnPortForInternalBuffer_GetDR_out.strResult;
        return( rc );
    }
//P6000027 end

    /*-----------------------------------*/
    /*   Check Location                  */
    /*-----------------------------------*/
//P6000027    CORBA::Long portLen = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
//P6000027    PPT_METHODTRACE_V2("CS_PPTManager_i:: txUnloadingLotForInternalBufferRpt", "portLen ",portLen);
//P6000027
//P6000027    CORBA::Boolean portFind = FALSE;
//P6000027
//P6000027    for(CORBA::Long p=0; p<portLen; p++)
//P6000027    {
//P6000027        PPT_METHODTRACE_V2("CS_PPTManager_i:: txUnloadingLotForInternalBufferRpt", "p--> ", p);
//P6000027
//P6000027        PPT_METHODTRACE_V2("cassetteID.identifier", "inparm's cassetteID", cassetteID.identifier);
//P6000027        PPT_METHODTRACE_V2("cassetteID.identifier", "loadedCassetteID  ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[p].loadedCassetteID.identifier);
//P6000027        PPT_METHODTRACE_V2("cassetteID.identifier", "inparm's portID   ", portID.identifier);
//P6000027        PPT_METHODTRACE_V2("cassetteID.identifier", "loadedPortID      ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[p].portID.identifier);
//P6000027
//P6000027        if(CIMFWStrCmp(cassetteID.identifier,
//P6000027                       strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[p].loadedCassetteID.identifier)==0
//P6000027        && CIMFWStrCmp(portID.identifier,
//P6000027                       strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[p].portID.identifier)==0)
//P6000027        {
//P6000027            portFind = TRUE; 
//P6000027            break;
//P6000027        }
//P6000027    }
//P6000027 start
    PPT_METHODTRACE_V2("", "inparm's cassetteID", cassetteID.identifier);
    PPT_METHODTRACE_V2("", "inparm's portID    ", portID.identifier);

    CORBA::Boolean portFind = FALSE;
    CORBA::Long portLen = strEquipment_allCassetteOnPortForInternalBuffer_GetDR_out.strPortInfo.length();
    PPT_METHODTRACE_V2("", "portLen", portLen);

    for ( CORBA::Long p=0; p < portLen; p++ )
    {
        PPT_METHODTRACE_V2("", "loadedCassetteID", strEquipment_allCassetteOnPortForInternalBuffer_GetDR_out.strPortInfo[p].cassetteID.identifier);
        PPT_METHODTRACE_V2("", "loadedPortID    ", strEquipment_allCassetteOnPortForInternalBuffer_GetDR_out.strPortInfo[p].portID.identifier);

        if ( 0 == CIMFWStrCmp(cassetteID.identifier, strEquipment_allCassetteOnPortForInternalBuffer_GetDR_out.strPortInfo[p].cassetteID.identifier)
          && 0 == CIMFWStrCmp(portID.identifier, strEquipment_allCassetteOnPortForInternalBuffer_GetDR_out.strPortInfo[p].portID.identifier) )
        {
            PPT_METHODTRACE_V1("", "Found Inparam's information");
            portFind = TRUE;
            break;
        }
    }
//P6000027 end

    if(!portFind)
    {
        PPT_METHODTRACE_V1("", "portFind is FALSE!") ;
        SET_MSG_RC( strUnloadingLotForInternalBufferRptResult,
                    MSG_NO_CASSETTE_ON_PORT,
                    RC_NO_CASSETTE_ON_PORT );
        return (RC_NO_CASSETTE_ON_PORT) ;
    }
//--end P4000125

     /*---------------------------------*/
     /*   Get Equipment's Online Mode   */
     /*---------------------------------*/
     objPortResource_currentOperationMode_Get_out  strPortResource_currentOperationMode_Get_out;
     rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                 strObjCommonIn,
                                                 equipmentID,
                                                 portID );
     if ( rc != RC_OK )
     {
         PPT_METHODTRACE_V1( "", "portResource_currentOperationMode_Get() != RC_OK" );
         strUnloadingLotForInternalBufferRptResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
         return( rc );
     }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - transferState                                                     */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objCassette_CheckConditionForUnloading_out strCassette_CheckConditionForUnloading_out;
    rc = cassette_CheckConditionForUnloading( strCassette_CheckConditionForUnloading_out, strObjCommonIn,
                                              cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "cassette_CheckConditionForUnloading() != RC_OK" );
        strUnloadingLotForInternalBufferRptResult.strResult = strCassette_CheckConditionForUnloading_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - lotProcessState                                                   */
    /*                                                                       */
    /*   Note:                                                               */
    /*   If equipment is Offline or Auto-Access case, all of lot, which is   */
    /*   contained in cassette of same controlJob of in-parm's cassette,     */
    /*   must not be "Processing".                                           */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/


    /*--------------------------------*/
    /*   Check Port's OperationMode   */
    /*--------------------------------*/
    if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline) ||
         0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto) )
    {
        /*---------------------------------*/
        /*   Get Cassette's ControlJobID   */
        /*---------------------------------*/
        objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

        rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                        strObjCommonIn,
                                        cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
            strUnloadingLotForInternalBufferRptResult.strResult = strCassette_controlJobID_Get_out.strResult;
            return( rc );
        }

        if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
        {
            PPT_METHODTRACE_V1( "", "len(controlJobID) > 0" );

            /*-------------------------*/
            /*   Get ControlJob Info   */
            /*-------------------------*/
            PPT_METHODTRACE_V1( "", "Get ControlJob Info" );

            objControlJob_containedLot_Get_out strControlJob_containedLot_Get_out;

            rc = controlJob_containedLot_Get( strControlJob_containedLot_Get_out,
                                              strObjCommonIn,
                                              strCassette_controlJobID_Get_out.controlJobID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "controlJob_containedLot_Get() != RC_OK" );
                strUnloadingLotForInternalBufferRptResult.strResult = strControlJob_containedLot_Get_out.strResult;
                return( rc );
            }

            /*----------------------------------------*/
            /*   Check ControlJobLot's ProcessState   */
            /*----------------------------------------*/
            PPT_METHODTRACE_V1( "", "Check ControlJobLot's ProcessState" );
            CORBA::Long lenCtrlJobCassette = strControlJob_containedLot_Get_out.strControlJobCassette.length();
            CORBA::Long lenCtrlJobLot;
            PPT_METHODTRACE_V2( "", "strControlJobCassette.length--->", lenCtrlJobCassette);

            for ( CORBA::Long i=0; i < lenCtrlJobCassette; i++ )
            {
                lenCtrlJobLot = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot.length();
                PPT_METHODTRACE_V2( "", "strControlJobLot.length--->", lenCtrlJobLot);

                if ( 0 == lenCtrlJobLot )
                {
                    PPT_METHODTRACE_V1( "", "0 == lenCtrlJobLot" );
                    continue;
                }

                PPT_METHODTRACE_V2( "", "strControlJobCassette[i].cassetteID--->",
                                strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID.identifier);

                objCassette_GetLotList_out strCassette_GetLotList_out;
                rc = cassette_GetLotList( strCassette_GetLotList_out,
                                          strObjCommonIn,
                                          strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID );
                    if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "cassette_GetLotList() != RC_OK" );
                    strUnloadingLotForInternalBufferRptResult.strResult = strCassette_GetLotList_out.strResult;
                    return( rc );
                }

                objLot_CheckConditionForUnloading_out strLot_CheckConditionForUnloading_out;

                rc = lot_CheckConditionForUnloading( strLot_CheckConditionForUnloading_out,
                                                     strObjCommonIn,
                                                     strCassette_GetLotList_out.strLotListInCassetteInfo );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "lot_CheckConditionForUnloading() != RC_OK" );
                    strUnloadingLotForInternalBufferRptResult.strResult = strLot_CheckConditionForUnloading_out.strResult;
                    return( rc );
                }
            }
        }
    }

    /*-----------------------------------------------------------------------------*/
    /*                                                                             */
    /*   Check Equipment Port for Unloading                                        */
    /*                                                                             */
    /*   The following conditions are checked by this object                       */
    /*                                                                             */
    /*   - In-parm's portID must has loadedCassetteID, and it must be same as      */
    /*     in-parm's cassetteID.                                                   */
    /*                                                                             */
    /*-----------------------------------------------------------------------------*/
    objEquipment_portState_CheckForUnloading_out strEquipment_portState_CheckForUnloading_out;
    rc = equipment_portState_CheckForUnloading( strEquipment_portState_CheckForUnloading_out, strObjCommonIn,
                                                equipmentID, portID, cassetteID );
    if ( rc != RC_OK && rc !=RC_INVALID_CAST_PORT_COMBINATION) 
    {
        PPT_METHODTRACE_V1( "", "equipment_portState_CheckForUnloading() != RC_OK" );
        strUnloadingLotForInternalBufferRptResult.strResult = strEquipment_portState_CheckForUnloading_out.strResult;
        return( rc );
    }


    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//  /*------------------------------------------------------*/
//  /*                                                      */
//  /*     Clear Loaded Cassette Information on Equipment   */
//  /*                                                      */
//  /*------------------------------------------------------*/
//  objEquipment_loadLot_Delete_out strEquipment_loadLot_Delete_out;
//  rc = equipment_loadLot_Delete( strEquipment_loadLot_Delete_out, strObjCommonIn,
//                                 equipmentID, portID, cassetteID );
//  if ( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1( "CS_PPTManager_i:: txUnloadingLotForInternalBufferRpt", "equipment_loadLot_Delete() != RC_OK" );
//      strUnloadingLotForInternalBufferRptResult.strResult = strEquipment_loadLot_Delete_out.strResult;
//      return( rc );
//  }
//
//-- start D4000103
    /*------------------------------------------------------*/
    /*                                                      */
    /*     Clear Loaded Cassette Information on Equipment   */
    /*                                                      */
    /*------------------------------------------------------*/
    objEquipment_loadLot_DeleteForInternalBuffer_out strEquipment_loadLot_DeleteForInternalBuffer_out;
    rc = equipment_loadLot_DeleteForInternalBuffer( strEquipment_loadLot_DeleteForInternalBuffer_out, strObjCommonIn,
                                   equipmentID, portID, cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "equipment_loadLot_DeleteForInternalBuffer() != RC_OK" );
        strUnloadingLotForInternalBufferRptResult.strResult = strEquipment_loadLot_DeleteForInternalBuffer_out.strResult;
        return( rc );
    }
//-- end   D4000103
    /*-------------------------------------------------------*/
    /*                                                       */
    /*     Change Cassette's TransferState to EquipmentOut   */
    /*                                                       */
    /*-------------------------------------------------------*/

    /*------------------------------------------------------------*/
    /*   Prepare In-Parm for txLotCassetteXferStatusChangeRpt()   */
    /*------------------------------------------------------------*/
    objectIdentifier  dummyStockerID;
    pptXferLot        strXferLot;

    strXferLot.cassetteID     = cassetteID;
    strXferLot.portID         = portID;
//INN-R170003    strXferLot.transferStatus = CIMFWStrDup( SP_TransState_EquipmentOut );
    strXferLot.transferStatus = CIMFWStrDup( CS_TRANS_STATE_PORT_OUT );  //INN-R170003
    PPT_METHODTRACE_V2("", "strXferLot.transferStatus = ",strXferLot.transferStatus);  //INN-R170003

    /*-----------------------------------------------------------------*/
    /*   Call txLotCassetteXferStatusChangeRpt() with 'EquipmentOut'   */
    /*-----------------------------------------------------------------*/
    pptLotCassetteXferStatusChangeRptResult strLotCassetteXferStatusChangeRptResult;
//PSN000081321    rc = txLotCassetteXferStatusChangeRpt( strLotCassetteXferStatusChangeRptResult, strObjCommonIn,
//INN-R170003    rc = txLotCassetteXferStatusChangeRpt__160( strLotCassetteXferStatusChangeRptResult, strObjCommonIn,    //PSN000081321
//INN-R170003                                           cassetteID, SP_TransState_EquipmentOut, FALSE,
//INN-R170003 add start
    rc = txLotCassetteXferStatusChangeRpt__160( strLotCassetteXferStatusChangeRptResult, strObjCommonIn,
                                           cassetteID, CS_TRANS_STATE_PORT_OUT, FALSE,
//INN-R170003 add end
                                           equipmentID, portID, "", "",
//PSN000081321                                           strObjCommonIn.strTimeStamp.reportTimeStamp); //D4100110
                                           strObjCommonIn.strTimeStamp.reportTimeStamp, //PSN000081321
                                           claimMemo);  //PSN000081321
    if ( rc != RC_OK )
    {
//PSN000081321        PPT_METHODTRACE_V1( "", "txLotCassetteXferStatusChangeRpt() != RC_OK" );
        PPT_METHODTRACE_V1( "", "txLotCassetteXferStatusChangeRpt__160() != RC_OK" );    //PSN000081321
        strUnloadingLotForInternalBufferRptResult.strResult = strLotCassetteXferStatusChangeRptResult.strResult;
        return( rc );
    }

     /*----------------------*/
     /*                      */
     /*   Return to Caller   */
     /*                      */
     /*----------------------*/
    SET_MSG_RC( strUnloadingLotForInternalBufferRptResult, MSG_OK, RC_OK );

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txUnloadingLotForInternalBufferRpt ");
    return( RC_OK );
}
