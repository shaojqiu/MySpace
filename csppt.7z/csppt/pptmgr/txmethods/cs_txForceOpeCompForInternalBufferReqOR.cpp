#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/txForceOpeCompForInternalBufferReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 9/25/07 18:34:38 [ 9/25/07 18:34:42 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txForceOpeCompForInternalBufferReqOR.cpp
//

//INN-R170002 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"    //INN-R170002
#include "pevclctd.hh"

#include <unistd.h>

void DebugOutStartCassette(pptDataSpecCheckReqResult& tg);  //DSIV00000201

// Class: PPTManager
//
// Service: txForceOpeCompForInternalBufferReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/01/20 D4100080 Y.Nagamine     Initial Release (R30)
// 2002/02/08 D4100083 T.Michii       Enhancement Future Hold
// 2002/02/15 D4100069 C.Tsuchiya     Drop LCFR logic
// 2002/02/15 D4100134 C.Tsuchiya     Use getenv() instead of Mgr class member "theSP_xxx'
// 2002/02/27 D4100120 N.Minami       Future Action
// 2002/03/07 D4100083 T.Michii       Fix length of structure
// 2002/03/26 P4100273 Y.Nagamine     Fix TXID for Event
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/03 P4200025 T.Nishimura    Source Check : return without message.
// 2002/07/30 D4200029 K.Kimura       Process Hold Control
// 2002/09/27 D4200115 C.Tsuchiya     New Action by SPC Check
// 2002/09/30 P4200204 H.Adachi       Add Parameter of holdReleasedLotIDs for txForceOpeCompForInternalBufferReq
// 2002/12/09 P4200438 H.Adachi       Add Error handling
// 2003/09/09 D5000225 T.Hikari       When "AddToQueue" failes, continuation of processing is enabled.
// 2004/04/07 D5100232 K.Matsuei      Initial Release. Add DCS Interfact to MM.
// 2004/04/19 D5100184 H.Hasegawa     Add the logic which repeats Gate Pass for Monitored Lot
// 2004/06/08 P5100366 K.Kido         Change return code handling for txEntityInhibitReq().
// 2004/08/03 P5100473 H.Adachi       Add logic of setting parameter for txSchdlChangeReservationExecuteReq().
// 2004/08/11 D51M0000 M.Mori         APC I/F Enhance for Interface Spec-B
// 2004/09/24 P51M0018 M.Mori         Change Set Return Structure after APC.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2004/11/08 P6000018 K.Kido         Chg Enitity Inhibit error handling.
// 2005/10/24 D6000479 K.Kido         Lock Port Object.
// 2005/10/31 D7000006 T.Ohsaki       exchange "controlJob_Delete()" to "txControlJobManageReq()"
// 2005/12/12 D7000096 Y.Kadowaki     Delete environment variable "SP_DELIVERY_REQ_EXIST"
// 2006/01/20 D7000182 H.Mutoh        Enhancement of re-sending APCControlJobInformation.
// 2006/04/12 P7000126 H.Mutoh        Fix number of cases of Mail and same Contents.
// 2006/10/26 D7000354 H.Hasegawa     Add the logic which resets Q-Time actions
// 2007/09/18 D9000084 K.Kido         Set last used time of used reticle.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/08 DSIV00000201 M.Ishino       Improvement of Post-Processing.
// 2009/04/10 PSIV00000888 R.Okano        Change logic not to create CollectedDataEvent when CollectedDataAction is performed in PostProcess.
// 2009/11/13 DSIV00001471 F.Chen         Collected data validation enhancement.
// 2010/10/14 DSIV00002435 M.Ogawa        Support SubLotType change by Schedule Change Reservation
// 2011/03/15 PSIV00003068 N.Makino       Change logic so that 'RunningHold' is released before execution of 'FututeHold' or 'ProcessHold'.
// 2011/08/31 DSN000015229 Sa Guo         Do not delete controlJob object if it is called from partial operation completion
// 2012/07/24 DSN000043340 M.Ogawa        Post process migration mode
// 2012/11/30 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
// 2014/06/04 DSN000085791 C.Mo           Entity Inhibit Exception Lot Support. (R150)
// 2016/11/18 PSN000103621 Q.Li           Add Lock Material Location.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/07 INN-R170002  JQ.Shao        Contamination Control
// 2017/09/12 INN-R170002  Thomas.Song    Contamination Control
// 2017/09/22 INN-R170003  Joan Zhou      Change status to WaitClean when operation complete with clean flag
// 2017/10/19 INN-R170009  Qufd           Send Used Recipe Parameter to APC
//
// Description:
//
// Return:
//     long

// TX Generates Return Code and Message :

// Return Code                             Message
// --------------------------------------- ---------------------------------------
// RC_INVALID_LOT_PROCSTAT                 MSG_INVALID_LOT_PROCSTAT
// -                                       MSG_FAIL_MAKE_HISTORY
// RC_PILOT_WAFER_ID_NOT_BLANK             MSG_PILOT_WAFER_ID_NOT_BLANK
// RC_ROUTEID_DELETED                      MSG_ROUTEID_DELETED
// RC_OPENO_DELETED                        MSG_OPENO_DELETED
//
//
// Parameter:
//
//      pptForceOpeCompForInternalBufferReqResult& strForceOpeCompForInternalBufferReqResult
//      const pptObjCommonIn& strObjCommonIn
//      const objectIdentifier& equipmentID
//      const objectIdentifier& controlJobID
//      CORBA::Boolean spcResultRequiredFlag
//      const char * claimMemo
//      objectIdentifierSequence holdReleasedLotIDs                          //P4200204
//      CORBA::Environment& IT_env
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//P4200204 Delete Start
//CORBA::Long CS_PPTManager_i::txForceOpeCompForInternalBufferReq (
//            pptForceOpeCompForInternalBufferReqResult& strForceOpeCompForInternalBufferReqResult,
//            const pptObjCommonIn&       strObjCommonIn,
//            const objectIdentifier&     equipmentID,
//            const objectIdentifier&     controlJobID,
//            CORBA::Boolean              spcResultRequiredFlag,
//            const char*                 claimMemo,
//            CORBA::Environment &        IT_env)
//P4200204 Delete End

//P4200204 Add
CORBA::Long CS_PPTManager_i::txForceOpeCompForInternalBufferReq (
            pptForceOpeCompForInternalBufferReqResult& strForceOpeCompForInternalBufferReqResult,
            const pptObjCommonIn&       strObjCommonIn,
            const objectIdentifier&     equipmentID,
            const objectIdentifier&     controlJobID,
            CORBA::Boolean              spcResultRequiredFlag,
            const char*                 claimMemo,
//D6000025             objectIdentifierSequence&   holdReleasedLotIDs,
//D6000025             CORBA::Environment &        IT_env)
//D7000182            objectIdentifierSequence&   holdReleasedLotIDs //D6000025
            objectIdentifierSequence&   holdReleasedLotIDs, //D7000182
            char *&                     APCIFControlStatus  //D7000182
            CORBAENV_LAST_CPP)                             //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txForceOpeCompForInternalBufferReq") ;
    CORBA::Long rc = RC_OK ;
    CORBA::Long PostProcForLotFlag = atoi(getenv(SP_POSTPROC_FOR_LOT_FLAG));    //DSIV00000201

    //D4000015 Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//D4100080     CORBA::Boolean  EmptyPortFlag = FALSE;                                    //P3000364
//D4100080    /*-----------------------------------------------------------------------*/
//D4100080    /*   Get unload information which is sepcified with ControlJob ID        */
//D4100080    /*-----------------------------------------------------------------------*/
//D4100080    CORBA::String_var deliveryReqExist = theSP_DELIVERY_REQ_EXIST;   //D4000011
//D4100080
//D4100080    PPT_METHODTRACE_V2("","deliveryReqExist=",deliveryReqExist);
//D4100080
//D4100080    objEquipment_inprocessingControlJobInfo_Get_out strEquipment_inprocessingControlJobInfo_Get_out;
//D4100080    if ( 0 != CIMFWStrCmp(deliveryReqExist, "YES") )
//D4100080    {
//D4100080        rc = equipment_inprocessingControlJobInfo_Get( strEquipment_inprocessingControlJobInfo_Get_out,
//D4100080                                                       strObjCommonIn,
//D4100080                                                       equipmentID);
//D4100080        if( rc != RC_OK )
//D4100080        {
//D4100080            PPT_METHODTRACE_V1("", "equipment_inprocessingControlJobInfo_Get() != RC_OK") ;
//D4100080            strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_inprocessingControlJobInfo_Get_out.strResult ;
//D4100080            return( rc );
//D4100080        }
//D4100080    }

    /*-----------------------------------------------------------------------*/
    /*   Get Started Lot information which is sepcified with ControlJob ID   */
    /*-----------------------------------------------------------------------*/
    objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
    rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
                                                 strObjCommonIn,
                                                 controlJobID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult ;
        return( rc );
    }

    CORBA::Long scLen = 0;
    scLen = strControlJob_startReserveInformation_Get_out.strStartCassette.length();
    PPT_METHODTRACE_V2("", "strControlJob_startReserveInformation_Get_out.strStartCassette.length()", scLen) ;

    CORBA::Long totalStartLotCount = 0;    //D4100083 (03/07)

    CORBA::Long ii, jj, kk, ll;
    CORBA::Long leng1, leng2, leng3;
    for (ii=0; ii < scLen; ii++)
    {
        leng1 = strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette.length();
        PPT_METHODTRACE_V2("","strLotInCassette.length--->", leng1);
        for (jj=0; jj < leng1; jj++)
        {
//D4100083 (03/07)  add
            if ( strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].operationStartFlag == TRUE )
            {
                totalStartLotCount ++ ;
            }
//D4100083 (03/07)  end
            leng2 = strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef.length();
            PPT_METHODTRACE_V2("","strStartRecipe.strDCDef.length--->", leng2);
            for (kk=0; kk < leng2; kk++)
            {
                leng3 = strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem.length();
                PPT_METHODTRACE_V2("","strDCDef.strDCItem.length--->", leng3);
                for (ll=0; ll < leng3; ll++)
                {
                    PPT_METHODTRACE_V2("","specCheckResult--->",
                    strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].specCheckResult);
                }
            }
        }
    }

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXEWC011" ); // TxForceOpeCompForInternalBufferReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strForceOpeCompForInternalBufferReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strForceOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*--------------------------------*/
        /*   Lock Macihne object          */
        /*--------------------------------*/
//DSN000049350        objObject_Lock_out  strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
            strForceOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult ;
            return( rc );
        }
    } //DSN000049350

//DSN000049350 Move to later session
//DSN000049350 //D6000479 add start
//DSN000049350     /**********************************************************/
//DSN000049350     /*  Lock All Port Object for internal Buffer Equipment.   */
//DSN000049350     /**********************************************************/
//DSN000049350     objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
//DSN000049350     rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
//DSN000049350                                                     strObjCommonIn,
//DSN000049350                                                     equipmentID );
//DSN000049350     if ( rc != RC_OK )
//DSN000049350     {
//DSN000049350         PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
//DSN000049350         strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
//DSN000049350         return( rc );
//DSN000049350     }
//DSN000049350
//DSN000049350     CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
//DSN000049350     for( CORBA::Long j = 0 ; j < lenPortInfo ; j++ )
//DSN000049350     {
//DSN000049350         objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
//DSN000049350         rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
//DSN000049350                                               strObjCommonIn,
//DSN000049350                                               equipmentID,
//DSN000049350                                               strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID,
//DSN000049350                                               SP_ClassName_PosPortResource );
//DSN000049350         if ( rc != RC_OK )
//DSN000049350         {
//DSN000049350             PPT_METHODTRACE_V2("", "object_LockForEquipmentResource () rc != RC_OK", rc);
//DSN000049350             strForceOpeCompForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
//DSN000049350             return( rc );
//DSN000049350         }
//DSN000049350         PPT_METHODTRACE_V2("", "Locked port object : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier);
//DSN000049350     }
//DSN000049350 //D6000479 add end

    /*--------------------------------*/
    /*   Lock Cassette / Lot Object   */
    /*--------------------------------*/

    pptStartCassetteSequence  strStartCassette(scLen);
    strStartCassette.length(scLen);

    //P4100536 add start
    // Check length of Start Cassette
    if(0 >= strStartCassette.length())
    {
        PPT_SET_MSG_RC_KEY(strForceOpeCompForInternalBufferReqResult, MSG_NOT_FOUND_CASSETTE, RC_NOT_FOUND_CASSETTE, "(There is no started cassette.)"); //P4200025 add
        return RC_NOT_FOUND_CASSETTE;
    }
    //P4100536 add end

//DSN000049350 Add Start
    objectIdentifierSequence lotIDs;
    objectIdentifierSequence cassetteIDs;
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_lotIDLen    = extendLen;
    CORBA::ULong lotIDCnt      = 0;
    CORBA::ULong cassetteIDCnt = 0;
    lotIDs.length(t_lotIDLen);
    cassetteIDs.length(scLen);
//DSN000049350 Add End

    for (CORBA::Long i=0; i<scLen; i++)
    {
        strStartCassette[i] = strControlJob_startReserveInformation_Get_out.strStartCassette[i];

        CORBA::Long nLen = 0;                                                            //0.02
        nLen =  strStartCassette[i].strLotInCassette.length();                           //0.02
        PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()", nLen) ;  //0.02

        /*--------------------------*/
        /*   Lock Cassette Object   */
        /*--------------------------*/
        if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
        {
            PPT_METHODTRACE_V2("", "CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0", i) ;

//D4100080            EmptyPortFlag = TRUE;                                                       //P3000364

            objEquipment_monitorCreationFlag_Get_out   strEquipment_monitorCreationFlag_Get_out;
            rc = equipment_monitorCreationFlag_Get( strEquipment_monitorCreationFlag_Get_out,
                                                    strObjCommonIn,
                                                    equipmentID);
            //---------------------------------------------------------------------------------------------
            //    if monitor creationflag was TRUE, at least one Lot should be existed in Empty Cassete.
            //---------------------------------------------------------------------------------------------
            //P4200438 Add Start
            if ( rc != RC_OK )                                                                                  //P4200438
            {                                                                                                   //P4200438 Following logic was nested.

                if ( rc == RC_MONITOR_CREAT_REQD )
                {
                    if ( nLen == 0 )
                    {
//P4200438                        PPT_METHODTRACE_V1("", "object_Lock() == RC_MONITOR_CREAT_REQD") ;
                        PPT_METHODTRACE_V1("", "equipment_monitorCreationFlag_Get() == RC_MONITOR_CREAT_REQD"); //P4200438
                        SET_MSG_RC(strForceOpeCompForInternalBufferReqResult, MSG_MONITOR_CREAT_REQD, rc) ;
                        return( rc );
                    }
                }
                else if ( rc == RC_NOT_FOUND_EQP )                                                              //P4200438
                {                                                                                               //P4200438
                    PPT_METHODTRACE_V1("", "equipment_monitorCreationFlag_Get() == RC_NOT_FOUND_EQP") ;         //P4200438
                    strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_monitorCreationFlag_Get_out.strResult ;   //P4200438
                    return( rc );                                                                               //P4200438
                }                                                                                               //P4200438
                else                                                                                            //P4200438
                {                                                                                               //P4200438
                    // Do nothing.                                                                              //P4200438
                    // Because equipment_monitorCreationFlag_Get returns                                        //P4200438
                    // RC_MONITOR_CREAT_REQD, RC_MONITOR_CREAT_NOT_REQD,                                        //P4200438
                    // or RC_NOT_FOUND_EQP only.                                                                //P4200438
                    PPT_METHODTRACE_V2("","equipment_monitorCreationFlag_Get() Returns",                        //P4200438
                                       strEquipment_monitorCreationFlag_Get_out.strResult.messageText);         //P4200438
                }                                                                                               //P4200438
            }                                                                                                   //P4200438

//DSN000049350            objObject_Lock_out  strObject_Lock_out;
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn, strStartCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
//DSN000049350                strForceOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult ;
//DSN000049350                return( rc );
//DSN000049350            }
            cassetteIDs[cassetteIDCnt++] = strStartCassette[i].cassetteID;  //DSN000049350

            continue;
        }

//DSN000049350        objObject_Lock_out  strObject_Lock_out;
//DSN000049350        rc = object_Lock( strObject_Lock_out, strObjCommonIn, strStartCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350        if ( rc != RC_OK )
//DSN000049350        {
//DSN000049350            PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
//DSN000049350            strForceOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult ;
//DSN000049350            return( rc );
//DSN000049350        }
        cassetteIDs[cassetteIDCnt++] = strStartCassette[i].cassetteID;  //DSN000049350

        for (CORBA::Long j=0; j<nLen; j++)
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
               PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE") ;
                continue;
            }

            /*---------------------*/
            /*   Lock Lot Object   */
            /*---------------------*/
//DSN000049350            objObject_Lock_out  strObject_Lock_out;
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
//DSN000049350                strForceOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult ;
//DSN000049350                return( rc );
//DSN000049350            }

//DSN000049350 Add Start
            if( lotIDCnt >= t_lotIDLen )
            {
                PPT_METHODTRACE_V1("", "lotIDCnt >= t_lotIDLen");
                t_lotIDLen += extendLen;
                lotIDs.length( t_lotIDLen );
            }
            lotIDs[lotIDCnt++] = strStartCassette[i].strLotInCassette[j].lotID;
//DSN000049350 Add End
        }
    }
    cassetteIDs.length(cassetteIDCnt);  //DSN000049350
    lotIDs.length(lotIDCnt);            //DSN000049350

    PPT_METHODTRACE_V2( "", "cassetteIDCnt", cassetteIDCnt);    //DSN000049350
    PPT_METHODTRACE_V2( "", "lotIDCnt", lotIDCnt);              //DSN000049350

//DSN000049350 Add Start
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
        rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out, strObjCommonIn, equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
            strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
            return rc;
        }

        if ( 0 == CIMFWStrCmp( strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline ) )
        {
            // Lock Equipment ProcLot Element (Count)
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_COUNT;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                       strObjCommonIn,
                                       strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strForceOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }

        // Lock Equipment ProcLot Element (Write)
        stringSequence procLotSeq;
        procLotSeq.length(lotIDCnt);
        for ( CORBA::ULong procLotNo = 0; procLotNo < lotIDCnt; procLotNo++ )
        {
            procLotSeq[procLotNo] = lotIDs[procLotNo].identifier;
        }
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
        strAdvanced_object_Lock_in.keySeq     = procLotSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strForceOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Move from earlier session
//D6000479 add start
        /**********************************************************/
        /*  Lock All Port Object for internal Buffer Equipment.   */
        /**********************************************************/
        objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
        rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                        strObjCommonIn,
                                                        equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
            strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
            return( rc );
        }

        CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
        for( CORBA::Long j = 0 ; j < lenPortInfo ; j++ )
        {
            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  equipmentID,
                                                  strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                  SP_ClassName_PosPortResource );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource () rc != RC_OK", rc);
                strForceOpeCompForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "Locked port object : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier);
        }
//D6000479 add end
//DSN000049350 Move End
    }
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
//PSN000103621 Add Start
        /*------------------------------*/
        /*   Lock Material Location     */
        /*------------------------------*/
        for ( CORBA::Long ij = 0 ; ij < scLen ; ij++ )
        {
            objAdvanced_object_LockForEquipmentResource_out strAdvanced_object_LockForEquipmentResource_out;
            objAdvanced_object_LockForEquipmentResource_in strAdvanced_object_LockForEquipmentResource_in;
            strAdvanced_object_LockForEquipmentResource_in.equipmentID              = equipmentID;
            strAdvanced_object_LockForEquipmentResource_in.className                = CIMFWStrDup( SP_ClassName_PosMaterialLocation_ByCJ );
            strAdvanced_object_LockForEquipmentResource_in.objectID                 = controlJobID;
            strAdvanced_object_LockForEquipmentResource_in.objectLockType           = SP_ObjectLock_LockType_WRITE;
            strAdvanced_object_LockForEquipmentResource_in.bufferResourceName       = strStartCassette[ij].loadPurposeType;
            strAdvanced_object_LockForEquipmentResource_in.bufferResourceLockType   = SP_ObjectLock_LockType_READ;

            PPT_METHODTRACE_V2( "", "calling advanced_object_LockForEquipmentResource()", SP_ClassName_PosMaterialLocation_ByCJ );
            rc =  advanced_object_LockForEquipmentResource( strAdvanced_object_LockForEquipmentResource_out,
                                                            strObjCommonIn,
                                                            strAdvanced_object_LockForEquipmentResource_in );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_LockForEquipmentResource() != RC_OK", rc);
                strForceOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_LockForEquipmentResource_out.strResult ;
                return( rc );
            }
        }
//PSN000103621 Add End
        /*------------------------------*/
        /*   Lock ControlJob Object     */
        /*------------------------------*/
        PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosControlJob );
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          controlJobID,
                          SP_ClassName_PosControlJob );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strForceOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }
    /*------------------------------*/
    /*   Lock Cassette/Lot Object   */
    /*-------------------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strForceOpeCompForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosLot );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              lotIDs,
                              SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strForceOpeCompForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

//D51M0000 Add Start
    /*-------------------------------------------------*/
    /*   call cassette_APCInformation_GetDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call cassette_APCInformation_GetDR") ;

    objCassette_APCInformation_GetDR_out strCassette_APCInformation_GetDR_out;
    rc = cassette_APCInformation_GetDR ( strCassette_APCInformation_GetDR_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         strStartCassette );
    if ( rc == RC_SYSTEM_ERROR )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() == RC_SYSTEM_ERROR");
        strForceOpeCompForInternalBufferReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
        return ( rc );
    }
    else if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() != RC_OK");
        strForceOpeCompForInternalBufferReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
    }
//D51M0000 Add End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*---------------------------------*/
    /*   Get Equipment's Online Mode   */
    /*---------------------------------*/
    objPortResource_currentOperationMode_Get_out  strPortResource_currentOperationMode_Get_out;
    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                strObjCommonIn,
                                                equipmentID,
                                                strStartCassette[0].unloadPortID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult ;
        return( rc );
    }


    /*----------------------------------------------------------------------------*/
    /*                                                                            */
    /*   If AccessMode is Auto or OnlineMode is Offline, do the following check.  */
    /*                                                                            */
    /*----------------------------------------------------------------------------*/
//D4100080    if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode,SP_Eqp_OnlineMode_Offline) == 0||
//D4100080         CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,SP_Eqp_AccessMode_Auto   ) == 0 )
//D4100080    {
//D4100080
//D4100080        // End of P3000223
//D4100080
//D4100080        /*-----------------------------------------------------------------------*/
//D4100080        /*                                                                       */
//D4100080        /*   Check Process for Cassette                                          */
//D4100080        /*                                                                       */
//D4100080        /*   The following conditions are checked by this object                 */
//D4100080        /*                                                                       */
//D4100080        /*   - transferState                                                     */
//D4100080        /*                                                                       */
//D4100080        /*-----------------------------------------------------------------------*/
//D4100080        objCassette_CheckConditionForOpeComp_out   strCassette_CheckConditionForOpeComp_out;
//D4100080        rc = cassette_CheckConditionForOpeComp( strCassette_CheckConditionForOpeComp_out,
//D4100080                                                strObjCommonIn,
//D4100080                                                strStartCassette );
//D4100080        if ( rc != RC_OK )
//D4100080        {
//D4100080            PPT_METHODTRACE_V1("", "cassette_CheckConditionForOpeComp() != RC_OK") ;
//D4100080            strForceOpeCompForInternalBufferReqResult.strResult = strCassette_CheckConditionForOpeComp_out.strResult ;
//D4100080            return( rc );
//D4100080        }

//D4100080        // Start of L0.03
//D4100080        /*-----------------------------------------------------------------------*/
//D4100080        /*                                                                       */
//D4100080        /*   Check Equipment Port for OpeComp                                    */
//D4100080        /*                                                                       */
//D4100080        /*   The following conditions are checked by this object                 */
//D4100080        /*                                                                       */
//D4100080        /*   - All of Cassette, which is contained in controlJob, must be on     */
//D4100080        /*     the equipment's unloadingPort.                                    */
//D4100080        /*                                                                       */
//D4100080        /*-----------------------------------------------------------------------*/
//D4100080        objEquipment_portState_CheckForOpeComp_out   strEquipment_portState_CheckForOpeComp_out;
//D4100080        rc = equipment_portState_CheckForOpeComp( strEquipment_portState_CheckForOpeComp_out,
//D4100080                                                  strObjCommonIn,
//D4100080                                                  equipmentID,
//D4100080                                                  strStartCassette );
//D4100080        if ( rc != RC_OK )
//D4100080        {
//D4100080            PPT_METHODTRACE_V1("", "equipment_portState_CheckForOpeComp() != RC_OK") ;
//D4100080            strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_portState_CheckForOpeComp_out.strResult ;
//D4100080            return( rc );
//D4100080        }
//D4100080        // End of L0.03
//D4100080
//D4100080    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - lotProcessState                                                   */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//D4100080 Add Start
    for ( i=0 ; i<scLen ; i++ )
    {
        CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0; j<nLen; j++)
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            objLot_allState_Get_out strLot_allState_Get_out;
            rc = lot_allState_Get( strLot_allState_Get_out,
                                   strObjCommonIn,
                                   strStartCassette[i].strLotInCassette[j].lotID);
            if ( rc )
            {
                PPT_METHODTRACE_V1("", "lot_allState_Get() != RC_OK");
                strForceOpeCompForInternalBufferReqResult.strResult = strLot_allState_Get_out.strResult;
                return(rc);
            }

            if (CIMFWStrCmp(strLot_allState_Get_out.processState, SP_Lot_ProcState_Processing) != 0)
            {
                PPT_METHODTRACE_V1("", "lot_allState_Get() strLot_allState_Get_out.processState == SP_Lot_ProcState_Processing");
                PPT_SET_MSG_RC_KEY2(strForceOpeCompForInternalBufferReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                                    strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                    strLot_allState_Get_out.processState);
                return( RC_INVALID_LOT_PROCSTAT );
            }

            if (CIMFWStrCmp(strLot_allState_Get_out.holdState , CIMFW_Lot_HoldState_NotOnHold) == 0)
            {
                PPT_METHODTRACE_V1("", "HoldState == NotOnHold");
                PPT_SET_MSG_RC_KEY2(strForceOpeCompForInternalBufferReqResult, MSG_INVALID_LOT_HOLDSTAT, RC_INVALID_LOT_HOLDSTAT,
                                    strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                    strLot_allState_Get_out.holdState);
                return( RC_INVALID_LOT_HOLDSTAT );
            }

         }
    }
//D4100080 Add End
//D4100080    objLot_CheckConditionForOpeComp_out   strLot_CheckConditionForOpeComp_out;
//D4100080    rc = lot_CheckConditionForOpeComp( strLot_CheckConditionForOpeComp_out, strObjCommonIn, strStartCassette );
//D4100080    if ( rc != RC_OK )
//D4100080    {
//D4100080        PPT_METHODTRACE_V1("", "lot_CheckConditionForOpeComp() != RC_OK") ;
//D4100080        strForceOpeCompForInternalBufferReqResult.strResult = strLot_CheckConditionForOpeComp_out.strResult ;
//D4100080        return( rc );
//D4100080    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Equipment                                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - All lof lot, which is contained in controlJob, must be existing   */
    /*     in the equipment's processing information.                        */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objEquipment_CheckConditionForOpeComp_out   strEquipment_CheckConditionForOpeComp_out;
    rc = equipment_CheckConditionForOpeComp( strEquipment_CheckConditionForOpeComp_out,
                                             strObjCommonIn,
                                             equipmentID,
                                             strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_CheckConditionForOpeComp() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_CheckConditionForOpeComp_out.strResult ;
        return( rc );
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process (Reverse Order of OpeStart Procedure)                  */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//DSIV00000201    /*----------------------------------------------*/
//DSIV00000201    /*                                              */
//DSIV00000201    /*   Data Collection Procedure                  */
//DSIV00000201    /*                                              */
//DSIV00000201    /*----------------------------------------------*/
//DSIV00000201    CORBA::Boolean spcCheckRequiredFlag = FALSE ;  //P3000241
//DSIV00000201
//DSIV00000201    pptSpcCheckReqResult strSpcCheckReqResult;
//DSIV00000201    objSPCMgr_SendSPCCheckReq_out strSPCMgr_SendSPCCheckReq_out;    //P7000126

//D4100080    /*----------------------------------------------*/
//D4100080    /*   If Eqp's CompetionMode is Auto Mode        */
//D4100080    /*   Call txSpecCheckDataReq                    */
//D4100080    /*----------------------------------------------*/
//D4100080    if (CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode ,
//D4100080                    SP_Eqp_CompMode_Auto ) == 0)
//D4100080    {
//D4100080        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode, SP_Eqp_CompMode_Auto ) == 0") ;
//D4100080
//D4100080        /*-------------------------------------------------------------------------------------------*/
//D4100080        /*   Do Spec Check                                                                           */
//D4100080        /*      - Calculate the derived value and Set them to PO if calculationRequiredFlag is TRUE  */
//D4100080        /*      - Set speck check result to PO if speckCheckRequiredFlag is TRUE.                    */
//D4100080        /*-------------------------------------------------------------------------------------------*/
//D4100080        pptDataSpecCheckReqResult strDataSpecCheckReqResult;
//D4100080        rc = txDataSpecCheckReq( strDataSpecCheckReqResult,
//D4100080                                 strObjCommonIn,
//D4100080                                 equipmentID,
//D4100080                                 controlJobID,
//D4100080                                 strStartCassette);
//D4100080
//D4100080
//D4100080        if ( rc == RC_OK )
//D4100080        {
//D4100080            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() == RC_OK") ;
//D4100080
//D4100080            /*-------------------------------------------------------------------------------*/
//D4100080            /*   Get Started Lot information in order to get the derived / delta datavalues  */
//D4100080            /*   and also specCheckResult in case that CompletionMode is Auto.               */
//D4100080            /*-------------------------------------------------------------------------------*/
//D4100080            objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
//D4100080            rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
//D4100080                                                         strObjCommonIn,
//D4100080                                                         controlJobID);
//D4100080            if ( rc != RC_OK )
//D4100080            {
//D4100080                PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK") ;
//D4100080                strForceOpeCompForInternalBufferReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult ;
//D4100080                return( rc );
//D4100080            }
//D4100080
//D4100080            strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;  //P3000241
//D4100080            spcCheckRequiredFlag = TRUE;                                                        //P3000241

//D4100080//P3000241  /*-----------------------*/
//D4100080//P3000241  /*   SPC Check Request   */
//D4100080//P3000241  /*-----------------------*/
//D4100080//P3000241  rc = txSpcCheckReq(strSpcCheckReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette);
//D4100080//P3000241  switch ( rc )
//D4100080//P3000241  {
//D4100080//P3000241     case RC_OK:
//D4100080//P3000241     case RC_NO_NEED_TO_SPCCHECK:
//D4100080//P3000241         PPT_METHODTRACE_V1("", "txSpcCheckReq() == RC_OK || RC_NO_NEED_TO_SPCCHECK") ;
//D4100080//P3000241         break;
//D4100080//P3000241     default:
//D4100080//P3000241         PPT_METHODTRACE_V1("", "txSpcCheckReq() != RC_OK") ;
//D4100080//P3000241         strForceOpeCompForInternalBufferReqResult.strResult = strSpcCheckReqResult.strResult ;
//D4100080//P3000241         return( rc );
//D4100080//P3000241         break;
//D4100080//P3000241  }
//D4100080        }
//D4100080        else if ( rc == RC_NO_NEED_SPEC_CHECK )
//D4100080        {
//D4100080            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() == RC_NO_NEED_TO_SPECCHECK") ;
//D4100080            rc = RC_OK;
//D4100080        }
//D4100080        else
//D4100080        {
//D4100080            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() != RC_OK") ;
//D4100080            strForceOpeCompForInternalBufferReqResult.strResult = strDataSpecCheckReqResult.strResult ;
//D4100080            return( rc );
//D4100080        }
//D4100080    }
//D4100080    //P3000241 add start
//D4100080    else
//D4100080    {
//D4100080        /*----------------------------------------*/
//D4100080        /*   Judge SPC-Check is Required or Not   */
//D4100080        /*----------------------------------------*/
//D4100080        CORBA::Long nILen = strStartCassette.length();
//D4100080        for (CORBA::Long i=0 ; i<nILen; i++ )
//D4100080        {
//D4100080            CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
//D4100080            for (CORBA::Long j=0 ; j<nJLen; j++ )
//D4100080            {
//D4100080                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
//D4100080                {
//D4100080                    continue;
//D4100080                }
//D4100080
//D4100080                CORBA::Long nKLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
//D4100080                for (CORBA::Long k=0 ; k<nKLen ; k++ )
//D4100080                {
//D4100080                    if ( strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].specCheckRequiredFlag == TRUE )
//D4100080                    {
//D4100080                        spcCheckRequiredFlag = TRUE;
//D4100080                        break;
//D4100080                    }
//D4100080                }
//D4100080
//D4100080                /*===== quit [j] Loop =====*/
//D4100080                if ( spcCheckRequiredFlag == TRUE )
//D4100080                {
//D4100080                    break;
//D4100080                }
//D4100080            }
//D4100080
//D4100080            /*===== quit [i] Loop =====*/
//D4100080            if ( spcCheckRequiredFlag == TRUE )
//D4100080            {
//D4100080                break;
//D4100080            }
//D4100080        }
//D4100080
//D4100080    }
//D4100080    //P3000241 add end

//D4100080    //P3000241 add start for SPC-Check
    /*-------------------------*/
    /*   SPC Check Procedure   */
    /*-------------------------*/
//D4100080    if ( spcCheckRequiredFlag == TRUE )
//D4100080    {

    /*----------------------------*/
    /*   Send SPC Check Request   */
    /*----------------------------*/
//P7000126    rc = txSpcCheckReq(strSpcCheckReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette);
//P7000126    if ( rc == RC_OK || rc == RC_NO_NEED_TO_SPCCHECK )
//P7000126    {
//P7000126        PPT_METHODTRACE_V1("", "txSpcCheckReq() == RC_OK || RC_NO_NEED_TO_SPCCHECK") ;
//P7000126        rc = RC_OK;
//P7000126    }
//P7000126    else
//P7000126    {
//P7000126        PPT_METHODTRACE_V1("", "txSpcCheckReq() != RC_OK") ;
//P7000126        strForceOpeCompForInternalBufferReqResult.strResult = strSpcCheckReqResult.strResult ;
//P7000126        return( rc );
//P7000126    }
//P7000126 add start
//DSIV00000201    rc = SPCMgr_SendSPCCheckReq( strSPCMgr_SendSPCCheckReq_out,
//DSIV00000201                                 strObjCommonIn,
//DSIV00000201                                 equipmentID,
//DSIV00000201                                 controlJobID,
//DSIV00000201                                 strStartCassette );
//DSIV00000201    if ( rc == RC_OK || rc == RC_NO_NEED_TO_SPCCHECK )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq() == RC_OK || RC_NO_NEED_TO_SPCCHECK") ;
//DSIV00000201        rc = RC_OK;
//DSIV00000201    }
//DSIV00000201    else
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V1("", "SPCMgr_SendSPCCheckReq() != RC_OK") ;
//DSIV00000201        strForceOpeCompForInternalBufferReqResult.strResult = strSPCMgr_SendSPCCheckReq_out.strResult ;
//DSIV00000201        return( rc );
//DSIV00000201    }
//DSIV00000201    strSpcCheckReqResult = strSPCMgr_SendSPCCheckReq_out.strSpcCheckReqResult;
//DSIV00000201//P7000126 add end
//DSIV00000201//D4100080  }
//DSIV00000201
//DSIV00000201    /*-----------------------------------------------------------------*/
//DSIV00000201    /*   Summary Action Items to Lot based on the Spec Check Result    */
//DSIV00000201    /*-----------------------------------------------------------------*/
//DSIV00000201    objStartLot_actionList_EffectSpecCheck_out   strStartLot_actionList_EffectSpecCheck_out;
//DSIV00000201    rc = startLot_actionList_EffectSpecCheck(strStartLot_actionList_EffectSpecCheck_out,
//DSIV00000201                                             strObjCommonIn,
//DSIV00000201                                             strStartCassette,
//DSIV00000201                                             equipmentID);
//DSIV00000201    if ( rc != RC_OK )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V1("", "startLot_actionList_EffectSpecCheck() != RC_OK") ;
//DSIV00000201        strForceOpeCompForInternalBufferReqResult.strResult = strStartLot_actionList_EffectSpecCheck_out.strResult ;
//DSIV00000201        return( rc );
//DSIV00000201    }
//DSIV00000201    /*-----------------------------------------------------------------------*/
//DSIV00000201    /*   Register Entity Inhibition as the result of SPEC Check              */
//DSIV00000201    /*-----------------------------------------------------------------------*/
//DSIV00000201    CORBA::Long nLen = strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length();
//DSIV00000201    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length()",nLen) ;
//DSIV00000201    pptEntityInhibitReqResult strEntityInhibitReqResult;
//DSIV00000201
//DSIV00000201    for(i=0; i<nLen; i++)
//DSIV00000201    {
//DSIV00000201        rc = txEntityInhibitReq(strEntityInhibitReqResult,
//DSIV00000201                                strObjCommonIn,
//DSIV00000201                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[i],
//DSIV00000201                                claimMemo);
//DSIV00000201//P5100366        if ( rc != RC_OK)
//DSIV00000201        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))    //P5100366
//DSIV00000201        {
//DSIV00000201            PPT_METHODTRACE_V1("", "txEntityInhibitReq() != RC_OK") ;
//DSIV00000201            strForceOpeCompForInternalBufferReqResult.strResult = strEntityInhibitReqResult.strResult ;
//DSIV00000201            return( rc );
//DSIV00000201        }
//DSIV00000201    }
//DSIV00000201    /*-----------------------------------------------*/
//DSIV00000201    /*   Send a message as the result of SPEC Check  */
//DSIV00000201    /*-----------------------------------------------*/
//DSIV00000201    nLen = strStartLot_actionList_EffectSpecCheck_out.strMessageList.length();
//DSIV00000201    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSpecCheck_out.strMessageList.length()",nLen) ;
//DSIV00000201    objMessageDistributionMgr_PutMessage_out   strMessageDistributionMgr_PutMessage_out;
//DSIV00000201
//DSIV00000201    for(i=0; i<nLen; i++)
//DSIV00000201    {
//DSIV00000201        rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out,
//DSIV00000201                                                strObjCommonIn,
//DSIV00000201                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].messageID,
//DSIV00000201                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].lotID,
//DSIV00000201                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].lotStatus,
//DSIV00000201                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].equipmentID,
//DSIV00000201                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].routeID,
//DSIV00000201                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].operationNumber,
//DSIV00000201                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].reasonCode,
//DSIV00000201                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].messageText);
//DSIV00000201        if ( rc != RC_OK )
//DSIV00000201        {
//DSIV00000201            PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK") ;
//DSIV00000201            strForceOpeCompForInternalBufferReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult ;
//DSIV00000201            return( rc );
//DSIV00000201        }
//DSIV00000201    }
//DSIV00000201    /*-----------------------------------------------------------------*/
//DSIV00000201    /*   Summary Action Items to Lot based on the SPC Check Result     */
//DSIV00000201    /*-----------------------------------------------------------------*/
//DSIV00000201    objStartLot_actionList_EffectSPCCheck_out   strStartLot_actionList_EffectSPCCheck_out;
//DSIV00000201    rc = startLot_actionList_EffectSPCCheck(strStartLot_actionList_EffectSPCCheck_out,
//DSIV00000201                                            strObjCommonIn,
//DSIV00000201                                            strSpcCheckReqResult.strSpcCheckLot,
//DSIV00000201                                            strSPCMgr_SendSPCCheckReq_out.strSpcIFParm,              //P7000126
//DSIV00000201                                            equipmentID);
//DSIV00000201    if ( rc != RC_OK )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V1("", "strStartLot_actionList_EffectSPCCheck_out() != RC_OK") ;
//DSIV00000201        strForceOpeCompForInternalBufferReqResult.strResult = strStartLot_actionList_EffectSPCCheck_out.strResult ;
//DSIV00000201        return( rc );
//DSIV00000201    }
//DSIV00000201
//DSIV00000201    /*-----------------------------------------------------------------------*/                                //Q3000284
//DSIV00000201    /*   Register Entity Inhibition as the result of SPC Check               */                                //Q3000284
//DSIV00000201    /*-----------------------------------------------------------------------*/                                //Q3000284
//DSIV00000201    CORBA::Long nSpcLen = strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length();             //Q3000284
//DSIV00000201    PPT_METHODTRACE_V2("",  "strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length()",nLen) ;  //Q3000284
//DSIV00000201    pptEntityInhibitReqResult strSpcEntityInhibitReqResult;                                                    //Q3000284
//DSIV00000201                                                                                                               //Q3000284
//DSIV00000201    for(i=0; i<nSpcLen; i++)                                                                                   //Q3000284
//DSIV00000201    {                                                                                                          //Q3000284
//DSIV00000201        rc = txEntityInhibitReq(strSpcEntityInhibitReqResult,                                                  //Q3000284
//DSIV00000201                                strObjCommonIn,                                                                //Q3000284
//DSIV00000201                                strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[i],             //Q3000284
//DSIV00000201                                claimMemo);                                                                    //Q3000284
//DSIV00000201//P6000018        if ( rc != RC_OK)                                                                                      //Q3000284
//DSIV00000201        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))    //P6000018
//DSIV00000201        {                                                                                                      //Q3000284
//DSIV00000201            PPT_METHODTRACE_V1("", "txEntityInhibitReq() != RC_OK") ;                                          //Q3000284
//DSIV00000201            strForceOpeCompForInternalBufferReqResult.strResult = strSpcEntityInhibitReqResult.strResult ;                   //Q3000284
//DSIV00000201            return( rc );                                                                                      //Q3000284
//DSIV00000201        }                                                                                                      //Q3000284
//DSIV00000201    }                                                                                                          //Q3000284
//DSIV00000201
//DSIV00000201    /*-----------------------------------------------*/
//DSIV00000201    /*   Send a message as the result of SPC Check   */
//DSIV00000201    /*-----------------------------------------------*/
//DSIV00000201    nLen = strStartLot_actionList_EffectSPCCheck_out.strMessageList.length();
//DSIV00000201    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSPCCheck_out.strMessageList.length()",nLen) ;
//DSIV00000201
//DSIV00000201    for(i=0; i<nLen; i++)
//DSIV00000201    {
//DSIV00000201        rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out,
//DSIV00000201                                                strObjCommonIn,
//DSIV00000201                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageID,
//DSIV00000201                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].lotID,
//DSIV00000201                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].lotStatus,
//DSIV00000201                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].equipmentID,
//DSIV00000201                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].routeID,
//DSIV00000201                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].operationNumber,
//DSIV00000201                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].reasonCode,
//DSIV00000201                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageText);
//DSIV00000201        if ( rc != RC_OK )
//DSIV00000201        {
//DSIV00000201            PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK") ;
//DSIV00000201            strForceOpeCompForInternalBufferReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult ;
//DSIV00000201            return( rc );
//DSIV00000201        }
//DSIV00000201    }
//DSN000043340 Add Start
    /*---------------------------------------------------------------------*/
    /*   In case of post process migration mode, fix PostProcForLotFlag    */
    /*---------------------------------------------------------------------*/
    if ( -1 == PostProcForLotFlag )
    {
        PPT_METHODTRACE_V1("", "Post Process Migration Mode");
        /*----------------------------------------------------------------------*/
        /*   In case of post process migration mode, check value in FSCONFIG    */
        /*----------------------------------------------------------------------*/
        objConfigurationInformation_GetDR_out strConfigurationInformation_GetDR_out;
        objConfigurationInformation_GetDR_in  strConfigurationInformation_GetDR_in;
        strConfigurationInformation_GetDR_in.objectKey = equipmentID.identifier;
        strConfigurationInformation_GetDR_in.category  = CIMFWStrDup(SP_ConfigurationCategory_EquipmentPostProcDecoupleMode);
        rc = configurationInformation_GetDR( strConfigurationInformation_GetDR_out,
                                             strObjCommonIn,
                                             strConfigurationInformation_GetDR_in );
        if( rc != RC_OK && rc != RC_NOT_FOUND_ENTRY )
        {
            PPT_METHODTRACE_V2("", "configurationInformation_GetDR() != RC_OK, RC_NOT_FOUND_ENTRY", rc);
            strForceOpeCompForInternalBufferReqResult.strResult = strConfigurationInformation_GetDR_out.strResult;
            return( rc );
        }

        if ( rc == RC_NOT_FOUND_ENTRY )
        {
            // rc == RC_NOT_FOUND_ENTRY
            PPT_METHODTRACE_V1("","Entry isn't found in FSCONFIG");
            PostProcForLotFlag = 0;
        }
        else
        {
            // rc == RC_OK
            // Check FSCONFIG.VALUE
            if ( 0 == CIMFWStrCmp(strConfigurationInformation_GetDR_out.strConfigInfo.value, "1") )
            {
                PPT_METHODTRACE_V1("","EquipmentPostProcActionDecoupleMode = 1");
                PostProcForLotFlag = 1;
            }
            else
            {
                PPT_METHODTRACE_V1("","EquipmentPostProcActionDecoupleMode != 1");
                PostProcForLotFlag = 0;
            }
        }

        // Store PostProcForLotFlag as thread specific data
        char* methodName = NULL;
        try
        {
            char strPostProcForLotFlag[4];
            memset( strPostProcForLotFlag, '\0', sizeof(strPostProcForLotFlag) );
            sprintf( strPostProcForLotFlag, "%d", PostProcForLotFlag );
            methodName = CIMFWStrDup("setThreadSpecificDataString");
            setThreadSpecificDataString (SP_ThreadSpecificData_Key_PostProcForLotFlag, strPostProcForLotFlag);
            CORBA::string_free(methodName);
            methodName = NULL;
        }
        CATCH_GLOBAL_EXCEPTIONS(strForceOpeCompForInternalBufferReqResult, txForceOpeCompForInternalBufferReq, methodName);
    }
//DSN000043340 Add End
    /*--------------------------------*/
    /*                                */
    /*   CP Test Function Procedure   */
    /*                                */
    /*--------------------------------*/
    CORBA::Long nLen = 0;   //DSIV00000201
    for ( i=0 ; i<scLen ; i++ )
    {
        nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0; j<nLen; j++)
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }
            /*-----------------------------------------*/
            /*   Check Test Type of Current Process    */
            /*-----------------------------------------*/
            objLot_testTypeID_Get_out   strLot_testTypeID_Get_out;
            rc = lot_testTypeID_Get( strLot_testTypeID_Get_out,
                                     strObjCommonIn,
                                     strStartCassette[i].strLotInCassette[j].lotID );
            if ( rc != RC_OK && rc != RC_NOT_FOUND_TESTTYPE )
            {
                PPT_METHODTRACE_V1("", "lot_testTypeID_Get() != RC_OK") ;
                strForceOpeCompForInternalBufferReqResult.strResult = strLot_testTypeID_Get_out.strResult ;
                return( rc );
            }
            if ( CIMFWStrLen(strLot_testTypeID_Get_out.testTypeID.identifier) > 0 )
            {
                /*---------------------------------------------------------------*/
                /*   Gather Bin Summary Information based on lotID & testTypeID  */
                /*---------------------------------------------------------------*/
                objBinSummary_GetByTestTypeDR_out   strBinSummary_GetByTestTypeDR_out;
                rc = binSummary_GetByTestTypeDR( strBinSummary_GetByTestTypeDR_out,
                                                 strObjCommonIn,
                                                 strStartCassette[i].strLotInCassette[j].lotID,
                                                 strLot_testTypeID_Get_out.testTypeID);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "binSummary_GetByTestTypeDR() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strBinSummary_GetByTestTypeDR_out.strResult ;
                    return( rc );
                }
                /*----------------------------------------------------------*/
                /*   Update Wafer Die quantity based on the input parameter  */
                /*-----------------------------------------------------------*/
                CORBA::Long bsLen = 0;
                bsLen = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary.length();
                PPT_METHODTRACE_V2("", "strBinSummary_GetByTestTypeDR_out.strWaferBinSummary.length()", bsLen);

                pptLotWaferAttributesSequence strLotWaferAttributes ;
                strLotWaferAttributes.length(bsLen) ;

                for(CORBA::Long k=0; k<bsLen; k++)
                {
                    if(strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].binReportCount)
                    {
                        strLotWaferAttributes[k].waferID         = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].waferID ;
                        strLotWaferAttributes[k].goodUnitCount   = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].goodUnitCount ;
                        strLotWaferAttributes[k].repairUnitCount = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].repairUnitCount ;
                        strLotWaferAttributes[k].failUnitCount   = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].failUnitCount ;
                    }
                }
                objLot_wafer_ChangeDie_out   strLot_wafer_ChangeDie_out;
                rc = lot_wafer_ChangeDie( strLot_wafer_ChangeDie_out,
                                          strObjCommonIn,
                                          strStartCassette[i].strLotInCassette[j].lotID,
                                          strLotWaferAttributes);
                if ( rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "lot_wafer_ChangeDie() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strLot_wafer_ChangeDie_out.strResult ;
                    return( rc );
                }
            }
        }
    }

    /*------------------------------------------------------*/
    /*                                                      */
    /*     FlowBatch Related Information Update Procedure   */
    /*                                                      */
    /*------------------------------------------------------*/
    /*----------------------------------------------------------*/
    /*   Update FlowBatch Information of Equipment              */
    /*----------------------------------------------------------*/
    objFlowBatch_Information_UpdateByOpeComp_out   strFlowBatch_Information_UpdateByOpeComp_out;
    rc = flowBatch_Information_UpdateByOpeComp( strFlowBatch_Information_UpdateByOpeComp_out,
                                                strObjCommonIn,
                                                equipmentID,
                                                strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "flowBatch_information_UpdateByOpeComp() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strFlowBatch_Information_UpdateByOpeComp_out.strResult ;
        return( rc );
    }
    /*----------------------------------------------*/
    /*                                              */
    /*   Process Operation Update Procedure         */
    /*                                              */
    /*----------------------------------------------*/
    /*-------------------------------------------------*/
    /*   Update Process Operation (actual comp xxxx)   */
    /*-------------------------------------------------*/
    objProcess_actualCompInformation_Set_out   strProcess_actualCompInformation_Set_out;
    rc = process_actualCompInformation_Set( strProcess_actualCompInformation_Set_out,
                                            strObjCommonIn,
                                            strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_actualCompInformation_Set() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strProcess_actualCompInformation_Set_out.strResult ;
        return( rc );
    }

//INN-R170009 add start
    CORBA::String_var APCAvailable = CIMFWStrDup(getenv(SP_APC_Available));
    if (CIMFWStrCmp(APCAvailable, SP_CheckFlag_On) == 0 )
    {
        PPT_METHODTRACE_V1("", "if (CIMFWStrCmp(APCAvailable, SP_CheckFlag_On) == 0 )");

        csObjAPCMgr_SendLithoUsedInfoReq_out  strObjAPCMgr_SendLithoUsedInfoReq_out;
        csObjAPCMgr_SendLithoUsedInfoReq_in   strObjAPCMgr_SendLithoUsedInfoReq_in;
        strObjAPCMgr_SendLithoUsedInfoReq_in.equipmentID      = equipmentID;
        strObjAPCMgr_SendLithoUsedInfoReq_in.strStartCassette = strStartCassette;
        rc = cs_APCMgr_SendLithoUsedInfoReq( strObjAPCMgr_SendLithoUsedInfoReq_out,
                                             strObjCommonIn,
                                             strObjAPCMgr_SendLithoUsedInfoReq_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_APCMgr_SendLithoUsedInfoReq() != RC_OK");
            strForceOpeCompForInternalBufferReqResult.strResult = strObjAPCMgr_SendLithoUsedInfoReq_out.strResult;
            return ( rc );
        }
    }
//INN-R170009 add end
//PSIV00000888 add start
    if( PostProcForLotFlag != 1 )
    {
//PSIV00000888 add end
        /*-------------------------------------------------*/
        /*   Make Measurement & Process Data History       */
        /*-------------------------------------------------*/
        objCollectedDataEvent_Make_out  strCollectedDataEvent_Make_out;
        rc = collectedDataEvent_Make( strCollectedDataEvent_Make_out,
                                      strObjCommonIn,
                                      "TXEWC011",
                                      strStartCassette,
                                      controlJobID,
                                      equipmentID,
                                      claimMemo);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "collectedDataEvent_Make() != RC_OK") ;
            strForceOpeCompForInternalBufferReqResult.strResult = strCollectedDataEvent_Make_out.strResult ;
             return( rc );
        }
//PSIV00000888 add start
    }
//PSIV00000888 add end

//DSIV00000201 add start
    objLot_futureHoldRequests_EffectByCondition_outSequence strLot_futureHoldRequests_EffectByCondition_outSequence;
    CORBA::Long fHCnt = 0;
    objectIdentifier releaseReasonCodeID ;
    releaseReasonCodeID.identifier = CIMFWStrDup( SP_Reason_GatePass ) ;

    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*-------------------------------------------*/
        /*   Delete Effected Future Hold Direction   */
        /*-------------------------------------------*/
//DSIV00000201        objectIdentifier releaseReasonCodeID ;
//DSIV00000201        releaseReasonCodeID.identifier = CIMFWStrDup( SP_Reason_GatePass ) ;

//DSIV00000201        CORBA::Long fHCnt = 0;  //D4100083
//DSIV00000201        objLot_futureHoldRequests_EffectByCondition_outSequence strLot_futureHoldRequests_EffectByCondition_outSequence;  //D4100083
    //D4100083 (03/07)    strLot_futureHoldRequests_EffectByCondition_outSequence.length( scLen );  //D4100083
        strLot_futureHoldRequests_EffectByCondition_outSequence.length( totalStartLotCount );  //D4100083 (03/07)

        for ( i=0 ; i<scLen ; i++ )
        {
            nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0 ; j<nLen; j++)
            {
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

    //D4100083 Add Start
                PPT_METHODTRACE_V2("", "i",i);
                PPT_METHODTRACE_V2("", "j",j);
                PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette[j].lotID",strStartCassette[i].strLotInCassette[j].lotID.identifier);

                /*-------------------------------*/
                /*   Get Effected Future Hold    */
                /*-------------------------------*/
                PPT_METHODTRACE_V1("", "Get Effected Future Hold") ;
                pptEffectCondition strEffectCondition;
                strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_POST );
                strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

                rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt],
                                                               strObjCommonIn,
                                                               strStartCassette[i].strLotInCassette[j].lotID,
                                                               strEffectCondition);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].strResult ;
                    return( rc );
                }

                fHCnt++;

                /*-------------------------------------------*/
                /*   Delete Effected Future Hold Direction   */
                /*-------------------------------------------*/
                strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_ALL );
                strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

                objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;
                rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                                       strObjCommonIn,
                                                                       strStartCassette[i].strLotInCassette[j].lotID,
                                                                       strEffectCondition );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
                    return( rc );
                }

    //D4100083 Add End
    //D4100083            /*-------------------------------------------*/
    //D4100083            /*   Delete Effected Future Hold Direction   */
    //D4100083            /*-------------------------------------------*/
    //D4100083            objLot_futureHoldRequests_DeleteEffected_out    strLot_futureHoldRequests_DeleteEffected_out;
    //D4100083
    //D4100083            rc = lot_futureHoldRequests_DeleteEffected(strLot_futureHoldRequests_DeleteEffected_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID) ;
    //D4100083            if(rc != RC_OK)
    //D4100083            {
    //D4100083                PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffected() != RC_OK") ;
    //D4100083                strForceOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_DeleteEffected_out.strResult ;
    //D4100083                return(rc);
    //D4100083            }

                // Pass hold cancel record list
                if ( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )  //D4100083
    //D4100083            if ( strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList.length() > 0 )
                {
                    pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
                    rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult,
                                                strObjCommonIn,
                                                strStartCassette[i].strLotInCassette[j].lotID,
                                                releaseReasonCodeID,
                                                SP_EntryType_Remove,
                                                strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList);  //D4100083
    //D4100083                                            strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK") ;
                        strForceOpeCompForInternalBufferReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
                        return( rc );
                    }
                }
            }
        }

        strLot_futureHoldRequests_EffectByCondition_outSequence.length( fHCnt );  //D4100083
//DSIV00000201 add start
    }
//DSIV00000201 add end

    /*------------------------------------------------------------*/
    /*                                                            */
    /*   Reticle / Fixture Related Information Update Procedure   */
    /*                                                            */
    /*------------------------------------------------------------*/

    CORBA::Long usedReticleSeqLen = 0;
    CORBA::Long usedFixtureSeqLen = 0;
    /*--------------------------------------------------------*/
    /*   Check ProcessDurable was Used for Operation or Not   */
    /*--------------------------------------------------------*/
    objEquipment_processDurableRequiredFlag_Get_out   strEquipment_processDurableRequiredFlag_Get_out;
    rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out,
                                                   strObjCommonIn,
                                                   equipmentID);
    CORBA::Long saveRC = rc;
    if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
    {
        PPT_METHODTRACE_V1("", "equipment_processDurableRequiredFlag_Get() == RC_EQP_PROCDRBL_NOT_REQD") ;
        rc = RC_OK;
    }
    else if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1("", "equipment_processDurableRequiredFlag_Get() == RC_EQP_PROCDRBL_RTCL_REQD || RC_EQP_PROCDRBL_FIXT_REQD") ;
        for ( i=0 ; i<scLen ; i++ )
        {
            nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0; j<nLen; j++)
            {
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                {

                    /*-------------------------------*/
                    /*   Get Used Reticles for Lot   */
                    /*-------------------------------*/
                    objProcess_assignedReticle_Get_out   strProcess_assignedReticle_Get_out;
                    rc = process_assignedReticle_Get( strProcess_assignedReticle_Get_out,
                                                      strObjCommonIn,
                                                      strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "process_assignedReticle_Get() != RC_OK") ;
                        strForceOpeCompForInternalBufferReqResult.strResult = strProcess_assignedReticle_Get_out.strResult ;
                        return( rc );
                    }

                    usedReticleSeqLen = strProcess_assignedReticle_Get_out.strStartReticle.length();
                    PPT_METHODTRACE_V2("", "strProcess_assignedReticle_Get_out.strStartReticle.length()",usedReticleSeqLen);

                    for (CORBA::Long k=0; k<usedReticleSeqLen; k++)
                    {
//INN-R170003 Add Start
                        //objReticle_usageLimitation_Check_out   strReticle_usageLimitation_Check_out;
                        //rc = reticle_usageLimitation_Check( strReticle_usageLimitation_Check_out,
                        //                                    strObjCommonIn,
                        //                                    strProcess_assignedReticle_Get_out.strStartReticle[k].reticleID);
                        //if ( rc != RC_OK )
                        //{
                        //    PPT_METHODTRACE_V1("", "reticle_usageLimitation_Check() != RC_OK") ;
                        //    strForceOpeCompForInternalBufferReqResult.strResult = strReticle_usageLimitation_Check_out.strResult ;
                        //    return( rc );
                        //}
                        //
                        //if ( strReticle_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
                        //{
                        //    PPT_METHODTRACE_V1("", "strReticle_usageLimitation_Check_out.usageLimitOverFlag == TRUE") ;
                        //
                        //    /*-------------------------*/
                        //    /*   Call System Message   */
                        //    /*-------------------------*/
                        //    pptSystemMsgRptResult strSystemMsgRptResult;
                        //    objectIdentifier      dummy;
                        //
                        //    rc = txSystemMsgRpt( strSystemMsgRptResult,
                        //                         strObjCommonIn,
                        //                         SP_SubSystemID_MM,
                        //                         SP_SystemMsgCode_RtclUsageLimitOver,
                        //                         strReticle_usageLimitation_Check_out.messageText,
                        //                         TRUE,
                        //                         dummy,
                        //                         "",
                        //                         dummy,
                        //                         "",
                        //                         dummy,
                        //                         "",
                        //                         dummy,
                        //                         "",
                        //                         dummy,
                        //                         dummy,
                        //                         "",
                        //                         strObjCommonIn.strTimeStamp.reportTimeStamp,
                        //                         "" );
                        //    if ( rc != RC_OK )
                        //    {
                        //        PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
                        //        strForceOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
                        //        return( rc );
                        //    }
                        //
                        //}
//INN-R170003 Add End

//D9000084 add start
                        /*---------------------------------------------*/
                        /*  Set last used time stamp for used reticle  */
                        /*---------------------------------------------*/
                        objReticle_lastUsedTime_Set_out strReticle_lastUsedTime_Set_out;
                        objReticle_lastUsedTime_Set_in  strReticle_lastUsedTime_Set_in;
                        strReticle_lastUsedTime_Set_in.reticleID = strProcess_assignedReticle_Get_out.strStartReticle[k].reticleID;
                        strReticle_lastUsedTime_Set_in.lastUsedTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
                        rc = reticle_lastUsedTime_Set( strReticle_lastUsedTime_Set_out, strObjCommonIn,
                                                       strReticle_lastUsedTime_Set_in );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "reticle_lastUsedTime_Set() != RC_OK") ;
                            strForceOpeCompForInternalBufferReqResult.strResult = strReticle_lastUsedTime_Set_out.strResult ;
                            return( rc );
                        }
//D9000084 add end
                    }

                }
                else
                {

                    /*------------------------------*/
                    /*   Get Used Fixture for Lot   */
                    /*------------------------------*/
                    objProcess_assignedFixture_Get_out   strProcess_assignedFixture_Get_out;
                    rc = process_assignedFixture_Get( strProcess_assignedFixture_Get_out,
                                                      strObjCommonIn,
                                                      strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "process_assignedFixture_Get() != RC_OK") ;
                        strForceOpeCompForInternalBufferReqResult.strResult = strProcess_assignedFixture_Get_out.strResult ;
                        return( rc );
                    }

                    usedFixtureSeqLen = strProcess_assignedFixture_Get_out.strStartFixture.length();
                    PPT_METHODTRACE_V2("", "strProcess_assignedFixture_Get_out.strStartFixture.length()",usedFixtureSeqLen);

                    /*------------------------------------*/
                    /*   Fixture Usage Limitation Check   */
                    /*------------------------------------*/
                    for (CORBA::Long k=0; k<usedFixtureSeqLen; k++)
                    {
                        objFixture_usageLimitation_Check_out   strFixture_usageLimitation_Check_out;
                        strFixture_usageLimitation_Check_out.usageLimitOverFlag = FALSE; //P3000280
                        rc = fixture_usageLimitation_Check( strFixture_usageLimitation_Check_out,
                                                            strObjCommonIn,
                                                            strProcess_assignedFixture_Get_out.strStartFixture[k].fixtureID);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "fixture_usageLimitation_Check() != RC_OK") ;
                            strForceOpeCompForInternalBufferReqResult.strResult = strFixture_usageLimitation_Check_out.strResult ;
                            return( rc );
                        }

                        if ( strFixture_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
                        {
                            PPT_METHODTRACE_V1("", "strFixture_usageLimitation_Check_out.usageLimitOverFlag == TRUE");

                            /*-------------------------*/
                            /*   Call System Message   */
                            /*-------------------------*/
                            pptSystemMsgRptResult strSystemMsgRptResult;
                            objectIdentifier      dummy;

                            rc = txSystemMsgRpt( strSystemMsgRptResult,
                                                 strObjCommonIn,
                                                 SP_SubSystemID_MM,
                                                 SP_SystemMsgCode_FixtUsageLimitOver,
                                                 strFixture_usageLimitation_Check_out.messageText,
                                                 TRUE,
                                                 dummy,
                                                 "",
                                                 dummy,
                                                 "",
                                                 dummy,
                                                 "",
                                                 dummy,
                                                 "",
                                                 dummy,
                                                 dummy,
                                                 "",
                                                 strObjCommonIn.strTimeStamp.reportTimeStamp,
                                                 "" );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
                                strForceOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
                                return( rc );
                            }

                        }

                    }

                }

            }

        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "equipment_processDurableRequiredFlag_Get() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult ;
        return( rc );
    }

    /*----------------------------------------------*/
    /*                                              */
    /*   Lot Related Information Update Procedure   */
    /*                                              */
    /*----------------------------------------------*/
//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*---------------------------------*/
        /*   Set/Clear Q-Time Management   */
        /*---------------------------------*/
        objQtime_SetClearByOpeComp_out   strQtime_SetClearByOpeComp_out;
        rc = qtime_SetClearByOpeComp( strQtime_SetClearByOpeComp_out, strObjCommonIn, strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "qtime_SetClearByOpeComp() != RC_OK") ;
            strForceOpeCompForInternalBufferReqResult.strResult = strQtime_SetClearByOpeComp_out.strResult ;
            return( rc );
        }

        //D7000354 Add Start
        //--------------------------------------------------
        // Reset Q-Time actions
        //--------------------------------------------------
        objectIdentifier  resetReasonCodeID;
        resetReasonCodeID.identifier = CIMFWStrDup( SP_Reason_QTimeClear );

        CORBA::Long  resetLen = strQtime_SetClearByOpeComp_out.strActionResetList.length();
        for( CORBA::Long  resetCnt = 0; resetCnt < resetLen; resetCnt++ )
        {
            pptQTimeActionRegistInfo  strResetAction = strQtime_SetClearByOpeComp_out.strActionResetList[resetCnt];

            //----- Lot Hold Actions -------//
            if( strResetAction.strLotHoldList.length() > 0 )
            {
                PPT_METHODTRACE_V1("", "The lot hold actions to reset was found.");

                pptHoldLotReleaseReqResult  strHoldLotReleaseReqResult;
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, strResetAction.lotID, resetReasonCodeID, strResetAction.strLotHoldList );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK");
                    strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return rc;
                }
            }

            //----- Future Hold Actions -------//
            if( strResetAction.strFutureHoldList.length() > 0 )
            {
                PPT_METHODTRACE_V1("", "The future hold actions to cancel was found.");

                pptFutureHoldCancelReqResult  strFutureHoldCancelReqResult;
                rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult, strObjCommonIn, strResetAction.lotID, resetReasonCodeID,
                                            SP_EntryType_Cancel, strResetAction.strFutureHoldList );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK");
                    strForceOpeCompForInternalBufferReqResult.strResult = strFutureHoldCancelReqResult.strResult;
                    return rc;
                }
            }

            //----- Future Rework Actions -------//
            CORBA::Long  cancelLen = strResetAction.strFutureReworkList.length();
            if( cancelLen > 0 )
            {
                PPT_METHODTRACE_V2("", "The future rework actions to cancel was found.", cancelLen);

                for( CORBA::Long  cancelCnt = 0; cancelCnt < cancelLen; cancelCnt++ )
                {
                    pptFutureReworkInfo  strFutureRework = strResetAction.strFutureReworkList[cancelCnt];

                    pptFutureReworkCancelReqResult  strFutureReworkCancelReqResult;
                    rc = txFutureReworkCancelReq( strFutureReworkCancelReqResult, strObjCommonIn, strFutureRework.lotID, strFutureRework.routeID,
                                                  strFutureRework.operationNumber, strFutureRework.strFutureReworkDetailInfoSeq, "" );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureReworkCancelReq() != RC_OK");
                        strForceOpeCompForInternalBufferReqResult.strResult = strFutureReworkCancelReqResult.strResult;
                        return rc;
                    }
                }
            }
        }
        //D7000354 Add End
//DSIV00000201 add start
    }
//DSIV00000201 add end

    /*-----------------------------------------*/
    /*   Change Lot Process State to Waiting   */
    /*-----------------------------------------*/
    objLot_processState_MakeWaiting_out   strLot_processState_MakeWaiting_out;
    rc = lot_processState_MakeWaiting( strLot_processState_MakeWaiting_out,
                                       strObjCommonIn,
                                       strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_processState_MakeWaiting() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strLot_processState_MakeWaiting_out.strResult ;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*   Procedure for PO Moving                                             */
    /*-----------------------------------------------------------------------*/
    CORBA::Long lotcount = 0;
    for ( i=0 ; i<scLen ; i++ )
    {
        nLen = strStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()",nLen) ;
        lotcount = lotcount + nLen;
    }
    PPT_METHODTRACE_V2("","lotcount",lotcount) ;
    objectIdentifierSequence autoBankInLotIDs;
    autoBankInLotIDs.length(lotcount);

//DSIV00000201 add start
    objectIdentifierSequence opeStartLotIDs;
    opeStartLotIDs.length(lotcount);
    CORBA::Long opeStartLotCount = 0;
//DSIV00000201 add end

    lotcount = 0;
    for ( i=0 ; i<scLen ; i++ )
    {
        nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0 ; j<nLen; j++ )
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

//INN-R170002 add start
            //-------------------------------------------
            // Update contamination Info for lot
            //-------------------------------------------
            csObjLot_ContaminationInfo_Set_in strLot_ContaminationInfo_Set_in;
            strLot_ContaminationInfo_Set_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;

            csObjLot_ContaminationInfo_Set_out strLot_ContaminationInfo_Set_out;
            rc = cs_lot_ContaminationInfo_Set( strLot_ContaminationInfo_Set_out,
                                               strObjCommonIn,
                                               strLot_ContaminationInfo_Set_in );
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_Set() rc != RC_OK", rc);
                strForceOpeCompForInternalBufferReqResult.strResult = strLot_ContaminationInfo_Set_out.strResult;
                return( rc );
            }
//INN-R170002 add end
//INN-R170003 Start
            //for test instead of CS_S_MAINPD_OPE_FOUP_CLEAN_FLAG with "S_MAINPD_OpeFOUPCleanFlag"
            csObjUserData_GetByLotOperation_in strUserData_GetByLotOperation_in;
            strUserData_GetByLotOperation_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;
            strUserData_GetByLotOperation_in.userDataNameSeq.length(1);
            strUserData_GetByLotOperation_in.userDataNameSeq[0] =  CIMFWStrDup("S_MAINPD_OpeFOUPCleanFlag");
            csObjUserData_GetByLotOperation_out strUserData_GetByLotOperation_out;
            PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_in.userDataNameSeq[0]", strUserData_GetByLotOperation_in.userDataNameSeq[0]);
            rc = cs_userData_GetByLotOperation(strUserData_GetByLotOperation_out, strObjCommonIn,
                strUserData_GetByLotOperation_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "cs_userData_GetByLotOperation() rc != RC_OK", rc);
                strForceOpeCompForInternalBufferReqResult.strResult = strUserData_GetByLotOperation_out.strResult;
                return(rc);
            }
            //for each UserData
            CORBA::Long userDataSeqLen = strUserData_GetByLotOperation_out.strUserDataSeq.length();
            for (CORBA::Long i1 = 0; i1 < userDataSeqLen; i1++)
            {
                //CORBA::String_var strtmp = "S_MAINPD_OpeFOUPCleanFlag";
                PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_out.strUserDataSeq[i1].name---------------- >", strUserData_GetByLotOperation_out.strUserDataSeq[i1].name);
                PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_out.strUserDataSeq[i1].value---------------- >", strUserData_GetByLotOperation_out.strUserDataSeq[i1].value);

                if(CIMFWStrCmp(strUserData_GetByLotOperation_out.strUserDataSeq[i1].name, "S_MAINPD_OpeFOUPCleanFlag") == 0 &&
                   CIMFWStrCmp(strUserData_GetByLotOperation_out.strUserDataSeq[i1].value, CS_YESNOFLAG_YES) == 0 )
                {

                    PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_out.strUserDataSeq[i1].name is CS_S_MAINPD_OPE_FOUP_CLEAN_FLAG---------------- >", i1);
                    PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_out.strUserDataSeq[i1].value is Yes---------------- >", i1);

                    objDurable_currentState_Change_out         strDurable_currentState_Change_out;
                    objDurable_currentState_Change_in           strDurable_currentState_Change_in;
                    strDurable_currentState_Change_in.durableCategory = CIMFWStrDup(SP_Durable_Category_Cassette);
                    strDurable_currentState_Change_in.durableStatus = CIMFWStrDup(CS_SP_DRBL_STATE_NOTAVAILABLE);
                    strDurable_currentState_Change_in.durableSubStatus.identifier = CIMFWStrDup(CS_FOUP_DURABLE_SUB_STATE_WAITCLEAN);
                    strDurable_currentState_Change_in.durableID = strStartCassette[i].cassetteID;
                    PPT_METHODTRACE_V2("", "cs_txForceOpeCompForInternalBufferReqOR durable_currentState_Change------------------->", i1);
                    rc = durable_currentState_Change(strDurable_currentState_Change_out, strObjCommonIn,
                        strDurable_currentState_Change_in);
                    if (rc != RC_OK)
                    {
                            PPT_METHODTRACE_V2("", "durable_currentState_Change() rc != RC_OK", rc);
                            strForceOpeCompForInternalBufferReqResult.strResult = strDurable_currentState_Change_out.strResult;
                            return(rc);
                    }
                }

            }
//INN-R170003 End

            /*-----------------------------------*/
            /*   Move Process Operation of Lot   */
            /*-----------------------------------*/
            objProcess_Move_out  strProcess_Move_out;
            strProcess_Move_out.autoBankInFlag = FALSE; //P3000280
            rc = process_Move( strProcess_Move_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID );
//D5000225 Insert Start
            if ( rc == RC_ADDTOQUEUE_FAIL )
            {
                PPT_METHODTRACE_V1("", "process_Move() == RC_ADDTOQUEUE_FAIL") ;

                objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                   strObjCommonIn,
                                                   strStartCassette[i].strLotInCassette[j].lotID ) ;

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                    strForceOpeCompForInternalBufferReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult ;
                    return (rc) ;
                }

                pptHoldLotReqResult strHoldLotReqResult ;
                pptHoldListSequence strLotHoldReqList( 1 ) ;
                strLotHoldReqList.length( 1 ) ;

                strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_AddToQueueErrHold ) ;
                strLotHoldReqList[0].holdReasonCodeID.identifier          = CIMFWStrDup( SP_Reason_AddToQueueErrHold );
                strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
                strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
                strLotHoldReqList[0].routeID                  = strLot_currentOperationInfo_Get_out.routeID ;
                strLotHoldReqList[0].operationNumber          = strLot_currentOperationInfo_Get_out.operationNumber ;
                strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "");

                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                                   strStartCassette[i].strLotInCassette[j].lotID,
                                   strLotHoldReqList );

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                    return rc ;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For AddToQueue") ;
                }
            }
            else
            {
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "process_Move() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strProcess_Move_out.strResult ;
                    return( rc );
                }
                else
                {
                    PPT_METHODTRACE_V1("", "process_Move() == RC_OK") ;
                }
            }
//D5000225 Insert End
//D5000225            if ( rc != RC_OK )
//D5000225            {
//D5000225                PPT_METHODTRACE_V1("", "process_Move() != RC_OK") ;
//D5000225                strForceOpeCompForInternalBufferReqResult.strResult = strProcess_Move_out.strResult ;
//D5000225                return( rc );
//D5000225            }

            // save the returned lotID as objectIdentifier type for last txBankInReq() if autoBankInFlag is TRUE;
            if ( strProcess_Move_out.autoBankInFlag == TRUE )
            {
                autoBankInLotIDs[lotcount] = strStartCassette[i].strLotInCassette[j].lotID;
                lotcount++;
            }
//DSIV00000201 add start
            // set operation start lot
            opeStartLotIDs[opeStartLotCount] = strStartCassette[i].strLotInCassette[j].lotID;
            opeStartLotCount++;
//DSIV00000201 add end
#if 1
            //--------------------------------------------------------------------------------------------------
            // UpDate RequiredCassetteCategory
            //--------------------------------------------------------------------------------------------------
            objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
            rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                                     strObjCommonIn,
                                                                     strStartCassette[i].strLotInCassette[j].lotID );

            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
                strForceOpeCompForInternalBufferReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
                return rc;
            }
#endif

//INN-R170002 Add Start
            csObjLot_ContaminationInfo_CheckForMove_in    strLot_ContaminationInfo_CheckForMove_in;
            strLot_ContaminationInfo_CheckForMove_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;
            strLot_ContaminationInfo_CheckForMove_in.carrierID = strStartCassette[i].cassetteID;
            csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
            rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                        strObjCommonIn,
                                                        strLot_ContaminationInfo_CheckForMove_in );
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
                strForceOpeCompForInternalBufferReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
                return rc;
            }

            if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
            {
                pptHoldLotReqResult strHoldLotReqResult;
                pptHoldListSequence strLotHoldReqList( 1 );
                strLotHoldReqList.length( 1 );

                strLotHoldReqList[0].holdType = CIMFWStrDup(SP_HoldType_LotHold);
                strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup(CS_SP_Reason_ContaminationMismatchHold);
                strLotHoldReqList[0].holdUserID = strObjCommonIn.strUser.userID;
                strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup(SP_ResponsibleOperation_Current);
                strLotHoldReqList[0].claimMemo = claimMemo;

                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                                             strStartCassette[i].strLotInCassette[j].lotID,
                                             strLotHoldReqList);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                    return rc ;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
                }
            }
//INN-R170002 Add End
        }
    }
    autoBankInLotIDs.length(lotcount);
    opeStartLotIDs.length(opeStartLotCount);    //DSIV00000201

//PSIV00003068 add start
    /*---------------------------------------------------------------*/
    /*   Auto Hold after force complete                              */
    /*---------------------------------------------------------------*/
    for ( i=0 ; i<scLen ; i++ )
    {
        CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0; j<nLen; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            pptLotHoldListInqResult strLotHoldListInqResult;
            rc = txLotHoldListInq( strLotHoldListInqResult,
                                   strObjCommonIn,
                                   strStartCassette[i].strLotInCassette[j].lotID ) ;
            if( rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "txLotHoldListInq() != RC_OK") ;
                strForceOpeCompForInternalBufferReqResult.strResult = strLotHoldListInqResult.strResult ;
                return (rc) ;
            }

            PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette[j].lotID =",strStartCassette[i].strLotInCassette[j].lotID.identifier);

            CORBA::Long oLen = strLotHoldListInqResult.strLotHoldListAttributes.length();
            for (CORBA::Long k=0; k<oLen; k++ )
            {
                PPT_METHODTRACE_V2("", "k =",k);

                if (CIMFWStrCmp(strLotHoldListInqResult.strLotHoldListAttributes[k].reasonCodeID.identifier, SP_Reason_RunningHold ) == 0)
                {

                    PPT_METHODTRACE_V1("", "Find Running Hold Record!!") ;
                    pptHoldListSequence strLotHoldReleaseReqList;
                    strLotHoldReleaseReqList.length(1);

                    strLotHoldReleaseReqList[0].holdType                 = strLotHoldListInqResult.strLotHoldListAttributes[k].holdType;
                    strLotHoldReleaseReqList[0].holdReasonCodeID         = strLotHoldListInqResult.strLotHoldListAttributes[k].reasonCodeID;
                    strLotHoldReleaseReqList[0].holdUserID               = strLotHoldListInqResult.strLotHoldListAttributes[k].userID;
                    strLotHoldReleaseReqList[0].responsibleOperationMark = strLotHoldListInqResult.strLotHoldListAttributes[k].responsibleOperationMark;
                    strLotHoldReleaseReqList[0].routeID                  = strLotHoldListInqResult.strLotHoldListAttributes[k].responsibleRouteID;
                    strLotHoldReleaseReqList[0].operationNumber          = strLotHoldListInqResult.strLotHoldListAttributes[k].responsibleOperationNumber;
                    strLotHoldReleaseReqList[0].relatedLotID             = strLotHoldListInqResult.strLotHoldListAttributes[k].relatedLotID;
                    strLotHoldReleaseReqList[0].claimMemo                = CIMFWStrDup("");

                    objectIdentifier aReasonCodeID ;
                    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_RunningHoldRelease ) ;

                    pptHoldLotReleaseReqResult strHoldLotReleaseReqResult;
                    rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult,
                                              strObjCommonIn,
                                              strStartCassette[i].strLotInCassette[j].lotID,
                                              aReasonCodeID,
                                              strLotHoldReleaseReqList ) ;
                    if( rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK") ;
                        strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReleaseReqResult.strResult ;
                        return (rc) ;
                    }
                    break;

                }

            }

            /*-------------------------*/
            /*   Execute Lot Hold      */
            /*-------------------------*/
            objectIdentifier dummyRoute;
            objectIdentifier dummyLot;
            objectIdentifier reasonCodeID;
            reasonCodeID.identifier = CIMFWStrDup( SP_Reason_ForceCompHold );

            pptHoldListSequence  strHoldListSeq;
            strHoldListSeq.length(1);

            strHoldListSeq[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold );
            strHoldListSeq[0].holdReasonCodeID         = reasonCodeID;
            strHoldListSeq[0].holdUserID               = strObjCommonIn.strUser.userID;
            strHoldListSeq[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Previous );
            strHoldListSeq[0].routeID                  = dummyRoute;
            strHoldListSeq[0].operationNumber          = CIMFWStrDup("");
            strHoldListSeq[0].relatedLotID             = dummyLot;
            strHoldListSeq[0].claimMemo                = CIMFWStrDup("SYSAUTO:Force Compelete System Hold");

            pptHoldLotReqResult strHoldLotReqResult;
            rc = txHoldLotReq( strHoldLotReqResult,
                               strObjCommonIn,
                               strStartCassette[i].strLotInCassette[j].lotID,
                               strHoldListSeq );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txForceOpeCompForInternalBufferReq", "txHoldLotReq() != RC_OK") ;
                strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                return(rc);
            }
        }
    }
//PSIV00003068 add end

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
//D4100083 Add Start
        /*----------------------------------------------------------------------------*/
        /*   Lot FutureHold Post By Previous Operation Effect after Operation Move    */
        /*----------------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Lot FutureHold Post By Previous Operation Effect after Operation Move  ") ;

        CORBA::Long fhLen = strLot_futureHoldRequests_EffectByCondition_outSequence.length();

        for ( fHCnt = 0 ; fHCnt < fhLen ; fHCnt++ )
        {
            PPT_METHODTRACE_V2("", "fHCnt",fHCnt);

            if (strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].strLotHoldReqList.length() > 0)
            {

                PPT_METHODTRACE_V1("", "strLotHoldReqList.length() > 0") ;

                /*-----------------------------------------------------*/
                /*   Convert OpeNo, RouteID from previous to current   */
                /*-----------------------------------------------------*/
                PPT_METHODTRACE_V1("", "Convert OpeNo from previous to current") ;

                objLot_futureHold_EffectedProcessConversion_out strLot_futureHold_EffectedProcessConversion_out;
                rc = lot_futureHold_EffectedProcessConversion( strLot_futureHold_EffectedProcessConversion_out,
                                                               strObjCommonIn,
                                                               strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].lotID,
                                                               strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].strLotHoldReqList );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHold_EffectedProcessConversion() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strLot_futureHold_EffectedProcessConversion_out.strResult ;
                    return( rc );
                }

                pptHoldLotReqResult strHoldLotReqResult ;

                rc = txHoldLotReq( strHoldLotReqResult,
                                   strObjCommonIn ,
                                   strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].lotID ,
                                   strLot_futureHold_EffectedProcessConversion_out.strLotHoldReqList ) ;

                if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                    return( rc );
                }

            }
        }

    //D4100083 Add End
//DSIV00000201 add start
    }
//DSIV00000201 add end

    //---------------------------------------------------------------------------
    //   Execute Lot Hold Action based on SpecCheck and also SPC Check result.
    //
    //---------------------------------------------------------------------------

//DSIV00000201    /*-------------------------------------*/
//DSIV00000201    /*   Effect The Result of SPEC Check   */
//DSIV00000201    /*-------------------------------------*/
//DSIV00000201    objLot_holdRecord_EffectSpecCheckResult_out   strLot_holdRecord_EffectSpecCheckResult_out;
//DSIV00000201
//DSIV00000201    rc = lot_holdRecord_EffectSpecCheckResult( strLot_holdRecord_EffectSpecCheckResult_out, strObjCommonIn, strStartCassette );
//DSIV00000201    if ( rc != RC_OK )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSpecCheckResult() != RC_OK" );
//DSIV00000201        strForceOpeCompForInternalBufferReqResult.strResult = strLot_holdRecord_EffectSpecCheckResult_out.strResult;
//DSIV00000201        return( rc );
//DSIV00000201    }
//DSIV00000201
//DSIV00000201    CORBA::Long nSpecLotHoldEffectListLen = 0;
//DSIV00000201    nSpecLotHoldEffectListLen = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length();
//DSIV00000201    if ( nSpecLotHoldEffectListLen  > 0 )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length()", nSpecLotHoldEffectListLen) ;
//DSIV00000201
//DSIV00000201        pptHoldLotReqResult strHoldLotReqResult ;
//DSIV00000201
//DSIV00000201        pptHoldListSequence strLotHoldReqList;
//DSIV00000201        strLotHoldReqList.length( 1 ) ;
//DSIV00000201
//DSIV00000201        for( i = 0 ; i< nSpecLotHoldEffectListLen ; i++ )
//DSIV00000201        {
//DSIV00000201            strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].holdType ;
//DSIV00000201            strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].reasonCodeID ;
//DSIV00000201            strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].userID ;
//DSIV00000201            strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].responsibleOperationMark ;
//DSIV00000201            strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].routeID ;
//DSIV00000201            strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].operationNumber ;
//DSIV00000201            strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].relatedLotID ;
//DSIV00000201            strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].claimMemo ;
//DSIV00000201
//DSIV00000201            rc = txHoldLotReq( strHoldLotReqResult,
//DSIV00000201                               strObjCommonIn ,
//DSIV00000201                               strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].lotID ,
//DSIV00000201                               strLotHoldReqList ) ;
//DSIV00000201
//DSIV00000201            if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )     //Q3000159
//DSIV00000201            {
//DSIV00000201                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
//DSIV00000201                strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
//DSIV00000201                return( rc );
//DSIV00000201            }
//DSIV00000201        }
//DSIV00000201    }
//DSIV00000201
//DSIV00000201    CORBA::Long nSpecFutureHoldEffectLen = 0;
//DSIV00000201    nSpecFutureHoldEffectLen = strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length() ;
//DSIV00000201    if ( nSpecFutureHoldEffectLen  > 0 )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length()", nSpecFutureHoldEffectLen) ;
//DSIV00000201
//DSIV00000201//D4100083        pptFutureHoldReqResult strFutureHoldReqResult ;
//DSIV00000201        for( i=0 ; i<nSpecFutureHoldEffectLen; i++ )
//DSIV00000201        {
//DSIV00000201//D4100083 Add Start
//DSIV00000201            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
//DSIV00000201            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
//DSIV00000201                                          strObjCommonIn ,
//DSIV00000201                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].holdType ,
//DSIV00000201                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].lotID,
//DSIV00000201                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].routeID,
//DSIV00000201                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].operationNumber,
//DSIV00000201                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
//DSIV00000201                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
//DSIV00000201                                          TRUE,
//DSIV00000201                                          TRUE,
//DSIV00000201                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].claimMemo ) ;
//DSIV00000201            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY)
//DSIV00000201            {
//DSIV00000201                PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY") ;
//DSIV00000201                strForceOpeCompForInternalBufferReqResult.strResult = strEnhancedFutureHoldReqResult.strResult ;
//DSIV00000201                return( rc );
//DSIV00000201            }
//DSIV00000201//D4100083 Add End
//DSIV00000201//D4100083            rc = txFutureHoldReq( strFutureHoldReqResult,
//DSIV00000201//D4100083                                  strObjCommonIn ,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].holdType ,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].lotID,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].routeID,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].operationNumber,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].claimMemo ) ;
//DSIV00000201//D4100083            if ( rc != RC_OK)
//DSIV00000201//D4100083            {
//DSIV00000201//D4100083                PPT_METHODTRACE_V1("", "txFutureHoldReq() != RC_OK") ;
//DSIV00000201//D4100083                strForceOpeCompForInternalBufferReqResult.strResult = strFutureHoldReqResult.strResult ;
//DSIV00000201//D4100083                return( rc );
//DSIV00000201//D4100083            }
//DSIV00000201        }
//DSIV00000201    }
//DSIV00000201
//DSIV00000201    /*------------------------------------*/
//DSIV00000201    /*   Effect The Result of SPC Check   */
//DSIV00000201    /*------------------------------------*/
//DSIV00000201    objLot_holdRecord_EffectSPCCheckResult_out   strLot_holdRecord_EffectSPCCheckResult_out;
//DSIV00000201//D4100069    PPT_METHODTRACE_V1("", "theSP_LCFR_Use_Flag is not env");  //D4000011
//DSIV00000201    rc = lot_holdRecord_EffectSPCCheckResult( strLot_holdRecord_EffectSPCCheckResult_out,
//DSIV00000201                                              strObjCommonIn,
//DSIV00000201                                              strSpcCheckReqResult.strSpcCheckLot );
//DSIV00000201    if ( rc != RC_OK )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSPCCheckResult() != RC_OK");
//DSIV00000201        strForceOpeCompForInternalBufferReqResult.strResult = strLot_holdRecord_EffectSPCCheckResult_out.strResult ;
//DSIV00000201        return( rc );
//DSIV00000201    }
//DSIV00000201
//DSIV00000201    CORBA::Long nSPCLotHoldEffectListLen = 0;
//DSIV00000201    nSPCLotHoldEffectListLen = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList.length();
//DSIV00000201    if ( nSPCLotHoldEffectListLen  > 0 )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList.length()", nSPCLotHoldEffectListLen) ;
//DSIV00000201
//DSIV00000201        pptHoldLotReqResult strHoldLotReqResult ;
//DSIV00000201
//DSIV00000201        pptHoldListSequence strLotHoldReqList;
//DSIV00000201        strLotHoldReqList.length( 1 ) ;
//DSIV00000201
//DSIV00000201        for( i = 0 ; i< nSPCLotHoldEffectListLen ; i++ )
//DSIV00000201        {
//DSIV00000201            strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].holdType ;
//DSIV00000201            strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].reasonCodeID ;
//DSIV00000201            strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].userID ;
//DSIV00000201            strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].responsibleOperationMark ;
//DSIV00000201            strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].routeID ;
//DSIV00000201            strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].operationNumber ;
//DSIV00000201            strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].relatedLotID ;
//DSIV00000201            strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].claimMemo ;
//DSIV00000201
//DSIV00000201            rc = txHoldLotReq( strHoldLotReqResult,
//DSIV00000201                               strObjCommonIn ,
//DSIV00000201//P3000246                     strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].lotID ,
//DSIV00000201                               strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].lotID ,            //P3000246
//DSIV00000201                               strLotHoldReqList ) ;
//DSIV00000201
//DSIV00000201//Q3000159  if ( rc != RC_OK )
//DSIV00000201            if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )     //Q3000159
//DSIV00000201            {
//DSIV00000201                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
//DSIV00000201                strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
//DSIV00000201                return( rc );
//DSIV00000201            }
//DSIV00000201        }
//DSIV00000201    }
//DSIV00000201
//DSIV00000201    CORBA::Long nSPCFutureHoldEffectLen = 0;
//DSIV00000201    nSPCFutureHoldEffectLen = strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList.length() ;
//DSIV00000201    if ( nSPCFutureHoldEffectLen  > 0 )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList.length()", nSPCFutureHoldEffectLen) ;
//DSIV00000201
//DSIV00000201//D4100083        pptFutureHoldReqResult strFutureHoldReqResult ;
//DSIV00000201        for( i=0 ; i<nSPCFutureHoldEffectLen; i++ )
//DSIV00000201        {
//DSIV00000201//D4100083 Add Start
//DSIV00000201            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
//DSIV00000201            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
//DSIV00000201                                          strObjCommonIn ,
//DSIV00000201                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].holdType ,
//DSIV00000201                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].lotID,
//DSIV00000201                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].routeID,
//DSIV00000201                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].operationNumber,
//DSIV00000201                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
//DSIV00000201                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
//DSIV00000201                                          TRUE,
//DSIV00000201                                          TRUE,
//DSIV00000201                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].claimMemo ) ;
//DSIV00000201            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY)
//DSIV00000201            {
//DSIV00000201                PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY") ;
//DSIV00000201                strForceOpeCompForInternalBufferReqResult.strResult = strEnhancedFutureHoldReqResult.strResult ;
//DSIV00000201                return( rc );
//DSIV00000201            }
//DSIV00000201//D4100083 Add End
//DSIV00000201//D4100083            rc = txFutureHoldReq( strFutureHoldReqResult,
//DSIV00000201//D4100083                                  strObjCommonIn ,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].holdType ,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].lotID,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].routeID,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].operationNumber,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
//DSIV00000201//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].claimMemo ) ;
//DSIV00000201//D4100083            if ( rc != RC_OK )
//DSIV00000201//D4100083            {
//DSIV00000201//D4100083                PPT_METHODTRACE_V1("", "txFutureHoldReq() != RC_OK") ;
//DSIV00000201//D4100083                strForceOpeCompForInternalBufferReqResult.strResult = strFutureHoldReqResult.strResult ;
//DSIV00000201//D4100083                return( rc );
//DSIV00000201//D4100083            }
//DSIV00000201        }
//DSIV00000201    }
//DSIV00000201
//DSIV00000201    /*---------------------------------------------------------------*/
//DSIV00000201    /*   Cut Monitor Relation for ProcessMonitorLot and ProcessLot   */
//DSIV00000201    /*---------------------------------------------------------------*/
//DSIV00000201    CORBA::Long holdReleasedLotCount = 0;                        //P4200204
//DSIV00000201
//DSIV00000201    objectIdentifier monitorLotID;
//DSIV00000201    for ( i=0 ; i<scLen ; i++ )
//DSIV00000201    {
//DSIV00000201        nLen = strStartCassette[i].strLotInCassette.length();
//DSIV00000201        for (CORBA::Long j=0 ; j<nLen ; j++ )
//DSIV00000201        {
//DSIV00000201            /*---------------------------*/
//DSIV00000201            /*   Omit Not-OpeStart Lot   */
//DSIV00000201            /*---------------------------*/
//DSIV00000201            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
//DSIV00000201            {
//DSIV00000201                continue;
//DSIV00000201            }
//DSIV00000201
//DSIV00000201            /*-----------------------------*/
//DSIV00000201            /*   Delete Monitor Grouping   */
//DSIV00000201            /*-----------------------------*/
//DSIV00000201            objMonitorGroup_DeleteComp_out  strMonitorGroup_DeleteComp_out;
//DSIV00000201            rc = monitorGroup_DeleteComp( strMonitorGroup_DeleteComp_out,
//DSIV00000201                                          strObjCommonIn,
//DSIV00000201                                          strStartCassette[i].strLotInCassette[j].lotID);
//DSIV00000201            if ( rc != RC_OK )
//DSIV00000201            {
//DSIV00000201                PPT_METHODTRACE_V1("", "monitorGroup_DeleteComp() != RC_OK") ;
//DSIV00000201                strForceOpeCompForInternalBufferReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult ;
//DSIV00000201                return( rc );
//DSIV00000201            }
//DSIV00000201
//DSIV00000201            CORBA::Long nMonitorCompLotsLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length() ;
//DSIV00000201
//DSIV00000201            if( nMonitorCompLotsLen != 0 )
//DSIV00000201            {
//DSIV00000201                pptHoldLotReleaseReqResult strHoldLotReleaseReqResult ;
//DSIV00000201                objectIdentifier aReasonCodeID ;
//DSIV00000201                aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_WaitingMonitorHoldRelease ) ;
//DSIV00000201
//DSIV00000201                holdReleasedLotIDs.length(holdReleasedLotCount + nMonitorCompLotsLen);              //P4200204
//DSIV00000201
//DSIV00000201//D5100184                for(CORBA::Long j=0; j<nMonitorCompLotsLen; j++ )
//DSIV00000201                for( CORBA::Long k = 0; k < nMonitorCompLotsLen; k++ )    //D5100184
//DSIV00000201                {
//DSIV00000201                    CORBA::Long nLotHoldLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].strLotHoldReleaseReqList.length();    //D5100184
//DSIV00000201//D5100184                    CORBA::Long nLotHoldLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[j].strLotHoldReleaseReqList.length() ;
//DSIV00000201                    if ( nLotHoldLen > 0 )
//DSIV00000201                    {
//DSIV00000201                        rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult,
//DSIV00000201                                                  strObjCommonIn,
//DSIV00000201                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID,                     //D5100184
//DSIV00000201//D5100184                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[j].productLotID,
//DSIV00000201                                                  aReasonCodeID,
//DSIV00000201                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].strLotHoldReleaseReqList );       //D5100184
//DSIV00000201//D5100184                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[j].strLotHoldReleaseReqList ) ;
//DSIV00000201                        if( rc != RC_OK)
//DSIV00000201                        {
//DSIV00000201                            PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK") ;
//DSIV00000201                            strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReleaseReqResult.strResult ;
//DSIV00000201                            return (rc) ;
//DSIV00000201                        }
//DSIV00000201
//DSIV00000201                        //P4200204 Add Start
//DSIV00000201                        //-------------------------------------
//DSIV00000201                        //Return Hold Released LotID for Caller
//DSIV00000201                        //-------------------------------------
//DSIV00000201                        holdReleasedLotIDs[holdReleasedLotCount] = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID;    //D5100184
//DSIV00000201//D5100184                        holdReleasedLotIDs[holdReleasedLotCount] = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[j].productLotID;
//DSIV00000201
//DSIV00000201                        PPT_METHODTRACE_V3("","Hold Released LotID",holdReleasedLotCount,  holdReleasedLotIDs[holdReleasedLotCount].identifier );
//DSIV00000201                        holdReleasedLotCount++;
//DSIV00000201                        //P4200204 Add End
//DSIV00000201
//DSIV00000201                        //D5100184 Add Start
//DSIV00000201                        //------------------------------------------
//DSIV00000201                        //  Check Lot Type of Monitoring Lot
//DSIV00000201                        //------------------------------------------
//DSIV00000201                        if( CIMFWStrCmp( SP_Lot_Type_ProductionLot, strStartCassette[i].strLotInCassette[j].lotType ) == 0 )
//DSIV00000201                        {
//DSIV00000201                            while( 1 )
//DSIV00000201                            {
//DSIV00000201                                //------------------------------------------
//DSIV00000201                                //  Check whether GatePass is required
//DSIV00000201                                //------------------------------------------
//DSIV00000201                                PPT_METHODTRACE_V2("", "===== repeatGatePass_CheckCondition() ========",
//DSIV00000201                                                       strStartCassette[i].strLotInCassette[j].lotID.identifier);
//DSIV00000201
//DSIV00000201                                objRepeatGatePass_CheckCondition_out  strRepeatGatePass_CheckCondition_out;
//DSIV00000201                                strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag = TRUE;
//DSIV00000201                                rc = repeatGatePass_CheckCondition( strRepeatGatePass_CheckCondition_out,
//DSIV00000201                                                                    strObjCommonIn,
//DSIV00000201                                                                    strStartCassette[i].strLotInCassette[j].lotID,
//DSIV00000201                                                                    strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID );
//DSIV00000201                                if( rc != RC_OK )
//DSIV00000201                                {
//DSIV00000201                                    PPT_METHODTRACE_V2("", "repeatGatePass_CheckCondition() != RC_OK", rc);
//DSIV00000201                                    strForceOpeCompForInternalBufferReqResult.strResult = strRepeatGatePass_CheckCondition_out.strResult;
//DSIV00000201                                    return( rc );
//DSIV00000201                                }
//DSIV00000201                                if( strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag == FALSE )
//DSIV00000201                                {
//DSIV00000201                                    PPT_METHODTRACE_V1("", "gatePassRequiredFlag == FALSE");
//DSIV00000201                                    break;
//DSIV00000201                                }
//DSIV00000201
//DSIV00000201                                //--------------------------------
//DSIV00000201                                //  Get Monitored Lot's Info
//DSIV00000201                                //--------------------------------
//DSIV00000201                                objLot_currentOperationInfo_Get_out  strLot_currentOperationInfo_Get_out;
//DSIV00000201                                rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
//DSIV00000201                                                                   strObjCommonIn,
//DSIV00000201                                                                   strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID );
//DSIV00000201                                if( rc != RC_OK )
//DSIV00000201                                {
//DSIV00000201                                    PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK", rc);
//DSIV00000201                                    strForceOpeCompForInternalBufferReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
//DSIV00000201                                    return( rc );
//DSIV00000201                                }
//DSIV00000201
//DSIV00000201                                //------------------------------------------
//DSIV00000201                                //  Call txGatePassReq()
//DSIV00000201                                //------------------------------------------
//DSIV00000201                                pptGatePassReqResult        strGatePassReqResult;
//DSIV00000201                                CORBA::Long                 seqIndex = 0;
//DSIV00000201                                pptGatePassLotInfoSequence  strGatePassLotInfo;
//DSIV00000201                                objectIdentifierSequence    dummyLotIDs;            //for Return, but it's dummy.
//DSIV00000201
//DSIV00000201                                strGatePassReqResult.strGatePassLotsResult.length( 1 );
//DSIV00000201                                strGatePassLotInfo.length( 1 );
//DSIV00000201                                strGatePassLotInfo[0].lotID =
//DSIV00000201                                                      strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID;
//DSIV00000201                                strGatePassLotInfo[0].currentRouteID =
//DSIV00000201                                                      strLot_currentOperationInfo_Get_out.routeID;
//DSIV00000201                                strGatePassLotInfo[0].currentOperationNumber =
//DSIV00000201                                                      CIMFWStrDup( strLot_currentOperationInfo_Get_out.operationNumber );
//DSIV00000201
//DSIV00000201                                rc = txGatePassReq( strGatePassReqResult,
//DSIV00000201                                                    strObjCommonIn,
//DSIV00000201                                                    seqIndex,
//DSIV00000201                                                    strGatePassLotInfo,
//DSIV00000201                                                    claimMemo,
//DSIV00000201                                                    dummyLotIDs );
//DSIV00000201                                if( rc != RC_OK )
//DSIV00000201                                {
//DSIV00000201                                    PPT_METHODTRACE_V2("", "txGatePassReq() != RC_OK", rc);
//DSIV00000201                                    strForceOpeCompForInternalBufferReqResult.strResult = strGatePassReqResult.strResult;
//DSIV00000201                                    return( rc );
//DSIV00000201                                }
//DSIV00000201                            }
//DSIV00000201                        }
//DSIV00000201                        else
//DSIV00000201                        {
//DSIV00000201                            continue;
//DSIV00000201                        }
//DSIV00000201                        //D5100184 Add End
//DSIV00000201                    }
//DSIV00000201                }
//DSIV00000201            }
//DSIV00000201        }
//DSIV00000201    }
//DSIV00000201    holdReleasedLotIDs.length(holdReleasedLotCount);                              //P4200204
//DSIV00000201    PPT_METHODTRACE_V2("","HoldReleased Lot Count is", holdReleasedLotCount );    //P4200204

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*-------------------------------------------*/
        /*   Effect PO's Direction for TEL Furnace   */
        /*-------------------------------------------*/
        objLot_holdRecord_EffectMonitorIssue_out   strLot_holdRecord_EffectMonitorIssue_out;
        rc = lot_holdRecord_EffectMonitorIssue( strLot_holdRecord_EffectMonitorIssue_out,
                                                strObjCommonIn,
                                                strStartCassette);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_holdRecord_EffectMonitorIssue() != RC_OK") ;
            strForceOpeCompForInternalBufferReqResult.strResult = strLot_holdRecord_EffectMonitorIssue_out.strResult ;
            return( rc );
        }

        CORBA::Long nMonitorHoldEffectLen = 0;
        nMonitorHoldEffectLen = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList.length() ;
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList.length()", nMonitorHoldEffectLen) ;

        if( nMonitorHoldEffectLen > 0 )
        {
            pptHoldLotReqResult strHoldLotReqResult ;
            pptHoldListSequence strLotHoldReqList( 1 ) ;
            strLotHoldReqList.length( 1 ) ;

            for( i = 0 ; i< nMonitorHoldEffectLen ; i++ )
            {
                strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].holdType ;
                strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].reasonCodeID ;
                strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].userID ;
                strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].responsibleOperationMark ;
                strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].routeID ;
                strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].operationNumber ;
                strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].relatedLotID ;
                strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].claimMemo ;

                rc = txHoldLotReq( strHoldLotReqResult,
                                   strObjCommonIn ,
                                   strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].lotID ,
                                   strLotHoldReqList ) ;

                if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )     //Q3000159
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                    return( rc );
                }
            }
        }
//DSIV00000201 add start
    }
//DSIV00000201 add end

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*------------------------------------------*/
        /*   Effect Future Hold Direction if Exist  */
        /*------------------------------------------*/
    //D4100083    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;

        for( i=0 ; i<scLen; i++ )
        {
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0; j<nLen; j++)
            {
                 /*---------------------------*/
                 /*   Omit Not-OpeStart Lot   */
                 /*---------------------------*/
                 if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                 {
                     continue;
                 }

                /*------------------------------------------*/
                /*   Effect Future Hold Direction if Exist  */
                /*------------------------------------------*/
    //D4100083            rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID) ;
    //D4100083            if(rc != RC_OK)
    //D4100083            {
    //D4100083                PPT_METHODTRACE_V1("", "lot_futureHoldRequests_Effect() != RC_OK") ;
    //D4100083                strForceOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
    //D4100083                return(rc);
    //D4100083            }
    //D4100083 Add Start

                PPT_METHODTRACE_V2("", "i",i);
                PPT_METHODTRACE_V2("", "j",j);
                PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette[j].lotID",strStartCassette[i].strLotInCassette[j].lotID.identifier);

                /*------------------------------------------------------------------*/
                /*   Get Effected Future Hold PRE of Current after Operation Move   */
                /*------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("", "Get Effected Future Hold PRE of Current after Operation Move") ;

                pptEffectCondition strEffectCondition;
                strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
                strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

                objLot_futureHoldRequests_EffectByCondition_out strLot_futureHoldRequests_EffectByCondition_out;
                rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_out,
                                                               strObjCommonIn,
                                                               strStartCassette[i].strLotInCassette[j].lotID,
                                                               strEffectCondition);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_out.strResult ;
                    return( rc );
                }

                if( strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", "strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0") ;

    //D4100083 Add End

    //D4100083            if( strLot_futureHoldRequests_Effect_out.strLotHoldReqList.length() > 0 )
    //D4100083            {
                    pptHoldLotReqResult strHoldLotReqResult ;
                    rc = txHoldLotReq( strHoldLotReqResult,
                                       strObjCommonIn,
                                       strStartCassette[i].strLotInCassette[j].lotID,
                                       strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList ) ;  //D4100083
    //D4100083                                   strLot_futureHoldRequests_Effect_out.strLotHoldReqList ) ;

                    if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )     //Q3000159
                    {
                        PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                        strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                        return(rc);
                    }
                }

    //D4100083 Add Start
                /*------------------------------------------------------------------------------------*/
                /*   Get Effected Future Hold Cancel PRE and SINGLE of Current after Operation Move   */
                /*------------------------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("", "Get Effected Future Hold Cancel PRE and SINGLE of Current after Operation Move") ;

                strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
                strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_SINGLE );

                objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;
                rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                                       strObjCommonIn,
                                                                       strStartCassette[i].strLotInCassette[j].lotID,
                                                                       strEffectCondition );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
                    return( rc );
                }

                if ( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", "strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0") ;
                    pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
                    rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult,
                                                strObjCommonIn,
                                                strStartCassette[i].strLotInCassette[j].lotID,
                                                releaseReasonCodeID,
                                                SP_EntryType_Remove,
                                                strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK") ;
                        strForceOpeCompForInternalBufferReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
                        return( rc );
                    }
                }

    //D4100083 Add End

            }
        }
//DSIV00000201 add start
    }
//DSIV00000201 add end


    /*----------------------------------------------------*/
    /*                                                    */
    /*   Equipment Related Information Update Procedure   */
    /*                                                    */
    /*----------------------------------------------------*/

    /*----------------------------------------------------------------*/
    /*   Remove ControlJobLot from EqpInfo's ProcessingLot Sequence   */
    /*----------------------------------------------------------------*/
    objEquipment_processingLot_Delete_out   strEquipment_processingLot_Delete_out;
    rc = equipment_processingLot_Delete( strEquipment_processingLot_Delete_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_processingLot_Delete() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_processingLot_Delete_out.strResult ;
        return(rc);
    }

    /*---------------------------------------------*/
    /*   Maintain Eqp's Status when OFF-LINE Mode  */
    /*---------------------------------------------*/
    if (CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode,
                    SP_Eqp_OnlineMode_Offline ) == 0)
    {
        PPT_METHODTRACE_V1("", "strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode == SP_Eqp_OnlineMode_Offline") ;

        /*--------------------------------------------------------*/
        /*   Change Equipment's Status to 'STANDBY' if necessary  */
        /*--------------------------------------------------------*/

        /*===== get StateChangeableFlag ===*/
        objEquipment_currentState_CheckToManufacturing_out   strEquipment_currentState_CheckToManufacturing_out;
        strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag = FALSE; //P3000280
        rc = equipment_currentState_CheckToManufacturing( strEquipment_currentState_CheckToManufacturing_out,
                                                          strObjCommonIn,
                                                          equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_currentState_CheckToManufacturing() != RC_OK") ;
            strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult ;
            return(rc);
        }

        if ( strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag == TRUE") ;

            /*===== get Defaclt Status Code for Productive / Standby ===*/
            objEquipment_recoverState_GetManufacturing_out   strEquipment_currentState_CheckToManufacturing_out;
            rc = equipment_recoverState_GetManufacturing( strEquipment_currentState_CheckToManufacturing_out,
                                                          strObjCommonIn,
                                                          equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_recoverState_GetManufacturing() != RC_OK") ;
                strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult ;
                return(rc);
            }

            /*---------------------------------*/
            /*   Call txEqpStatusChangeReq()   */
            /*---------------------------------*/
            pptEqpStatusChangeReqResult strEqpStatusChangeReqResult ;
            objectIdentifier equipmentStatus = strEquipment_currentState_CheckToManufacturing_out.equipmentStatusCode;

            rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult, strObjCommonIn, equipmentID, equipmentStatus, claimMemo );
            if ( rc != RC_OK && rc != RC_INVALID_STATE_TRANSITION )
            {
                PPT_METHODTRACE_V1("", "txEqpStatusChangeReq() != RC_OK") ;
                strForceOpeCompForInternalBufferReqResult.strResult = strEqpStatusChangeReqResult.strResult ;
                return(rc);
            }
        }
    }

    /*--------------------------------------*/
    /*   Equipment Usage Limitation Check   */
    /*--------------------------------------*/
    objEquipment_usageLimitation_Check_out   strEquipment_usageLimitation_Check_out;
    strEquipment_usageLimitation_Check_out.usageLimitOverFlag = FALSE; //P3000280
    rc = equipment_usageLimitation_Check( strEquipment_usageLimitation_Check_out, strObjCommonIn, equipmentID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_usageLimitation_Check() != RC_OK") ;
        strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_usageLimitation_Check_out.strResult ;
        return(rc);
    }

    if ( strEquipment_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
    {
        PPT_METHODTRACE_V1("", "strEquipment_usageLimitation_Check_out.usageLimitOverFlag == TRUE") ;

        /*-------------------------*/
        /*   Call System Message   */
        /*-------------------------*/
        pptSystemMsgRptResult strSystemMsgRptResult;
        objectIdentifier      dummy;

        rc = txSystemMsgRpt( strSystemMsgRptResult,
                             strObjCommonIn,
                             SP_SubSystemID_MM,
                             SP_SystemMsgCode_EqpUsageLimitOver,
                             strEquipment_usageLimitation_Check_out.messageText,
                             TRUE,
                             equipmentID,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             dummy,
                             "",
                             strObjCommonIn.strTimeStamp.reportTimeStamp,
                             "");
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
            strForceOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
            return(rc);
        }

    }


    /*----------------------------------------------------*/
    /*                                                    */
    /*   ControlJob Related Information Update Proceure   */
    /*                                                    */
    /*----------------------------------------------------*/

    /*------------------------*/
    /*   Delete Control Job   */
    /*------------------------*/
//D7000006    objControlJob_Delete_out   strControlJob_Delete_out;
//D7000006    rc = controlJob_Delete( strControlJob_Delete_out, strObjCommonIn, controlJobID );
//D7000006    if ( rc != RC_OK )
//D7000006    {
//D7000006        PPT_METHODTRACE_V1("", "controlJob_Delete() != RC_OK") ;
//D7000006        strForceOpeCompForInternalBufferReqResult.strResult = strControlJob_Delete_out.strResult ;
//D7000006        return(rc);
//D7000006    }
//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID is not TXEWC015 and TXEWC016");
//DSN000015229 Add End

        //D7000006 Add Start
        pptControlJobManageReqResult strControlJobManageReqResult;
        pptControlJobCreateRequest   dummyControlJobCreateRequest;
    //DSIV00000201    rc = txControlJobManageReq( strControlJobManageReqResult,
    //DSIV00000201                                strObjCommonIn,
    //DSIV00000201                                controlJobID,
    //DSIV00000201                                SP_ControlJobAction_Type_delete,
    //DSIV00000201                                dummyControlJobCreateRequest,
    //DSIV00000201                                claimMemo );
    //DSIV00000201 add start
        //----------------------------------------------------------------------------------
        // Delete ControlJob from EQP.
        // The relation of it with Lot and Cassette is deleted in txCollectedDataActionReq.
        //----------------------------------------------------------------------------------
        rc = txControlJobManageReq( strControlJobManageReqResult,
                                    strObjCommonIn,
                                    controlJobID,
                                    SP_ControlJobAction_Type_delete_From_EQP,
                                    dummyControlJobCreateRequest,
                                    claimMemo );
    //DSIV00000201 add end
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
            strForceOpeCompForInternalBufferReqResult.strResult = strControlJobManageReqResult.strResult;
            return( rc );
        }
        //D7000006 Add End
    }   //DSN000015229



    /*---------------------------------------------------*/
    /*                                                   */
    /*   Cassette Related Information Update Procedure   */
    /*                                                   */
    /*---------------------------------------------------*/
    for ( i=0; i<scLen; i++ )
    {
//INN-R170003 Add Start

        /*-------------------------------------*/
        /*   Cassette Usage Limitation Check   */
        /*-------------------------------------*/
        //objCassette_usageLimitation_Check_out   strCassette_usageLimitation_Check_out;
        //strCassette_usageLimitation_Check_out.usageLimitOverFlag = FALSE; //P3000280
        //rc = cassette_usageLimitation_Check( strCassette_usageLimitation_Check_out, strObjCommonIn, strStartCassette[i].cassetteID );
        //if ( rc != RC_OK )
        //{
        //    PPT_METHODTRACE_V1("", "cassette_usageLimitation_Check() != RC_OK") ;
        //    strForceOpeCompForInternalBufferReqResult.strResult = strCassette_usageLimitation_Check_out.strResult ;
        //    return(rc);
        //}
        //
        //if ( strCassette_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
        //{
        //    PPT_METHODTRACE_V1("", "strCassette_usageLimitation_Check_out.usageLimitOverFlag == TRUE") ;
        //
        //    /*-------------------------*/
        //    /*   Call System Message   */
        //    /*-------------------------*/
        //    pptSystemMsgRptResult strSystemMsgRptResult;
        //    objectIdentifier      dummy;
        //
        //    rc = txSystemMsgRpt( strSystemMsgRptResult,
        //                         strObjCommonIn,
        //                         SP_SubSystemID_MM,
        //                         SP_SystemMsgCode_CastUsageLimitOver,
        //                         strCassette_usageLimitation_Check_out.messageText,
        //                         TRUE,
        //                         dummy,
        //                         "",
        //                         dummy,
        //                         "",
        //                         dummy,
        //                         "",
        //                         dummy,
        //                         "",
        //                         dummy,
        //                         dummy,
        //                         "",
        //                         strObjCommonIn.strTimeStamp.reportTimeStamp,
        //                         "");
        //    if ( rc != RC_OK )
        //    {
        //        PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
        //        strForceOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
        //        return(rc);
        //    }
        //}
//INN-R170003 Add End
        /*---------------------------------------*/
        /*   Update Cassette's MultiLotType      */
        /*---------------------------------------*/
        objCassette_multiLotType_Update_out   strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn, strStartCassette[i].cassetteID );
        if ( rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
            strForceOpeCompForInternalBufferReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
            return(rc);
        }
    }

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        //-------------------------------------------------// //D40A0027
        //                                                 // //D40A0027
        //   ProcessLagTime Information Update Procedure   // //D40A0027
        //                                                 // //D40A0027
        //-------------------------------------------------// //D40A0027
        PPT_METHODTRACE_V1("", "ProcessLagTime Information Update Procedure...") ;
        for ( i=0 ; i<scLen ; i++ )
        {

            PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()=>", nLen) ;
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0; j<nLen; j++ )
            {

                //---------------------------//
                //   Omit Not-OpeStart Lot   //
                //---------------------------//
                PPT_METHODTRACE_V1("", "Omit Not-OpeStart Lot...") ;
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                //--------------------------------------//
                //   Call txProcessLagTimeUpdateReq()   //
                //--------------------------------------//
                PPT_METHODTRACE_V1("", "Call txProcessLagTimeUpdateReq()...") ;
                pptProcessLagTimeUpdateReqResult strProcessLagTimeUpdateReqResult;
                rc = txProcessLagTimeUpdateReq( strProcessLagTimeUpdateReqResult,
                                                strObjCommonIn,
                                                strStartCassette[i].strLotInCassette[j].lotID,
                                                SP_ProcessLagTime_Action_Set,
                                                claimMemo );
                if ( rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txProcessLagTimeUpdateReq() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strProcessLagTimeUpdateReqResult.strResult ;
                    return( rc );
                }

            }

        }

    //D4200029 Add Start
//DSIV00000201 add start
    }
//DSIV00000201 add end

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        //-----------------------//
        //     Process Hold      //
        //-----------------------//

        for ( i=0 ; i<scLen ; i++ )
        {
            CORBA::Long lcLen = 0;
            lcLen = strStartCassette[i].strLotInCassette.length();

            for ( CORBA::Long j = 0; j<lcLen ; j++ )
            {
                PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
                pptProcessHoldExecReqResult strProcessHoldExecReqResult;

                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE )
                {
                    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                                               strObjCommonIn,
                                               strStartCassette[i].strLotInCassette[j].lotID,
                                               claimMemo );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
                        strForceOpeCompForInternalBufferReqResult.strResult = strProcessHoldExecReqResult.strResult ;
                        return( rc );
                    }
                }
            }
        }

    //D4200029 Add End
//DSIV00000201 add start
    }
//DSIV00000201 add end

    /*--------------------------*/
    /*                          */
    /*   Event Make Procedure   */
    /*                          */
    /*--------------------------*/
    for ( i=0 ; i<scLen ; i++ )
    {
        PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()=>", nLen) ;
        CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0; j<nLen; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            PPT_METHODTRACE_V2("", "counter j for lotOperationMoveEvent_MakeOpeComp=", j) ;
            /*--------------------------------------------------------------------*/
            /*   Make OperationMoveEvent for Operation History - OpeComp          */
            /*--------------------------------------------------------------------*/
            objLotOperationMoveEvent_MakeOpeComp_out strLotOperationMoveEvent_MakeOpeComp_out;
            rc = lotOperationMoveEvent_MakeOpeComp( strLotOperationMoveEvent_MakeOpeComp_out,
                                                    strObjCommonIn,
//P4100273                                                    "TXTRC004",
                                                    "TXEWC011",           //P4100273
                                                    equipmentID,
                                                    strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier,
                                                    controlJobID,
                                                    strStartCassette[i].cassetteID,
                                                    strStartCassette[i].strLotInCassette[j],
                                                    claimMemo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lotOperationMoveEvent_MakeOpeComp() != RC_OK") ;
                strForceOpeCompForInternalBufferReqResult.strResult = strLotOperationMoveEvent_MakeOpeComp_out.strResult ;
                return(rc);
            }

        }

    }

//DSIV00000201 add start
    pptCollectedDataActionReqResult    strCollectedDataActionReqResult;

    if( PostProcForLotFlag != 1 )
    {
        //-------------------------------------------------//
        //                                                 //
        //     Invoking Action for Collected Data.         //
        //                                                 //
        //-------------------------------------------------//
        pptCollectedDataActionReqInParm    strCollectedDataActionReqInParm;
        strCollectedDataActionReqInParm.controlJobID     = controlJobID;
        strCollectedDataActionReqInParm.equipmentID      = equipmentID;
        strCollectedDataActionReqInParm.strStartCassette = strStartCassette;

        rc = txCollectedDataActionReq ( strCollectedDataActionReqResult,
                                        strObjCommonIn,
                                        strCollectedDataActionReqInParm,
                                        claimMemo );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txCollectedDataActionReq() != RC_OK") ;
            strForceOpeCompForInternalBufferReqResult.strResult = strCollectedDataActionReqResult.strResult;
            return(rc);
        }
        holdReleasedLotIDs                                      = strCollectedDataActionReqResult.holdReleasedLotIDs;
        strForceOpeCompForInternalBufferReqResult.strResult     = strCollectedDataActionReqResult.strOpeCompWithDataReqResult.strResult ;
        strForceOpeCompForInternalBufferReqResult.strOpeCompLot = strCollectedDataActionReqResult.strOpeCompWithDataReqResult.strOpeCompLot ;
    }
    else
    {
        pptDataSpecCheckReqResult tg;
        tg.strStartCassette = strStartCassette;
        DebugOutStartCassette( tg );

        //-------------------------------------------------//
        //                                                 //
        //     DataValue CheckValidity for SpeckCheck      //
        //                                                 //
        //-------------------------------------------------//
        objDataValue_CheckValidityForSpecCheckDR_out strDataValue_CheckValidityForSpecCheckDR_out;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.equipmentID      = equipmentID;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.controlJobID     = controlJobID;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette = strStartCassette;

        /*----------------------*/
        /*   Initialize Logic   */
        /*----------------------*/
        PPT_METHODTRACE_V1("", "Initialize Logic...") ;

        /*-------------------------------*/
        /*   Loop for strStartCassette   */
        /*-------------------------------*/
        PPT_METHODTRACE_V1("", "Loop for strStartCassette...") ;
        for ( i=0 ; i<scLen ; i++ )
        {
            /*-------------------------------*/
            /*   Loop for strLotInCassette   */
            /*-------------------------------*/
            PPT_METHODTRACE_V3("", "scLen / i", scLen, i);
            PPT_METHODTRACE_V1("", "Loop for strLotInCassette...") ;

            CORBA::Long lcLen = strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette.length();
            for ( CORBA::Long j=0 ; j<lcLen ; j++ )
            {
                PPT_METHODTRACE_V3("", "lcLen / j", lcLen, j);
                /*------------------------*/
                /*   Omit Not-Start Lot   */
                /*------------------------*/
                PPT_METHODTRACE_V1("", "Omit Not-Start Lot...");

                if ( strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "Not-Start Lot. continue...");
                    continue;
                }

                /*---------------------------------*/
                /*   Omit Non-DataClooection Lot   */
                /*---------------------------------*/
                PPT_METHODTRACE_V1("", "Omit Non-DataClooection Lot...");

                if ( strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.dataCollectionFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "Non-DCDef Lot. continue...");
                    continue;
                }

                /*-----------*/
                /*   Clear   */
                /*-----------*/
                PPT_METHODTRACE_V1("", "Clear...");
                CORBA::Long dcLen = strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                for ( CORBA::Long n=0 ; n<dcLen ; n++ )
                {
                    PPT_METHODTRACE_V3("", "dcLen / n", dcLen, n);
                    CORBA::Long itLen = strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem.length();
                    for ( CORBA::Long l=0 ; l<itLen ; l++ )
                    {
                        PPT_METHODTRACE_V3("", "itLen / l", itLen, l);
//DSN000015229 Add Start
                        CORBA::Boolean bClearFlag = TRUE;
                        if ( 0 == CIMFWStrCmp(SP_DCDef_Meas_PJ, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].measurementType)
                          || 0 == CIMFWStrCmp(SP_DCDef_Meas_PJWafer, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].measurementType)
                          || 0 == CIMFWStrCmp(SP_DCDef_Meas_PJWaferSite, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].measurementType) )
                        {
                            PPT_METHODTRACE_V5("", "strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].measurementType is SP_DCDef_Meas_PJ or SP_DCDef_Meas_PJWafer or SP_DCDef_Meas_PJWaferSite", i, j, n, l);
                            if ( 0 < CIMFWStrLen(strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult) )
                            {
                                PPT_METHODTRACE_V5("", "0 < CIMFWStrLen(strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)", i, j, n, l);
                                if ( 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_OK, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_UpperControlLimit, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_LowerControlLimit, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_UpperSpecLimit, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_LowerSpecLimit, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_UpperScreenLimit, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_LowerScreenLimit, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_APCError, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_Asterisk, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_1X_Pound, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult)
                                  || 0 == CIMFWStrCmp(SP_SpecCheckResult_Error, strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult) )
                                {
                                    //Do Nothing
                                    PPT_METHODTRACE_V1("", "Do Nothing");
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("", "set bClearFlag = FALSE");
                                    bClearFlag = FALSE;
                                }
                            }
                        }
                        if (TRUE == bClearFlag)
                        {
//DSN000015229 Add End
//DSN000015229 Indent Start
                            /*===== Clear specCheckResult / actionCode =====*/
                            PPT_METHODTRACE_V1("", "Clear specCheckResult / actionCode...");
                            strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult = (const char *)"";
                            strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].actionCode.length(0);

                            /*===== Clear dataValue =====*/
                            PPT_METHODTRACE_V1("", "Clear dataValue...");
                            if ( CIMFWStrCmp(strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].itemType, SP_DCDef_Item_Raw) == 0 )
                            {
                                PPT_METHODTRACE_V1("", "Raw Item. continue...");
                                continue;
                            }
                            strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].dataValue = (const char *)"";
//DSN000015229 Indent End
                        }           //DSN000015229
                    }   // Loop for DCItem
                }   // Loop for DCDef
            }   // Loop for strLotInCassette
        }   // Loop for strStartCassette

        /*----------------------------------*/
        /*   Set Initialized Data into PO   */
        /*----------------------------------*/
        PPT_METHODTRACE_V1("", "Set Initialized Data into PO...");
        objProcessOperation_tempData_Set_out strProcessOperation_tempData_Set_out;
        rc = processOperation_tempData_Set( strProcessOperation_tempData_Set_out,
                                            strObjCommonIn,
                                            controlJobID,
                                            strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "processOperation_tempData_Set() != RC_OK");
            strForceOpeCompForInternalBufferReqResult.strResult = strProcessOperation_tempData_Set_out.strResult;
            return( rc );
        }
//DSIV00001471 Add Start
        /*------------------------------------------------*/
        /*   Set DC Spec's detailed information into PO   */
        /*------------------------------------------------*/
        objProcess_dataCollectionSpecification_Set_out strProcess_dataCollectionSpecification_Set_out;

        rc = process_dataCollectionSpecification_Set( strProcess_dataCollectionSpecification_Set_out,
                                                      strObjCommonIn,
                                                      strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_dataCollectionSpecification_Set() != RC_OK");
            strForceOpeCompForInternalBufferReqResult.strResult = strProcess_dataCollectionSpecification_Set_out.strResult;
            return( rc );
        }
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette = strProcess_dataCollectionSpecification_Set_out.strStartCassette;

        PPT_METHODTRACE_V1("", "Do dataValue_CheckValidityForSpecCheck");
//DSIV00001471 Add End
        /*--------------------*/
        /*   Validity Check   */
        /*--------------------*/
        rc = dataValue_CheckValidityForSpecCheckDR(strDataValue_CheckValidityForSpecCheckDR_out, strObjCommonIn);
        switch ( rc )
        {
            case RC_OK:
                PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() == RC_OK") ;
                break;
            case RC_ALL_DATAVAL_ASTERISK:
                PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() == RC_ALL_DATAVAL_ASTERISK") ;
                rc = RC_OK;
                break;
            default:
                PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() != RC_OK") ;
                strForceOpeCompForInternalBufferReqResult.strResult = strDataValue_CheckValidityForSpecCheckDR_out.strResult;
                return(rc);
        }
//DSN000015229 Add Start
        if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
          && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
        {
//DSN000015229 Add End
//DSN000015229 Indent Start
            //---------------------------------------------//
            //   Delete Control Job From Lot and Cassette  //
            //---------------------------------------------//
            PPT_METHODTRACE_V1( "", "Delete controlJob from Lot and Cassette.");
            pptControlJobManageReqResult strControlJobManageReqResult2;
            pptControlJobCreateRequest   dummyControlJobCreateRequest2;
            rc = txControlJobManageReq( strControlJobManageReqResult2,
                                        strObjCommonIn,
                                        controlJobID,
                                        SP_ControlJobAction_Type_delete_From_LotAndCassette,
                                        dummyControlJobCreateRequest2,
                                        claimMemo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
                strForceOpeCompForInternalBufferReqResult.strResult = strControlJobManageReqResult2.strResult;
                return( rc );
            }
//DSN000015229 Indent End
        }   //DSN000015229
    }
//DSIV00000201 add end

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
    //D4100120 Add Start
        /*-----------------------------*/
        /*   Future Action Procedure   */
        /*-----------------------------*/
        for (i=0;i<scLen;i++)
        {
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0;j<nLen;j++)
            {
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if (strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE)
                {
                    continue;
                }

                CORBA::String_var tmpRouteID = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier;
//DSIV00002435                objSchdlChangeReservation_CheckForAction_out strSchdlChangeReservation_CheckForAction_out;
//DSIV00002435                rc = schdlChangeReservation_CheckForActionDR(strSchdlChangeReservation_CheckForAction_out,
//DSIV00002435                                                             strObjCommonIn,
//DSIV00002435                                                             strStartCassette[i].strLotInCassette[j].lotID,
//DSIV00002435                                                             tmpRouteID,
//DSIV00002435                                                            strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber);
//DSIV00002435 add start
                objSchdlChangeReservation_CheckForActionDR_out__110 strSchdlChangeReservation_CheckForAction_out;
                objSchdlChangeReservation_CheckForActionDR_in__110  strSchdlChangeReservation_CheckForActionDR_in;
                strSchdlChangeReservation_CheckForActionDR_in.lotID           = strStartCassette[i].strLotInCassette[j].lotID;
                strSchdlChangeReservation_CheckForActionDR_in.routeID         = tmpRouteID;
                strSchdlChangeReservation_CheckForActionDR_in.operationNumber = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;
                rc = schdlChangeReservation_CheckForActionDR__110( strSchdlChangeReservation_CheckForAction_out,
                                                                   strObjCommonIn,
                                                                   strSchdlChangeReservation_CheckForActionDR_in );
//DSIV00002435 add end
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForActionDR() != RC_OK") ;
                    strForceOpeCompForInternalBufferReqResult.strResult = strSchdlChangeReservation_CheckForAction_out.strResult;
                    return(rc);
                }

                if (strSchdlChangeReservation_CheckForAction_out.existFlag == True)
                {
                    pptSchdlChangeReservationExecuteReqResult strSchdlChangeReservationExecuteReqResult;
//DSIV00002435                    pptRescheduledLotAttributesSequence strRescheduledLotAttributes;
                    pptRescheduledLotAttributesSequence__110 strRescheduledLotAttributes;           //DSIV00002435
                    strRescheduledLotAttributes.length(1);
                    strRescheduledLotAttributes[0].lotID                  = strStartCassette[i].strLotInCassette[j].lotID;
                    strRescheduledLotAttributes[0].productID              = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.productID;
                    strRescheduledLotAttributes[0].routeID                = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.routeID;
                    strRescheduledLotAttributes[0].currentOperationNumber = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.operationNumber;
                    strRescheduledLotAttributes[0].subLotType             = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.subLotType;          //DSIV00002435

                    //P5100473 Add Start
                    //------------------------------------------------------------------------//
                    // Get current RouteID by lotID                                           //
                    //------------------------------------------------------------------------//
                    objLot_currentRouteID_Get_out       strLot_currentRouteID_Get_out;
                    rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out,
                                                 strObjCommonIn,
                                                 strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_currentRouteID_Get() != RC_OK :", rc);
                        strForceOpeCompForInternalBufferReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
                        return( rc );
                    }

                    strRescheduledLotAttributes[0].originalRouteID = strLot_currentRouteID_Get_out.currentRouteID.identifier;
                    PPT_METHODTRACE_V2( "", "OriginalRouteID", strRescheduledLotAttributes[0].originalRouteID );

                    //------------------------------------------------------------------------//
                    // Get current oparation No. by lotID                                     //
                    //------------------------------------------------------------------------//
                    objLot_currentOpeNo_Get_out strLot_currentOpeNo_Get_out;
                    rc = lot_currentOpeNo_Get(strLot_currentOpeNo_Get_out,
                                              strObjCommonIn,
                                              strStartCassette[i].strLotInCassette[j].lotID);
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "lot_currentOpeNo_Get() != RC_OK",rc);
                        strForceOpeCompForInternalBufferReqResult.strResult = strLot_currentOpeNo_Get_out.strResult;
                        return(rc);
                    }

                    strRescheduledLotAttributes[0].originalOperationNumber = CIMFWStrDup( strLot_currentOpeNo_Get_out.currentOperationNumber );
                    PPT_METHODTRACE_V2("","OroginalOperationNumber",strRescheduledLotAttributes[0].originalOperationNumber);
                    //P5100473 Add End

//DSIV00002435                    rc = txSchdlChangeReservationExecuteReq(strSchdlChangeReservationExecuteReqResult,
                    rc = txSchdlChangeReservationExecuteReq__110(strSchdlChangeReservationExecuteReqResult,             //DSIV00002435
                                                            strObjCommonIn,
                                                            strRescheduledLotAttributes,
                                                            strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.eventID);

                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "txSchdlChangeReservationExecuteReq() != RC_OK") ;
                        strForceOpeCompForInternalBufferReqResult.strResult = strSchdlChangeReservationExecuteReqResult.strResult;
                        return(rc);
                    }

//DSIV00002435                    objSchdlChangeReservation_applyCount_Increase_out strSchdlChangeReservation_applyCount_Increase_out;
//DSIV00002435                    rc = schdlChangeReservation_applyCount_IncreaseDR(strSchdlChangeReservation_applyCount_Increase_out,
//DSIV00002435                                                                      strObjCommonIn,
//DSIV00002435                                                                      strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation);
//DSIV00002435 add start
                    objSchdlChangeReservation_applyCount_Increase_out       strSchdlChangeReservation_applyCount_Increase_out;
                    objSchdlChangeReservation_applyCount_IncreaseDR_in__110 strSchdlChangeReservation_applyCount_IncreaseDR_in;
                    strSchdlChangeReservation_applyCount_IncreaseDR_in.strSchdlChangeReservation = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation;
                    rc = schdlChangeReservation_applyCount_IncreaseDR__110( strSchdlChangeReservation_applyCount_Increase_out,
                                                                            strObjCommonIn,
                                                                            strSchdlChangeReservation_applyCount_IncreaseDR_in );
//DSIV00002435 add end
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "schdlChangeReservation_applyCount_IncreaseDR() != RC_OK") ;
                        strForceOpeCompForInternalBufferReqResult.strResult = strSchdlChangeReservation_applyCount_Increase_out.strResult;
                        return(rc);
                    }
                }
            }
        }
    //D4100120 Add End
//DSIV00000201 add start
    }
//DSIV00000201 add end

    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   BR Script Procedure                                                  */
    /*                                                                        */
    /*------------------------------------------------------------------------*/

    /*-----------------------*/
    /*   Execute BRScript    */
    /*-----------------------*/
    for ( i=0 ; i<scLen ; i++ )
    {

        CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0; j<nLen; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            /*-------------------------*/
            /*   Execute Post BRScript */
            /*-------------------------*/
            pptRunBRScriptReqResult strRunBRScriptReqResult;
            rc = txRunBRScriptReq( strRunBRScriptReqResult,
                                   strObjCommonIn,
                                   SP_BRScript_Post,
                                   strStartCassette[i].strLotInCassette[j].lotID,
                                   equipmentID);
            if ( rc == RC_NOT_FOUND_SCRIPT )
            {
                PPT_METHODTRACE_V1("", "txRunBRScriptReq() == RC_NOT_FOUND_SCRIPT") ;
            }
            else if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txRunBRScriptReq() != RC_OK") ;
                strForceOpeCompForInternalBufferReqResult.strResult = strRunBRScriptReqResult.strResult ;
                return(rc);
            }
        }
    }

//PSIV00003068    /*---------------------------------------------------------------*/
//PSIV00003068    /*   Auto Hold after force complete                              */
//PSIV00003068    /*---------------------------------------------------------------*/
//PSIV00003068    for ( i=0 ; i<scLen ; i++ )
//PSIV00003068    {
//PSIV00003068        CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
//PSIV00003068        for (CORBA::Long j=0; j<nLen; j++ )
//PSIV00003068        {
//PSIV00003068
//PSIV00003068            /*---------------------------*/
//PSIV00003068            /*   Omit Not-OpeStart Lot   */
//PSIV00003068            /*---------------------------*/
//PSIV00003068            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
//PSIV00003068            {
//PSIV00003068                continue;
//PSIV00003068            }
//PSIV00003068
//PSIV00003068//D4100080 Add Start
//PSIV00003068            pptLotHoldListInqResult strLotHoldListInqResult;
//PSIV00003068            rc = txLotHoldListInq( strLotHoldListInqResult,
//PSIV00003068                                   strObjCommonIn,
//PSIV00003068                                   strStartCassette[i].strLotInCassette[j].lotID ) ;
//PSIV00003068            if( rc != RC_OK)
//PSIV00003068            {
//PSIV00003068                PPT_METHODTRACE_V1("", "txLotHoldListInq() != RC_OK") ;
//PSIV00003068                strForceOpeCompForInternalBufferReqResult.strResult = strLotHoldListInqResult.strResult ;
//PSIV00003068                return (rc) ;
//PSIV00003068            }
//PSIV00003068
//PSIV00003068            PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette[j].lotID =",strStartCassette[i].strLotInCassette[j].lotID.identifier);
//PSIV00003068
//PSIV00003068            CORBA::Long oLen = strLotHoldListInqResult.strLotHoldListAttributes.length();
//PSIV00003068            for (CORBA::Long k=0; k<oLen; k++ )
//PSIV00003068            {
//PSIV00003068                PPT_METHODTRACE_V2("", "k =",k);
//PSIV00003068
//PSIV00003068                if (CIMFWStrCmp(strLotHoldListInqResult.strLotHoldListAttributes[k].reasonCodeID.identifier, SP_Reason_RunningHold ) == 0)
//PSIV00003068                {
//PSIV00003068
//PSIV00003068                    PPT_METHODTRACE_V1("", "Find Running Hold Record!!") ;
//PSIV00003068                    pptHoldListSequence strLotHoldReleaseReqList;
//PSIV00003068                    strLotHoldReleaseReqList.length(1);
//PSIV00003068
//PSIV00003068                    strLotHoldReleaseReqList[0].holdType                 = strLotHoldListInqResult.strLotHoldListAttributes[k].holdType;
//PSIV00003068                    strLotHoldReleaseReqList[0].holdReasonCodeID         = strLotHoldListInqResult.strLotHoldListAttributes[k].reasonCodeID;
//PSIV00003068                    strLotHoldReleaseReqList[0].holdUserID               = strLotHoldListInqResult.strLotHoldListAttributes[k].userID;
//PSIV00003068                    strLotHoldReleaseReqList[0].responsibleOperationMark = strLotHoldListInqResult.strLotHoldListAttributes[k].responsibleOperationMark;
//PSIV00003068                    strLotHoldReleaseReqList[0].routeID                  = strLotHoldListInqResult.strLotHoldListAttributes[k].responsibleRouteID;
//PSIV00003068                    strLotHoldReleaseReqList[0].operationNumber          = strLotHoldListInqResult.strLotHoldListAttributes[k].responsibleOperationNumber;
//PSIV00003068                    strLotHoldReleaseReqList[0].relatedLotID             = strLotHoldListInqResult.strLotHoldListAttributes[k].relatedLotID;
//PSIV00003068                    strLotHoldReleaseReqList[0].claimMemo                = CIMFWStrDup("");
//PSIV00003068
//PSIV00003068                    objectIdentifier aReasonCodeID ;
//PSIV00003068                    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_RunningHoldRelease ) ;
//PSIV00003068
//PSIV00003068                    pptHoldLotReleaseReqResult strHoldLotReleaseReqResult;
//PSIV00003068                    rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult,
//PSIV00003068                                              strObjCommonIn,
//PSIV00003068                                              strStartCassette[i].strLotInCassette[j].lotID,
//PSIV00003068                                              aReasonCodeID,
//PSIV00003068                                              strLotHoldReleaseReqList ) ;
//PSIV00003068                    if( rc != RC_OK)
//PSIV00003068                    {
//PSIV00003068                        PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK") ;
//PSIV00003068                        strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReleaseReqResult.strResult ;
//PSIV00003068                        return (rc) ;
//PSIV00003068                    }
//PSIV00003068                    break;
//PSIV00003068
//PSIV00003068                }
//PSIV00003068
//PSIV00003068            }
//PSIV00003068//D4100080 Add End
//PSIV00003068
//PSIV00003068            /*-------------------------*/
//PSIV00003068            /*   Execute Lot Hold      */
//PSIV00003068            /*-------------------------*/
//PSIV00003068            objectIdentifier dummyRoute;
//PSIV00003068            objectIdentifier dummyLot;
//PSIV00003068            objectIdentifier reasonCodeID;
//PSIV00003068            reasonCodeID.identifier = CIMFWStrDup( SP_Reason_ForceCompHold );
//PSIV00003068
//PSIV00003068            pptHoldListSequence  strHoldListSeq;
//PSIV00003068            strHoldListSeq.length(1);
//PSIV00003068
//PSIV00003068            strHoldListSeq[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold );
//PSIV00003068            strHoldListSeq[0].holdReasonCodeID         = reasonCodeID;
//PSIV00003068            strHoldListSeq[0].holdUserID               = strObjCommonIn.strUser.userID;
//PSIV00003068            strHoldListSeq[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Previous );
//PSIV00003068            strHoldListSeq[0].routeID                  = dummyRoute;
//PSIV00003068            strHoldListSeq[0].operationNumber          = CIMFWStrDup("");
//PSIV00003068            strHoldListSeq[0].relatedLotID             = dummyLot;
//PSIV00003068            strHoldListSeq[0].claimMemo                = CIMFWStrDup("SYSAUTO:Force Compelete System Hold");
//PSIV00003068
//PSIV00003068            pptHoldLotReqResult strHoldLotReqResult;
//PSIV00003068            rc = txHoldLotReq( strHoldLotReqResult,
//PSIV00003068                               strObjCommonIn,
//PSIV00003068                               strStartCassette[i].strLotInCassette[j].lotID,
//PSIV00003068                               strHoldListSeq );
//PSIV00003068
//PSIV00003068            if ( rc != RC_OK )
//PSIV00003068            {
//PSIV00003068                PPT_METHODTRACE_V1("CS_PPTManager_i:: txForceOpeCompForInternalBufferReq", "txHoldLotReq() != RC_OK") ;
//PSIV00003068                strForceOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
//PSIV00003068                return(rc);
//PSIV00003068            }
//PSIV00003068        }
//PSIV00003068    }

//DSIV00000201//D4200115 add start
//DSIV00000201    /*---------------------------------------------------------------*/
//DSIV00000201    /*   New Action by SPC Check result                              */
//DSIV00000201    /*---------------------------------------------------------------*/
//DSIV00000201    pptSpcActionExecuteReqResult strSpcActionExecuteReqResult;
//DSIV00000201    rc = txSpcActionExecuteReq( strSpcActionExecuteReqResult,
//DSIV00000201                                strObjCommonIn,
//DSIV00000201                                strStartLot_actionList_EffectSPCCheck_out.strBankMoveList,
//DSIV00000201                                strStartLot_actionList_EffectSPCCheck_out.strMailSendList,
//DSIV00000201                                strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList,
//DSIV00000201                                claimMemo );
//DSIV00000201    if ( rc != RC_OK )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V1("", "txSpcActionExecuteReq() != RC_OK") ;
//DSIV00000201        strForceOpeCompForInternalBufferReqResult.strResult = strSpcActionExecuteReqResult.strResult ;
//DSIV00000201        return(rc);
//DSIV00000201    }
//DSIV00000201//D4200115 add end


//D7000096    //D4100134 if ( 0 != CIMFWStrCmp(theSP_DELIVERY_REQ_EXIST, "YES") )  //D4000011
//D7000096    if ( 0 != CIMFWStrCmp(getenv(SP_DELIVERY_REQ_EXIST), "YES") )        //D4100134
//D7000096    {
//D7000096//D4000015 add start
//D7000096        /*-------------------------------------*/
//D7000096        /*   Get Port Information              */
//D7000096        /*-------------------------------------*/
//D7000096        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//D7000096        rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
//D7000096        if ( rc != RC_OK )
//D7000096        {
//D7000096           PPT_METHODTRACE_V1("", "equipment_portInfo_Get() rc != RC_OK");
//D7000096           strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
//D7000096           return( rc );
//D7000096        }
//D7000096
//D7000096        CORBA::Long portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//D7000096        PPT_METHODTRACE_V2("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", portLen);
//D7000096
//D7000096        for ( i=0 ; i<scLen ; i++ )
//D7000096        {
//D7000096            PPT_METHODTRACE_V3("", "cassetteID ", i, strStartCassette[i].cassetteID.identifier );
//D7000096            /*--------------------------------------------------*/
//D7000096            /*   Find Target Cassette                           */
//D7000096            /*   Condition:                                     */
//D7000096            /*    loadedCassetteID         ==  cassetteID       */
//D7000096            /*    Access Mode              ==  Auto             */
//D7000096            /*    PortState                ==  UnloadReq        */
//D7000096            /*    onlineMode               !=  OffLine          */
//D7000096            /*    dispatchState            ==  Required         */
//D7000096            /*    dispatchUnloadCassetteID ==  null             */
//D7000096            /*--------------------------------------------------*/
//D7000096            CORBA::Boolean  bFindCassetteFlag = FALSE;
//D7000096            for (CORBA::Long j = 0; j < portLen ; j++)
//D7000096            {
//D7000096                PPT_METHODTRACE_V3("", "loadedCassetteID         ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier );
//D7000096                PPT_METHODTRACE_V3("", "PortID                   ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier );
//D7000096                PPT_METHODTRACE_V3("", "Port State               ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState );
//D7000096                PPT_METHODTRACE_V3("", "Port Access Mode         ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].accessMode );
//D7000096                PPT_METHODTRACE_V3("", "OnlineMode  Mode         ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].onlineMode );
//D7000096                PPT_METHODTRACE_V3("", "dispatchState            ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState );
//D7000096                PPT_METHODTRACE_V3("", "dispatchUnloadCassetteID ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchUnloadCassetteID.identifier );
//D7000096
//D7000096                // Find Same Cassette from Equipment
//D7000096                if (CIMFWStrCmp( strStartCassette[i].cassetteID.identifier,
//D7000096                                 strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) == 0)
//D7000096                {
//D7000096                    // onlineMode check:
//D7000096                    //   1. accessMode is auto
//D7000096                    //   2. portState is UnloadReq
//D7000096                    //   3. onlineMode is Online
//D7000096                    //   4. dispatchState is Required
//D7000096                    //   5. dispatchUnloadCassetteID is null
//D7000096                    if (CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].accessMode, SP_Eqp_AccessMode_Auto               ) == 0 &&
//D7000096                        CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState,  SP_PortRsc_PortState_UnloadReq       ) == 0 &&
//D7000096                        CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].onlineMode, SP_Eqp_OnlineMode_Offline            ) != 0 &&
//D7000096                        CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Required ) == 0 &&
//D7000096                        CIMFWStrLen( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchUnloadCassetteID.identifier              ) == 0 )
//D7000096                    {
//D7000096                        bFindCassetteFlag = TRUE;
//D7000096                        break;
//D7000096                    }
//D7000096                }
//D7000096            }
//D7000096            // If it isn't found, it isn't made the target.
//D7000096            if (bFindCassetteFlag == FALSE)
//D7000096                continue;
//D7000096
//D7000096            PPT_METHODTRACE_V2("", "Call txWhereNextInterBayInq: cassetteID", strStartCassette[i].cassetteID.identifier );
//D7000096            /*----------------------------*/
//D7000096            /*   Get Where Next Stocker   */
//D7000096            /*----------------------------*/
//D7000096            objectIdentifier dummy;
//D7000096            pptWhereNextInterBayInqResult strWhereNextInterBayInqResult;
//D7000096            rc = txWhereNextInterBayInq( strWhereNextInterBayInqResult,
//D7000096                                         strObjCommonIn,
//D7000096                                         dummy,
//D7000096                                         strStartCassette[i].cassetteID );
//D7000096
//D7000096            if ( rc != RC_OK )
//D7000096            {
//D7000096                PPT_METHODTRACE_V1("", "txWhereNextInterBayInq() rc != RC_OK");
//D7000096                strForceOpeCompForInternalBufferReqResult.strResult = strWhereNextInterBayInqResult.strResult;
//D7000096                return( rc );
//D7000096            }
//D7000096            PPT_METHODTRACE_V1("", "Make txSingleCarrierXferReq parameter");
//D7000096            /*-------------------------------------------*/
//D7000096            /*   Make txSingleCarrierXferReq parameter   */
//D7000096            /*-------------------------------------------*/
//D7000096            objSingleCarrierXferFillInTXLGC013InParm_out strSingleCarrierXferFillInTXLGC013InParm_out;
//D7000096            rc = singleCarrierXferFillInTXLGC013InParm(
//D7000096                        strSingleCarrierXferFillInTXLGC013InParm_out,
//D7000096                        strObjCommonIn,
//D7000096                        equipmentID,
//D7000096                        strStartCassette[i].unloadPortID,
//D7000096                        strStartCassette[i].cassetteID,
//D7000096                        strWhereNextInterBayInqResult );
//D7000096            if ( rc != RC_OK )
//D7000096            {
//D7000096                PPT_METHODTRACE_V1("", "singleCarrierXferFillInTXLGC013InParm() rc != RC_OK");
//D7000096                strForceOpeCompForInternalBufferReqResult.strResult = strSingleCarrierXferFillInTXLGC013InParm_out.strResult;
//D7000096                return( rc );
//D7000096            }
//D7000096
//D7000096            PPT_METHODTRACE_V1("", "Send Request to XM. (EQP -> Stocker)");
//D7000096            /*------------------------------------------*/
//D7000096            /*   Send Request to XM. (EQP -> Stocker)   */
//D7000096            /*------------------------------------------*/
//D7000096            pptSingleCarrierXferReqResult strSingleCarrierXferReqResult;
//D7000096            rc = txSingleCarrierXferReq( strSingleCarrierXferReqResult,
//D7000096                                         strObjCommonIn,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.rerouteFlag,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.zoneType,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.n2PurgeFlag,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedStartTime,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedEndTime,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.mandatoryFlag,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.priority );
//D7000096
//D7000096            if ( rc != RC_OK )
//D7000096            {
//D7000096                PPT_METHODTRACE_V1("", "txSingleCarrierXferReq() rc != RC_OK");
//D7000096                strForceOpeCompForInternalBufferReqResult.strResult = strSingleCarrierXferReqResult.strResult;
//D7000096                return( rc );
//D7000096            }
//D7000096        }
//D7000096//D4000015 add end
//D7000096    }

//D5100232 start
    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send OpeComp Report to DCS Procedure                                 */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
    CORBA::Boolean bDCSAvailable = FALSE;
    CORBA::String_var DCSAvailable = CIMFWStrDup(getenv(SP_DCS_Available));
    PPT_METHODTRACE_V2("", "DCSAvailable", DCSAvailable);
    if (CIMFWStrCmp(DCSAvailable, "1") == 0 )
    {
        PPT_METHODTRACE_V1("", "DCS Interface Available");
        bDCSAvailable = TRUE;
    }

    if ( 0 != CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline)
      && TRUE == bDCSAvailable )
    {
        PPT_METHODTRACE_V1("", "Send OpeComp Report to DCS");

        CORBA::String_var IgnoreErr = CIMFWStrDup(getenv(SP_DCS_Ignore_OpeComp_Result));
        PPT_METHODTRACE_V2("", "SP_DCS_IGNORE_OPECOMP_RESULT", IgnoreErr);

        objDCSMgr_SendOperationCompletedRpt_out strDCSMgr_SendOperationCompletedRpt_out;
        rc = DCSMgr_SendOperationCompletedRpt( strDCSMgr_SendOperationCompletedRpt_out, strObjCommonIn, controlJobID );

        if ( rc != RC_OK && 0 != CIMFWStrCmp(IgnoreErr, "1") )
        {
            PPT_METHODTRACE_V2("", "##### DCSMgr_SendOperationCompletedRpt() != RC_OK", rc);
            strForceOpeCompForInternalBufferReqResult.strResult = strDCSMgr_SendOperationCompletedRpt_out.strResult;
            return( rc );
        }
    }
//D5100232 end

//P51M0018 move start
//P51M0018    /*--------------------------*/
//P51M0018    /*                          */
//P51M0018    /*   Set Return Structure   */
//P51M0018    /*                          */
//P51M0018    /*--------------------------*/
//P51M0018    objEquipment_FillInTxTRC004_out   strEquipment_FillInTxTRC004_out;
//P51M0018    rc = equipment_FillInTxTRC004( strEquipment_FillInTxTRC004_out, //0.01
//P51M0018                                   strObjCommonIn,
//P51M0018                                   strStartCassette,
//P51M0018                                   strSpcCheckReqResult.strSpcCheckLot);
//P51M0018    if ( rc != RC_OK )
//P51M0018    {
//P51M0018        PPT_METHODTRACE_V1("", "equipment_FillInTxTRC004() != RC_OK") ;
//P51M0018        strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_FillInTxTRC004_out.strResult ;
//P51M0018        return(rc);
//P51M0018    }
//P51M0018
//P51M0018    /*----------------------*/
//P51M0018    /*                      */
//P51M0018    /*   Return to Caller   */
//P51M0018    /*                      */
//P51M0018    /*----------------------*/
//P51M0018    strForceOpeCompForInternalBufferReqResult.strResult     = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strResult ;
//P51M0018    strForceOpeCompForInternalBufferReqResult.strOpeCompLot = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot ;
//P51M0018 move end

//D51M0000 Add Start
    /*-----------------------------------------------------*/
    /*   Call APCRuntimeCapability_DeleteDR                */
    /*-----------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call APCRuntimeCapability_DeleteDR");
    objAPCRuntimeCapability_DeleteDR_out strAPCRuntimeCapability_DeleteDR_out;
    rc = APCRuntimeCapability_DeleteDR ( strAPCRuntimeCapability_DeleteDR_out,
                                         strObjCommonIn,
                                         controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCRuntimeCapability_DeleteDR != RC_OK");
        strForceOpeCompForInternalBufferReqResult.strResult = strAPCRuntimeCapability_DeleteDR_out.strResult;
        return( rc );
    }

    /*-------------------------------------------------*/
    /*   Call APCMgr_SendControlJobInformationDR       */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call APCMgr_SendControlJobInformationDR()");
    objAPCMgr_SendControlJobInformationDR_out strAPCMgr_SendControlJobInformationDR_out;
    rc = APCMgr_SendControlJobInformationDR ( strAPCMgr_SendControlJobInformationDR_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              controlJobID,
                                              SP_APC_ControlJobStatus_Completed,
                                              strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList );
//D7000182    if ( rc != RC_OK )
    if ( rc != RC_OK && rc != RC_OK_NO_IF )    //D7000182
    {
        PPT_METHODTRACE_V1("", "APCMgr_SendControlJobInformationDR != RC_OK");
        strForceOpeCompForInternalBufferReqResult.strResult = strAPCMgr_SendControlJobInformationDR_out.strResult;
        return( rc );
    }

//D7000182 add start
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCControlJobInformation was sent normally.");
        CORBA::String_var tmpString = APCIFControlStatus;
        APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Executing);
    }
//D7000182 add end
//D51M0000 Add End

//D9000084 add start
    /*--------------------------------------*/
    /*  Update Reticle's LastUsedTimestamp  */
    /*--------------------------------------*/
    objReticle_lastUsedTimeStamp_Update_in strReticle_lastUsedTimeStamp_Update_in;
    strReticle_lastUsedTimeStamp_Update_in.strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;

    objReticle_lastUsedTimeStamp_Update_out strReticle_lastUsedTimeStamp_Update_out;
    rc = reticle_lastUsedTimeStamp_Update( strReticle_lastUsedTimeStamp_Update_out,
                                           strObjCommonIn,
                                           strReticle_lastUsedTimeStamp_Update_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "reticle_lastUsedTimeStamp_Update() != RC_OK");
        strForceOpeCompForInternalBufferReqResult.strResult = strReticle_lastUsedTimeStamp_Update_out.strResult;
        return( rc );
    }
//D9000084 add end

//DSN000085791 Add Start
    objEntityInhibitExceptionLot_ChangeForOpeComp_in strExceptionLot_ChangeForOpeComp_in;
    strExceptionLot_ChangeForOpeComp_in.lotIDs = opeStartLotIDs;
    strExceptionLot_ChangeForOpeComp_in.controlJobID = controlJobID;

    objEntityInhibitExceptionLot_ChangeForOpeComp_out strExceptionLot_ChangeForOpeComp_out;
    rc = entityInhibitExceptionLot_ChangeForOpeComp(strExceptionLot_ChangeForOpeComp_out, strObjCommonIn, strExceptionLot_ChangeForOpeComp_in);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "entityInhibitExceptionLot_ChangeForOpeComp() != RC_OK");
        strForceOpeCompForInternalBufferReqResult.strResult = strExceptionLot_ChangeForOpeComp_out.strResult;
        return( rc );
    }
//DSN000085791 Add End

//P51M0018 move start
//DSIV00000201    /*--------------------------*/
//DSIV00000201    /*                          */
//DSIV00000201    /*   Set Return Structure   */
//DSIV00000201    /*                          */
//DSIV00000201    /*--------------------------*/
//DSIV00000201    objEquipment_FillInTxTRC004_out   strEquipment_FillInTxTRC004_out;
//DSIV00000201    rc = equipment_FillInTxTRC004( strEquipment_FillInTxTRC004_out, //0.01
//DSIV00000201                                   strObjCommonIn,
//DSIV00000201                                   strStartCassette,
//DSIV00000201                                   strSpcCheckReqResult.strSpcCheckLot);
//DSIV00000201    if ( rc != RC_OK )
//DSIV00000201    {
//DSIV00000201        PPT_METHODTRACE_V1("", "equipment_FillInTxTRC004() != RC_OK") ;
//DSIV00000201        strForceOpeCompForInternalBufferReqResult.strResult = strEquipment_FillInTxTRC004_out.strResult ;
//DSIV00000201        return(rc);
//DSIV00000201    }
//DSIV00000201
//DSIV00000201    /*----------------------*/
//DSIV00000201    /*                      */
//DSIV00000201    /*   Return to Caller   */
//DSIV00000201    /*                      */
//DSIV00000201    /*----------------------*/
//DSIV00000201    strForceOpeCompForInternalBufferReqResult.strResult     = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strResult ;
//DSIV00000201    strForceOpeCompForInternalBufferReqResult.strOpeCompLot = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult.strOpeCompLot ;
//DSIV00000201 add start
    /*--------------------------*/
    /*                          */
    /*   Set Return Structure   */
    /*                          */
    /*--------------------------*/
    if( PostProcForLotFlag != 1 )
    {
        strForceOpeCompForInternalBufferReqResult.strResult     = strCollectedDataActionReqResult.strOpeCompWithDataReqResult.strResult ;
        strForceOpeCompForInternalBufferReqResult.strOpeCompLot = strCollectedDataActionReqResult.strOpeCompWithDataReqResult.strOpeCompLot ;
    }
    else
    {
        strForceOpeCompForInternalBufferReqResult.strResult     = strReticle_lastUsedTimeStamp_Update_out.strResult;
        nLen = opeStartLotIDs.length();
        strForceOpeCompForInternalBufferReqResult.strOpeCompLot.length(nLen);
        for( i=0 ; i<nLen ; i++ )
        {
            strForceOpeCompForInternalBufferReqResult.strOpeCompLot[i].lotID = opeStartLotIDs[i];
        }
    }
//DSIV00000201 add end
//P51M0018 move end

    SET_MSG_RC(strForceOpeCompForInternalBufferReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txForceOpeCompForInternalBufferReq") ;
    return( RC_OK );
}


//DSIV00000201 add start
void DebugOutStartCassette(pptDataSpecCheckReqResult& tg)   //P3100372 add
{
PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txForceOpeCompForInternalBufferReq::DebugOutStartCassette ") ; //D4100092
PPT_METHODTRACE_V1("", "P3100372 log start ******************************************");
CORBA::Long ii, jj, kk, ll, mm;
CORBA::Long len1, len2, len3, len4, len5;
len1 = tg.strStartCassette.length();
PPT_METHODTRACE_V2("", "tg.strStartCassette.length**********>", len1);
for(ii=0; ii < len1; ii++)
{
PPT_METHODTRACE_V2("", "loadSequenceNumber------------------------", tg.strStartCassette[ii].loadSequenceNumber);
PPT_METHODTRACE_V2("", "cassetteID--------------------------------", tg.strStartCassette[ii].cassetteID.identifier);
PPT_METHODTRACE_V2("", "loadPurposeType---------------------------", tg.strStartCassette[ii].loadPurposeType);
PPT_METHODTRACE_V2("", "loadPortID--------------------------------", tg.strStartCassette[ii].loadPortID.identifier);
PPT_METHODTRACE_V2("", "unloadPortID------------------------------", tg.strStartCassette[ii].unloadPortID.identifier);

len2 = tg.strStartCassette[ii].strLotInCassette.length();
PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette.length**********>", len2);
for(jj=0; jj < len2; jj++)
{
PPT_METHODTRACE_V2("", "  operationStartFlag----------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].operationStartFlag); //D9000001
PPT_METHODTRACE_V2("", "  monitorLotFlag--------------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].monitorLotFlag); //D9000001
PPT_METHODTRACE_V2("", "  lotID-----------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].lotID.identifier);
PPT_METHODTRACE_V2("", "  lotType---------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].lotType);
PPT_METHODTRACE_V2("", "  subLotType------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].subLotType);
PPT_METHODTRACE_V2("", "    logicalRecipeID-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.logicalRecipeID.identifier);
PPT_METHODTRACE_V2("", "    machineRecipeID-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.machineRecipeID.identifier);
PPT_METHODTRACE_V2("", "    physicalRecipeID----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.physicalRecipeID);

len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle.length();
PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle.length**********>", len3);
for(kk=0; kk < len3; kk++)
{
PPT_METHODTRACE_V2("", "      sequenceNumber----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle[kk].sequenceNumber);
PPT_METHODTRACE_V2("", "      reticleID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle[kk].reticleID.identifier);
}
len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture.length();
PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture.length**********>", len3);
for(kk=0; kk < len3; kk++)
{
PPT_METHODTRACE_V2("", "      fixtureID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture[kk].fixtureID.identifier);
PPT_METHODTRACE_V2("", "      fixtureCategory---------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture[kk].fixtureCategory);
PPT_METHODTRACE_V2("", "    dataCollectionFlag--------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.dataCollectionFlag); //D9000001
}
len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef.length();
PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef.length**********>", len3);
for(kk=0; kk < len3; kk++)
{
PPT_METHODTRACE_V2("", "      dataCollectionDefinitionID----------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionDefinitionID.identifier);
PPT_METHODTRACE_V2("", "      description-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].description);
PPT_METHODTRACE_V2("", "      dataCollectionType------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionType);

len4 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem.length();
PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem.length**********>", len4);
for(ll=0; ll < len4; ll++)
{
PPT_METHODTRACE_V2("", "        dataCollectionItemName------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionItemName);
PPT_METHODTRACE_V2("", "        dataCollectionMode----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionMode);
PPT_METHODTRACE_V2("", "        dataCollectionUnit----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionUnit);
PPT_METHODTRACE_V2("", "        dataType--------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataType);
PPT_METHODTRACE_V2("", "        itemType--------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].itemType);
PPT_METHODTRACE_V2("", "        measurementType-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].measurementType);
PPT_METHODTRACE_V2("", "        waferID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].waferID.identifier);
PPT_METHODTRACE_V2("", "        waferPosition---------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].waferPosition);
PPT_METHODTRACE_V2("", "        sitePosition----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].sitePosition);
PPT_METHODTRACE_V2("", "        historyRequiredFlag---------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].historyRequiredFlag); //D9000001
PPT_METHODTRACE_V2("", "        calculationType-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].calculationType);
PPT_METHODTRACE_V2("", "        calculationExpression-------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].calculationExpression);
PPT_METHODTRACE_V2("", "        dataValue-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataValue);
PPT_METHODTRACE_V2("", "        targetValue-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].targetValue);
PPT_METHODTRACE_V2("", "        specCheckResult-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].specCheckResult);
}
PPT_METHODTRACE_V2("", "      calculationRequiredFlag-------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].calculationRequiredFlag); //D9000001
PPT_METHODTRACE_V2("", "      specCheckRequiredFlag---------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].specCheckRequiredFlag); //D9000001
PPT_METHODTRACE_V2("", "      dataCollectionSpecificationID-------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionSpecificationID.identifier);
PPT_METHODTRACE_V2("", "      previousDataCollectionDefinitionID--", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousDataCollectionDefinitionID.identifier);
PPT_METHODTRACE_V2("", "      previousOperationID-----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousOperationID.identifier);
PPT_METHODTRACE_V2("", "      previousOperationNumber-------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousOperationNumber);
PPT_METHODTRACE_V2("", "  recipeParameterChangeType---------------", tg.strStartCassette[ii].strLotInCassette[jj].recipeParameterChangeType);
}
len3 = tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer.length();
PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer.length**********>", len3);
for(kk=0; kk < len3; kk++)
{
PPT_METHODTRACE_V2("", "    waferID-------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].waferID.identifier);
PPT_METHODTRACE_V2("", "    slotNumber----------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].slotNumber);
PPT_METHODTRACE_V2("", "    controlWaferFlag----------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].controlWaferFlag); //D9000001

len4 = tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter.length();
PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter.length**********>", len4);
for(ll=0; ll < len4; ll++)
{
PPT_METHODTRACE_V2("", "      parameterName-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].parameterName);
PPT_METHODTRACE_V2("", "      parameterValue----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].parameterValue);
PPT_METHODTRACE_V2("", "      targetValue-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].targetValue);
PPT_METHODTRACE_V2("", "      useCurrentSettingValueFlag----------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].useCurrentSettingValueFlag); //D9000001
}
}
PPT_METHODTRACE_V2("", "  productID-------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].productID.identifier);
}
}
PPT_METHODTRACE_V1("", "P3100372 log end ******************************************");
}
//DSIV00000201 add end
