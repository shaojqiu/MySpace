#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/txArrivalCarrierCancelReq__090.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 10/29/07 18:22:53 [ 10/29/07 18:22:54 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: txArrivalCarrierCancelReq__090.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

#include <unistd.h>

// Class: PPTManager
//
// Service: txArrivalCarrierCancelReq__090
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/07/18 D4000028 K.Takikita     Initial Release (R40)
// 2001/09/07 D4000060 K.Kido         Add retry TCS request logic
// 2001/09/17 D4000028(1) T.Yamamoto  Add equipmentID:NULL case for double LoadReq error case
// 2001/10/11 D4000348    T.Yamamoto  Add cassetteCount:0 case, return error
// 2001/10/30 P4000402 S.Tokumasu     Disable clear condition for disp load carrier
// 10/22/04 D6000025 K.Murakami       eBroker Migration.
// 2005/09/09 D6000418 M.Murata       Lock Port Object.
// 2006/07/20 P7000350 K.Matsuei      NPWReserveCancel is not performed correctly.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// ------------------------------------------------------------------------------
// 2007/06/20 D9000005 K.Kido         Intitial release for Wafer Sorter automation (AAS support).
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/11/29 DSN000049350 F.Chen         Equipment parallel processing support (P2)
//
//---------- ------------ -------------- -------------------------------------------
//
//
//D4000028(1)
//  case of equipmentID is null                                                                                  D4000028(1)
//    clear FRCAST DISPACHED_RESERVE Flag to OFF & FRCAST NPWLoadPurposeType to NULL.                            D4000028(1)
//    ( Not to clear Equipment PORT Information)                                                                 D4000028(1)
//                                                                                                               D4000028(1)
//     For LoadReq sequence error : Before LoadComp, If LoadReq recieved, Eqp.Port Info is cleared.              D4000028(1)
//                                  but Casette Disp. reserve remain & NPW LoadPurp.Type is filled.              D4000028(1)
//                                  So EqpID is NULL in this TX, clear Cassette Disp.Reserve & NPWLoadPurp.Type  D4000028(1)
//                                                                                                               D4000028(1)
//  ------------------------------------------------------------------------------------------------------------ D4000028(1)
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptArrivalCarrierCancelReqResult&       strArrivalCarrierCancelReqResult
//     const pptObjCommonIn&                   strObjCommonIn
//     const objectIdentifier&                 equipmentID
//     const char*                             portGroupID
//     const pptNPWXferCassetteSequence&       strNPWXferCassette
//     CORBA::Boolean                          notifyToTCSFlag
//     cosnt char*                             claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txArrivalCarrierCancelReq__090 (
    pptArrivalCarrierCancelReqResult__090& strArrivalCarrierCancelReqResult,
    const pptObjCommonIn&                  strObjCommonIn,
    const objectIdentifier&                equipmentID,
    const char *                           portGroupID,
    const pptNPWXferCassetteSequence&      strNPWXferCassette,
    CORBA::Boolean                         notifyToTCSFlag,
    const char *                           claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txArrivalCarrierCancelReq__090 ")

    CORBA::Long rc = RC_OK ;

    CORBA::Long nStrNPWCassetteLen = strNPWXferCassette.length() ;         //4000348
                                                                           //4000348
    if( nStrNPWCassetteLen == 0 )                                          //4000348
    {                                                                      //4000348
        PPT_METHODTRACE_V1("", "strNPWXferCassette.length is 0"); //4000348
        SET_MSG_RC(strArrivalCarrierCancelReqResult,MSG_INVALID_INPUT_PARM,RC_INVALID_INPUT_PARM);//4000348
        return( RC_INVALID_INPUT_PARM );                                   //4000348
    }                                                                      //4000348

    //D4000028(1) Add Start
    if ( 0 == CIMFWStrLen( equipmentID.identifier ) )
    {

        PPT_METHODTRACE_V1("", "equipmentID is nil");

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Object Lock Process                                                 */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        PPT_METHODTRACE_V1("", "Object Lock Process" );
        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
        PPT_METHODTRACE_V1("", "Lock objects to be updated" );
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out , strObjCommonIn , equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock() != RC_OK" );
            strArrivalCarrierCancelReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }

        CORBA::Long i = 0;
        CORBA::Long j = 0;
//4000348  CORBA::Long nStrNPWCassetteLen = strNPWXferCassette.length() ;

        for ( i=0 ; i< nStrNPWCassetteLen ; i++ )
        {
            PPT_METHODTRACE_V2("", "PPTNPWCassette Len" ,i);

            rc = object_Lock( strObject_Lock_out , strObjCommonIn ,strNPWXferCassette[i].cassetteID, SP_ClassName_PosCassette );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strObject_Lock_out.strResult;
               return( rc );
            }
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Check Process                                                       */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        PPT_METHODTRACE_V1("", "Check Process" );

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Process for Cassette                                          */
        /*                                                                       */
        /*   The following conditions are checked by this object                 */
        /*                                                                       */
        /*   - dispatchState should be TRUE.                                     */
        /*   - controlJobID should be blank'.                                    */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Check Process for Cassette" );
        objCassette_CheckConditionForArrivalCarrierCancel_out   strCassette_CheckConditionForArrivalCarrierCancel_out;
        rc = cassette_CheckConditionForArrivalCarrierCancel( strCassette_CheckConditionForArrivalCarrierCancel_out ,
                                                             strObjCommonIn,
                                                             strNPWXferCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_CheckConditionForArrivalCarrierCancel() != RC_OK" );
            strArrivalCarrierCancelReqResult.strResult = strCassette_CheckConditionForArrivalCarrierCancel_out.strResult ;
            return( rc );
        }

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Process for Lot                                               */
        /*                                                                       */
        /*   The following conditions are checked by this object                 */
        /*   - Omit Empty cassette.                                              */
        /*   - lotProcessState should not be InProcessing.                       */
        /*   - controlJobID should be blank.                                     */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
        objectIdentifier controlJobID;

        /*-----------------------------------------------------------*/
        /*   Make strStartCassetteSequence from strNPWXferCassette   */
        /*-----------------------------------------------------------*/
        pptStartCassetteSequence          strStartCassetteSequence;
        strStartCassetteSequence.length(nStrNPWCassetteLen);

        for( i = 0 ; i < nStrNPWCassetteLen ; i++ )
        {
            strStartCassetteSequence[i].loadSequenceNumber = strNPWXferCassette[i].loadSequenceNumber ;
            strStartCassetteSequence[i].cassetteID         = strNPWXferCassette[i].cassetteID         ;
            strStartCassetteSequence[i].loadPurposeType    = strNPWXferCassette[i].loadPurposeType    ;
            strStartCassetteSequence[i].loadPortID         = strNPWXferCassette[i].loadPortID         ;
            strStartCassetteSequence[i].unloadPortID       = strNPWXferCassette[i].unloadPortID       ;

        }

        PPT_METHODTRACE_V1("", "Check Process for Lot" );
        objLot_CheckConditionForArrivalCarrierCancel_out   strLot_CheckConditionForArrivalCarrierCancel_out;
        rc = lot_CheckConditionForArrivalCarrierCancel( strLot_CheckConditionForArrivalCarrierCancel_out,
                                                        strObjCommonIn,
                                                        controlJobID,
                                                        strStartCassetteSequence );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_CheckConditionForArrivalCarrierCancel() != RC_OK" );
            strArrivalCarrierCancelReqResult.strResult = strLot_CheckConditionForArrivalCarrierCancel_out.strResult ;
            return( rc );
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Main Process                                                        */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

        /*---------------------------------------------------*/
        /*                                                   */
        /*   Cassette Related Information Update Procedure   */
        /*                                                   */
        /*---------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Cassette Related Information Update Procedure" );

        for ( i=0 ; i< nStrNPWCassetteLen ; i++ )
        {

            PPT_METHODTRACE_V2("", "PPTStrNPWCassetteLen" ,i);

            /*-----------------------------------------------*/
            /*   Change Cassette's Dispatch State to FALSE   */
            /*-----------------------------------------------*/
            PPT_METHODTRACE_V1("", "Change Cassette's Dispatch State to FALSE");
            objCassette_dispatchState_Change_out   strCassette_dispatchState_Change_out;

            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out , strObjCommonIn ,strNPWXferCassette[i].cassetteID , FALSE );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_dispatchState_Change() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strCassette_dispatchState_Change_out.strResult ;
                return( rc );
            }

            /*--------------------------------------------------*/
            /*   Change Cassette's NPWLoadPurposeType to NULL   */
            /*--------------------------------------------------*/
            PPT_METHODTRACE_V1("", "Change Cassette's NPWLoadPurposeType to NULL" );

            objCassette_SetNPWLoadPurposeType_out   strCassette_SetNPWLoadPurposeType_out;
            rc = cassette_SetNPWLoadPurposeType( strCassette_SetNPWLoadPurposeType_out ,
                                                 strObjCommonIn,
                                                 strNPWXferCassette[i].cassetteID,
                                                 NULL );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_SetNPWLoadPurposeType() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strCassette_SetNPWLoadPurposeType_out.strResult ;
                return( rc );
            }

        }

    } else {
    //D4000028(1) Add End

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Check TransactionID                                                 */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        PPT_METHODTRACE_V1("", "Check TransactionID" );

        objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
        rc = equipment_categoryVsTxID_CheckCombination(
                                    strEquipment_categoryVsTxID_CheckCombination_out,
                                    strObjCommonIn,
                                    equipmentID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_categoryVsTxID_CheckCombination() != RC_OK" );
            strArrivalCarrierCancelReqResult.strResult = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
            return( rc );
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Object Lock Process                                                 */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        PPT_METHODTRACE_V1("", "Object Lock Process" );

//DSN000049350 Add Start
        // Get required equipment lock mode
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXLGC015" ); // TxArrivalCarrierCancelReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strArrivalCarrierCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }
        
        objObject_Lock_out strObject_Lock_out;
        
        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );
        
        if (lockMode != SP_EQP_LOCK_MODE_WRITE)
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
            objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
            objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
            
            // Lock Equipment Main Object
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
            strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strArrivalCarrierCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
            /*--------------------------------*/
            /*   Lock objects to be updated   */
            /*--------------------------------*/
            PPT_METHODTRACE_V1("", "Lock objects to be updated" );
//DSN000049350            objObject_Lock_out strObject_Lock_out;
            rc = object_Lock( strObject_Lock_out , strObjCommonIn , equipmentID, SP_ClassName_PosMachine );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        } //DSN000049350

        CORBA::Long i = 0;
        CORBA::Long j = 0;
        CORBA::Long nStrNPWCassetteLen = strNPWXferCassette.length() ;

//D6000418 add start
        /*--------------------------------------------*/
        /*                                            */
        /*        Port Object Lock Process            */
        /*                                            */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("", "#### Port Object Lock ");
        /*--------------------------*/
        /*   Lock Port object (To)  */
        /*--------------------------*/
        /*--------------------------------------------------------*/
        /*   Get All Ports being in the same Port Group as ToPort */
        /*--------------------------------------------------------*/
        objPortResource_allPortsInSameGroup_Get_out strPortResource_allPortsInSameGroup_Get_out;
        rc = portResource_allPortsInSameGroup_Get( strPortResource_allPortsInSameGroup_Get_out,
                                                   strObjCommonIn,
                                                   equipmentID,
                                                   strNPWXferCassette[0].loadPortID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "portResource_allPortsInSameGroup_Get() rc != RC_OK", rc);
            strArrivalCarrierCancelReqResult.strResult = strPortResource_allPortsInSameGroup_Get_out.strResult;
            return( rc );
        }

        /*---------------------------------------------------------*/
        /* Lock All Ports being in the same Port Group as ToPort   */
        /*---------------------------------------------------------*/
        CORBA::Long lenToPort = strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        for ( CORBA::Long ii=0 ; ii < lenToPort ; ii++ )
        {
            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  equipmentID,
                                                  strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[ii].portID,
                                                  SP_ClassName_PosPortResource );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[ii].portID.identifier) ;
                strArrivalCarrierCancelReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "Locked port object(to)  : ", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[ii].portID.identifier) ;
        }

        /*--------------------------------*/
        /*   Lock Port object (From)      */
        /*--------------------------------*/
        for ( ii=0 ; ii<nStrNPWCassetteLen ; ii++ )
        {
            /*-----------------------------------*/
            /*  Check cassette transfer status   */
            /*-----------------------------------*/
            PPT_METHODTRACE_V1( "", "Check cassette transfer status");
            objCassette_transferState_Get_out strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                             strObjCommonIn,
                                             strNPWXferCassette[ii].cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "cassette_transferState_Get != RC_OK", rc);
                strArrivalCarrierCancelReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return( rc );
            }

            if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
            {
                PPT_METHODTRACE_V2( "", "Cassette's transferState == EI", strNPWXferCassette[ii].cassetteID.identifier);
                /*------------------------------------*/
                /*   Get Cassette Info in Equipment   */
                /*------------------------------------*/
                PPT_METHODTRACE_V1( "","Get Cassette Info in Equipment");
                objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
                rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                               strObjCommonIn,
                                               strNPWXferCassette[ii].cassetteID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
                    strArrivalCarrierCancelReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                    return( rc );
                }
                PPT_METHODTRACE_V2( "", "equipmentID == ", strCassette_equipmentID_Get_out.equipmentID.identifier);

                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                             strObjCommonIn,
                                             strCassette_equipmentID_Get_out.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "", "equipment_portInfo_Get != RC_OK", rc);
                    strArrivalCarrierCancelReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                    return( rc );
                }

                /*----------------------------------------------------------*/
                /*  Lock port object which has the specified cassette.      */
                /*----------------------------------------------------------*/
                CORBA::Long lenFromPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
                for ( CORBA::Long jj=0 ; jj < lenFromPort ; jj++ )
                {
                    if ( 0 == CIMFWStrCmp( strNPWXferCassette[ii].cassetteID.identifier,
                                           strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[jj].loadedCassetteID.identifier) )
                    {
                        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                              strObjCommonIn,
                                                              strCassette_equipmentID_Get_out.equipmentID,
                                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[jj].portID,
                                                              SP_ClassName_PosPortResource );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
                            strArrivalCarrierCancelReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                            return( rc );
                        }
                        PPT_METHODTRACE_V2("", "Locked port object(from)  : ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
                    }
                }// lenFromPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            }// 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn )
        }// scLen = strNPWXferCassette.length();
//D6000418 add end

        for ( i=0 ; i< nStrNPWCassetteLen ; i++ )
        {
            PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierNotificationReq", "PPTNPWCassette Len" ,i);

            rc = object_Lock( strObject_Lock_out , strObjCommonIn ,strNPWXferCassette[i].cassetteID, SP_ClassName_PosCassette );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strObject_Lock_out.strResult;
               return( rc );
            }
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Port Status Change Process    (To Equipment)                        */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        PPT_METHODTRACE_V1("", "Port Status Change Process    (To Equipment)" );
        for ( i=0 ; i< nStrNPWCassetteLen ; i++ )
        {
            PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierNotificationReq", "PPTNPWCassette Len" ,i);
//P7000350 start
            PPT_METHODTRACE_V2("", "loadSequenceNumber ..." ,strNPWXferCassette[i].loadSequenceNumber );
            PPT_METHODTRACE_V2("", "cassetteID ..........." ,strNPWXferCassette[i].cassetteID.identifier );
            PPT_METHODTRACE_V2("", "loadPurposeType ......" ,strNPWXferCassette[i].loadPurposeType );
            PPT_METHODTRACE_V2("", "loadPortID ..........." ,strNPWXferCassette[i].loadPortID.identifier );
            PPT_METHODTRACE_V2("", "unloadPortID ........." ,strNPWXferCassette[i].unloadPortID.identifier );
//P7000350 end

//P7000350            CORBA::Long basePGNo = 0;
            CORBA::Long basePGNo = -1; //P7000350

            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                         strObjCommonIn,
                                         equipmentID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_portInfo_Get() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                return( rc );
            }

            CORBA::Long lenPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();

            for ( CORBA::Long j=0 ; j<lenPortInfo ; j++ )
            {

                if ( 0 != CIMFWStrCmp( strNPWXferCassette[i].loadPortID.identifier,
                                       strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "strNPWXferCassette[i].loadPortID.identifier != strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier" );
                    continue;
                }

                if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
                {

    //D4000028(1)    if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq) ||
    //D4000028(1)         0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) )
    //D4000028(1) Add Start
//P4000402                    if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq) ||
//P4000402                         0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) ||
//P4000402                         0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_Unknown) )
    //D4000028(1) Add End
//P4000402                    {

                        /*------------------------*/
                        /*   change to Required   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1("", "change to Required" );

                        objectIdentifier dummyOI;
                        objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out ;
                        rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                             strObjCommonIn,
                                                             equipmentID,
                                                             strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                             SP_PortRsc_DispatchState_Required,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "equipment_dispatchState_Change() != RC_OK" );
                            strArrivalCarrierCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                            return( rc );
                        }
//P4000402                    }

                    basePGNo = j;
                    break;
                }
            }

            /*--------------------------*/
            /*   find Same Port Group   */
            /*--------------------------*/
            if ( 0 <= basePGNo ) //P7000350
            {                    //P7000350
                PPT_METHODTRACE_V2("", "0 <= basePGNo" ,basePGNo); //P7000350

                for ( j=0 ; j<lenPortInfo ; j++ )
                {

                    /*===== Omit Base Port =====*/
                    if ( j == basePGNo )
                    {
                        PPT_METHODTRACE_V2("", "Omit Base Port" ,j);
                        continue;
                    }
                    /*===== Omit Different Group's Port =====*/
                    if ( 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portGroup, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[basePGNo].portGroup) )
                    {
                        PPT_METHODTRACE_V1("", "Omit Different Group's Port Not Equal" );
                        continue;
                    }

                    /*===== Check portState =====*/
        //D4000028(1) if ( 0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq) &&
        //D4000028(1)      0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) )
        //D4000028(1) Add Start
                     if ( 0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq) &&
                          0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) &&
                          0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_Unknown) )
        //D4000028(1) Add End
                    {
                        PPT_METHODTRACE_V1("", "Omit Different Group's Port Not Equal" );
                        continue;
                    }

                    /*===== Check dispatchState =====*/
                    if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched ) ||
                         0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_NotDispatched ) )
                    {
                        PPT_METHODTRACE_V1("", "Check dispatchState" );

                        /*------------------------*/
                        /*   change to Required   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1("", "change to Required" );
                        objectIdentifier dummyOI;
                        objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out ;
                        rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                             strObjCommonIn,
                                                             equipmentID,
                                                             strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                             SP_PortRsc_DispatchState_Required,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI,
                                                             dummyOI );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "equipment_dispatchState_Change() != RC_OK" );
                            strArrivalCarrierCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                            return( rc );
                        }
                    }
                }
            } //P7000350
        }


        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Port Status Change Process    (From Equipment)                      */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        PPT_METHODTRACE_V1("", "Port Status Change Process" );

        for ( i=0 ; i< nStrNPWCassetteLen ; i++ )
        {
            PPT_METHODTRACE_V2("", "PPTNpwCassetteLen", i);
            /*-----------------------------------*/
            /*  Check cassette transfer status   */
            /*-----------------------------------*/
            PPT_METHODTRACE_V1("", "Check cassette transfer status" );

            objCassette_transferState_Get_out strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                             strObjCommonIn,
                                             strNPWXferCassette[i].cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_transferState_Get() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return( rc );
            }
            if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
            {
                PPT_METHODTRACE_V1("", "transferState = SP_TransState_EquipmentIn" );

                /*------------------------------------*/
                /*   Get Cassette Info in Equipment   */
                /*------------------------------------*/
                PPT_METHODTRACE_V1("", "Get Cassette Info in Equipment" );
                objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
                rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                               strObjCommonIn,
                                               strNPWXferCassette[i].cassetteID );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cassette_equipmentID_Get() != RC_OK" );
                    strArrivalCarrierCancelReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                    return( rc );
                }

                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                             strObjCommonIn,
                                             strCassette_equipmentID_Get_out.equipmentID );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "equipment_portInfo_Get() != RC_OK" );
                    strArrivalCarrierCancelReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                    return( rc );
                }


                CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
                for ( CORBA::Long j=0; j < lenEqpPort; j++ )
                {
                    PPT_METHODTRACE_V2("", "PptEqpPortStatus", j);
                    if ( 0 == CIMFWStrCmp( strNPWXferCassette[i].cassetteID.identifier,
                                           strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "cassetteID = loadedCassetteID");

                        if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) &&
                             0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
                        {
                            PPT_METHODTRACE_V1("", "portState = SP_PortRsc_PortState_UnloadReq && dispatchState = SP_PortRsc_DispatchState_Dispatched");

                            /*------------------------*/
                            /*   change to Required   */
                            /*------------------------*/
                            PPT_METHODTRACE_V1("", "change to Required");
                            objectIdentifier dummyOI;
                            objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out;
                            rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                                 strObjCommonIn,
                                                                 strCassette_equipmentID_Get_out.equipmentID,
                                                                 strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                                 SP_PortRsc_DispatchState_Required,
                                                                 dummyOI,
                                                                 dummyOI,
                                                                 dummyOI,
                                                                 dummyOI );

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "equipment_dispatchState_Change() != RC_OK" );
                                strArrivalCarrierCancelReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                                return( rc );
                            }
                        }
                    }
                }
            }
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Check Process                                                       */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        PPT_METHODTRACE_V1("", "Check Process" );

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Process for Cassette                                          */
        /*                                                                       */
        /*   The following conditions are checked by this object                 */
        /*                                                                       */
        /*   - dispatchState should be TRUE.                                     */
        /*   - controlJobID should be blank'.                                    */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Check Process for Cassette" );
        objCassette_CheckConditionForArrivalCarrierCancel_out   strCassette_CheckConditionForArrivalCarrierCancel_out;
        rc = cassette_CheckConditionForArrivalCarrierCancel( strCassette_CheckConditionForArrivalCarrierCancel_out ,
                                                             strObjCommonIn,
                                                             strNPWXferCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_CheckConditionForArrivalCarrierCancel() != RC_OK" );
            strArrivalCarrierCancelReqResult.strResult = strCassette_CheckConditionForArrivalCarrierCancel_out.strResult ;
            return( rc );
        }

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Process for Lot                                               */
        /*                                                                       */
        /*   The following conditions are checked by this object                 */
        /*   - Omit Empty cassette.                                              */
        /*   - lotProcessState should not be InProcessing.                       */
        /*   - controlJobID should be blank.                                     */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
        objectIdentifier controlJobID;

        /*-----------------------------------------------------------*/
        /*   Make strStartCassetteSequence from strNPWXferCassette   */
        /*-----------------------------------------------------------*/
        pptStartCassetteSequence          strStartCassetteSequence;
        strStartCassetteSequence.length(nStrNPWCassetteLen);

        for( i = 0 ; i < nStrNPWCassetteLen ; i++ )
        {
            strStartCassetteSequence[i].loadSequenceNumber = strNPWXferCassette[i].loadSequenceNumber ;
            strStartCassetteSequence[i].cassetteID         = strNPWXferCassette[i].cassetteID         ;
            strStartCassetteSequence[i].loadPurposeType    = strNPWXferCassette[i].loadPurposeType    ;
            strStartCassetteSequence[i].loadPortID         = strNPWXferCassette[i].loadPortID         ;
            strStartCassetteSequence[i].unloadPortID       = strNPWXferCassette[i].unloadPortID       ;

        }

        PPT_METHODTRACE_V1("", "Check Process for Lot" );
        objLot_CheckConditionForArrivalCarrierCancel_out   strLot_CheckConditionForArrivalCarrierCancel_out;
        rc = lot_CheckConditionForArrivalCarrierCancel( strLot_CheckConditionForArrivalCarrierCancel_out,
                                                        strObjCommonIn,
                                                        controlJobID,
                                                        strStartCassetteSequence );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_CheckConditionForArrivalCarrierCancel() != RC_OK" );
            strArrivalCarrierCancelReqResult.strResult = strLot_CheckConditionForArrivalCarrierCancel_out.strResult ;
            return( rc );
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Main Process                                                        */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

        /*---------------------------------------------------*/
        /*                                                   */
        /*   Cassette Related Information Update Procedure   */
        /*                                                   */
        /*---------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Cassette Related Information Update Procedure" );

        for ( i=0 ; i< nStrNPWCassetteLen ; i++ )
        {

            PPT_METHODTRACE_V2("", "PPTStrNPWCassetteLen" ,i);

            /*-----------------------------------------------*/
            /*   Change Cassette's Dispatch State to FALSE   */
            /*-----------------------------------------------*/
            PPT_METHODTRACE_V1("", "Change Cassette's Dispatch State to FALSE");
            objCassette_dispatchState_Change_out   strCassette_dispatchState_Change_out;

            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out , strObjCommonIn ,strNPWXferCassette[i].cassetteID , FALSE );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_dispatchState_Change() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strCassette_dispatchState_Change_out.strResult ;
                return( rc );
            }

            /*--------------------------------------------------*/
            /*   Change Cassette's NPWLoadPurposeType to NULL   */
            /*--------------------------------------------------*/
            PPT_METHODTRACE_V1("", "Change Cassette's NPWLoadPurposeType to NULL" );

            objCassette_SetNPWLoadPurposeType_out   strCassette_SetNPWLoadPurposeType_out;
            rc = cassette_SetNPWLoadPurposeType( strCassette_SetNPWLoadPurposeType_out ,
                                                 strObjCommonIn,
                                                 strNPWXferCassette[i].cassetteID,
                                                 NULL );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_SetNPWLoadPurposeType() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strCassette_SetNPWLoadPurposeType_out.strResult ;
                return( rc );
            }

        }


        /*------------------------------------------------------------------------*/
        /*                                                                        */
        /*   Send ArrivalCarrierCancelReq() to TCS Procedure                      */
        /*                                                                        */
        /*------------------------------------------------------------------------*/
        if( TRUE == notifyToTCSFlag )           //D9000005
        {                                       //D9000005
            PPT_METHODTRACE_V1("", "Send ArrivalCarrierCancelReq() to TCS Procedure" );
    //D4000060    objTCSMgr_SendArrivalCarrierCancelReq_out   strTCSMgr_SendArrivalCarrierCancelReq_out;
    //D4000060    rc = TCSMgr_SendArrivalCarrierCancelReq( strTCSMgr_SendArrivalCarrierCancelReq_out,
    //D4000060                                             strObjCommonIn,
    //D4000060                                             strObjCommonIn.strUser,
    //D4000060                                             equipmentID,
    //D4000060                                             portGroupID,
    //D4000060                                             strNPWXferCassette,
    //D4000060                                             claimMemo );
    //D4000060    if ( rc != RC_OK )
    //D4000060    {
    //D4000060        PPT_METHODTRACE_V1("", "TCSMgr_SendArrivalCarrierCancelReq() != RC_OK" );
    //D4000060        strArrivalCarrierCancelReqResult.strResult = strTCSMgr_SendArrivalCarrierCancelReq_out.strResult ;
    //D4000060        return( rc );
    //D4000060    }
    //D4000060 add start
            CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
            CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
            CORBA::Long sleepTimeValue;
            CORBA::Long retryCountValue;

            if (CIMFWStrLen(tmpSleepTimeValue) == 0)
            {
                sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
            }
            else
            {
//D9000001  sleepTimeValue = atol(tmpSleepTimeValue) ;
                sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
            }

            if (CIMFWStrLen(tmpRetryCountValue) == 0)
            {
                retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
            }
            else
            {
//D9000001  retryCountValue = atol(tmpRetryCountValue);
                retryCountValue = atoi(tmpRetryCountValue);    //D9000001
            }

            PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
            PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

            objTCSMgr_SendArrivalCarrierCancelReq_out   strTCSMgr_SendArrivalCarrierCancelReq_out;

            //'retryCountValue + 1' means first try plus retry count
            for( i = 0 ; i < (retryCountValue + 1) ; i++)
            {
                /*--------------------------*/
                /*    Send Request to TCS   */
                /*--------------------------*/
                rc = TCSMgr_SendArrivalCarrierCancelReq( strTCSMgr_SendArrivalCarrierCancelReq_out,
                                                         strObjCommonIn,
                                                         strObjCommonIn.strUser,
                                                         equipmentID,
                                                         portGroupID,
                                                         strNPWXferCassette,
                                                         claimMemo );
                PPT_METHODTRACE_V2("","rc = ",rc);

                if(rc == RC_OK)
                {
                    PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                    break;
                }
                else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                          rc == RC_EXT_SERVER_NIL_OBJ   ||
                          rc == RC_TCS_NO_RESPONSE )
                {
                    PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
                    PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                    sleep(sleepTimeValue);
                    continue;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "TCSMgr_SendArrivalCarrierCancelReq() != RC_OK" );
                    strArrivalCarrierCancelReqResult.strResult = strTCSMgr_SendArrivalCarrierCancelReq_out.strResult ;
                    return( rc );
                }

            }

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "TCSMgr_SendArrivalCarrierCancelReq() != RC_OK" );
                strArrivalCarrierCancelReqResult.strResult = strTCSMgr_SendArrivalCarrierCancelReq_out.strResult ;
                return( rc );
            }
        }       //D9000005
    //D4000060 add end

    } //D4000028(1)  (end elseif equipmentID:NULL)

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/

    SET_MSG_RC(strArrivalCarrierCancelReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txArrivalCarrierCancelReq__090 ")
    return( RC_OK );
}

