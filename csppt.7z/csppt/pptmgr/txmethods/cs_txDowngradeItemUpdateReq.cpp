//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txDowngradeItemUpdateReq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txDowngradeItemUpdateReq()
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/24 INN-R170016  Yangxiaojun    Equipment Monitor customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csDowngradeItemUpdateReqResult& strDowngradeItemUpdateReqResult
//     const pptObjCommonIn& strObjCommonIn
//
//  typedef  pptBaseResult csDowngradeItemUpdateReqResult
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txDowngradeItemUpdateReq (csDowngradeItemUpdateReqResult&       strDowngradeItemUpdateReqResult,
                                                        const pptObjCommonIn&                   strObjCommonIn,
                                                        const csDowngradeItemUpdateReqInParm&   strDowngradeItemUpdateReqInParm,
                                                        const char*                             claimMemo
                                                        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txDowngradeItemUpdateReq")
    CORBA::Long rc = RC_OK;

    //---------------------------------------------
    // save DcItems to CSFSNPWDCDEF_ITEM
    //---------------------------------------------
    csObjDowngradeItemList_UpdateDR_in strDowngradeItemList_UpdateDR_in;
    strDowngradeItemList_UpdateDR_in.dcDefID = strDowngradeItemUpdateReqInParm.dcDefID;
    PPT_METHODTRACE_V2("", "strDowngradeItemList_UpdateDR_in.dcDefID", strDowngradeItemList_UpdateDR_in.dcDefID.identifier);
    strDowngradeItemList_UpdateDR_in.selectedDCItems = strDowngradeItemUpdateReqInParm.selectedDCItems;

    csObjDowngradeItemList_UpdateDR_out strDowngradeItemList_UpdateDR_out;
    rc = cs_downgradeItemList_UpdateDR( strDowngradeItemList_UpdateDR_out,
                               strObjCommonIn,
                               strDowngradeItemList_UpdateDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_downgradeItemList_UpdateDR() != RC_OK", rc);
        strDowngradeItemUpdateReqResult.strResult = strDowngradeItemList_UpdateDR_out.strResult;
        return rc;
    }
 
    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    SET_MSG_RC(strDowngradeItemUpdateReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txDowngradeItemUpdateReq")
    return( RC_OK );
}
