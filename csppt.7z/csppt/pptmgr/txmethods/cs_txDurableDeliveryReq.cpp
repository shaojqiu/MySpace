#ifndef lint
static char *sccsid =  "@(#) 1.8 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txDurableDeliveryReq.cpp, mm_srv_120e_ppt, mm_srv_120e_ppt 2/25/08 20:42:11 [ 2/25/08 20:42:13 ]";
#endif

//
//
// SiView
// Name: cs_txDurableDeliveryReq.cpp
//

#include "cs_pptmgr.hpp"
#include "pptconvert.h"
#include "pptconverter.h"

//
// PPT Service Manager - Transaction Method Design
//
//
// Subsystem Name      : PPT Service Manager
// TX Method ID        :
// TX Method Name      : cs_txDurableDeliveryReq
// Process Description : Auto Lot Selection & Xfer Req to XMS
//
// TX Generates Return Code and Message :
//
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/26 INN-R170003  Evie Su        Initial Release, copy from sorter_CheckConditionForJobCreate.cpp
//
//
//
CORBA::Long CS_PPTManager_i::cs_txDurableDeliveryReq(
    csDurableDeliveryReqResult& strDurableDeliveryReqResult,
    const pptObjCommonIn&       strObjCommonIn,
    const objectIdentifier&     equipmentID
    CORBAENV_LAST_CPP )
{
    /*----------------*/
    /*   Initialize   */
    /*----------------*/
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txDurableDeliveryReq @Delivery@");

    char strTrace[128];  //P4100480
    sprintf(strTrace, "DL@%s", (const char*)equipmentID.identifier);

    PPT_METHODTRACE_V2(strTrace, "InParam [equipmentID]", equipmentID.identifier);
    CORBA::Long rc = RC_OK;
    CORBA::Long i, j;

       //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
       //   Check Process
       //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
       PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

       objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
       rc = equipment_categoryVsTxID_CheckCombination(
                                   strEquipment_categoryVsTxID_CheckCombination_out,
                                   strObjCommonIn,
                                   equipmentID);
       if ( rc != RC_OK )
       {
           PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

           strDurableDeliveryReqResult.strResult
               = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
           return( rc );
       }

       PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


       /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
       /*                                                                       */
       /*   Check Process                                                       */
       /*                                                                       */
       /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       PPT_METHODTRACE_V1(strTrace, "Get Equipment Infomation");
       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       /*--------------------------------*/
       /*   Get Equipment Infomation     */
       /*--------------------------------*/
       pptEqpInfoInqResult__160 strEqpInfoInqResult;

       strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag  = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.reticleUseFlag              = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.fixtureUseFlag              = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.cassetteChangeFlag          = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.startLotsNotifyRequiredFlag = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.monitorCreationFlag         = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.eqpToEqpTransferFlag        = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.takeInOutTransferFlag       = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.emptyCassetteRequireFlag    = FALSE;
       strEqpInfoInqResult.equipmentBRInfo.SLMCapabilityFlag           = FALSE;

       rc = txEqpInfoInq__160( strEqpInfoInqResult, strObjCommonIn,
                               equipmentID,
                               TRUE,    //requestFlagForBRInfo
                               TRUE,    //requestFlagForStatusInfo
                               FALSE,   //requestFlagForPMInfo
                               TRUE,    //requestFlagForPortInfo
                               FALSE,   //requestFlagForChamberInfo
                               FALSE,   //requestFlagForStockerInfo
                               FALSE,   //requestFlagForInprocessingLotInfo
                               FALSE,   //requestFlagForReservedControlJobInfo
                               FALSE,   //requestFlagForRSPPortInfo
                               FALSE ); //requestFlagEqpContainerInfo

       if(rc != RC_OK)
       {
           PPT_METHODTRACE_V2("", "txEqpInfoInq__160() != RC_OK", rc);
           strDurableDeliveryReqResult.strResult = strEqpInfoInqResult.strResult;
           return (rc);
       }

       PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


       /*------------------------------------------*/
       /*   Check Online Mode and Available Flag   */
       /*------------------------------------------*/
       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       PPT_METHODTRACE_V1(strTrace, "Check Online Mode and Available Flag");
       PPT_METHODTRACE_V1(strTrace, "***************************************************************");

       CORBA::Long nILen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length();
       PPT_METHODTRACE_V2(strTrace, "strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length", nILen);
       for ( i=0; i < nILen; i++ )
       {
           PPT_METHODTRACE_V2(strTrace, "-------------------------------------------------------------round[i]", i);
           PPT_METHODTRACE_V2(strTrace, "portID...............", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portID.identifier);
           PPT_METHODTRACE_V2(strTrace, "portGroup............", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup);
           PPT_METHODTRACE_V2(strTrace, "loadSequenceNumber...", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].loadSequenceNumber);
           PPT_METHODTRACE_V2(strTrace, "loadPurposeType......", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].loadPurposeType);
           PPT_METHODTRACE_V2(strTrace, "portState............", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portState);
           PPT_METHODTRACE_V2(strTrace, "operationMode........", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].operationMode);
           PPT_METHODTRACE_V2(strTrace, "onlineMode...........", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode);
           PPT_METHODTRACE_V2(strTrace, "dispatchMode.........", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].dispatchMode);
           PPT_METHODTRACE_V2(strTrace, "accessMode...........", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].accessMode);
           PPT_METHODTRACE_V1(strTrace, "");

           if ( 0 == CIMFWStrCmp(strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode, SP_Eqp_OnlineMode_Offline) )
           {
               PPT_METHODTRACE_V1(strTrace, "##### onlineMode == [Offline]");
               PPT_SET_MSG_RC_KEY2( strDurableDeliveryReqResult, MSG_INVALID_EQP_MODE, RC_INVALID_EQP_MODE,
                                    equipmentID.identifier,
                                    strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode );
               return RC_INVALID_EQP_MODE;
           }
           else
           {
               PPT_METHODTRACE_V2(strTrace, "onlineMode is OK", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].onlineMode);
           }
       }

       CORBA::String_var takeOutXferInNotAvailableState = CIMFWStrDup(getenv(SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE));
       PPT_METHODTRACE_V2("","takeOutXferInNotAvailableState",takeOutXferInNotAvailableState);

       PPT_METHODTRACE_V2(strTrace, "equipmentAvailableFlag", (CORBA::Long)strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag);
       if ( TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag && 0 != CIMFWStrCmp(takeOutXferInNotAvailableState, "1") )
       {
           PPT_METHODTRACE_V1(strTrace, "##### TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag");
           PPT_SET_MSG_RC_KEY2( strDurableDeliveryReqResult, MSG_INVALID_EQP_STAT, RC_INVALID_EQP_STAT,
                               equipmentID.identifier, "NotAvailable" );
           return RC_INVALID_EQP_STAT;
       }
       PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       PPT_METHODTRACE_V1(strTrace, "Sorting Port Group Info by Port Group");
       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       /*-------------------------------------------*/
       /*   Sorting Port Group Info by Port Group   */
       /*-------------------------------------------*/
       objEquipment_portInfo_SortByGroup_out strEquipment_portInfo_SortByGroup_out;
       rc = equipment_portInfo_SortByGroup( strEquipment_portInfo_SortByGroup_out,
                                            strObjCommonIn,
                                            equipmentID,
                                            strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus );
       if ( rc != RC_OK )
       {
           PPT_METHODTRACE_V1(strTrace, "##### equipment_portInfo_SortByGroup() rc != RC_OK");
           strDurableDeliveryReqResult.strResult = strEquipment_portInfo_SortByGroup_out.strResult;
           return( rc );
       }
       PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       PPT_METHODTRACE_V1(strTrace, "Pick Up Target Port");
       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       /*------------------------*/
       /*   Pick Up Target Port  */
       /*------------------------*/
       objEquipment_targetPort_Pickup_out strEquipment_targetPort_Pickup_out;

       strEquipment_targetPort_Pickup_out.whatsNextRequireFlag = FALSE;

       pptEqpBrInfo strEqpBrInfo;
       PPTConverter converter;
       converter.Convert120_to_080( strEqpInfoInqResult.equipmentBRInfo, strEqpBrInfo );

       rc = equipment_targetPort_Pickup( strEquipment_targetPort_Pickup_out,
                                         strObjCommonIn,
                                         strEquipment_portInfo_SortByGroup_out.strEqpPortInfoOrderByGroup,
                                         strEqpBrInfo,
                                         strEqpInfoInqResult.equipmentPortInfo );
       if ( rc != RC_OK )
       {
           PPT_METHODTRACE_V1(strTrace, "##### equipment_targetPort_Pickup() rc != RC_OK");
           strDurableDeliveryReqResult.strResult = strEquipment_targetPort_Pickup_out.strResult;
           return( rc );
       }
       PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

       //VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV       
       PPT_METHODTRACE_V1(strTrace, "VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
       CORBA::Long ii, jj, kk;
       CORBA::Long len1 = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup.length();
       PPT_METHODTRACE_V2(strTrace, "len1--->", len1);
       for (ii=0; ii < len1; ii++)
       {
           PPT_METHODTRACE_V2(strTrace, "portGroup--->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].portGroup);
           CORBA::Long len2 = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID.length();
           PPT_METHODTRACE_V2(strTrace, "len2--->", len2);
           for (jj=0; jj < len2; jj++)
           {
               PPT_METHODTRACE_V2(strTrace, "portID                   --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portID.identifier);
               PPT_METHODTRACE_V2(strTrace, "loadSequenceNoInPortGroup--->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].loadSequenceNoInPortGroup);
               PPT_METHODTRACE_V2(strTrace, "portUsage                --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portUsage);
               PPT_METHODTRACE_V2(strTrace, "usageType                --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].usageType);
               PPT_METHODTRACE_V2(strTrace, "loadPurposeType          --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].loadPurposeType);
               PPT_METHODTRACE_V2(strTrace, "portState                --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].portState);
               PPT_METHODTRACE_V2(strTrace, "cassetteID               --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].cassetteID.identifier);
               PPT_METHODTRACE_V2(strTrace, "dispatchState            --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchState);
               PPT_METHODTRACE_V2(strTrace, "dispatchState_TimeStamp  --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchState_TimeStamp);
               PPT_METHODTRACE_V2(strTrace, "dispatchLoadLotID        --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchLoadLotID.identifier);
               PPT_METHODTRACE_V2(strTrace, "dispatchLoadCassetteID   --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchLoadCassetteID.identifier);
               PPT_METHODTRACE_V2(strTrace, "dispatchUnloadLotID      --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchUnloadLotID.identifier);
               PPT_METHODTRACE_V2(strTrace, "dispatchUnloadCassetteID --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].dispatchUnloadCassetteID.identifier);
       
               CORBA::Long len3 = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].strLotInfoOnPort.length();
               PPT_METHODTRACE_V2(strTrace, "len3--->", len3);
               for (kk=0; kk < len3; kk++)
               {
                   PPT_METHODTRACE_V2(strTrace, "  lotID                  --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].strLotInfoOnPort[kk].lotID.identifier);
                   PPT_METHODTRACE_V2(strTrace, "  lotType                --->", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[ii].strPortID[jj].strLotInfoOnPort[kk].lotType);
               }
           }
       }
       PPT_METHODTRACE_V1(strTrace, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
       
       //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       PPT_METHODTRACE_V1(strTrace, "Check Target Port Count");
       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
       /*----------------------------*/
       /*   Check Target Port Count  */
       /*----------------------------*/
       CORBA::Long lenPortGroup = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup.length();
       PPT_METHODTRACE_V2(strTrace, "Target Port Group count--->", lenPortGroup);
       if ( 0 == lenPortGroup )
       {
           PPT_METHODTRACE_V1(strTrace, "##### 0 == lenPortGroup");
           SET_MSG_RC( strDurableDeliveryReqResult, MSG_NOT_FOUND_TARGET_PORT, RC_NOT_FOUND_TARGET_PORT);
           return RC_NOT_FOUND_TARGET_PORT;
       }
       PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


       /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
       /*                                                                       */
       /*   Main Process                                                        */
       /*                                                                       */
       /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

       objectIdentifier dummy;
       CORBA::Boolean bLoadReqFlag = TRUE;
       CORBA::Long nPortLen;

       PPT_METHODTRACE_V2(strTrace, "targetPortType", strEquipment_targetPort_Pickup_out.targetPortType);
       /*--------------------*/
       /*   Unload Request   */
       /*--------------------*/
       if ( 0 == CIMFWStrCmp(strEquipment_targetPort_Pickup_out.targetPortType, SP_PortRsc_PortState_UnloadReq) )
       {
           PPT_METHODTRACE_V1(strTrace, "");
           PPT_METHODTRACE_V1(strTrace, "***************************************************************");
           PPT_METHODTRACE_V1(strTrace, "Unload Request");
           PPT_METHODTRACE_V1(strTrace, "***************************************************************");

           bLoadReqFlag = FALSE;

           PPT_METHODTRACE_V1(strTrace, "***************************************************************");
           PPT_METHODTRACE_V1(strTrace, "Check Durable Process State");
           PPT_METHODTRACE_V1(strTrace, "***************************************************************");

           /*-----------------------------*/
           /*   Check Durable State       */
           /*-----------------------------*/
           PPT_METHODTRACE_V2(strTrace, "TergetPort [PortGroupID]", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].portGroup);

           nPortLen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length();
           PPT_METHODTRACE_V2(strTrace, "strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length", nPortLen);
           for ( i=0; i < nPortLen; i++ )
           {
               PPT_METHODTRACE_V2(strTrace, "EqpInfo [PortGroupID]", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup);

               // check is targetPortInfo only
               if ( 0 == CIMFWStrCmp(strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].portGroup,
                                     strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup) )
               {
                   PPT_METHODTRACE_V1(strTrace, "TergetPortGropuID == EqpInfoPortGroupID");

                   CORBA::Long nLotOnPortLen = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].strLotOnPort.length();
                   PPT_METHODTRACE_V2(strTrace, "nLotOnPortLen--->", nLotOnPortLen);

                   PPT_METHODTRACE_V2(strTrace, "EqpInfo [loadedCassetteID]", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].loadedCassetteID.identifier);
                   
                   objDurable_state_Get_in strDurable_state_Get_in;
                   strDurable_state_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
                   strDurable_state_Get_in.durableID       = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].loadedCassetteID;
                   
                   objDurable_state_Get_out strDurable_state_Get_out;
                   rc = durable_state_Get( strDurable_state_Get_out,
                                           strObjCommonIn,
                                           strDurable_state_Get_in );
                   
                   if ( rc != RC_OK )
                   {
                       PPT_METHODTRACE_V1(strTrace, "##### durable_state_Get() rc != RC_OK");
                       strDurableDeliveryReqResult.strResult = strDurable_state_Get_out.strResult;
                       return( rc );
                   }
                   
                   PPT_METHODTRACE_V2(strTrace, "durableState", strDurable_state_Get_out.durableState);
                   
                   if ( 0 == CIMFWStrCmp(strDurable_state_Get_out.durableState, SP_DRBL_STATE_AVAILABLE) )
                   {
                       PPT_METHODTRACE_V1(strTrace, "strDurable_state_Get_out.durableState == SP_DRBL_STATE_AVAILABLE");
                       PPT_METHODTRACE_V1(strTrace, "##### Cancel UnloadReq #####");
                       bLoadReqFlag = TRUE;        // Cancel UnloadReq
                       break;
                   }
               }
               else
               {
                   PPT_METHODTRACE_V2(strTrace, "NoCheck ignore [PortGropuID]", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup);
               }
           }
           PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

           // if ( bLoadReqFlag == FALSE )
           // {
           //     PPT_METHODTRACE_V1(strTrace, "bLoadReqFlag == FALSE");
           // 
           //     if ( TRUE == strEqpInfoInqResult.equipmentBRInfo.eqpToEqpTransferFlag )
           //     {
           //         PPT_METHODTRACE_V1(strTrace, "***************************************************************");
           //         PPT_METHODTRACE_V1(strTrace, "UnLoadReq Process RUN!!  EQP -> EQP");
           //         PPT_METHODTRACE_V1(strTrace, "***************************************************************");
           // 
           //         //CORBA::Long len1 = strWhatNextDurableListInqResult.strWhatNextDurableAttributes.length();
           //         //PPT_METHODTRACE_V2(strTrace, "strWhatNextDurableAttributes.length--->", len1);
           //         //durableIDs.length(len1);
           //         //for (CORBA::Long ii=0; ii < len1; ii++)
           //         //{
           //         //    PPT_METHODTRACE_V2(strTrace, "  ==> [count]", ii);
           //         //    PPT_METHODTRACE_V2(strTrace, "  ==> durableID ", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].durableID.identifier);
           //         //}
           //         
           //         /*------------------------------*/
           //         /*   get whereNextTransferEqp   */
           //         /*------------------------------*/
           //         objectIdentifierSequence durableIDs;
           //         
           //         PPT_METHODTRACE_V1(strTrace, "get whereNextTransferEqp");
           //         objWhereNextTransferEqp_out_struct strWhereNextTransferEqp_struct_out;
           //         rc = whereNextTransferEqp( strWhereNextTransferEqp_struct_out,
           //                                    strObjCommonIn,
           //                                    equipmentID,
           //                                    strEquipment_targetPort_Pickup_out );
           // 
           //         if (rc == RC_OK)
           //         {
           //             PPT_METHODTRACE_V1(strTrace, "whereNextTransferEqp() rc == RC_OK");
           // 
           //             PPT_METHODTRACE_V2(strTrace, "whereNextTransferEqp [equipmentID] --->", strWhereNextTransferEqp_struct_out.equipmentID.identifier);
           //             PPT_METHODTRACE_V2(strTrace, "whereNextTransferEqp [portGroup] ----->", strWhereNextTransferEqp_struct_out.portGroup);
           //             
           //             CORBA::Long lnLenCast = strWhereNextTransferEqp_struct_out.strStartCassette.length();
           //             durableIDs.length(lnLenCast);
           //             for( ii=0; ii<lnLenCast; ii++ )
           //             {
           //                 PPT_METHODTRACE_V2(strTrace, "whereNextTransferEqp [cassetteID] -------->", strWhereNextTransferEqp_struct_out.strStartCassette[ii].cassetteID.identifier );
           //                 PPT_METHODTRACE_V2(strTrace, "whereNextTransferEqp [loadPurposeType] --->", strWhereNextTransferEqp_struct_out.strStartCassette[ii].loadPurposeType );
           //                 PPT_METHODTRACE_V2(strTrace, "whereNextTransferEqp [loadPortID] -------->", strWhereNextTransferEqp_struct_out.strStartCassette[ii].loadPortID.identifier );
           //                 PPT_METHODTRACE_V2(strTrace, "whereNextTransferEqp [unloadPortID] ------>", strWhereNextTransferEqp_struct_out.strStartCassette[ii].unloadPortID.identifier );
           //                 
           //                 durableIDs[ii] = strWhereNextTransferEqp_struct_out.strStartCassette[ii].cassetteID;
           //             }                       
           //             
           //             // call txDurablesInfoForStartReservationInq
           //             pptDurablesInfoForStartReservationInqInParam strDurablesInfoForStartReservationInqInParam;
           //             strDurablesInfoForStartReservationInqInParam.equipmentID     = strWhereNextTransferEqp_struct_out.equipmentID;
           //             strDurablesInfoForStartReservationInqInParam.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
           //             strDurablesInfoForStartReservationInqInParam.durableIDs      = durableIDs;                       
           // 
           //             pptDurablesInfoForStartReservationInqResult strDurablesInfoForStartReservationInqResult;
           //             rc = txDurablesInfoForStartReservationInq( strDurablesInfoForStartReservationInqResult,
           //                                                        strObjCommonIn,
           //                                                        strDurablesInfoForStartReservationInqInParam );
           // 
           //             PPT_METHODTRACE_V1(strTrace, "VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
           //             CORBA::Long ii, jj, kk;
           //             CORBA::Long len1 = strDurablesInfoForStartReservationInqResult.strStartDurables.length();
           //             PPT_METHODTRACE_V2(strTrace, "strStartDurables.length--->", len1);
           //             for (ii=0; ii < len1; ii++)
           //             {
           //                 PPT_METHODTRACE_V1(strTrace, "  ----------");
           //                 PPT_METHODTRACE_V2(strTrace, "  durableID --->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].durableID.identifier);
           //                 
           //                 PPT_METHODTRACE_V2(strTrace, "  loadPurposeType ------>", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.loadPurposeType);
           //                 PPT_METHODTRACE_V2(strTrace, "  loadPortID ----------->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.loadPortID.identifier);
           //                 PPT_METHODTRACE_V2(strTrace, "  loadSequenceNumber --->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.loadSequenceNumber);
           //                 PPT_METHODTRACE_V2(strTrace, "  unloadPortID --------->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.unloadPortID.identifier);
           //                 PPT_METHODTRACE_V2(strTrace, "  unloadSequenceNumber ->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.unloadSequenceNumber);
           //                 
           //                 PPT_METHODTRACE_V2(strTrace, "  routeID -------------->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartOperationInfo.routeID.identifier);
           //                 PPT_METHODTRACE_V2(strTrace, "  operationID ---------->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartOperationInfo.operationID.identifier);
           //                 PPT_METHODTRACE_V2(strTrace, "  loadSequenceNumber --->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartOperationInfo.operationNumber);
           //                 PPT_METHODTRACE_V2(strTrace, "  passCount ------------>", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartOperationInfo.passCount);
           //             }
           //             
           //             PPT_METHODTRACE_V1(strTrace, "strDurableStartRecipe :");
           //             PPT_METHODTRACE_V2(strTrace, "  logicalRecipeID  ---->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.logicalRecipeID.identifier);
           //             PPT_METHODTRACE_V2(strTrace, "  machineRecipeID  ---->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.machineRecipeID.identifier);
           //             PPT_METHODTRACE_V2(strTrace, "  physicalRecipeID ---->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.physicalRecipeID);
           //             PPT_METHODTRACE_V2(strTrace, "  parameterUpdateFlag ->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.parameterUpdateFlag);
           //             PPT_METHODTRACE_V1(strTrace, "  strStartRecipeParameter ----->" );
           //             CORBA::Long len2 = strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter.length();
           //             PPT_METHODTRACE_V2(strTrace, "  strStartRecipeParameter.length() --->", len2);
           //             PPT_METHODTRACE_V1(strTrace, "  ----------");
           //             
           //             PPT_METHODTRACE_V2(strTrace, "  parameterName --------------->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter[ii].parameterName);
           //             PPT_METHODTRACE_V2(strTrace, "  parameterValue -------------->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter[ii].parameterValue);
           //             PPT_METHODTRACE_V2(strTrace, "  targetValue ----------------->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter[ii].targetValue);
           //             PPT_METHODTRACE_V2(strTrace, "  useCurrentSettingValueFlag -->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter[ii].useCurrentSettingValueFlag);
           //             PPT_METHODTRACE_V1(strTrace, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
           // 
           //             /*--------------------------------------*/
           //             /*   Request to Start Lot Reservation   */
           //             /*--------------------------------------*/
           //             PPT_METHODTRACE_V1(strTrace, "// Request to Start Lot Reservation");
           //             objectIdentifier dummy;
           // 
           //             // Change TransactionID                       
           //             pptStartDurablesReservationReqInParam strStartDurablesReservationReqInParam;
           //             strStartDurablesReservationReqInParam.equipmentID           = strWhereNextTransferEqp_struct_out.equipmentID;
           //             strStartDurablesReservationReqInParam.durableCategory       = CIMFWStrDup(SP_DurableCat_Cassette);
           //             strStartDurablesReservationReqInParam.strStartDurables      = strDurablesInfoForStartReservationInqResult.strStartDurables;
           //             strStartDurablesReservationReqInParam.strDurableStartRecipe = strDurablesInfoForStartReservationInqResult.strDurableStartRecipe;
           //             
           //             pptObjCommonIn strTmpObjCommonIn;
           //             strTmpObjCommonIn = strObjCommonIn;
           //             strTmpObjCommonIn.transactionID = CIMFWStrDup("TXPDC040");    
           //             pptStartDurablesReservationReqResult strStartDurablesReservationReqResult;
           //             rc = txStartDurablesReservationReq( strStartDurablesReservationReqResult,
           //                                                 strTmpObjCommonIn,
           //                                                 strStartDurablesReservationReqInParam,
           //                                                 "" );
           // 
           //             if (rc == RC_OK)
           //             {
           //                 PPT_METHODTRACE_V1(strTrace, "txStartDurablesReservationReq() == RC_OK");
           // 
           //                 /*------------------------------------------*/
           //                 /*   Make txMultiCarrierXferReq parameter   */
           //                 /*------------------------------------------*/
           //                 PPT_METHODTRACE_V1(strTrace, "// Make txMultiCarrierXferReq parameter");
           //                 objMultiCarrierXferFillInTXLGC012InParm_out strMultiCarrierXferFillInTXLGC012InParm_out;
           //                 rc = multiCarrierXferFillInTXLGC012InParm( strMultiCarrierXferFillInTXLGC012InParm_out,
           //                                                            strObjCommonIn,
           //                                                            strWhereNextTransferEqp_struct_out.equipmentID,
           //                                                            strWhereNextTransferEqp_struct_out.strStartCassette );
           // 
           //                 if ( rc != RC_OK )
           //                 {
           //                     PPT_METHODTRACE_V1(strTrace, "##### multiCarrierXferFillInTXLGC012InParm() rc != RC_OK");
           //                     strDurableDeliveryReqResult.strResult = strMultiCarrierXferFillInTXLGC012InParm_out.strResult;
           // 
           //                     PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------*/");
           //                     PPT_METHODTRACE_V1(strTrace, "/*   Request to Start Lot Reservation Cancel   */");
           //                     PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------*/");
           // 
           //                     CORBA::Long saveRC = rc;
           //                     /*---------------------------------------------*/
           //                     /*   Request to Start Lot Reservation Cancel   */
           //                     /*---------------------------------------------*/
           //                     pptStartDurablesReservationCancelReqInParam strStartDurablesReservationCancelReqInParam;
           //                     strStartDurablesReservationCancelReqInParam.equipmentID         = strWhereNextTransferEqp_struct_out.equipmentID;
           //                     strStartDurablesReservationCancelReqInParam.durableControlJobID = strStartDurablesReservationReqResult.durableControlJobID;
           //                     
           //                     pptStartDurablesReservationCancelReqResult strStartDurablesReservationCancelReqResult;
           //                     rc = txStartDurablesReservationCancelReq ( strStartDurablesReservationCancelReqResult,
           //                                                                strObjCommonIn,
           //                                                                strStartDurablesReservationCancelReqInParam,
           //                                                                "" );
           //                                                            
           //                     if ( rc != RC_OK )
           //                     {
           //                         PPT_METHODTRACE_V1(strTrace, "txStartDurablesReservationCancelReq != RC_OK");
           //                     }
           // 
           //                     rc = saveRC;
           //                     return( rc );
           //                 }
           // 
           //                 PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------*/");
           //                 PPT_METHODTRACE_V1(strTrace, "/*   Send Transfer Request to XM. (EQP -> EQP)   */");
           //                 PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------*/");
           //                 /*-----------------------------------------------*/
           //                 /*   Send Transfer Request to XM. (EQP -> EQP)   */
           //                 /*-----------------------------------------------*/
           //                 pptMultiCarrierXferReqResult strMultiCarrierXferReqResult;
           //                 rc = txMultiCarrierXferReq( strMultiCarrierXferReqResult,
           //                                             strObjCommonIn,
           //                                             FALSE,        // const : FALSE
           //                                             "S",          // const : "S"
           //                                             strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq );
           //                  
           //                 if ( rc != RC_OK )
           //                 {
           //                     PPT_METHODTRACE_V1(strTrace, "##### txMultiCarrierXferReq() rc != RC_OK");
           //                     strDurableDeliveryReqResult.strResult = strMultiCarrierXferReqResult.strResult;
           // 
           //                     //-------------------------------------------------------
           //                     // Prepare e-mail Message Text
           //                     //-------------------------------------------------------
           //                     CORBA::String_var msg;
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Transfer Error!  (EQP -> EQP) >>>" );
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
           //                     PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
           // 
           //                     CORBA::Long ii, jj;
           //                     CORBA::Long lenCarrierXfer = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq.length();
           //                     for ( ii=0; ii < lenCarrierXfer; ii++ )
           //                     {
           //                         PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
           //                         PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
           //                         PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].carrierID.identifier );
           //                         PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
           //                         PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].lotID.identifier );
           //                         PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
           //                         PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].fromMachineID.identifier );
           //                         PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
           //                         PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].fromPortID.identifier );
           //                         PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
           //                         PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].toStockerGroup );
           // 
           //                         CORBA::Long lenToEqp = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine.length();
           //                         if ( 0 == lenToEqp )
           //                         {
           //                                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
           //                         }
           //                         for ( jj=0; jj < lenToEqp; jj++ )
           //                         {
           //                             PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
           //                             PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine[jj].toMachineID.identifier );
           //                             PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
           //                             PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine[jj].toPortID.identifier );
           //                         }
           //                     }
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
           //                     PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.transactionID );
           //                     PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.returnCode );
           //                     PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.messageID );
           //                     PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.messageText );
           //                     PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
           //                     PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.reasonText );
           // 
           //                     PPT_METHODTRACE_V2("", "messageText--->", msg);
           // 
           //                     /*------------------------*/
           //                     /*   Set System Message   */
           //                     /*------------------------*/
           //                     PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
           //                     PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   txMultiCarrierXferReq() != RC_OK   */");
           //                     PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
           // 
           //                     csSysMsgDurableInfo sysMsg;
           //                     sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
           //                     sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
           //                     sysMsg.systemMessageText      = CIMFWStrDup( msg );
           //                     sysMsg.notifyFlag             = TRUE;
           //                     sysMsg.equipmentID            = equipmentID;
           //                     sysMsg.equipmentStatus        = CIMFWStrDup("");
           //                     sysMsg.stockerID              = dummy;
           //                     sysMsg.stockerStatus          = CIMFWStrDup("");
           //                     sysMsg.AGVID                  = dummy;
           //                     sysMsg.AGVStatus              = CIMFWStrDup("");
           //                     sysMsg.lotID                  = dummy;
           //                     sysMsg.lotStatus              = CIMFWStrDup("");
           //                     sysMsg.routeID                = dummy;
           //                     sysMsg.operationID            = dummy;
           //                     sysMsg.operationNumber        = CIMFWStrDup("");
           //                     sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
           // 
           //                     CORBA::Long lenSysMsg = strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length();
           //                     strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length( lenSysMsg+1 );
           //                     strDurableDeliveryReqResult.strSysMsgDurableInfoSeq[lenSysMsg] = sysMsg;
           // 
           //                     PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------*/");
           //                     PPT_METHODTRACE_V1(strTrace, "/*   Request to Start Lot Reservation Cancel   */");
           //                     PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------*/");
           // 
           //                     CORBA::Long saveRC = rc;
           //                     /*-------------------------------------------------*/
           //                     /*   Request to Start Durable Reservation Cancel   */
           //                     /*-------------------------------------------------*/
           //                     pptStartDurablesReservationCancelReqInParam strStartDurablesReservationCancelReqInParam;
           //                     strStartDurablesReservationCancelReqInParam.equipmentID         = strWhereNextTransferEqp_struct_out.equipmentID;
           //                     strStartDurablesReservationCancelReqInParam.durableControlJobID = strStartDurablesReservationReqResult.durableControlJobID;
           //                     
           //                     pptStartDurablesReservationCancelReqResult strStartDurablesReservationCancelReqResult;
           //                     rc = txStartDurablesReservationCancelReq ( strStartDurablesReservationCancelReqResult,
           //                                                                strObjCommonIn,
           //                                                                strStartDurablesReservationCancelReqInParam,
           //                                                                "" );
           //                     if ( rc != RC_OK )
           //                     {
           //                         PPT_METHODTRACE_V1(strTrace, "txStartLotsReservationCancelReq != RC_OK");
           //                     }
           // 
           //                     rc = saveRC;
           //                     return( rc );
           //                 }
           // 
           //                 /*--------------------*/
           //                 /*   Return to Main   */
           //                 /*--------------------*/
           //                 PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
           //                 PPT_METHODTRACE_V1(strTrace, "@@@@@ OK! OK! OK! [EQP to EQP]  Return to Main");
           //                 PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
           // 
           //                 SET_MSG_RC(strDurableDeliveryReqResult, MSG_OK, RC_OK);
           //                 return RC_OK;
           //             }
           //             else
           //             {
           //                 PPT_METHODTRACE_V1(strTrace, "##### txStartDurablesReservationReq() rc != RC_OK");
           //                 strDurableDeliveryReqResult.strResult = strStartDurablesReservationReqResult.strResult;
           // 
           //                 //---------------------------------------------------------------------------------------------
           //                 //  Prepare message text string for case of failure of start durable reservation.
           //                 //  If start durable reservation for equipment is fail, this messageText is filled.
           //                 //---------------------------------------------------------------------------------------------
           //                 PPT_METHODTRACE_V1(strTrace, "### Prepare e-mail Message Text");
           // 
           //                 //-------------------------------------------------------
           //                 // Prepare e-mail Message Text
           //                 //-------------------------------------------------------
           //                 CORBA::String_var msg;
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< StartDurablesReservation Error!  (EQP -> EQP) >>>" );
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
           //                 PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhereNextTransferEqp_struct_out.equipmentID.identifier );
           //                 PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot IDs              : " );
           // 
           //                 CORBA::Boolean bLotSet = FALSE;
           //                 CORBA::Long nCastCnt = strWhereNextTransferEqp_struct_out.strStartCassette.length();
           //                 for ( i=0; i < nCastCnt; i++ )
           //                 {
           //                     if (CIMFWStrLen(strWhereNextTransferEqp_struct_out.strStartCassette[i].cassetteID.identifier) != 0)
           //                     {
           //                         if ( TRUE == bLotSet )
           //                         {
           //                             PPT_STRDUPCAT_STRING( FALSE, msg, msg, ", " );
           //                         }
           //                         PPT_STRDUPCAT_STRING( FALSE, msg, msg, strWhereNextTransferEqp_struct_out.strStartCassette[i].cassetteID.identifier );
           //                         bLotSet = TRUE;
           //                     }
           //                 }
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
           //                 PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.transactionID );
           //                 PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.returnCode );
           //                 PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.messageID );
           //                 PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.messageText );
           //                 PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
           //                 PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.reasonText );
           // 
           //                 PPT_METHODTRACE_V2("", "messageText--->", msg);
           // 
           //                 csSysMsgDurableInfo sysMsg;
           //                 sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
           //                 sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
           //                 sysMsg.systemMessageText      = CIMFWStrDup( msg );
           //                 sysMsg.notifyFlag             = TRUE;
           //                 sysMsg.equipmentID            = equipmentID;
           //                 sysMsg.equipmentStatus        = CIMFWStrDup("");
           //                 sysMsg.stockerID              = dummy;
           //                 sysMsg.stockerStatus          = CIMFWStrDup("");
           //                 sysMsg.AGVID                  = dummy;
           //                 sysMsg.AGVStatus              = CIMFWStrDup("");
           //                 sysMsg.lotID                  = dummy;
           //                 sysMsg.lotStatus              = CIMFWStrDup("");
           //                 sysMsg.routeID                = dummy;
           //                 sysMsg.operationID            = dummy;
           //                 sysMsg.operationNumber        = CIMFWStrDup("");
           //                 sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
           // 
           //                 CORBA::Long lenSysMsg = strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length();
           //                 strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length( lenSysMsg+1 );
           //                 strDurableDeliveryReqResult.strSysMsgDurableInfoSeq[lenSysMsg] = sysMsg;
           // 
           //                 PPT_METHODTRACE_V2(strTrace, "return rc", rc);
           //                 strDurableDeliveryReqResult.strResult.reasonText = msg;
           //                 return ( rc );
           //             }
           //         }
           //     }
           // }

           if ( bLoadReqFlag == FALSE )
           {
               PPT_METHODTRACE_V1(strTrace, "***************************************************************");
               PPT_METHODTRACE_V1(strTrace, " UnLoadReq Process RUN!!");
               PPT_METHODTRACE_V1(strTrace, "***************************************************************");
               pptCarrierXferReqSequence tmpCarrierXferReqSeq;
               CORBA::ULong XferCnt = 0 ;

               CORBA::Long nILen = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID.length();
               for ( i=0; i < nILen; i++ )
               {
                   PPT_METHODTRACE_V2(strTrace, "Get Where Next Stocker [i]", i);
                   PPT_METHODTRACE_V2(strTrace, "cassetteID", strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID.identifier);

                   /*----------------------------*/
                   /*   Get Where Next Stocker   */
                   /*----------------------------*/
                   pptWhereNextInterBayInqResult strWhereNextInterBayInqResult;

                   PPT_METHODTRACE_V1(strTrace, "// Make txSingleCarrierXferReq parameter");
                   /*-------------------------------------------*/
                   /*   Make txSingleCarrierXferReq parameter   */
                   /*-------------------------------------------*/
                   objSingleCarrierXferFillInTXLGC013InParm_out strSingleCarrierXferFillInTXLGC013InParm_out;
                   rc = singleCarrierXferFillInTXLGC013InParm(
                               strSingleCarrierXferFillInTXLGC013InParm_out,
                               strObjCommonIn,
                               equipmentID,
                               strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].portID,
                               strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[0].strPortID[i].cassetteID,
                               strWhereNextInterBayInqResult );

                   if ( rc == RC_NO_XFER_NEEDED )
                   {
                       PPT_METHODTRACE_V1(strTrace, "No Transfer Job is requested by environment variable. Proceed to the Next Port...");
                       continue;
                   }
                   else if (rc == RC_NO_STOCKER_FOR_CURRENT_EQP)
                   {
                       PPT_METHODTRACE_V1(strTrace, "An Error is Detected. Proceed to the Next Port...");
                       //-------------------------------------------------------
                       // Prepare e-mail Message Text
                       //-------------------------------------------------------
                       CORBA::String_var msg;
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Transfer Error!  (EQP -> Stocker) >>>" );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup );

                       CORBA::Long jj;
                       CORBA::Long lenToEqp = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine.length();
                       if ( 0 == lenToEqp )
                       {
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
                       }
                       for ( jj=0; jj < lenToEqp; jj++ )
                       {
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[jj].toMachineID.identifier );
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[jj].toPortID.identifier );
                       }
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.transactionID );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.returnCode );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.messageID );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.messageText );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strResult.reasonText );

                       PPT_METHODTRACE_V2("", "messageText--->", msg);

                       /*------------------------*/
                       /*   Set System Message   */
                       /*------------------------*/
                       PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------------------------------------*/");
                       PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   singleCarrierXferFillInTXLGC013InParm) != RC_OK   */");
                       PPT_METHODTRACE_V1(strTrace, "/*---------------------------------------------------------------------------*/");

                       csSysMsgDurableInfo sysMsg;
                       sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                       sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                       sysMsg.systemMessageText      = CIMFWStrDup( msg );
                       sysMsg.notifyFlag             = TRUE;
                       sysMsg.equipmentID            = equipmentID;
                       sysMsg.equipmentStatus        = CIMFWStrDup("");
                       sysMsg.stockerID              = dummy;
                       sysMsg.stockerStatus          = CIMFWStrDup("");
                       sysMsg.AGVID                  = dummy;
                       sysMsg.AGVStatus              = CIMFWStrDup("");
                       sysMsg.lotID                  = dummy;
                       sysMsg.lotStatus              = CIMFWStrDup("");
                       sysMsg.routeID                = dummy;
                       sysMsg.operationID            = dummy;
                       sysMsg.operationNumber        = CIMFWStrDup("");
                       sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                       CORBA::Long lenSysMsg = strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length();
                       strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length( lenSysMsg+1 );
                       strDurableDeliveryReqResult.strSysMsgDurableInfoSeq[lenSysMsg] = sysMsg;
                       continue;
                   }
                   else if ( rc != RC_OK )
                   {
                       PPT_METHODTRACE_V1(strTrace, "##### singleCarrierXferFillInTXLGC013InParm() rc != RC_OK");
                       strDurableDeliveryReqResult.strResult = strSingleCarrierXferFillInTXLGC013InParm_out.strResult;
                       return( rc );
                   }

                   /*------------------------------------------------------*/
                   /*  Check whether specified machine is eqp or stocker   */
                   /*------------------------------------------------------*/
                   CORBA::Boolean isStorageFlag = FALSE ;
                   objEquipment_statusInfo_Get_out__090 strEquipment_statusInfo_GetDR_outForLock;
                   objEquipment_statusInfo_Get_in__090  strEquipment_statusInfo_Get_in;
                   strEquipment_statusInfo_Get_in.equipmentID = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID;
                   rc = equipment_statusInfo_Get__090( strEquipment_statusInfo_GetDR_outForLock,
                                                       strObjCommonIn,
                                                       strEquipment_statusInfo_Get_in);

                   if ( rc != RC_OK )
                   {
                       if ( rc == RC_NOT_FOUND_EQP )
                       {
                           isStorageFlag = TRUE;
                       }
                       else
                       {
                           PPT_METHODTRACE_V2("", "equipment_statusInfo_Get__090() rc != RC_OK", rc);
                           strDurableDeliveryReqResult.strResult = strEquipment_statusInfo_GetDR_outForLock.strResult;
                           return( rc );
                       }
                   }

                   PPT_METHODTRACE_V3("", "Equipment is Storage or not == ", strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID.identifier, isStorageFlag );

                   if ( FALSE == isStorageFlag )
                   {
                       /*--------------------------------------------*/
                       /* Lock Port object of machine                */
                       /*--------------------------------------------*/

                       objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                       rc = object_LockForEquipmentResource(strObject_LockForEquipmentResource_out,
                                                            strObjCommonIn,
                                                            strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID,
                                                            strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID,
                                                            SP_ClassName_PosPortResource );
                       if ( rc != RC_OK )
                       {
                           PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier );
                           strDurableDeliveryReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
                           return( rc );
                       }
                       PPT_METHODTRACE_V2("","Locked port object  :", strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier);

                       /*-----------------------------------------------------------------------------*/
                       /*                                                                             */
                       /*   Check Equipment Port for Sending Request to XM. (EQP -> Stocker)          */
                       /*                                                                             */
                       /*-----------------------------------------------------------------------------*/
                       objEquipment_portState_CheckForCassetteDelivery_out strEquipment_portState_CheckForCassetteDelivery_out;
                       objEquipment_portState_CheckForCassetteDelivery_in strEquipment_portState_CheckForCassetteDelivery_in;
                       strEquipment_portState_CheckForCassetteDelivery_in.equipmentID = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID;
                       strEquipment_portState_CheckForCassetteDelivery_in.portID      = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID;
                       rc = equipment_portState_CheckForCassetteDelivery(strEquipment_portState_CheckForCassetteDelivery_out,
                                                                         strObjCommonIn,
                                                                         strEquipment_portState_CheckForCassetteDelivery_in);
                       if ( rc != RC_OK )
                       {
                           PPT_METHODTRACE_V1( "", "equipment_portState_CheckForCassetteDelivery() != RC_OK" );
                           strDurableDeliveryReqResult.strResult = strEquipment_portState_CheckForCassetteDelivery_out.strResult;
                           return( rc );
                       }
                   }

                   PPT_METHODTRACE_V1(strTrace, "// Send Request to XM. (EQP -> Stocker)");
                   /*------------------------------------------*/
                   /*   Send Request to XM. (EQP -> Stocker)   */
                   /*------------------------------------------*/
                   pptSingleCarrierXferReqResult strSingleCarrierXferReqResult;
                   rc = txSingleCarrierXferReq( strSingleCarrierXferReqResult,
                                                strObjCommonIn,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.rerouteFlag,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.zoneType,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.n2PurgeFlag,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedStartTime,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedEndTime,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.mandatoryFlag,
                                                strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.priority );
                   if ( rc != RC_OK )
                   {
                       PPT_METHODTRACE_V1(strTrace, "##### txSingleCarrierXferReq() rc != RC_OK");
                       strDurableDeliveryReqResult.strResult = strSingleCarrierXferReqResult.strResult;

                       //-------------------------------------------------------
                       // Prepare e-mail Message Text
                       //-------------------------------------------------------
                       CORBA::String_var msg;
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Transfer Error!  (EQP -> Stocker) >>>" );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup );

                       CORBA::Long jj;
                       CORBA::Long lenToEqp = strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine.length();
                       if ( 0 == lenToEqp )
                       {
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
                       }
                       for ( jj=0; jj < lenToEqp; jj++ )
                       {
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[jj].toMachineID.identifier );
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine[jj].toPortID.identifier );
                       }
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.transactionID );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.returnCode );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.messageID );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.messageText );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strSingleCarrierXferReqResult.strResult.reasonText );

                       PPT_METHODTRACE_V2("", "messageText--->", msg);

                       /*------------------------*/
                       /*   Set System Message   */
                       /*------------------------*/
                       PPT_METHODTRACE_V1(strTrace, "/*-------------------------------------------------------------*/");
                       PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   txSingleCarrierXferReq() != RC_OK   */");
                       PPT_METHODTRACE_V1(strTrace, "/*-------------------------------------------------------------*/");

                       csSysMsgDurableInfo sysMsg;
                       sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                       sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                       sysMsg.systemMessageText      = CIMFWStrDup( msg );
                       sysMsg.notifyFlag             = TRUE;
                       sysMsg.equipmentID            = equipmentID;
                       sysMsg.equipmentStatus        = CIMFWStrDup("");
                       sysMsg.stockerID              = dummy;
                       sysMsg.stockerStatus          = CIMFWStrDup("");
                       sysMsg.AGVID                  = dummy;
                       sysMsg.AGVStatus              = CIMFWStrDup("");
                       sysMsg.lotID                  = dummy;
                       sysMsg.lotStatus              = CIMFWStrDup("");
                       sysMsg.routeID                = dummy;
                       sysMsg.operationID            = dummy;
                       sysMsg.operationNumber        = CIMFWStrDup("");
                       sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                       CORBA::Long lenSysMsg = strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length();
                       strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length( lenSysMsg+1 );
                       strDurableDeliveryReqResult.strSysMsgDurableInfoSeq[lenSysMsg] = sysMsg;

                       return( rc );
                   }
               }

               /*--------------------*/
               /*   End of Process   */
               /*--------------------*/
               bLoadReqFlag = FALSE;

               PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
               PPT_METHODTRACE_V1(strTrace, "@@@@@ OK! OK! OK! [EQP to Stocker]  Return to Main");
               PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
           }
       }

       if ( bLoadReqFlag == TRUE )
       {
           PPT_METHODTRACE_V1(strTrace, "bLoadReqFlag == TRUE");
           /*-----------------*/
           /*   Load Request  */
           /*-----------------*/
           if ( 0 == CIMFWStrCmp(strEquipment_targetPort_Pickup_out.targetPortType, SP_PortRsc_PortState_LoadReq) )
           {
               PPT_METHODTRACE_V1(strTrace, "***************************************************************");
               PPT_METHODTRACE_V1(strTrace, "Load Request");
               PPT_METHODTRACE_V1(strTrace, "***************************************************************");

               if ( TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag )
               {
                   PPT_METHODTRACE_V1(strTrace, "##### TRUE != strEqpInfoInqResult.equipmentStatusInfo.equipmentAvailableFlag");
                   PPT_SET_MSG_RC_KEY2( strDurableDeliveryReqResult, MSG_INVALID_EQP_STAT, RC_INVALID_EQP_STAT,
                                       equipmentID.identifier, "NotAvailable" );
                   return RC_INVALID_EQP_STAT;
               }


               PPT_METHODTRACE_V1(strTrace, "***************************************************************");
               PPT_METHODTRACE_V1(strTrace, "Get WIP Lots <<< txWhatNextLotListInq >>>");
               PPT_METHODTRACE_V1(strTrace, "***************************************************************");
               /*----------------------*/
               /*   Get WIP Durables   */
               /*----------------------*/
               pptWhatNextDurableListInqResult  strWhatNextDurableListInqResult;

               /*-------------------------------------------------*/
               /*   Call Normal Function (txWhatNextDurableListInq)   */
               /*-------------------------------------------------*/
               PPT_METHODTRACE_V1(strTrace, "/*--------------------------------------------------*/");
               PPT_METHODTRACE_V1(strTrace, "/*   Call Normal Function (txWhatNextDurableListInq)*/");
               PPT_METHODTRACE_V1(strTrace, "/*--------------------------------------------------*/");
               pptWhatNextDurableListInqInParam strWhatNextDurableListInqInParam;
               strWhatNextDurableListInqInParam.equipmentID     = equipmentID;
               strWhatNextDurableListInqInParam.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
               strWhatNextDurableListInqInParam.selectCriteria  = CIMFWStrDup(SP_DP_SelectCriteria_Auto3);
               
               rc = txWhatNextDurableListInq( strWhatNextDurableListInqResult,
                                              strObjCommonIn,
                                              strWhatNextDurableListInqInParam );                   
               if( rc != RC_OK )
               {
                   /*------------------------*/
                   /*   Set System Message   */
                   /*------------------------*/
                   PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------------------*/");
                   PPT_METHODTRACE_V1(strTrace, "/*   Set System Message. txWhatNextDurableListInq() != RC_OK */");
                   PPT_METHODTRACE_V1(strTrace, "/*-----------------------------------------------------------*/");
                   
                   CORBA::String_var msg;
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< WhatNext Error!  (Stocker -> EQP) >>>" );
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                   PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                   PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextDurableListInqResult.strResult.transactionID );
                   PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextDurableListInqResult.strResult.returnCode );
                   PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextDurableListInqResult.strResult.messageID );
                   PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextDurableListInqResult.strResult.messageText );
                   PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                   PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strWhatNextDurableListInqResult.strResult.reasonText );
                   
                   PPT_METHODTRACE_V2("", "messageText--->", msg);
                   
                   csSysMsgDurableInfo sysMsg;
                   sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                   sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                   sysMsg.systemMessageText      = CIMFWStrDup( msg );
                   sysMsg.notifyFlag             = TRUE;
                   sysMsg.equipmentID            = equipmentID;
                   sysMsg.equipmentStatus        = CIMFWStrDup("");
                   sysMsg.stockerID              = dummy;
                   sysMsg.stockerStatus          = CIMFWStrDup("");
                   sysMsg.AGVID                  = dummy;
                   sysMsg.AGVStatus              = CIMFWStrDup("");
                   sysMsg.lotID                  = dummy;
                   sysMsg.lotStatus              = CIMFWStrDup("");
                   sysMsg.routeID                = dummy;
                   sysMsg.operationID            = dummy;
                   sysMsg.operationNumber        = CIMFWStrDup("");
                   sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
                   
                   CORBA::Long lenSysMsg = strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length();
                   strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length( lenSysMsg+1 );
                   strDurableDeliveryReqResult.strSysMsgDurableInfoSeq[lenSysMsg] = sysMsg;

                   PPT_METHODTRACE_V1(strTrace, "##### txWhatNextDurableListInq() != RC_OK");
                   return( rc );
               }

               //dispaly
               {
                   PPT_METHODTRACE_V1(strTrace, "VVVVV txWhatNextDurableListInq VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
                   PPT_METHODTRACE_V2(strTrace, "equipmentID ------------------>", strWhatNextDurableListInqResult.equipmentID.identifier);
                   PPT_METHODTRACE_V2(strTrace, "equipmentCategory ------------>", strWhatNextDurableListInqResult.equipmentCategory);
                   PPT_METHODTRACE_V2(strTrace, "lastRecipeID ----------------->", strWhatNextDurableListInqResult.lastRecipeID.identifier);
                   PPT_METHODTRACE_V2(strTrace, "dispatchRule ----------------->", strWhatNextDurableListInqResult.dispatchRule);
                   PPT_METHODTRACE_V2(strTrace, "processRunSizeMaximum -------->", strWhatNextDurableListInqResult.processRunSizeMaximum);
                   PPT_METHODTRACE_V2(strTrace, "processRunSizeMinimum -------->", strWhatNextDurableListInqResult.processRunSizeMinimum);
               
                   CORBA::Long ii, jj, kk;
                   CORBA::Long len1 = strWhatNextDurableListInqResult.strWhatNextDurableAttributes.length();
                   PPT_METHODTRACE_V2(strTrace, "strWhatNextDurableAttributes.length--->", len1);
                   for (ii=0; ii < len1; ii++)
                   {
                       PPT_METHODTRACE_V2(strTrace, "--------------------------------------------------------------[count]", ii);
                       PPT_METHODTRACE_V2(strTrace, "  durableCategory ---------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].durableCategory);
                       PPT_METHODTRACE_V2(strTrace, "  durableID  --------------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].durableID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  transferStatus ----------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].transferStatus);
                       PPT_METHODTRACE_V2(strTrace, "  transferReserveUserID ---------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].transferReserveUserID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  stockerID ---------------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].stockerID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  equipmentID -------------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].equipmentID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  durableControlJob--------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].durableControlJob.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  processReserveEquipmentID ------------>", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].processReserveEquipmentID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  processReserveUserID ----------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].processReserveUserID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  recipeAvailableFlag ------------------>", (CORBA::Long)strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].recipeAvailableFlag);
                       PPT_METHODTRACE_V2(strTrace, "  logicalRecipeID ---------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].logicalRecipeID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  machineRecipeID ---------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].machineRecipeID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  physicalRecipeID --------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].physicalRecipeID);
                       PPT_METHODTRACE_V2(strTrace, "  lastClaimedTimeStamp ----------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].lastClaimedTimeStamp);
                       PPT_METHODTRACE_V2(strTrace, "  stateChangeTimeStamp ----------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].stateChangeTimeStamp);
                       PPT_METHODTRACE_V2(strTrace, "  stateChangeTimeStamp ----------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].stateChangeTimeStamp);
                       PPT_METHODTRACE_V2(strTrace, "  inventoryChangeTimeStamp ------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].inventoryChangeTimeStamp);
                       PPT_METHODTRACE_V2(strTrace, "  dueTimeStamp ------------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].dueTimeStamp);
                       PPT_METHODTRACE_V2(strTrace, "  testTypeID --------------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].testTypeID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  inspectionType ----------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].inspectionType);
                       PPT_METHODTRACE_V2(strTrace, "  next2EquipmentID --------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].next2EquipmentID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  next2LogicalRecipeID ----------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].next2LogicalRecipeID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  operableFlagForCurrentMachineState --->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].operableFlagForCurrentMachineState);
                       PPT_METHODTRACE_V2(strTrace, "  contentCategory ---------------------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].contentCategory);
                       PPT_METHODTRACE_V2(strTrace, "  inPostProcessFlagOfDurable ----------->", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].inPostProcessFlagOfDurable);;
                   }
                   PPT_METHODTRACE_V1(strTrace, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
               }
               
               CORBA::Long len1 = strWhatNextDurableListInqResult.strWhatNextDurableAttributes.length();
               PPT_METHODTRACE_V2(strTrace, "strWhatNextDurableAttributes.length--->", len1);
               
               objectIdentifierSequence durableIDs;
               durableIDs.length(len1);
               for (CORBA::Long ii=0; ii < len1; ii++)
               {
                   PPT_METHODTRACE_V2(strTrace, "  ==> [count]", ii);
                   PPT_METHODTRACE_V2(strTrace, "  ==> durableID ", strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].durableID.identifier);
                   durableIDs[ii] = strWhatNextDurableListInqResult.strWhatNextDurableAttributes[ii].durableID;
               }               
               
               PPT_METHODTRACE_V2(strTrace, "lenPortGroup", lenPortGroup);
               for ( i=0; i < lenPortGroup; i++ )
               {
                   PPT_METHODTRACE_V3(strTrace, "-----------------------------------round[i]", i,
                                       strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[i].portGroup);

                   pptPortGroupSequence strPortGroupSeq;
                   strPortGroupSeq.length(1);
                   strPortGroupSeq[0] = strEquipment_targetPort_Pickup_out.strEqpTargetPortInfo.strPortGroup[i];

                                        
                   PPT_METHODTRACE_V1(strTrace, "");
                   PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                   PPT_METHODTRACE_V1(strTrace, "Select Multiple Lots <<< txDurablesInfoForStartReservationInq >>>");
                   PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                   /*--------------------------*/
                   /*   Select Durable         */
                   /*--------------------------*/    
                   pptDurablesInfoForStartReservationInqInParam strDurablesInfoForStartReservationInqInParam;
                   strDurablesInfoForStartReservationInqInParam.equipmentID     = equipmentID;
                   strDurablesInfoForStartReservationInqInParam.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
                   strDurablesInfoForStartReservationInqInParam.durableIDs      = durableIDs;
    
                   pptDurablesInfoForStartReservationInqResult strDurablesInfoForStartReservationInqResult;
                   rc = txDurablesInfoForStartReservationInq( strDurablesInfoForStartReservationInqResult,
                                                              strObjCommonIn,
                                                              strDurablesInfoForStartReservationInqInParam );
                   if ( rc != RC_OK )
                   {
                       PPT_METHODTRACE_V2(strTrace, "txDurablesInfoForStartReservationInq() rc != RC_OK", rc);
                       if ( i == lenPortGroup - 1 )
                       {
                           PPT_METHODTRACE_V1(strTrace, "##### i is last loop. so return error.");
                           strDurableDeliveryReqResult.strResult = strDurablesInfoForStartReservationInqResult.strResult;
                           return( rc );
                       }
                       else
                       {
                           PPT_METHODTRACE_V1(strTrace, "continue next PortGroup!!");
                           continue;
                       }
                   }

                   //display
                   {
                       PPT_METHODTRACE_V1(strTrace, "VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
                       CORBA::Long ii, jj, kk;
                       CORBA::Long len1 = strDurablesInfoForStartReservationInqResult.strStartDurables.length();
                       PPT_METHODTRACE_V2(strTrace, "strStartDurables.length--->", len1);
                       for (ii=0; ii < len1; ii++)
                       {
                           PPT_METHODTRACE_V1(strTrace, "  ----------");
                           PPT_METHODTRACE_V2(strTrace, "  durableID --->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].durableID.identifier);
                           
                           PPT_METHODTRACE_V2(strTrace, "  loadPurposeType ------>", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.loadPurposeType);
                           PPT_METHODTRACE_V2(strTrace, "  loadPortID ----------->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.loadPortID.identifier);
                           PPT_METHODTRACE_V2(strTrace, "  loadSequenceNumber --->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.loadSequenceNumber);
                           PPT_METHODTRACE_V2(strTrace, "  unloadPortID --------->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.unloadPortID.identifier);
                           PPT_METHODTRACE_V2(strTrace, "  unloadSequenceNumber ->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartDurablePort.unloadSequenceNumber);
                           
                           PPT_METHODTRACE_V2(strTrace, "  routeID -------------->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartOperationInfo.routeID.identifier);
                           PPT_METHODTRACE_V2(strTrace, "  operationID ---------->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartOperationInfo.operationID.identifier);
                           PPT_METHODTRACE_V2(strTrace, "  loadSequenceNumber --->", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartOperationInfo.operationNumber);
                           PPT_METHODTRACE_V2(strTrace, "  passCount ------------>", strDurablesInfoForStartReservationInqResult.strStartDurables[ii].strStartOperationInfo.passCount);
                       }
                       
                       PPT_METHODTRACE_V1(strTrace, "strDurableStartRecipe :");
                       PPT_METHODTRACE_V2(strTrace, "  logicalRecipeID  ---->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.logicalRecipeID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  machineRecipeID  ---->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.machineRecipeID.identifier);
                       PPT_METHODTRACE_V2(strTrace, "  physicalRecipeID ---->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.physicalRecipeID);
                       PPT_METHODTRACE_V2(strTrace, "  parameterUpdateFlag ->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.parameterUpdateFlag);
                       PPT_METHODTRACE_V1(strTrace, "  strStartRecipeParameter ----->" );
                       CORBA::Long len2 = strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter.length();
                       PPT_METHODTRACE_V2(strTrace, "  strStartRecipeParameter.length() --->", len2);
                       PPT_METHODTRACE_V1(strTrace, "  ----------");
                    
                       PPT_METHODTRACE_V2(strTrace, "  parameterName --------------->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter[ii].parameterName);
                       PPT_METHODTRACE_V2(strTrace, "  parameterValue -------------->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter[ii].parameterValue);
                       PPT_METHODTRACE_V2(strTrace, "  targetValue ----------------->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter[ii].targetValue);
                       PPT_METHODTRACE_V2(strTrace, "  useCurrentSettingValueFlag -->", strDurablesInfoForStartReservationInqResult.strDurableStartRecipe.strStartRecipeParameter[ii].useCurrentSettingValueFlag);
                       PPT_METHODTRACE_V1(strTrace, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                   }
         
         
                   PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                   PPT_METHODTRACE_V1(strTrace, "Request to Start Durable Reservation");
                   PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                   /*--------------------------------------*/
                   /*   Request to Start Durable Reservation   */
                   /*--------------------------------------*/
                   objectIdentifier dummy;
                   pptStartDurable       strStartDurable;
                   pptDurableStartRecipe strDurableStartRecipe;
                   
                   pptStartDurablesReservationReqInParam strStartDurablesReservationReqInParam;
                   strStartDurablesReservationReqInParam.equipmentID           = equipmentID;
                   strStartDurablesReservationReqInParam.durableCategory       = CIMFWStrDup(SP_DurableCat_Cassette);
                   strStartDurablesReservationReqInParam.strStartDurables      = strDurablesInfoForStartReservationInqResult.strStartDurables;
                   strStartDurablesReservationReqInParam.strDurableStartRecipe = strDurablesInfoForStartReservationInqResult.strDurableStartRecipe;
                   
                   // Change TransactionID
                   pptObjCommonIn strTmpObjCommonIn;
                   strTmpObjCommonIn = strObjCommonIn;
                   strTmpObjCommonIn.transactionID = CIMFWStrDup("TXPDC040");  // TransactionID of TxStartDurablesReservationRe
                   pptStartDurablesReservationReqResult strStartDurablesReservationReqResult;
                   rc = txStartDurablesReservationReq( strStartDurablesReservationReqResult,
                                                       strTmpObjCommonIn,
                                                       strStartDurablesReservationReqInParam,
                                                       "" );

                   if ( rc != RC_OK )
                   {
                       PPT_METHODTRACE_V1(strTrace, "txStartDurablesReservationReq() rc != RC_OK");
                       strDurableDeliveryReqResult.strResult = strStartDurablesReservationReqResult.strResult;

                       //---------------------------------------------------------------------------------------------
                       //  Prepare message text string for case of failure of start lot reservation
                       //  Only if start lot resercatioin for current equipment is fail, this messageText is filled
                       //---------------------------------------------------------------------------------------------
                       PPT_METHODTRACE_V1(strTrace, "### Prepare e-mail Message Text");

                       //-------------------------------------------------------
                       // Prepare e-mail Message Text
                       //-------------------------------------------------------
                       CORBA::String_var msg;
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< StartLotsReservation Error!  (Stocker -> EQP) >>>" );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot IDs              : " );

                       CORBA::Boolean bFirstSet = FALSE;
                       // CORBA::Long nCasLen = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette.length();
                       // for ( i=0; i < nCasLen; i++ )
                       // {
                       //     CORBA::Long nLotLen = strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette.length();
                       //     for ( j=0; j < nLotLen; j++ )
                       //     {
                       //         if (CIMFWStrLen(strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette[j].lotID.identifier) != 0)
                       //         {
                       //             if ( TRUE == bFirstSet )
                       //             {
                       //                 PPT_STRDUPCAT_STRING( FALSE, msg, msg, ", " );
                       //             }
                       //             PPT_STRDUPCAT_STRING( FALSE, msg, msg, strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette[i].strLotInCassette[j].lotID.identifier );
                       //             bFirstSet = TRUE;
                       //         }
                       //     }
                       // }
                       PPT_STRDUPCAT_STRING( TRUE, msg, msg, "" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.transactionID );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.returnCode );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.messageID );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.messageText );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strStartDurablesReservationReqResult.strResult.reasonText );

                       PPT_METHODTRACE_V2("", "messageText--->", msg);
                       csSysMsgDurableInfo sysMsg;
                       sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                       sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                       sysMsg.systemMessageText      = CIMFWStrDup( msg );
                       sysMsg.notifyFlag             = TRUE;
                       sysMsg.equipmentID            = equipmentID;
                       sysMsg.equipmentStatus        = CIMFWStrDup("");
                       sysMsg.stockerID              = dummy;
                       sysMsg.stockerStatus          = CIMFWStrDup("");
                       sysMsg.AGVID                  = dummy;
                       sysMsg.AGVStatus              = CIMFWStrDup("");
                       sysMsg.lotID                  = dummy;
                       sysMsg.lotStatus              = CIMFWStrDup("");
                       sysMsg.routeID                = dummy;
                       sysMsg.operationID            = dummy;
                       sysMsg.operationNumber        = CIMFWStrDup("");
                       sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                       CORBA::Long lenSysMsg = strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length();
                       strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length( lenSysMsg+1 );
                       strDurableDeliveryReqResult.strSysMsgDurableInfoSeq[lenSysMsg] = sysMsg;

                       PPT_METHODTRACE_V2(strTrace, "return rc", rc);
                       strDurableDeliveryReqResult.strResult.reasonText = msg;
                       return ( rc );
                   }

                   PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                   PPT_METHODTRACE_V1(strTrace, "Make txMultiCarrierXferReq parameter");
                   PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                   /*------------------------------------------*/
                   /*   Make txMultiCarrierXferReq parameter   */
                   /*------------------------------------------*/
                   pptStartCassetteSequence    strStartCassette;
                   objMultiCarrierXferFillInTXLGC012InParm_out strMultiCarrierXferFillInTXLGC012InParm_out;
                   rc = multiCarrierXferFillInTXLGC012InParm( strMultiCarrierXferFillInTXLGC012InParm_out,
                                                              strObjCommonIn,
                                                              equipmentID,
                                                              strStartCassette ); //strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette );
                   if ( rc != RC_OK )
                   {
                       PPT_METHODTRACE_V1(strTrace, "multiCarrierXferFillInTXLGC012InParm() rc != RC_OK");
                       strDurableDeliveryReqResult.strResult = strMultiCarrierXferFillInTXLGC012InParm_out.strResult;

                       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                       PPT_METHODTRACE_V1(strTrace, "Request to Start Lot Reservation Cancel");
                       PPT_METHODTRACE_V1(strTrace, "***************************************************************");

                       CORBA::Long saveRC = rc;
                       /*---------------------------------------------*/
                       /*   Request to Start Lot Reservation Cancel   */
                       /*---------------------------------------------*/
                       pptStartDurablesReservationCancelReqInParam strStartDurablesReservationCancelReqInParam;
                       strStartDurablesReservationCancelReqInParam.equipmentID         = equipmentID;
                       strStartDurablesReservationCancelReqInParam.durableControlJobID = strStartDurablesReservationReqResult.durableControlJobID;
                       
                       pptStartDurablesReservationCancelReqResult strStartDurablesReservationCancelReqResult;
                       rc = txStartDurablesReservationCancelReq ( strStartDurablesReservationCancelReqResult,
                                                                  strObjCommonIn,
                                                                  strStartDurablesReservationCancelReqInParam,
                                                                  "" );                       

                       if ( rc != RC_OK )
                       {
                           PPT_METHODTRACE_V1(strTrace, "txStartLotsReservationCancelReq != RC_OK");
                       }

                       rc = saveRC;
                       return rc;
                   }

                   CORBA::Boolean bReRouteFlg = FALSE;
                   CORBA::String_var reRouteXferFlag = CIMFWStrDup(getenv(SP_REROUTE_XFER_FLAG));
                   PPT_METHODTRACE_V2("","SP_REROUTE_XFER_FLAG ---> ",reRouteXferFlag);
                   if ( 0 == CIMFWStrCmp(reRouteXferFlag, "1") )
                   {
                       PPT_METHODTRACE_V1("","reRouteXferFlag is 1");
                       bReRouteFlg = TRUE;
                   }

                   PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                   PPT_METHODTRACE_V1(strTrace, "Send Transfer Request to XM. (Stocker -> EQP)");
                   PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                   /*---------------------------------------------------*/
                   /*   Send Transfer Request to XM. (Stocker -> EQP)   */
                   /*---------------------------------------------------*/
                   pptMultiCarrierXferReqResult strMultiCarrierXferReqResult;
                   rc = txMultiCarrierXferReq( strMultiCarrierXferReqResult,
                                               strObjCommonIn,
                                               bReRouteFlg,
                                               "S",
                                               strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq );
                   if ( rc != RC_OK )
                   {
                       PPT_METHODTRACE_V1(strTrace, "txMultiCarrierXferReq() rc != RC_OK");
                       strDurableDeliveryReqResult.strResult = strMultiCarrierXferReqResult.strResult;

                       //-------------------------------------------------------
                       // Prepare e-mail Message Text
                       //-------------------------------------------------------
                       CORBA::String_var msg;
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Transfer Error!  (Stocker -> EQP) >>>" );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );

                       CORBA::Long ii, jj;
                       CORBA::Long lenCarrierXfer = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq.length();
                       for ( ii=0; ii < lenCarrierXfer; ii++ )
                       {
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "carrier ID           : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].carrierID.identifier );
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].lotID.identifier );
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Machine ID      : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].fromMachineID.identifier );
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].fromPortID.identifier );
                           PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Stocker Group     : " );
                           PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].toStockerGroup );

                           CORBA::Long lenToEqp = strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine.length();
                           if ( 0 == lenToEqp )
                           {
                               PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "To Machine ID        : Nothing" );
                           }
                           for ( jj=0; jj < lenToEqp; jj++ )
                           {
                               PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Machine ID        : " );
                               PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine[jj].toMachineID.identifier );
                               PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
                               PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq[ii].strToMachine[jj].toPortID.identifier );
                           }
                       }
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "-----------------------------------------" );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.transactionID );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.returnCode );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.messageID );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.messageText );
                       PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
                       PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strMultiCarrierXferReqResult.strResult.reasonText );

                       PPT_METHODTRACE_V2("", "messageText--->", msg);

                       /*------------------------*/
                       /*   Set System Message   */
                       /*------------------------*/
                       PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");
                       PPT_METHODTRACE_V1(strTrace, "/*   Set System Message.   txMultiCarrierXferReq() != RC_OK   */");
                       PPT_METHODTRACE_V1(strTrace, "/*------------------------------------------------------------*/");

                       csSysMsgDurableInfo sysMsg;
                       sysMsg.subSystemID            = CIMFWStrDup( SP_SubSystemID_MM );
                       sysMsg.systemMessageCode      = CIMFWStrDup( SP_SystemMsgCode_DeliveryError );
                       sysMsg.systemMessageText      = CIMFWStrDup( msg );
                       sysMsg.notifyFlag             = TRUE;
                       sysMsg.equipmentID            = equipmentID;
                       sysMsg.equipmentStatus        = CIMFWStrDup("");
                       sysMsg.stockerID              = dummy;
                       sysMsg.stockerStatus          = CIMFWStrDup("");
                       sysMsg.AGVID                  = dummy;
                       sysMsg.AGVStatus              = CIMFWStrDup("");
                       sysMsg.lotID                  = dummy;
                       sysMsg.lotStatus              = CIMFWStrDup("");
                       sysMsg.routeID                = dummy;
                       sysMsg.operationID            = dummy;
                       sysMsg.operationNumber        = CIMFWStrDup("");
                       sysMsg.systemMessageTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

                       CORBA::Long lenSysMsg = strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length();
                       strDurableDeliveryReqResult.strSysMsgDurableInfoSeq.length( lenSysMsg+1 );
                       strDurableDeliveryReqResult.strSysMsgDurableInfoSeq[lenSysMsg] = sysMsg;

                       PPT_METHODTRACE_V1(strTrace, "***************************************************************");
                       PPT_METHODTRACE_V1(strTrace, "Request to Start Lot Reservation Cancel");
                       PPT_METHODTRACE_V1(strTrace, "***************************************************************");

                       CORBA::Long saveRC = rc;
                       /*---------------------------------------------*/
                       /*   Request to Start Lot Reservation Cancel   */
                       /*---------------------------------------------*/
                       pptStartDurablesReservationCancelReqInParam strStartDurablesReservationCancelReqInParam;
                       strStartDurablesReservationCancelReqInParam.equipmentID         = equipmentID;
                       strStartDurablesReservationCancelReqInParam.durableControlJobID = strStartDurablesReservationReqResult.durableControlJobID;
                       
                       pptStartDurablesReservationCancelReqResult strStartDurablesReservationCancelReqResult;
                       rc = txStartDurablesReservationCancelReq ( strStartDurablesReservationCancelReqResult,
                                                                  strObjCommonIn,
                                                                  strStartDurablesReservationCancelReqInParam,
                                                                  "" );
                       if ( rc != RC_OK )
                       {
                           PPT_METHODTRACE_V1(strTrace, "txStartDurablesReservationCancelReq != RC_OK");
                       }

                       rc = saveRC;
                       return rc;
                   }

                   /*--------------------*/
                   /*   End of Process   */
                   /*--------------------*/
                   PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                   PPT_METHODTRACE_V1(strTrace, "@@@@@ OK! OK! OK! [Stocker to EQP]  Return to Main");
                   PPT_METHODTRACE_V1(strTrace, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                   break;
               }
           }
       }

    /*--------------------*/
    /*                    */
    /*   Return to Main   */
    /*                    */
    /*--------------------*/
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txDurableDeliveryReq");

    SET_MSG_RC(strDurableDeliveryReqResult, MSG_OK, RC_OK);
    return RC_OK;
}
