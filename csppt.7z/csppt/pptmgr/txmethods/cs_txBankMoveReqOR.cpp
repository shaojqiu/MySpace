#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/txBankMoveReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:13:07 [ 7/13/07 21:13:08 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: txBankMoveReq.cpp
//

//INN-R170017 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"  //INN-R170017

// Class: PPTManager
//
// Service: txBankMoveReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/09/12 P3000139 O.Sugiyama     add SET_MSG_RC
// 2000/09/18 P3000139 T.Yamano       add SET_MSG_RC
// 2001/08/13 P3300061 K.Kido         Set return structure in sequence
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/31 DSIV00000214 S.Miyata       Multi Fab Transfer Support
//
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/26 INN-R170017  Evie Su        add BWS logic, reject if lot/wafer in BWS or has sorter job
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptBankMoveReqResult& strBankMoveReqResult
//     const pptObjCommonIn& strObjCommonIn
//     CORBA::Long seqIx
//     const objectIdentifierSequence& lotIDs
//     const objectIdentifier& toBankID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//D6000025 CORBA::Long PPTManager_i::txBankMoveReq (pptBankMoveReqResult& strBankMoveReqResult, const pptObjCommonIn& strObjCommonIn, CORBA::Long seqIx, const objectIdentifierSequence& lotIDs,  const objectIdentifier& toBankID,  const char * claimMemo, CORBA::Environment &IT_env)
//INN-R170017 CORBA::Long PPTManager_i::txBankMoveReq (pptBankMoveReqResult& strBankMoveReqResult, const pptObjCommonIn& strObjCommonIn, CORBA::Long seqIx, const objectIdentifierSequence& lotIDs,  const objectIdentifier& toBankID,  const char * claimMemo CORBAENV_LAST_CPP) //D6000025
CORBA::Long CS_PPTManager_i::txBankMoveReq (pptBankMoveReqResult& strBankMoveReqResult, const pptObjCommonIn& strObjCommonIn, CORBA::Long seqIx, const objectIdentifierSequence& lotIDs,  const objectIdentifier& toBankID,  const char * claimMemo CORBAENV_LAST_CPP) //INN-R170017
{
    //INN-R170017 PPT_METHODTRACE_ENTRY("PPTManager_i::txBankMoveReq ")
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txBankMoveReq ")   //INN-R170017

    CORBA::Long rc = RC_OK ;

    /*------------------------------------------------------------------------*/
    /*   Check Condition                                                      */
    /*------------------------------------------------------------------------*/

    // Common Initialisaition done here itself for all the cases.
    strBankMoveReqResult.strBankMoveResult[seqIx].lotID = lotIDs[seqIx] ;

    objLot_inventoryState_Get_out  strLot_inventoryState_Get_out ;
    rc = lot_inventoryState_Get(strLot_inventoryState_Get_out,strObjCommonIn,lotIDs[seqIx]);
    if( rc )
    {
        //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "rc != RC_OK")
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "rc != RC_OK")   //INN-R170017
        strBankMoveReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
        strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( rc ) ;
        return (rc) ;
    }
    else if ( CIMFWStrCmp( strLot_inventoryState_Get_out.lotInventoryState , SP_Lot_InventoryState_InBank ) == 0 )
    {
        objLot_holdState_Get_out  strLot_holdState_Get_out;
        rc = lot_holdState_Get(strLot_holdState_Get_out,strObjCommonIn,lotIDs[seqIx]);
        if( rc )
        {
            //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "rc != RC_OK")
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "rc != RC_OK")   //INN-R170017
            strBankMoveReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
            strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( rc ) ;
            return(rc);
        }
        else if (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold) == 0)
        {
            //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold) != 0")
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold) != 0")   //INN-R170017
            PPT_SET_MSG_RC_KEY2(strBankMoveReqResult, MSG_INVALID_LOT_HOLDSTAT,RC_INVALID_LOT_HOLDSTAT,(const char*)lotIDs[seqIx].identifier,(const char*)strLot_holdState_Get_out.lotHoldState)
            strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( RC_INVALID_LOT_HOLDSTAT ) ;
            return RC_INVALID_LOT_HOLDSTAT ;
        }

        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get(strLot_state_Get_out,strObjCommonIn,lotIDs[seqIx]) ;
        if( rc )
        {
            //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "rc != RC_OK")
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "rc != RC_OK")   //INN-R170017
            strBankMoveReqResult.strResult = strLot_state_Get_out.strResult ;
            strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString( rc ) ;
            return(rc);
        }
        else if (CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Shipped) == 0 )
        {
            //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Finished) !=0")
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Finished) !=0")   //INN-R170017
            PPT_SET_MSG_RC_KEY(strBankMoveReqResult, MSG_INVALID_LOT_STAT ,RC_INVALID_LOT_STAT,strLot_state_Get_out.lotState)
            strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( RC_INVALID_LOT_STAT ) ;
            return(RC_INVALID_LOT_STAT);
        }

        objLot_finishedState_Get_out strLot_finishedState_Get_out ;
        rc = lot_finishedState_Get(strLot_finishedState_Get_out, strObjCommonIn,lotIDs[seqIx]) ;
        if( rc )
        {
            //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "rc != RC_OK")
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "rc != RC_OK")   //INN-R170017
            strBankMoveReqResult.strResult = strLot_finishedState_Get_out.strResult ;
            strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString( rc ) ;
            return(rc);
        }
        else if (CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_Scrapped) ==0 ||
                 CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_Emptied) ==0   )
        {
            //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "CIMFWStrCmp(CIMFW_Lot_FinishedState_Completed) || CIMFWStrCmp(CIMFW_Lot_FinishedState_Emptied)")
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "CIMFWStrCmp(CIMFW_Lot_FinishedState_Completed) || CIMFWStrCmp(CIMFW_Lot_FinishedState_Emptied)")   //INN-R170017
            PPT_SET_MSG_RC_KEY(strBankMoveReqResult, MSG_INVALID_LOT_FINISHSTAT, RC_INVALID_LOT_FINISHSTAT,strLot_finishedState_Get_out.lotFinishedState)
            strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( RC_INVALID_LOT_FINISHSTAT ) ;
            return(RC_INVALID_LOT_FINISHSTAT);
        }
    }
    else if ( CIMFWStrCmp( strLot_inventoryState_Get_out.lotInventoryState , SP_Lot_InventoryState_NonProBank ) == 0 )
    {
        objBank_CheckNonProBank_out strBank_CheckNonProBank_out ;
                rc = bank_CheckNonProBank( strBank_CheckNonProBank_out , strObjCommonIn , toBankID ) ;
        if( rc )
        {
            //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "rc != RC_OK")
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "rc != RC_OK")   //INN-R170017
            strBankMoveReqResult.strResult = strBank_CheckNonProBank_out.strResult ;
            strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( rc );
            return (rc);
        }
    }
    else
    {
        PPT_SET_MSG_RC_KEY(strBankMoveReqResult, MSG_LOT_NOT_IN_BANK ,RC_LOT_NOT_IN_BANK,lotIDs[seqIx].identifier)
        PPT_SET_MSG_RC_KEY2(strBankMoveReqResult,MSG_INVALID_LOT_INVENTORYSTAT,RC_INVALID_LOT_INVENTORYSTAT,lotIDs[seqIx].identifier,strLot_inventoryState_Get_out.lotInventoryState) ;
        strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( RC_INVALID_LOT_INVENTORYSTAT );            //P4000090
        return RC_INVALID_LOT_INVENTORYSTAT ;
    }

//DSIV00000214 add start
    //-----------------------------------------------------------
    // Check lot interFabXferState
    //-----------------------------------------------------------
    objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;
    objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
    strLot_interFabXferState_Get_in.lotID = lotIDs[seqIx];
    rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,    
                                    strObjCommonIn,
                                    strLot_interFabXferState_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
        strBankMoveReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
        return( rc );
    }

    //-----------------------------------------------------------
    // "Transferring"
    //-----------------------------------------------------------
    if( CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring) == 0 )
    {
         PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
         PPT_SET_MSG_RC_KEY2( strBankMoveReqResult,
                              MSG_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                              RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                              lotIDs[seqIx].identifier,
                              strLot_interFabXferState_Get_out.interFabXferState );
         return( RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ );
    }
//DSIV00000214 add end

    //INN-R170017 add start
    PPT_METHODTRACE_V1( "", "##-------- Start for BWS checking --------##" );
    
    //----------------------------------------
    //   Get lotID/waferID of BWS
    //----------------------------------------
    PPT_METHODTRACE_V1( "", "##----- call cs_BWS_WaferList_GetDR() -----##" );
    
    csObjBWS_WaferList_GetDR_in strBWS_WaferList_GetDR_in;
    strBWS_WaferList_GetDR_in.lSearchType           = 2;
    strBWS_WaferList_GetDR_in.strBWSWaferData.lotID = lotIDs[seqIx];
    
    csObjBWS_WaferList_GetDR_out strBWS_WaferList_GetDR_out;
    rc = cs_BWS_WaferList_GetDR( strBWS_WaferList_GetDR_out, 
                                 strObjCommonIn,
                                 strBWS_WaferList_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "cs_BWS_WaferList_GetDR() != RC_OK, rc=", rc )
        strBankMoveReqResult.strResult = strBWS_WaferList_GetDR_out.strResult;
        return(rc);
    }
    
    //----------------------------------------
    //   Check if lotID/waferID already in BWS
    //----------------------------------------
    CORBA::Long lnLenBWS = strBWS_WaferList_GetDR_out.strBWSDataSeq.length();
    PPT_METHODTRACE_V2( "", "##--- lnLenBWS", lnLenBWS );
    for( CORBA::Long ix=0; ix<lnLenBWS; ix++ )
    {
        PPT_METHODTRACE_V2( "", "##--- BWSID", strBWS_WaferList_GetDR_out.strBWSDataSeq[ix].BWSID.identifier );
        
        CORBA::Long lnLenZone = strBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq.length();
        PPT_METHODTRACE_V3( "", ix, "##--- lnLenZone", lnLenZone );
        for( CORBA::Long jx=0; jx<lnLenZone; jx++ )
        {
            PPT_METHODTRACE_V4( "", ix, jx, "##--- zoneID", strBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].zoneID );
            
            CORBA::Long lnLenWafer = strBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq.length();
            PPT_METHODTRACE_V4( "", ix, jx, "##--- lnLenWafer", lnLenWafer );
            for( CORBA::Long kx=0; kx<lnLenWafer; kx++ )
            {
                PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- lotID",   strBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].lotID.identifier );
                PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- waferID", strBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].waferID.identifier );
                
                if( 0 == CIMFWStrCmp( lotIDs[seqIx].identifier,
                                      strBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].lotID.identifier ) )
                {
                    PPT_METHODTRACE_V1( "", "lot/wafer is in BWS. Operation is not allowed.")
                    
                    CS_PPT_SET_MSG_RC_KEY2( strBankMoveReqResult,
                                            CS_MSG_BWS_NOT_ALLOWED_MOVEBANK,
                                            CS_RC_BWS_NOT_ALLOWED_MOVEBANK,
                                            (const char*)lotIDs[seqIx].identifier,
                                            (const char*)strBWS_WaferList_GetDR_out.strBWSDataSeq[ix].BWSID.identifier );
                    return CS_RC_BWS_NOT_ALLOWED_MOVEBANK;
                }
            }
        }
    }
    
    //----------------------------------------
    //   Check if lotID/waferID has sorterJob
    //----------------------------------------
    PPT_METHODTRACE_V1( "", "##----- call txSortJobListInq() -----##" );

    pptSortJobListInqResult strSortJobListInqResult;
    objectIdentifier dummy;
    rc = txSortJobListInq( strSortJobListInqResult,
                           strObjCommonIn,
                           dummy,
                           dummy,
                           lotIDs[seqIx],
                           dummy,
                           dummy );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "txSortJobListInq() != RC_OK, rc=", rc )
        strBankMoveReqResult.strResult = strSortJobListInqResult.strResult;
        return(rc);
    }
    
    objectIdentifier sorterJobID;
    objectIdentifier equipmentID;
    objectIdentifier waferID;
    CORBA::Long lnLenSortJob = strSortJobListInqResult.strSortJobListAttributesSequence.length();
    PPT_METHODTRACE_V2( "", "##--- lnLenSortJob", lnLenSortJob );
    for( ix=0; ix<lnLenSortJob; ix++ )
    {
        PPT_METHODTRACE_V3( "", ix, "##--- sorterJobID", strSortJobListInqResult.strSortJobListAttributesSequence[ix].sorterJobID.identifier );
        PPT_METHODTRACE_V3( "", ix, "##--- equipmentID", strSortJobListInqResult.strSortJobListAttributesSequence[ix].equipmentID.identifier );
        
        CORBA::Long lnLenAttr = strSortJobListInqResult.strSortJobListAttributesSequence[ix].strSorterComponentJobListAttributesSeq.length();
        PPT_METHODTRACE_V3( "", ix, "##--- lnLenAttr", lnLenAttr );
        for( CORBA::Long jx=0; jx<lnLenAttr; jx++ )
        {
           CORBA::Long lnLenSlotMap = strSortJobListInqResult.strSortJobListAttributesSequence[ix].strSorterComponentJobListAttributesSeq[jx].strWaferSorterSlotMapSequence.length();
           PPT_METHODTRACE_V4( "", ix, jx, "##--- lnLenSlotMap", lnLenSlotMap );
           for( CORBA::Long kx=0; kx<lnLenAttr; kx++ )
           {
               PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- waferID", strSortJobListInqResult.strSortJobListAttributesSequence[ix].strSorterComponentJobListAttributesSeq[jx].strWaferSorterSlotMapSequence[kx].waferID.identifier );
               PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- lotID",   strSortJobListInqResult.strSortJobListAttributesSequence[ix].strSorterComponentJobListAttributesSeq[jx].strWaferSorterSlotMapSequence[kx].lotID.identifier );
               
               if( 0 == CIMFWStrCmp( lotIDs[seqIx].identifier,
                                     strSortJobListInqResult.strSortJobListAttributesSequence[ix].strSorterComponentJobListAttributesSeq[jx].strWaferSorterSlotMapSequence[kx].lotID.identifier ) )
               {
                   PPT_METHODTRACE_V2( "", "##--- lotID has sorterJob !!!", lnLenSortJob );
                   
                   sorterJobID = strSortJobListInqResult.strSortJobListAttributesSequence[ix].sorterJobID;
                   equipmentID = strSortJobListInqResult.strSortJobListAttributesSequence[ix].equipmentID;
                   waferID     = strSortJobListInqResult.strSortJobListAttributesSequence[ix].strSorterComponentJobListAttributesSeq[jx].strWaferSorterSlotMapSequence[kx].waferID;
                   break;
               }
           }
        }        
    }
    
    PPT_METHODTRACE_V2( "", "##--- sorterJobID", sorterJobID.identifier );
    PPT_METHODTRACE_V2( "", "##--- equipmentID", equipmentID.identifier );
    PPT_METHODTRACE_V2( "", "##--- waferID",     waferID.identifier );
    
    //----------------------------------------
    //   Check if equipmentID is BWS
    //----------------------------------------    
    if( 0 < CIMFWStrLen( equipmentID.identifier ) )
    {
        PPT_METHODTRACE_V1( "", "##----- call txEqpInfoInq__160() -----##" );
        
        pptEqpInfoInqResult__160 strEqpInfoInqResult;
        rc = txEqpInfoInq__160( strEqpInfoInqResult,
                                strObjCommonIn,
                                equipmentID,
                                TRUE,       //requestFlagForBRInfo
                                FALSE,      //requestFlagForStatusInfo
                                FALSE,      //requestFlagForPMInfo
                                FALSE,      //requestFlagForPortInfo
                                FALSE,      //requestFlagForChamberInfo
                                FALSE,      //requestFlagForStockerInfo
                                FALSE,      //requestFlagForInprocessingLotInfo
                                FALSE,      //requestFlagForReservedControlJobInfo
                                FALSE,      //requestFlagForRSPortInfo
                                FALSE );    //requestFlagForEqpContainerInfo
        if( rc != RC_OK ) 
        {
            PPT_METHODTRACE_V2( "", "txEqpInfoInq__160() != RC_OK, rc=", rc );
            strBankMoveReqResult.strResult = strEqpInfoInqResult.strResult;
            return(rc);
        }   
        
        // check specialControl
        CORBA::Boolean bBWSSpecialCtrlFlag = FALSE;
        CORBA::Long lnLenCtrl = strEqpInfoInqResult.equipmentBRInfo.specialControl.length();
        for( ix=0; ix<lnLenCtrl; ix++ )
        {
            if( 0 == CIMFWStrCmp( CS_EQP_SpecialEquipmentControl_BareWaferStocker,
                                  strEqpInfoInqResult.equipmentBRInfo.specialControl[ix] ) )
            {
                PPT_METHODTRACE_V2( "", "equipment specialControl", strEqpInfoInqResult.equipmentBRInfo.specialControl[ix] );
                bBWSSpecialCtrlFlag = TRUE;
                break;
            }
        }
        PPT_METHODTRACE_V2( "", "bBWSSpecialCtrlFlag", bBWSSpecialCtrlFlag );
        
        if( bBWSSpecialCtrlFlag == TRUE )
        {
            PPT_METHODTRACE_V1( "", "Eqp Special Control is Bare Wafer Stocker" );
                        
            CS_PPT_SET_MSG_RC_KEY3( strBankMoveReqResult,
                                    CS_MSG_BWS_NOT_ALLOWED_OPERATION_FOR_SORTERJOB,
                                    CS_RC_BWS_NOT_ALLOWED_OPERATION_FOR_SORTERJOB,
                                   (const char*)lotIDs[seqIx].identifier,
                                   (const char*)sorterJobID.identifier,
                                   (const char*)equipmentID.identifier );
            return( CS_RC_BWS_NOT_ALLOWED_OPERATION_FOR_SORTERJOB );          
        }
    }
    PPT_METHODTRACE_V1( "", "##----- End of BWS checking -----##" );
    //INN-R170017 add end
    
    /*------------------------------------------------------------------------*/
    /*   Change State                                                         */
    /*------------------------------------------------------------------------*/

    objlot_bank_Move_out strlot_bank_Move ;
    rc = lot_bank_Move(strlot_bank_Move,strObjCommonIn,lotIDs[seqIx],toBankID) ;
    if( rc )
    {
        //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "rc != RC_OK")
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "rc != RC_OK")   //INN-R170017
        strBankMoveReqResult.strResult = strlot_bank_Move.strResult ;
        strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( rc );
        return (rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/

    objLotBankMoveEvent_Make_out strLotBankMoveEvent_Make_out ;
    rc = lotBankMoveEvent_Make(strLotBankMoveEvent_Make_out,strObjCommonIn,"TXBKC003",lotIDs[seqIx],claimMemo) ;
    if( rc )
    {
        //INN-R170017 PPT_METHODTRACE_V1("PPTManager_i:: txBankMoveReq ", "rc != RC_OK")
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txBankMoveReq ", "rc != RC_OK")   //INN-R170017
        strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( rc ) ;
//P3000139    strBankMoveReqResult.strResult = strLotBankMoveEvent_Make_out.strResult ; //P3000139
//P5000145        PPT_SET_MSG_RC_KEY(strBankMoveReqResult, MSG_FAIL_MAKE_HISTORY, rc ,lotIDs[seqIx].identifier)
        SET_MSG_RC( strBankMoveReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/

    strBankMoveReqResult.strBankMoveResult[seqIx].returnCode = ConvertLongtoString ( RC_OK ) ;

    SET_MSG_RC(strBankMoveReqResult, MSG_OK, RC_OK); //P3000139

    //INN-R170017 PPT_METHODTRACE_EXIT("PPTManager_i::txBankMoveReq ")
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txBankMoveReq ")   //INN-R170017
    return(RC_OK);
}


