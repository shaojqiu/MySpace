#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txPartialReworkWithoutHoldReleaseReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:29:09 [ 7/13/07 21:29:10 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txPartialReworkWithoutHoldReleaseReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txPartialReworkWithoutHoldReleaseReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2005/04/13 D6000259   H.Hasegawa     Initial Release (R6.0.1)
// 2005/06/23 P6000544   H.Hasegawa     Change operation number of Rework Hold.
// 2005/11/18 D7000021   M.Murata       Add : Check lot's hold state. (LOCK)
// 2005/12/16 P7000058   Y.Kadowaki     Add check logic for carrier dispatch status.
// 2006/02/09 D7000173   H.Hasegawa     Add input parameter of process_OperationListForLot().
// 2007/06/13 D9000005   H.Hotta        WaferSorter automation support.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/30 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2012/06/05 PSN000043987 T.Ishida       Wrong hold information is inherit to child lot on split without hold release operation.
// 2013/05/13 DSN000071674 Liuya          Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2014/05/17 PSN000081348 C.Mo           ProcessHolds: Split with "Without Hold release" can't inherit the hold
// 2014/07/29 DSN000085792 Sa Guo         Q-Time Improvements.
// 2015/11/11 DSN000096135 XF.Ming        process_OperationListForLot ==> process_OperationListForLot__160.
// 2017/02/08 DSN000104277 Q.Li           process_OperationListForLot__160 ==>  process_OperationProcessRefListForLot.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170002  JJ.Zhang       Contamination Control
//
// Description:
//   This function performs Partial Rework to a Lot whose Hold State is "ONHOLD".
//   To inherit Hold Records to Child Lot from Parent Lot is possible.
//   However Process Hold, Merge Hold, Rework Hold and so on is not so.
//   The other processes are same as txPartialReworkReq().
//   * If the lot is held with "LOCK", it's not performed.    //D7000021
//
// Return:
//   long
//
// Parameter:
//  pptPartialReworkWithoutHoldReleaseReqResult&  strPartialReworkWithoutHoldReleaseReqResult
//  const pptObjCommonIn&                         strObjCommonIn
//  const pptPartialReworkReq&                    strPartialReworkReq
//  const char*                                   claimMemo
//  const pptHoldListSequence&                    strLotHoldRequests
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long  CS_PPTManager_i::txPartialReworkWithoutHoldReleaseReq(
    pptPartialReworkWithoutHoldReleaseReqResult&  strPartialReworkWithoutHoldReleaseReqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const pptPartialReworkReq&                    strPartialReworkReq,
    const char*                                   claimMemo,
    const pptHoldListSequence&                    strLotHoldRequests CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txPartialReworkWithoutHoldReleaseReq");
    CORBA::Long  rc = RC_OK;

    objectIdentifier   parentLotID  = strPartialReworkReq.parentLotID;
    CORBA::String_var  tmpRtnOpeNum = strPartialReworkReq.returnOperationNumber;

    //===========================================================================
    // Lock for objects
    //===========================================================================
    //----- Gets Parent Lot's Cassette. -------//
    objLot_cassette_Get_out  strLot_cassette_Get_out;
    rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_cassette_Get_out.strResult;
        return rc;
    }
    objectIdentifier  cassetteID = strLot_cassette_Get_out.cassetteID;

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;
    objObject_Lock_out  strObject_Lock_out;

    if ( 0 == lotOperationEIcheck )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC073" ); // TxPartialReworkWithoutHoldReleaseReq

        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );
        if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
        {
            updateControlJobFlag = TRUE;

            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strPartialReworkWithoutHoldReleaseReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = cassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strPartialReworkWithoutHoldReleaseReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strPartialReworkWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }
//PSN000083176        if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            cassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strPartialReworkWithoutHoldReleaseReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;
//PSN000083176                if( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strPartialReworkWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end

    //----- Lock for Cassette -------//
//DSN000071674    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, cassetteID, SP_ClassName_PosCassette );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }

//PSN000083176 add start
    if ( 0 == lotOperationEIcheck )
    {
        if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strPartialReworkWithoutHoldReleaseReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;
                if( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strPartialReworkWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end

    //----- Lock for Parent Lot -------//
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, parentLotID, SP_ClassName_PosLot );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyCastIDs, lotIDs;
    lotIDs.length(1);
    lotIDs[0] = parentLotID;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyCastIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = lotIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Lot);

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end


    //===========================================================================
    // Check for conditions
    //===========================================================================
    //-----------------------------------------------------------
    // Check for consistency of Sub Route and Return Operation
    //-----------------------------------------------------------
    //----- Converts Sub Route which is specified by input-parameter into the active one. -------//
    objProcess_activeID_Get_out  strProcess_activeID_Get_out;
    rc = process_activeID_Get( strProcess_activeID_Get_out, strObjCommonIn, strPartialReworkReq.subRouteID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_activeID_Get() != RC_OK") ;
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_activeID_Get_out.strResult;
        return rc;
    }
    objectIdentifier  subRouteID = strProcess_activeID_Get_out.activeID;

    //----- Gets Parent Lot's Current Operation. -------//
    objLot_currentOperationInfo_Get_out  strLot_currentOperationInfo_Get_out;
    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","lot_currentOperationInfo_Get() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
        return rc;
    }

    //----- Check for Current Route : It should not be same as Sub Route. -------//
    if( CIMFWStrCmp( strLot_currentOperationInfo_Get_out.routeID.identifier, subRouteID.identifier ) == 0 )
    {
        PPT_METHODTRACE_V2("", "Sub Route is Invalid !!! This is same as Parent Lot's curret Route.", subRouteID.identifier);
        SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_BRANCH_ROUTEID, RC_INVALID_BRANCH_ROUTEID );
        return RC_INVALID_BRANCH_ROUTEID;
    }

    //----- Gets Parent Lot's Original Route. -------//
    objLot_originalRouteList_Get_out  strLot_originalRouteList_Get_out;
    rc = lot_originalRouteList_Get( strLot_originalRouteList_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_originalRouteList_Get() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_originalRouteList_Get_out.strResult;
        return rc;
    }

    //----- Check for Original Route : It should not be same as Sub Route. -------//
    CORBA::Long originalRouteLen = strLot_originalRouteList_Get_out.originalRouteID.length();
    for( CORBA::Long  routeCnt = 0; routeCnt < originalRouteLen; routeCnt++ )
    {
        if( CIMFWStrCmp( strLot_originalRouteList_Get_out.originalRouteID[routeCnt].identifier, subRouteID.identifier ) == 0 )
        {
            PPT_METHODTRACE_V2("", "Sub Route is Invalid !!! This is same as Parent Lot's original Route.", subRouteID.identifier);
            SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID );
            return RC_INVALID_BRANCH_ROUTEID;
        }
    }

    //----- Gets Sub Route's Dynamic Route Flag. -------//
    objProcess_checkForDynamicRoute_out  strProcess_checkForDynamicRoute_out;
    rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, subRouteID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_checkForDynamicRoute() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult;
        return rc;
    }

    //----- Check for Dynamic Route Flag -------//
    if( strPartialReworkReq.bDynamicRoute == TRUE && strProcess_checkForDynamicRoute_out.bDynamicRoute == FALSE )
    {
        PPT_METHODTRACE_V1("", "Dynamic Route Flag is Invalid !!! Sub Route is not the dynamic one.");
        SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_NOT_DYNAMIC_ROUTE, RC_NOT_DYNAMIC_ROUTE );
        return RC_NOT_DYNAMIC_ROUTE;
    }

    //----- Gets Sub Route's Return Operation. -------//
    objProcess_GetReturnOperation_out  strProcess_GetReturnOperation_out;
    rc = process_GetReturnOperation( strProcess_GetReturnOperation_out, strObjCommonIn, parentLotID, subRouteID );
    if( rc != RC_OK && rc != RC_NOT_FOUND_SUBROUTE )
    {
        PPT_METHODTRACE_V1("", "process_GetReturnOperation() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_GetReturnOperation_out.strResult;
        return rc;
    }

    //----- Check for ProcessDefinitionType of Sub Route -------//
    if( CIMFWStrCmp( strProcess_GetReturnOperation_out.processDefinitionType, SP_MAINPDTYPE_REWORK ) != 0 )
    {
        PPT_METHODTRACE_V2("", "Sub Route is Invalid !!! This is not rework route", subRouteID.identifier);
        SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_ROUTE_TYPE, RC_INVALID_ROUTE_TYPE );
        return RC_INVALID_ROUTE_TYPE;
    }

    //----- Check for Return Operation -------//
    CORBA::Boolean  connectedRouteReturnOperationFlag = FALSE;
    if( rc == RC_OK )
    {
        connectedRouteReturnOperationFlag = TRUE;

        if( CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, tmpRtnOpeNum ) == 0 )
        {
            PPT_METHODTRACE_V1("", "Return Operation which is specified by input-parameter is correct.");
        }
        else if( strProcess_checkForDynamicRoute_out.bDynamicRoute == FALSE && CIMFWStrLen( tmpRtnOpeNum ) > 0 )
        {
            PPT_METHODTRACE_V2("", "Return Operation is Invalid !!! This is not same as Sub Route's Return Operation.", tmpRtnOpeNum);
            SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }
    }
    else if( strPartialReworkReq.bDynamicRoute == FALSE )
    {
        PPT_METHODTRACE_V1("", "Dynamic Route Flag is Invalid !!! Sub Route doesn't have Return Operation.");
        SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_ROUTE_ID, RC_INVALID_ROUTE_ID );
        return RC_INVALID_ROUTE_ID;
    }

    PPT_METHODTRACE_V2("", "This is Sub Route which is used at after process.", subRouteID.identifier);

//DSIV00000214 add start
    //---------------------------------------
    // Check interFabXferPlan existence
    //---------------------------------------
    objProcess_CheckInterFabXferPlanSkip_in strProcess_CheckInterFabXferPlanSkip_in;
    strProcess_CheckInterFabXferPlanSkip_in.lotID = parentLotID;
    strProcess_CheckInterFabXferPlanSkip_in.currentRouteID = strLot_currentOperationInfo_Get_out.routeID;
    strProcess_CheckInterFabXferPlanSkip_in.currentOpeNo = strLot_currentOperationInfo_Get_out.operationNumber;
    strProcess_CheckInterFabXferPlanSkip_in.jumpingRouteID = strLot_currentOperationInfo_Get_out.routeID;
    strProcess_CheckInterFabXferPlanSkip_in.jumpingOpeNo = strPartialReworkReq.returnOperationNumber;

    objProcess_CheckInterFabXferPlanSkip_out strProcess_CheckInterFabXferPlanSkip_out;
    rc = process_CheckInterFabXferPlanSkip( strProcess_CheckInterFabXferPlanSkip_out,
                                            strObjCommonIn,
                                            strProcess_CheckInterFabXferPlanSkip_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_CheckInterFabXferPlanSkip() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_CheckInterFabXferPlanSkip_out.strResult;
        return( rc );
    }
//DSIV00000214 add end

//DSIV00001830 add start
    //-----------------------------------------------------------
    // Check for Bonding Group of Parent Lot
    //-----------------------------------------------------------
    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = parentLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strPartialReworkWithoutHoldReleaseReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    //-----------------------------------------------------------
    // Check for contents of Parent Lot
    //-----------------------------------------------------------
    //----- Gets Parent Lot's contents. -------//
    objLot_contents_Get_out  strLot_contents_Get_out;
    rc = lot_contents_Get( strLot_contents_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_contents_Get_out.strResult;
        return rc;
    }

    //----- Check for contents : It should be "Wafer" or "Die". -------//
    if( CIMFWStrCmp( strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer ) != 0 &&
        CIMFWStrCmp( strLot_contents_Get_out.theLotContents, SP_ProdType_Die   ) != 0   )
    {
        PPT_METHODTRACE_V2("", "Lot's contents is Invalid !!!", strLot_contents_Get_out.theLotContents);
        PPT_SET_MSG_RC_KEY( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                            parentLotID.identifier );
        return RC_INVALID_LOT_CONTENTS;
    }

    //-----------------------------------------------------------
    // Check for each state of Parent Lot
    //-----------------------------------------------------------
    //----- Gets Parent Lot's all state. -------//
    objLot_allState_Get_out  strLot_allState_Get_out;
    rc = lot_allState_Get( strLot_allState_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_allState_Get_out.strResult;
        return rc;
    }

    //----- Check for Lot State : It should be "ACTIVE". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.lotState, CIMFW_Lot_State_Active ) != 0 )
    {
        PPT_METHODTRACE_V2("", "Lot State is Invalid !!!", strLot_allState_Get_out.lotState);
        PPT_SET_MSG_RC_KEY( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_LOT_STAT, RC_INVALID_LOT_STAT, strLot_allState_Get_out.lotState );
        return RC_INVALID_LOT_STAT;
    }
    //----- Check for Lot Hold State : It should be "ONHOLD". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.holdState, CIMFW_Lot_HoldState_OnHold ) != 0 )
    {
        PPT_METHODTRACE_V2("", "Lot Hold State is Invalid !!!", strLot_allState_Get_out.holdState);
        PPT_SET_MSG_RC_KEY( strPartialReworkWithoutHoldReleaseReqResult, MSG_LOT_NOT_HELD, RC_LOT_NOT_HELD, parentLotID.identifier );
        return RC_LOT_NOT_HELD;
    }
//D7000021 add start
    //---- But, the lot should not be held by "LOCK". -----//
    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
    objectIdentifierSequence lotIDSeq;
    lotIDSeq.length(1);
    lotIDSeq[0] = parentLotID;
    objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
    rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", lotIDSeq[0].identifier );
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
        return ( rc );
    }
//D7000021 add end
    //----- Check for Lot Process State : It should not be "Processing". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.processState, SP_Lot_ProcState_Processing ) == 0)
    {
        PPT_METHODTRACE_V2("", "Lot Process State is Invalid !!!", strLot_allState_Get_out.processState);
        PPT_SET_MSG_RC_KEY2( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                             parentLotID.identifier, strLot_allState_Get_out.processState );
        return RC_INVALID_LOT_PROCSTAT;
    }
    //----- Check for Lot Production State : It should not be "INREWORK". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.productionState, CIMFW_Lot_ProductionState_InRework ) == 0 )
    {
        PPT_METHODTRACE_V2("", "Lot Production State is Invalid !!!", strLot_allState_Get_out.productionState);
        PPT_SET_MSG_RC_KEY2( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_LOT_PRODSTAT, RC_INVALID_LOT_PRODSTAT,
                             parentLotID.identifier, strLot_allState_Get_out.productionState );
        return RC_INVALID_LOT_PRODSTAT;
    }
    //----- Check for Lot Inventory State : It should be "OnFloor". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.inventoryState, SP_Lot_InventoryState_OnFloor ) != 0 )
    {
        PPT_METHODTRACE_V2("", "Lot Inventory State is Invalid !!!", strLot_allState_Get_out.inventoryState);
        PPT_SET_MSG_RC_KEY2( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_LOT_INVENTORYSTAT, RC_INVALID_LOT_INVENTORYSTAT,
                             parentLotID.identifier, strLot_allState_Get_out.inventoryState );
        return RC_INVALID_LOT_INVENTORYSTAT;
    }

    //-----------------------------------------------------------
    // Check for Control Job of Parent Lot
    //-----------------------------------------------------------
    //----- Gets Parent Lot's Control Job. -------//
    objLot_controlJobID_Get_out  strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }

    //----- Check for Control Job : It should not exist. -------//
    if( CIMFWStrLen( strLot_controlJobID_Get_out.controlJobID.identifier ) > 0 )
    {
        PPT_METHODTRACE_V2("", "Lot Control Job condition is Invalid !!!", strLot_controlJobID_Get_out.controlJobID.identifier);
        PPT_SET_MSG_RC_KEY2( strPartialReworkWithoutHoldReleaseReqResult, MSG_LOT_CTLJOBID_FILLED, RC_LOT_CTLJOBID_FILLED,
                             parentLotID.identifier, strLot_controlJobID_Get_out.controlJobID.identifier );
        return RC_LOT_CTLJOBID_FILLED;
    }

//DSN000071674 add start
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
//P7000058 add start
        //-------------------------------
        // Check carrier dispatch status
        //-------------------------------
        objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
        strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE;
        rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn, cassetteID);
        if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", "cassette_dispatchState_Get() dispatchReservedFlag == TRUE");
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strCassette_dispatchState_Get_out.strResult ;
            SET_MSG_RC(strPartialReworkWithoutHoldReleaseReqResult,
                       MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST);
            return( RC_ALREADY_DISPATCH_RESVED_CST );
        }
//P7000058 add end
    } //DSN000071674

    //-----------------------------------------------------------
    // Check for current Operation of Parent Lot
    //-----------------------------------------------------------
    //----- Gets Parent Lot's current and previous Operation. -------//
    objectIdentifier  searchRouteID_dummy;                                                                            //D7000173
    searchRouteID_dummy.identifier = CIMFWStrDup( "" );                                                               //D7000173

//DSN000096135    objProcess_OperationListForLot_out  strProcess_OperationListForLot_out;
//D7000173    rc = process_OperationListForLot( strProcess_OperationListForLot_out, strObjCommonIn, FALSE, TRUE, 2, TRUE, parentLotID );
//D7000173    // rc = process_OperationListForLot( returnStructure, commonInfo, searchDirection, posSearchFlag, searchCount, currentFlag );
//DSN000096135    rc = process_OperationListForLot( strProcess_OperationListForLot_out, strObjCommonIn,                             //D7000173
//DSN000096135                                      FALSE, TRUE, 2, searchRouteID_dummy, "", TRUE, parentLotID );                   //D7000173
    // rc = process_OperationListForLot( returnStructure, commonInfo, searchDirection, posSearchFlag, searchCount,    //D7000173
    //                                   searchRouteID, searchOperationNumber, currentFlag, lotID );                  //D7000173
    //   - searchDirection : "FALSE" specifies search of Backward Operation.
    //   - posSearchFlag   : "TRUE"  specifies search by POS.
    //   - searchCount     : "2"     specifies search of 2 Operations.
    //   - currentFlag     : "TRUE"  specifies search of Current Operation
//DSN000096135 add start
//DSN000104277    objProcess_OperationListForLot_out__160 strProcess_OperationListForLot_out;
//DSN000104277    objProcess_OperationListForLot_in__160 strProcess_OperationListForLot_in;
//DSN000104277    strProcess_OperationListForLot_in.searchDirection           = FALSE;
//DSN000104277    strProcess_OperationListForLot_in.posSearchFlag             = TRUE;
//DSN000104277    strProcess_OperationListForLot_in.searchCount               = 2;
//DSN000104277    strProcess_OperationListForLot_in.searchRouteID             = searchRouteID_dummy;
//DSN000104277    strProcess_OperationListForLot_in.searchOperationNumber     = CIMFWStrDup("");
//DSN000104277    strProcess_OperationListForLot_in.currentFlag               = TRUE;
//DSN000104277    strProcess_OperationListForLot_in.lotID                     = parentLotID;
//DSN000104277    rc = process_OperationListForLot__160(strProcess_OperationListForLot_out, strObjCommonIn, strProcess_OperationListForLot_in);
//DSN000096135 add end
//DSN000104277 add start
    objProcess_OperationProcessRefListForLot_out strProcess_OperationProcessRefListForLot_out;
    objProcess_OperationProcessRefListForLot_in strProcess_OperationProcessRefListForLot_in;
    strProcess_OperationProcessRefListForLot_in.searchDirection           = FALSE;
    strProcess_OperationProcessRefListForLot_in.posSearchFlag             = TRUE;
    strProcess_OperationProcessRefListForLot_in.searchCount               = 2;
    strProcess_OperationProcessRefListForLot_in.searchRouteID             = searchRouteID_dummy;
    strProcess_OperationProcessRefListForLot_in.searchOperationNumber     = CIMFWStrDup("");
    strProcess_OperationProcessRefListForLot_in.currentFlag               = TRUE;
    strProcess_OperationProcessRefListForLot_in.lotID                     = parentLotID;
    rc = process_OperationProcessRefListForLot(strProcess_OperationProcessRefListForLot_out, strObjCommonIn, strProcess_OperationProcessRefListForLot_in);
//DSN000104277 add end
    if( rc != RC_OK )
    {
//DSN000096135        PPT_METHODTRACE_V1("", "process_OperationListForLot() != RC_OK");
//DSN000104277        PPT_METHODTRACE_V1("", "process_OperationListForLot__160() != RC_OK");   //DSN000096135
//DSN000104277        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_OperationListForLot_out.strResult;
        PPT_METHODTRACE_V1("", "process_OperationProcessRefListForLot() != RC_OK");                                        //DSN000104277
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_OperationProcessRefListForLot_out.strResult;    //DSN000104277
        return rc;
    }

    //----- Check for Operaions : Current Operation should be the first one or be same as the previous one. -------//
//DSN000104277    CORBA::Long  opeLen = strProcess_OperationListForLot_out.strOperationNameAttributes.length();
//DSN000104277    if( opeLen < 2 || ( opeLen >= 2  &&
//DSN000104277                        CIMFWStrCmp( strProcess_OperationListForLot_out.strOperationNameAttributes[0].routeID.identifier,
//DSN000104277                                     strProcess_OperationListForLot_out.strOperationNameAttributes[1].routeID.identifier ) != 0 ) )
    CORBA::Long  opeLen = strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes.length();                                     //DSN000104277
    if( opeLen < 2 || ( opeLen >= 2  &&                                                                                                               //DSN000104277
                        CIMFWStrCmp( strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes[0].routeID.identifier,             //DSN000104277
                                     strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes[1].routeID.identifier ) != 0 ) )   //DSN000104277
    {
        PPT_METHODTRACE_V1("", "Current Operation is Invalid !!!");
        SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_REWORK_OPERATION, RC_INVALID_REWORK_OPERATION );
        return RC_INVALID_REWORK_OPERATION;
    }

    //-----------------------------------------------------------
    // Check for Future Hold Request of Parent Lot
    //-----------------------------------------------------------
    objLot_futureHoldRequests_CheckSplit_out  strLot_futureHoldRequests_CheckSplit_out;
    rc = lot_futureHoldRequests_CheckSplit( strLot_futureHoldRequests_CheckSplit_out, strObjCommonIn, parentLotID, "", tmpRtnOpeNum );
    // rc = lot_futureHoldRequests_CheckSplit( returnStructure, commonInfo, lotID, mergedOperationNumber, returnOperationNumber );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_CheckSplit() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_futureHoldRequests_CheckSplit_out.strResult;
        return rc;
    }

    //-----------------------------------------------------------
    // Check for Xfer State of Cassette
    //-----------------------------------------------------------
    //----- Gets Cassette's Xfer State. -------//
    objCassette_transferState_Get_out  strCassette_transferState_Get_out;
//DSN000071674 add start
    if ( 1 == lotOperationEIcheck 
        || ( 0 == lotOperationEIcheck && (0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ) ) )
    {
//DSN000071674 add end
        rc = cassette_transferState_Get( strCassette_transferState_Get_out, strObjCommonIn, cassetteID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_transferState_Get() != RC_OK");
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strCassette_transferState_Get_out.strResult;
            return rc;
        }

//DSN000071674 add start
        if ( 0 == lotOperationEIcheck )
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
            if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn))                                                  //D4100091
            {
                PPT_METHODTRACE_V1("","Changed to EI by other operation");
                strPartialReworkWithoutHoldReleaseReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                PPT_SET_MSG_RC_KEY(strPartialReworkWithoutHoldReleaseReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                   cassetteID.identifier);
                return( CS_RC_CAST_XFERSTATE_BE_CHANGED_BY_OTHER_OPERATION );
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
            //----- Check for Xfer State : It should not be "BO" and "EI". -------//
            if( CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_BayOut      ) == 0 || CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) == 0 )
            {
                PPT_METHODTRACE_V2("", "Xfer State is Invalid !!!", strCassette_transferState_Get_out.transferState);
                PPT_SET_MSG_RC_KEY2( strPartialReworkWithoutHoldReleaseReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                     strCassette_transferState_Get_out.transferState, cassetteID.identifier );
                return RC_INVALID_CAST_XFERSTAT;
            }
//DSN000071674 add start
        }
    }
    if ( 0 == lotOperationEIcheck )
    {
        strCassette_transferState_Get_out = strCassetteTransferState;
    }
//DSN000071674 add end

    //-----------------------------------------------------------
    // Check for consistency of Hold Requests
    //-----------------------------------------------------------
    CORBA::Long  requestLen = strLotHoldRequests.length();
//PSN000081348 Add Start
    CORBA::Long processHoldAllowLotMovement = atoi( getenv(SP_PROCESSHOLD_ALLOW_LOTMOVEMENT) );
    CORBA::Boolean inheritProcessHold = FALSE;
    CORBA::ULong procHoldReqLen = 0;
    CORBA::ULong holdReqWithoutProcHoldLen = 0;
    pptHoldListSequence procHoldReq;
    pptHoldListSequence holdReqWithoutProcHold;
    procHoldReq.length(requestLen);
    holdReqWithoutProcHold.length(requestLen);
//PSN000081348 Add End
    for( CORBA::Long  requestCnt = 0; requestCnt < requestLen; requestCnt++ )
    {
        if( CIMFWStrCmp( strLotHoldRequests[requestCnt].holdType, SP_HoldType_ProcessHold ) == 0 )
        {
            if ( processHoldAllowLotMovement == 0 ) //PSN000081348
            { //PSN000081348
                PPT_METHODTRACE_V1("", "Process Hold cannot be inherited.");
                PPT_SET_MSG_RC_KEY4( strPartialReworkWithoutHoldReleaseReqResult, MSG_HOLDRECORD_CANNOT_INHERIT, RC_HOLDRECORD_CANNOT_INHERIT,
                                     strLotHoldRequests[requestCnt].holdType, strLotHoldRequests[requestCnt].holdReasonCodeID.identifier,
                                     strLotHoldRequests[requestCnt].holdUserID.identifier, strLotHoldRequests[requestCnt].relatedLotID.identifier );
                return RC_HOLDRECORD_CANNOT_INHERIT;
            } //PSN000081348
            inheritProcessHold = TRUE; //PSN000081348
            procHoldReq[procHoldReqLen++] = strLotHoldRequests[requestCnt]; //PSN000081348
        }
        else if( CIMFWStrLen( strLotHoldRequests[requestCnt].relatedLotID.identifier ) > 0 )
        {
            PPT_METHODTRACE_V1("", "Merge Hold, Rework Hold and so on cannot be inherited.");
            PPT_SET_MSG_RC_KEY4( strPartialReworkWithoutHoldReleaseReqResult, MSG_HOLDRECORD_CANNOT_INHERIT, RC_HOLDRECORD_CANNOT_INHERIT,
                                 strLotHoldRequests[requestCnt].holdType, strLotHoldRequests[requestCnt].holdReasonCodeID.identifier,
                                 strLotHoldRequests[requestCnt].holdUserID.identifier, strLotHoldRequests[requestCnt].relatedLotID.identifier );
            return RC_HOLDRECORD_CANNOT_INHERIT;
        }
        else
        {
            PPT_METHODTRACE_V1("", "Inherited Hold Request");
            PPT_METHODTRACE_V3("", strLotHoldRequests[requestCnt].holdType, strLotHoldRequests[requestCnt].holdReasonCodeID.identifier,
                                   strLotHoldRequests[requestCnt].holdUserID.identifier);
            holdReqWithoutProcHold[holdReqWithoutProcHoldLen++] = strLotHoldRequests[requestCnt]; //PSN000081348
        }
    }
    procHoldReq.length(procHoldReqLen); //PSN000081348
    holdReqWithoutProcHold.length(holdReqWithoutProcHoldLen); //PSN000081348
    PPT_METHODTRACE_V2( "", "ProcessHold Request length", procHoldReqLen ); //PSN000081348
    PPT_METHODTRACE_V2( "", "Hold Request Without ProcessHold length", holdReqWithoutProcHoldLen ); //PSN000081348

    //PSN000043987 Add Start
    //---------------------------
    // Get the lot's hold list.
    //---------------------------
    PPT_METHODTRACE_V2( "", "Get the lot's hold list. ", parentLotID.identifier );

    objLot_FillInTxTRQ005DR_out strLot_FillInTxTRQ005DR_out;
    rc = lot_FillInTxTRQ005DR( strLot_FillInTxTRQ005DR_out, strObjCommonIn, parentLotID );

    if( rc != RC_OK && rc != RC_NOT_FOUND_ENTRY )
    {
        PPT_METHODTRACE_V1( "", "lot_FillInTxTRQ005DR() != RC_OK" );
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_FillInTxTRQ005DR_out.strResult;
        return ( rc ) ;
    }

    CORBA::Long inheritLen = 0;
    inheritLen = strLotHoldRequests.length();

    if( rc == RC_OK )
    {
        //---------------------------
        // Check Inherit Hold Record
        //---------------------------
        CORBA::Long holdLen = 0;
        CORBA::Boolean existFlag = FALSE;

        holdLen = strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length();

        PPT_METHODTRACE_V2( "", "strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length()", holdLen );

        for( CORBA::Long inheritCnt=0; inheritCnt<inheritLen; inheritCnt++ )
        {
            existFlag = FALSE;
            for( CORBA::Long holdCnt=0; holdCnt<holdLen; holdCnt++ )
            {
                if( ( CIMFWStrCmp( strLotHoldRequests[inheritCnt].holdType,                    strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].holdType ) == 0 ) &&
                    ( CIMFWStrCmp( strLotHoldRequests[inheritCnt].holdReasonCodeID.identifier, strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].reasonCodeID.identifier ) == 0 ) &&
                    ( CIMFWStrCmp( strLotHoldRequests[inheritCnt].holdUserID.identifier,       strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].userID.identifier ) == 0 ) &&
                    ( CIMFWStrCmp( strLotHoldRequests[inheritCnt].relatedLotID.identifier,     strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].relatedLotID.identifier ) == 0 ) )
                {
                    PPT_METHODTRACE_V5( "", "Hold Record Exist!", strLotHoldRequests[inheritCnt].holdType, strLotHoldRequests[inheritCnt].holdReasonCodeID.identifier, strLotHoldRequests[inheritCnt].holdUserID.identifier, strLotHoldRequests[inheritCnt].relatedLotID.identifier );
                    existFlag = TRUE;
                    break;
                }
            }

            if( existFlag == FALSE )
            {
                PPT_METHODTRACE_V5( "", "Hold Record Not Exist! Cannot be inherited", strLotHoldRequests[inheritCnt].holdType, strLotHoldRequests[inheritCnt].holdReasonCodeID.identifier, strLotHoldRequests[inheritCnt].holdUserID.identifier, strLotHoldRequests[inheritCnt].relatedLotID.identifier );

                PPT_SET_MSG_RC_KEY4( strPartialReworkWithoutHoldReleaseReqResult, MSG_HOLDRECORD_CANNOT_INHERIT, RC_HOLDRECORD_CANNOT_INHERIT,
                                     strLotHoldRequests[inheritCnt].holdType, strLotHoldRequests[inheritCnt].holdReasonCodeID.identifier,
                                     strLotHoldRequests[inheritCnt].holdUserID.identifier, strLotHoldRequests[inheritCnt].relatedLotID.identifier );
                return RC_HOLDRECORD_CANNOT_INHERIT;
            }
        }
    }
    else
    {
        if( inheritLen > 0 )
        {
            PPT_SET_MSG_RC_KEY4( strPartialReworkWithoutHoldReleaseReqResult, MSG_HOLDRECORD_CANNOT_INHERIT, RC_HOLDRECORD_CANNOT_INHERIT,
                                 strLotHoldRequests[0].holdType, strLotHoldRequests[0].holdReasonCodeID.identifier,
                                 strLotHoldRequests[0].holdUserID.identifier, strLotHoldRequests[0].relatedLotID.identifier );
            return RC_HOLDRECORD_CANNOT_INHERIT;
        }
    }
    //PSN000043987 Add End

    //===========================================================================
    // Preparation for change
    //===========================================================================
    //----- Decides Return Operation. -------//
    CORBA::String_var  returnOperationNumber;
    if( ( tmpRtnOpeNum != NULL ) && ( CIMFWStrLen( tmpRtnOpeNum ) !=0 ) )
    {
        returnOperationNumber = tmpRtnOpeNum;
    }
    else if( strPartialReworkReq.bDynamicRoute == TRUE )
    {
        if ( connectedRouteReturnOperationFlag == TRUE )
        {
            returnOperationNumber = strProcess_GetReturnOperation_out.operationNumber;
        }
        else
        {
            returnOperationNumber = strLot_currentOperationInfo_Get_out.operationNumber;
        }
    }
    else
    {
        returnOperationNumber = strProcess_GetReturnOperation_out.operationNumber;
    }

    //----- Gets all Operations on Parent Lot's Route. -------//
    pptRouteOperationListForLotInqResult  strRouteOperationListForLotInqResult;
    rc = txRouteOperationListForLotInq( strRouteOperationListForLotInqResult, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txRouteOperationListForLotInq() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strRouteOperationListForLotInqResult.strResult ;
        return rc;
    }

    //----- Check for the decided Return Operation : It should be exist. -------//
    CORBA::Long  routeOpeLen = strRouteOperationListForLotInqResult.strOperationNameAttributes.length();
    for( CORBA::Long  opeCnt = 0; opeCnt < routeOpeLen; opeCnt++ )
    {
        if( CIMFWStrCmp( strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber, returnOperationNumber ) == 0 )
        {
            PPT_METHODTRACE_V1("", "Return Operation is found.");
            break;
        }
        else if( opeCnt == routeOpeLen - 1 )
        {
            PPT_METHODTRACE_V2("", "Return Operation is Invelid!!! This is not on Parent Lot's Route.", returnOperationNumber );
            PPT_SET_MSG_RC_KEY( strPartialReworkWithoutHoldReleaseReqResult, MSG_NOT_FOUND_OPERATION, RC_NOT_FOUND_OPERATION, returnOperationNumber );
            return RC_NOT_FOUND_OPERATION;
        }
        else
        {
            PPT_METHODTRACE_V1("", strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber );
        }
    }

    PPT_METHODTRACE_V2("", "This is Return Operation which is used at after process.", returnOperationNumber );



    //===========================================================================
    // Change for objects
    //===========================================================================
    //-----------------------------------------------------------
    // Creates Child Lot
    //-----------------------------------------------------------
    objLot_SplitWaferLot_out  strLot_SplitWaferLot_out;
    rc = lot_SplitWaferLot( strLot_SplitWaferLot_out, strObjCommonIn, parentLotID, strPartialReworkReq.childWaferID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_SplitWaferLot() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_SplitWaferLot_out.strResult;
        return rc;
    }
    objectIdentifier  childLotID = strLot_SplitWaferLot_out.childLotID;
    strPartialReworkWithoutHoldReleaseReqResult.childLotID = strLot_SplitWaferLot_out.childLotID;

    //----- Updates History Time Stamp to Parent Lot : Those data are used in Event. -------//
    objLot_waferLotHistoryPointer_Update_out  strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update( strLot_waferLotHistoryPointer_Update_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() != RC_OK");
        SET_MSG_RC(strPartialReworkWithoutHoldReleaseReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return rc;
    }

    //----- Updates History Time Stamp to Child Lot : Those data are used in Event. -------//
    rc = lot_waferLotHistoryPointer_Update( strLot_waferLotHistoryPointer_Update_out, strObjCommonIn, childLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
        return rc;
    }

    //----- Prepares data of Split Event. -------//
    objLot_waferMap_Get_out  strLot_waferMap_Get_out;
    rc = lot_waferMap_Get( strLot_waferMap_Get_out, strObjCommonIn, childLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_waferMap_Get() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
        return rc;
    }
    CORBA::Long  waferLen = strLot_waferMap_Get_out.strLotWaferMap.length();

    //----- Makes Split Event. -------//
    pptNewLotAttributes  strNewLotAttributes;
    strNewLotAttributes.cassetteID = cassetteID;
    strNewLotAttributes.strNewWaferAttributes.length( waferLen );
    for( CORBA::Long  waferCnt = 0; waferCnt < waferLen; waferCnt++ )
    {
        strNewLotAttributes.strNewWaferAttributes[waferCnt].newLotID       = childLotID;
        strNewLotAttributes.strNewWaferAttributes[waferCnt].newWaferID     = strLot_waferMap_Get_out.strLotWaferMap[waferCnt].waferID;
        strNewLotAttributes.strNewWaferAttributes[waferCnt].newSlotNumber  = strLot_waferMap_Get_out.strLotWaferMap[waferCnt].slotNumber;
        strNewLotAttributes.strNewWaferAttributes[waferCnt].sourceLotID    = parentLotID;
        strNewLotAttributes.strNewWaferAttributes[waferCnt].sourceWaferID  = strLot_waferMap_Get_out.strLotWaferMap[waferCnt].waferID;
    }

    objLotWaferMoveEvent_Make_out  strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make( strLotWaferMoveEvent_Make_out, strObjCommonIn, "TXTRC073", strNewLotAttributes, claimMemo );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lotWaferMoveEvent_Make() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult;
        return rc;
    }

//PSN000081348 Add Start
    if ( inheritProcessHold == TRUE)
    {
        //-----------------------------------------------------------
        // Performs Process Hold to Child Lot
        //-----------------------------------------------------------
        pptHoldLotReqResult  strProcessHoldLotReqResult;
        rc = txHoldLotReq( strProcessHoldLotReqResult, strObjCommonIn, childLotID, procHoldReq );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK" );
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcessHoldLotReqResult.strResult;
            return rc;
        }
    }
//PSN000081348 Add End

    //-----------------------------------------------------------
    // Performs Rework to Child Lot
    //-----------------------------------------------------------
    //----- Check for Rework Count of Child Lot -------//
    if( strPartialReworkReq.bForceRework == FALSE )
    {
        objProcess_reworkCount_Check_out  strProcess_reworkCount_Check_out;
        rc = process_reworkCount_Check( strProcess_reworkCount_Check_out, strObjCommonIn, childLotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_reworkCount_Check() != RC_OK");
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_reworkCount_Check_out.strResult;
            return rc;
        }
    }

    //----- Increments Rework Count of Child Lot. -------//
    objProcess_reworkCount_Increment_out  strProcess_reworkCount_Increment_out;
    rc = process_reworkCount_Increment( strProcess_reworkCount_Increment_out, strObjCommonIn, childLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_reworkCount_Increment() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_reworkCount_Increment_out.strResult;
        return rc;
    }
//DSN000085792 Add start
    objQTime_CheckConditionForReplaceTarget_in strQTime_CheckConditionForReplaceTarget_in;
    objQTime_CheckConditionForReplaceTarget_out strQTime_CheckConditionForReplaceTarget_out;
    strQTime_CheckConditionForReplaceTarget_in.lotID = childLotID;
    rc = qTime_CheckConditionForReplaceTarget(strQTime_CheckConditionForReplaceTarget_out,strObjCommonIn,strQTime_CheckConditionForReplaceTarget_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "qTime_CheckConditionForReplaceTarget() != RC_OK") ;
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strQTime_CheckConditionForReplaceTarget_out.strResult ;
        return rc ;
    }
//DSN000085792 Add end
    //----- Moves Child Lot to Sub Route. -------//
    objProcess_BranchRoute_out  strProcess_BranchRoute_out;
    rc = process_BranchRoute( strProcess_BranchRoute_out, strObjCommonIn, childLotID, subRouteID, returnOperationNumber );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_BranchRoute() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_BranchRoute_out.strResult;
        return rc;
    }

    //----- Makes Branch Event. -------//
    objLotReworkEvent_Make_out  strLotReworkEvent_Make_out;
    rc = lotReworkEvent_Make( strLotReworkEvent_Make_out, strObjCommonIn, "TXTRC073", childLotID, strPartialReworkReq.reasonCodeID,
                              strProcess_BranchRoute_out.oldCurrentPOData, claimMemo );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lotReworkEvent_Make() rc != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLotReworkEvent_Make_out.strResult;
        SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_FAIL_MAKE_HISTORY, rc );
        return rc;
    }

    //-----------------------------------------------------------
    // Performs Rework Hold
    //-----------------------------------------------------------
    objectIdentifier  reasonCodeID;
    reasonCodeID.identifier = CIMFWStrDup( SP_Reason_ReworkHold );

    //----- Performs Rework Hold Request to Lot, which is on Return Point or more forward Operation. -------//
    CORBA::String_var  operationNumber = returnOperationNumber;                                                        //P6000544

    objProcess_CompareCurrent_out  strProcess_CompareCurrent_out;
    rc = process_CompareCurrent( strProcess_CompareCurrent_out, strObjCommonIn, parentLotID, subRouteID, returnOperationNumber );
    if( rc == RC_CURRENTOPERATION_SAME || rc == RC_CURRENTOPERATION_LATE )
    {
        operationNumber = strProcess_CompareCurrent_out.currentOperationNumber;                                        //P6000544

        //----- Performs Rework Hold Request to Parent Lot -------//
        pptHoldListSequence  strLotHoldReqList;
        strLotHoldReqList.length( 1 );
        strLotHoldReqList[0].holdType                   = CIMFWStrDup( SP_HoldType_ReworkHold );
        strLotHoldReqList[0].holdReasonCodeID           = reasonCodeID;
        strLotHoldReqList[0].holdUserID                 = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark   = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].routeID                    = subRouteID;
        strLotHoldReqList[0].operationNumber            = returnOperationNumber;
        strLotHoldReqList[0].relatedLotID               = childLotID;

        pptHoldLotReqResult  strHoldLotReqResult;
        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, parentLotID, strLotHoldReqList );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strHoldLotReqResult.strResult;
            return rc;
        }
    }
    else if( rc == RC_CURRENTOPERATION_EARLY )
    {
        PPT_METHODTRACE_V1("", "Parent Lot is on more backward Operation of Return Point.");
    }
    else
    {
        PPT_METHODTRACE_V1("", "process_CompareCurrent() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_CompareCurrent_out.strResult;
        return rc;
    }
    objectIdentifier  currentRouteID = strProcess_CompareCurrent_out.currentRouteID;

//DSIV00001830 add start
    //-------------------------
    // Check Bonding Group for childLot
    //-------------------------
    PPT_METHODTRACE_V2("", "strProcess_CompareCurrent_out.currentRouteID", strProcess_CompareCurrent_out.currentRouteID.identifier);
    PPT_METHODTRACE_V2("", "returnOperationNumber", returnOperationNumber);
//DSN000096135    rc  = process_OperationListForLot( strProcess_OperationListForLot_out,
//DSN000096135                                       strObjCommonIn,
//DSN000096135                                       TRUE,                   // search direction
//DSN000096135                                       TRUE,                   // posSearchFlag
//DSN000096135                                       9999,                   // search count
//DSN000096135                                       currentRouteID,         // search routeID
//DSN000096135                                       returnOperationNumber,  // search operation Number
//DSN000096135                                       TRUE,                   // currentFlag
//DSN000096135                                       parentLotID );
//DSN000096135 add start
//DSN000104277    objProcess_OperationListForLot_in__160 strProcess_OperationListForLot_in_1;
//DSN000104277    strProcess_OperationListForLot_in_1.searchDirection           = TRUE;
//DSN000104277    strProcess_OperationListForLot_in_1.posSearchFlag             = TRUE;
//DSN000104277    strProcess_OperationListForLot_in_1.searchCount               = 9999;
//DSN000104277    strProcess_OperationListForLot_in_1.searchRouteID             = currentRouteID;
//DSN000104277    strProcess_OperationListForLot_in_1.searchOperationNumber     = CIMFWStrDup(returnOperationNumber);
//DSN000104277    strProcess_OperationListForLot_in_1.currentFlag               = TRUE;
//DSN000104277    strProcess_OperationListForLot_in_1.lotID                     = parentLotID;
//DSN000104277    rc = process_OperationListForLot__160(strProcess_OperationListForLot_out, strObjCommonIn, strProcess_OperationListForLot_in_1);
//DSN000096135 add end
//DSN000104277 add start
    objProcess_OperationProcessRefListForLot_in strProcess_OperationProcessRefListForLot_in_1;
    strProcess_OperationProcessRefListForLot_in_1.searchDirection           = TRUE;
    strProcess_OperationProcessRefListForLot_in_1.posSearchFlag             = TRUE;
    strProcess_OperationProcessRefListForLot_in_1.searchCount               = 9999;
    strProcess_OperationProcessRefListForLot_in_1.searchRouteID             = currentRouteID;
    strProcess_OperationProcessRefListForLot_in_1.searchOperationNumber     = CIMFWStrDup(returnOperationNumber);
    strProcess_OperationProcessRefListForLot_in_1.currentFlag               = TRUE;
    strProcess_OperationProcessRefListForLot_in_1.lotID                     = parentLotID;
    rc = process_OperationProcessRefListForLot(strProcess_OperationProcessRefListForLot_out, strObjCommonIn, strProcess_OperationProcessRefListForLot_in_1);
//DSN000104277 add end
    if( rc != RC_OK )
    {
//DSN000096135        PPT_METHODTRACE_V1("", "process_OperationListForLot() != RC_OK") ;
//DSN000104277        PPT_METHODTRACE_V1("", "process_OperationListForLot__160() != RC_OK") ;  //DSN000096135
//DSN000104277        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_OperationListForLot_out.strResult;
        PPT_METHODTRACE_V1("", "process_OperationProcessRefListForLot() != RC_OK") ;                                      //DSN000104277
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcess_OperationProcessRefListForLot_out.strResult;   //DSN000104277
        return rc;
    }
//DSN000104277    CORBA::ULong operationCountForLot = strProcess_OperationListForLot_out.strOperationNameAttributes.length();
    CORBA::ULong operationCountForLot = strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes.length();    //DSN000104277
    if( operationCountForLot >= 1 )
    {
        objLot_bondingFlowSection_CheckLocate_out strLot_bondingFlowSection_CheckLocate_out;
        rc = lot_bondingFlowSection_CheckLocate( strLot_bondingFlowSection_CheckLocate_out,
                                                 strObjCommonIn,
                                                 strLot_SplitWaferLot_out.childLotID,
                                                 strProcess_OperationProcessRefListForLot_out.strOperationProcessRefListAttributes[operationCountForLot-1].processRef );   //DSN000104277
//DSN000104277                                                 strProcess_OperationListForLot_out.strOperationNameAttributes[operationCountForLot-1].processRef );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_bondingFlowSection_CheckLocate() rc != RC_OK");
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_bondingFlowSection_CheckLocate_out.strResult;
            return rc;
        }
    }
//DSIV00001830 add end

    //----- Creates Rework Hold Request of Parent Lot -------//
    pptEnhancedFutureHoldReqResult  strEnhancedFutureHoldReqResult;
    rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult, strObjCommonIn, SP_HoldType_ReworkHold, parentLotID,
                                  currentRouteID, operationNumber, reasonCodeID, childLotID, FALSE, FALSE, NULL );     //P6000544
//P6000544                                  currentRouteID, returnOperationNumber, reasonCodeID, childLotID, FALSE, FALSE, NULL );
    // rc = txEnhancedFutureHoldReq( returnStructure, commonInfo, holdType, lotID,
    //                               routeID, operationNumber, reasonCodeID, relatedLotID, postFlag, singleTriggerFlag, claimMemo );
    if( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
    {
        PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
        return rc;
    }

    //----- Creates Rework Hold Request of Child Lot -------//
    rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult, strObjCommonIn, SP_HoldType_ReworkHold, childLotID,
                                  currentRouteID, operationNumber, reasonCodeID, parentLotID, FALSE, FALSE, NULL );    //P6000544
//P6000544                                  currentRouteID, returnOperationNumber, reasonCodeID, parentLotID, FALSE, FALSE, NULL );
    // rc = txEnhancedFutureHoldReq( returnStructure, commonInfo, holdType, lotID,
    //                               routeID, operationNumber, reasonCodeID, relatedLotID, postFlag, singleTriggerFlag, claimMemo );
    if( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
    {
        PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
        return rc;
    }

    //-----------------------------------------------------------
    // Performs Process Hold to Child Lot
    //-----------------------------------------------------------
    pptProcessHoldExecReqResult  strProcessHoldExecReqResult_Child;
    rc = txProcessHoldExecReq( strProcessHoldExecReqResult_Child, strObjCommonIn, childLotID, claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","txProcessHoldExecReq() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strProcessHoldExecReqResult_Child.strResult;
        return rc;
    }

    //-----------------------------------------------------------
    // Inherits Hold Records to Child Lot
    //-----------------------------------------------------------
//PSN000081348    if( strLotHoldRequests.length() > 0 )
    if( holdReqWithoutProcHold.length() > 0 ) //PSN000081348
    {
        pptHoldLotReqResult  strHoldLotReqResult_inheritance;
//PSN000081348        rc = txHoldLotReq( strHoldLotReqResult_inheritance, strObjCommonIn, childLotID, strLotHoldRequests );
        rc = txHoldLotReq( strHoldLotReqResult_inheritance, strObjCommonIn, childLotID, holdReqWithoutProcHold ); //PSN000081348
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK" );
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strHoldLotReqResult_inheritance.strResult;
            return rc;
        }
    }

//DSN000071674 add start
    if ( TRUE == updateControlJobFlag )
    {
        //----------------------
        // Update control Job Info and
        // Machine Cassette info if information exist
        //----------------------
        objectIdentifierSequence tmpCassetteIDSeq;
        tmpCassetteIDSeq.length(1);
        tmpCassetteIDSeq[0] = cassetteID;
        objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
        rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                           tmpCassetteIDSeq);
        if (rc)
        {
            PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
            return(rc);
        }
    }
//DSN000071674 add end

    //-----------------------------------------------------------
    // Updates Cassette's Multi Lot Type
    //-----------------------------------------------------------
    objCassette_multiLotType_Update_out  strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn, cassetteID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
        return rc;
    }

    //-----------------------------------------------------------
    // Updates Child Lot's Required Cassette Category
    //-----------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out  strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out, strObjCommonIn, childLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl() != RC_OK");
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }

//INN-R170002 add start
    //------------------------------------------------------------------------
    //   Check contamination information for newly created lot
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check contamination information");

    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    csObjLot_ContaminationInfo_CheckForMove_in  strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = childLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = strLot_cassette_Get_out.cassetteID;

    rc = cs_lot_ContaminationInfo_CheckForMove(strLot_ContaminationInfo_CheckForMove_out, strObjCommonIn,
                                 strLot_ContaminationInfo_CheckForMove_in); 
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForMove() rc != RC_OK",rc);
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return(rc);
    }
    if (TRUE == strLot_ContaminationInfo_CheckForMove_out.holdReqFlag)
    {
        PPT_METHODTRACE_V1("", "strLot_ContaminationInfo_CheckForMove_out.holdReqFlag= TRUE");
        pptHoldListSequence strLotHoldReqList;
        strLotHoldReqList.length( 1 );
        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = claimMemo;

        pptHoldLotReqResult strHoldLotReqResult;
        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           childLotID,
                           strLotHoldReqList );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strPartialReworkWithoutHoldReleaseReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 add end

//DSN000085792 Add Start
    //-----------------------------------------------------------
    // Replace Target Operation for rework route
    //-----------------------------------------------------------
    objQTime_targetOpe_Replace_out strQTime_targetOpe_Replace_out;
    objQTime_targetOpe_Replace_in  strQTime_targetOpe_Replace_in;
    strQTime_targetOpe_Replace_in.lotID               = childLotID;
    strQTime_targetOpe_Replace_in.specificControlFlag = FALSE;
    rc = qTime_targetOpe_Replace( strQTime_targetOpe_Replace_out,
                                  strObjCommonIn,
                                  strQTime_targetOpe_Replace_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "qTime_targetOpe_Replace() != RC_OK", rc);
        strPartialReworkWithoutHoldReleaseReqResult.strResult = strQTime_targetOpe_Replace_out.strResult;
        return rc;
    }
//DSN000085792 Add End

    SET_MSG_RC( strPartialReworkWithoutHoldReleaseReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txPartialReworkWithoutHoldReleaseReq");
    return RC_OK;
}