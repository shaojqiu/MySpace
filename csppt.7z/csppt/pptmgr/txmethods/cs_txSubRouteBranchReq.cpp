// @(#) 1.3 superpos/src/csppt/source/posppt/pptmgr/txmethods/cs_txSubRouteBranchReq.cpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:16:14 [ 6/9/03 14:16:15 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_txSubRouteBranchReq.cpp
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//


#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txSubRouteBranchReq()
//
// Change history:
// Date       Defect#   Person        Comments
// ---------- --------  ------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami      eBrokerMigration.
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txSubRouteBranchReq (pptSubRouteBranchReqResult& strSubRouteBranchReqResult,
                                               const pptObjCommonIn& strObjCommonIn,
                                               const objectIdentifier& lotID,
                                               const objectIdentifier& currentRouteID,
                                               const char * currentOperationNumber,
                                               const objectIdentifier& subRouteID,
                                               const char * returnOperationNumber,
                                               const char * claimMemo    //D6000025
                                               CORBAENV_LAST_CPP)        //D6000025
                                             //D6000025  const char * claimMemo,
                                             //D6000025  CORBA::Environment &IT_env)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txSubRouteBranchReq") ;

    CORBA::Long rc = RC_OK ;
    pptBranchReq strBranchReq;
    strBranchReq.lotID                 = lotID;
    strBranchReq.subRouteID            = subRouteID;
    strBranchReq.returnOperationNumber = returnOperationNumber;
    strBranchReq.eventTxId             = strObjCommonIn.strUser.functionID;
    strBranchReq.bDynamicRoute         = False;
    strBranchReq.currentRouteID        = currentRouteID;
    strBranchReq.currentOperationNumber= currentOperationNumber;

    if( 0 != CIMFWStrCmp( strObjCommonIn.strUser.userID.identifier, "test user" ) )
    {

    pptBranchReqResult strBranchReqResult;
    rc = txBranchReq( strBranchReqResult,
                      strObjCommonIn,
                      strBranchReq,
                      claimMemo);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txSubRouteBranchReq", "txBranchReq() != RC_OK", rc);
        strSubRouteBranchReqResult.strResult = strBranchReqResult.strResult ;
        return( rc );
    }
 
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strSubRouteBranchReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txSubRouteBranchReq") ;
    return(RC_OK);
}

