//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txBWSWaferOutAndSTBReq.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"

// Class: CS_PPTManager
//
// Service: cs_txBWSWaferOutAndSTBReq()
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/20 INN-R170016  JJ.Zhang       Equipment Monitor customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     csBWSWaferOutAndSTBReqResult& strBWSWaferOutAndSTBReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txBWSWaferOutAndSTBReq (csBWSWaferOutAndSTBReqResult& strBWSWaferOutAndSTBReqResult,
                                                        const pptObjCommonIn& strObjCommonIn,
                                                        const csBWSWaferOutAndSTBReqInParm& strBWSWaferOutAndSTBReqInParm,
                                                        const char* claimMemo
                                                        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txBWSWaferOutAndSTBReq")
    char* methodName = NULL;
    CORBA::Long rc = RC_OK ;

    CORBA::Long i=0, j=0, k=0;
    CORBA::Long nBWSLen = 0;

    //-------------------------------------------------------------
    // Get monitor product setting and source product per NPW type
    //-------------------------------------------------------------
    csObjEqpMonitor_list_GetDR_out strEqpMonitor_list_GetDR_out;
    csEqpMonitorInventoryInfoSequence strEqpMonitorInventoryInfoSeq;
    CORBA::Long nProdLen = 0;
    CORBA::Long nPortLen = 0;
    csAutoBWSOutProductInfoSequence strAutoBWSOutProductInfos;
    strAutoBWSOutProductInfos.length(0);
    stringSequence strOrgBWSIDSeq;
    stringSequence BWSIDs;
    BWSIDs.length(0);
    CORBA::String_var requiredCarrierCategory;

    PPT_METHODTRACE_V2("", "npwType", strBWSWaferOutAndSTBReqInParm.npwType);
    if( 0 == CIMFWStrCmp(strBWSWaferOutAndSTBReqInParm.npwType, CS_EqpMonitor_NPW_Type_Monitor))
    {
        PPT_METHODTRACE_V2("", "eqpMonitorID", strBWSWaferOutAndSTBReqInParm.eqpMonitorID.identifier);
        //----------------------------------------------------------------
        //  Get EqpMonitor information from DB
        //----------------------------------------------------------------
        objEqpMonitor_list_GetDR_in  strEqpMonitor_list_GetDR_in;
        strEqpMonitor_list_GetDR_in.eqpMonitorID = strBWSWaferOutAndSTBReqInParm.eqpMonitorID;
        rc = cs_eqpMonitor_list_GetDR( strEqpMonitor_list_GetDR_out,
                                    strObjCommonIn,
                                    strEqpMonitor_list_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_eqpMonitor_list_GetDR() != RC_OK", rc);
            strBWSWaferOutAndSTBReqResult.strResult = strEqpMonitor_list_GetDR_out.strResult;
            return rc;
        }
        CORBA::Long nTmpLen = strEqpMonitor_list_GetDR_out.strEqpMonitorDetailInfoSeq.length();
        PPT_METHODTRACE_V2("", "strEqpMonitorDetailInfoSeq.length", nTmpLen);
        if( 0 == nTmpLen)
        {
            PPT_METHODTRACE_V1("", "Input parameter eqpMonitorID is invalid");
            PPT_SET_MSG_RC_KEY( strBWSWaferOutAndSTBReqResult,
                                MSG_NOT_FOUND_EQPMONITOR,
                                RC_NOT_FOUND_EQPMONITOR,
                                strBWSWaferOutAndSTBReqInParm.eqpMonitorID.identifier );
            return RC_NOT_FOUND_EQPMONITOR;
        }
        pptEqpMonitorProductInfoSequence& strEqpMonitorProductInfoSeq = strEqpMonitor_list_GetDR_out.strEqpMonitorDetailInfoSeq[0].strEqpMonitorProductInfoSeq;
        nProdLen = strEqpMonitorProductInfoSeq.length();
        PPT_METHODTRACE_V2("", "strEqpMonitorProductInfoSeq.length", nProdLen);

        strEqpMonitorInventoryInfoSeq.length(nProdLen);
        strOrgBWSIDSeq.length(nProdLen);
        strAutoBWSOutProductInfos.length(nProdLen);

        //---------------------------------------------
        // Get monitor product setting info for every
        // product used in this EQP Monitor Task
        //---------------------------------------------
        for( i=0; i<nProdLen; i++)
        {
            csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
            strEqpMonitorInventory_ListGetDR_in.npwType = strBWSWaferOutAndSTBReqInParm.npwType;
            strEqpMonitorInventory_ListGetDR_in.productID = strEqpMonitorProductInfoSeq[i].productID.identifier;
            PPT_METHODTRACE_V2("", "npwType", strEqpMonitorInventory_ListGetDR_in.npwType);
            PPT_METHODTRACE_V2("", "productID", strEqpMonitorInventory_ListGetDR_in.productID);

            csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
            rc = cs_eqpMonitorInventory_ListGetDR(strEqpMonitorInventory_ListGetDR_out,
                                         strObjCommonIn,
                                         strEqpMonitorInventory_ListGetDR_in) ;
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_ListGetDR() rc != RC_OK")
                strBWSWaferOutAndSTBReqResult.strResult = strEqpMonitorInventory_ListGetDR_out.strResult ;
                return rc ;
            }
            nTmpLen = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length();
            if( 0 == nTmpLen)
            {
                PPT_METHODTRACE_V1("", "not valid strEqpMonitorInventoryInfoSeq.length" );
                CS_PPT_SET_MSG_RC_KEY1( strBWSWaferOutAndSTBReqResult,
                                        CS_MSG_NOT_FOUND_EQPMONITOR_INVENTORY_INFO,
                                        CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO,
                                        strEqpMonitorProductInfoSeq[i].productID.identifier );
                return CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO;
            }
            strEqpMonitorInventoryInfoSeq[i] = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq[0];
            strOrgBWSIDSeq[i] = strEqpMonitorInventoryInfoSeq[i].startBWSID;

            strAutoBWSOutProductInfos[i].productID   = strEqpMonitorProductInfoSeq[i].productID;
            strAutoBWSOutProductInfos[i].requiredQty = strEqpMonitorProductInfoSeq[i].waferCount;
            strAutoBWSOutProductInfos[i].subLotType  = strEqpMonitorInventoryInfoSeq[i].subLotType;
            strAutoBWSOutProductInfos[i].bankID.identifier = strEqpMonitorInventoryInfoSeq[i].startBankID;

            //---------------------------------------------
            // Get requiredCarrierCategory of 1st operation
            //---------------------------------------------
            PPT_METHODTRACE_V2("", "call cs_route_requiredCarrierCategory_GetDR", strEqpMonitorInventoryInfoSeq[i].routeID);

            csObjRoute_requiredCarrierCategory_GetDR_in strRoute_requiredCarrierCategory_GetDR_in;
            strRoute_requiredCarrierCategory_GetDR_in.routeID.identifier = strEqpMonitorInventoryInfoSeq[i].routeID;

            csObjRoute_requiredCarrierCategory_GetDR_out strRoute_requiredCarrierCategory_GetDR_out;
            rc = cs_route_requiredCarrierCategory_GetDR(strRoute_requiredCarrierCategory_GetDR_out,
                                                        strObjCommonIn,
                                                        strRoute_requiredCarrierCategory_GetDR_in) ;
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_ListGetDR() rc != RC_OK")
                strBWSWaferOutAndSTBReqResult.strResult = strRoute_requiredCarrierCategory_GetDR_out.strResult ;
                return rc ;
            }
            if (CIMFWStrLen(requiredCarrierCategory) == 0)
            {
                requiredCarrierCategory = strRoute_requiredCarrierCategory_GetDR_out.requiredCarrierCategory;
            }
            PPT_METHODTRACE_V2("", "requiredCarrierCategory", requiredCarrierCategory );

            if( CIMFWStrLen(strRoute_requiredCarrierCategory_GetDR_out.requiredCarrierCategory) > 0 &&
                CIMFWStrCmp(strRoute_requiredCarrierCategory_GetDR_out.requiredCarrierCategory, requiredCarrierCategory) != 0 )
            {
                PPT_METHODTRACE_V1("", "not same requiredCarrierCategory" );
                CS_PPT_SET_MSG_RC_KEY1( strBWSWaferOutAndSTBReqResult,
                                        CS_MSG_NOT_SAME_CARRIER_CATEGOPRY,
                                        CS_RC_NOT_SAME_CARRIER_CATEGOPRY,
                                        strEqpMonitorProductInfoSeq[i].productID.identifier );
                return CS_RC_NOT_SAME_CARRIER_CATEGOPRY;
            }
        }
    }
    else if( 0 == CIMFWStrCmp(strBWSWaferOutAndSTBReqInParm.npwType, CS_EqpMonitor_NPW_Type_PreProcess)
          || 0 == CIMFWStrCmp(strBWSWaferOutAndSTBReqInParm.npwType, CS_EqpMonitor_NPW_Type_Recycle) )
    {
        PPT_METHODTRACE_V1("", "npwType is not Monitor" );

        strEqpMonitorInventoryInfoSeq.length(1);
        strOrgBWSIDSeq.length(1);
        //---------------------------------------------
        // Get monitor product setting info
        //---------------------------------------------
        csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
        strEqpMonitorInventory_ListGetDR_in.npwType = strBWSWaferOutAndSTBReqInParm.npwType;
        strEqpMonitorInventory_ListGetDR_in.productID = strBWSWaferOutAndSTBReqInParm.productID.identifier;

        csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
        rc = cs_eqpMonitorInventory_ListGetDR(strEqpMonitorInventory_ListGetDR_out,
                                     strObjCommonIn,
                                     strEqpMonitorInventory_ListGetDR_in) ;

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_ListGetDR() rc != RC_OK")
            strBWSWaferOutAndSTBReqResult.strResult = strEqpMonitorInventory_ListGetDR_out.strResult ;
            return rc ;
        }
        CORBA::Long nLen = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length();
        PPT_METHODTRACE_V2("", "strEqpMonitorInventoryInfoSeq.length", nLen );

        if( 0 == nLen)
        {
            PPT_METHODTRACE_V1("", "not valid strEqpMonitorInventoryInfoSeq.length" );
            CS_PPT_SET_MSG_RC_KEY1( strBWSWaferOutAndSTBReqResult,
                                    CS_MSG_NOT_FOUND_EQPMONITOR_INVENTORY_INFO,
                                    CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO,
                                    strBWSWaferOutAndSTBReqInParm.productID.identifier );
            return CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO;
        }
        strEqpMonitorInventoryInfoSeq[0] = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq[0];
        strOrgBWSIDSeq[0] = strEqpMonitorInventoryInfoSeq[0].startBWSID;

        strAutoBWSOutProductInfos.length(1);
        strAutoBWSOutProductInfos[0].requiredQty = SP_Cassette_Default_Capacity; //25
        strAutoBWSOutProductInfos[0].productID.identifier  = strEqpMonitorInventoryInfoSeq[0].productID;
        strAutoBWSOutProductInfos[0].subLotType = strEqpMonitorInventoryInfoSeq[0].subLotType;
        strAutoBWSOutProductInfos[0].bankID.identifier = strEqpMonitorInventoryInfoSeq[0].startBankID;
        //---------------------------------------------
        // Get requiredCarrierCategory of 1st operation
        //---------------------------------------------
        csObjRoute_requiredCarrierCategory_GetDR_in strRoute_requiredCarrierCategory_GetDR_in;
        strRoute_requiredCarrierCategory_GetDR_in.routeID.identifier = strEqpMonitorInventoryInfoSeq[0].routeID;

        csObjRoute_requiredCarrierCategory_GetDR_out strRoute_requiredCarrierCategory_GetDR_out;
        rc = cs_route_requiredCarrierCategory_GetDR(strRoute_requiredCarrierCategory_GetDR_out,
                                                    strObjCommonIn,
                                                    strRoute_requiredCarrierCategory_GetDR_in) ;
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_ListGetDR() rc != RC_OK")
            strBWSWaferOutAndSTBReqResult.strResult = strRoute_requiredCarrierCategory_GetDR_out.strResult ;
            return rc ;
        }
        requiredCarrierCategory = strRoute_requiredCarrierCategory_GetDR_out.requiredCarrierCategory;
        PPT_METHODTRACE_V2("", "requiredCarrierCategory", requiredCarrierCategory );
    }
    else
    {
        PPT_METHODTRACE_V2("", "npwType !=PreProcess or Recycle", strBWSWaferOutAndSTBReqInParm.npwType );
        SET_MSG_RC(strBWSWaferOutAndSTBReqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER);
        return RC_INVALID_PARAMETER;
    }

    //---------------------------------------------
    // Get same BWSIDs used by all products
    //---------------------------------------------
    if( CIMFWStrLen(strBWSWaferOutAndSTBReqInParm.BWSID.identifier) > 0 )
    {
        BWSIDs.length(1);
        BWSIDs[0] = strBWSWaferOutAndSTBReqInParm.BWSID.identifier;
        PPT_METHODTRACE_V2("", "BWSIDs", BWSIDs[0]);

        //Check BWS usage type
        csObjEquipment_udata_GetDR_in strObjEquipment_udata_GetDR_in;
        strObjEquipment_udata_GetDR_in.udataName.length(1);
        strObjEquipment_udata_GetDR_in.udataName[0] = CIMFWStrDup(CS_S_EQP_BWSUsageType);
        strObjEquipment_udata_GetDR_in.equipmentID = strBWSWaferOutAndSTBReqInParm.BWSID;

        csObjEquipment_udata_GetDR_out strObjEquipment_udata_GetDR_out;
        rc = cs_equipment_udata_GetDR( strObjEquipment_udata_GetDR_out,
                                   strObjCommonIn,
                                   strObjEquipment_udata_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_equipment_udata_GetDR() != RC_OK", rc);
            strBWSWaferOutAndSTBReqResult.strResult = strObjEquipment_udata_GetDR_out.strResult;
            return rc;
        }

        if( 0 <  strObjEquipment_udata_GetDR_out.udataValue.length()
         && 0 == CIMFWStrCmp(strObjEquipment_udata_GetDR_out.udataValue[0], CS_ProductCategory_Production) )
        {
            PPT_METHODTRACE_V1("", "BWSUsageType =  Production" );
            CS_PPT_SET_MSG_RC_KEY1( strBWSWaferOutAndSTBReqResult,
                                    CS_MSG_INVALID_BWS_USAGETYPE,
                                    CS_RC_INVALID_BWS_USAGETYPE,
                                    strObjEquipment_udata_GetDR_out.udataValue[0] );
            return CS_RC_INVALID_BWS_USAGETYPE;
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "BWSID no input");
        csObjNPW_sameBWSID_Get_in strNPW_sameBWSID_Get_in;
        strNPW_sameBWSID_Get_in.strOrgBWSIDSeq = strOrgBWSIDSeq;

        csObjNPW_sameBWSID_Get_out strNPW_sameBWSID_Get_out;
        rc = cs_NPW_sameBWSID_Get( strNPW_sameBWSID_Get_out,
                                   strObjCommonIn,
                                   strNPW_sameBWSID_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_NPW_sameBWSID_Get() != RC_OK", rc);
            strBWSWaferOutAndSTBReqResult.strResult = strNPW_sameBWSID_Get_out.strResult;
            return rc;
        }
        BWSIDs = strNPW_sameBWSID_Get_out.BWSIDs;
    }
    nBWSLen = BWSIDs.length();
    PPT_METHODTRACE_V2("", "BWSIDs.length", nBWSLen);

    //---------------------------------------------
    // Get empty carrier
    //---------------------------------------------
    objectIdentifier emptyCarrierID;
    if( CIMFWStrLen(strBWSWaferOutAndSTBReqInParm.carrierID.identifier) > 0 )
    {
        emptyCarrierID = strBWSWaferOutAndSTBReqInParm.carrierID;
        PPT_METHODTRACE_V2("", "emptyCarrierID", emptyCarrierID.identifier);
    }
    else
    {
        PPT_METHODTRACE_V1("", "call cs_NPW_emptyCarrier_Pickup");
        //---------------------------------------------
        // Pick Up target empty carrier
        //---------------------------------------------
        csObjNPW_emptyCarrier_Pickup_in  strNPW_emptyCarrier_Pickup_in;
        strNPW_emptyCarrier_Pickup_in.cassetteCategory = requiredCarrierCategory;

        csObjNPW_emptyCarrier_Pickup_out strNPW_emptyCarrier_Pickup_out;
        rc = cs_NPW_emptyCarrier_Pickup( strNPW_emptyCarrier_Pickup_out,
                                         strObjCommonIn,
                                         strNPW_emptyCarrier_Pickup_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "RC_OK != cs_NPW_emptyCarrier_Pickup()");
            strBWSWaferOutAndSTBReqResult.strResult = strNPW_emptyCarrier_Pickup_out.strResult;
            return( rc );
        }
        emptyCarrierID = strNPW_emptyCarrier_Pickup_out.carrierID;
        PPT_METHODTRACE_V2("", "Pick up emptyCarrierID", emptyCarrierID.identifier);
    }

    //---------------------------------------------
    // Loop for each BWS, to check wheter we can collect enough source wafers for every used product.
    // And make sure the empty carrier is with correct carrier category to be loaded on BWS.
    //---------------------------------------------
    CORBA::Boolean bFoundBWS = FALSE;
    CORBA::Boolean bFoundBWSPort = FALSE;
    CORBA::Boolean bEnoughQty = FALSE;
    objectIdentifier targetBWSID;
    pptEqpPortStatus targetEqpPort;
    csBWSWaferDataSequence strBWSWaferDataSeq;
    strBWSWaferDataSeq.length(0);
    for( i=0; i<nBWSLen; i++)
    {
        PPT_METHODTRACE_V2("", "get CS_S_EQP_BWSUsageType", BWSIDs[i]);
        //Check BWS usage type
        csObjEquipment_udata_GetDR_in strObjEquipment_udata_GetDR_in;
        strObjEquipment_udata_GetDR_in.udataName.length(1);
        strObjEquipment_udata_GetDR_in.udataName[0] = CIMFWStrDup(CS_S_EQP_BWSUsageType);
        strObjEquipment_udata_GetDR_in.equipmentID.identifier = BWSIDs[i];

        csObjEquipment_udata_GetDR_out strObjEquipment_udata_GetDR_out;
        rc = cs_equipment_udata_GetDR( strObjEquipment_udata_GetDR_out,
                                   strObjCommonIn,
                                   strObjEquipment_udata_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_equipment_udata_GetDR() != RC_OK", rc);
            strBWSWaferOutAndSTBReqResult.strResult = strObjEquipment_udata_GetDR_out.strResult;
            return rc;
        }
        if( 0 <  strObjEquipment_udata_GetDR_out.udataValue.length()
         && 0 == CIMFWStrCmp(strObjEquipment_udata_GetDR_out.udataValue[0], CS_ProductCategory_Production) )
        {
            PPT_METHODTRACE_V2("", "EQP_BWSUsageType is Production, skip", BWSIDs[i]);
            //not for NPW purpose
            continue;
        }

        //---------------------------------------------
        // Get source wafer info for every used product
        //---------------------------------------------
        PPT_METHODTRACE_V1("", "call cs_NPW_sourceWaferInfo_GetDR");
        csObjNPW_sourceWaferInfo_GetDR_in strNPW_sourceWaferInfo_GetDR_in;
        strNPW_sourceWaferInfo_GetDR_in.strAutoBWSOutProductInfos = strAutoBWSOutProductInfos;
        strNPW_sourceWaferInfo_GetDR_in.BWSID = BWSIDs[i];

        csObjNPW_sourceWaferInfo_GetDR_out strNPW_sourceWaferInfo_GetDR_out;
        rc = cs_NPW_sourceWaferInfo_GetDR(strNPW_sourceWaferInfo_GetDR_out,
                                          strObjCommonIn,
                                          strNPW_sourceWaferInfo_GetDR_in) ;

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_NPW_sourceWaferInfo_GetDR() rc != RC_OK")
            strBWSWaferOutAndSTBReqResult.strResult = strNPW_sourceWaferInfo_GetDR_out.strResult ;
            return rc ;
        }
        if( !strNPW_sourceWaferInfo_GetDR_out.enoughQty && !strBWSWaferOutAndSTBReqInParm.forceExecute)
        {
            PPT_METHODTRACE_V2("", "could not collected enough source wafers in BWS", BWSIDs[i] );
            continue;
        }
        bEnoughQty = TRUE;
        strBWSWaferDataSeq = strNPW_sourceWaferInfo_GetDR_out.strBWSWaferDataSeq;

        //---------------------------------------------
        // Get BWS Port Info
        //---------------------------------------------
        objectIdentifier equipmentID;
        equipmentID.identifier = BWSIDs[i];
        PPT_METHODTRACE_V2( "", "Get available port for", equipmentID.identifier );

        objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
        rc = equipment_portInfo_GetDR( strEquipment_portInfo_GetDR_out, strObjCommonIn, equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "equipment_portInfo_GetDR rc = ", rc );
            strBWSWaferOutAndSTBReqResult.strResult = strEquipment_portInfo_GetDR_out.strResult;
            return (rc);
        }
        pptEqpPortStatusSequence& strEqpPortStatus = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus;

        nPortLen = strEqpPortStatus.length();
        PPT_METHODTRACE_V2( "", "nPortLen", nPortLen );

        if( CIMFWStrLen(strBWSWaferOutAndSTBReqInParm.BWSID.identifier) > 0 && CIMFWStrLen(strBWSWaferOutAndSTBReqInParm.portID.identifier) > 0 )
        {
            PPT_METHODTRACE_V2( "", "portID", strBWSWaferOutAndSTBReqInParm.portID.identifier );
            for( j=0; j<nPortLen; j++ )
            {
                if( 0 == CIMFWStrCmp(strBWSWaferOutAndSTBReqInParm.portID.identifier, strEqpPortStatus[j].portID.identifier))
                {
                    targetEqpPort = strEqpPortStatus[j];
                    bFoundBWSPort = TRUE;
                    break;
                }
            }
            PPT_METHODTRACE_V3( "", "bFoundBWSPort", equipmentID.identifier, bFoundBWSPort );
        }
        else
        {
            PPT_METHODTRACE_V2( "", "portID is not specified on ", equipmentID.identifier );
            for( j=0; j<nPortLen; j++ )
            {
                //get the port with accessMode=auto and requiredCarrierCategory
                PPT_METHODTRACE_V2( "", "port accessMode", strEqpPortStatus[j].accessMode );
                if(CIMFWStrCmp(strEqpPortStatus[j].accessMode, SP_Eqp_AccessMode_Auto) != 0)
                {
                    //not auto access port
                    continue;
                }
                if(CIMFWStrCmp(strEqpPortStatus[j].portState, SP_PortRsc_PortState_LoadReq) != 0)
                {
                    //not LoadReq port
                    PPT_METHODTRACE_V2("", "portState is not LoadReq", strEqpPortStatus[j].portState);
                    continue;
                }
                if( CIMFWStrLen(strEqpPortStatus[j].loadResrvedCassetteID.identifier) > 0 )
                {
                    //reserved by others
                    PPT_METHODTRACE_V2("", "reserved for CassetteID", strEqpPortStatus[j].loadResrvedCassetteID.identifier);
                    continue;
                }

                CORBA::Long nCasCategoryLen = strEqpPortStatus[j].cassetteCategoryCapability.length();
                PPT_METHODTRACE_V2( "", "Length of Cassette Category Capability", nCasCategoryLen );
                if( CIMFWStrLen(requiredCarrierCategory) == 0 || nCasCategoryLen == 0 )
                {
                    bFoundBWSPort = TRUE;
                }

                PPT_METHODTRACE_V2( "", "requiredCarrierCategory", requiredCarrierCategory );

                for(k=0; k<nCasCategoryLen; k++)
                {
                    if(CIMFWStrCmp(strEqpPortStatus[j].cassetteCategoryCapability[k], requiredCarrierCategory) == 0)
                    {
                        bFoundBWSPort = TRUE;
                        break;
                    }
                }
                if(bFoundBWSPort)
                {
                    PPT_METHODTRACE_V2( "", "Found port", strEqpPortStatus[j].portID.identifier );
                    targetEqpPort = strEqpPortStatus[j];
                    break;
                }
                PPT_METHODTRACE_V2( "", "CarrierCategory not matched", strEqpPortStatus[j].portID.identifier );
            }
            PPT_METHODTRACE_V3( "", "bFoundBWSPort", equipmentID.identifier, bFoundBWSPort );
        }
        if(!bFoundBWSPort)
        {
            PPT_METHODTRACE_V2( "", "Not found port", equipmentID.identifier );
            continue;
        }

        bFoundBWS = TRUE;
        targetBWSID = equipmentID;
        break;
    }

    if( !bFoundBWS )
    {
        PPT_METHODTRACE_V1("", "could not collected enough source wafers by BWS." );
        CORBA::String tmpMsgId;
        if( 0 == CIMFWStrCmp(strBWSWaferOutAndSTBReqInParm.npwType, CS_EqpMonitor_NPW_Type_PreProcess)
         || 0 == CIMFWStrCmp(strBWSWaferOutAndSTBReqInParm.npwType, CS_EqpMonitor_NPW_Type_Recycle) )
         {
            tmpMsgId = CIMFWStrDup(strBWSWaferOutAndSTBReqInParm.productID.identifier);
         }
        else
        {
            tmpMsgId = CIMFWStrDup(strBWSWaferOutAndSTBReqInParm.eqpMonitorID.identifier);
        }
        PPT_METHODTRACE_V2("", "tmpMsgId", tmpMsgId );
        if(!bEnoughQty)
        {
            CS_PPT_SET_MSG_RC_KEY1( strBWSWaferOutAndSTBReqResult,
                                    CS_MSG_NOT_FOUND_ENOUGH_SOURCE_WAFER,
                                    CS_RC_NOT_FOUND_ENOUGH_SOURCE_WAFER,
                                    tmpMsgId );
            return CS_RC_NOT_FOUND_ENOUGH_SOURCE_WAFER;
        }
        else
        {
            CS_PPT_SET_MSG_RC_KEY1( strBWSWaferOutAndSTBReqResult,
                                    CS_MSG_NOT_FOUND_AVAILABLE_BWS,
                                    CS_RC_NOT_FOUND_AVAILABLE_BWS,
                                    tmpMsgId );
            return CS_RC_NOT_FOUND_AVAILABLE_BWS;
        }
    }

    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = targetBWSID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "" );
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", targetBWSID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strBWSWaferOutAndSTBReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Advanced Mode
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = targetBWSID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strBWSWaferOutAndSTBReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, targetBWSID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: cs_txBWSWaferOutAndSTBReq", "object_Lock() != RC_OK") ;
            strBWSWaferOutAndSTBReqResult.strResult = strObject_Lock_out.strResult ;
            return( rc );
        }
    }

    rc = object_Lock( strObject_Lock_out, strObjCommonIn, emptyCarrierID, SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txLoadingLotRpt", "object_Lock() != RC_OK") ;
        strBWSWaferOutAndSTBReqResult.strResult = strObject_Lock_out.strResult ;
        return( rc );
    }

    //---------------------------------------------
    // Check operation condition for BWS Out
    //---------------------------------------------
    csObjNPW_CheckCoditionForBWSOut_in  strNPW_CheckCoditionForBWSOut_in;
    strNPW_CheckCoditionForBWSOut_in.BWSID = targetBWSID;
    strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus = targetEqpPort;
    strNPW_CheckCoditionForBWSOut_in.emptyCarrierID = emptyCarrierID;

    csObjNPW_CheckCoditionForBWSOut_out strNPW_CheckCoditionForBWSOut_out;
    rc = cs_NPW_CheckCoditionForBWSOut( strNPW_CheckCoditionForBWSOut_out,
                                        strObjCommonIn,
                                        strNPW_CheckCoditionForBWSOut_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "RC_OK != cs_NPW_CheckCoditionForBWSOut()");
        strBWSWaferOutAndSTBReqResult.strResult = strNPW_CheckCoditionForBWSOut_out.strResult;
        return( rc );
    }

    //---------------------------------------------
    // convert to csNPWSTB_SlotMap
    //---------------------------------------------
    CORBA::Long waferLen = strBWSWaferDataSeq.length();
    csNPWSTB_SlotMapSequence strNPWSTB_SlotMapSeq;
    strNPWSTB_SlotMapSeq.length(waferLen);
    csEqpMonitorSubInfoSequence strEqpMonitorSubInfoSeq;
    if( 0 == CIMFWStrCmp(strBWSWaferOutAndSTBReqInParm.npwType, CS_EqpMonitor_NPW_Type_Monitor))
    {
        PPT_METHODTRACE_V2("", "eqpMonitorID", strBWSWaferOutAndSTBReqInParm.eqpMonitorID.identifier);

        strEqpMonitorSubInfoSeq = strEqpMonitor_list_GetDR_out.strEqpMonitorDetailInfoSeq[0].strEqpMonitorSubInfoSeq;
        CORBA::Long nSeqLen = strEqpMonitorSubInfoSeq.length();
        if( nSeqLen != waferLen )
        {
            //not reachable, to avoid memory fault
            CS_PPT_SET_MSG_RC_KEY1( strBWSWaferOutAndSTBReqResult,
                                    CS_MSG_NOT_FOUND_ENOUGH_SOURCE_WAFER,
                                    CS_RC_NOT_FOUND_ENOUGH_SOURCE_WAFER,
                                    strBWSWaferOutAndSTBReqInParm.eqpMonitorID.identifier );
            return CS_RC_NOT_FOUND_ENOUGH_SOURCE_WAFER;
        }
        PPT_METHODTRACE_V2("", "nSeqLen", nSeqLen);
        PPT_METHODTRACE_V2("", "waferLen", waferLen);

        for( i=0; i<nSeqLen; i++)
        {
            PPT_METHODTRACE_V2("", "strEqpMonitorSubInfoSeq[i].slotNumber", strEqpMonitorSubInfoSeq[i].slotNumber);
            strNPWSTB_SlotMapSeq[i].carrierID  = emptyCarrierID;
            strNPWSTB_SlotMapSeq[i].slotNumber = strEqpMonitorSubInfoSeq[i].slotNumber;
            for( j=0; j<waferLen; j++)
            {
                PPT_METHODTRACE_V2("", "strBWSWaferDataSeq[j].productID.identifier", strBWSWaferDataSeq[j].productID.identifier);
                PPT_METHODTRACE_V2("", "strEqpMonitorSubInfoSeq[i].productID.identifier", strEqpMonitorSubInfoSeq[i].productID.identifier);
                PPT_METHODTRACE_V2("", "strBWSWaferDataSeq[j].dstProductID.identifier", strBWSWaferDataSeq[j].dstProductID.identifier);
                if( 0 == CIMFWStrCmp(strBWSWaferDataSeq[j].dstProductID.identifier, strEqpMonitorSubInfoSeq[i].productID.identifier) )
                {
                    PPT_METHODTRACE_V3("", "strBWSWaferDataSeq[j].waferID", strBWSWaferDataSeq[j].waferID.identifier, strBWSWaferDataSeq[j].productID.identifier);
                    strNPWSTB_SlotMapSeq[i].waferID       = strBWSWaferDataSeq[j].waferID;
                    strNPWSTB_SlotMapSeq[i].lotID         = strBWSWaferDataSeq[j].lotID;
                    strNPWSTB_SlotMapSeq[i].productID     = strBWSWaferDataSeq[j].productID;
                    strNPWSTB_SlotMapSeq[i].destProductID = strBWSWaferDataSeq[j].dstProductID;
                    strNPWSTB_SlotMapSeq[i].subLotType    = strBWSWaferDataSeq[j].subLotType;
                    //mark wafer used
                    strBWSWaferDataSeq[j].productID.identifier = CIMFWStrDup("");
                    break;
                }
            }
            if( j == waferLen )
            {
                //not reachable, to avoid memory fault
                CS_PPT_SET_MSG_RC_KEY1( strBWSWaferOutAndSTBReqResult,
                                        CS_MSG_NOT_FOUND_ENOUGH_SOURCE_WAFER,
                                        CS_RC_NOT_FOUND_ENOUGH_SOURCE_WAFER,
                                        strEqpMonitorSubInfoSeq[i].productID.identifier );
                return CS_RC_NOT_FOUND_ENOUGH_SOURCE_WAFER;
            }
        }
        PPT_METHODTRACE_V1("", "create for EqpMonitor success");
    }
    else
    {
        PPT_METHODTRACE_V1("", "Recycle or PreProcess");
        for( i=0; i<waferLen; i++)
        {
            PPT_METHODTRACE_V2("", "strBWSWaferDataSeq[i].waferID", strBWSWaferDataSeq[i].waferID.identifier);
            strNPWSTB_SlotMapSeq[i].carrierID     = emptyCarrierID;
            strNPWSTB_SlotMapSeq[i].slotNumber    = i+1;
            strNPWSTB_SlotMapSeq[i].waferID       = strBWSWaferDataSeq[i].waferID;
            strNPWSTB_SlotMapSeq[i].lotID         = strBWSWaferDataSeq[i].lotID;
            strNPWSTB_SlotMapSeq[i].productID     = strBWSWaferDataSeq[i].productID;
            strNPWSTB_SlotMapSeq[i].destProductID = strBWSWaferDataSeq[i].productID;
            strNPWSTB_SlotMapSeq[i].subLotType    = strBWSWaferDataSeq[i].subLotType;
        }
    }
    //---------------------------------------------
    // get carrier location info
    //---------------------------------------------
    PPT_METHODTRACE_V2( "", "calling cassette_LocationInfo_GetDR()", emptyCarrierID.identifier );
    objCassette_LocationInfo_GetDR_out  strCassette_LocationInfo_GetDR_out;
    rc = cassette_LocationInfo_GetDR( strCassette_LocationInfo_GetDR_out,
                                      strObjCommonIn,
                                      emptyCarrierID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "cassette_LocationInfo_GetDR() != RC_OK", rc );
        strBWSWaferOutAndSTBReqResult.strResult = strCassette_LocationInfo_GetDR_out.strResult;
        return( rc );
    }

    //---------------------------------------------
    // Save to MMDB CSFSNPWSTB:CSFSNPWSTB_SLOTMAP
    //---------------------------------------------
    csObjBWSOutSTB_slotMap_InsertDR_in  strBWSOutSTB_slotMap_InsertDR_in;
    strBWSOutSTB_slotMap_InsertDR_in.BWSID = targetBWSID;
    strBWSOutSTB_slotMap_InsertDR_in.portID = targetEqpPort.portID;
    strBWSOutSTB_slotMap_InsertDR_in.carrierID = emptyCarrierID;
    strBWSOutSTB_slotMap_InsertDR_in.npwType = strBWSWaferOutAndSTBReqInParm.npwType;
    strBWSOutSTB_slotMap_InsertDR_in.strNPWSTB_SlotMapSeq = strNPWSTB_SlotMapSeq;

    csObjBWSOutSTB_slotMap_InsertDR_out strBWSOutSTB_slotMap_InsertDR_out;
    rc = cs_BWSOutSTB_slotMap_InsertDR( strBWSOutSTB_slotMap_InsertDR_out,
                                        strObjCommonIn,
                                        strBWSOutSTB_slotMap_InsertDR_in);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "RC_OK != cs_BWSOutSTB_slotMap_InsertDR()");
        strBWSWaferOutAndSTBReqResult.strResult = strBWSOutSTB_slotMap_InsertDR_out.strResult;
        return( rc );
    }

    //---------------------------------------------
    // call BWS new Tx to create BWS Out Job
    //---------------------------------------------
    pptSorterComponentJobListAttributesSequence strSorterComponentJobListAttributesSeq;
    strSorterComponentJobListAttributesSeq.length(1);
    strSorterComponentJobListAttributesSeq[0].originalCarrierID = emptyCarrierID;
    strSorterComponentJobListAttributesSeq[0].originalPortID = targetEqpPort.portID;
    strSorterComponentJobListAttributesSeq[0].destinationCarrierID = emptyCarrierID;
    strSorterComponentJobListAttributesSeq[0].destinationPortID = targetEqpPort.portID;
    strSorterComponentJobListAttributesSeq[0].destinationCarrierXferStatus = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus;
    strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence.length(waferLen);

    objectIdentifier dummyID;
    for( i=0; i<waferLen; i++)
    {
        PPT_METHODTRACE_V2("", "strBWSWaferDataSeq[i].waferID", strBWSWaferDataSeq[i].waferID.identifier);
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].portGroup             = targetEqpPort.portGroup;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].equipmentID           = targetBWSID;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].actionCode            = CIMFWStrDup(CS_WaferTransfer_BWSOut);
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].requestTime           = CIMFWStrDup("");
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].direction             = CIMFWStrDup("");
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].waferID               = strBWSWaferDataSeq[i].waferID;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].lotID                 = strBWSWaferDataSeq[i].lotID;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].destinationCassetteID = emptyCarrierID;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].destinationPortID     = targetEqpPort.portID;
        if( 0 == CIMFWStrCmp(strBWSWaferOutAndSTBReqInParm.npwType, CS_EqpMonitor_NPW_Type_Monitor))
        {
            strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].destinationSlotNumber = strEqpMonitorSubInfoSeq[i].slotNumber;
        }
        else
        {
            strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].destinationSlotNumber = i+1;
        }
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].originalCassetteID    = emptyCarrierID;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].originalPortID        = targetEqpPort.portID;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].originalSlotNumber    = i+1;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].requestUserID         = strObjCommonIn.strUser.userID;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].replyTime             = CIMFWStrDup("");
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].sorterStatus          = CIMFWStrDup("");
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].slotMapCompareStatus  = CIMFWStrDup("");
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].mmCompareStatus       = CIMFWStrDup("");
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView = 0;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView = 1;
        csWaferSorterSlotMap_siInfo strWaferSorterSlotMap_siInfo;
        strWaferSorterSlotMap_siInfo.zoneID = strBWSWaferDataSeq[i].bankID.identifier;
        strSorterComponentJobListAttributesSeq[0].strWaferSorterSlotMapSequence[i].siInfo <<= strWaferSorterSlotMap_siInfo;
    }
    pptSortJobCreateReqResult strSortJobCreateReqResult;
    rc = txSortJobCreateReq( strSortJobCreateReqResult,
                             strObjCommonIn,
                             strSorterComponentJobListAttributesSeq,
                             targetBWSID,
                             targetEqpPort.portGroup,
                             FALSE, //waferIDReadFlag
                             claimMemo);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "call txSortJobCreateReq(),rc=", rc);
        strBWSWaferOutAndSTBReqResult.strResult = strSortJobCreateReqResult.strResult;
        return( rc );
    }

    //SortJob watchdog will NPW carrier/port and create XJ later accordingly, no need to create XJ here

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    SET_MSG_RC(strBWSWaferOutAndSTBReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txBWSWaferOutAndSTBReq")
    return( RC_OK );
}
