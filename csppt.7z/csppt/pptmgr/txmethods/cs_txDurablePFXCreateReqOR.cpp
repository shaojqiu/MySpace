//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txDurablePFXCreateReqOR.cpp
//

//INN-R170003 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"   //INN-R170003

// Class: PPTManager
//
// Service: txDurablePFXCreateReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2015/01/20 DSN000085770 Sa Guo         Durable Management.
// 2015/07/27 DSN000096126 C.Mo           Durable Process Flow Control Support.
//
//
// Innotron Modification History:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/11/08 INN-R170003 Nick Tsai      Reject if FOUP STB to unmatch route
//
//
// Description:
//    This function creates Durable PFX of specified Durable.
//      - Check condition of durable( PFX is Nil )
//      - Check status of durable( Should be NotAvailable )
//      - Create Durable PFX
//      - Make event
//
// Return:
//    long
//
// Parameter:
//
//  [Input Parameters]:
//    const pptObjCommonIn&                    strObjCommonIn
//    const pptDurablePFXCreateReqInParam&     strDurablePFXCreateReqInParam
//    const char *                             claimMemo
//
//  [Output Parameters]:
//    pptDurablePFXCreateReqResult&            strDurablePFXCreateReqResult
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170003 CORBA::Long PPTManager_i::txDurablePFXCreateReq(
CORBA::Long CS_PPTManager_i::txDurablePFXCreateReq(     //INN-R170003
    pptDurablePFXCreateReqResult&              strDurablePFXCreateReqResult,
    const pptObjCommonIn&                      strObjCommonIn,
    const pptDurablePFXCreateReqInParam&       strDurablePFXCreateReqInParam,
    const char *                               claimMemo
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txDurablePFXCreateReq");
    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------

    // Initialize
    CORBA::Long rc = RC_OK;

    const pptDurablePFXCreateReqInParam& strInParm = strDurablePFXCreateReqInParam;

    //----------------------------------------------------------------
    //  In-Parameter Trace
    //----------------------------------------------------------------
    //Trace InParameters
    PPT_METHODTRACE_V2("", "in-parm durableCategory  ", strInParm.durableCategory);

    const char* durableCategory = strInParm.durableCategory;
    if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
        PPT_SET_MSG_RC_KEY( strDurablePFXCreateReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            durableCategory );
        return RC_INVALID_DURABLE_CATEGORY ;
    }

    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosCassette);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  strInParm.durableIDs,
                                  SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurablePFXCreateReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosReticlePod);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  strInParm.durableIDs,
                                  SP_ClassName_PosReticlePod );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurablePFXCreateReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosProcessDurable);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  strInParm.durableIDs,
                                  SP_ClassName_PosProcessDurable );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurablePFXCreateReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }

    CORBA::ULong durableLen = strInParm.durableIDs.length();
    CORBA::ULong durableCnt = 0;
    pptStartDurableSequence strStartDurables;
    strStartDurables.length( durableLen );
    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.durableIDs.length()", durableCnt);
        strStartDurables[durableCnt].durableID = strInParm.durableIDs[durableCnt];
    }

    objDurable_CheckConditionForOperation_out strDurable_CheckConditionForOperation_out;
    objDurable_CheckConditionForOperation_in  strDurable_CheckConditionForOperation_in;
    strDurable_CheckConditionForOperation_in.operation        = CIMFWStrDup( SP_Operation_PFXCreate );
    strDurable_CheckConditionForOperation_in.durableCategory  = strInParm.durableCategory;
    strDurable_CheckConditionForOperation_in.strStartDurables = strStartDurables;
    rc = durable_CheckConditionForOperation( strDurable_CheckConditionForOperation_out,
                                             strObjCommonIn,
                                             strDurable_CheckConditionForOperation_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durable_CheckConditionForOperation() != RC_OK", rc);
        strDurablePFXCreateReqResult.strResult = strDurable_CheckConditionForOperation_out.strResult;
        return rc;
    }

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.durableIDs.length()", durableCnt);
        objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
        objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
        strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup( SP_Operation_PFXCreate );
        strDurable_status_CheckForOperation_in.durableID       = strInParm.durableIDs[durableCnt];
        strDurable_status_CheckForOperation_in.durableCategory = strInParm.durableCategory;
        rc = durable_status_CheckForOperation( strDurable_status_CheckForOperation_out,
                                               strObjCommonIn,
                                               strDurable_status_CheckForOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_status_CheckForOperation() != RC_OK", rc);
            strDurablePFXCreateReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
            return rc;
        }
    }

//DSN000096126 Add Start
    if(CIMFWStrLen(strInParm.routeID.identifier) > 0)
    {
        PPT_METHODTRACE_V2("", "input-param routeID: ", strInParm.routeID.identifier);
        objBank_durableSTB_Check_out strBank_durableSTB_Check_out;
        objBank_durableSTB_Check_in  strBank_durableSTB_Check_in;
        strBank_durableSTB_Check_in.routeID         = strInParm.routeID;
        strBank_durableSTB_Check_in.durableCategory = strInParm.durableCategory;
        strBank_durableSTB_Check_in.durables        = strInParm.durableIDs;

        rc = bank_durableSTB_Check(strBank_durableSTB_Check_out, strObjCommonIn, strBank_durableSTB_Check_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "bank_durableSTB_Check() != RC_OK", rc);
            strDurablePFXCreateReqResult.strResult = strBank_durableSTB_Check_out.strResult;
            return rc;
        }

        //INN-R170003 add start
        if ( CIMFWStrCmp ( strInParm.durableCategory, SP_DurableCat_Cassette ) == 0 )
        {
            PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Cassette ");

            for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
            {
                PPT_METHODTRACE_V3("", "durableCnt", durableCnt, strInParm.durableIDs[durableCnt].identifier );
                //--------------------------------------------------------------//
                //   Get Current Durable Sub-Status                             //
                //--------------------------------------------------------------//
                objDurable_subState_Get_out strDurable_subState_Get_out;
                objDurable_subState_Get_in  strDurable_subState_Get_in;
                strDurable_subState_Get_in.durableCategory = strInParm.durableCategory;
                strDurable_subState_Get_in.durableID       = strInParm.durableIDs[durableCnt];
                rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "durable_subState_Get() != RC_OK", rc );
                    strDurablePFXCreateReqResult.strResult = strDurable_subState_Get_out.strResult;
                    return  rc;
                }

                PPT_METHODTRACE_V2("", "durableSubStatus", strDurable_subState_Get_out.durableSubStatus.identifier );

                if ( CIMFWStrCmp ( strDurable_subState_Get_out.durableSubStatus.identifier, CS_FOUP_DURABLE_SUB_STATE_WAITINSP  ) == 0 ||
                     CIMFWStrCmp ( strDurable_subState_Get_out.durableSubStatus.identifier, CS_FOUP_DURABLE_SUB_STATE_WAITCLEAN ) == 0    )
                {
                    //--------------------------------------------------------------//
                    //   Get route object                                           //
                    //--------------------------------------------------------------//
                    objObject_Get_out strObject_Get_out;
                    objObject_Get_in  strObject_Get_in;
                    strObject_Get_in.className                      = CIMFWStrDup( SP_ClassName_PosProcessDefinition );
                    strObject_Get_in.strHashedInfoSeq.length( 2 );
                    strObject_Get_in.strHashedInfoSeq[0].hashKey    = CIMFWStrDup( SP_HashData_PD_ID );
                    strObject_Get_in.strHashedInfoSeq[0].hashData   = CIMFWStrDup( strInParm.routeID.identifier );
                    strObject_Get_in.strHashedInfoSeq[1].hashKey    = CIMFWStrDup( SP_HashData_PD_LEVEL );
                    strObject_Get_in.strHashedInfoSeq[1].hashData   = CIMFWStrDup( SP_PD_FlowLevel_Main );

                    PPT_METHODTRACE_V1("", "call object_Get()");

                    rc = object_Get( strObject_Get_out,
                                     strObjCommonIn,
                                     strObject_Get_in );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "", "object_Get() rc != RC_OK" );
                        strDurablePFXCreateReqResult.strResult = strObject_Get_out.strResult;
                        return rc;
                    }
                    PPT_METHODTRACE_V2("", "routeID stringifiedObjectReference", strObject_Get_out.stringifiedObjectReference);

                    pptUserDataInqInParm__101 strUserDataInqInParm;
                    strUserDataInqInParm.userDataName       = CIMFWStrDup(CS_S_MAINPD_DURABLE_FLOW_TYPE);
                    strUserDataInqInParm.userDataOriginator = CIMFWStrDup(SP_USERDATA_ORIG_SM);

                    objObject_UserData_Get_out strObject_UserData_Get_out;
                    rc = object_userData_Get__101( strObject_UserData_Get_out,
                                                   strObjCommonIn,
                                                   strUserDataInqInParm,
                                                   strObject_Get_out.stringifiedObjectReference);

                    if (rc != RC_OK && rc != RC_NOT_FOUND_UDATA)
                    {
                        PPT_METHODTRACE_V1("", "object_userData_Get__101() rc != RC_OK");
                        strDurablePFXCreateReqResult.strResult = strObject_UserData_Get_out.strResult;
                        return rc;
                    }

                    if( strObject_UserData_Get_out.strUserDataSeq.length() > 0 &&
                        CIMFWStrLen (strObject_UserData_Get_out.strUserDataSeq[0].value) > 0 )
                    {
                        PPT_METHODTRACE_V2("", "name",  strObject_UserData_Get_out.strUserDataSeq[0].name);
                        PPT_METHODTRACE_V2("", "value", strObject_UserData_Get_out.strUserDataSeq[0].value);

                        PPT_METHODTRACE_V2("", "durableSubStatus", strDurable_subState_Get_out.durableSubStatus.identifier);
                        if ( CIMFWStrCmp ( strDurable_subState_Get_out.durableSubStatus.identifier, CS_FOUP_DURABLE_SUB_STATE_WAITINSP  ) == 0 &&
                             CIMFWStrCmp ( strObject_UserData_Get_out.strUserDataSeq[0].value, CS_DURABLE_FLOW_TYPE_FOUP_INSPECTION  ) != 0 )
                        {
                            PPT_METHODTRACE_V1("", "Invalid route for cassette in FOUP_WaitInsp");

                            CS_PPT_SET_MSG_RC_KEY2 ( strDurablePFXCreateReqResult,
                                                     CS_MSG_CAST_STB_INVALID_ROUTE,
                                                     CS_RC_CAST_STB_INVALID_ROUTE,
                                                     strDurable_subState_Get_out.durableSubStatus.identifier,
                                                     strObject_UserData_Get_out.strUserDataSeq[0].value);
                            return CS_RC_CAST_STB_INVALID_ROUTE;
                        }

                        if ( CIMFWStrCmp ( strDurable_subState_Get_out.durableSubStatus.identifier, CS_FOUP_DURABLE_SUB_STATE_WAITCLEAN  ) == 0 &&
                             CIMFWStrCmp ( strObject_UserData_Get_out.strUserDataSeq[0].value, CS_DURABLE_FLOW_TYPE_FOUP_CLEAN  ) != 0 )
                        {
                            PPT_METHODTRACE_V1("", "Invalid route for cassette in FOUP_WaitClean");

                            CS_PPT_SET_MSG_RC_KEY2 ( strDurablePFXCreateReqResult,
                                                     CS_MSG_CAST_STB_INVALID_ROUTE,
                                                     CS_RC_CAST_STB_INVALID_ROUTE,
                                                     strDurable_subState_Get_out.durableSubStatus.identifier,
                                                     strObject_UserData_Get_out.strUserDataSeq[0].value);
                            return CS_RC_CAST_STB_INVALID_ROUTE;
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "Undefined Durable Flow Type");

                        CS_PPT_SET_MSG_RC_KEY1 ( strDurablePFXCreateReqResult,
                                                 CS_MSG_UNDEFINE_DURABLE_FLOW_TYPE,
                                                 CS_RC_UNDEFINE_DURABLE_FLOW_TYPE,
                                                 strInParm.routeID.identifier);
                        return CS_RC_UNDEFINE_DURABLE_FLOW_TYPE;
                    }
                }
            }
        }
        //INN-R170003 add end
    }
//DSN000096126 Add End

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.durableIDs.length()", durableCnt);
        objDurablePFXCreate_out strDurablePFXCreate_out;
        objDurablePFXCreate_in  strDurablePFXCreate_in;
        strDurablePFXCreate_in.durableCategory = strInParm.durableCategory;
        strDurablePFXCreate_in.durableID       = strInParm.durableIDs[durableCnt];
        strDurablePFXCreate_in.routeID         = strInParm.routeID;                //DSN000096126
        rc = durablePFXCreate( strDurablePFXCreate_out,
                               strObjCommonIn,
                               strDurablePFXCreate_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durablePFXCreate() != RC_OK", rc);
            strDurablePFXCreateReqResult.strResult = strDurablePFXCreate_out.strResult;
            return rc;
        }

        objDurablePFXCreateEvent_Make_out strDurablePFXCreateEvent_Make_out;
        objDurablePFXCreateEvent_Make_in  strDurablePFXCreateEvent_Make_in;
        strDurablePFXCreateEvent_Make_in.durableCategory = strInParm.durableCategory;
        strDurablePFXCreateEvent_Make_in.durableID       = strInParm.durableIDs[durableCnt];
        strDurablePFXCreateEvent_Make_in.routeID         = strInParm.routeID;
        strDurablePFXCreateEvent_Make_in.claimMemo       = claimMemo;
        rc = durablePFXCreateEvent_Make( strDurablePFXCreateEvent_Make_out,
                                         strObjCommonIn,
                                         strDurablePFXCreateEvent_Make_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durablePFXCreateEvent_Make() != RC_OK", rc);
            strDurablePFXCreateReqResult.strResult = strDurablePFXCreateEvent_Make_out.strResult;
            return rc;
        }
    }

    // Return to caller
    SET_MSG_RC( strDurablePFXCreateReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txDurablePFXCreateReq");
    return RC_OK;
}