#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/txLotsInfoForOpeStartInq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/15/07 15:49:19 [ 11/15/07 15:49:19 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: txLotsInfoForOpeStartInq.cpp
//

#include "cs_pptmgr.hpp"

extern void traceSampledStartCassette( const pptStartCassetteSequence& strStartCassette );    //D9000003 for Cassette trace


// Class: PPTManager
//
// Service: txLotsInfoForOpeStartInq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/02          O.Sugiyama     Initial Release
// 2000/09/05 0.01     T.Yamano       Bug Fix
// 2000/09/06 P3000049 Y.Iwasaki      Bug fix to set strStartCassette
// 2000-09-06 P3000058 Y.Iwasaki      Bug fix (return structure set logic)
// 2000/09/11 P3000129 O.Sugiyama     Bug Fix set MSG_RC
// 2001/06/06 D4000014 K.Kido         APC Interface
// 2001-07-05 D4000015 H.Katoh        Add Equipment Category Check Logic because of
//                                    Internal Buffer Support
// 2001-08-20 P4000099 K.Kido         Change filename
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025 T.Nishimura    Source Check : return without message.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2006/12/01 D8000024 H.Mutoh        Flexible Process Condition Change (R80)
// 2007/01/23 P8000072 M.Murata       Fix handling logic. (FPC)
// 2007/04/02 D8000207 M.Murata       Add changing logic processJobExecFlag.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/06/03 D9000003 M.Nakano       Modify changing logic processJobExecFlag for wafer sampling operation.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009-11-11 PSIV00001581 R.Iriguchi     Fix memory leak
// 2010/06/25 PSIV00002149 S.Kawabe       Start Lot Reservation fails when a lot in FOUP is not on a route.
// 2015/12/03 DSN000096135 T.Ishida       Virtual Operation


// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/27 INN-R170009  Liu Xinxin     Litho APC Enahncement

//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptLotsInfoForOpeStartInqResult& strLotsInfoForOpeStartInqResult
//     const pptObjCommonIn&                strObjCommonIn
//     const objectIdentifier&              equipmentID
//     const objectIdentifierSequence&      cassetteID,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txLotsInfoForOpeStartInq (
    pptLotsInfoForOpeStartInqResult&    strLotsInfoForOpeStartInqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
//D6000025     const objectIdentifierSequence&     cassetteID,
//D6000025     CORBA::Environment &                IT_env)
    const objectIdentifierSequence&     cassetteID  //D6000025
    CORBAENV_LAST_CPP)                              //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txLotsInfoForOpeStartInq ");

    CORBA::Long rc = RC_OK;

    //P4100536 add start
    // Check length of In-Parameter
    if ( 0 >= cassetteID.length() )
    {
        SET_MSG_RC(strLotsInfoForOpeStartInqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER); //P4200025 add
        return RC_INVALID_PARAMETER;
    }
    //P4100536 add end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    //D4000015 Start
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strLotsInfoForOpeStartInqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //D4000015 End


    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*--------------------------------------------------*/
    /*                                                  */
    /*   Get Equipment's Start Reserved ControlJob ID   */
    /*                                                  */
    /*--------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txLotsInfoForOpeStartInq", "Get Equipment's Start Reserved ControlJob ID");

    objEquipment_reservedControlJobID_Get_out strEquipment_reservedControlJobID_Get_out;
    rc = equipment_reservedControlJobID_Get(strEquipment_reservedControlJobID_Get_out, strObjCommonIn,
                                            equipmentID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txLotsInfoForOpeStartInq", "equipment_reservedControlJobID_Get() rc != RC_OK");
        strLotsInfoForOpeStartInqResult.strResult = strEquipment_reservedControlJobID_Get_out.strResult;
        return (rc);
    }

    /*-------------------------------------------------*/
    /*                                                 */
    /*   Get Cassette's Start Reserved ControlJob ID   */
    /*                                                 */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txLotsInfoForOpeStartInq", "Get Cassette's Start Reserved ControlJob ID");

    objectIdentifier saveControlJobID;
    CORBA::Long i = 0;
    CORBA::Long nIMax = cassetteID.length();
    PPT_METHODTRACE_V2( "PPTManager_i:: txLotsInfoForOpeStartInq", "nIMax = ", nIMax );
    for ( i = 0; i < nIMax; i++ )
    {
        objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
        rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, cassetteID[i] );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txLotsInfoForOpeStartInq", "cassette_controlJobID_Get() rc != RC_OK")
            strLotsInfoForOpeStartInqResult.strResult = strCassette_controlJobID_Get_out.strResult;
            return (rc);
        }

        CORBA::Boolean findFlag = FALSE;
        CORBA::Long j = 0;
        CORBA::Long nJMax = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();
        PPT_METHODTRACE_V2( "PPTManager_i:: txLotsInfoForOpeStartInq", "nJMax = ", nJMax );
        for ( j = 0; j < nJMax; j++ )
        {
            if ( CIMFWStrCmp( strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier, strCassette_controlJobID_Get_out.controlJobID.identifier ) == 0 ) // 0.01
            {
                findFlag = TRUE;
                break;
            }
        }

        if ( CIMFWStrLen( strCassette_controlJobID_Get_out.controlJobID.identifier ) != 0 ) // 0.01
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txLotsInfoForOpeStartInq", "CIMFWStrLen(strCassette_controlJobID_Get_out.contorolJobID.identifier) != 0" );
            saveControlJobID = strCassette_controlJobID_Get_out.controlJobID; // 0.01

            if ( findFlag == FALSE )
            {
                PPT_METHODTRACE_V1( "PPTManager_i::txLotsInfoForOpeStartInq", "findFlag == FALSE" );
//P3000129      SET_MSG_RC( strEquipment_reservedControlJobID_Get_out,
//P3000129                  MSG_NOT_RESVED_PORTGRP,
//P3000129                  RC_NOT_RESVED_PORTGRP);
//DSN000096135                SET_MSG_RC( strLotsInfoForOpeStartInqResult, //P3000129
//DSN000096135                            MSG_NOT_RESVED_PORTGRP,          //P3000129
//DSN000096135                            RC_NOT_RESVED_PORTGRP);          //P3000129
//DSN000096135                return( RC_NOT_RESVED_PORTGRP );
                SET_MSG_RC( strLotsInfoForOpeStartInqResult,       //DSN000096135
                            MSG_UNMATCH_CONTROLJOB_EQP_VS_CAST,    //DSN000096135
                            RC_UNMATCH_CONTROLJOB_EQP_VS_CAST);    //DSN000096135
                return( RC_UNMATCH_CONTROLJOB_EQP_VS_CAST );       //DSN000096135
            }
        }
        else
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txLotsInfoForOpeStartInq", "CIMFWStrLen(strCassette_controlJobID_Get_out.contorolJobID.identifier) == 0" );
            if ( findFlag == TRUE )
            {
                PPT_METHODTRACE_V1( "PPTManager_i::txLotsInfoForOpeStartInq", "findFlag == FALSE" );
//P3000129      PPT_SET_MSG_RC_KEY2( strEquipment_reservedControlJobID_Get_out,
//P3000129                           MSG_ALREADY_RESERVED_PORTGRP,
//P3000129                           RC_ALREADY_RESERVED_PORTGRP,
//P3000129                           "",
//P3000129                           strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier );
                PPT_SET_MSG_RC_KEY2( strLotsInfoForOpeStartInqResult, //P3000129
                                     MSG_ALREADY_RESERVED_PORTGRP,    //P3000129
                                     RC_ALREADY_RESERVED_PORTGRP,     //P3000129
                                     "",                              //P3000129
                                     strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier ); //P3000129
                return (RC_ALREADY_RESERVED_PORTGRP);
            }
        }
    }

    /*----------------------------------------------------*/
    /*                                                    */
    /*   Get Start Information for each Cassette / Lot    */
    /*                                                    */
    /*----------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txLotsInfoForOpeStartInq", "Get Start Information for each Cassette / Lot");

//D9000003 add start
    CORBA::Boolean slotmapConflictWarnFlag = FALSE;   //Switch RC and MSG: when sampling logic below finished with warning.
    CORBA::Long capacity;
    capacity = atoi( getenv( SP_CARRIER_CAPACITY ) );

    ostrstream smplMessage;
//D9000003 add end
    if ( CIMFWStrLen( saveControlJobID.identifier ) != 0 ) // 0.01
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txLotsInfoForOpeStartInq", "CIMFWStrCmp(saveControlJobID.identifier, " ") != 0" );
        objControlJob_startReserveInformation_Get_out strControlJob_startReserveInformation_Get_out;
        rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
                                                     strObjCommonIn, saveControlJobID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txLotsInfoForOpeStartInq", "controlJob_startReserveInformation_Get() rc != RC_OK" );
            strLotsInfoForOpeStartInqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult;
            return (rc);
        }
        strLotsInfoForOpeStartInqResult.strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette; //P3000041
    }
    else
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txLotsInfoForOpeStartInq", "CIMFWStrCmp(saveControlJobID.identifier, " ") == 0" );

        objProcess_startReserveInformation_GetByCassette_out strProcess_startReserveInformation_GetByCassette_out;                          //PSIV00002149
        rc = process_startReserveInformation_GetByCassette( strProcess_startReserveInformation_GetByCassette_out,                           //PSIV00002149
                                                            strObjCommonIn, equipmentID, cassetteID );                                      //PSIV00002149
        if ( rc != RC_OK )                                                                                                                  //PSIV00002149
        {                                                                                                                                   //PSIV00002149
            PPT_METHODTRACE_V1( "PPTManager_i:: txLotsInfoForOpeStartInq", "process_startReserveInformation_GetByCassette() rc != RC_OK" ); //PSIV00002149
            strLotsInfoForOpeStartInqResult.strResult = strProcess_startReserveInformation_GetByCassette_out.strResult;                     //PSIV00002149
            return (rc);                                                                                                                    //PSIV00002149
        }                                                                                                                                   //PSIV00002149
        strLotsInfoForOpeStartInqResult.strStartCassette = strProcess_startReserveInformation_GetByCassette_out.strStartCassette;           //PSIV00002149

//D8000024 add start
//D9000001        CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
        CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
        if ( 1 == tmpFPCAdoptFlag )
        {
//PSIV00002149            CORBA::Long castLen = cassetteID.length();
            CORBA::Long castLen = strLotsInfoForOpeStartInqResult.strStartCassette.length();                                                //PSIV00002149
            for ( CORBA::Long castCnt = 0; castCnt < castLen; castCnt++ )
            {
//PSIV00002149                objCassette_GetLotList_out strCassette_GetLotList_out;
//PSIV00002149                rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, cassetteID[castCnt] );
//PSIV00002149//P8000072                if( rc != RC_OK )
//PSIV00002149                if ( rc != RC_OK && rc != RC_NOT_FOUND_LOT )    //P8000072
//PSIV00002149                {
//PSIV00002149                    PPT_METHODTRACE_V2( "", "cassette_GetLotList() != RC_OK", rc );
//PSIV00002149                    strLotsInfoForOpeStartInqResult.strResult = strCassette_GetLotList_out.strResult;
//PSIV00002149                    return (rc);
//PSIV00002149                }

//PSIV00002149                CORBA::Long lotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
                CORBA::Long lotLen = strLotsInfoForOpeStartInqResult.strStartCassette[castCnt].strLotInCassette.length();                   //PSIV00002149
                for ( CORBA::Long lotCnt = 0; lotCnt < lotLen; lotCnt++ )
                {
                    if( strLotsInfoForOpeStartInqResult.strStartCassette[castCnt].strLotInCassette[lotCnt].operationStartFlag == FALSE )    //PSIV00002149
                    {                                                                                                                       //PSIV00002149
                        PPT_METHODTRACE_V1("", "operationStartFlag == FALSE" );                                                             //PSIV00002149
                        continue;                                                                                                           //PSIV00002149
                    }                                                                                                                       //PSIV00002149
                    objectIdentifier lotID = strLotsInfoForOpeStartInqResult.strStartCassette[castCnt].strLotInCassette[lotCnt].lotID;      //PSIV00002149
//PSIV00002149                    PPT_METHODTRACE_V2( "", "Check lot's FPC definition.",
//PSIV00002149                                        strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[lotCnt].identifier );
                    PPT_METHODTRACE_V2( "", "Check lot's FPC definition.", lotID.identifier );                                              //PSIV00002149
                    objLot_currentFPCInfo_Get_out strLot_currentFPCInfo_Get_out;
                    rc = lot_currentFPCInfo_Get( strLot_currentFPCInfo_Get_out, strObjCommonIn,
//PSIV00002149                                                 strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[lotCnt],
                                                 lotID,                                                                                     //PSIV00002149
                                                 equipmentID, FALSE, FALSE, FALSE, FALSE );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "", "lot_currentFPCInfo_Get() != RC_OK", rc );
                        strLotsInfoForOpeStartInqResult.strResult = strLot_currentFPCInfo_Get_out.strResult;
                        return (rc);
                    }

                    CORBA::Long fpcLen = strLot_currentFPCInfo_Get_out.strFPCInfoList.length();
                    if ( fpcLen > 0 )
                    {
                        PPT_METHODTRACE_V2( "", "This lot is influenced by FPC.", fpcLen );
                        PPT_SET_MSG_RC_KEY( strLotsInfoForOpeStartInqResult,
                                            MSG_FPC_REQUIRE_START_RESERVE, RC_FPC_REQUIRE_START_RESERVE,
//PSIV00002149                                            strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[lotCnt].identifier );
                                            lotID.identifier );                                                                             //PSIV00002149
                        return RC_FPC_REQUIRE_START_RESERVE;
                    }
                }
            }
        }
//D8000024 add end

//PSIV00002149        objProcess_startReserveInformation_GetByCassette_out strProcess_startReserveInformation_GetByCassette_out;
//PSIV00002149        rc = process_startReserveInformation_GetByCassette( strProcess_startReserveInformation_GetByCassette_out,
//PSIV00002149                                                            strObjCommonIn, equipmentID, cassetteID );
//PSIV00002149        if ( rc != RC_OK )
//PSIV00002149        {
//PSIV00002149            PPT_METHODTRACE_V1( "PPTManager_i:: txLotsInfoForOpeStartInq", "process_startReserveInformation_GetByCassette() rc != RC_OK" );
//PSIV00002149            strLotsInfoForOpeStartInqResult.strResult = strProcess_startReserveInformation_GetByCassette_out.strResult;
//PSIV00002149            return (rc);
//PSIV00002149        }
//PSIV00002149        strLotsInfoForOpeStartInqResult.strStartCassette = strProcess_startReserveInformation_GetByCassette_out.strStartCassette; //P3000041


//D9000003 add start
        //set processJobExecFlag when reserve information does not exist.
        PPT_METHODTRACE_V1( "", "Set processJobExecFlag based on wafer sampling setting. " );
        objStartCassette_processJobExecFlag_Set_out__090 strStartCassette_processJobExecFlag_Set_out__090;
        objStartCassette_processJobExecFlag_Set_in__090 strStartCassette_processJobExecFlag_Set_in__090;
        strStartCassette_processJobExecFlag_Set_in__090.strStartCassette = strLotsInfoForOpeStartInqResult.strStartCassette;
        strStartCassette_processJobExecFlag_Set_in__090.equipmentID = equipmentID;

        rc = startCassette_processJobExecFlag_Set__090(strStartCassette_processJobExecFlag_Set_out__090, strObjCommonIn, strStartCassette_processJobExecFlag_Set_in__090);
        if ( rc != RC_SMPL_SLOTMAP_CONFLICT_WARN && rc != RC_OK )
        {
            // Return error when input parameter or sampling setting is invalid format.
            PPT_METHODTRACE_V1( "", "startCassette_processJobExecFlag_Set__090() != RC_OK " );
            strLotsInfoForOpeStartInqResult.strResult = strStartCassette_processJobExecFlag_Set_out__090.strResult;
            return rc;
        }
        //-------------------------------------------------------
        // When RC_SMPL_SLOTMAP_CONFLICT_WARN is returned,
        // return RC_SMPL_SLOTMAP_CONFLICT_WARN at the last of TX process.
        //-------------------------------------------------------
        if ( rc == RC_SMPL_SLOTMAP_CONFLICT_WARN )
        {
            PPT_METHODTRACE_V1( "", "rc == RC_SMPL_SLOTMAP_CONFLICT_WARN" );
            slotmapConflictWarnFlag = TRUE;
        }
        //-------------------------------------------------------
        // create return message or e-mail text.
        //-------------------------------------------------------
        PPT_METHODTRACE_V2( "", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length()", strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length() );
        for ( CORBA::Long msgCnt = 0; msgCnt < strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length(); msgCnt++ )
        {
            if ( strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_warn_mail )
            {
                PPT_METHODTRACE_V1( "", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_warn_mail" );
                // create return message;
                if ( smplMessage.pcount() > 0 )
                {
                    smplMessage << "," << endl;
                }
                smplMessage << strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageText;
            }
            else if (strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_ignored_mail)
            {
                PPT_METHODTRACE_V1("", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_ignored_mail");
                // Send E-mail when recycle sampling setting is ignored.
                pptSystemMsgRptResult strSystemMsgRptResult;
                objectIdentifier dummyID;
                rc = txSystemMsgRpt(strSystemMsgRptResult,
                                    strObjCommonIn,
                                    SP_SubSystemID_MM,
                                    SP_SystemMsgCode_SMPLERR,
                                    strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageText,
                                    TRUE,
                                    dummyID,
                                    "",
                                    dummyID,
                                    "",
                                    dummyID,
                                    "",
                                    strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].lotID,
                                    "",
                                    dummyID,
                                    dummyID,
                                    "",
                                    strObjCommonIn.strTimeStamp.reportTimeStamp,
                                    "" );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "txSystemMsgRpt != RC_OK" );
                    strLotsInfoForOpeStartInqResult.strResult = strSystemMsgRptResult.strResult;
                    return( rc );
                }
            }
        } //end for-loop
        smplMessage << ends ;

        PPT_METHODTRACE_V2( "", "smplMessage = ", smplMessage.str() );
        smplMessage.rdbuf()->freeze(0);             //PSIV00001581
        strLotsInfoForOpeStartInqResult.strStartCassette = strStartCassette_processJobExecFlag_Set_out__090.strStartCassette;
//D9000003 add end
    }

//D8000207 add start
    //----------------------------------------
    // Change processJobExecFlag to True.
    //----------------------------------------
//D9000003 delete start
//    PPT_METHODTRACE_V2("","SP_OPER_START_WAFER_FLAG_CONTROL is ", atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)));
//    if( 1 == atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)) )
//    {
//        objStartCassette_processJobExecFlag_Set_out   strStartCassette_processJobExecFlag_Set_out;
//        rc = startCassette_processJobExecFlag_Set(strStartCassette_processJobExecFlag_Set_out, strObjCommonIn, strLotsInfoForOpeStartInqResult.strStartCassette );
//        if( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("","objStartCassette_processJobExecFlag_Set() != RC_OK ");
//            strLotsInfoForOpeStartInqResult.strResult = strStartCassette_processJobExecFlag_Set_out.strResult;
//            return rc ;
//        }
//        strLotsInfoForOpeStartInqResult.strStartCassette = strStartCassette_processJobExecFlag_Set_out.strStartCassette;
//    }
//D9000003 delete end
//D8000207 add end


    //P3000058 add start
    /*------------------------------------------*/
    /*                                          */
    /*   Set EqpID, ControlJobID, PortGroupID   */
    /*                                          */
    /*------------------------------------------*/
    strLotsInfoForOpeStartInqResult.equipmentID = equipmentID;
    strLotsInfoForOpeStartInqResult.controlJobID = saveControlJobID;

    /*---------------------*/  // This implementation is not good from
    /*   Get PortGroupID   */  // responce point of view. In the near
    /*---------------------*/  // future, this logic must be replaced.
    objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
    rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i::txLotsInfoForOpeStartInq", "equipment_portInfo_Get() != RC_OK" );
        strLotsInfoForOpeStartInqResult.strResult = strEquipment_portInfo_Get_out.strResult;
        return (rc);
    }
    CORBA::Long EPSLength = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
    for ( i = 0; i < EPSLength; i++ )
    {
        PPT_METHODTRACE_V3( "PPTManager_i::txLotsInfoForOpeStartInq", "loop to strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", EPSLength, i );
        CORBA::String_var EPSIdent;
        CORBA::String_var InCIDIdent;
        EPSIdent = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].loadedCassetteID.identifier;
        InCIDIdent = cassetteID[0].identifier;
        if ( CIMFWStrCmp( EPSIdent, InCIDIdent ) == 0 )
        {
            PPT_METHODTRACE_V1( "PPTManager_i::txLotsInfoForOpeStartInq", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].loadedCassetteID == in-parm' scassetteID[0]" );
            strLotsInfoForOpeStartInqResult.portGroupID = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portGroup;
            break;
        }
    }
    //P3000058 add end

//D4000014 start
//INN-R170009#if 1
//INN-R170009    /*------------------------------------------------------*/
//INN-R170009    /*   Get Info for StartReservation use APC I/F or not   */
//INN-R170009    /*------------------------------------------------------*/
//INN-R170009    objAPC_interfaceFlag_Check_out strAPC_interfaceFlag_Check_out;
//INN-R170009    rc = APC_interfaceFlag_Check( strAPC_interfaceFlag_Check_out,
//INN-R170009                                  strObjCommonIn,
//INN-R170009                                  strLotsInfoForOpeStartInqResult.strStartCassette );

//INN-R170009    if ( rc != RC_OK )
//INN-R170009    {
//INN-R170009        PPT_METHODTRACE_V1( "", "APC_interfaceFlag_Check() != RC_OK" );
//INN-R170009        strLotsInfoForOpeStartInqResult.strResult = strAPC_interfaceFlag_Check_out.strResult;
//INN-R170009        return (rc);
//INN-R170009    }

//INN-R170009    if ( strAPC_interfaceFlag_Check_out.APCInterFaceFlag )
//INN-R170009    {
//INN-R170009        PPT_METHODTRACE_V1( "", "APCInterFaceFlag is TRUE!!!" );

//INN-R170009        /*-------------------------------------------------*/
//INN-R170009        /*   Get from APCInterface AdjustRecipeParameter   */
//INN-R170009        /*-------------------------------------------------*/
//INN-R170009        PPT_METHODTRACE_V1("", "Get from APCInterface APCMgr_SendRecipeParamInq");
//INN-R170009        objAPCMgr_SendRecipeParamInq_out strAPCMgr_SendRecipeParamInq_out;
//INN-R170009        rc = APCMgr_SendRecipeParamInq(
//INN-R170009                                        strAPCMgr_SendRecipeParamInq_out,
//INN-R170009                                        strObjCommonIn,
//INN-R170009                                        strLotsInfoForOpeStartInqResult.equipmentID,
//INN-R170009                                        strLotsInfoForOpeStartInqResult.portGroupID,
//INN-R170009                                        strLotsInfoForOpeStartInqResult.controlJobID,
//INN-R170009                                        strLotsInfoForOpeStartInqResult.strStartCassette );

//INN-R170009        if ( rc != RC_OK )
//INN-R170009        {
//INN-R170009            PPT_METHODTRACE_V1( "", "APCMgr_SendRecipeParamInq() != RC_OK" );
//INN-R170009            strLotsInfoForOpeStartInqResult.strResult = strAPCMgr_SendRecipeParamInq_out.strResult;
//INN-R170009            return (rc);
//INN-R170009        }

//INN-R170009        strLotsInfoForOpeStartInqResult.strStartCassette = strAPCMgr_SendRecipeParamInq_out.strStartCassette;
//INN-R170009    }
//INN-R170009#endif
    //INN-R170009 Start//
    CORBA::String_var APCFlag = CIMFWStrDup(getenv(SP_APC_Available));
    PPT_METHODTRACE_V2("", "APCAvailable", APCFlag);

    if (CIMFWStrCmp(APCFlag,SP_CheckFlag_On) == 0)
    {
        csObjAPCMgr_SendLithoRecommendInfoInq_in  strObjAPCMgr_SendLithoRecommendInfoInq_in;
        csObjAPCMgr_SendLithoRecommendInfoInq_out strObjAPCMgr_SendLithoRecommendInfoInq_out;
        strObjAPCMgr_SendLithoRecommendInfoInq_in.equipmentID      = equipmentID;
        strObjAPCMgr_SendLithoRecommendInfoInq_in.action           = CIMFWStrDup ( CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND );
        strObjAPCMgr_SendLithoRecommendInfoInq_in.strStartCassette = strLotsInfoForOpeStartInqResult.strStartCassette;
        rc = cs_APCMgr_SendLithoRecommendInfoInq( strObjAPCMgr_SendLithoRecommendInfoInq_out,
                                       strObjCommonIn,
                                       strObjAPCMgr_SendLithoRecommendInfoInq_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_APCMgr_SendLithoRecommendInfoInq() != RC_OK");
            strLotsInfoForOpeStartInqResult.strResult = strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult;
            return ( rc );
        }
        strLotsInfoForOpeStartInqResult.strStartCassette  =  strObjAPCMgr_SendLithoRecommendInfoInq_out.strStartCassette ;
    }
    //INN-R170009 end//
//D4000014 end

    traceSampledStartCassette( strLotsInfoForOpeStartInqResult.strStartCassette );  //D9000003

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
//D9000003 add start
    if ( slotmapConflictWarnFlag == TRUE )
    {
        PPT_SET_MSG_RC_KEY( strLotsInfoForOpeStartInqResult, MSG_SMPL_SLOTMAP_CONFLICT_WARN, RC_SMPL_SLOTMAP_CONFLICT_WARN, smplMessage.str() );
        smplMessage.rdbuf()->freeze( 0 );
        PPT_METHODTRACE_V2( "", "txLotsInfoForOpeStartInq MSG", strLotsInfoForOpeStartInqResult.strResult.messageText );
        PPT_METHODTRACE_EXIT( "PPTManager_i::txLotsInfoForOpeStartInq " );
        return RC_SMPL_SLOTMAP_CONFLICT_WARN;
    }
    else
    {
//D9000003 add end
        SET_MSG_RC( strLotsInfoForOpeStartInqResult, MSG_OK, RC_OK );    //D9000003 Indentation is adjusted.
    }  //D9000003
    PPT_METHODTRACE_EXIT( "PPTManager_i::txLotsInfoForOpeStartInq " );
    return (rc);
}
