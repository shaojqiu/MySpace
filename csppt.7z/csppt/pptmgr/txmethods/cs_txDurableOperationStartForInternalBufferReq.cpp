//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txDurableOperationStartForInternalBufferReq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txDurableOperationStartForInternalBufferReq
(
    csDurableOperationStartForInternalBufferReqResult&          strDurableOperationStartForInternalBufferReqResult,
    const pptObjCommonIn&                                       strObjCommonIn,
    const csDurableOperationStartForInternalBufferReqInParam&   strDurableOperationStartForInternalBufferReqInParam,
    const char *                                                claimMemo
    CORBAENV_LAST_CPP
)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txDurableOperationStartForInternalBufferReq");

    /*--------------------------------------------*/
    /*                                            */
    /*      Pre Process                           */
    /*                                            */
    /*--------------------------------------------*/
    // Initialize
    CORBA::Long rc = RC_OK;

    const csDurableOperationStartForInternalBufferReqInParam& strInParm = strDurableOperationStartForInternalBufferReqInParam;

    /*--------------------------------------------*/
    /*                                            */
    /*      In-Parameter Trace                    */
    /*                                            */
    /*--------------------------------------------*/
    //Trace InParameters
    PPT_METHODTRACE_V2("", "in-parm equipmentID          ", strInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "in-parm durableControlJobID  ", strInParm.durableControlJobID.identifier);
    PPT_METHODTRACE_V2("", "in-parm durableCategory      ", strInParm.durableCategory);

    if ( 0 >= CIMFWStrLen(strInParm.durableControlJobID.identifier) )
    {
        PPT_METHODTRACE_V1("", "durableControlJobID is empty.");
        SET_MSG_RC( strDurableOperationStartForInternalBufferReqResult,
                    MSG_DURABLECTRLJOBID_BLANK,
                    RC_DURABLECTRLJOBID_BLANK );
        return RC_DURABLECTRLJOBID_BLANK;
    }

    const char* durableCategory = strInParm.durableCategory;
    if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
        PPT_SET_MSG_RC_KEY( strDurableOperationStartForInternalBufferReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            durableCategory );
        return RC_INVALID_DURABLE_CATEGORY ;
    }

    CORBA::ULong durableLen = strInParm.strStartDurables.length();
    if ( 0 >= durableLen )
    {
        PPT_METHODTRACE_V1("", "0 > = CIMFWStrLen(strStartDurables.length())");
        SET_MSG_RC( strDurableOperationStartForInternalBufferReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Tx ID Check                           */
    /*                                            */
    /*--------------------------------------------*/
    objEquipment_SpecialControlVsTxID_CheckCombination_out strEquipment_SpecialControlVsTxID_CheckCombination_out;
    objEquipment_SpecialControlVsTxID_CheckCombination_in  strEquipment_SpecialControlVsTxID_CheckCombination_in;
    strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID = strInParm.equipmentID;
    rc = equipment_SpecialControlVsTxID_CheckCombination( strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                                          strObjCommonIn,
                                                          strEquipment_SpecialControlVsTxID_CheckCombination_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_SpecialControlVsTxID_CheckCombination() != RC_OK", rc);
        strDurableOperationStartForInternalBufferReqResult.strResult = strEquipment_SpecialControlVsTxID_CheckCombination_out.strResult;
        return rc;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Object Lock Process                   */
    /*                                            */
    /*--------------------------------------------*/
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = strInParm.equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "CSPDC008" ); // CS_TxDurableOperationStartForInternalBufferReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strDurableOperationStartForInternalBufferReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return rc;
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = strInParm.equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2("", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject);
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return rc;
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode == SP_EQP_LOCK_MODE_WRITE");
        PPT_METHODTRACE_V1("", "#### Machine Object Lock ");

        // Machine Object Lock Process
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          strInParm.equipmentID,
                          SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return rc;
        }
    }

    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
        {
            // Lock Cassette Element (Read)
            CORBA::ULong cassetteLen = strInParm.strStartDurables.length();
            stringSequence cassetteSeq;
            cassetteSeq.length(cassetteLen);
            for ( CORBA::ULong cassetteCnt=0; cassetteCnt < cassetteLen; cassetteCnt++ )
            {
                PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", cassetteCnt);
                cassetteSeq[cassetteCnt] = strInParm.strStartDurables[cassetteCnt].durableID.identifier;
            }

            strAdvanced_object_Lock_in.objectID   = strInParm.equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_READ;
            strAdvanced_object_Lock_in.keySeq     = cassetteSeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                       strObjCommonIn,
                                       strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strDurableOperationStartForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return rc;
            }
        }
    }

    // Lock DurableControlJob Object Process
    rc = object_Lock( strObject_Lock_out,
                      strObjCommonIn,
                      strInParm.durableControlJobID,
                      SP_ClassName_PosDurableControlJob );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
        strDurableOperationStartForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }

    CORBA::ULong durableCnt = 0;
    objectIdentifierSequence durableIDs;
    durableIDs.length(durableLen);
    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
        durableIDs[durableCnt] = strInParm.strStartDurables[durableCnt].durableID;
    }

    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosCassette);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosReticlePod);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosReticlePod );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosProcessDurable);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosProcessDurable );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }

    /*---------------------------------------------------*/
    /*                                                   */
    /*        Durable OnRoute and BRScript Check         */
    /*                                                   */
    /*---------------------------------------------------*/
    CORBA::Boolean onRouteFlag = TRUE;
    CORBA::Boolean tmpOnRouteFlag = TRUE;

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "durable loop index", durableCnt);

        // Check Durable OnRoute
        objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
        objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
        strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
        strDurable_OnRoute_Check_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
        rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
        if(durableCnt == 0)
        {
            if( rc != RC_DURABLE_ONROUTE )
            {
                onRouteFlag = FALSE;
            }
            PPT_METHODTRACE_V3("", "the first durable OnRoute state",
                               (onRouteFlag?"TRUE":"FALSE"),
                               strInParm.strStartDurables[durableCnt].durableID.identifier);
        }
        else
        {
            if( rc != RC_DURABLE_ONROUTE )
            {
                PPT_METHODTRACE_V2("", "durable OnRoute state is FALSE", strInParm.strStartDurables[durableCnt].durableID.identifier);
                tmpOnRouteFlag = FALSE;
            }
            else
            {
                PPT_METHODTRACE_V2("", "durable OnRoute state is TRUE", strInParm.strStartDurables[durableCnt].durableID.identifier);
                tmpOnRouteFlag = TRUE;
            }

            if(tmpOnRouteFlag != onRouteFlag)
            {
                PPT_METHODTRACE_V1("", "all durable OnRoute state is not same");
                SET_MSG_RC( strDurableOperationStartForInternalBufferReqResult, MSG_DURABLE_ONROUTE_STAT_NOT_SAME, RC_DURABLE_ONROUTE_STAT_NOT_SAME );
                return( RC_DURABLE_ONROUTE_STAT_NOT_SAME );
            }
        }
    }

    // Check BRScript for durable
    if(onRouteFlag == TRUE)
    {
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            pptRunDurableBRScriptReqResult  strRunDurableBRScriptReqResult;
            pptRunDurableBRScriptReqInParam strRunDurableBRScriptReqInParam;
            strRunDurableBRScriptReqInParam.phase           = CIMFWStrDup(SP_BRScript_Pre2);
            strRunDurableBRScriptReqInParam.durableCategory = strInParm.durableCategory;
            strRunDurableBRScriptReqInParam.durableID       = strInParm.strStartDurables[durableCnt].durableID;
            strRunDurableBRScriptReqInParam.equipmentID     = strInParm.equipmentID;
            rc = txRunDurableBRScriptReq(strRunDurableBRScriptReqResult, strObjCommonIn, strRunDurableBRScriptReqInParam, claimMemo);
            if(rc == RC_NOT_FOUND_SCRIPT)
            {
                PPT_METHODTRACE_V2("", "txRunDurableBRScriptReq() == RC_NOT_FOUND_SCRIPT", rc);
                rc = RC_OK;
            }
            else if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "txRunDurableBRScriptReq() != RC_OK", rc);
                strDurableOperationStartForInternalBufferReqResult.strResult = strRunDurableBRScriptReqResult.strResult;
                return rc;
            }
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "durable not OnRoute.");
    }

    CORBA::String_var onlineMode;
    objectIdentifier operationMode;
    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");

        /*---------------------------------*/
        /*   Get Equipment's Online Mode   */
        /*---------------------------------*/
        objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
        rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                    strObjCommonIn,
                                                    strInParm.equipmentID,
                                                    strInParm.strStartDurables[0].strStartDurablePort.loadPortID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "portResource_currentOperationMode_Get() rc != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
            return rc;
        }

        onlineMode    = strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode;
        operationMode = strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode;
    }
    else
    {
        PPT_METHODTRACE_V1("", "durableCategory != SP_DurableCat_Cassette");

        objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
        rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out,
                                       strObjCommonIn,
                                       strInParm.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
            return rc;
        }

        onlineMode = strEquipment_onlineMode_Get_out.onlineMode;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Check Process for Durables          */
    /*                                            */
    /*--------------------------------------------*/
    csObjDurable_CheckConditionForOperationForInternalBuffer_in strDurable_CheckConditionForOperationForInternalBuffer_in;
    strDurable_CheckConditionForOperationForInternalBuffer_in.operation             = CIMFWStrDup( SP_Operation_OpeStart );
    strDurable_CheckConditionForOperationForInternalBuffer_in.equipmentID           = strInParm.equipmentID;
    strDurable_CheckConditionForOperationForInternalBuffer_in.durableCategory       = strInParm.durableCategory;
    strDurable_CheckConditionForOperationForInternalBuffer_in.strStartDurables      = strInParm.strStartDurables;
    strDurable_CheckConditionForOperationForInternalBuffer_in.strDurableStartRecipe = strInParm.strDurableStartRecipe;

    csObjDurable_CheckConditionForOperationForInternalBuffer_out strDurable_CheckConditionForOperationForInternalBuffer_out;
    rc = cs_durable_CheckConditionForOperationForInternalBuffer( strDurable_CheckConditionForOperationForInternalBuffer_out,
                                                                 strObjCommonIn,
                                                                 strDurable_CheckConditionForOperationForInternalBuffer_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_durable_CheckConditionForOperationForInternalBuffer() != RC_OK", rc);
        strDurableOperationStartForInternalBufferReqResult.strResult = strDurable_CheckConditionForOperationForInternalBuffer_out.strResult;
        return rc;
    }

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
        objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
        objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
        strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup( SP_Operation_OpeStart );
        strDurable_status_CheckForOperation_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
        strDurable_status_CheckForOperation_in.durableCategory = strInParm.durableCategory;
        rc = durable_status_CheckForOperation( strDurable_status_CheckForOperation_out,
                                               strObjCommonIn,
                                               strDurable_status_CheckForOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_status_CheckForOperation() != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
            return rc;
        }
    }

    /*---------------------------------------------------------------*/
    /*                                                               */
    /*        Check Equipment Port for Durable Operation             */
    /*                                                               */
    /*---------------------------------------------------------------*/
    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in;
    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.operation        = CIMFWStrDup( SP_Operation_OpeStart );
    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.equipmentID      = strInParm.equipmentID;
    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.durableCategory  = strInParm.durableCategory;
    strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.strStartDurables = strInParm.strStartDurables;

    csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out;
    rc = cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                                               strObjCommonIn,
                                                                               strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer() != RC_OK", rc);
        strDurableOperationStartForInternalBufferReqResult.strResult = strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult;
        return rc;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Main process                        */
    /*                                            */
    /*--------------------------------------------*/
    objProcess_startDurablesReserveInformation_Set_out strProcess_startDurablesReserveInformation_Set_out;
    objProcess_startDurablesReserveInformation_Set_in  strProcess_startDurablesReserveInformation_Set_in;
    strProcess_startDurablesReserveInformation_Set_in.equipmentID           = strInParm.equipmentID;
    strProcess_startDurablesReserveInformation_Set_in.portGroupID           = CIMFWStrDup("");
    strProcess_startDurablesReserveInformation_Set_in.durableControlJobID   = strInParm.durableControlJobID;
    strProcess_startDurablesReserveInformation_Set_in.durableCategory       = strInParm.durableCategory;
    strProcess_startDurablesReserveInformation_Set_in.strStartDurables      = strInParm.strStartDurables;
    strProcess_startDurablesReserveInformation_Set_in.strDurableStartRecipe = strInParm.strDurableStartRecipe;
    rc = process_startDurablesReserveInformation_Set( strProcess_startDurablesReserveInformation_Set_out,
                                                      strObjCommonIn,
                                                      strProcess_startDurablesReserveInformation_Set_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "process_startDurablesReserveInformation_Set() != RC_OK", rc);
        strDurableOperationStartForInternalBufferReqResult.strResult = strProcess_startDurablesReserveInformation_Set_out.strResult;
        return rc;
    }

    if ( 0 == CIMFWStrCmp(onlineMode, SP_Eqp_OnlineMode_Offline) )
    {
        PPT_METHODTRACE_V1("", "onlineMode == SP_Eqp_OnlineMode_Offline");

        /*-----------------------------------------------*/
        /*   Change Equipment's Status to 'PRODUCTIVE'   */
        /*-----------------------------------------------*/

        /*===== get StateChageableFlag ===*/
        objEquipment_currentState_CheckToManufacturing_out strEquipment_currentState_CheckToManufacturing_out;
        strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag = FALSE;
        rc = equipment_currentState_CheckToManufacturing( strEquipment_currentState_CheckToManufacturing_out,
                                                          strObjCommonIn,
                                                          strInParm.equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_currentState_GetManufacturing() != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult;
            return rc;
        }

        if ( TRUE == strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag )
        {
            PPT_METHODTRACE_V1("", "ManufacturingStateChangeableFlag == TRUE");

            /*===== get Defaclt Status Code for Productive / Standby ===*/
            objEquipment_recoverState_GetManufacturingForDurable_out strEquipment_recoverState_GetManufacturingForDurable_out;
            objEquipment_recoverState_GetManufacturingForDurable_in strEquipment_recoverState_GetManufacturingForDurable_in;
            strEquipment_recoverState_GetManufacturingForDurable_in.operationType = CIMFWStrDup(SP_Operation_OpeStart);
            strEquipment_recoverState_GetManufacturingForDurable_in.equipmentID = strInParm.equipmentID;
            strEquipment_recoverState_GetManufacturingForDurable_in.durableControlJobID = strInParm.durableControlJobID;
            rc = equipment_recoverState_GetManufacturingForDurable( strEquipment_recoverState_GetManufacturingForDurable_out,
                                                                    strObjCommonIn,
                                                                    strEquipment_recoverState_GetManufacturingForDurable_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_recoverState_GetManufacturingForDurable() != RC_OK", rc);
                strDurableOperationStartForInternalBufferReqResult.strResult = strEquipment_recoverState_GetManufacturingForDurable_out.strResult;
                return rc;
            }

            /*---------------------------------*/
            /*   Call txEqpStatusChangeReq()   */
            /*---------------------------------*/
            pptEqpStatusChangeReqResult strEqpStatusChangeReqResult;
            rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult,
                                       strObjCommonIn,
                                       strInParm.equipmentID,
                                       strEquipment_recoverState_GetManufacturingForDurable_out.equipmentStatusCode,
                                       claimMemo );
            if ( rc != RC_OK && rc != RC_CURRSTATE_SAME )
            {
                PPT_METHODTRACE_V2("", "txEqpStatusChangeReq() != RC_OK", rc);
                strDurableOperationStartForInternalBufferReqResult.strResult = strEqpStatusChangeReqResult.strResult;
                return rc;
            }
        }
    }

    //-----------------------------------
    // Update cassette dispatch state
    //-----------------------------------
    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
            objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out,
                                                strObjCommonIn,
                                                strInParm.strStartDurables[durableCnt].durableID,
                                                FALSE );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_dispatchState_Change() != RC_OK", rc);
                strDurableOperationStartForInternalBufferReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
                return rc;
            }
        }
    }

    if(onRouteFlag == TRUE)
    {
        objDurable_processState_MakeProcessing_out strDurable_processState_MakeProcessing_out;
        objDurable_processState_MakeProcessing_in  strDurable_processState_MakeProcessing_in;
        strDurable_processState_MakeProcessing_in.durableCategory  = strInParm.durableCategory;
        strDurable_processState_MakeProcessing_in.strStartDurables = strInParm.strStartDurables;
        rc = durable_processState_MakeProcessing(strDurable_processState_MakeProcessing_out,
                                                 strObjCommonIn,
                                                 strDurable_processState_MakeProcessing_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_processState_MakeProcessing() != RC_OK", rc);
            strDurableOperationStartForInternalBufferReqResult.strResult = strDurable_processState_MakeProcessing_out.strResult;
            return rc;
        }
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Create Event                        */
    /*                                            */
    /*--------------------------------------------*/
    objDurableOperationStartEvent_MakeOpeStart_out strDurableOperationStartEvent_MakeOpeStart_out;
    objDurableOperationStartEvent_MakeOpeStart_in  strDurableOperationStartEvent_MakeOpeStart_in;
    strDurableOperationStartEvent_MakeOpeStart_in.equipmentID           = strInParm.equipmentID;
    strDurableOperationStartEvent_MakeOpeStart_in.operationMode         = operationMode.identifier;
    strDurableOperationStartEvent_MakeOpeStart_in.durableControlJobID   = strInParm.durableControlJobID;
    strDurableOperationStartEvent_MakeOpeStart_in.durableCategory       = strInParm.durableCategory;
    strDurableOperationStartEvent_MakeOpeStart_in.strStartDurables      = strInParm.strStartDurables;
    strDurableOperationStartEvent_MakeOpeStart_in.strDurableStartRecipe = strInParm.strDurableStartRecipe;
    strDurableOperationStartEvent_MakeOpeStart_in.claimMemo             = claimMemo;
    rc = durableOperationStartEvent_MakeOpeStart( strDurableOperationStartEvent_MakeOpeStart_out,
                                                  strObjCommonIn,
                                                  strDurableOperationStartEvent_MakeOpeStart_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durableOperationStartEvent_MakeOpeStart() != RC_OK", rc);
        strDurableOperationStartForInternalBufferReqResult.strResult = strDurableOperationStartEvent_MakeOpeStart_out.strResult;
        return rc;
    }

    /*---------------------------------------------------*/
    /*                                                   */
    /*        Send DurableOpeStartReq() to TCS           */
    /*                                                   */
    /*---------------------------------------------------*/
    CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0;
    CORBA::Long retryCountValue = 0;

    if ( 0 == CIMFWStrLen(tmpSleepTimeValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = atoi(tmpSleepTimeValue);
    }

    if ( 0 == CIMFWStrLen(tmpRetryCountValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("", "env value of SP_BIND_SLEEP_TIME_TCS  = ", sleepTimeValue);
    PPT_METHODTRACE_V2("", "env value of SP_BIND_RETRY_COUNT_TCS = ", retryCountValue);

    objTCSMgr_SendDurableOpeStartReq_out strTCSMgr_SendDurableOpeStartReq_out;
    objTCSMgr_SendDurableOpeStartReq_in  strTCSMgr_SendDurableOpeStartReq_in;
    strTCSMgr_SendDurableOpeStartReq_in.strDurableOperationStartReqInParam.equipmentID           = strInParm.equipmentID;
    strTCSMgr_SendDurableOpeStartReq_in.strDurableOperationStartReqInParam.durableControlJobID   = strInParm.durableControlJobID;
    strTCSMgr_SendDurableOpeStartReq_in.strDurableOperationStartReqInParam.durableCategory       = strInParm.durableCategory;
    strTCSMgr_SendDurableOpeStartReq_in.strDurableOperationStartReqInParam.strStartDurables      = strInParm.strStartDurables;
    strTCSMgr_SendDurableOpeStartReq_in.strDurableOperationStartReqInParam.strDurableStartRecipe = strInParm.strDurableStartRecipe;
    strTCSMgr_SendDurableOpeStartReq_in.claimMemo                                                = claimMemo;

    //'retryCountValue + 1' means first try plus retry count
    for ( CORBA::ULong retryNum=0; retryNum < (retryCountValue + 1); retryNum++ )
    {
        PPT_METHODTRACE_V2("", "loop to retryCountValue + 1", retryNum);
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        rc = TCSMgr_SendDurableOpeStartReq( strTCSMgr_SendDurableOpeStartReq_out,
                                            strObjCommonIn,
                                            strTCSMgr_SendDurableOpeStartReq_in );

        PPT_METHODTRACE_V2("", "rc = ", rc);

        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL
               || rc == RC_EXT_SERVER_NIL_OBJ
               || rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("", "TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...", retryNum);
            PPT_METHODTRACE_V2("", "now sleeping... ", sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendDurableOpeStartReq() != RC_OK");
            strDurableOperationStartForInternalBufferReqResult.strResult = strTCSMgr_SendDurableOpeStartReq_out.strResult;
            return rc;
        }
    }

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "TCSMgr_SendDurableOpeStartReq() != RC_OK");
        strDurableOperationStartForInternalBufferReqResult.strResult = strTCSMgr_SendDurableOpeStartReq_out.strResult;
        return rc;
    }

    pptDurableControlJobManageReqResult  strDurableControlJobManageReqResult;
    pptDurableControlJobManageReqInParam strDurableControlJobManageReqInParam;
    strDurableControlJobManageReqInParam.durableControlJobID               = strInParm.durableControlJobID;
    strDurableControlJobManageReqInParam.controlJobAction                  = CIMFWStrDup( SP_DurableControlJobAction_Type_queue );
    pptDurableControlJobCreateRequest strDurableControlJobCreateRequest;
    strDurableControlJobCreateRequest.equipmentID      = strInParm.equipmentID;
    strDurableControlJobCreateRequest.durableCategory  = strInParm.durableCategory;
    strDurableControlJobCreateRequest.strStartDurables = strInParm.strStartDurables;
    strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest = strDurableControlJobCreateRequest;
    rc = txDurableControlJobManageReq( strDurableControlJobManageReqResult,
                                       strObjCommonIn,
                                       strDurableControlJobManageReqInParam,
                                       claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txDurableControlJobManageReq() != RC_OK", rc);
        strDurableOperationStartForInternalBufferReqResult.strResult = strDurableControlJobManageReqResult.strResult;
        return rc;
    }

    // Set Return Structure
    strDurableOperationStartForInternalBufferReqResult.durableControlJobID   = strInParm.durableControlJobID;
    strDurableOperationStartForInternalBufferReqResult.durableCategory       = strInParm.durableCategory;
    strDurableOperationStartForInternalBufferReqResult.strStartDurables      = strInParm.strStartDurables;
    strDurableOperationStartForInternalBufferReqResult.strDurableStartRecipe = strInParm.strDurableStartRecipe;

    // Return to caller
    SET_MSG_RC( strDurableOperationStartForInternalBufferReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txDurableOperationStartForInternalBufferReq");
    return RC_OK;
}
