//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txUnloadingLotRptOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txUnloadingLotRpt()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/21          O.Sugiyama     Initial Release
// 2000-09-20 Q3000107 Y.Iwasaki      Add Logic for Empty Cassette Unloading
// 2000-09-25 P3000223 Y.Iwasaki      Change check condition for lot
// 2000-09-26 Q3000192 Y.Iwasaki      Change check condition for empty cassette
// 2000-09-28 P3000239 Y.Iwasaki      Change lot's processState check logic
// 2001-07-05 D4000015 H.Katoh        Add Equipment Category Check Logic because of
//                                    Internal BUffer Suppot
// 2001-08-01 D4000056 M.Shimizu      Add Slot Map Exist Check for Wafer Sorter And Delete to SlotMap [R40 Core]
// 2001-08-21 P4000099 H.Adachi       Change objectName(waferSorter_SlotMap_DeleteDR to waferSorter_slotMap_DeleteDR)
//                                                     (equipment_categoryCheckForWaferSorter to equipment_CheckCategoryForWaferSorter)
// 2001-08-24 D4000056 M.Shimizu      Change Call objmethod equipment_CheckCategoryForWaferSorter() -> strEqpInfoBySQL()
// 2001-08-31 D4000056 M.Shimizu      Delete Logic to WaferSorter
// 2001-09-11 D4000056 M.Shimizu      Restoration Logic to WaferSorter
// 2002-02-04 D4100110 S.Tokumasu     Add timeStamp into xferStatusChangeRpt
// 2002-02-14 D4100134 C.Tsuchiya     Use getenv() instead of Mgr class member 'theSP_xxx'
// 2002-03-25 D4100206 C.Tsuchiya     Remove SP_EqpInfo_By_SQL env val and use DR code every time.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/10/24 D6000479 K.Kido         Lock Port Object.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/03 DSIV00000099 M.Ogawa        equipment_brInfo_GetDR ==> equipment_brInfo_GetDR__100
// 2011/08/09 DSN000015229 Sa Guo         equipment_brInfo_GetDR__100 ==> equipment_brInfo_GetDR__120
// 2012/11/30 DSN000049350 S.Liu          Equipment parallel processing support (P2)
// 2014/12/29 DSN000085770 C.Mo           Durable Control Job Management support.
// 2015/11/10 PSN000081321 XF.Ming        txLotCassetteXferStatusChangeRpt ==> txLotCassetteXferStatusChangeRpt__160
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017/11/07 INN-R170016   JJ.Zhang       Equipment monitor enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptUnloadingLotRptResult&   strUnloadingLotRptResult
//    const pptObjCommonIn&       strObjCommonIn
//    const objectIdentifier&     equipmentID
//    const objectIdentifier&     cassetteID
//    const objectIdentifier&     portID
//    const char *                claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//INN-R170016 CORBA::Long PPTManager_i:: txUnloadingLotRpt (
CORBA::Long CS_PPTManager_i:: txUnloadingLotRpt ( //INN-R170016
    pptUnloadingLotRptResult&   strUnloadingLotRptResult,
    const pptObjCommonIn&       strObjCommonIn,
    const objectIdentifier&     equipmentID,
    const objectIdentifier&     cassetteID,
    const objectIdentifier&     portID,
//D6000025     const char *                claimMemo,
//D6000025     CORBA::Environment &        IT_env)
    const char *                claimMemo  //D6000025
    CORBAENV_LAST_CPP)                     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txUnloadingLotRpt ");

    CORBA::Long rc = RC_OK ;

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRR004" ); // TxUnloadingLotRpt
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strUnloadingLotRptResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;
    
    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Advanced Mode
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strUnloadingLotRptResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
        
        // Lock Equipment LoadCassette Element (Write)
        stringSequence loadCastSeq;
        loadCastSeq.length(1);
        loadCastSeq[0] = cassetteID.identifier;
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strUnloadingLotRptResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "object_Lock(equipmentID) != RC_OK" );
            strUnloadingLotRptResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

//D6000479 add start
    /*----------------------------------------------------------*/
    /*   Get All Port Objects belong to a input Port's PortGrp  */
    /*----------------------------------------------------------*/
    objPortResource_allPortsInSameGroup_Get_out strPortResource_allPortsInSameGroup_Get_out;
    rc = portResource_allPortsInSameGroup_Get( strPortResource_allPortsInSameGroup_Get_out,
                                               strObjCommonIn,
                                               equipmentID,
                                               portID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "portResource_allPortsInSameGroup_Get() rc != RC_OK", rc);
        strUnloadingLotRptResult.strResult = strPortResource_allPortsInSameGroup_Get_out.strResult;
        return( rc );
    }

    /*---------------------------------------------------------*/
    /* Lock All Ports being in the same Port Group as ToPort   */
    /*---------------------------------------------------------*/
    CORBA::Long lenToPort = strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length();
    for ( CORBA::Long kk =0 ; kk < lenToPort ; kk++ )
    {
        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID,
                                              SP_ClassName_PosPortResource );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID.identifier) ;
            strUnloadingLotRptResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "Locked port object  : ", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID.identifier) ;
    }
//D6000479 add end

//DSN000085770 add start (position move)
    /*---------------------------------*/
    /*   Get Equipment's Online Mode   */
    /*---------------------------------*/
    objPortResource_currentOperationMode_Get_out  strPortResource_currentOperationMode_Get_out;
    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                strObjCommonIn,
                                                equipmentID,
                                                portID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "portResource_currentOperationMode_Get() != RC_OK", rc );
        strUnloadingLotRptResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
        return( rc );
    }

    if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline) ||
         0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto) )
    {
        PPT_METHODTRACE_V3( "", "onlineMode = Offline or accessMode = Auto", strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode);

        objDurable_durableControlJobID_Get_out strDurable_durableControlJobID_Get_out;
        objDurable_durableControlJobID_Get_in  strDurable_durableControlJobID_Get_in;
        strDurable_durableControlJobID_Get_in.durableID       = cassetteID;
        strDurable_durableControlJobID_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
        rc = durable_durableControlJobID_Get( strDurable_durableControlJobID_Get_out, 
                                              strObjCommonIn, 
                                              strDurable_durableControlJobID_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","durable_durableControlJobID_Get() returned error.");
            strUnloadingLotRptResult.strResult = strDurable_durableControlJobID_Get_out.strResult;
            return (rc);
        }

        if ( CIMFWStrLen(strDurable_durableControlJobID_Get_out.durableControlJobID.identifier) > 0 )
        {
            PPT_METHODTRACE_V2("","durableControlJobID is not blank", strDurable_durableControlJobID_Get_out.durableControlJobID.identifier);

            rc = object_Lock( strObject_Lock_out,
                              strObjCommonIn,
                              strDurable_durableControlJobID_Get_out.durableControlJobID,
                              SP_ClassName_PosDurableControlJob );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strUnloadingLotRptResult.strResult = strObject_Lock_out.strResult;
                return rc;
            }

            objDurableControlJob_status_Get_out strDurableControlJob_status_Get_out;
            objDurableControlJob_status_Get_in  strDurableControlJob_status_Get_in;
            strDurableControlJob_status_Get_in.durableControlJobID = strDurable_durableControlJobID_Get_out.durableControlJobID;
            rc = durableControlJob_status_Get( strDurableControlJob_status_Get_out, 
                                               strObjCommonIn, 
                                               strDurableControlJob_status_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","durableControlJob_status_Get() returned error.");
                strUnloadingLotRptResult.strResult = strDurableControlJob_status_Get_out.strResult;
                return (rc);
            }
            PPT_METHODTRACE_V2("","strDurableControlJob_status_Get_out.durableControlJobStatus",strDurableControlJob_status_Get_out.durableControlJobStatus);

            if ( CIMFWStrCmp(strDurableControlJob_status_Get_out.durableControlJobStatus, SP_DurableControlJobStatus_Created) != 0 &&
                 CIMFWStrCmp(strDurableControlJob_status_Get_out.durableControlJobStatus, SP_DurableControlJobStatus_Delete) != 0 )
            {
                PPT_METHODTRACE_V1("", "##### return RC_INVALID_DCJSTATUS");
                PPT_SET_MSG_RC_KEY( strUnloadingLotRptResult, 
                                    MSG_INVALID_DCJSTATUS, 
                                    RC_INVALID_DCJSTATUS, 
                                    strDurableControlJob_status_Get_out.durableControlJobStatus );
                return RC_INVALID_DCJSTATUS;
            }
        }
    }
//DSN000085770 add end

    rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                      cassetteID, SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "object_Lock(cassetteID) != RC_OK" );
        strUnloadingLotRptResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//DSN000085770     //P3000223 add start (position move)
//DSN000085770     /*---------------------------------*/
//DSN000085770     /*   Get Equipment's Online Mode   */
//DSN000085770     /*---------------------------------*/
//DSN000085770     objPortResource_currentOperationMode_Get_out  strPortResource_currentOperationMode_Get_out;
//DSN000085770     rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
//DSN000085770                                                 strObjCommonIn,
//DSN000085770                                                 equipmentID,
//DSN000085770                                                 portID );
//DSN000085770     if ( rc != RC_OK )
//DSN000085770     {
//DSN000085770         PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "portResource_currentOperationMode_Get() != RC_OK" );
//DSN000085770         strUnloadingLotRptResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
//DSN000085770         return( rc );
//DSN000085770     }
//DSN000085770     //P3000223 add end

    //D4000015 Start
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strUnloadingLotRptResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //D4000015 End

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - transferState                                                     */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objCassette_CheckConditionForUnloading_out strCassette_CheckConditionForUnloading_out;
    rc = cassette_CheckConditionForUnloading( strCassette_CheckConditionForUnloading_out, strObjCommonIn,
                                              cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "cassette_CheckConditionForUnloading() != RC_OK" );
        strUnloadingLotRptResult.strResult = strCassette_CheckConditionForUnloading_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - lotProcessState                                                   */
    /*                                                                       */
    /*   Note:                                                               */ //P3000239
    /*   If equipment is Offline or Auto-Access case, all of lot, which is   */ //P3000239
    /*   contained in cassette of same controlJob of in-parm's cassette,     */ //P3000239
    /*   must not be "Processing".                                           */ //P3000239
    /*                                                                       */
    /*-----------------------------------------------------------------------*/

//P3000239 delete start
//  /*------------------------------*/
//  /*   Get Lot List in Cassette   */
//  /*------------------------------*/
//  CORBA::Boolean emptyCassetteFlag = FALSE;                                   //Q3000107
//  objCassette_GetLotList_out strCassette_GetLotList_out;
//  rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn,
//                            cassetteID );
//  if ( rc == RC_NOT_FOUND_LOT )                                               //Q3000107
//  {                                                                           //Q3000107
//      PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt",         //Q3000107
//                          "cassette is empty..." );                           //Q3000107
//      emptyCassetteFlag = TRUE;                                               //Q3000107
//      rc = RC_OK;                                                             //Q3000107
//  }                                                                           //Q3000107
//  if ( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "cassette_GetLotList() != RC_OK" );
//      strUnloadingLotRptResult.strResult = strCassette_GetLotList_out.strResult;
//      return( rc );
//  }
//
//  /*---------------------------*/
//  /*   Check Lot's Confition   */
//  /*---------------------------*/
//  if ( emptyCassetteFlag == FALSE )                                           //Q3000107
//  {                                                                           //Q3000107
//
//      PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt",                 //Q3000107
//                          "emptyCassetteFlag == FALSE..." );                  //Q3000107
//
//      /*--------------------------------*/                                                                                          //P3000223
//      /*   Check Port's OperationMode   */                                                                                          //P3000223
//      /*--------------------------------*/                                                                                          //P3000223
//      if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode,SP_Eqp_OnlineMode_Offline) == 0 ||  //P3000223
//           CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,SP_Eqp_AccessMode_Auto )   == 0 )   //P3000223
//      {                                                                                                                             //P3000223
//          objLot_CheckConditionForUnloading_out strLot_CheckConditionForUnloading_out;
//          rc = lot_CheckConditionForUnloading( strLot_CheckConditionForUnloading_out, strObjCommonIn,
//                                               strCassette_GetLotList_out.strLotListInCassetteInfo );
//          if ( rc != RC_OK )
//          {
//              PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "lot_CheckConditionForUnloading() != RC_OK" );
//              strUnloadingLotRptResult.strResult = strLot_CheckConditionForUnloading_out.strResult;
//              return( rc );
//          }
//      }                                                                                                                           //P3000223
//
//  }                                                                           //Q3000107
//
//  //Q3000192 add start
//  /*--------------------------------------*/
//  /*   Check Empty Cassette's Condition   */
//  /*--------------------------------------*/
//  else
//  {
//P3000239 delete end

//      CORBA::Long i, j;

        /*--------------------------------*/
        /*   Check Port's OperationMode   */
        /*--------------------------------*/
        if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline) ||
             0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto) )
        {
            /*---------------------------------*/
            /*   Get Cassette's ControlJobID   */
            /*---------------------------------*/
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "cassette_controlJobID_Get() != RC_OK" );
                strUnloadingLotRptResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }

            if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
            {
                PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "len(controlJobID) > 0" );

                /*-------------------------*/
                /*   Get ControlJob Info   */
                /*-------------------------*/
                PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "Get ControlJob Info" );

                objControlJob_containedLot_Get_out strControlJob_containedLot_Get_out;

                rc = controlJob_containedLot_Get( strControlJob_containedLot_Get_out,
                                                  strObjCommonIn,
                                                  strCassette_controlJobID_Get_out.controlJobID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "controlJob_containedLot_Get() != RC_OK" );
                    strUnloadingLotRptResult.strResult = strControlJob_containedLot_Get_out.strResult;
                    return( rc );
                }

                /*----------------------------------------*/
                /*   Check ControlJobLot's ProcessState   */
                /*----------------------------------------*/
                PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "Check ControlJobLot's ProcessState" );
                CORBA::Long lenCtrlJobCassette = strControlJob_containedLot_Get_out.strControlJobCassette.length();
                CORBA::Long lenCtrlJobLot;
                PPT_METHODTRACE_V2( "PPTManager_i:: txUnloadingLotRpt", "strControlJobCassette.length--->", lenCtrlJobCassette);

                for ( CORBA::Long i=0; i < lenCtrlJobCassette; i++ )
                {
                    lenCtrlJobLot = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot.length();
                    PPT_METHODTRACE_V2( "PPTManager_i:: txUnloadingLotRpt", "strControlJobLot.length--->", lenCtrlJobLot);

                    if ( 0 == lenCtrlJobLot )
                    {
                        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "0 == lenCtrlJobLot" );
                        continue;
                    }

                    PPT_METHODTRACE_V2( "PPTManager_i:: txUnloadingLotRpt", "strControlJobCassette[i].cassetteID--->",
                                    strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID.identifier);

                    objCassette_GetLotList_out strCassette_GetLotList_out;
                    rc = cassette_GetLotList( strCassette_GetLotList_out,
                                              strObjCommonIn,
                                              strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "cassette_GetLotList() != RC_OK" );
                        strUnloadingLotRptResult.strResult = strCassette_GetLotList_out.strResult;
                        return( rc );
                    }

                    objLot_CheckConditionForUnloading_out strLot_CheckConditionForUnloading_out;

                    rc = lot_CheckConditionForUnloading( strLot_CheckConditionForUnloading_out,
                                                         strObjCommonIn,
                                                         strCassette_GetLotList_out.strLotListInCassetteInfo );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "lot_CheckConditionForUnloading() != RC_OK" );
                        strUnloadingLotRptResult.strResult = strLot_CheckConditionForUnloading_out.strResult;
                        return( rc );
                    }
                }
            }
        }                                                                                                              //P3000223
//  }
    //Q3000192 add end

    /*-----------------------------------------------------------------------------*/
    /*                                                                             */
    /*   Check Equipment Port for Unloading                                        */
    /*                                                                             */
    /*   The following conditions are checked by this object                       */
    /*                                                                             */
    /*   - In-parm's portID must has loadedCassetteID, and it must be same as      */
    /*     in-parm's cassetteID.                                                   */
    /*                                                                             */
    /*-----------------------------------------------------------------------------*/
    objEquipment_portState_CheckForUnloading_out strEquipment_portState_CheckForUnloading_out;
    rc = equipment_portState_CheckForUnloading( strEquipment_portState_CheckForUnloading_out, strObjCommonIn,
                                                equipmentID, portID, cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "equipment_portState_CheckForUnloading() != RC_OK" );
        strUnloadingLotRptResult.strResult = strEquipment_portState_CheckForUnloading_out.strResult;
        return( rc );
    }

//DSIV00000099 Add Start
//DSN000015229    PPT_METHODTRACE_V1("", "call equipment_brInfo_GetDR__100()...");
//DSN000015229    objEquipment_brInfo_GetDR_out__100 strEquipment_brInfo_GetDR_out;
//DSN000015229    objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
//DSN000015229    strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
//DSN000015229    rc = equipment_brInfo_GetDR__100(strEquipment_brInfo_GetDR_out, strObjCommonIn, strEquipment_brInfo_GetDR_in);
//DSN000015229    if ( rc != RC_OK )
//DSN000015229    {
//DSN000015229        PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR__100() rc != RC_OK", rc);
//DSN000015229        strUnloadingLotRptResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
//DSN000015229        return( rc );
//DSN000015229    }
//DSN000015229 Add Start
    PPT_METHODTRACE_V1("", "call equipment_brInfo_GetDR__120()...");
    objEquipment_brInfo_GetDR_out__120 strEquipment_brInfo_GetDR_out;
    objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
    strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
    rc = equipment_brInfo_GetDR__120(strEquipment_brInfo_GetDR_out, strObjCommonIn, strEquipment_brInfo_GetDR_in);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR__120() != RC_OK", rc);
        strUnloadingLotRptResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
        return( rc );
    }
//DSN000015229 Add End

    // Check SLM Capability
    if ( TRUE == strEquipment_brInfo_GetDR_out.equipmentBRInfo.SLMCapabilityFlag )
    {
        PPT_METHODTRACE_V1("", "SLM Capability is ON.");
        /*----------------------------------------*/
        /*                                        */
        /*   Check Condition for SLM.             */
        /*                                        */
        /*----------------------------------------*/
        objSLM_CheckConditionForUnloading_in  strSLM_CheckConditionForUnloading_in;

        strSLM_CheckConditionForUnloading_in.equipmentID = equipmentID;
        strSLM_CheckConditionForUnloading_in.cassetteID = cassetteID;

        objSLM_CheckConditionForUnloading_out strSLM_CheckConditionForUnloading_out;
        rc = SLM_CheckConditionForUnloading( strSLM_CheckConditionForUnloading_out,
                                             strObjCommonIn,
                                             strSLM_CheckConditionForUnloading_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "SLM_CheckConditionForUnloading() != RC_OK", rc);
            strUnloadingLotRptResult.strResult = strSLM_CheckConditionForUnloading_out.strResult;
            return( rc );
        }
    }
//DSIV00000099 Add End

//P3000223 delete start
//  /*---------------------------------*/
//  /*   Get Equipment's Online Mode   */
//  /*---------------------------------*/
//  objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
//  rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out, strObjCommonIn,
//                                              equipmentID, portID );
//  if ( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "portResource_currentOperationMode_Get() != RC_OK" );
//      strUnloadingLotRptResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
//      return( rc );
//   }
//P3000223 delete end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*------------------------------------------------------*/
    /*                                                      */
    /*     Clear Loaded Cassette Information on Equipment   */
    /*                                                      */
    /*------------------------------------------------------*/
    objEquipment_loadLot_Delete_out strEquipment_loadLot_Delete_out;
    rc = equipment_loadLot_Delete( strEquipment_loadLot_Delete_out, strObjCommonIn,
                                   equipmentID, portID, cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "equipment_loadLot_Delete() != RC_OK" );
        strUnloadingLotRptResult.strResult = strEquipment_loadLot_Delete_out.strResult;
        return( rc );
    }

    /*-------------------------------------------------------*/
    /*                                                       */
    /*     Change Cassette's TransferState to EquipmentOut   */
    /*                                                       */
    /*-------------------------------------------------------*/

    /*------------------------------------------------------------*/
    /*   Prepare In-Parm for txLotCassetteXferStatusChangeRpt()   */
    /*------------------------------------------------------------*/
    objectIdentifier  dummyStockerID;
    pptXferLot        strXferLot;

    strXferLot.cassetteID     = cassetteID;
    strXferLot.portID         = portID;
    strXferLot.transferStatus = CIMFWStrDup( SP_TransState_EquipmentOut );

    /*-----------------------------------------------------------------*/
    /*   Call txLotCassetteXferStatusChangeRpt() with 'EquipmentOut'   */
    /*-----------------------------------------------------------------*/
    pptLotCassetteXferStatusChangeRptResult strLotCassetteXferStatusChangeRptResult;
//PSN000081321    rc = txLotCassetteXferStatusChangeRpt( strLotCassetteXferStatusChangeRptResult, strObjCommonIn,
    rc = txLotCassetteXferStatusChangeRpt__160( strLotCassetteXferStatusChangeRptResult, strObjCommonIn,    //PSN000081321
                                           cassetteID, SP_TransState_EquipmentOut, FALSE,
                                           equipmentID, portID, "", "",
//PSN000081321                                           strObjCommonIn.strTimeStamp.reportTimeStamp); //D4100110
                                           strObjCommonIn.strTimeStamp.reportTimeStamp,  //PSN000081321
                                           claimMemo);  //PSN000081321
    if ( rc != RC_OK )
    {
//PSN000081321        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "txLotCassetteXferStatusChangeRpt() != RC_OK" );
        PPT_METHODTRACE_V1( "PPTManager_i:: txUnloadingLotRpt", "txLotCassetteXferStatusChangeRpt__160() != RC_OK" );   //PSN000081321
        strUnloadingLotRptResult.strResult = strLotCassetteXferStatusChangeRptResult.strResult;
        return( rc );
    }

//2001-09-11 Restoration D4000056
//2001-08-31 Delete All D4000056
//D4000056 Add Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process for WaferSorter
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1(""," Check Process for WaferSorter ");

//P4000099    objEquipment_categoryCheckForWaferSorter_out strEquipment_categoryCheckForWaferSorter_out;
//P4000099    rc = equipment_categoryCheckForWaferSorter(
//P4000099                                strEquipment_categoryCheckForWaferSorter_out,
//P4000099                                strObjCommonIn,
//P4000099                                equipmentID);

//D4000056    objEquipment_CheckCategoryForWaferSorter_out strEquipment_CheckCategoryForWaferSorter_out;       //P4000099
//D4000056    rc = equipment_CheckCategoryForWaferSorter(
//D4000056                                strEquipment_CheckCategoryForWaferSorter_out,
//D4000056                                strObjCommonIn,
//D4000056                                equipmentID);                                                        //P4000099

//D4000056    if ( rc != RC_OK )
//D4000056    {
//P4000099        PPT_METHODTRACE_V2("txOpeStartReq","equipment_categoryCheckForWaferSorter() != RC_OK",rc);
//P4000099        strUnloadingLotRptResult.strResult = strEquipment_categoryCheckForWaferSorter_out.strResult;
//D4000056        PPT_METHODTRACE_V2("txOpeStartReq","equipment_CheckCategoryForWaferSorter() != RC_OK",rc);   //P4000099
//D4000056        strUnloadingLotRptResult.strResult = strEquipment_CheckCategoryForWaferSorter_out.strResult; //P4000099
//D4000056        return (rc);
//D4000056    }

// Add S D4000056
    CORBA::String_var strEquipmentCategory;
    strEquipmentCategory = CIMFWStrDup("");

//D4100134    CORBA::String_var strEqpInfoBySQL = theSP_EqpInfo_By_SQL;
//D4100206    CORBA::String_var strEqpInfoBySQL = CIMFWStrDup(getenv(SP_EqpInfo_By_SQL));    //D4100134
//D4100206    PPT_METHODTRACE_V2("", "Env value is    ",strEqpInfoBySQL);

//D4100206    if(CIMFWStrCmp(strEqpInfoBySQL , "1") == 0)
//D4100206    {
//DSIV00000099    PPT_METHODTRACE_V1("PPTManager_i:: txUnloadingLotRpt", "call equipment_brInfo_GetDR()...");
//DSIV00000099    objEquipment_brInfo_GetDR_out strEquipment_brInfo_GetDR_out;
//DSIV00000099    rc = equipment_brInfo_GetDR(strEquipment_brInfo_GetDR_out, strObjCommonIn, equipmentID);
//DSIV00000099    PPT_METHODTRACE_V1("PPTManager_i:: txUnloadingLotRpt", "end equipment_brInfo_GetDR()...");
//DSIV00000099    if ( rc != RC_OK )
//DSIV00000099    {
//DSIV00000099        PPT_METHODTRACE_V2("PPTManager_i:: txUnloadingLotRpt", "rc = ",rc);
//DSIV00000099        PPT_METHODTRACE_V1("PPTManager_i:: txUnloadingLotRpt", "equipment_brInfo_GetDR() rc != RC_OK");
//DSIV00000099        strUnloadingLotRptResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
//DSIV00000099        return( rc );
//DSIV00000099    }
    strEquipmentCategory = CIMFWStrDup(strEquipment_brInfo_GetDR_out.equipmentBRInfo.equipmentCategory);
//D4100206    }
//D4100206    else
//D4100206    {
//D4100206        PPT_METHODTRACE_V1("PPTManager_i:: txUnloadingLotRpt", "call equipment_brInfo_Get()...");
//D4100206        objEquipment_brInfo_Get_out strEquipment_brInfo_Get_out;
//D4100206        rc = equipment_brInfo_Get(strEquipment_brInfo_Get_out, strObjCommonIn, equipmentID);
//D4100206        if ( rc != RC_OK )
//D4100206        {
//D4100206            PPT_METHODTRACE_V2("PPTManager_i:: txUnloadingLotRpt", "rc = ",rc);
//D4100206            PPT_METHODTRACE_V1("PPTManager_i:: txUnloadingLotRpt", "equipment_brInfo_Get() rc != RC_OK");

//D4100206            strUnloadingLotRptResult.strResult = strEquipment_brInfo_Get_out.strResult;
//D4100206            return( rc );
//D4100206        }
//D4100206        strEquipmentCategory = CIMFWStrDup(strEquipment_brInfo_Get_out.equipmentBRInfo.equipmentCategory);
//D4100206    }
// Add E D4000056

    PPT_METHODTRACE_V2("", "strEquipmentCategory",strEquipmentCategory);
//P4000099    if(strEquipment_categoryCheckForWaferSorter_out.bCheckCategory == TRUE)
//D4000056    if(strEquipment_CheckCategoryForWaferSorter_out.bCheckCategory == TRUE)                          //P4000099
    if ( CIMFWStrCmp(strEquipmentCategory, SP_Mc_Category_WaferSorter) == 0 )                                  //D4000056
    {
        PPT_METHODTRACE_V1("", "strEquipmentCategory == SP_Mc_Category_WaferSorter");

        //---------------------------------------------
        // Get portGroup
        //---------------------------------------------
        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                     strObjCommonIn,
                                     equipmentID);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("txUnloadingLotRpt", "equipment_portInfo_Get() != RC_OK",rc);
            strUnloadingLotRptResult.strResult = strEquipment_portInfo_Get_out.strResult ;
            return( rc );
        }

        //---------------------------------------------
        // Delete FSSLOTMAP Information
        //---------------------------------------------
        PPT_METHODTRACE_V1(""," Data in SlotMap are erased. ");
        //---------------------------------------------------------------------
        // Carrier ID All means delete all Slotmap Information related Eqp:Port
        //---------------------------------------------------------------------
        objectIdentifierSequence cassetteIDs;
        cassetteIDs.length(1);
        cassetteIDs[0] = cassetteID;

        PPT_METHODTRACE_V2("", "cassetteIDs[0] = ",cassetteIDs[0].identifier);

        pptEqpPortStatusSequence tmpEqpPortStatus;
        tmpEqpPortStatus = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus;

        CORBA::Long nEqpPortLen = tmpEqpPortStatus.length();

        PPT_METHODTRACE_V2("", "tmpEqpPortStatus.length = ",nEqpPortLen);
        for(CORBA::Long i = 0;i < nEqpPortLen ; i++)
        {
            if(CIMFWStrCmp(tmpEqpPortStatus[i].portID.identifier, portID.identifier) == 0)
            {
//P4000099                objWaferSorter_SlotMap_DeleteDR_out strWaferSorter_SlotMap_DeleteDR_out;
//P4000099                rc = waferSorter_SlotMap_DeleteDR( strWaferSorter_SlotMap_DeleteDR_out,
//P4000099                                                   strObjCommonIn,
//P4000099                                                   tmpEqpPortStatus[i].portGroup,
//P4000099                                                   equipmentID,
//P4000099                                                   cassetteIDs,
//P4000099                                                   "",
//P4000099                                                   SP_Sorter_AllDelete,
//P4000099                                                   "");

                objWaferSorter_slotMap_DeleteDR_out strWaferSorter_slotMap_DeleteDR_out;    //P4000099
                rc = waferSorter_slotMap_DeleteDR( strWaferSorter_slotMap_DeleteDR_out,
                                                   strObjCommonIn,
                                                   tmpEqpPortStatus[i].portGroup,
                                                   equipmentID,
                                                   cassetteIDs,
                                                   "",
                                                   SP_Sorter_AllDelete,
                                                   "");                                     //P4000099

                if ( rc != RC_OK )
                {
//P4000099                    PPT_METHODTRACE_V1("txUnloadingLotRpt", "waferSorter_SlotMap_DeleteDR() != RC_OK");
//P4000099                    strUnloadingLotRptResult.strResult = strWaferSorter_SlotMap_DeleteDR_out.strResult ;
                    PPT_METHODTRACE_V1("txUnloadingLotRpt", "waferSorter_slotMap_DeleteDR() != RC_OK");    //P4000099
                    strUnloadingLotRptResult.strResult = strWaferSorter_slotMap_DeleteDR_out.strResult ;   //P4000099
                    return( rc );
                }
            }
        }
//INN-R170016 Add Start
        //---------------------------------------------------------------------
        // STB wafers into EqpMonitor lot(s) if carrier is prepared for BWSOut&STB
        //---------------------------------------------------------------------
        csEqpMonitorLotSTBReqInParm strEqpMonitorLotSTBReqInParm;
        strEqpMonitorLotSTBReqInParm.BWSID = equipmentID;
        strEqpMonitorLotSTBReqInParm.carrierID = cassetteID;

        csEqpMonitorLotSTBReqResult strEqpMonitorLotSTBReqResult;
        rc = cs_txEqpMonitorLotSTBReq( strEqpMonitorLotSTBReqResult,
                                     strObjCommonIn,
                                     strEqpMonitorLotSTBReqInParm,
                                     claimMemo );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_txEqpMonitorLotSTBReq() != RC_OK",rc);
            strUnloadingLotRptResult.strResult = strEqpMonitorLotSTBReqResult.strResult ;
            return( rc );
        }
//INN-R170016 Add End
    }
//D4000056 Add End

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/
    SET_MSG_RC( strUnloadingLotRptResult, MSG_OK, RC_OK );

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txUnloadingLotRpt ");
    return( RC_OK );
}
