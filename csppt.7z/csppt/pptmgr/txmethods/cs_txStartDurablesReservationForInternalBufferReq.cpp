//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txStartDurablesReservationForInternalBufferReq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/10/23 INN-R170003  Arvin Chen     Initial release
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txStartDurablesReservationForInternalBufferReq
(
    csStartDurablesReservationForInternalBufferReqResult&           strStartDurablesReservationForInternalBufferReqResult,
    const pptObjCommonIn&                                           strObjCommonIn,
    const csStartDurablesReservationForInternalBufferReqInParam&    strStartDurablesReservationForInternalBufferReqInParam,
    const char *                                                    claimMemo
    CORBAENV_LAST_CPP
)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txStartDurablesReservationForInternalBufferReq");

    /*--------------------------------------------*/
    /*                                            */
    /*      Pre Process                           */
    /*                                            */
    /*--------------------------------------------*/
    // Initialize
    CORBA::Long rc = RC_OK;

    const csStartDurablesReservationForInternalBufferReqInParam& strInParm = strStartDurablesReservationForInternalBufferReqInParam;

    /*--------------------------------------------*/
    /*                                            */
    /*      In-Parameter Trace                    */
    /*                                            */
    /*--------------------------------------------*/
    // Trace InParameters
    PPT_METHODTRACE_V2("", "in-parm equipmentID      ", strInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "in-parm durableCategory  ", strInParm.durableCategory);

    const char* durableCategory = strInParm.durableCategory;
    if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
        PPT_SET_MSG_RC_KEY( strStartDurablesReservationForInternalBufferReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            durableCategory );
        return RC_INVALID_DURABLE_CATEGORY ;
    }

    CORBA::ULong durableLen = strInParm.strStartDurables.length();
    if ( 0 >= durableLen )
    {
        PPT_METHODTRACE_V1("", "0 > = CIMFWStrLen(strStartDurables.length())");
        SET_MSG_RC( strStartDurablesReservationForInternalBufferReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Tx ID Check                           */
    /*                                            */
    /*--------------------------------------------*/
    objEquipment_SpecialControlVsTxID_CheckCombination_out strEquipment_SpecialControlVsTxID_CheckCombination_out;
    objEquipment_SpecialControlVsTxID_CheckCombination_in  strEquipment_SpecialControlVsTxID_CheckCombination_in;
    strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID = strInParm.equipmentID;
    rc = equipment_SpecialControlVsTxID_CheckCombination( strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                                          strObjCommonIn,
                                                          strEquipment_SpecialControlVsTxID_CheckCombination_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_SpecialControlVsTxID_CheckCombination() != RC_OK", rc);
        strStartDurablesReservationForInternalBufferReqResult.strResult = strEquipment_SpecialControlVsTxID_CheckCombination_out.strResult;
        return rc;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*      Object Lock Process                   */
    /*                                            */
    /*--------------------------------------------*/
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = strInParm.equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "CSPDC006" ); // CS_TxStartDurablesReservationForInternalBufferReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strStartDurablesReservationForInternalBufferReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return rc;
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = strInParm.equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2("", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject);
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strStartDurablesReservationForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return rc;
        }

        // Lock Dispatcher Object
        PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosDispatcher );

        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          strInParm.equipmentID,
                          SP_ClassName_PosDispatcher );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strStartDurablesReservationForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return rc;
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode == SP_EQP_LOCK_MODE_WRITE");
        PPT_METHODTRACE_V1("", "#### Machine Object Lock ");

        // Machine Object Lock Process
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          strInParm.equipmentID,
                          SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strStartDurablesReservationForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return rc;
        }
    }

    //-----------------------------------------------
    // Port Object Lock Process
    //-----------------------------------------------
    CORBA::ULong durableCnt = 0;

    // For cassette
    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "[Port Lock Process] durableCategory == SP_DurableCat_Cassette");

        if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            PPT_METHODTRACE_V1("", "[Port Lock Process] lockMode != SP_EQP_LOCK_MODE_WRITE");

            for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
            {
                PPT_METHODTRACE_V2("", "[Port Lock Process] loop to strInParm.strStartDurables.length()", durableCnt);
                objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                      strObjCommonIn,
                                                      strInParm.equipmentID,
                                                      strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID,
                                                      SP_ClassName_PosPortResource );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "[Port Lock Process] object_LockForEquipmentResource() != RC_OK", rc);
                    strStartDurablesReservationForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
                    return rc;
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "[Port Lock Process] lockMode = SP_EQP_LOCK_MODE_WRITE");

            objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
            rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                            strObjCommonIn,
                                                            strInParm.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "[Port Lock Process] equipment_portInfoForInternalBuffer_GetDR() != RC_OK", rc);
                strStartDurablesReservationForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                return rc;
            }

            CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
            for ( CORBA::Long cntPortInfo=0 ; cntPortInfo < lenPortInfo ; cntPortInfo++ )
            {
                PPT_METHODTRACE_V2("", "[Port Lock Process] Try to lock for port object: ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[cntPortInfo].portID.identifier);

                objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                      strObjCommonIn,
                                                      strInParm.equipmentID,
                                                      strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[cntPortInfo].portID,
                                                      SP_ClassName_PosPortResource );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "[Port Lock Process] object_LockForEquipmentResource() != RC_OK", rc);
                    strStartDurablesReservationForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                    return rc;
                }
            }
        }

        //-----------------------------------------------------------------------------
        // Material Location Object (and Buffer resource object )Lock Process
        // ==> This lock process is for Material Location resynchronization.
        //-----------------------------------------------------------------------------
        if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            PPT_METHODTRACE_V1("", "[Material Location Lock Process] lockMode != SP_EQP_LOCK_MODE_WRITE");

            for ( durableCnt = 0; durableCnt < durableLen; durableCnt++ )
            {
                objAdvanced_object_LockForEquipmentResource_in strAdvanced_object_LockForEquipmentResource_in;
                strAdvanced_object_LockForEquipmentResource_in.equipmentID            = strInParm.equipmentID;
                strAdvanced_object_LockForEquipmentResource_in.className              = CIMFWStrDup( SP_ClassName_PosMaterialLocation_EmptyML );
                strAdvanced_object_LockForEquipmentResource_in.objectID               = strInParm.strStartDurables[durableCnt].durableID;
                strAdvanced_object_LockForEquipmentResource_in.objectLockType         = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_LockForEquipmentResource_in.bufferResourceName     = strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPurposeType;
                strAdvanced_object_LockForEquipmentResource_in.bufferResourceLockType = SP_ObjectLock_LockType_READ;

                objAdvanced_object_LockForEquipmentResource_out strAdvanced_object_LockForEquipmentResource_out;
                rc = advanced_object_LockForEquipmentResource( strAdvanced_object_LockForEquipmentResource_out,
                                                            strObjCommonIn,
                                                            strAdvanced_object_LockForEquipmentResource_in );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "[Material Location Lock Process] advanced_object_LockForEquipmentResource() != RC_OK", rc);
                    strStartDurablesReservationForInternalBufferReqResult.strResult = strAdvanced_object_LockForEquipmentResource_out.strResult ;
                    return rc;
                }
            }
        }
        else
        {
            objectIdentifier loadPurposeType;
            for ( durableCnt = 0; durableCnt < durableLen; durableCnt++ )
            {
                loadPurposeType.identifier = strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPurposeType;

                objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                      strObjCommonIn,
                                                      strInParm.equipmentID,
                                                      loadPurposeType,
                                                      SP_ClassName_PosMaterialLocation );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "[Material Location Lock Process] advanced_object_LockForEquipmentResource() != RC_OK", rc);
                    strStartDurablesReservationForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                    return( rc );
                }
            }
        }
    }
    // For reticle pod
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "[Port Lock Process] durableCategory == SP_DurableCat_ReticlePod");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "[Port Lock Process] loop to strInParm.strStartDurables.length()", durableCnt);
            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  strInParm.equipmentID,
                                                  strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID,
                                                  SP_ClassName_PosReticlePodPortResource );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "[Port Lock Process] object_LockForEquipmentResource() != RC_OK", rc);
                strStartDurablesReservationForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
                return rc;
            }
        }
    }

    //-----------------------------------------------
    // Durable Object Lock Process
    //-----------------------------------------------
    objectIdentifierSequence durableIDs;
    durableIDs.length(durableLen);
    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
        durableIDs[durableCnt] = strInParm.strStartDurables[durableCnt].durableID;
    }

    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosCassette);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosReticlePod);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosReticlePod );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosProcessDurable);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosProcessDurable );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Durable OnRoute Check               */
    /*                                            */
    /*--------------------------------------------*/
    CORBA::Boolean bOnRouteFlag  = FALSE;
    CORBA::Boolean bOffRouteFlag = FALSE;
    for( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
        objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
        objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
        strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
        strDurable_OnRoute_Check_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
        rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);

        if( rc == RC_DURABLE_ONROUTE )
        {
            PPT_METHODTRACE_V1("","##### durable is on  route");
            bOnRouteFlag = TRUE;
        }
        else
        {
            PPT_METHODTRACE_V1("","##### durable is off route");
            bOffRouteFlag = TRUE;
        }
    }
    if( bOnRouteFlag && bOffRouteFlag )
    {
        PPT_METHODTRACE_V1("", "all durable OnRoute state is not same");
        SET_MSG_RC( strStartDurablesReservationForInternalBufferReqResult, MSG_DURABLE_ONROUTE_STAT_NOT_SAME, RC_DURABLE_ONROUTE_STAT_NOT_SAME );
        return( RC_DURABLE_ONROUTE_STAT_NOT_SAME );
    }

    if( bOnRouteFlag && 0 == CIMFWStrLen(strInParm.strDurableStartRecipe.logicalRecipeID.identifier) )
    {
        PPT_METHODTRACE_V1("", "logicalRecipeID is blank");
        SET_MSG_RC( strStartDurablesReservationForInternalBufferReqResult, MSG_DURABLE_CANNOT_OFFROUTE_RESERVE, RC_DURABLE_CANNOT_OFFROUTE_RESERVE );
        return( RC_DURABLE_CANNOT_OFFROUTE_RESERVE );
    }

    /*--------------------------------------------*/
    /*                                            */
    /*        Check Process for Durables          */
    /*                                            */
    /*--------------------------------------------*/
    csObjDurable_CheckConditionForOperationForInternalBuffer_in strDurable_CheckConditionForOperationForInternalBuffer_in;
    strDurable_CheckConditionForOperationForInternalBuffer_in.operation             = CIMFWStrDup( SP_Operation_StartReservation );
    strDurable_CheckConditionForOperationForInternalBuffer_in.equipmentID           = strInParm.equipmentID;
    strDurable_CheckConditionForOperationForInternalBuffer_in.durableCategory       = strInParm.durableCategory;
    strDurable_CheckConditionForOperationForInternalBuffer_in.strStartDurables      = strInParm.strStartDurables;
    strDurable_CheckConditionForOperationForInternalBuffer_in.strDurableStartRecipe = strInParm.strDurableStartRecipe;

    csObjDurable_CheckConditionForOperationForInternalBuffer_out strDurable_CheckConditionForOperationForInternalBuffer_out;
    rc = cs_durable_CheckConditionForOperationForInternalBuffer( strDurable_CheckConditionForOperationForInternalBuffer_out,
                                                                 strObjCommonIn,
                                                                 strDurable_CheckConditionForOperationForInternalBuffer_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_durable_CheckConditionForOperationForInternalBuffer() != RC_OK", rc);
        strStartDurablesReservationForInternalBufferReqResult.strResult = strDurable_CheckConditionForOperationForInternalBuffer_out.strResult;
        return rc;
    }

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
        objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
        objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
        strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup( SP_Operation_StartReservation );
        strDurable_status_CheckForOperation_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
        strDurable_status_CheckForOperation_in.durableCategory = strInParm.durableCategory;
        rc = durable_status_CheckForOperation( strDurable_status_CheckForOperation_out,
                                               strObjCommonIn,
                                               strDurable_status_CheckForOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_status_CheckForOperation() != RC_OK", rc);
            strStartDurablesReservationForInternalBufferReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
            return rc;
        }
    }

    /*---------------------------------------------------------------*/
    /*                                                               */
    /*        Check Equipment Port for Durable Operation             */
    /*                                                               */
    /*---------------------------------------------------------------*/
    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette)
      || 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette || SP_DurableCat_ReticlePod");

        csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in;
        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.operation        = CIMFWStrDup( SP_Operation_StartReservation );
        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.equipmentID      = strInParm.equipmentID;
        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.durableCategory  = strInParm.durableCategory;
        strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in.strStartDurables = strInParm.strStartDurables;

        csObjEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out;
        rc = cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer( strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out,
                                                                                   strObjCommonIn,
                                                                                   strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_equipment_and_portState_CheckForDurableOperationForInternalBuffer() != RC_OK", rc);
            strStartDurablesReservationForInternalBufferReqResult.strResult = strEquipment_and_portState_CheckForDurableOperationForInternalBuffer_out.strResult;
            return rc;
        }
    }

    /*--------------------------------------------------------------------------------*/
    /*                                                                                */
    /*        Confirmation for Uploaded Recipe Body and Eqp's Recipe Body             */
    /*                                                                                */
    /*--------------------------------------------------------------------------------*/
    objMachineRecipe_GetListForRecipeBodyManagementForDurable_out strMachineRecipe_GetListForRecipeBodyManagementForDurable_out;
    objMachineRecipe_GetListForRecipeBodyManagementForDurable_in  strMachineRecipe_GetListForRecipeBodyManagementForDurable_in;
    strMachineRecipe_GetListForRecipeBodyManagementForDurable_in.equipmentID            = strInParm.equipmentID;
    strMachineRecipe_GetListForRecipeBodyManagementForDurable_in.durableCategory        = strInParm.durableCategory;
    strMachineRecipe_GetListForRecipeBodyManagementForDurable_in.strStartDurables       = strInParm.strStartDurables;
    pptDurableStartRecipeSequence strDurableStartRecipes;
    strDurableStartRecipes.length(1);
    strDurableStartRecipes[0] = strInParm.strDurableStartRecipe;
    strMachineRecipe_GetListForRecipeBodyManagementForDurable_in.strDurableStartRecipes = strDurableStartRecipes;
    rc = machineRecipe_GetListForRecipeBodyManagementForDurable( strMachineRecipe_GetListForRecipeBodyManagementForDurable_out,
                                                                 strObjCommonIn,
                                                                 strMachineRecipe_GetListForRecipeBodyManagementForDurable_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "machineRecipe_GetListForRecipeBodyManagementForDurable() != RC_OK", rc);
        strStartDurablesReservationForInternalBufferReqResult.strResult = strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strResult;
        return rc;
    }

    CORBA::ULong targetRecipeLen = strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq.length();
    for ( CORBA::ULong targetRecipeCnt=0; targetRecipeCnt<targetRecipeLen; targetRecipeCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq.length()", targetRecipeCnt);
        PPT_METHODTRACE_V2("", " Machine Recipe ID          ",  strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
        PPT_METHODTRACE_V2("", " Force Down Load Flag       ", (strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].forceDownLoadFlag?"True":"False"));
        PPT_METHODTRACE_V2("", " Recipe Body Confirm Flag   ", (strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag?"True":"False"));
        PPT_METHODTRACE_V2("", " Conditional Down Load Flag ", (strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].conditionalDownLoadFlag?"True":"False"));

        //-------------------
        // Force Down Load
        //-------------------
        CORBA::Boolean downLoadFlag = FALSE;
        if ( TRUE == strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].forceDownLoadFlag )
        {
             PPT_METHODTRACE_V1("", "downLoadFlag turns to True.");
             downLoadFlag = TRUE;
        }
        else
        {
            PPT_METHODTRACE_V1("", "else.");
            if ( TRUE == strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag )
            {
                PPT_METHODTRACE_V1("", "recipeBodyConfirmFlag == TRUE");
                //---------------------
                // Recipe Confirmation
                //---------------------
                PPT_METHODTRACE_V1("", "Call txRecipeConfirmationReq");
                pptRecipeConfirmationReqResult strRecipeConfirmationReqResult;
                rc = txRecipeConfirmationReq( strRecipeConfirmationReqResult,
                                              strObjCommonIn,
                                              strInParm.equipmentID,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileLocation,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileName,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].formatFlag,
                                              "" );

                if ( rc != RC_OK && rc != RC_TCS_MM_TAP_PP_CONFIRM_ERROR)  // RC_TCS_MM_TAP_PP_CONFIRM_ERROR = 5914
                {
                    PPT_METHODTRACE_V2("", "txRecipeConfirmationReq() != RC_OK", rc);
                    strStartDurablesReservationForInternalBufferReqResult.strResult = strRecipeConfirmationReqResult.strResult;
                    return rc;
                }

                if ( rc == RC_TCS_MM_TAP_PP_CONFIRM_ERROR )
                {
                    PPT_METHODTRACE_V1("", "rc == RC_TCS_MM_TAP_PP_CONFIRM_ERROR");
                    if ( TRUE == strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].conditionalDownLoadFlag )
                    {
                        //--------------------------
                        // Conditional Down Load
                        //--------------------------
                        PPT_METHODTRACE_V1("", "downLoadFlag turns to True.");
                        downLoadFlag = TRUE;
                    }
                    else
                    {
                        //Recipe Body Confirmation error. the Recipe Body differs between Uploaded it to system and the owned it by equipment.
                        PPT_METHODTRACE_V2("", "Recipe Body Confirmation error. the Recipe Body differs between Uploaded it to system and the owned it by equipment.",
                                           strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
                        PPT_SET_MSG_RC_KEY( strStartDurablesReservationForInternalBufferReqResult,
                                            MSG_RECIPE_CONFIRM_ERROR,
                                            RC_RECIPE_CONFIRM_ERROR,
                                            strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier );
                        return RC_RECIPE_CONFIRM_ERROR;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","Recipe Body management .. no action.");
                // no action.
            }
        }

        PPT_METHODTRACE_V2("", "Recipe Down Load ??", (downLoadFlag?"True":"False"));
        if ( TRUE == downLoadFlag )
        {
            //---------------------
            // Recipe Down Load
            //---------------------
            PPT_METHODTRACE_V1("","Call txRecipeDownloadReq");
            pptRecipeDownloadReqResult strRecipeDownloadReqResult;
            rc = txRecipeDownloadReq( strRecipeDownloadReqResult,
                                      strObjCommonIn,
                                      strInParm.equipmentID,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileLocation,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileName,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].formatFlag,
                                      "" );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txRecipeDownloadReq() != RC_OK", rc);
                strStartDurablesReservationForInternalBufferReqResult.strResult = strRecipeDownloadReqResult.strResult;
                return rc;
            }
        }
    } //Loop of targetRecipeLen

    /*--------------------------------------------*/
    /*                                            */
    /*        Main process                        */
    /*                                            */
    /*--------------------------------------------*/
    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
            objDurable_CassetteCategory_CheckForContaminationControl_out strDurable_CassetteCategory_CheckForContaminationControl_out;
            objDurable_CassetteCategory_CheckForContaminationControl_in  strDurable_CassetteCategory_CheckForContaminationControl_in;
            strDurable_CassetteCategory_CheckForContaminationControl_in.cassetteID  = strInParm.strStartDurables[durableCnt].durableID;
            strDurable_CassetteCategory_CheckForContaminationControl_in.equipmentID = strInParm.equipmentID;
            strDurable_CassetteCategory_CheckForContaminationControl_in.portID      = strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID;
            rc = durable_CassetteCategory_CheckForContaminationControl( strDurable_CassetteCategory_CheckForContaminationControl_out,
                                                                        strObjCommonIn,
                                                                        strDurable_CassetteCategory_CheckForContaminationControl_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "durable_CassetteCategory_CheckForContaminationControl() != RC_OK", rc);
                strStartDurablesReservationForInternalBufferReqResult.strResult = strDurable_CassetteCategory_CheckForContaminationControl_out.strResult;
                return rc;
            }

            objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out,
                                                strObjCommonIn,
                                                strInParm.strStartDurables[durableCnt].durableID,
                                                TRUE );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_dispatchState_Change() != RC_OK", rc);
                strStartDurablesReservationForInternalBufferReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
                return rc;
            }
        }
    }

    // Create durable control job
    objectIdentifier dummyDurableControlJobID;
    dummyDurableControlJobID.identifier = CIMFWStrDup("");

    pptDurableControlJobCreateRequest strDurableControlJobCreateRequest;
    strDurableControlJobCreateRequest.equipmentID      = strInParm.equipmentID;
    strDurableControlJobCreateRequest.durableCategory  = strInParm.durableCategory;
    strDurableControlJobCreateRequest.strStartDurables = strInParm.strStartDurables;

    pptDurableControlJobManageReqInParam strDurableControlJobManageReqInParam;
    strDurableControlJobManageReqInParam.durableControlJobID               = dummyDurableControlJobID;
    strDurableControlJobManageReqInParam.controlJobAction                  = CIMFWStrDup( SP_DurableControlJobAction_Type_create );
    strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest = strDurableControlJobCreateRequest;

    pptDurableControlJobManageReqResult  strDurableControlJobManageReqResult;
    rc = txDurableControlJobManageReq( strDurableControlJobManageReqResult,
                                       strObjCommonIn,
                                       strDurableControlJobManageReqInParam,
                                       claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txDurableControlJobManageReq() != RC_OK", rc);
        strStartDurablesReservationForInternalBufferReqResult.strResult = strDurableControlJobManageReqResult.strResult;
        return rc;
    }

    objProcess_startDurablesReserveInformation_Set_out strProcess_startDurablesReserveInformation_Set_out;
    objProcess_startDurablesReserveInformation_Set_in  strProcess_startDurablesReserveInformation_Set_in;
    strProcess_startDurablesReserveInformation_Set_in.equipmentID           = strInParm.equipmentID;
    strProcess_startDurablesReserveInformation_Set_in.portGroupID           = CIMFWStrDup("");
    strProcess_startDurablesReserveInformation_Set_in.durableControlJobID   = strDurableControlJobManageReqResult.durableControlJobID;
    strProcess_startDurablesReserveInformation_Set_in.durableCategory       = strInParm.durableCategory;
    strProcess_startDurablesReserveInformation_Set_in.strStartDurables      = strInParm.strStartDurables;
    strProcess_startDurablesReserveInformation_Set_in.strDurableStartRecipe = strInParm.strDurableStartRecipe;
    rc = process_startDurablesReserveInformation_Set( strProcess_startDurablesReserveInformation_Set_out,
                                                      strObjCommonIn,
                                                      strProcess_startDurablesReserveInformation_Set_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "process_startDurablesReserveInformation_Set() != RC_OK", rc);
        strStartDurablesReservationForInternalBufferReqResult.strResult = strProcess_startDurablesReserveInformation_Set_out.strResult;
        return rc;
    }

    /*-----------------------------------------------------*/
    /*                                                     */
    /*        Send Start Durables Reservation to TCS       */
    /*                                                     */
    /*-----------------------------------------------------*/
    CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0;
    CORBA::Long retryCountValue = 0;

    if ( 0 == CIMFWStrLen(tmpSleepTimeValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = atoi(tmpSleepTimeValue);
    }

    if ( 0 == CIMFWStrLen(tmpRetryCountValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("", "env value of SP_BIND_SLEEP_TIME_TCS  = ", sleepTimeValue);
    PPT_METHODTRACE_V2("", "env value of SP_BIND_RETRY_COUNT_TCS = ", retryCountValue);

    objTCSMgr_SendStartDurablesReservationReq_out strTCSMgr_SendStartDurablesReservationReq_out;
    objTCSMgr_SendStartDurablesReservationReq_in  strTCSMgr_SendStartDurablesReservationReq_in;
    strTCSMgr_SendStartDurablesReservationReq_in.strStartDurablesReservationReqInParam.equipmentID           = strInParm.equipmentID;
    strTCSMgr_SendStartDurablesReservationReq_in.strStartDurablesReservationReqInParam.durableCategory       = strInParm.durableCategory;
    strTCSMgr_SendStartDurablesReservationReq_in.strStartDurablesReservationReqInParam.strStartDurables      = strInParm.strStartDurables;
    strTCSMgr_SendStartDurablesReservationReq_in.strStartDurablesReservationReqInParam.strDurableStartRecipe = strInParm.strDurableStartRecipe;
    strTCSMgr_SendStartDurablesReservationReq_in.claimMemo                                                   = claimMemo;

    //'retryCountValue + 1' means first try plus retry count
    for ( CORBA::ULong retryNum=0; retryNum < (retryCountValue + 1); retryNum++ )
    {
        PPT_METHODTRACE_V2("", "loop to retryCountValue + 1", retryNum);

        //--------------------------
        // Send Request to TCS
        //--------------------------
        rc = TCSMgr_SendStartDurablesReservationReq( strTCSMgr_SendStartDurablesReservationReq_out,
                                                     strObjCommonIn,
                                                     strTCSMgr_SendStartDurablesReservationReq_in );

        PPT_METHODTRACE_V2("", "rc = ", rc);

        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL
               || rc == RC_EXT_SERVER_NIL_OBJ
               || rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("", "TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...", retryNum);
            PPT_METHODTRACE_V2("", "now sleeping... ", sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendStartDurablesReservationReq() != RC_OK");
            strStartDurablesReservationForInternalBufferReqResult.strResult = strTCSMgr_SendStartDurablesReservationReq_out.strResult;
            return rc;
        }
    }

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "TCSMgr_SendStartDurablesReservationReq() != RC_OK");
        strStartDurablesReservationForInternalBufferReqResult.strResult = strTCSMgr_SendStartDurablesReservationReq_out.strResult;
        return rc;
    }

    // Set Return Structure
    strStartDurablesReservationForInternalBufferReqResult.durableControlJobID = strDurableControlJobManageReqResult.durableControlJobID;

    // Return to caller
    SET_MSG_RC( strStartDurablesReservationForInternalBufferReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txStartDurablesReservationForInternalBufferReq");
    return RC_OK;
}
