#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txStockerInventoryReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/18/08 17:27:57 [ 7/18/08 17:27:58 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txStockerInventoryReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txStockerInventoryReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/17          S.Kawabe       Initial Release (R30)
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize 
// 2001/03/16 P3100131 Y.Iwasaki      Bug fix for = operator usage
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2008/07/15 P9000368 K.Kido         1.Check FOSB  2.Object lock for equipment port 3.Object lock for cassette
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/11/29 DSN000049350 S.Liu          Equipment parallel processing support (P2)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptStockerInventoryReqResult& strStockerInventoryReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& machineID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txStockerInventoryReq (pptStockerInventoryReqResult& strStockerInventoryReqResult,
                                                 const pptObjCommonIn& strObjCommonIn,
                                                 const objectIdentifier& machineID,
//D6000025                                                  const char * claimMemo,
//D6000025                                                  CORBA::Environment &IT_env)
                                                 const char * claimMemo //D6000025
                                                 CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txStockerInventoryReq ") ;
    CORBA::Long rc = RC_OK ;
    CORBA::Long rcPositionUpdate = RC_OK ;    //P9000368

    /*-----------------------------------*/
    /*   Request for Automated Stocker   */
    /*-----------------------------------*/
    if(CIMFWStrLen(machineID.identifier) > 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq", 
                           "CIMFWStrLen(machineID.identifier) > 0 && CIMFWStrLen(machineID.stringifiedObjectReference) > 0") ;

        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, machineID, SP_ClassName_PosStorageMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq", "object_Lock() != RC_OK") ;
            strStockerInventoryReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }

        /*------------------------*/
        /*   Check Stocker Type   */
        /*------------------------*/
        objStocker_type_Get_out strStocker_type_Get_out;
        rc = stocker_type_Get(strStocker_type_Get_out, strObjCommonIn, machineID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq", "stocker_type_Get() != RC_OK") ;
            strStockerInventoryReqResult.strResult = strStocker_type_Get_out.strResult;
            return( rc );
        }
        if (CIMFWStrCmp(strStocker_type_Get_out.stockerType,SP_Stocker_Type_Auto) !=0 &&
            CIMFWStrCmp(strStocker_type_Get_out.stockerType,SP_Stocker_Type_Interm) !=0)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq",
                               "CIMFWStrCmp(strStocker_type_Get_out.stockerType,SP_Stocker_Type_*)") ;
            PPT_SET_MSG_RC_KEY(strStockerInventoryReqResult,
                               MSG_NOT_AUTO_STOCKER,
                               RC_NOT_AUTO_STOCKER,
                               machineID.identifier) ;
            return( RC_NOT_AUTO_STOCKER );
        }

        /*----------------------------*/
        /*   Check Inventory Status   */
        /*----------------------------*/
        objStocker_inventoryState_Get_out strStocker_inventoryState_Get_out;
        strStocker_inventoryState_Get_out.inventoryRequestedFlag = FALSE; //P3000280
        rc = stocker_inventoryState_Get(strStocker_inventoryState_Get_out, strObjCommonIn, machineID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq", "stocker_inventoryState_Get() != RC_OK") ;
            strStockerInventoryReqResult.strResult = strStocker_inventoryState_Get_out.strResult;
            return( rc );
        }
        if( strStocker_inventoryState_Get_out.inventoryRequestedFlag == TRUE )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq",
                               "strStocker_inventoryState_Get_out.inventoryRequestedFlag == TRUE") ;
            PPT_SET_MSG_RC_KEY(strStockerInventoryReqResult,
                               MSG_STOCKER_INVENTORY_IN_PROCESS,
                               RC_STOCKER_INVENTORY_IN_PROCESS,
                               machineID.identifier) ;
            return( RC_STOCKER_INVENTORY_IN_PROCESS );
        }

        /*-----------------------------------*/
        /*   Send Inventory Request to XMS   */
        /*-----------------------------------*/
        pptUploadInventoryReq   uploadInventoryReq;
        uploadInventoryReq.machineID = machineID;
//      uploadInventoryReq.uploadLevel = "";
        uploadInventoryReq.uploadLevel = CIMFWStrDup("");  //P3100131

        objXMSMgr_SendUploadInventoryReq_out   strXMSMgr_SendUploadInventoryReq_out;
        rc = XMSMgr_SendUploadInventoryReq( strXMSMgr_SendUploadInventoryReq_out,
                                            strObjCommonIn,
                                            strObjCommonIn.strUser,
                                            uploadInventoryReq);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq", "XMSMgr_SendUploadInventoryReq() != RC_OK") ;
            strStockerInventoryReqResult.strResult = strXMSMgr_SendUploadInventoryReq_out.strResult;
            return( rc );
        }

        /*---------------------------------*/
        /*   Update Cassette's position    */
        /*   by returned data of           */
        /*   XMSMgr_SendUploadInventoryReq */
        /*---------------------------------*/
        CORBA::Long nLen = strXMSMgr_SendUploadInventoryReq_out.strUploadInventoryReqResult.uploadInventoryResultData.length();
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txStockerInventoryReq",
                           "strXMSMgr_SendUploadInventoryReq_out.strUploadInventoryReqResult.uploadInventoryResultData.length()", nLen) ;

        pptInventoryLotInfoSequence strInventoryLotInfo;
        strInventoryLotInfo.length(nLen);

        for (CORBA::Long i=0; i<nLen; i++)
        {
            strInventoryLotInfo[i].cassetteID =
                strXMSMgr_SendUploadInventoryReq_out.strUploadInventoryReqResult.uploadInventoryResultData[i].carrierID;
        }

//P9000368 add start
        //------------------------------------------------------
        //   1. Omit FOSB from input parameter.
        //   2. Lock equipment object of 'EI' cassette.
        //------------------------------------------------------
        CORBA::Boolean NotFoundfoupFlg = FALSE;

        PPT_METHODTRACE_V2("","strInventoryLotInfo.length() =", nLen) ;

        pptInventoryLotInfoSequence carrierInfoSeq, FOSBInfoSeq;
        carrierInfoSeq.length(nLen);
        FOSBInfoSeq.length(nLen);
        CORBA::ULong fpCnt = 0, fbCnt = 0 , eqpCnt = 0;

        objectIdentifierSequence equipmentSeq;
        equipmentSeq.length(nLen);

        objectIdentifierSequence carrierLoadEqpIDSeq; //DSN000049350
        carrierLoadEqpIDSeq.length(nLen);             //DSN000049350

        for ( i = 0 ; i < nLen ; i++ )
        {
            /*-----------------------------------------------------------*/
            /*  Check carrier existence and get location information     */
            /*-----------------------------------------------------------*/
            objCassette_LocationInfo_GetDR_out strCassette_LocationInfo_GetDR_out;
            rc = cassette_LocationInfo_GetDR( strCassette_LocationInfo_GetDR_out,
                                              strObjCommonIn,
                                              strInventoryLotInfo[i].cassetteID );

            if( rc == RC_NOT_FOUND_CASSETTE )
            {
                PPT_METHODTRACE_V2("", "Reported carrier is not registered in MM    ID = ", strInventoryLotInfo[i].cassetteID.identifier);
                FOSBInfoSeq[fbCnt] = strInventoryLotInfo[i] ;
                fbCnt++;
                NotFoundfoupFlg = TRUE;
                continue;
            }
            else if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_LocationInfo_GetDR() != RC_OK") ;
                strStockerInventoryReqResult.strResult = strCassette_LocationInfo_GetDR_out.strResult ;
                return ( rc );
            }

            PPT_METHODTRACE_V2("", "Reported carrier ID is registered in MM    ID = ", strInventoryLotInfo[i].cassetteID.identifier);
            carrierInfoSeq[fpCnt] = strInventoryLotInfo[i] ;
            carrierLoadEqpIDSeq[fpCnt].identifier = CIMFWStrDup(""); //DSN000049350
            fpCnt++;

            /*---------------------------------------------------------------*/
            /*  If carrier location is 'EI', get equipmentID for object lock */
            /*---------------------------------------------------------------*/
            // INN-R170003 if( 0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentIn) ) 
            //INN-R170003 add start
            if( 0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentIn) ||
                0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentOut)||
                0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, CS_TRANS_STATE_PORT_IN)
              )
            //INN-R170003 add end
            {
                /*---------------------------------------------------------------*/
                /*  Check control job existence. If exist, no need to list up    */
                /*---------------------------------------------------------------*/
                 PPT_METHODTRACE_V2("", "strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus = ",strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus);//INN-R170003
                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                                strObjCommonIn,
                                                strInventoryLotInfo[i].cassetteID );

                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() != RC_OK") ;
                    strStockerInventoryReqResult.strResult = strCassette_controlJobID_Get_out.strResult ;
                    return ( rc );
                }

                if( 0 != CIMFWStrLen( strCassette_controlJobID_Get_out.controlJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "cassette has controljob ...");
                    continue;
                }
                
                // set load equipment ID
                carrierLoadEqpIDSeq[fpCnt-1] = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID; //DSN000049350

                /*-----------------------------------------------------*/
                /*  Check whether equipment already collected or not   */
                /*-----------------------------------------------------*/
                CORBA::Boolean alreadyCollectedFlag = FALSE ;
                CORBA::ULong collectedEqpLen = equipmentSeq.length();
                for( CORBA::ULong j = 0 ; j < collectedEqpLen ; j++ )
                {
                    if( 0 == CIMFWStrCmp( equipmentSeq[j].identifier, strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID.identifier) )
                    {
                        alreadyCollectedFlag = TRUE;
                        break;
                    }
                }

                if( FALSE == alreadyCollectedFlag )
                {
                    equipmentSeq[eqpCnt] = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
                    eqpCnt++;
                }
            }
        }
        carrierInfoSeq.length(fpCnt);
        FOSBInfoSeq.length(fbCnt);
        equipmentSeq.length(eqpCnt);
        carrierLoadEqpIDSeq.length(fpCnt);            //DSN000049350
        PPT_METHODTRACE_V2( "", "eqpCnt", eqpCnt);    //DSN000049350
        PPT_METHODTRACE_V2( "", "fpCnt", fpCnt);      //DSN000049350

        /*------------------*/
        /*  Screen log out  */
        /*------------------*/
        CORBA::ULong logCnt = 0 ;
        for( logCnt = 0 ; logCnt < fpCnt ; logCnt++ )
        {
            PPT_METHODTRACE_V2("","## carrierID = ", carrierInfoSeq[logCnt].cassetteID.identifier);
        }
        for( logCnt = 0 ; logCnt < fbCnt ; logCnt++ )
        {
            PPT_METHODTRACE_V2("","## FOSB ID   = ", FOSBInfoSeq[logCnt].cassetteID.identifier);
        }
        for( logCnt = 0 ; logCnt < eqpCnt ; logCnt++ )
        {
            PPT_METHODTRACE_V2("","## equipmentID = ", equipmentSeq[logCnt].identifier);
        }

        /*---------------------------------------------------------------*/
        /*  Set reason text if FOSB is included in reported carrieres    */
        /*---------------------------------------------------------------*/
        CORBA::String_var reasonText;
        if( 0 != fbCnt )
        {
            ostrstream errorMsg;
            errorMsg << "[Information : FOSB reported : Following reported carriers are FOSB. Its location was not changed.] =>" ;

            for( CORBA::ULong i = 0 ; i < fbCnt ; i++ )
            {
                errorMsg << (const char*)FOSBInfoSeq[i].cassetteID.identifier ;
                if( i < (fbCnt-1) )
                {
                    errorMsg << ", " ;
                }
            }

            errorMsg << ends;

            reasonText = CIMFWStrDup(errorMsg.str());
            errorMsg.rdbuf()->freeze(0);
            PPT_METHODTRACE_V2("","## reasonText = ", reasonText); 
        }

        /*------------------------------------------------------*/
        /*   Lock equipment/FOUP object for check (and update)  */
        /*------------------------------------------------------*/
        CORBA::ULong lockCnt = 0 ;
        for( lockCnt = 0 ; lockCnt < eqpCnt ; lockCnt++ )
        {
//DSN000049350 Add Start
            objObject_lockMode_Get_out strObject_lockMode_Get_out;
            objObject_lockMode_Get_in  strObject_lockMode_Get_in;
            strObject_lockMode_Get_in.objectID           = equipmentSeq[lockCnt];
            strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
            strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXLGC007" ); // TxStockerInventoryReq
            strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

            PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentSeq[lockCnt].identifier );
            rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                      strObjCommonIn,
                                      strObject_lockMode_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
                strStockerInventoryReqResult.strResult = strObject_lockMode_Get_out.strResult;
                return( rc );
            }

            objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
            objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
            
            CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
            PPT_METHODTRACE_V2( "", "lockMode", lockMode );
            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

                // Advanced Mode
                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = equipmentSeq[lockCnt];
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
                rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                           strObjCommonIn,
                                           strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strStockerInventoryReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
                
                stringSequence loadCastSeq;
                loadCastSeq.length(fpCnt);
                CORBA::ULong loadCastCnt = 0;
                for ( CORBA::ULong castCnt = 0 ; castCnt < fpCnt ; castCnt++ )
                {
                    if ( 0 == CIMFWStrCmp( equipmentSeq[lockCnt].identifier, carrierLoadEqpIDSeq[castCnt].identifier) )
                    {
                        loadCastSeq[loadCastCnt] = carrierInfoSeq[castCnt].cassetteID.identifier;
                        loadCastCnt++;
                    }
                }
                loadCastSeq.length(loadCastCnt);
                PPT_METHODTRACE_V2( "", "loadCastCnt", loadCastCnt);
                
                // Lock Equipment LoadCassette Element (Write)
                if ( 0 < loadCastSeq.length() )
                {
                    strAdvanced_object_Lock_in.objectID   = equipmentSeq[lockCnt];
                    strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                    strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                    strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                    strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                    PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
                    rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                               strObjCommonIn,
                                               strAdvanced_object_Lock_in );
                    if ( rc != RC_OK && rc != RC_NOT_FOUND_SOME_OBJECT)
                    {
                        PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                        strStockerInventoryReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                        return( rc );
                    }
                }                
            }
            else
            {
                PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
                rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                                  equipmentSeq[lockCnt], SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "object_Lock(equipmentID) != RC_OK" );
                    strStockerInventoryReqResult.strResult = strObject_Lock_out.strResult;
                    return( rc );
                }
            } //DSN000049350
        }

        for( lockCnt = 0 ; lockCnt < fpCnt ; lockCnt++ )
        {
            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                              carrierInfoSeq[lockCnt].cassetteID, SP_ClassName_PosCassette );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "object_Lock(cassetteID) != RC_OK" );
                strStockerInventoryReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        }
//P9000368 add end

        objCassette_position_UpdateByStockerInventory_out strCassette_position_UpdateByStockerInventory_out;
        rc = cassette_position_UpdateByStockerInventory(strCassette_position_UpdateByStockerInventory_out,
                                                        strObjCommonIn,
                                                        machineID,
//P9000368                                              strInventoryLotInfo);
                                                        carrierInfoSeq);    //P9000368
        switch( rc )
        {
           case RC_OK:
              SET_MSG_RC(strStockerInventoryReqResult, MSG_OK, RC_OK) ;    //P9000368
              rcPositionUpdate = rc ;    //P9000368
              break;
           case RC_SOMECASTINV_DATA_ERROR:
              strStockerInventoryReqResult.strResult = strCassette_position_UpdateByStockerInventory_out.strResult;    //P9000368
              rcPositionUpdate = rc ;    //P9000368
              break;
           default:
              PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq", "cassette_position_UpdateByStockerInventory() != RC_OK") ;
              strStockerInventoryReqResult.strResult = strCassette_position_UpdateByStockerInventory_out.strResult;
              return( rc );
              break;
        }

//P9000368 add start
        /*-----------------------*/
        /*   Set reason text     */
        /*-----------------------*/
        if( 0 != CIMFWStrLen(reasonText) )
        {
            ostrstream errorMsg;
            errorMsg << reasonText << strStockerInventoryReqResult.strResult.reasonText << ends;

            strStockerInventoryReqResult.strResult.reasonText = CIMFWStrDup(errorMsg.str());
            errorMsg.rdbuf()->freeze(0);
            PPT_METHODTRACE_V2("","## final reasonText = ", strStockerInventoryReqResult.strResult.reasonText); 
        }
//P9000368 add end

        /*-----------------------------*/
        /*   Change Inventory Status   */
        /*-----------------------------*/
        objStocker_inventoryState_Change_out strStocker_inventoryState_Change_out;
        rc = stocker_inventoryState_Change(strStocker_inventoryState_Change_out, strObjCommonIn, machineID, FALSE);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq", "stocker_inventoryState_Change() != RC_OK") ;
            strStockerInventoryReqResult.strResult = strStocker_inventoryState_Change_out.strResult;
            return( rc );
        }
    }
    else
    {
        /*---------------------------*/
        /*   Input Parameter Error   */
        /*---------------------------*/
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryReq",
                           "CIMFWStrLen(machineID.identifier) < 0 || CIMFWStrLen(machineID.stringifiedObjectReference) < 0") ;
        SET_MSG_RC(strStockerInventoryReqResult,MSG_INVALID_INPUT_PARM,RC_INVALID_INPUT_PARM) ;
        return( RC_INVALID_INPUT_PARM );
    }

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    strStockerInventoryReqResult.stockerID = machineID ;
//P9000368    SET_MSG_RC(strStockerInventoryReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txStockerInventoryReq ");
//P9000368    return( RC_OK );
    rc = rcPositionUpdate ;    //P9000368
    return rc;                 //P9000368
}
