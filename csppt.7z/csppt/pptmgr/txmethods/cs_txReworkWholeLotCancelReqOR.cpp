#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txReworkWholeLotCancelReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 17:35:36 [ 8/3/07 17:35:37 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: cs_txReworkWholeLotCancelReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"
extern char* makeInhibitListFromEntityInhibits(const PosEntityInhibitSequence* entityInhibits);

// Class: CS_PPTManager
//
// Service: txReworkWholeLotCancelReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000/08/09            S.Kawabe       Initial Release (R30)
// 2000/09/26 Q3000147   M.Mori         Add Check Lot's Control Job ID
// 2001/01-12 D3000118   M.Shimizu      Lot Customization and Flexible Rework
// 2001/01-12 D3000119   M.Shimizu      Lot Customization and Flexible Rework
// 2001/03/15 P3100043   M.Shimizu      extendedOperationNumber for LC-subRoute
// 2001/03/15 P3100095   M.Shimizu      bug fix
// 2001/04/10 P3100256   K.Matsuei      BranchCancel should not be allowed for Rework Lot.
// 2001/04/13 P3100279   K.Muguruma     LC:bug fix and code refinement :pending  (Original src is copied at 11-APR)
// 2001/07/12 D4000016   M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2002/01/15 D4100069   C.Tsuchiya     Drop LCFR logic
// 2002/01/21 D4100020   N.Maeda        Change oldCurrentPOS to oldCurrentPOData
// 2002/02/12 D4100083   T.Michii       Enhancement Future Hold
// 2002/02/28 D4100120   N.Minami       Future Action
// 2002/03/25 D4100210   H.Adachi       Add InParameter CurrentRouteID & CurrentOperationNum For Check Condition
// 2002/07/29 D4200029   K.Kimura       Process Hold Control
// 2003/09/09 P5000145   H.Adachi       Fix Message and Message Macro mismatch.
// 2004/10/22 D6000025   K.Murakami     eBroker Migration.
// 2005/09/22 D7000012   M.Kase         Change order of process_reworkCount_Decrement() and process_CancelBranchRoute()
//                                      (Change wafer level control for rework count)
// 2006/04/25 D7000213   Y.Kadowaki     Add a check for transfer state of cassette.
// 2006/05/18 D7000092   Y.Kadowaki     Add object lock for cassette.
// 2007/08/03 D9000056   H.Hotta        PostProcess performance improvement.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/30 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/07/28 DSN000085792 Sa Guo         Q-Time Improvements.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txReworkWholeLotCancelReq
// 2017/09/12 INN-R170002  Thomas Song    Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//      pptReworkWholeLotCancelReqResult& strReworkWholeLotCancelReqResult
//      const pptObjCommonIn& strObjCommonIn
//      const objectIdentifier& lotID
//      const objectIdentifier& reasonCodeID
//      const char * claimMemo
//      CORBA::Environment &IT_env
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//      TXTRC027

CORBA::Long CS_PPTManager_i::txReworkWholeLotCancelReq (pptReworkWholeLotCancelReqResult& strReworkWholeLotCancelReqResult,
                                                     const pptObjCommonIn& strObjCommonIn,
                                                     const objectIdentifier& lotID,
                                                     const objectIdentifier& currentRouteID,       //D4100210
                                                     const char * currentOperationNumber,          //D4100210
                                                     const objectIdentifier& reasonCodeID,
//D6000025                                                      const char * claimMemo,
//D6000025                                                      CORBA::Environment &IT_env)
                                                     const char * claimMemo //D6000025
                                                     CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txReworkWholeLotCancelReq ") ;
    CORBA::Long rc = RC_OK ;

    objectIdentifier aLotID( lotID ) ;
    objectIdentifier aCassetteID ;

    /*------------------------------------------------------------------------*/
    /*   Get cassette / lot connection                                        */
    /*------------------------------------------------------------------------*/
    objLot_cassette_Get_out strLot_cassette_Get_out ;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strLot_cassette_Get_out.strResult ;
        return(rc);
    }
    aCassetteID = strLot_cassette_Get_out.cassetteID ;

//D7000092 add start
    /*--------------------------------*/
    /*   Object Lock for cassette     */
    /*--------------------------------*/
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aCassetteID, SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strReworkWholeLotCancelReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }
//D7000092 add end

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
    if ( 1 == lotOperationEIcheck )
    {
//DSN000071674 add end
//D7000213 add start
        //-----------------------------------
        // TransferState should not be EI. 
        //-----------------------------------
        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get(strCassette_transferState_Get_out,strObjCommonIn,aCassetteID);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_transferState_Get rc != RC_OK", rc)
            strReworkWholeLotCancelReqResult.strResult = strCassette_transferState_Get_out.strResult;
            return(rc);
        }
        else if( CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
        {
            PPT_METHODTRACE_V1("", "TransferState of cassette is EI")
            PPT_SET_MSG_RC_KEY2( strReworkWholeLotCancelReqResult,
                                 MSG_INVALID_CAST_XFERSTAT,
                                 RC_INVALID_CAST_XFERSTAT,
                                 SP_TransState_EquipmentIn,
                                 aCassetteID.identifier );
            return( RC_INVALID_CAST_XFERSTAT );
        }
//D7000213 add end.
    } //DSN000071674

    /*--------------------------------*/
    /*   Lock objects to be updated   */
    /*--------------------------------*/
//D7000092    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aLotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock() rc != RC_OK" ) ;
        strReworkWholeLotCancelReqResult.strResult = strObject_Lock_out.strResult ;
        return( rc );
    }

    //D4100210 add start
    //--------------------------------------------------------------------------
    //   Check whether Lot is on the specified Route/Operation or Not
    //--------------------------------------------------------------------------
    PPT_METHODTRACE_V1("","Check whether Lot is on the specified Route/Operation or Not...");

    objectIdentifier  tmpCurrentRouteID         = currentRouteID;
    CORBA::String_var tmpCurrentOperationNumber = CIMFWStrDup(currentOperationNumber);

    if ((CIMFWStrLen(tmpCurrentRouteID.identifier) != 0)&&
        (CIMFWStrLen(tmpCurrentOperationNumber) != 0))
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Not Null. Begin to Check!!");

        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_currentOperationInfo_Get() != RC_OK");
            strReworkWholeLotCancelReqResult.strResult  = strLot_currentOperationInfo_Get_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2("","In-parm's routeID            :", tmpCurrentRouteID.identifier );
        PPT_METHODTRACE_V2("","In-Parm's operationNumber    :", tmpCurrentOperationNumber    );

        PPT_METHODTRACE_V2("","Lot's currentRouteID         :", strLot_currentOperationInfo_Get_out.routeID.identifier );
        PPT_METHODTRACE_V2("","Lot's currentOperationNumber :", strLot_currentOperationInfo_Get_out.operationNumber    );

        if ( CIMFWStrCmp(tmpCurrentRouteID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier) == 0 &&
             CIMFWStrCmp(tmpCurrentOperationNumber   , strLot_currentOperationInfo_Get_out.operationNumber   ) == 0 )
        {
            PPT_METHODTRACE_V1("","Route/Operation check OK. Go ahead...");
        }
        else
        {
            PPT_METHODTRACE_V1("","Route/Operation check NG.");
            PPT_SET_MSG_RC_KEY2(strReworkWholeLotCancelReqResult,
                                MSG_NOT_SAME_ROUTE,
                                RC_NOT_SAME_ROUTE,
                                "Input parameter's currentRouteID/currentOperationNumber",
                                "lot's current currentRouteID/currentOperationNumber");
            return( RC_NOT_SAME_ROUTE );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Null. No Check!!");
    }
    //D4100210 add end
    /*------------------------------------------------------------------------*/
    /*   Check Condition                                                      */
    /*------------------------------------------------------------------------*/
    objLot_holdState_Get_out strLot_holdState_Get_out ;
    rc = lot_holdState_Get(strLot_holdState_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_holdState_Get() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strLot_holdState_Get_out.strResult ;
        return(rc);
    }
    else if( (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_OnHold)) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_OnHold)) == 0" ) ;
        PPT_SET_MSG_RC_KEY2(strReworkWholeLotCancelReqResult,
                            MSG_INVALID_LOT_HOLDSTAT,
                            RC_INVALID_LOT_HOLDSTAT,
                            aLotID.identifier,
                            strLot_holdState_Get_out.lotHoldState) ;
        return(RC_INVALID_LOT_HOLDSTAT);
    }

//D9000056 delete start
//D9000056    rc = lot_holdState_Get(strLot_holdState_Get_out,strObjCommonIn,aLotID);
//D9000056    if (rc != RC_OK)
//D9000056    {
//D9000056        PPT_METHODTRACE_V1("", "lot_holdState_Get() != RC_OK") ;
//D9000056        strReworkWholeLotCancelReqResult.strResult = strLot_holdState_Get_out.strResult ;
//D9000056        return(rc);
//D9000056    }
//D9000056    else if( (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_OnHold)) == 0 )
//D9000056    {
//D9000056        PPT_METHODTRACE_V1("", "(CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_OnHold)) == 0") ;
//D9000056        PPT_SET_MSG_RC_KEY2(strReworkWholeLotCancelReqResult,
//D9000056                            MSG_INVALID_LOT_HOLDSTAT,
//D9000056                            RC_INVALID_LOT_HOLDSTAT,
//D9000056                            aLotID.identifier,
//D9000056                            strLot_holdState_Get_out.lotHoldState) ;
//D9000056
//D9000056        return(RC_INVALID_LOT_HOLDSTAT);
//D9000056    }
//D9000056 delete end

    objLot_state_Get_out strLot_state_Get_out ;
    rc = lot_state_Get(strLot_state_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_state_Get() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strLot_state_Get_out.strResult ;
        return(rc);
    }
    else if( (CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active)) != 0 )
    {
        PPT_METHODTRACE_V1("", "(CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active)) != 0") ;
        PPT_SET_MSG_RC_KEY(strReworkWholeLotCancelReqResult,
                           MSG_INVALID_LOT_STAT,
                           RC_INVALID_LOT_STAT,
                           strLot_state_Get_out.lotState) ;
        return(RC_INVALID_LOT_STAT);
    }

    objLot_processState_Get_out strLot_processState_Get_out ;
    rc = lot_processState_Get(strLot_processState_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_processState_Get() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strLot_processState_Get_out.strResult ;
        return(rc);
    }
    else if( (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Processing)) == 0 )
    {
        PPT_METHODTRACE_V1("", "(CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Processing)) == 0") ;
        PPT_SET_MSG_RC_KEY2(strReworkWholeLotCancelReqResult,
                            MSG_INVALID_LOT_PROCSTAT,
                            RC_INVALID_LOT_PROCSTAT,
                            aLotID.identifier,
                            strLot_processState_Get_out.theLotProcessState) ;

        return(RC_INVALID_LOT_PROCSTAT);
    }

    objLot_productionState_Get_out strLot_productionState_Get_out ;
    rc = lot_productionState_Get(strLot_productionState_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_productionState_Get() != RC_OK");
        strReworkWholeLotCancelReqResult.strResult = strLot_productionState_Get_out.strResult ;
        return(rc);
    }
//P3100256 start
    else if( 0 != CIMFWStrCmp(strLot_productionState_Get_out.lotProductionState, CIMFW_Lot_ProductionState_InRework) )
    {
        PPT_METHODTRACE_V1("", "lotProductionState != CIMFW_Lot_ProductionState_InRework");
        PPT_SET_MSG_RC_KEY2(strReworkWholeLotCancelReqResult,
                            MSG_INVALID_LOT_PRODSTAT,
                            RC_INVALID_LOT_PRODSTAT,
                            aLotID.identifier,
                            strLot_productionState_Get_out.lotProductionState );
        return(RC_INVALID_LOT_PRODSTAT);
    }
//P3100256 end

//P3100256    else if( (CIMFWStrCmp(strLot_productionState_Get_out.lotProductionState,CIMFW_Lot_ProductionState_InProduction)) == 0 )
//P3100256    {
//P3100256        PPT_METHODTRACE_V1("", "(CIMFWStrCmp(strLot_productionState_Get_out.lotProductionState,CIMFW_Lot_ProductionState_InProduction)) == 0") ;
//P3100256        PPT_SET_MSG_RC_KEY2(strReworkWholeLotCancelReqResult,
//P3100256                            MSG_INVALID_LOT_PRODSTAT,
//P3100256                            RC_INVALID_LOT_PRODSTAT,
//P3100256                            aLotID.identifier,
//P3100256                            strLot_productionState_Get_out.lotProductionState ) ;
//P3100256        return(RC_INVALID_LOT_PRODSTAT);
//P3100256    }

    objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
    rc = lot_inventoryState_Get(strLot_inventoryState_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_inventoryState_Get() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
        return(rc);
    }
    else if( (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor)) != 0 )
    {
        PPT_METHODTRACE_V1("", "(CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor)) != 0") ;
        PPT_SET_MSG_RC_KEY2(strReworkWholeLotCancelReqResult,
                            MSG_INVALID_LOT_INVENTORYSTAT,
                            RC_INVALID_LOT_INVENTORYSTAT,
                            aLotID.identifier,
                            strLot_inventoryState_Get_out.lotInventoryState) ;

        return(RC_INVALID_LOT_INVENTORYSTAT);
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = aLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strReworkWholeLotCancelReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strReworkWholeLotCancelReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strReworkWholeLotCancelReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                aLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

//DSIV00000214 add start
    //---------------------------------------
    //   Check interFabXferPlan existence
    //---------------------------------------
    objInterFab_xferPlanList_GetDR_out strInterFab_xferPlanList_GetDR_out;
    objInterFab_xferPlanList_GetDR_in strInterFab_xferPlanList_GetDR_in;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.lotID = aLotID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.seqNo = 0;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalFabID = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalRouteID = currentRouteID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalOpeNumber = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationFabID = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationRouteID.identifier = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationOpeNumber = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.xferType = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.description = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.modifierUserID.identifier = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.modifiedTime = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.state = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.stateUpdateTime = CIMFWStrDup("");
    
    rc = interFab_xferPlanList_GetDR( strInterFab_xferPlanList_GetDR_out,
                                      strObjCommonIn,
                                      strInterFab_xferPlanList_GetDR_in );
    if( rc != RC_OK && rc != RC_INTERFAB_NOT_FOUND_XFERPLAN )
    {
        PPT_METHODTRACE_V1("", "interFab_xferPlanList_GetDR() != RC_OK");
        strReworkWholeLotCancelReqResult.strResult = strInterFab_xferPlanList_GetDR_out.strResult;
        return( rc );
    }

    CORBA::Long xferLen = strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length();
    for( CORBA::Long xCnt = 0; xCnt < xferLen; xCnt++ )
    {
        if( 0 != CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[xCnt].state,
                             SP_InterFab_XferPlanState_Completed) )
        {
            PPT_METHODTRACE_V1("", "strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length != 0");
            SET_MSG_RC( strReworkWholeLotCancelReqResult,
                        MSG_INTERFAB_BRANCH_CANCEL_ERROR,
                        RC_INTERFAB_BRANCH_CANCEL_ERROR );
            return( RC_INTERFAB_BRANCH_CANCEL_ERROR );
        }
    }
//DSIV00000214 add end

//Q3000147 add start
    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strReworkWholeLotCancelReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strReworkWholeLotCancelReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             lotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }
//Q3000147 add end

//D4100069//P3100279 add start
//D4100069    /*--------------------------------------------------*/
//D4100069    /*   Check Logic for Route Kind                     */
//D4100069    /*   Not applicable to  Lot-Customized Branch Route */
//D4100069    /*--------------------------------------------------*/
//D4100069    CORBA::String_var   oldCurrentRouteKind ;                                                                        //P3100279
//D4100069    objLot_CheckForLCFR_out strLot_CheckForLCFR_out;                                                                 //P3100279
//D4100069    rc = lot_CheckForLCFR( strLot_CheckForLCFR_out, strObjCommonIn, aLotID,SP_LotCustomize_DBRECORD );               //P3100279
//D4100069    if ( rc == RC_OK)                                                                                                //P3100279
//D4100069    {                                                                                                                //P3100279
//D4100069        objLot_currentLCFRInfo_Get_out  strLot_currentLCFRInfo_Get_out;                                              //P3100279
//D4100069        rc = lot_currentLCFRInfo_Get( strLot_currentLCFRInfo_Get_out, strObjCommonIn, aLotID );                      //P3100279
//D4100069        if ( rc == RC_OK )                                                                                           //P3100279
//D4100069        {                                                                                                            //P3100279
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txReworkWholeCancelReq", "lot_currentLCFRInfo_Get() == RC_OK");       //P3100279
//D4100069            oldCurrentRouteKind = strLot_currentLCFRInfo_Get_out.routeKind;                                          //P3100279
//D4100069        }                                                                                                            //P3100279
//D4100069        else                                                                                                         //P3100279
//D4100069        {                                                                                                            //P3100279
//D4100069            PPT_METHODTRACE_V2("CS_PPTManager_i:: txReworkWholeCancelReq", "lot_currentLCFRInfo_Get() != RC_OK", rc);   //P3100279
//D4100069            strReworkWholeLotCancelReqResult.strResult = strLot_currentLCFRInfo_Get_out.strResult;                   //P3100279
//D4100069            return( rc );                                                                                            //P3100279
//D4100069        }                                                                                                            //P3100279
//D4100069        if ( CIMFWStrCmp( strLot_currentLCFRInfo_Get_out.routeKind, SP_RouteKind_LCSUB ) == 0 )                      //P3100279
//D4100069        {                                                                                                            //P3100279
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txReworkWholeCancelReq", "strLot_currentLCFRInfo_Get_out.routeKind == SP_RouteKind_LCSUB");   //P3100279
//D4100069            PPT_SET_MSG_RC_KEY( strReworkWholeLotCancelReqResult,                                                    //P3100279
//D4100069                                MSG_INVALID_OPE_TO_LCSUBROUTE,                                                       //P3100279
//D4100069                                RC_INVALID_OPE_TO_LCSUBROUTE,                                                        //P3100279
//D4100069                                aLotID.identifier) ;                                                                 //P3100279
//D4100069            return( RC_INVALID_OPE_TO_LCSUBROUTE );                                                                  //P3100279
//D4100069        }                                                                                                            //P3100279
//D4100069    }                                                                                                                //P3100279
//D4100069
//D4100069//P3100279 add end

    objProcess_CheckBranchCancel_out strProcess_CheckBranchCancel_out ;
    rc = process_CheckBranchCancel( strProcess_CheckBranchCancel_out , strObjCommonIn , aLotID ) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_CheckBranchCancel() != RC_OK");
        strReworkWholeLotCancelReqResult.strResult = strProcess_CheckBranchCancel_out.strResult ;
        return (rc) ;
    }

    objLot_futureHoldRequests_CheckBranchCancel_out strLot_futureHoldRequests_CheckBranchCancel_out ;
    rc = lot_futureHoldRequests_CheckBranchCancel(strLot_futureHoldRequests_CheckBranchCancel_out, strObjCommonIn, aLotID ) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_CheckBranchCancel() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strLot_futureHoldRequests_CheckBranchCancel_out.strResult ;
        return(rc);
    }

//D4100120 Add Start
    /*-----------------------------------*/
    /*   Check Future Action Procedure   */
    /*-----------------------------------*/
    objSchdlChangeReservation_CheckForBranchCancel_out strSchdlChangeReservation_CheckForBranchCancel_out;
    rc = schdlChangeReservation_CheckForBranchCancelDR(strSchdlChangeReservation_CheckForBranchCancel_out,
                                                       strObjCommonIn,
                                                       aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForBranchCancelDR() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strSchdlChangeReservation_CheckForBranchCancel_out.strResult;
        return(rc);
    }
//D4100120 Add End

//DSN000085792 Add Start
    /*-----------------------------------------------------------*/
    /* Roll back Target Operation for rework route               */
    /*-----------------------------------------------------------*/
    objQTime_targetOpe_cancelReplace_out strQTime_targetOpe_cancelReplace_out;
    objQTime_targetOpe_cancelReplace_in  strQTime_targetOpe_cancelReplace_in;
    strQTime_targetOpe_cancelReplace_in.lotID = aLotID;
    rc = qTime_targetOpe_cancelReplace( strQTime_targetOpe_cancelReplace_out,
                                        strObjCommonIn,
                                        strQTime_targetOpe_cancelReplace_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "qTime_targetOpe_cancelReplace() != RC_OK", rc);
        strReworkWholeLotCancelReqResult.strResult = strQTime_targetOpe_cancelReplace_out.strResult;
        return rc;
    }
//DSN000085792 Add End

    /*------------------------------------------------------------------------*/
    /*   Change State                                                         */
    /*------------------------------------------------------------------------*/
//D7000012 move from the lower part start
    objProcess_reworkCount_Decrement_out strProcess_reworkCount_Decrement_out ;
    rc = process_reworkCount_Decrement(strProcess_reworkCount_Decrement_out, strObjCommonIn,  aLotID ) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_reworkCount_Decrement() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strProcess_reworkCount_Decrement_out.strResult ;
        return(rc);
    }
//D7000012 move from the lower part end

    objProcess_CancelBranchRoute_out strProcess_CancelBranchRoute_out ;
    rc = process_CancelBranchRoute(strProcess_CancelBranchRoute_out,strObjCommonIn,aLotID) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_CancelBranchRoute() != RC_OK");
        strReworkWholeLotCancelReqResult.strResult = strProcess_CancelBranchRoute_out.strResult ;
        return (rc) ;
    }

//D4100069//(D3000118,D3000119) add start
//D4100069//P3100279    objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069    rc = lot_CheckForLCFR(  strLot_CheckForLCFR_out,strObjCommonIn,lotID,SP_LotCustomize_FR_DBRECORD);
//D4100069    if ( rc != RC_OK )
//D4100069    {
//D4100069        PPT_METHODTRACE_V1("", "lot_CheckForLCFR() != RC_OK") ;
//D4100069        objProcess_reworkCount_Decrement_out strProcess_reworkCount_Decrement_out;
//D4100069        rc = process_reworkCount_Decrement( strProcess_reworkCount_Decrement_out,strObjCommonIn,lotID);
//D4100069        if ( rc )
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("", "process_reworkCount_Decrement() == RC_OK") ;
//D4100069            strReworkWholeLotCancelReqResult.strResult = strProcess_reworkCount_Decrement_out.strResult ;
//D4100069            return( rc );
//D4100069        }
//D4100069    }
//D4100069    else
//D4100069    {
//D4100069        PPT_METHODTRACE_V1("", "lot_CheckForLCFR() == RC_OK") ;
//D4100069//P3100279 add start
//D4100069        if ( CIMFWStrCmp( oldCurrentRouteKind, SP_RouteKind_FRSUB ) == 0 )                                           //P3100279
//D4100069        {                                                                                                            //P3100279
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txReworkWholeLotCancelReq", "oldCurrentRouteKind == SP_RouteKind_FRSUB") ;
//D4100069//P3100279 add end
//D4100069
//D4100069            objProcess_CancelBranchRouteForLCFR_out strProcess_CancelBranchRouteForLCFR_out;
//D4100069            rc = process_CancelBranchRouteForLCFR(  strProcess_CancelBranchRouteForLCFR_out,strObjCommonIn,lotID);
//P3100095
//P3100095        if ( rc == RC_OK )
//P3100095        {
//P3100095            PPT_METHODTRACE_V1("", "process_CancelBranchRouteForLCFR() == RC_OK") ;
//P3100095            strReworkWholeLotCancelReqResult.strResult = strProcess_CancelBranchRouteForLCFR_out.strResult ;
//P3100095            return( rc );
//P3100095        }
//P3100095

//D4100069//P3100095  add start
//D4100069            switch( rc )
//D4100069            {
//D4100069                case RC_OK :
//D4100069                    PPT_METHODTRACE_V1("", "process_CancelBranchRouteForLCFR() == RC_OK") ;
//D4100069                    break;
//D4100069                case RC_NOT_FOUND_PFX      :
//D4100069                case RC_NOT_FOUND_ROUTE    :
//D4100069                case RC_NOT_FOUND_POS      :
//D4100069                case RC_NOT_FOUND_SUBROUTE :
//D4100069                case RC_NOT_FOUND_PO       :
//D4100069                case RC_OPENO_DELETED      :
//D4100069                case RC_ROUTEID_DELETED    :
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2("", "rc == (RC_NOT_FOUND_PFX,RC_NOT_FOUND_ROUTE,RC_NOT_FOUND_POS,RC_NOT_FOUND_SUBROUTE,RC_NOT_FOUND_PO ",rc) ;
//D4100069
//D4100069
//D4100069                    /*-------------------*/
//D4100069                    /* get main route id */
//D4100069                    /*-------------------*/
//D4100069                    objLot_mainRouteID_Get_out strLot_mainRouteID_Get_out;
//D4100069                    rc = lot_mainRouteID_Get(strLot_mainRouteID_Get_out, strObjCommonIn, lotID);
//D4100069                    if (rc != RC_OK)
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V2("", "lot_mainRouteID_Get() != RC_OK", rc);
//D4100069                        strReworkWholeLotCancelReqResult.strResult = strLot_mainRouteID_Get_out.strResult;
//D4100069                        return(rc);
//D4100069                    }
//D4100069
//D4100069                    objectIdentifier routeID = strLot_mainRouteID_Get_out.mainRouteID;
//D4100069
//D4100069                    /* ------------------------------------------------ */
//D4100069                    /* Locate to "0.0" operatioin.                      */
//D4100069                    /* ------------------------------------------------ */
//D4100069                    objProcess_LocateForLCFR_out    strProcess_LocateForLCFR_out;
//D4100069                    rc = process_LocateForLCFR( strProcess_LocateForLCFR_out,
//D4100069                                                strObjCommonIn,
//D4100069                                                lotID,
//D4100069                                                routeID,
//D4100069                                                SP_LotCustomize_Dummy_OperationNumber );
//D4100069                    if ( rc != RC_OK )
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V2("", "process_LocateForLCFR() != RC_OK : ", rc) ;
//D4100069                        strReworkWholeLotCancelReqResult.strResult = strProcess_LocateForLCFR_out.strResult ;
//D4100069                        return( rc );
//D4100069                    }
//D4100069
//D4100069                    /*------------------------------------------------------------------------------------*/
//D4100069                    /* parameter set                                                                      */
//D4100069                    /*------------------------------------------------------------------------------------*/
//D4100069                    objectIdentifier aReasonCodeID ;
//D4100069                    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_LCFR_Hold ) ;
//D4100069
//D4100069                    pptHoldListSequence strLotHoldReqList ;
//D4100069
//D4100069                    strLotHoldReqList.length( 1 ) ;
//D4100069                    strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LCFR_Route_Deleted ) ;
//D4100069                    strLotHoldReqList[0].holdReasonCodeID         = aReasonCodeID;
//D4100069                    strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
//D4100069                    strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
//D4100069                    strLotHoldReqList[0].routeID                  = routeID;
//D4100069                    strLotHoldReqList[0].operationNumber          = CIMFWStrDup( SP_LotCustomize_Dummy_OperationNumber );
//D4100069                    strLotHoldReqList[0].relatedLotID             = lotID;
//D4100069                    strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "");
//D4100069
//D4100069                    PPT_METHODTRACE_V2("", "holType          ", strLotHoldReqList[0].holdType) ;
//D4100069                    PPT_METHODTRACE_V2("", "holdReasonCodeID ", strLotHoldReqList[0].holdReasonCodeID.identifier) ;
//D4100069                    PPT_METHODTRACE_V2("", "operationNumber  ", strLotHoldReqList[0].operationNumber  ) ;
//D4100069
//D4100069                    /*------------------------------------------------------------------------------------*/
//D4100069                    /* parameter set                                                                      */
//D4100069                    /*------------------------------------------------------------------------------------*/
//D4100069                    pptHoldLotReqResult strHoldLotReqResult ;
//D4100069                    rc = txHoldLotReq(strHoldLotReqResult, strObjCommonIn, lotID, strLotHoldReqList) ;
//D4100069                    if (rc != RC_OK)
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V2("", "txHoldLotReq() != RC_OK", rc) ;
//D4100069                        strReworkWholeLotCancelReqResult.strResult = strHoldLotReqResult.strResult ;
//D4100069                        return( rc );
//D4100069                    }
//D4100069
//D4100069                    break;
//D4100069                }
//D4100069                default :
//D4100069                    PPT_METHODTRACE_V2("", "process_CancelBranchRouteForLCFR() == default ",rc) ;
//D4100069                    strReworkWholeLotCancelReqResult.strResult = strProcess_CancelBranchRouteForLCFR_out.strResult;
//D4100069                    return( rc );
//D4100069            }
//D4100069
//D4100069//P3100095  add end
//D4100069
//D4100069//P3100279 add start
//D4100069        }                                                                                                            //P3100279
//D4100069        else                                                                                                         //P3100279
//D4100069        {                                                                                                            //P3100279
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txReworkWholeLotCancelReq", "oldCurrentRouteKind != SP_RouteKind_FRSUB") ;
//D4100069            objProcess_reworkCount_Decrement_out strProcess_reworkCount_Decrement_out;                               //P3100279
//D4100069            rc = process_reworkCount_Decrement(strProcess_reworkCount_Decrement_out, strObjCommonIn, aLotID);         //P3100279
//D4100069            if (rc)                                                                                                  //P3100279
//D4100069            {                                                                                                        //P3100279
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txReworkWholeLotCancelReq ", "process_reworkCount_Decrement() rc != RC_OK", rc); //P3100279
//D4100069                strReworkWholeLotCancelReqResult.strResult = strProcess_reworkCount_Decrement_out.strResult;         //P3100279
//D4100069                return( rc );                                                                                        //P3100279
//D4100069            }                                                                                                        //P3100279
//D4100069        }                                                                                                            //P3100279
//D4100069//P3100279 add end
//D4100069
//D4100069    }
//D4100069//(D3000118,D3000119) add end

//(D3000118,D3000119) delete start
//    objProcess_reworkCount_Decrement_out strProcess_reworkCount_Decrement_out ;
//    rc = process_reworkCount_Decrement(strProcess_reworkCount_Decrement_out, strObjCommonIn,  aLotID ) ;
//    if(rc != RC_OK)
//    {
//        PPT_METHODTRACE_V1("", "process_reworkCount_Decrement() != RC_OK") ;
//        strReworkWholeLotCancelReqResult.strResult = strProcess_reworkCount_Decrement_out.strResult ;
//        return(rc);
//    }
//(D3000118,D3000119) delete end
//D4100069 restore start
//D7000012  move to the upper part start
//D7000012    objProcess_reworkCount_Decrement_out strProcess_reworkCount_Decrement_out ;
//D7000012    rc = process_reworkCount_Decrement(strProcess_reworkCount_Decrement_out, strObjCommonIn,  aLotID ) ;
//D7000012    if(rc != RC_OK)
//D7000012    {
//D7000012        PPT_METHODTRACE_V1("", "process_reworkCount_Decrement() != RC_OK") ;
//D7000012        strReworkWholeLotCancelReqResult.strResult = strProcess_reworkCount_Decrement_out.strResult ;
//D7000012        return(rc);
//D7000012    }
//D7000012  move to the upper part end
//D4100069 restore end


//D4100069//P3100043  add start
//D4100069    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;
//D4100069    {
//D4100069        objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069        rc = lot_CheckForLCFR(  strLot_CheckForLCFR_out,strObjCommonIn,aLotID,SP_LotCustomize_DBRECORD );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("", "lot_CheckForLCFR() != RC_OK", rc);
//D4100069            rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, aLotID) ;
//D4100069            if(rc != RC_OK)
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("", "lot_futureHoldRequests_Effect() != RC_OK") ;
//D4100069                strReworkWholeLotCancelReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//D4100069                return(rc);
//D4100069            }
//D4100069
//D4100069        }
//D4100069        else
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069            objLot_futureHoldRequests_EffectForLCFR_out  strLot_futureHoldRequests_EffectForLCFR_out;
//D4100069            rc = lot_futureHoldRequests_EffectForLCFR( strLot_futureHoldRequests_EffectForLCFR_out, strObjCommonIn, aLotID );
//D4100069            if ( rc == RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectForLCFR() == RC_OK");
//D4100069                strLot_futureHoldRequests_Effect_out.strLotHoldReqList = strLot_futureHoldRequests_EffectForLCFR_out.strLotHoldReqList;
//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("", "lot_futureHoldRequests_EffectForLCFR() != RC_OK", rc);
//D4100069                strReworkWholeLotCancelReqResult.strResult = strLot_futureHoldRequests_EffectForLCFR_out.strResult;
//D4100069                return( rc );
//D4100069            }
//D4100069        }
//D4100069
//D4100069    }
//D4100069//P3100043  add end

//P3100043    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;
//P3100043    rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, aLotID) ;
//P3100043    if(rc != RC_OK)
//P3100043    {
//P3100043        PPT_METHODTRACE_V1("", "objLot_futureHoldRequests_Effect_out() != RC_OK") ;
//P3100043        strReworkWholeLotCancelReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//P3100043        return(rc);
//P3100043    }

//D4100069 retore start
//D4100083    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;
//D4100083    rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, aLotID) ;
//D4100083    if(rc != RC_OK)
//D4100083    {
//D4100083        PPT_METHODTRACE_V1("", "objLot_futureHoldRequests_Effect_out() != RC_OK") ;
//D4100083        strReworkWholeLotCancelReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//D4100083        return(rc);
//D4100083    }
//D4100069 restore end
//D4100083 Add Start
    pptEffectCondition strEffectCondition;
    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

    objLot_futureHoldRequests_EffectByCondition_out strLot_futureHoldRequests_EffectByCondition_out;
    rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_out,
                                                   strObjCommonIn,
                                                   aLotID,
                                                   strEffectCondition);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_out.strResult ;
        return( rc );
    }

    if( strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0 )
    {
        PPT_METHODTRACE_V1("", "strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0") ;
//D4100083 Add End
//D4100083    if ( strLot_futureHoldRequests_Effect_out.strLotHoldReqList.length() > 0 )
//D4100083    {
        pptHoldLotReqResult strHoldLotReqResult ;
        rc = txHoldLotReq (strHoldLotReqResult, strObjCommonIn, aLotID, strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList) ;  //D4100083
//D4100083        rc = txHoldLotReq (strHoldLotReqResult, strObjCommonIn, aLotID, strLot_futureHoldRequests_Effect_out.strLotHoldReqList) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strReworkWholeLotCancelReqResult.strResult = strHoldLotReqResult.strResult ;
            return(rc);
        }
    }

//D4100083 Add Start
    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_SINGLE );

    objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;
    rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                           strObjCommonIn,
                                                           aLotID,
                                                           strEffectCondition );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
        return( rc );
    }

    if( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )
    {
        PPT_METHODTRACE_V1("", "strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0") ;

        objectIdentifier releaseReasonCodeID ;
        pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
        rc = txFutureHoldCancelReq(strFutureHoldCancelReqResult,
                                   strObjCommonIn,
                                   aLotID,
                                   releaseReasonCodeID,
                                   SP_EntryType_Remove,
                                   strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK") ;
            strReworkWholeLotCancelReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
            return(rc);
        }
    }
//D4100083 Add End

    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, aCassetteID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
        strReworkWholeLotCancelReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
        return(rc);
    }

#if 1
//D4000016 Add Start
    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             aLotID );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strReworkWholeLotCancelReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }
//D4000016 Add end
#endif

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = aLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = aCassetteID;
    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strReworkWholeLotCancelReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        pptHoldLotReqResult strHoldLotReqResult;
        pptHoldListSequence strLotHoldReqList( 1 );
        strLotHoldReqList.length( 1 );

        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = claimMemo;

        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           aLotID,
                           strLotHoldReqList );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strReworkWholeLotCancelReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End

//D4200029 Add Start
    //-----------------------//
    //     Process Hold      //
    //-----------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                               strObjCommonIn,
                               lotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
        strReworkWholeLotCancelReqResult.strResult = strProcessHoldExecReqResult.strResult ;
        return( rc );
    }
//D4200029 Add End

    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/
    objLotReworkEvent_Make_out  strLotReworkEvent_Make_out;
    rc = lotReworkEvent_Make(strLotReworkEvent_Make_out,
                            strObjCommonIn,
                            "TXTRC027",
                            aLotID,
                            reasonCodeID,
//                          strProcess_CancelBranchRoute_out.oldCurrentPOS,                              //D4100020 Delete
                            strProcess_CancelBranchRoute_out.oldCurrentPOData,                           //D4100020 Add
                            claimMemo) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lotReworkEvent_Make() != RC_OK") ;
//P5000145        PPT_SET_MSG_RC_KEY(strReworkWholeLotCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc, aLotID.identifier) ;
        SET_MSG_RC( strReworkWholeLotCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strReworkWholeLotCancelReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txReworkWholeLotCancelReq") ;
    return (RC_OK);
}
