//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txReticleWaferCountResetReq.cpp
//

#include "cs_pptmgr.hpp"
#include "pptmgr.hpp"
//
//
// Subsystem Name      : CS_PPT Service Manager
//
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/09/04 INN-R170003 Helios Zhen    Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     csReticleWaferCountResetReqResult& strReticleWaferCountResetReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& reticleID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txReticleWaferCountResetReq(
    csReticleWaferCountResetReqResult&  strReticleWaferCountResetReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             reticleID,
    const char*                         claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txReticleWaferCountResetReq")
    CORBA::Long rc = RC_OK ;


    //------------------------------
    // Object Lock for Reticle
    //------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, reticleID, SP_ClassName_PosReticle);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strReticleWaferCountResetReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }

    /*------------------------------------------------*/
    /*   Reset reticle wafer count information        */
    /*------------------------------------------------*/
    csObjReticle_WaferCount_Reset_out strReticle_WaferCount_Reset_out;
    rc = cs_reticle_WaferCount_Reset(strReticle_WaferCount_Reset_out,strObjCommonIn,reticleID,claimMemo);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_reticle_WaferCount_Reset() rc != RC_OK", rc);
        strReticleWaferCountResetReqResult.strResult = strReticle_WaferCount_Reset_out.strResult ;
        return( rc );
    }

    /*---------------------------------------------*/
    /*   Create Durable Change Event               */
    /*---------------------------------------------*/
    objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
    rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                 strObjCommonIn,
                                 "TXPDC007",
                                 reticleID,
                                 SP_DurableCat_Reticle,
                                 CS_DURABLE_EVENT_ACTION_WAFER_COUNT_RESET,
                                 claimMemo) ;

    if( rc )
    {
        PPT_METHODTRACE_V2("", "durableChangeEvent_Make() rc != RC_OK",rc)
        strReticleWaferCountResetReqResult.strResult = strDurableChangeEvent_Make_out.strResult ;
        SET_MSG_RC( strReticleWaferCountResetReqResult, MSG_FAIL_MAKE_HISTORY, rc );
        return rc ;
    }

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    strReticleWaferCountResetReqResult.reticleID = reticleID ;

    SET_MSG_RC(strReticleWaferCountResetReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txReticleWaferCountResetReq")
    return( RC_OK );
}