//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txDurableBankInByPostProcReq.cpp
//
#include "cs_pptmgr.hpp"

            
            // Class: PPTManager
//
// Service:  txDurableBankInByPostProcReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2015/08/07 DSN000096126 C.Mo           Durable Process Flow Control
//
//Innotron Modification history
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/18 INN-R170003  Joan Zhou      Change Durable SubState when Carrier
// Description:
//    This function moves the specified Durable to the Bank logically.
//
// Return:
//     long
//
// Parameter:
//     pptDurableBankInByPostProcReqResult&               strDurableBankInByPostProcReqResult,
//     const pptObjCommonIn&                              strObjCommonIn,
//     const pptDurableBankInByPostProcReqInParam&        strDurableBankInByPostProcReqInParam,
//     const char *                                       claimMemo 
//
//     typedef struct pptDurableBankInByPostProcReqInParam_struct {
//         string                          durableCategory;             //<i>Durable Category
//         objectIdentifier                durableID;                   //<i>Durable ID
//         any siInfo;                                                  //<i>Reserved for SI customization
//     } pptDurableBankInByPostProcReqInParam;
//
//     typedef struct pptDurableBankInByPostProcReqResult_struct {
//         pptRetCode                      strResult;                   //<i>Transaction Execution Result Information
//         boolean                         autoBankInFlag;              //<i>Auto BankIn Flag
//         any siInfo;                                                  //<i>Reserved for SI customization
//     } pptDurableBankInByPostProcReqResult;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long  CS_PPTManager_i::txDurableBankInByPostProcReq(
    pptDurableBankInByPostProcReqResult&               strDurableBankInByPostProcReqResult,
    const pptObjCommonIn&                              strObjCommonIn,
    const pptDurableBankInByPostProcReqInParam&        strDurableBankInByPostProcReqInParam,
    const char *                                       claimMemo 
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txDurableBankInByPostProcReq");
    CORBA::Long rc = RC_OK;

    //----------------------------------------------------------------
    //  In-Parameter Trace
    //----------------------------------------------------------------
    const pptDurableBankInByPostProcReqInParam& strInParm = strDurableBankInByPostProcReqInParam;
    PPT_METHODTRACE_V2("", "in-parm durableCategory ", strInParm.durableCategory);
    PPT_METHODTRACE_V2("", "in-parm durableID       ", strInParm.durableID.identifier);

    //---------------------------------------
    // Check Durable Category 
    //---------------------------------------
    if( 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", strInParm.durableCategory);
        PPT_SET_MSG_RC_KEY( strDurableBankInByPostProcReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            strInParm.durableCategory );
        return RC_INVALID_DURABLE_CATEGORY;
    }

    //--------------------------------------------------
    // Trace and check input parameter
    //--------------------------------------------------
    if(CIMFWStrLen(strInParm.durableID.identifier) > 0)
    {
        PPT_METHODTRACE_V2("", "The input parameter durableID : ", strInParm.durableID.identifier);
    }
    else
    {
        PPT_METHODTRACE_V1("", "The input parameter is not specified.");
        SET_MSG_RC(strDurableBankInByPostProcReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
        return RC_INVALID_INPUT_PARM;
    }
 
    /*---------------------------------------------------------------*/
    /*   Auto-Bank-In Procedure                                      */
    /*---------------------------------------------------------------*/
    strDurableBankInByPostProcReqResult.autoBankInFlag = FALSE;

    //---------------------------------------
    // Check Durable Hold State 
    //---------------------------------------
    objDurable_holdState_Get_out strDurable_holdState_Get_out;
    objDurable_holdState_Get_in  strDurable_holdState_Get_in;
    strDurable_holdState_Get_in.durableCategory = strInParm.durableCategory;
    strDurable_holdState_Get_in.durableID       = strInParm.durableID;
    rc = durable_holdState_Get(strDurable_holdState_Get_out, strObjCommonIn, strDurable_holdState_Get_in);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durable_holdState_Get() != RC_OK", rc);
        strDurableBankInByPostProcReqResult.strResult = strDurable_holdState_Get_out.strResult;
        return( rc );
    }
    else if ( CIMFWStrCmp(strDurable_holdState_Get_out.durableHoldState, SP_Durable_HoldState_OnHold) != 0 )
    {
        PPT_METHODTRACE_V1("", "durableHoldState != SP_Durable_HoldState_OnHold");

        // Check Condition 
        objDurable_CheckConditionForAutoBankIn_out  strDurable_CheckConditionForAutoBankIn_out;
        objDurable_CheckConditionForAutoBankIn_in   strDurable_CheckConditionForAutoBankIn_in;
        strDurable_CheckConditionForAutoBankIn_in.durableCategory = strInParm.durableCategory;
        strDurable_CheckConditionForAutoBankIn_in.durableID       = strInParm.durableID;
 
        rc = durable_CheckConditionForAutoBankIn(strDurable_CheckConditionForAutoBankIn_out,
                                                 strObjCommonIn,
                                                 strDurable_CheckConditionForAutoBankIn_in);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "durable_CheckConditionForAutoBankIn() != RC_OK", rc);
            strDurableBankInByPostProcReqResult.strResult = strDurable_CheckConditionForAutoBankIn_out.strResult;
            return(rc);
        }
        strDurableBankInByPostProcReqResult.autoBankInFlag = strDurable_CheckConditionForAutoBankIn_out.autoBankInFlag;

        if(strDurableBankInByPostProcReqResult.autoBankInFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", "autoBankInFlag == TRUE");
//INN - R170003 Start
            if (CIMFWStrCmp(strInParm.durableCategory , SP_DurableCat_Cassette) == 0)
            {
                //----------------------------------------------------------------
                //  Get RouteID of Durable
                //----------------------------------------------------------------
                objDurable_routeID_Get_out strDurable_routeID_Get_out;
                objDurable_routeID_Get_in  strDurable_routeID_Get_in;
                strDurable_routeID_Get_in.durableCategory = strInParm.durableCategory;
                strDurable_routeID_Get_in.durableID = strInParm.durableID;
                rc = durable_routeID_Get(strDurable_routeID_Get_out, strObjCommonIn, strDurable_routeID_Get_in);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "##### durable_routeID_Get() != RC_OK", rc);
                    strDurableBankInByPostProcReqResult.strResult = strDurable_routeID_Get_out.strResult;
                    return(rc);
                }
                PPT_METHODTRACE_V2("", "strDurable_routeID_Get_out.routeID", strDurable_routeID_Get_out.routeID.identifier);
                

            
                if (CIMFWStrCmp(strInParm.durableCategory, CS_SP_DURABLE_FLOW_TYPE_FOUP_INSPECTION)== 0)
                {
                    //call cs_txCassettePMTimeResetReq()
                    csCassettePMTimeResetReqResult strCassettePMTimeResetReqResult;
                    rc = cs_txCassettePMTimeResetReq(strCassettePMTimeResetReqResult, strObjCommonIn, strInParm.durableID, claimMemo);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cs_txCassettePMTimeResetReq() != RC_OK", rc);
                        strDurableBankInByPostProcReqResult.strResult = strCassettePMTimeResetReqResult.strResult;
                        return( rc );
                    }

                }
                else if (CIMFWStrCmp(strInParm.durableCategory, CS_SP_DURABLE_FLOW_TYPE_FOUP_CLEAN)== 0 )

                {   csCassetteInspectionTimeResetReqResult strCassetteInspectionTimeResetReqResult;
                    rc = cs_txCassetteInspectionTimeResetReq(strCassetteInspectionTimeResetReqResult, strObjCommonIn, strInParm.durableID, claimMemo);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cs_txCassettePMTimeResetReq() != RC_OK", rc);
                        strDurableBankInByPostProcReqResult.strResult = strCassetteInspectionTimeResetReqResult.strResult;
                        return( rc );
                    }
                }
            }
//INN - R170003 End
            /*---------------------------------------------*/
            /*  Call txDurableBankInReq() for Auto-Bank-In */
            /*---------------------------------------------*/
            pptDurableBankInReqResult strDurableBankInReqResult;
            strDurableBankInReqResult.strBankInDurableResults.length(1);
            pptDurableBankInReqInParam strDurableBankInReqInParam;
            strDurableBankInReqInParam.durableCategory = strInParm.durableCategory;            
            strDurableBankInReqInParam.durableIDs.length(1);
            strDurableBankInReqInParam.durableIDs[0] = strInParm.durableID;
            strDurableBankInReqInParam.bankID.identifier = CIMFWStrDup("");

            rc = txDurableBankInReq(strDurableBankInReqResult, strObjCommonIn, 0, strDurableBankInReqInParam, claimMemo);
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "txDurableBankInReq() != RC_OK" ,rc);
                strDurableBankInByPostProcReqResult.strResult = strDurableBankInReqResult.strResult;
                return rc;
            }
        }
    }

    //---------------------------------------
    // Return
    //---------------------------------------
    SET_MSG_RC(strDurableBankInByPostProcReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("PPTManager_i::txDurableBankInByPostProcReq");
    return RC_OK;
}
