//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txDurableStatusMultiChangeReqOR.cpp
//

//INN-R170003 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"    //INN-R170003

// Class: CS_PPTManager
//
// Service: txDurableStatusMultiChangeReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2016/07/25 DSN000101569 C.Mo           Durable Sub Status Control Support.
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/11/02 INN-R170003  Nick Tsai      Support Fixture
//
// Description:
//    This function changesStatus and Sub Status of multiple Durables to the same status.
// Return:
//    long
//
// Parameter:
//    pptDurableStatusMultiChangeReqResult&        strDurableStatusMultiChangeReqResult,
//    const pptObjCommonIn&                        strObjCommonIn,
//    const  pptDurableStatusMultiChangeReqInParm& strDurableStatusMultiChangeReqInParm,
//    const char *                                 claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//INN-R170003 CORBA::Long PPTManager_i::txDurableStatusMultiChangeReq (
CORBA::Long CS_PPTManager_i::txDurableStatusMultiChangeReq (   //INN-R170003
    pptDurableStatusMultiChangeReqResult&        strDurableStatusMultiChangeReqResult,
    const pptObjCommonIn&                        strObjCommonIn,
    const  pptDurableStatusMultiChangeReqInParm& strDurableStatusMultiChangeReqInParm,
    const char *                                 claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txDurableStatusMultiChangeReq");
    CORBA::Long rc = RC_OK;

    //----------------------------------------------------------------
    //  In-Parameter Trace
    //----------------------------------------------------------------
    const pptDurableStatusMultiChangeReqInParm& strInParm = strDurableStatusMultiChangeReqInParm;
    PPT_METHODTRACE_V2("", "in-parm durableCategory  ", strInParm.durableCategory);
    PPT_METHODTRACE_V2("", "in-parm durableStatus    ", strInParm.durableStatus);
    PPT_METHODTRACE_V2("", "in-parm durableSubStatus ", strInParm.durableSubStatus.identifier);

    //---------------------------------------
    // Check Durable Category
    //---------------------------------------
    if ( 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette)
      && 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod)
      && 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Fixture)    //INN-R170003
      && 0 != CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", strInParm.durableCategory);
        PPT_SET_MSG_RC_KEY( strDurableStatusMultiChangeReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            strInParm.durableCategory );
        return RC_INVALID_DURABLE_CATEGORY;
    }

    //-----------------------------------------------------------------------//
    //   Decide TX_ID                                                        //
    //-----------------------------------------------------------------------//
    CORBA::String_var txID;
    if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette))
    {
        txID = CIMFWStrDup("TXPDC064");
    }
    else if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle))
    {
        txID = CIMFWStrDup("TXPDC065");
    }
    else if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod))
    {
        txID = CIMFWStrDup("TXPDC066");
    }
    //INN-R170003 add start
    else if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Fixture))
    {
        txID = CIMFWStrDup("CSPDC011");
    }
    //INN-R170003 add end
    PPT_METHODTRACE_V2("", "txID  ", txID);

    //---------------------------------------
    // ObjectSequence Lock
    //---------------------------------------
    CORBA::ULong durableLen = 0;
    CORBA::ULong durableCnt = 0;
    objectIdentifierSequence durableIDs;

    durableLen = strInParm.strCurrentDurableStatusInfoSeq.length();
    durableIDs.length(durableLen);

    for (durableCnt=0; durableCnt < durableLen; durableCnt++)
    {
        durableIDs[durableCnt] = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID;
    }

    objObjectSequence_Lock_out strObjectSequence_Lock_out;
    if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette))
    {
        PPT_METHODTRACE_V2("", "calling object_Lock()", SP_ClassName_PosCassette);
        rc = objectSequence_Lock(strObjectSequence_Lock_out, strObjCommonIn, durableIDs, SP_ClassName_PosCassette);
    }
    else if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod))
    {
        PPT_METHODTRACE_V2("", "calling object_Lock()", SP_DurableCat_ReticlePod);
        rc = objectSequence_Lock(strObjectSequence_Lock_out, strObjCommonIn, durableIDs, SP_ClassName_PosReticlePod );
    }
    else if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle))
    {
        PPT_METHODTRACE_V2("", "calling object_Lock()", SP_DurableCat_Reticle);
        rc = objectSequence_Lock(strObjectSequence_Lock_out, strObjCommonIn, durableIDs, SP_ClassName_PosProcessDurable);
    }
    //INN-R170003 add start
    else if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Fixture))
    {
        PPT_METHODTRACE_V2("", "calling object_Lock()", SP_DurableCat_Fixture);
        rc = objectSequence_Lock(strObjectSequence_Lock_out, strObjCommonIn, durableIDs, SP_ClassName_PosProcessDurable);
    }
    //INN-R170003 add end


    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
        strDurableStatusMultiChangeReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return rc;
    }

    for (durableCnt=0; durableCnt < durableLen; durableCnt++)
    {
        if (0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette))
        {
            PPT_METHODTRACE_V1("", "durableCategory is Cassette");

            //-----------------------------------------------------------
            // Check cassette interFabXferState
            //-----------------------------------------------------------
            objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
            objCassette_interFabXferState_Get_in strCassette_interFabXferState_Get_in;
            strCassette_interFabXferState_Get_in.cassetteID = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID;

            rc = cassette_interFabXferState_Get(strCassette_interFabXferState_Get_out,
                                                strObjCommonIn,
                                                strCassette_interFabXferState_Get_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "cassette_interFabXferState_Get() != RC_OK");
                strDurableStatusMultiChangeReqResult.strResult = strCassette_interFabXferState_Get_out.strResult;
                return rc;
            }

            //-----------------------------------------------------------
            // "Transferring"
            //-----------------------------------------------------------
            if (0 == CIMFWStrCmp(strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring))
            {
                PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
                PPT_SET_MSG_RC_KEY2(strDurableStatusMultiChangeReqResult,
                                    MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                    RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                    strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID.identifier,
                                    strCassette_interFabXferState_Get_out.interFabXferState);
                return( RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ );
            }
        }

        if (0 == CIMFWStrCmp(strInParm.durableStatus, CIMFW_Durable_Available)
         || 0 == CIMFWStrCmp(strInParm.durableStatus, CIMFW_Durable_InUse))
        {
            PPT_METHODTRACE_V1("","Change to Available or InUse");

            //---------------------------------------
            // Get Durable Sub-Status
            //---------------------------------------
            objDurable_subState_Get_out strDurable_subState_Get_out;
            objDurable_subState_Get_in  strDurable_subState_Get_in;
            strDurable_subState_Get_in.durableCategory = strInParm.durableCategory;
            strDurable_subState_Get_in.durableID       = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID;

            rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "durable_subState_Get() != RC_OK");
                strDurableStatusMultiChangeReqResult.strResult = strDurable_subState_Get_out.strResult;
                return rc;
            }

            if (CIMFWStrLen(strDurable_subState_Get_out.durableSubStatus.identifier) == 0)
            {
                PPT_METHODTRACE_V1("", "durableSubStatus is blank");

                //---------------------------------------
                // Check Durable OnRoute
                //---------------------------------------
                objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
                objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
                strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
                strDurable_OnRoute_Check_in.durableID       = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID;

                rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
                if (rc == RC_DURABLE_ONROUTE)
                {
                    PPT_METHODTRACE_V1("", "durable_OnRoute_Check() == RC_DURABLE_ONROUTE");

                    //---------------------------------------
                    // Check Durable Inventory State
                    //---------------------------------------
                    objDurable_inventoryState_Get_out strDurable_inventoryState_Get_out;
                    objDurable_inventoryState_Get_in  strDurable_inventoryState_Get_in;
                    strDurable_inventoryState_Get_in.durableCategory = strInParm.durableCategory;
                    strDurable_inventoryState_Get_in.durableID       = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID;
                    rc = durable_inventoryState_Get(strDurable_inventoryState_Get_out, strObjCommonIn, strDurable_inventoryState_Get_in);
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "durable_inventoryState_Get() != RC_OK");
                        strDurableStatusMultiChangeReqResult.strResult = strDurable_inventoryState_Get_out.strResult;
                        return rc;
                    }
                    else if (0 == CIMFWStrCmp(strDurable_inventoryState_Get_out.durableInventoryState, SP_Durable_InventoryState_OnFloor))
                    {
                        PPT_METHODTRACE_V1("", "durableInventoryState = SP_Durable_InventoryState_OnFloor");
                        PPT_SET_MSG_RC_KEY(strDurableStatusMultiChangeReqResult,
                                           MSG_DURABLE_CANNOT_STATECHANGE_ONFLOOR,
                                           RC_DURABLE_CANNOT_STATECHANGE_ONFLOOR,
                                           strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID.identifier);
                        return RC_DURABLE_CANNOT_STATECHANGE_ONFLOOR;
                    }
                }
            }
        }

        //---------------------------------------
        // Check Durable Sub Status transition
        //---------------------------------------
        objDurable_currentState_CheckTransition_out strDurable_currentState_CheckTransition_out;
        objDurable_currentState_CheckTransition_in  strDurable_currentState_CheckTransition_in;
        strDurable_currentState_CheckTransition_in.durableCategory         = strInParm.durableCategory;
        strDurable_currentState_CheckTransition_in.durableID               = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID;
        strDurable_currentState_CheckTransition_in.durableStatus           = strInParm.durableStatus;
        strDurable_currentState_CheckTransition_in.durableSubStatus        = strInParm.durableSubStatus;
        strDurable_currentState_CheckTransition_in.currentDurableStatus    = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableStatus;
        strDurable_currentState_CheckTransition_in.currentDurableSubStatus = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableSubStatus;

        rc = durable_currentState_CheckTransition(strDurable_currentState_CheckTransition_out,
                                                  strObjCommonIn,
                                                  strDurable_currentState_CheckTransition_in);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "durable_currentState_CheckTransition() != RC_OK");
            strDurableStatusMultiChangeReqResult.strResult = strDurable_currentState_CheckTransition_out.strResult;
            return rc;
        }

        //---------------------------------------
        // Change durable status & sub-status
        //---------------------------------------
        objDurable_currentState_Change_out  strDurable_currentState_Change_out;
        objDurable_currentState_Change_in   strDurable_currentState_Change_in;
        strDurable_currentState_Change_in.durableCategory  = strInParm.durableCategory;
        strDurable_currentState_Change_in.durableID        = strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID;
        strDurable_currentState_Change_in.durableStatus    = strInParm.durableStatus;
        strDurable_currentState_Change_in.durableSubStatus = strInParm.durableSubStatus;

        rc = durable_currentState_Change(strDurable_currentState_Change_out,
                                         strObjCommonIn,
                                         strDurable_currentState_Change_in);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "durable_currentState_Change() != RC_OK");
            strDurableStatusMultiChangeReqResult.strResult = strDurable_currentState_Change_out.strResult;
            return( rc );
        }

        //---------------------------------------
        // Create Durable Change Event
        //---------------------------------------
        objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
        rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                     strObjCommonIn,
                                     txID,
                                     strInParm.strCurrentDurableStatusInfoSeq[durableCnt].durableID,
                                     strInParm.durableCategory,
                                     SP_DurableEvent_Action_StateChange,
                                     claimMemo);

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "durableChangeEvent_Make() != RC_OK");
            strDurableStatusMultiChangeReqResult.strResult = strDurableChangeEvent_Make_out.strResult;
            SET_MSG_RC(strDurableStatusMultiChangeReqResult, MSG_FAIL_MAKE_HISTORY, rc);
            return rc;
        }
    }
    SET_MSG_RC(strDurableStatusMultiChangeReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txDurableStatusMultiChangeReq");
    return RC_OK;
}