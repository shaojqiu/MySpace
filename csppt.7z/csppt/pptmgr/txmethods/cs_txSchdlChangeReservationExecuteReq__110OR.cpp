#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txSchdlChangeReservationExecuteReq__110OR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/22/07 17:30:25 [ 11/22/07 17:30:27 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_txSchdlChangeReservationExecuteReq__110OR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txSchdlChangeReservationExecuteReq__110()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/03/05 D4100120 Y.Kurisu       Initial Release (Future Action)
// 2002/10/23 P4200271 K.Kido         Add : Check lot's inventry state.
// 2002/11/19 D4200210 K.Kido         Add : Check lot's backup state.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/11/18 D7000021 M.Murata       Add : Check lot's hold state. (LOCK)
// 2006/10/20 D8000028 K.Kido         Change cassette_representLot_Get ==> cassette_lotList_GetWithPriorityOrder
// 2006/10/26 D7000354 H.Hasegawa     Add the logic which resets Q-Time actions
// 2007/02/02 P8000062 M.Kase         Change the value of input parameter : priorityClass for lotChangeEvent_Make method.
// 2007/05/28 P9000007 S.Yamamoto     Fix : Lot Schedule Change aren't allowed under NonProBank state
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/30 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2010-04-19 DSIV00001830 R.Iriguchi     Wafer Stacking Operation Support.
// 2010/10/13 DSIV00002435 M.Ogawa        Support SubLotType change by Schedule Change Reservation
// 2011/01/26 PSIV00002827 M.Ogawa        Updating required carrier category
// 2011/10/21 DSN000022151 Qiang Wen      Q-Time clearance control
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txSchdlChangeReservationExecuteReq__110
// 2017/09/12 INN-R170002  Thomas Song    Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptSchdlChangeReservationExecuteReqResult        strSchdlChangeReservationExecuteReqResult
//     const pptObjCommonIn&                            strObjCommonIn
//     const pptRescheduledLotAttributesSequence__110&  strRescheduledLotAttributes
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txSchdlChangeReservationExecuteReq__110 ( pptSchdlChangeReservationExecuteReqResult&      strSchdlChangeReservationExecuteReqResult,
                                                                    const pptObjCommonIn&                           strObjCommonIn,
                                                                    const pptRescheduledLotAttributesSequence__110& strRescheduledLotAttributes,
//D6000025                                                               const char * claimMemo,
//D6000025                                                               CORBA::Environment &IT_env)
                                                                    const char *                                    claimMemo   //D6000025
                                                                    CORBAENV_LAST_CPP )                                         //D6000025

{
    PPT_METHODTRACE_ENTRY( "CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110 " );
    CORBA::Long rc = RC_OK;

    CORBA::Long nLen = strRescheduledLotAttributes.length();
    PPT_METHODTRACE_V2( "CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "strRescheduledLotAttributes.length()", nLen );

    strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn.length(nLen);
    char * methodName = NULL;

//D7000021 add start
    //------------------------------------
    // Check LOCK Hold.
    //------------------------------------
    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
    for ( CORBA::Long loopCnt = 0; loopCnt < nLen; loopCnt++ )
    {
        objectIdentifierSequence lotIDSeq;
        lotIDSeq.length(1);
        lotIDSeq[0] = strRescheduledLotAttributes[loopCnt].lotID;
        objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
        rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", lotIDSeq[0].identifier );
            strSchdlChangeReservationExecuteReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
            return ( rc );
        }
    }
//D7000021 add end

//D9000056 add start
    //-----------------------------
    //  Check InPostProcessFlag
    //-----------------------------
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
//DSIV00000201 Add Start
    objectIdentifierSequence userGroupIDs;
    userGroupIDs.length(0);
    CORBA::ULong userGroupIDsLen = userGroupIDs.length();

//DSIV00000201 Add End
    for( loopCnt = 0; loopCnt < nLen; loopCnt++ )
    {
        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
        objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = strRescheduledLotAttributes[loopCnt].lotID;

        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strSchdlChangeReservationExecuteReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            return( rc );
        }

        //----------------------------------------------
        //  If Lot is in post process, returns error
        //----------------------------------------------
        if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
        {
            PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
            if (userGroupIDsLen == 0)
            {
                /*---------------------------*/
                /* Get UserGroupID By UserID */
                /*---------------------------*/
                objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
                rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                                 strObjCommonIn,
                                                 strObjCommonIn.strUser.userID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                    strSchdlChangeReservationExecuteReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
                    return( rc );
                }
                userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
                userGroupIDsLen = userGroupIDs.length();
                PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
            }
            CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
            PPT_METHODTRACE_V2("", "extPostProc", extPostProc);

            CORBA::ULong nCnt = 0;
            for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                {
                    PPT_METHODTRACE_V1("", "# External Post Process User!");
                    break;
                }

            }
            if (nCnt == userGroupIDsLen)
            {
                PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                PPT_SET_MSG_RC_KEY( strSchdlChangeReservationExecuteReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    strRescheduledLotAttributes[loopCnt].lotID.identifier );
                return( RC_LOT_INPOSTPROCESS );
            }   //DSIV00000201
        }
    }
//D9000056 add end

    for ( CORBA::Long seqIx = 0; seqIx < nLen; seqIx++ )
    {
        strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].lotID = strRescheduledLotAttributes[seqIx].lotID;
        /*------------------------------------------------------------------------*/
        /*   Check Lot Process State                                              */
        /*------------------------------------------------------------------------*/
        objLot_processState_Get_out       strLot_processState_Get_out;
        rc = lot_processState_Get( strLot_processState_Get_out,strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "lot_processState_Get() != RC_OK", seqIx);
            strSchdlChangeReservationExecuteReqResult.strResult =  strLot_processState_Get_out.strResult;
            strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }
        else if ( CIMFWStrCmp( strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Waiting) != 0 )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0", seqIx) ;
            PPT_SET_MSG_RC_KEY2( strSchdlChangeReservationExecuteReqResult,
                                 MSG_INVALID_LOT_PROCSTAT,
                                 RC_INVALID_LOT_PROCSTAT,
                                 strRescheduledLotAttributes[seqIx].lotID.identifier,
                                 strLot_processState_Get_out.theLotProcessState ) ;
            strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_LOT_PROCSTAT) ;
            return(RC_INVALID_LOT_PROCSTAT);
        }

//P4200271 add start
        /*------------------------------------------------------------------------*/
        /*   Check Lot Inventory State                                            */
        /*------------------------------------------------------------------------*/
        if( (CIMFWStrLen(strRescheduledLotAttributes[seqIx].routeID.identifier)     > 0)  &&
            (CIMFWStrLen(strRescheduledLotAttributes[seqIx].currentOperationNumber) > 0) )
        {
            objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
            rc = lot_inventoryState_Get( strLot_inventoryState_Get_out, strObjCommonIn,
                                         strRescheduledLotAttributes[seqIx].lotID ) ;
            if (rc != RC_OK)
            {
                strSchdlChangeReservationExecuteReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
                return( rc );
            }
//P9000007            else if ( CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_OnFloor) != 0 )
            else if ( ( CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_OnFloor) != 0 ) &&   //P9000007
                      ( CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_NonProBank) != 0 ) ) //P9000007
            {
                PPT_SET_MSG_RC_KEY2( strSchdlChangeReservationExecuteReqResult,
                                     MSG_INVALID_LOT_INVENTORYSTAT,
                                     RC_INVALID_LOT_INVENTORYSTAT,
                                     strRescheduledLotAttributes[seqIx].lotID.identifier,
                                     strLot_inventoryState_Get_out.lotInventoryState );
                return(RC_INVALID_LOT_INVENTORYSTAT);
            }
        }
//P4200271 add end

//DSIV00001830 Add Start
        /*------------------------------------------------------------------------*/
        /*   Check Lot Inventory State                                            */
        /*------------------------------------------------------------------------*/
        objLot_finishedState_Get_out strLot_finishedState_Get_out ;
        rc = lot_finishedState_Get( strLot_finishedState_Get_out, strObjCommonIn,
                                    strRescheduledLotAttributes[seqIx].lotID );

        if ( rc != RC_OK )
        {
            strSchdlChangeReservationExecuteReqResult.strResult = strLot_finishedState_Get_out.strResult;
            return rc;
        }

        if ( CIMFWStrCmp( strLot_finishedState_Get_out.lotFinishedState, SP_LOT_FINISHED_STATE_STACKED ) == 0 )
        {
            PPT_SET_MSG_RC_KEY( strSchdlChangeReservationExecuteReqResult,
                                MSG_INVALID_LOT_FINISHSTAT,
                                RC_INVALID_LOT_FINISHSTAT,
                                strLot_finishedState_Get_out.lotFinishedState );
        
            return RC_INVALID_LOT_FINISHSTAT;
        }
//DSIV00001830 Add End

//DSIV00000214 add start
        if( CIMFWStrCmp( strRescheduledLotAttributes[seqIx].originalRouteID, strRescheduledLotAttributes[seqIx].routeID.identifier ) == 0 )
        {
            //---------------------------------------
            // Check interFabXferPlan existence
            //---------------------------------------
            PPT_METHODTRACE_V1("", "call process_CheckInterFabXferPlanSkip()");
            objProcess_CheckInterFabXferPlanSkip_in strProcess_CheckInterFabXferPlanSkip_in;
            strProcess_CheckInterFabXferPlanSkip_in.lotID = strRescheduledLotAttributes[seqIx].lotID;
            strProcess_CheckInterFabXferPlanSkip_in.currentRouteID.identifier = strRescheduledLotAttributes[seqIx].originalRouteID;
            strProcess_CheckInterFabXferPlanSkip_in.currentOpeNo = strRescheduledLotAttributes[seqIx].originalOperationNumber;
            strProcess_CheckInterFabXferPlanSkip_in.jumpingRouteID = strRescheduledLotAttributes[seqIx].routeID;
            strProcess_CheckInterFabXferPlanSkip_in.jumpingOpeNo = strRescheduledLotAttributes[seqIx].currentOperationNumber;

            objProcess_CheckInterFabXferPlanSkip_out strProcess_CheckInterFabXferPlanSkip_out;
            rc = process_CheckInterFabXferPlanSkip( strProcess_CheckInterFabXferPlanSkip_out,
                                                    strObjCommonIn,
                                                    strProcess_CheckInterFabXferPlanSkip_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### process_CheckInterFabXferPlanSkip() != RC_OK", rc);
                strSchdlChangeReservationExecuteReqResult.strResult = strProcess_CheckInterFabXferPlanSkip_out.strResult;
                return( rc );
            }
        }
//DSIV00000214 add end

//D4200210 add start
        /*------------------------------------------------------------------------*/
        /*   Check Lot's backup State                                             */
        /*------------------------------------------------------------------------*/
        objLot_backupInfo_Get_out strLot_backupInfo_Get_out;
        rc = lot_backupInfo_Get( strLot_backupInfo_Get_out, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID );

        if( rc != RC_OK )
        {
            strSchdlChangeReservationExecuteReqResult.strResult = strLot_backupInfo_Get_out.strResult ;
            return( rc );
        }
        else if(strLot_backupInfo_Get_out.strLotBackupInfo.backupProcessingFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", " ##### lot's backupProcessingFlag == TRUE ");
            if( 0 != CIMFWStrLen(strRescheduledLotAttributes[seqIx].productID.identifier))
            {
                PPT_SET_MSG_RC_KEY( strSchdlChangeReservationExecuteReqResult,
                                    MSG_LOT_BACKUP_ON_BACKUPSITE,
                                    RC_LOT_BACKUP_ON_BACKUPSITE,
                                    strRescheduledLotAttributes[seqIx].lotID.identifier );
                return( RC_LOT_BACKUP_ON_BACKUPSITE );
            }

            objLot_currentRouteID_Get_out strLot_currentRouteID_Get_out;
            rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out,strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID );

            if( rc != RC_OK )
            {
                strSchdlChangeReservationExecuteReqResult.strResult = strLot_currentRouteID_Get_out.strResult ;
                return( rc );
            }
            else if( 0 != CIMFWStrCmp(strLot_currentRouteID_Get_out.currentRouteID.identifier, strRescheduledLotAttributes[seqIx].routeID.identifier))
            {
                PPT_SET_MSG_RC_KEY( strSchdlChangeReservationExecuteReqResult,
                                    MSG_LOT_BACKUP_ON_BACKUPSITE,
                                    RC_LOT_BACKUP_ON_BACKUPSITE,
                                    strRescheduledLotAttributes[seqIx].lotID.identifier );
                return( RC_LOT_BACKUP_ON_BACKUPSITE );
            }
        }
//D4200210 add end

        /*------------------------------------------------------------------------*/
        /*   Register Product Request                                             */
        /*------------------------------------------------------------------------*/
        objLot_ChangeSchedule_out       strLot_ChangeSchedule_out;
        objLot_ChangeSchedule_in__110   strLot_ChangeSchedule_in;
        strLot_ChangeSchedule_in.strRescheduledLotAttributes = strRescheduledLotAttributes[seqIx];
        strLot_ChangeSchedule_out.opehsMoveFlag = FALSE;
        rc = lot_ChangeSchedule__110(strLot_ChangeSchedule_out,strObjCommonIn,strLot_ChangeSchedule_in);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "lot_ChangeSchedule() != RC_OK", seqIx);
            strSchdlChangeReservationExecuteReqResult.strResult =  strLot_ChangeSchedule_out.strResult ;
            strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }

        /*------------------------------------------------------------------------*/
        /*   Delete all QTime restrictions for previous route                     */
        /*------------------------------------------------------------------------*/
        if( strLot_ChangeSchedule_out.opehsMoveFlag == TRUE )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "strLot_ChangeSchedule_out.opehsMoveFlag == TRUE", seqIx);
//DSN000022151 Add Start
            CORBA::Boolean bSameRouteFlag = FALSE;
            if ( 0 == CIMFWStrCmp( strRescheduledLotAttributes[seqIx].routeID.identifier, strRescheduledLotAttributes[seqIx].originalRouteID) )
            {
                PPT_METHODTRACE_V2("", "strRescheduledLotAttributes[seqIx].routeID = strRescheduledLotAttributes[seqIx].originalRouteID",
                                        strRescheduledLotAttributes[seqIx].routeID.identifier);
                bSameRouteFlag = TRUE;
            }

            CORBA::String_var keepQTime = CIMFWStrDup(getenv(SP_KEEP_QTIME_ON_SCHCHANGE));
            PPT_METHODTRACE_V2("", "keepQTime", keepQTime);
            if( ( TRUE == bSameRouteFlag )
             && ( 0 == CIMFWStrCmp( keepQTime, SP_Function_Available_TRUE ) ) )
            {
                PPT_METHODTRACE_V1("", "Not clear Q-Time info");
                //Not clear Q-Time information
            }
            else
            {
                PPT_METHODTRACE_V1("", "Clear Q-Time info");
//DSN000022151 Add End
//DSN000022151 Indent Start
                objQtime_AllClearByRouteChange_out strQtime_AllClearByRouteChange_out ;
                rc = qtime_AllClearByRouteChange( strQtime_AllClearByRouteChange_out , strObjCommonIn , strRescheduledLotAttributes[seqIx].lotID);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "qtime_AllClearByRouteChange() != RC_OK", seqIx);
                    strSchdlChangeReservationExecuteReqResult.strResult =  strQtime_AllClearByRouteChange_out.strResult ;
                    strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString( rc );
                    return(rc);
                }

                //D7000354 Add Start
                //--------------------------------------------------
                // Reset Q-Time actions
                //--------------------------------------------------
                objectIdentifier  resetReasonCodeID;
                resetReasonCodeID.identifier = CIMFWStrDup( SP_Reason_QTimeClear );

                //----- Lot Hold Actions -------//
                if( strQtime_AllClearByRouteChange_out.strLotHoldReleaseList.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", "The lot hold actions to reset was found.");

                    pptHoldLotReleaseReqResult  strHoldLotReleaseReqResult;
                    rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID,
                                              resetReasonCodeID, strQtime_AllClearByRouteChange_out.strLotHoldReleaseList );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK");
                        strSchdlChangeReservationExecuteReqResult.strResult                                 = strHoldLotReleaseReqResult.strResult;
                        strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString( rc );
                        return rc;
                    }
                }

                //----- Future Hold Actions -------//
                if( strQtime_AllClearByRouteChange_out.strFutureHoldCancelList.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", "The future hold actions to cancel was found.");

                    pptFutureHoldCancelReqResult  strFutureHoldCancelReqResult;
                    rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID, resetReasonCodeID,
                                                SP_EntryType_Cancel, strQtime_AllClearByRouteChange_out.strFutureHoldCancelList );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK");
                        strSchdlChangeReservationExecuteReqResult.strResult                                 = strFutureHoldCancelReqResult.strResult;
                        strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString( rc );
                        return rc;
                    }
                }

                //----- Future Rework Actions -------//
                CORBA::Long  cancelLen = strQtime_AllClearByRouteChange_out.strFutureReworkCancelList.length();
                if( cancelLen > 0 )
                {
                    PPT_METHODTRACE_V2("", "The future rework actions to cancel was found.", cancelLen);

                    for( CORBA::Long  cancelCnt = 0; cancelCnt < cancelLen; cancelCnt++ )
                    {
                        pptFutureReworkInfo  strFutureRework = strQtime_AllClearByRouteChange_out.strFutureReworkCancelList[cancelCnt];

                        pptFutureReworkCancelReqResult  strFutureReworkCancelReqResult;
                        rc = txFutureReworkCancelReq( strFutureReworkCancelReqResult, strObjCommonIn, strFutureRework.lotID, strFutureRework.routeID,
                                                      strFutureRework.operationNumber, strFutureRework.strFutureReworkDetailInfoSeq, "" );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "txFutureReworkCancelReq() != RC_OK");
                            strSchdlChangeReservationExecuteReqResult.strResult                                 = strFutureReworkCancelReqResult.strResult;
                            strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString( rc );
                            return rc;
                        }
                    }
                }
                //D7000354 Add End
//DSN000022151 Indent End
            }   //DSN000022151
        }
//PSIV00002827 Add start
        //--------------------------------------------------------------------------------------------------
        // UpDate RequiredCassetteCategory
        //--------------------------------------------------------------------------------------------------
        objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
        rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                                 strObjCommonIn,
                                                                 strRescheduledLotAttributes[seqIx].lotID );

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
            strSchdlChangeReservationExecuteReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
            return rc;
        }
//PSIV00002827 Add End

//INN-R170002 Add Start
        //--------------------------------------------------------------------------------------------------
        // Check Contamination Level
        //--------------------------------------------------------------------------------------------------
        objLot_cassette_Get_out strLot_cassette_Get_out;
        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, strRescheduledLotAttributes[seqIx].lotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_cassette_Get() != RC_OK") ;
            strSchdlChangeReservationExecuteReqResult.strResult = strLot_cassette_Get_out.strResult ;
            return(rc);
        }
        
        csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
        strLot_ContaminationInfo_CheckForMove_in.lotID = strRescheduledLotAttributes[seqIx].lotID;
        strLot_ContaminationInfo_CheckForMove_in.carrierID = strLot_cassette_Get_out.cassetteID;
        csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
        rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                    strObjCommonIn,
                                                    strLot_ContaminationInfo_CheckForMove_in );

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
            strSchdlChangeReservationExecuteReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
            return rc;
        }

        if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
        {
            pptHoldLotReqResult strHoldLotReqResult;
            pptHoldListSequence strLotHoldReqList( 1 );
            strLotHoldReqList.length( 1 );

            strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
            strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
            strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
            strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
            strLotHoldReqList[0].claimMemo                   = claimMemo;

            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                               strRescheduledLotAttributes[seqIx].lotID,
                               strLotHoldReqList );

            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                strSchdlChangeReservationExecuteReqResult.strResult = strHoldLotReqResult.strResult ;
                return rc ;
            }
            else
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
            }
        }
//INN-R170002 Add End

        /*------------------------------------------------------------------------*/
        /*   Make History                                                         */
        /*------------------------------------------------------------------------*/
        if(strLot_ChangeSchedule_out.opehsAddFlag == TRUE)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "strLot_ChangeSchedule_out.opehsAddFlag == TRUE", seqIx);
            objLotOperationMoveEvent_MakeChangeRoute_out  strLotOperationMoveEvent_MakeChangeRoute_out;
            rc = lotOperationMoveEvent_MakeChangeRoute(strLotOperationMoveEvent_MakeChangeRoute_out,
                                                       strObjCommonIn,
                                                       "TXOMC004",
                                                       strRescheduledLotAttributes[seqIx].lotID,
                                                       strLot_ChangeSchedule_out.oldCurrentPOData,
                                                       claimMemo);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "lotOperationMoveEvent_MakeChangeRoute() != RC_OK", seqIx) ;
//P5000145                PPT_SET_MSG_RC_KEY(strSchdlChangeReservationExecuteReqResult,MSG_FAIL_MAKE_HISTORY ,rc,strRescheduledLotAttributes[seqIx].lotID.identifier) ;
                SET_MSG_RC( strSchdlChangeReservationExecuteReqResult,MSG_FAIL_MAKE_HISTORY ,rc );        //P5000145
                strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
                return(rc);
            }
        }

        objLotChangeEvent_Make_out strLotChangeEvent_Make_out;
        rc = lotChangeEvent_Make(strLotChangeEvent_Make_out, strObjCommonIn,
                                 "TXOMC011",
                                 strRescheduledLotAttributes[seqIx].lotID.identifier,
                                 "0",
                                 "",
                                 "",
                                 "",
                                 "",
//P8000062                                 "0",
                                 strRescheduledLotAttributes[seqIx].priorityClass,    //P8000062
                                 strRescheduledLotAttributes[seqIx].productID.identifier,
                                 strLot_ChangeSchedule_out.previousProductID.identifier,
                                 strRescheduledLotAttributes[seqIx].plannedStartTime,
                                 strRescheduledLotAttributes[seqIx].plannedFinishTime,
                                 claimMemo) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "lotChangeEvent_Make() != RC_OK", seqIx) ;
//P5000145            PPT_SET_MSG_RC_KEY(strSchdlChangeReservationExecuteReqResult, MSG_FAIL_MAKE_HISTORY ,rc ,strRescheduledLotAttributes[seqIx].lotID.identifier) ;
            SET_MSG_RC( strSchdlChangeReservationExecuteReqResult, MSG_FAIL_MAKE_HISTORY ,rc );        //P5000145
            strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].lotID = strRescheduledLotAttributes[seqIx].lotID ;
            strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
        }

        objLotReticleSetChangeEvent_Make_out strLotReticleSetChangeEvent_Make_out;
        rc = lotReticleSetChangeEvent_Make( strLotReticleSetChangeEvent_Make_out,
                                            strObjCommonIn,
                                            "TXOMC004",
                                            strRescheduledLotAttributes[seqIx].lotID,
                                            claimMemo);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "lotReticleSetChangeEvent_Make() != RC_OK", seqIx);
//P5000145            PPT_SET_MSG_RC_KEY( strSchdlChangeReservationExecuteReqResult, MSG_FAIL_MAKE_HISTORY, rc , strRescheduledLotAttributes[seqIx].lotID.identifier );
            SET_MSG_RC( strSchdlChangeReservationExecuteReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
            strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].lotID = strRescheduledLotAttributes[seqIx].lotID;
            strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }
    }

    /*------------------------------------------*/
    /*   AMHS I/F for Priority Change Request   */
    /*------------------------------------------*/
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "Start AMHS I/F")

    CORBA::Long cLen=0;

    pptPriorityChangeReq priorityChangeReq;

    objectIdentifier aLotID ;
    objectIdentifier aCassetteID ;

    for (CORBA::Long i=0; i<nLen; i++)
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "Lot Loop Count ",i)
        /*------------------------------------------------------------------------*/
        /*   Get cassette / lot connection                                        */
        /*------------------------------------------------------------------------*/
        aLotID = strRescheduledLotAttributes[i].lotID;
        objLot_cassette_Get_out strLot_cassette_Get_out ;

        PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "aLotID ",aLotID.identifier)

        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "lot_cassette_Get() == RC_OK") ;
            aCassetteID = strLot_cassette_Get_out.cassetteID ;

            PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "aCassetteID ",aCassetteID.identifier)
            /*----------------------------------------------*/
            /*   Check the representative lotID             */
            /*----------------------------------------------*/
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "Check the representative lotID");

//D8000028  objCassette_representLot_Get_out strCassette_representLot_Get_out;
//D8000028
//D8000028  rc = cassette_representLot_Get( strCassette_representLot_Get_out, strObjCommonIn, aCassetteID );
//D8000028  if (rc == RC_OK)
//D8000028  {
//D8000028      PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "cassette_representLot_Get().lotID ",strCassette_representLot_Get_out.lotID.identifier)
//D8000028      if(0 == CIMFWStrCmp(aLotID.identifier,strCassette_representLot_Get_out.lotID.identifier))
//D8000028      {
//D8000028          PPT_METHODTRACE_V1("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "cassette_representLot_Get() == RC_OK")
//D8000028          priorityChangeReq.priorityInfoData.length(cLen+1);
//D8000028          priorityChangeReq.priorityInfoData[cLen].priority = strRescheduledLotAttributes[i].priorityClass;
//D8000028          priorityChangeReq.priorityInfoData[cLen].carrierID= aCassetteID;
//D8000028          PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "priorityInfoData.length",cLen+1)
//D8000028          PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "priorityInfoData[cLen].priority",priorityChangeReq.priorityInfoData[cLen].priority)
//D8000028          PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "priorityInfoData[cLen].carrierID",priorityChangeReq.priorityInfoData[cLen].carrierID.identifier)
//D8000028          cLen++;
//D8000028      }
//D8000028  }
//D8000028  else
//D8000028  {
//D8000028      PPT_METHODTRACE_V1("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "cassette_representLot_Get() != RC_OK")
//D8000028  }
//D8000028 add start
            objCassette_lotList_GetWithPriorityOrder_out strCassette_lotList_GetWithPriorityOrder_out;
            rc = cassette_lotList_GetWithPriorityOrder( strCassette_lotList_GetWithPriorityOrder_out, strObjCommonIn, aCassetteID );

            if (rc == RC_OK && 0 < strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq.length() )
            {
                PPT_METHODTRACE_V2("", "cassette_lotList_GetWithPriorityOrder.lotID ",strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID.identifier)
                if(0 == CIMFWStrCmp( aLotID.identifier,strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID.identifier ))
                {
                    priorityChangeReq.priorityInfoData.length(cLen+1);
                    priorityChangeReq.priorityInfoData[cLen].priority = strRescheduledLotAttributes[i].priorityClass ;
                    priorityChangeReq.priorityInfoData[cLen].carrierID = aCassetteID ;
                    PPT_METHODTRACE_V2("", "### priorityInfoData.length = ",cLen+1);
                    PPT_METHODTRACE_V2("", "### priorityInfoData[cLen].priority  = ",priorityChangeReq.priorityInfoData[cLen].priority);
                    PPT_METHODTRACE_V2("", "### priorityInfoData[cLen].carrierID = ",priorityChangeReq.priorityInfoData[cLen].carrierID.identifier);
                    cLen++;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "cassette_lotList_GetWithPriorityOrder() != RC_OK")
            }
//D8000028 add end
        }
        else
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "lot_cassette_Get() != RC_OK")
        }
    }

    CORBA::Long xLen = priorityChangeReq.priorityInfoData.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "xLen",xLen)

    if (0 < xLen)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "Call XMSMgr_SendPriorityChangeReq")

        objXMSMgr_SendPriorityChangeReq_out strXMSMgr_SendPriorityChangeReq_out;
        rc = XMSMgr_SendPriorityChangeReq(strXMSMgr_SendPriorityChangeReq_out,
                                          strObjCommonIn,
                                          strObjCommonIn.strUser,
                                          priorityChangeReq);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110", "XMSMgr_SendPriorityChangeReq() != RC_OK") ;
        }
    }
    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    for (i=0; i<nLen; i++)
    {
        strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[i].returnCode = ConvertLongtoString( RC_OK );
        strSchdlChangeReservationExecuteReqResult.strChangeLotSchdlReturn[i].lotID = strRescheduledLotAttributes[i].lotID ;
    }

    SET_MSG_RC(strSchdlChangeReservationExecuteReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txSchdlChangeReservationExecuteReq__110 ") ;
    return RC_OK ;
}
