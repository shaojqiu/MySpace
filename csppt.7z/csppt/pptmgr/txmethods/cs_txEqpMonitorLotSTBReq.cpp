//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorLotSTBReq.cpp
//
#include "cs_pptmgr.hpp"
#include "pprsp.hh"
#include "ppsctgy.hh"
//
// Class: CS_PPTManager
//
// Service: cs_txEqpMonitorLotSTBReq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-31 INN-R170016   JJ.Zhang       Equipment monitor enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csEqpMonitorLotSTBReqResult&            strEqpMonitorLotSTBReqResult
//     const pptObjCommonIn&                   strObjCommonIn
//     const csEqpMonitorLotSTBReqInParm&      strEqpMonitorLotSTBReqInParm
//     const char *                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long CS_PPTManager_i::cs_txEqpMonitorLotSTBReq(
    csEqpMonitorLotSTBReqResult&            strEqpMonitorLotSTBReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const csEqpMonitorLotSTBReqInParm&      strEqpMonitorLotSTBReqInParm,
    const char*                             claimMemo
  	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txEqpMonitorLotSTBReq")
    CORBA::Long rc = RC_OK ;

    PPT_METHODTRACE_V2("","in para BWSID    ", strEqpMonitorLotSTBReqInParm.BWSID.identifier );
    PPT_METHODTRACE_V2("","in para carrierID", strEqpMonitorLotSTBReqInParm.carrierID.identifier );

    strEqpMonitorLotSTBReqResult.lotIDs.length(0);
    objectIdentifier carrierID = strEqpMonitorLotSTBReqInParm.carrierID;

    //----------------------------------
    //  get BWSOut slotMap for carrier
    //----------------------------------
    csObjBWSOutSTB_slotMap_GetDR_in strBWSOutSTB_slotMap_GetDR_in;
    strBWSOutSTB_slotMap_GetDR_in.carrierID = carrierID;

    csObjBWSOutSTB_slotMap_GetDR_out strBWSOutSTB_slotMap_GetDR_out;
    rc = cs_BWSOutSTB_slotMap_GetDR(strBWSOutSTB_slotMap_GetDR_out,
                                    strObjCommonIn, 
                                    strBWSOutSTB_slotMap_GetDR_in);
    if( rc == RC_NOT_FOUND_CASSETTE)
    {
        PPT_METHODTRACE_V2("","BWS Out&STB info for carrier no exist", carrierID.identifier);
        SET_MSG_RC(strEqpMonitorLotSTBReqResult, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorLotSTBReq")
        return( RC_OK );
    }
    else if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","cs_BWSOutSTB_slotMap_GetDR() rc != RC_OK", rc);
        strEqpMonitorLotSTBReqResult.strResult = strBWSOutSTB_slotMap_GetDR_out.strResult;
        return(rc);
    }
    CORBA::ULong mapLen1 = strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq.length();
    PPT_METHODTRACE_V2("","strNPWSTB_SlotMapSeq.length", mapLen1);
    PPT_METHODTRACE_V2("", "npwType", strBWSOutSTB_slotMap_GetDR_out.npwType );

    //Monitor: show monitor ID
    //Recycle/Pre-Process: show product Id
    CORBA::String_var strMsgkey;
    if( 0 == CIMFWStrCmp(strBWSOutSTB_slotMap_GetDR_out.npwType, CS_EqpMonitor_NPW_Type_Monitor))
    {
        strMsgkey = strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID.identifier;
    }
    else if(mapLen1 > 0)
    {
        strMsgkey = strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq[0].destProductID.identifier;
    }
    else
    {
        //not reachable, keep blank anyway
    }
    PPT_METHODTRACE_V2("", "strMsgkey", strMsgkey );

    //--------------------------------
    //   Object Lock for Cassette
    //--------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, carrierID, SP_ClassName_PosCassette);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strEqpMonitorLotSTBReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    //--------------------------------
    //  Get cassette lot list.
    //--------------------------------
    objCassette_GetLotList_out strCassette_GetLotList_out;
    rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, carrierID );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK", rc);
        strEqpMonitorLotSTBReqResult.strResult = strCassette_GetLotList_out.strResult;
        return( rc );
    }

    CORBA::ULong i = 0, j = 0;
    CORBA::ULong nSeqLen = 0;
    CORBA::ULong nLotLen = 0;

    nLotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
    PPT_METHODTRACE_V2("","strLotListInCassetteInfo.lotID.length", nLotLen);

    for( i =0; i<nLotLen; i++)
    {
        PPT_METHODTRACE_V2("","object_Lock", strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[i].identifier);

        //------------------------------
        // Lock lot for update
        //------------------------------
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, 
                        strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[i],
                        SP_ClassName_PosLot );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
            strEqpMonitorLotSTBReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
    }

    CORBA::Boolean bValidSTBInfo = TRUE;
    csEqpMonitorSubInfoSequence strEqpMonitorSubInfoSeq;
    //----------------------------------------------
    // Check slot map matched the monitor definiton
    //----------------------------------------------
    objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
    rc = cassette_GetWaferMapDR(strCassette_GetWaferMapDR_out, strObjCommonIn, carrierID);
    if(rc!= RC_OK)
    {
        PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK ", carrierID.identifier );
        strEqpMonitorLotSTBReqResult.strResult = strCassette_GetWaferMapDR_out.strResult;
        return( rc );
    }

    CORBA::ULong mapLen2 = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();
    PPT_METHODTRACE_V2("","strWaferMapInCassetteInfo.length", mapLen2);

    pptWaferMapInCassetteInfoSequence strWaferMapInCassetteInfoSeq;
    strWaferMapInCassetteInfoSeq.length(mapLen2);
    CORBA::Long waferCount = 0;

    for( i =0; i<mapLen2; i++)
    {
        PPT_METHODTRACE_V2("", "waferID", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier );
        if( 0 < CIMFWStrLen(strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier) )
        {
            strWaferMapInCassetteInfoSeq[waferCount] = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i];
            waferCount++ ;
        }
    }
    strWaferMapInCassetteInfoSeq.length(waferCount);
    PPT_METHODTRACE_V2("", "waferCount", waferCount );

    if( mapLen1 != waferCount )
    {
        //slot map not matched the monitor definiton
        PPT_METHODTRACE_V2("", "waferCount!= mapLen1", waferCount );
        CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotSTBReqResult,
                                CS_MSG_WAFER_SLOTMAP_UNMATCH,
                                CS_RC_WAFER_SLOTMAP_UNMATCH,
                                carrierID.identifier,
                                strMsgkey );
        bValidSTBInfo = FALSE;
    }
    if( bValidSTBInfo )
    {
        PPT_METHODTRACE_V1("", "bValidSTBInfo, continue to check slotmap");
        for( i =0; i<waferCount; i++)
        {
            if( 0 != CIMFWStrCmp(strWaferMapInCassetteInfoSeq[i].waferID.identifier, 
                                 strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq[i].waferID.identifier) )
            {
                PPT_METHODTRACE_V2("", "WaferID not matched", strWaferMapInCassetteInfoSeq[i].waferID.identifier);
                char slotNumber[64];
                sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
                CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotSTBReqResult,
                                        CS_MSG_WAFER_NO_USE_BY_EQPMON,
                                        CS_RC_WAFER_NO_USE_BY_EQPMON,
                                        slotNumber,
                                        strMsgkey );
                bValidSTBInfo = FALSE;
                break;
            }
        }
    }

    //----------------------------------------------
    //  Get EqpMonitor definition info
    //----------------------------------------------
    if( bValidSTBInfo )
    {
        PPT_METHODTRACE_V2("", "npwType", strBWSOutSTB_slotMap_GetDR_out.npwType );
        nSeqLen = 0;
        if( 0 == CIMFWStrCmp(strBWSOutSTB_slotMap_GetDR_out.npwType, CS_EqpMonitor_NPW_Type_Monitor))
        {
            PPT_METHODTRACE_V2("", "call cs_eqpMonitor_info_GetDR()", strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID.identifier );

            objEqpMonitor_info_Get_in strEqpMonitor_info_Get_in;
            strEqpMonitor_info_Get_in.eqpMonitorID = strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID;

            csObjEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
            rc = cs_eqpMonitor_info_GetDR( strEqpMonitor_info_Get_out,
                                      strObjCommonIn,
                                      strEqpMonitor_info_Get_in );

            if ( rc == RC_NOT_FOUND_EQPMONITOR )
            {
                PPT_METHODTRACE_V2("", "not found eqpMonitorID", strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID.identifier );
                strEqpMonitorLotSTBReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
                bValidSTBInfo = FALSE;
            }
            else if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cs_eqpMonitor_info_GetDR() != RC_OK", rc);
                strEqpMonitorLotSTBReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
                return rc;
            }
            else
            {
                PPT_METHODTRACE_V2("", "found eqpMonitorID", strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID.identifier );
                strEqpMonitorSubInfoSeq = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].strEqpMonitorSubInfoSeq;
                nSeqLen = strEqpMonitorSubInfoSeq.length();
            }
        }
        else //Pre-Process, Recycle
        {
            //temporarily create strEqpMonitorSubInfoSeq from strNPWSTB_SlotMapSeq for validity-check purpose
            nSeqLen = strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq.length();
            strEqpMonitorSubInfoSeq.length(nSeqLen);
            for( i =0; i<nSeqLen; i++)
            {
                strEqpMonitorSubInfoSeq[i].slotNumber = strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq[i].slotNumber;
                strEqpMonitorSubInfoSeq[i].productID  = strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq[i].destProductID;
                strEqpMonitorSubInfoSeq[i].castSeqNo  = 1;
                strEqpMonitorSubInfoSeq[i].subRouteID.identifier = CIMFWStrDup("");
                PPT_METHODTRACE_V2("", "slotNumber", strEqpMonitorSubInfoSeq[i].slotNumber);
            }
        }
    }
    PPT_METHODTRACE_V2("", "strEqpMonitorSubInfoSeq.length", nSeqLen );

    //----------------------------------------------
    // wafer qty should matched the request qty by EqpMonitor
    //----------------------------------------------
    if( bValidSTBInfo )
    {
        if( waferCount != nSeqLen )
        {
            //slot map not matched the monitor definiton
            PPT_METHODTRACE_V1("", "waferCount != nSeqLen");
            CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotSTBReqResult,
                                    CS_MSG_WAFER_SLOTMAP_UNMATCH,
                                    CS_RC_WAFER_SLOTMAP_UNMATCH,
                                    carrierID.identifier,
                                    strMsgkey );
            bValidSTBInfo = FALSE;
        }
    }

    //----------------------------------------------
    // lot product should be defined as source
    //----------------------------------------------
    CORBA::String_var strLotType;
    if( bValidSTBInfo )
    {
        PPT_METHODTRACE_V1("", "bValidSTBInfo, continue to check slotmap");
        objectIdentifierSequence sourceProductIDs;
        for( i =0; i<nSeqLen; i++)
        {
            //wafer in slot should have same attribute as what defined in EQPMON_SUB
            PPT_METHODTRACE_V2("", " check slotNumber", strEqpMonitorSubInfoSeq[i].slotNumber);
            if(strWaferMapInCassetteInfoSeq[i].slotNumber != strEqpMonitorSubInfoSeq[i].slotNumber)
            {
                PPT_METHODTRACE_V2("", "slotNumber not matched", strWaferMapInCassetteInfoSeq[i].waferID.identifier);
                char slotNumber[64];
                sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
                CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotSTBReqResult,
                                        CS_MSG_WAFER_NO_USE_BY_EQPMON,
                                        CS_RC_WAFER_NO_USE_BY_EQPMON,
                                        slotNumber,
                                        strMsgkey );
                bValidSTBInfo = FALSE;
                break;
            }

            //----------------------------------------------
            // Get product ID for wafer
            //----------------------------------------------
            objLot_productID_Get_out strLot_productID_Get_out;
            rc = lot_productID_Get( strLot_productID_Get_out,
                                    strObjCommonIn,
                                    strWaferMapInCassetteInfoSeq[i].lotID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","lot_productID_Get != RC_OK", rc );
                strEqpMonitorLotSTBReqResult.strResult = strLot_productID_Get_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "productID", strLot_productID_Get_out.productID.identifier);

            //----------------------------------------------
            // get source product list
            //----------------------------------------------
            PPT_METHODTRACE_V2("", "strProductIDListAttributes for ", strEqpMonitorSubInfoSeq[i].productID.identifier) ;
            if( i == 0 || (0 == CIMFWStrCmp(strBWSOutSTB_slotMap_GetDR_out.npwType, CS_EqpMonitor_NPW_Type_Monitor)) )
            {
                PPT_METHODTRACE_V2("", "strBWSOutSTB_slotMap_GetDR_out.npwType", strBWSOutSTB_slotMap_GetDR_out.npwType) ;

                objProductSpecification_FillInTxPCQ015DR_in__160 strProductSpecification_FillInTxPCQ015DR_in;
                strProductSpecification_FillInTxPCQ015DR_in.strProductIDListInqInParm.productID = strEqpMonitorSubInfoSeq[i].productID.identifier;
                strProductSpecification_FillInTxPCQ015DR_in.strProductIDListInqInParm.productCategory = CS_ProductCategory_NonProduction;

                objProductSpecification_FillInTxPCQ015DR_out strProductSpecification_FillInTxPCQ015DR_out ;
                rc = productSpecification_FillInTxPCQ015DR__160(strProductSpecification_FillInTxPCQ015DR_out, strObjCommonIn, strProductSpecification_FillInTxPCQ015DR_in);

                if( rc != RC_OK && rc != RC_SOMEPRODSP_DATA_ERROR)
                {
                    PPT_METHODTRACE_V2( "","productSpecification_FillInTxPCQ015DR__160 != RC_OK", rc );
                    strEqpMonitorLotSTBReqResult.strResult = strProductSpecification_FillInTxPCQ015DR_out.strResult;
                    return rc;
                }
                CORBA::Long nProdLen = strProductSpecification_FillInTxPCQ015DR_out.strProductIDListAttributes.length();
                PPT_METHODTRACE_V2("", "nProdLen", nProdLen);

                if( nProdLen < 1)
                {
                    //not reachable, just to avoid memory fault
                    PPT_METHODTRACE_V1("", "Error : Lot Product ID is NIL");
                    SET_MSG_RC( strEqpMonitorLotSTBReqResult,
                                MSG_NOT_FOUND_PRODUCTSPEC,
                                RC_NOT_FOUND_PRODUCTSPEC );
                    return RC_NOT_FOUND_PRODUCTSPEC;
                }
                sourceProductIDs = strProductSpecification_FillInTxPCQ015DR_out.strProductIDListAttributes[0].sourceProductID;
                strLotType = strProductSpecification_FillInTxPCQ015DR_out.strProductIDListAttributes[0].lotType.identifier;
            }

            CORBA::Long nSrcProdLen = sourceProductIDs.length();
            PPT_METHODTRACE_V2("", "sourceProductIDs.length", nSrcProdLen);

            //turn off this flag until we find the valid info from the source list
            bValidSTBInfo = FALSE;
            for( j=0; j<nSrcProdLen; j++)
            {
                PPT_METHODTRACE_V2("", "sourceProductIDs[]", sourceProductIDs[j].identifier);
                if ( 0 == CIMFWStrCmp(sourceProductIDs[j].identifier, strLot_productID_Get_out.productID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "source Product match.");
                    bValidSTBInfo = TRUE;
                    break;
                }
            }
            if( !bValidSTBInfo)
            {
                PPT_METHODTRACE_V2("", "Not valid source product", strLot_productID_Get_out.productID.identifier);
                char slotNumber[64];
                sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
                CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotSTBReqResult,
                                        CS_MSG_WAFER_NO_USE_BY_EQPMON,
                                        CS_RC_WAFER_NO_USE_BY_EQPMON,
                                        slotNumber,
                                        strMsgkey );
                break;
            }
        }
    }
    PPT_METHODTRACE_V2("", "strLotType", strLotType);

    //----------------------------------------------
    // STB lots by Sub-Route
    //----------------------------------------------
    if( bValidSTBInfo )
    {
        pptNewLotAttributes strNewLotAttributes;
        strNewLotAttributes.cassetteID = carrierID;

        nSeqLen = strEqpMonitorSubInfoSeq.length();
        strEqpMonitorLotSTBReqResult.lotIDs.length(nSeqLen);
        nLotLen = 0;
        for( i =0; i<nSeqLen; i++)
        {
            PPT_METHODTRACE_V3("", "STB for", strEqpMonitorSubInfoSeq[i].productID.identifier, strEqpMonitorSubInfoSeq[i].subRouteID.identifier );

            if( 0 == strEqpMonitorSubInfoSeq[i].slotNumber )
            {
                PPT_METHODTRACE_V2("", "already checked.", i);
                continue;
            }

            //----------------------------------------------
            // collect wafers for same product and sub-route
            //----------------------------------------------
            strNewLotAttributes.strNewWaferAttributes.length(nSeqLen-i);

            CORBA::Long wfrCount = 1;
            strNewLotAttributes.strNewWaferAttributes[0].newSlotNumber = strWaferMapInCassetteInfoSeq[i].slotNumber;
            strNewLotAttributes.strNewWaferAttributes[0].sourceLotID   = strWaferMapInCassetteInfoSeq[i].lotID;
            strNewLotAttributes.strNewWaferAttributes[0].sourceWaferID = strWaferMapInCassetteInfoSeq[i].waferID;
            //mark colleted flag
            strEqpMonitorSubInfoSeq[i].slotNumber = 0;
            for( j =i+1; j<nSeqLen; j++)
            {
                PPT_METHODTRACE_V3("", "check", strEqpMonitorSubInfoSeq[j].productID.identifier, strEqpMonitorSubInfoSeq[j].subRouteID.identifier );

                if( 0 <  strEqpMonitorSubInfoSeq[j].slotNumber
                 && 0 == CIMFWStrCmp(strEqpMonitorSubInfoSeq[i].productID.identifier, strEqpMonitorSubInfoSeq[j].productID.identifier )
                 && 0 == CIMFWStrCmp(strEqpMonitorSubInfoSeq[i].subRouteID.identifier,strEqpMonitorSubInfoSeq[j].subRouteID.identifier) )
                 {
                    strNewLotAttributes.strNewWaferAttributes[wfrCount].newSlotNumber = strWaferMapInCassetteInfoSeq[j].slotNumber;
                    strNewLotAttributes.strNewWaferAttributes[wfrCount].sourceLotID   = strWaferMapInCassetteInfoSeq[j].lotID;
                    strNewLotAttributes.strNewWaferAttributes[wfrCount].sourceWaferID = strWaferMapInCassetteInfoSeq[j].waferID;
                    //mark colleted flag
                    strEqpMonitorSubInfoSeq[j].slotNumber = 0;
                    wfrCount++;
                 }
            }
            PPT_METHODTRACE_V3("", "collected wafers for sub-route", strEqpMonitorSubInfoSeq[i].subRouteID.identifier, wfrCount);
            strNewLotAttributes.strNewWaferAttributes.length(wfrCount);
            PPT_METHODTRACE_V3("", "txCtrlLotSTBReq for", strEqpMonitorSubInfoSeq[i].productID.identifier, wfrCount);

            //---------------------------------------------
            // contrl lot STB for selected wafers
            //---------------------------------------------
            pptCtrlLotSTBReqResult strCtrlLotSTBReqResult;
            rc = txCtrlLotSTBReq(strCtrlLotSTBReqResult, 
                                 strObjCommonIn, 
                                 strEqpMonitorSubInfoSeq[i].productID,
                                 wfrCount,
                                 strLotType, //lotType
                                 strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq[i].subLotType,
                                 strNewLotAttributes,
                                 claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","txCtrlLotSTBReq != RC_OK", rc );
                strEqpMonitorLotSTBReqResult.strResult = strCtrlLotSTBReqResult.strResult;
                strEqpMonitorLotSTBReqResult.lotIDs.length(0);
                return rc;
            }

            //---------------------------------------------
            // Get all sub route info for this lot
            //---------------------------------------------
            PPT_METHODTRACE_V2("", "controlLotID", strCtrlLotSTBReqResult.controlLotID.identifier);
            strEqpMonitorLotSTBReqResult.lotIDs[nLotLen] = strCtrlLotSTBReqResult.controlLotID;
            nLotLen++;
        }
        strEqpMonitorLotSTBReqResult.lotIDs.length(nLotLen);
    }
    else
    {
        PPT_METHODTRACE_V1("", "not ValidSTBInfo");

        char     messageText[2048];
        char     m1[] = "<<< STB for BWS Out wafers failed. >>>";
        char     m2[] = "\n    BWS ID       : ";
        char     m3[] = "\n    Carrier ID   : ";
        char     m5[] = "\n    Error Message: ";

        if( 0 == CIMFWStrCmp(strBWSOutSTB_slotMap_GetDR_out.npwType, CS_EqpMonitor_NPW_Type_Monitor) )
        {
            char     m4[] = "\n    EqpMonitor ID: ";
            sprintf( messageText, "%s%s%s%s%s%s%s%s%s",
                     m1,
                     m2, (const char *)strEqpMonitorLotSTBReqInParm.BWSID.identifier,
                     m3, (const char *)carrierID.identifier,
                     m4, (const char *)strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID.identifier,
                     m5, (const char *)strEqpMonitorLotSTBReqResult.strResult.messageText );
        }
        else
        {
            char     m4[] = "\n    Product ID   : ";
            sprintf( messageText, "%s%s%s%s%s%s%s%s%s",
                     m1,
                     m2, (const char *)strEqpMonitorLotSTBReqInParm.BWSID.identifier,
                     m3, (const char *)carrierID.identifier,
                     m4, (const char *)strMsgkey,
                     m5, (const char *)strEqpMonitorLotSTBReqResult.strResult.messageText );
        }

        /*-------------------------*/
        /*   Call System Message   */
        /*-------------------------*/
        pptSystemMsgRptResult strSystemMsgRptResult;
        objectIdentifier dummy;

        rc = txSystemMsgRpt( strSystemMsgRptResult,
                             strObjCommonIn,
                             SP_SubSystemID_MM,
                             SP_MessageID_MonitorFail,
                             messageText,
                             TRUE,
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             dummy,
                             "",
                             strObjCommonIn.strTimeStamp.reportTimeStamp,
                             "" );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
            strEqpMonitorLotSTBReqResult.strResult = strSystemMsgRptResult.strResult ;
            return( rc );
        }
    }

    //----------------------------------------------
    // Set monitor PrepareID for all lots
    //----------------------------------------------
    if( bValidSTBInfo && (0 == CIMFWStrCmp(strBWSOutSTB_slotMap_GetDR_out.npwType, CS_EqpMonitor_NPW_Type_Monitor)) )
    {
        PPT_METHODTRACE_V1("", "call cs_eqpMonitorLot_prepareIDSet");

        csObjEqpMonitorLot_prepareIDSet_in strEqpMonitorLot_prepareIDSet_in;
        strEqpMonitorLot_prepareIDSet_in.eqpMonitorID = strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID;
        strEqpMonitorLot_prepareIDSet_in.carrierID    = carrierID;
        strEqpMonitorLot_prepareIDSet_in.lotIDs       = strEqpMonitorLotSTBReqResult.lotIDs;

        csObjEqpMonitorLot_prepareIDSet_out strEqpMonitorLot_prepareIDSet_out;
        rc = cs_eqpMonitorLot_prepareIDSet( strEqpMonitorLot_prepareIDSet_out,
                                     strObjCommonIn,
                                     strEqpMonitorLot_prepareIDSet_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_EqpMonitorLot_prepareIDSet != RC_OK", rc);
            strEqpMonitorLotSTBReqResult.strResult = strEqpMonitorLot_prepareIDSet_out.strResult;
            return( rc );
        }
    }

    //----------------------------------
    // delete BWSOut slotMap for carrier
    //----------------------------------
    csObjBWSOutSTB_slotMap_DeleteDR_in strBWSOutSTB_slotMap_DeleteDR_in;
    strBWSOutSTB_slotMap_DeleteDR_in.carrierID = carrierID;

    csObjBWSOutSTB_slotMap_DeleteDR_out strBWSOutSTB_slotMap_DeleteDR_out;
    rc = cs_BWSOutSTB_slotMap_DeleteDR(strBWSOutSTB_slotMap_DeleteDR_out, strObjCommonIn, strBWSOutSTB_slotMap_DeleteDR_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","cs_BWSOutSTB_slotMap_DeleteDR() rc != RC_OK", rc);
        strEqpMonitorLotSTBReqResult.strResult = strBWSOutSTB_slotMap_DeleteDR_out.strResult;
        return(rc);
    }

    //---------------------------
    //  Set out structure
    //---------------------------
    SET_MSG_RC(strEqpMonitorLotSTBReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorLotSTBReq")
    return( RC_OK );

}