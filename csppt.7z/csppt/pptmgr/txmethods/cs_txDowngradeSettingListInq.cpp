//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txDowngradeSettingListInq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txDowngradeSettingListInq()
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/24 INN-R170016  Yangxiaojun    Equipment Monitor customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csDowngradeSettingListInqResult& strDowngradeSettingListInqResult
//     const pptObjCommonIn& strObjCommonIn
//
//  typedef  struct csDowngradeSettingListInqInParm_struct{
//      string            productID;
//      any               siInfo;
//  }csDowngradeSettingListInqInParm;
//
//  typedef  struct csDowngradeSettingListInqResult_struct{
//    pptRetCode                     strResult;
//    csDowngradeSettingInfoSequence strDowngradeSettingInfoSeq;
//    any                   siInfo;
//  }csDowngradeSettingListInqResult;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txDowngradeSettingListInq(csDowngradeSettingListInqResult& strDowngradeSettingListInqResult,
                                                        const pptObjCommonIn& strObjCommonIn,
                                                        const csDowngradeSettingListInqInParm& strDowngradeSettingListInqInParm
                                                        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txDowngradeSettingListInq")
    CORBA::Long rc = RC_OK ;

    //---------------------------------------------
    // Get downgrade items from CSFSNPWDCDEF_ITEM
    //---------------------------------------------
    csObjDowngradeSettingList_GetDR_in strDowngradeSettingList_GetDR_in;
    strDowngradeSettingList_GetDR_in.productID = strDowngradeSettingListInqInParm.productID;

    csObjDowngradeSettingList_GetDR_out strDowngradeSettingList_GetDR_out;
    rc = cs_downgradeSettingList_GetDR( strDowngradeSettingList_GetDR_out,
                               strObjCommonIn,
                               strDowngradeSettingList_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_downgradeSettingList_GetDR() != RC_OK", rc);
        strDowngradeSettingListInqResult.strResult = strDowngradeSettingList_GetDR_out.strResult;
        return rc;
    }
    strDowngradeSettingListInqResult.strDowngradeSettingInfoSeq = strDowngradeSettingList_GetDR_out.strDowngradeSettingInfoSeq;

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    SET_MSG_RC(strDowngradeSettingListInqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txDowngradeSettingListInq")
    return( RC_OK );
}
