#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/txChamberProcessWaferRpt.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/23/07 16:01:23 [ 7/23/07 16:01:25 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txChamberProcessWaferRptOR.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "pwafer.hh"
#include "pmaloc.hh"
#include "plotfm.hh"
#include "pperson.hh"
// Class: PPTManager
//
// Service: txChamberProcessWaferRpt()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------------------------------------
// 2003/04/14 D5000056 M.Kase         Initial release(R50) for Multiple Chamber Process Wafer Level Tracking.
// 2003/08/20 D5000192 M.Kase         Add error handling logic for actionCode
// 2003/11/10 P5100008 M.Kase         Add to get waferCount and chamberCount again
// 2003/11/10 P5100029 M.Kase         Change the location of waferChamberProcessEvent_Make logic.
// 2004/04/14 P5100246 M.Kase         Change logic for checking wafer's lotID.
// 2004/04/19 D5100088 M.Kase         Add logic for setting wafer-chamber information
//                                    Set chamber's information to set wafer-chamber information
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2007/07/23 P9000034 H.Hotta        Add check logic for ActionCode.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------------------
// 2011/10/28 DSN000015229 M.Ogawa        Advanced Wafer Level Control
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2017/02/10 DSN000104277 K.Yamaoku      Performance improvement(reference:lot_wafers_GetDR)
//
// Innotron Modification history :
// Date       Defect#         Person               Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/23 INN-R170009  Gary Ke        INN-R170009: Call cs_lot_PhotoLayer_Get
//
// Description:
//
// Return:
//    long
//
// Parameter:
//    pptChamberProcessWaferRptResult&           strChamberProcessWaferRptResult
//    const pptObjCommonIn&                      strObjCommonIn
//    const objectIdentifier&                    equipmentID
//    const objectIdentifier&                    controlJobID
//    const pptChamberProcessLotInfoSequence&    strChamberProcessLotInfos
//    const char *                               claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txChamberProcessWaferRpt( pptChamberProcessWaferRptResult&         strChamberProcessWaferRptResult,
                                                    const pptObjCommonIn&                    strObjCommonIn,
                                                    const objectIdentifier&                  equipmentID,
                                                    const objectIdentifier&                  controlJobID,
                                                    const pptChamberProcessLotInfoSequence&  strChamberProcessLotInfos,
//D6000025                                                     const char *                             claimMemo,
//D6000025                                                     CORBA::Environment                       &IT_env )
                                                    const char *                             claimMemo //D6000025
                                                    CORBAENV_LAST_CPP )                                //D6000025
{
    /*-----------------*/
    /*   Initialize    */
    /*-----------------*/
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txChamberProcessWaferRpt");
    SET_MSG_RC( strChamberProcessWaferRptResult, MSG_OK, RC_OK );
    CORBA::Long rc = RC_OK;
    CORBA::Long i, j, k;
    pptChamberProcessLotInfoSequence tmpStrChamberProcessLotInfos;    //D5100088
    tmpStrChamberProcessLotInfos = strChamberProcessLotInfos;         //D5100088

    /*-----------------------------------------------------------------------------*/
    /*   Get Inprocessing Lots information with using equipmentID.                 */
    /*   Check controlJob of in-parameter is in-processing with equipment or not   */
    /*-----------------------------------------------------------------------------*/
    objEquipment_inprocessingControlJobInfo_Get_out strEquipemt_inprocessingControlJobInfo_Get_out;
    rc = equipment_inprocessingControlJobInfo_Get( strEquipemt_inprocessingControlJobInfo_Get_out,
                                                   strObjCommonIn,
                                                   equipmentID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_inprocessingControlJobInfo_Get() != RC_OK");
        strChamberProcessWaferRptResult.strResult = strEquipemt_inprocessingControlJobInfo_Get_out.strResult;
        return( rc );
    }

    CORBA::Boolean found_flag = FALSE;
    CORBA::Long nLen = strEquipemt_inprocessingControlJobInfo_Get_out.strEqpInprocessingControlJobInfo.strEqpInprocessingControlJob.length();

    PPT_METHODTRACE_V2("", "controlJobID.identifier = ", controlJobID.identifier);
    for ( CORBA::Long n=0; n<nLen; n++ )
    {
        PPT_METHODTRACE_V2("", "strEqpInprocessingControlJob[n].controlJobID.identifier = ", strEquipemt_inprocessingControlJobInfo_Get_out.strEqpInprocessingControlJobInfo.strEqpInprocessingControlJob[n].controlJobID.identifier);
        if ( CIMFWStrCmp(strEquipemt_inprocessingControlJobInfo_Get_out.strEqpInprocessingControlJobInfo.strEqpInprocessingControlJob[n].controlJobID.identifier,
                         controlJobID.identifier) == 0 )
        {
            found_flag = TRUE;
            break;
        }
    }

    if ( found_flag == FALSE )
    {
//DSN000015229 Add Start
        CORBA::Boolean SLMCapabilityFlag = FALSE;
        /*--------------------------------------*/
        /*   Get SLM Switch for the equipment   */
        /*--------------------------------------*/
        objEquipment_brInfo_GetDR_out__120 strEquipment_brInfo_GetDR_out;
        objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
        strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
        rc = equipment_brInfo_GetDR__120( strEquipment_brInfo_GetDR_out,
                                          strObjCommonIn,
                                          strEquipment_brInfo_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR__120() != RC_OK", rc);
            strChamberProcessWaferRptResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
            return rc;
        }

        // Check SLM Capability
        if( strEquipment_brInfo_GetDR_out.equipmentBRInfo.SLMCapabilityFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", "SLM Capability is TRUE. ");
            SLMCapabilityFlag = TRUE;
        }

        if ( TRUE == SLMCapabilityFlag )
        {
            // CJ isn't found in equipment CJs and the equipment is SLM type
            // This means ChamberProcesWaferRpt is reported after PartialOpeComp
            // -> Normal end
            PPT_METHODTRACE_V1("", "SLMCapabilityFlag == TRUE" );
            SET_MSG_RC( strChamberProcessWaferRptResult, MSG_OK, RC_OK );
            return( RC_OK );
        }
        else
        {
//DSN000015229 Add End
//DSN000015229 Indent Start
            SET_MSG_RC( strChamberProcessWaferRptResult, MSG_LOT_PORT_CTRLJOB_UNMATCH, RC_LOT_PORT_CTRLJOB_UNMATCH );
            return( RC_LOT_PORT_CTRLJOB_UNMATCH );
//DSN000015229 Indent End
        }       //DSN000015229
    }

    /*-----------------------------------------------------*/
    /*   Check In-parm's Lot and Wafer and Chamber Count   */
    /*-----------------------------------------------------*/
    CORBA::Long lotCount=0, waferCount=0, chamberCount=0;
    lotCount = strChamberProcessLotInfos.length();
    PPT_METHODTRACE_V2("", "LotCount     = ", lotCount);

    if ( lotCount == 0 )
    {
        SET_MSG_RC( strChamberProcessWaferRptResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return( RC_INVALID_INPUT_PARM );
    }

    for ( i=0; i<lotCount; i++ )
    {
        waferCount = strChamberProcessLotInfos[i].strChamberProcessWaferInfos.length();
        PPT_METHODTRACE_V2("", "WaferCount   = ", waferCount);

        if ( waferCount == 0 )
        {
            SET_MSG_RC( strChamberProcessWaferRptResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return( RC_INVALID_INPUT_PARM );
        }

        for ( j=0; j<waferCount; j++ )
        {
            chamberCount = strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos.length();
            PPT_METHODTRACE_V2("", "ChamberCount = ", chamberCount);

            if ( chamberCount == 0 )
            {
                SET_MSG_RC( strChamberProcessWaferRptResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
                return( RC_INVALID_INPUT_PARM );
            }
        }
    }

//D5000192 add start
    /*---------------------------------*/
    /*   Check In-parm's Action Code   */
    /*---------------------------------*/
    PPT_METHODTRACE_V2("", "ActionCode = ", strChamberProcessLotInfos[0].actionCode);

    if ( CIMFWStrCmp(strChamberProcessLotInfos[0].actionCode, SP_ChamberProcActionCode_ProcessStart) != 0 &&
         CIMFWStrCmp(strChamberProcessLotInfos[0].actionCode, SP_ChamberProcActionCode_ProcessEnd) != 0 )
    {
        PPT_SET_MSG_RC_KEY( strChamberProcessWaferRptResult,
                            MSG_NOT_VALID_ACT,
                            RC_NOT_VALID_ACT,
                            strChamberProcessLotInfos[0].actionCode );
        return( RC_NOT_VALID_ACT );
    }
//D5000192 add end

//P9000034 add start
    for( i = 0; i < lotCount; i++ )
    {
        PPT_METHODTRACE_V3("", "actionCode ", i, strChamberProcessLotInfos[i].actionCode);

        if( 0 == i )
        {
            continue;
        }

        if( 0 != CIMFWStrCmp( strChamberProcessLotInfos[i].actionCode, strChamberProcessLotInfos[0].actionCode ) )
        {
            PPT_METHODTRACE_V1("", "ActionCode of all Lots are not the same.");
            SET_MSG_RC( strChamberProcessWaferRptResult, MSG_ACTION_CODE_NOT_SAME, RC_ACTION_CODE_NOT_SAME );
            return( RC_ACTION_CODE_NOT_SAME );
        }
    }
//P9000034 add end

    /*-------------------------------*/
    /*   Get Equipment's ChamberID   */
    /*-------------------------------*/
    objEquipment_chamberInfo_GetDR_out strEquipment_chamberInfo_GetDR_out;
    rc = equipment_chamberInfo_GetDR( strEquipment_chamberInfo_GetDR_out,
                                      strObjCommonIn,
                                      equipmentID );
    if ( rc != RC_OK ) 
    {
        PPT_METHODTRACE_V1("", "equipment_inprocessingControlJobInfo_Get() != RC_OK");
        strChamberProcessWaferRptResult.strResult = strEquipment_chamberInfo_GetDR_out.strResult;
        return( rc );
    }

    nLen = strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus.length();

    /*-----------------------------------------------*/
    /*   Check Lot's ProcessState and ControlJobID   */
    /*-----------------------------------------------*/
    for ( i=0; i<lotCount; i++ )
    {
        PPT_METHODTRACE_V2("", "strChamberProcessLotInfos[i].lotID.identifier = ", strChamberProcessLotInfos[i].lotID.identifier);
        /*----------------------------*/
        /*   Get Lot's ProcessState   */
        /*----------------------------*/
        objLot_processState_Get_out strLot_processState_Get_out;
        rc = lot_processState_Get( strLot_processState_Get_out,
                                   strObjCommonIn,
                                   strChamberProcessLotInfos[i].lotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_processState_Get() != RC_OK");
            strChamberProcessWaferRptResult.strResult = strLot_processState_Get_out.strResult;
            return( rc );
        }

        if ( CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) != 0 )
        {
            PPT_SET_MSG_RC_KEY2( strChamberProcessWaferRptResult,
                                 MSG_INVALID_LOT_PROCSTAT,
                                 RC_INVALID_LOT_PROCSTAT,
                                 strChamberProcessLotInfos[i].lotID.identifier,
                                 strLot_processState_Get_out.theLotProcessState );
            return( RC_INVALID_LOT_PROCSTAT );
        }

        /*----------------------------*/
        /*   Get Lot's ControlJobID   */
        /*----------------------------*/
        objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
        rc = lot_controlJobID_Get( strLot_controlJobID_Get_out,
                                   strObjCommonIn,
                                   strChamberProcessLotInfos[i].lotID );
        if ( rc != RC_OK ) 
        {
            PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
            strChamberProcessWaferRptResult.strResult = strLot_controlJobID_Get_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2("", "strLot_controlJobID_Get_out.controlJobID.identifier = ", strLot_controlJobID_Get_out.controlJobID.identifier);
        PPT_METHODTRACE_V2("", "controlJobID.identifier = ", controlJobID.identifier);
        if ( CIMFWStrCmp(strLot_controlJobID_Get_out.controlJobID.identifier, controlJobID.identifier) != 0 )
        {
            PPT_SET_MSG_RC_KEY2( strChamberProcessWaferRptResult,
                                 MSG_CTRLJOB_LOT_UNMATCH,
                                 RC_CTRLJOB_LOT_UNMATCH,
                                 controlJobID.identifier,
                                 strChamberProcessLotInfos[i].lotID.identifier );
            return( RC_CTRLJOB_LOT_UNMATCH );
        }

//INN-R170009 Add Start
        /*--------------------------------*/
        /*   Call cs_lot_PhotoLayer_Get   */
        /*--------------------------------*/
        CORBA::Boolean previousPOFlag = FALSE;
        csObjLot_PhotoLayer_Get_out strLot_PhotoLayer_Get_out;
        csObjLot_PhotoLayer_Get_in  strLot_PhotoLayer_Get_in;
        strLot_PhotoLayer_Get_in.lotID          = strChamberProcessLotInfos[i].lotID;
        strLot_PhotoLayer_Get_in.previousPOFlag = previousPOFlag;
        rc = cs_lot_PhotoLayer_Get( strLot_PhotoLayer_Get_out,
                                    strObjCommonIn,
                                    strLot_PhotoLayer_Get_in);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cs_lot_PhotoLayer_Get rc != RC_OK");
            strChamberProcessWaferRptResult.strResult = strLot_PhotoLayer_Get_out.strResult;
            return rc;
        }
        /*------------------------------*/
        /*    Get photolayer UserData   */
        /*------------------------------*/ 
        pptUserDataInqInParm__101  strUserDataInqInParm;
        objObject_UserData_Get_out strObject_UserData_Get_out;
        objObject_Get_out strObject_Get_out;
        objObject_Get_in  strObject_Get_in;
        if( CIMFWStrLen(strLot_PhotoLayer_Get_out.photoLayer) > 0 ) 
        { 
            PPT_METHODTRACE_V2("", "strLot_PhotoLayer_Get_out.photoLayer", strLot_PhotoLayer_Get_out.photoLayer);
            
            strUserDataInqInParm.className = CIMFWStrDup(SP_ClassName_PosCode);
            strUserDataInqInParm.strHashedInfoSeq.length(2);
            strUserDataInqInParm.strHashedInfoSeq[0].hashKey  = CIMFWStrDup(SP_HashData_CODE_ID);
            strUserDataInqInParm.strHashedInfoSeq[0].hashData = strLot_PhotoLayer_Get_out.photoLayer;
            strUserDataInqInParm.strHashedInfoSeq[1].hashKey  = CIMFWStrDup(SP_HashData_CATEGORY_ID);
            strUserDataInqInParm.strHashedInfoSeq[1].hashData = CIMFWStrDup(SP_CATEGORY_PHOTOLAYER);
            strUserDataInqInParm.userDataName = CIMFWStrDup(CS_S_PHOTO_FIRST_LAYER);
            strUserDataInqInParm.userDataOriginator = CIMFWStrDup(SP_USERDATA_ORIG_SM);
            
            strObject_Get_in.className = strUserDataInqInParm.className;
            strObject_Get_in.strHashedInfoSeq = strUserDataInqInParm.strHashedInfoSeq;
            
            rc = object_Get(strObject_Get_out, strObjCommonIn, strObject_Get_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "object_Get() rc != RC_OK");
                strChamberProcessWaferRptResult.strResult = strObject_Get_out.strResult;
                return rc;
            }
            // get uData
            
            rc = object_userData_Get__101( strObject_UserData_Get_out,
                                           strObjCommonIn,
                                           strUserDataInqInParm,
                                           strObject_Get_out.stringifiedObjectReference);
            
            if (rc != RC_OK && rc != RC_NOT_FOUND_UDATA)
            {
                PPT_METHODTRACE_V1("", "object_userData_Get() rc != RC_OK");
                strChamberProcessWaferRptResult.strResult = strObject_UserData_Get_out.strResult;
                return rc;
            }
            if(strObject_UserData_Get_out.strUserDataSeq.length() > 0 )
            {
                PPT_METHODTRACE_V1("", "Find PL UserData");
                PPT_METHODTRACE_V2("", "strObject_UserData_Get_out.strUserDataSeq.length()",strObject_UserData_Get_out.strUserDataSeq.length());
                PPT_METHODTRACE_V2("", "name",  strObject_UserData_Get_out.strUserDataSeq[0].name);
                PPT_METHODTRACE_V2("", "value", strObject_UserData_Get_out.strUserDataSeq[0].value);
            }
        }
//INN-R170009 Add End
        
//P5100246 add start
        /*-----------------------*/
        /*   Get Lot's WaferID   */
        /*-----------------------*/
//DSN000085698        objLot_wafers_GetDR_out strLot_wafers_GetDR_out;
//DSN000104277        objLot_wafers_GetDR_out__150 strLot_wafers_GetDR_out;   //DSN000085698
//DSN000104277        objLot_wafers_GetDR_in  strInParm;
//DSN000104277        strInParm.lotID          = strChamberProcessLotInfos[i].lotID;
//DSN000104277        strInParm.scrapCheckFlag = TRUE;
//DSN000104277//DSN000085698        rc = lot_wafers_GetDR( strLot_wafers_GetDR_out,
//DSN000104277        rc = lot_wafers_GetDR__150( strLot_wafers_GetDR_out,     //DSN000085698
//DSN000104277                               strObjCommonIn,
//DSN000104277                               strInParm );
//DSN000104277        if ( rc != RC_OK ) 
//DSN000104277        {
//DSN000104277//DSN000085698            PPT_METHODTRACE_V1("", "lot_wafers_GetDR() != RC_OK");
//DSN000104277            PPT_METHODTRACE_V1("", "lot_wafers_GetDR__150() != RC_OK");     //DSN000085698
//DSN000104277            strChamberProcessWaferRptResult.strResult = strLot_wafers_GetDR_out.strResult;
//DSN000104277            return( rc );
//DSN000104277        }
//DSN000104277 add start
        objLot_waferIDList_GetDR_out strLot_waferIDList_GetDR_out;
        objLot_waferIDList_GetDR_in  strLot_waferIDList_GetDR_in;
        strLot_waferIDList_GetDR_in.lotID          = strChamberProcessLotInfos[i].lotID;
        strLot_waferIDList_GetDR_in.scrapCheckFlag = TRUE;
        rc = lot_waferIDList_GetDR( strLot_waferIDList_GetDR_out, strObjCommonIn, strLot_waferIDList_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### lot_waferIDList_GetDR() != RC_OK", rc);
            strChamberProcessWaferRptResult.strResult = strLot_waferIDList_GetDR_out.strResult;
            return( rc );
        }
//DSN000104277 add end

//DSN000104277        CORBA::Long waferLen = strLot_wafers_GetDR_out.strLotWaferAttributes.length();
        CORBA::Long waferLen = strLot_waferIDList_GetDR_out.waferIDs.length(); //DSN000104277
//P5100246 add end

        /*-------------------------*/
        /*   Check Wafer's LotID   */
        /*-------------------------*/
        waferCount = strChamberProcessLotInfos[i].strChamberProcessWaferInfos.length();    //P5100008
        for ( j=0; j<waferCount; j++ )
        {
            PPT_METHODTRACE_V2("", "strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID.identifier = ", strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID.identifier);
//P5100246            /*-----------------------*/
//P5100246            /*   Get Wafer's LotID   */
//P5100246            /*-----------------------*/
//P5100246            objWafer_lot_Get_out strWafer_lot_Get_out;
//P5100246            rc = wafer_lot_Get( strWafer_lot_Get_out,
//P5100246                                strObjCommonIn,
//P5100246                                strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID );
//P5100246            if ( rc != RC_OK ) 
//P5100246            {
//P5100246                PPT_METHODTRACE_V1("", "wafer_lot_Get() != RC_OK");
//P5100246                strChamberProcessWaferRptResult.strResult = strWafer_lot_Get_out.strResult;
//P5100246                return( rc );
//P5100246            }
//P5100246
//P5100246            PPT_METHODTRACE_V2("", "strWafer_lot_Get_out.lotID.identifier = ", strWafer_lot_Get_out.lotID.identifier);
//P5100246            PPT_METHODTRACE_V2("", "strChamberProcessLotInfos[i].lotID.identifier = ", strChamberProcessLotInfos[i].lotID.identifier);
//P5100246            if ( CIMFWStrCmp(strWafer_lot_Get_out.lotID.identifier, strChamberProcessLotInfos[i].lotID.identifier) != 0 )
//P5100246            {
//P5100246                PPT_SET_MSG_RC_KEY2( strChamberProcessWaferRptResult,
//P5100246                                     MSG_LOT_WAFER_UNMATCH,
//P5100246                                     RC_LOT_WAFER_UNMATCH,
//P5100246                                     strChamberProcessLotInfos[i].lotID.identifier,
//P5100246                                     strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID.identifier );
//P5100246                return( RC_LOT_WAFER_UNMATCH );
//P5100246            }
//P5100246 add start
            CORBA::Boolean found_wafer_flag = FALSE;
            for ( CORBA::Long n=0; n<waferLen; n++ )
            {
//DSN000104277                PPT_METHODTRACE_V2("", "strLot_wafers_GetDR_out.strLotWaferAttributes[n].waferID.identifier = ", strLot_wafers_GetDR_out.strLotWaferAttributes[n].waferID.identifier);
//DSN000104277                if ( CIMFWStrCmp(strLot_wafers_GetDR_out.strLotWaferAttributes[n].waferID.identifier,
                PPT_METHODTRACE_V2("", "strLot_waferIDList_GetDR_out.waferIDs[n].identifier = ", strLot_waferIDList_GetDR_out.waferIDs[n].identifier); //DSN000104277
                if ( CIMFWStrCmp(strLot_waferIDList_GetDR_out.waferIDs[n].identifier,                                                                  //DSN000104277
                                 strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID.identifier) == 0 )
                {
                    found_wafer_flag = TRUE;
                    break;
                }
            }

            if ( found_wafer_flag == FALSE )
            {
                PPT_SET_MSG_RC_KEY2( strChamberProcessWaferRptResult,
                                     MSG_LOT_WAFER_UNMATCH,
                                     RC_LOT_WAFER_UNMATCH,
                                     strChamberProcessLotInfos[i].lotID.identifier,
                                     strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID.identifier );
                return( RC_LOT_WAFER_UNMATCH );
            }
//P5100246 add end

            /*---------------------------------*/
            /*   Check Equipment's ChamberID   */
            /*---------------------------------*/
            chamberCount = strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos.length();    //P5100008
            for ( k=0; k<chamberCount; k++ )
            {
                found_flag = FALSE;

                PPT_METHODTRACE_V2("", "strProcessedChamberInfos[k].chamberID.identifier = ", strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos[k].chamberID.identifier);
                for ( n=0; n<nLen; n++ )
                {
                    PPT_METHODTRACE_V2("", "strEqpChamberStatus[n].chamberID.identifier = ", strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus[n].chamberID.identifier);
                    if ( CIMFWStrCmp(strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus[n].chamberID.identifier,
                                     strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos[k].chamberID.identifier) == 0 )
                    {
                        tmpStrChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos[k].chamberID
                            = strEquipment_chamberInfo_GetDR_out.equipmentChamberInfo.strEqpChamberStatus[n].chamberID;    //D5100088
                        found_flag = TRUE;
                        break;
                    }
                }

                if ( found_flag == FALSE )
                {
                    PPT_SET_MSG_RC_KEY2( strChamberProcessWaferRptResult,
                                         MSG_NOT_FOUND_REQ_CHAMBER,
                                         RC_NOT_FOUND_REQ_CHAMBER,
                                         strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos[k].chamberID.identifier,
                                         equipmentID.identifier );
                    return( RC_NOT_FOUND_REQ_CHAMBER );
                }
//INN-R170009 Add Start
                /*----------------------------------------------------*/
                /*   Get UserData CS_M_WAFER_FIRST_LITHO_USED_CHUCK   */
                /*----------------------------------------------------*/
				if ( CIMFWStrLen(strObject_UserData_Get_out.strUserDataSeq[0].value) > 0 )
                {
                    if ( CIMFWStrCmp(strChamberProcessLotInfos[i].actionCode, SP_ChamberProcActionCode_ProcessEnd) == 0 && CIMFWStrCmp(strObject_UserData_Get_out.strUserDataSeq[0].value, "Yes") == 0)
                    {
                       
                        pptUserDataInqInParm__101  strUserDataInqInParm1;
                        strUserDataInqInParm1.strHashedInfoSeq.length(1);
                        
                        strUserDataInqInParm1.className                    = CIMFWStrDup(SP_ClassName_PosWafer);
                        strUserDataInqInParm1.strHashedInfoSeq[0].hashKey  = CIMFWStrDup(SP_HashData_WAFER_ID);
                        strUserDataInqInParm1.strHashedInfoSeq[0].hashData = strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].waferID.identifier;
                        strUserDataInqInParm1.userDataName = CIMFWStrDup(CS_M_WFR_FIRST_LITHO_USED_CHUCK);
                        strUserDataInqInParm1.userDataOriginator = CIMFWStrDup(SP_USERDATA_ORIG_MM);
                        
                        objObject_Get_out strobjObject_Get_out1;
                        objObject_Get_in strobjObject_Get_in1;
                       
                        strobjObject_Get_in1.className        = strUserDataInqInParm1.className;
                        strobjObject_Get_in1.strHashedInfoSeq = strUserDataInqInParm1.strHashedInfoSeq;
                        
                        rc = object_Get(strobjObject_Get_out1, strObjCommonIn, strobjObject_Get_in1);
                        if (rc != RC_OK)
                        {
                            PPT_METHODTRACE_V1("", "object_Get() rc != RC_OK");
                            strChamberProcessWaferRptResult.strResult = strobjObject_Get_out1.strResult;
                            return rc;
                        }
                        // Call object_userData_Get__101 to get uData
                        objObject_UserData_Get_out strObject_UserData_Get_out1;
                        rc = object_userData_Get__101( strObject_UserData_Get_out1,
                                                       strObjCommonIn,
                                                       strUserDataInqInParm1,
                                                       strobjObject_Get_out1.stringifiedObjectReference);
                        
                        if (rc != RC_OK && rc != RC_NOT_FOUND_UDATA)
                        {
                            PPT_METHODTRACE_V1("", "object_userData_Get() rc != RC_OK");
                            strChamberProcessWaferRptResult.strResult = strObject_UserData_Get_out1.strResult;
                            return rc;
                        }
                        if(strObject_UserData_Get_out1.strUserDataSeq.length() > 0 )
                        {
                            PPT_METHODTRACE_V1("", "Find CS_M_WFR_FIRST_LITHO_USED_CHUCK");
                            PPT_METHODTRACE_V2("", "strObject_UserData_Get_out1.strUserDataSeq.length()",strObject_UserData_Get_out1.strUserDataSeq.length());
                            PPT_METHODTRACE_V2("", "name",  strObject_UserData_Get_out1.strUserDataSeq[0].name);
                            PPT_METHODTRACE_V2("", "value", strObject_UserData_Get_out1.strUserDataSeq[0].value);
                        }
                    
                        
                        if ( CIMFWStrLen(strObject_UserData_Get_out1.strUserDataSeq[0].value)==0 )
                        {
                            PPT_METHODTRACE_V1("", "CIMFWStrLen(strObject_UserData_Get_out1.strUserDataSeq[0].value)==0");
                            if ( CIMFWStrnCmp(strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos[k].chamberID.identifier,
                                 CS_CHAMBER_CHUCK, 5)==0 )
                            {
                                PPT_METHODTRACE_V1("", "CIMFWStrnCmp(chamberID, CS_CHAMBER_CHUCK, 5) == 0");
                                /*-----------------------*/
                                /*   Make CHUCK String   */
                                /*-----------------------*/
                                char FirstLithoUsedChuck[512]; 
                                memset( FirstLithoUsedChuck, '\0', sizeof(FirstLithoUsedChuck) );
                                CIMFWStrCpy(FirstLithoUsedChuck, strChamberProcessLotInfos[i].strChamberProcessWaferInfos[j].strProcessedChamberInfos[k].chamberID.identifier);
                                char *Chuckptr = NULL;
                                Chuckptr = &FirstLithoUsedChuck[5];
                                CORBA::Long ChuckstrLen = CIMFWStrLen(Chuckptr);
                                char usedchuck[512];
                                memset( usedchuck, '\0', sizeof(usedchuck) );
                                CIMFWStrnCpy(usedchuck, Chuckptr, ChuckstrLen);
                                PPT_METHODTRACE_V2("", "FirstLithoUsedChuck", FirstLithoUsedChuck);
                                PPT_METHODTRACE_V2("", "ChuckstrLen",         ChuckstrLen);
                                PPT_METHODTRACE_V2("", "usedchuck",           usedchuck);
                                /*------------------*/
                                /*   Set UserData   */
                                /*------------------*/
                                pptUserData strUserData;                            
                                strUserData.name       = CIMFWStrDup( CS_M_WFR_FIRST_LITHO_USED_CHUCK );
                                strUserData.type       = CIMFWStrDup( CS_UDATA_TYPE_STRING );
                                strUserData.value      = CIMFWStrDup( usedchuck );
                                strUserData.originator = CIMFWStrDup( SP_USERDATA_ORIG_MM );
                    
                                //Call object_userData_Set to set uData
                                objObject_UserData_Set_out strObject_UserData_Set_out;
                                rc = object_userData_Set( strObject_UserData_Set_out,
                                                          strObjCommonIn,
                                                          strUserData,
                                                          strobjObject_Get_out1.stringifiedObjectReference);
                                
                                if (rc != RC_OK && rc != RC_NOT_FOUND_UDATA)
                                {
                                    PPT_METHODTRACE_V1("", "object_userData_Set() rc != RC_OK");
                                    strChamberProcessWaferRptResult.strResult = strObject_UserData_Set_out.strResult;
                                    return rc;
                                }
                               
                            }
                        }
                    }
                }
//INN-R170009 Add End                
            }
        }

//P5100029        /*-----------------------------------*/
//P5100029        /*   Make WaferChamberProcessEvent   */
//P5100029        /*-----------------------------------*/
//P5100029        objWaferChamberProcessEvent_Make_out strWaferChamberProcessEvent_Make_out;
//P5100029        rc = waferChamberProcessEvent_Make( strWaferChamberProcessEvent_Make_out,
//P5100029                                            strObjCommonIn,
//P5100029                                            "TXEQR009",
//P5100029                                            equipmentID,
//P5100029                                            strChamberProcessLotInfos,
//P5100029                                            claimMemo );
//P5100029        if ( rc != RC_OK )
//P5100029        {
//P5100029            PPT_METHODTRACE_V1("", "waferChamberProcessEvent_Make() != RC_OK");
//P5100029            strChamberProcessWaferRptResult.strResult = strWaferChamberProcessEvent_Make_out.strResult;
//P5100029            return( rc );
//P5100029        }
    }

//D5100088 add start
    /*-----------------------------------------*/
    /*   Set Wafer-Chamber Information in PO   */
    /*-----------------------------------------*/
    if ( CIMFWStrCmp(strChamberProcessLotInfos[0].actionCode, SP_ChamberProcActionCode_ProcessEnd) == 0 )
    {
        PPT_METHODTRACE_V1("", "ActionCode is 'ProcessEnd'. So, set Wafer-Chamber Information in PO.");

        objProcess_waferChamberInformation_Set_out strProcess_waferChamberInformation_Set_out;
        rc = process_waferChamberInformation_Set( strProcess_waferChamberInformation_Set_out,
                                                  strObjCommonIn,
                                                  tmpStrChamberProcessLotInfos );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_waferChamberInformation_Set() != RC_OK");
            strChamberProcessWaferRptResult.strResult = strProcess_waferChamberInformation_Set_out.strResult;
            return( rc );
        }
    }
//D5100088 add end

//P5100029 add start
    /*-----------------------------------*/
    /*   Make WaferChamberProcessEvent   */
    /*-----------------------------------*/
    objWaferChamberProcessEvent_Make_out strWaferChamberProcessEvent_Make_out;
    rc = waferChamberProcessEvent_Make( strWaferChamberProcessEvent_Make_out,
                                        strObjCommonIn,
                                        "TXEQR009",
                                        equipmentID,
                                        strChamberProcessLotInfos,
                                        claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferChamberProcessEvent_Make() != RC_OK");
        strChamberProcessWaferRptResult.strResult = strWaferChamberProcessEvent_Make_out.strResult;
        return( rc );
    }
//P5100029 add end

    /*----------------------*/
    /*   Return to Caller   */
    /*----------------------*/
    SET_MSG_RC( strChamberProcessWaferRptResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("PPTManager_i:: txChamberProcessWaferRpt");
    return( RC_OK );
}
