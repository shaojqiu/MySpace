//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorLotAllBranchReq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: cs_txEqpMonitorLotAllBranchReq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017/10/27 INN-R170016   JJ.Zhang       NPW Monitor Customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csEqpMonitorLotAllBranchReqResult&              strEqpMonitorLotAllBranchReqResult
//      const pptObjCommonIn&                           strObjCommonIn
//      const csEqpMonitorLotAllBranchReqInParm&        strEqpMonitorLotAllBranchReqInParm
//      const char*                                     claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//

CORBA::Long CS_PPTManager_i::cs_txEqpMonitorLotAllBranchReq(
    csEqpMonitorLotAllBranchReqResult&              strEqpMonitorLotAllBranchReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csEqpMonitorLotAllBranchReqInParm&        strEqpMonitorLotAllBranchReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txEqpMonitorLotAllBranchReq")
    CORBA::Long rc = RC_OK;

    PPT_METHODTRACE_V2("","in para eqpMonitorID",strEqpMonitorLotAllBranchReqInParm.eqpMonitorID.identifier );
    PPT_METHODTRACE_V2("","in para carrierID   ",strEqpMonitorLotAllBranchReqInParm.carrierID.identifier );

    CORBA::ULong i = 0, j = 0, k = 0;
    CORBA::ULong nSeqLen = 0;
    CORBA::ULong nLotLen = 0;

    objectIdentifier carrierID = strEqpMonitorLotAllBranchReqInParm.carrierID;
    //--------------------------------
    //   Object Lock for Cassette
    //--------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, carrierID, SP_ClassName_PosCassette);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strEqpMonitorLotAllBranchReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    //--------------------------------
    //  Get cassette lot list.
    //--------------------------------
    objCassette_GetLotList_out strCassette_GetLotList_out;
    rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, carrierID );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK", rc);
        strEqpMonitorLotAllBranchReqResult.strResult = strCassette_GetLotList_out.strResult;
        return( rc );
    }

    objectIdentifierSequence lotIDs;
    lotIDs = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID;
    nLotLen = lotIDs.length();

    for( i =0; i<nLotLen; i++)
    {
        //------------------------------
        // Lock lot for update
        //------------------------------
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, lotIDs[i], SP_ClassName_PosLot );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
            strEqpMonitorLotAllBranchReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
    }

    //----------------------------------------------
    // Check slot map matched the monitor definiton
    //----------------------------------------------
    objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
    rc = cassette_GetWaferMapDR(strCassette_GetWaferMapDR_out, strObjCommonIn, carrierID);
    if(rc!= RC_OK)
    {
        PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK ", carrierID.identifier );
        strEqpMonitorLotAllBranchReqResult.strResult = strCassette_GetWaferMapDR_out.strResult;
        return( rc );
    }
    //----------------------------------------------
    // pick-up wafers in carrier
    //----------------------------------------------
    CORBA::ULong mapLen = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();
    pptWaferMapInCassetteInfoSequence strWaferMapInCassetteInfoSeq;
    strWaferMapInCassetteInfoSeq.length(mapLen);
    CORBA::Long waferCount = 0;

    for( i =0; i<mapLen; i++)
    {
        PPT_METHODTRACE_V2("", "waferID", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier );
        if( 0 < CIMFWStrLen(strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier) )
        {
            strWaferMapInCassetteInfoSeq[waferCount] = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i];
            waferCount++ ;
        }
    }
    strWaferMapInCassetteInfoSeq.length(waferCount);
    PPT_METHODTRACE_V2("", "waferCount", waferCount );

    //----------------------------------------------
    // Get eqpMonitor definition
    //----------------------------------------------
    objEqpMonitor_info_Get_in strEqpMonitor_info_Get_in;
    strEqpMonitor_info_Get_in.eqpMonitorID = strEqpMonitorLotAllBranchReqInParm.eqpMonitorID;

    csObjEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
    rc = cs_eqpMonitor_info_GetDR( strEqpMonitor_info_Get_out,
                              strObjCommonIn,
                              strEqpMonitor_info_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_eqpMonitor_info_GetDR() != RC_OK", rc);
        strEqpMonitorLotAllBranchReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
        return rc;
    }

    csEqpMonitorSubInfoSequence& strEqpMonitorSubInfoSeq = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].strEqpMonitorSubInfoSeq;
    nSeqLen = strEqpMonitorSubInfoSeq.length();
    if( waferCount != nSeqLen )
    {
        //slot map not matched the monitor definiton
        PPT_METHODTRACE_V2("", "waferCount!= nSeqLen", waferCount );
        CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotAllBranchReqResult,
                                CS_MSG_WAFER_SLOTMAP_UNMATCH,
                                CS_RC_WAFER_SLOTMAP_UNMATCH,
                                carrierID.identifier,
                                strEqpMonitorLotAllBranchReqInParm.eqpMonitorID.identifier );
        return CS_RC_WAFER_SLOTMAP_UNMATCH;
    }

    for( i =0; i<nSeqLen; i++)
    {
        //wafer in slot should have same attribute as what defined in EQPMON_SUB
        PPT_METHODTRACE_V2("", " check slotNumber", strEqpMonitorSubInfoSeq[i].slotNumber);
        if(strWaferMapInCassetteInfoSeq[i].slotNumber != strEqpMonitorSubInfoSeq[i].slotNumber)
        {
            PPT_METHODTRACE_V2("", "WaferID", strWaferMapInCassetteInfoSeq[i].waferID.identifier);
            char slotNumber[64];
            sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
            CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotAllBranchReqResult,
                                    CS_MSG_WAFER_NO_USE_BY_EQPMON,
                                    CS_RC_WAFER_NO_USE_BY_EQPMON,
                                    slotNumber,
                                    strEqpMonitorLotAllBranchReqInParm.eqpMonitorID.identifier );
            return CS_RC_WAFER_NO_USE_BY_EQPMON;
        }

        //----------------------------------------------
        // Get product ID for wafer
        //----------------------------------------------
        objLot_productID_Get_out strLot_productID_Get_out;
        rc = lot_productID_Get( strLot_productID_Get_out,
                                strObjCommonIn,
                                strWaferMapInCassetteInfoSeq[i].lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "","lot_productID_Get != RC_OK", rc );
            strEqpMonitorLotAllBranchReqResult.strResult = strLot_productID_Get_out.strResult;
            return rc;
        }
        PPT_METHODTRACE_V2("", "productID", strLot_productID_Get_out.productID.identifier);

        if ( 0 != CIMFWStrCmp(strLot_productID_Get_out.productID.identifier, strEqpMonitorSubInfoSeq[i].productID.identifier) )
        {
            PPT_METHODTRACE_V2("", "Product doesn't match", strWaferMapInCassetteInfoSeq[i].waferID.identifier);
            char slotNumber[64];
            sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
            CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotAllBranchReqResult,
                                    CS_MSG_WAFER_NO_USE_BY_EQPMON,
                                    CS_RC_WAFER_NO_USE_BY_EQPMON,
                                    slotNumber,
                                    strEqpMonitorLotAllBranchReqInParm.eqpMonitorID.identifier );
            return CS_RC_WAFER_NO_USE_BY_EQPMON;
        }
    }

    //----------------------------------------------
    // Branch lot to sub-route
    //----------------------------------------------
    nSeqLen = strEqpMonitorSubInfoSeq.length();
    lotIDs.length(nSeqLen);
    nLotLen = 0;
    for( i =0; i<nSeqLen; i++)
    {
        PPT_METHODTRACE_V2("", "lotID", strWaferMapInCassetteInfoSeq[i].lotID.identifier);
        //---------------------------------------------
        // skip the lot if it has already been checked
        //---------------------------------------------
        CORBA::Boolean bFound = FALSE;
        for( j =0; j<nLotLen; j++)
        {
            if( 0 == CIMFWStrCmp(lotIDs[j].identifier, strWaferMapInCassetteInfoSeq[i].lotID.identifier) )
            {
                PPT_METHODTRACE_V2("", "lot already branched", strWaferMapInCassetteInfoSeq[i].lotID.identifier);
                bFound = TRUE;
                break;;
            }
        }
        if( TRUE == bFound )
        {
            PPT_METHODTRACE_V1("", "lot already branched");
            continue;
        }

        //----------------------------------------------
        // split the wafers which goto different sub-route
        //----------------------------------------------
        CORBA::Long splitCount = 0;
        objectIdentifierSequence childWaferID;

        for( j =i+1; j<nSeqLen; j++)
        {
            PPT_METHODTRACE_V2("", "lotID[j]", strWaferMapInCassetteInfoSeq[j].lotID.identifier);

            if( 0 == CIMFWStrCmp(strWaferMapInCassetteInfoSeq[i].lotID.identifier, strWaferMapInCassetteInfoSeq[j].lotID.identifier)
             && 0 != CIMFWStrCmp(strEqpMonitorSubInfoSeq[i].subRouteID.identifier, strEqpMonitorSubInfoSeq[j].subRouteID.identifier) )
            {
                PPT_METHODTRACE_V2("", "branch to different sub-routes", strWaferMapInCassetteInfoSeq[j].waferID.identifier);
                childWaferID.length(splitCount+1);
                childWaferID[splitCount] = strWaferMapInCassetteInfoSeq[j].waferID;
                splitCount++;
            }
        }
        PPT_METHODTRACE_V2("", "splitCount", splitCount);
        if( splitCount > 0 )
        {
            pptSplitWaferLotReqResult strSplitWaferLotReqResult;
            objectIdentifier dummyID;
            dummyID.identifier = CIMFWStrDup("");
            rc = txSplitWaferLotReq( strSplitWaferLotReqResult,
                                     strObjCommonIn,
                                     strWaferMapInCassetteInfoSeq[i].lotID, // parentLotID,
                                     childWaferID,      // childWaferID,
                                     FALSE,             // futureMergeFlag,
                                     dummyID,           // mergedRouteID,
                                     "",                // mergedOperationNumber,
                                     FALSE,             // branchingRouteSpecifyFlag,
                                     dummyID,           // subRouteID,
                                     "",                // returnOperationNumber,
                                     "" );              // claimMemo                                                   
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txSplitWaferLotReq() != RC_OK", rc);
                strEqpMonitorLotAllBranchReqResult.strResult = strSplitWaferLotReqResult.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "New splitted lot", strSplitWaferLotReqResult.childLotID.identifier);
            //save the lot id to strWaferMapInCassetteInfoSeq
            for( j =i+1; j<nSeqLen; j++)
            {
                for( k =0; k<splitCount; k++)
                {
                    if( 0 == CIMFWStrCmp(strWaferMapInCassetteInfoSeq[j].waferID.identifier, childWaferID[k].identifier) )
                    {
                        PPT_METHODTRACE_V2("", "replace lotID for wafer", strWaferMapInCassetteInfoSeq[j].waferID.identifier);
                        strWaferMapInCassetteInfoSeq[j].lotID = strSplitWaferLotReqResult.childLotID;
                        break;
                    }
                }
            }
        }

        //save the lotIDs into processed list
        lotIDs[nLotLen] = strWaferMapInCassetteInfoSeq[i].lotID;
        nLotLen++;

        //---------------------------------------------
        // skip the lot if subRoute is not defined
        //---------------------------------------------
        if( 0 == CIMFWStrLen(strEqpMonitorSubInfoSeq[i].subRouteID.identifier) )
        {
            PPT_METHODTRACE_V2("", "strEqpMonitorSubInfoSeq[i].subRouteID is blank", i);
            continue;
        }

        //---------------------------------------------
        // Check lot is on sub-route or not
        //---------------------------------------------
        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                     strObjCommonIn,
                                     strWaferMapInCassetteInfoSeq[i].lotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get != RC_OK", rc);
            strEqpMonitorLotAllBranchReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
            return( rc );
        }

        objectIdentifier currentRouteID = strLot_currentOperationInfo_Get_out.routeID;
        PPT_METHODTRACE_V2("", "currentRouteID", currentRouteID.identifier);
        if( 0 == CIMFWStrCmp(currentRouteID.identifier, strEqpMonitorSubInfoSeq[i].subRouteID.identifier) )
        {
            PPT_METHODTRACE_V1("", "lot already on subRoute");
            continue;
        }

        //---------------------------------------------
        // check whether lot is on wrong sub-route
        //---------------------------------------------
        objLot_mainRouteID_Get_out strLot_mainRouteID_Get_out;
        rc = lot_mainRouteID_Get( strLot_mainRouteID_Get_out,
                                     strObjCommonIn,
                                     strWaferMapInCassetteInfoSeq[i].lotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_mainRouteID_Get != RC_OK", rc);
            strEqpMonitorLotAllBranchReqResult.strResult = strLot_mainRouteID_Get_out.strResult;
            return( rc );
        }

        objectIdentifier mainRouteID = strLot_mainRouteID_Get_out.mainRouteID;
        PPT_METHODTRACE_V2("", "mainRouteID", mainRouteID.identifier);
        if( 0 != CIMFWStrCmp(currentRouteID.identifier, mainRouteID.identifier) )
        {
            //0011202E:The lot [%s] is already in branch route, but different from the requested one [%s].
            PPT_METHODTRACE_V1("", "lot is on wrong subRoute");
            CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotAllBranchReqResult,
                                    CS_MSG_LOT_IN_DIFFERENT_BRANCH,
                                    CS_RC_LOT_IN_DIFFERENT_BRANCH,
                                    strWaferMapInCassetteInfoSeq[i].lotID.identifier,
                                    strEqpMonitorSubInfoSeq[i].subRouteID.identifier);
            return CS_RC_LOT_IN_DIFFERENT_BRANCH;
        }

        //---------------------------------------------
        // Get all sub route info for this lot
        //---------------------------------------------
        objProcess_connectedRouteList_out strProcess_connectedRouteList_out ;
        rc = process_connectedRouteList(strProcess_connectedRouteList_out, strObjCommonIn,
                                        SP_MAINPDTYPE_BRANCH, //routeType,
                                        strWaferMapInCassetteInfoSeq[i].lotID ) ;
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_connectedRouteList rc != RC_OK")
            strEqpMonitorLotAllBranchReqResult.strResult = strProcess_connectedRouteList_out.strResult ;
            return rc ;
        }

        pptConnectedRouteListSequence& strConnectedRouteList = strProcess_connectedRouteList_out.strConnectedRouteList ;
        CORBA::Long nRouteListLen = strConnectedRouteList.length();
        PPT_METHODTRACE_V2("", "strConnectedRouteList.length", nRouteListLen);

        //---------------------------------------------
        // Perform Branch
        //---------------------------------------------
        CORBA::String_var returnOpeNo;

        //Get return operation number
        for( j=0; j<nRouteListLen; j++ )
        {
            if( 0 == CIMFWStrCmp(strConnectedRouteList[j].routeID.identifier, strEqpMonitorSubInfoSeq[i].subRouteID.identifier) )
            {
                PPT_METHODTRACE_V1("", "found subRoute");
                returnOpeNo  = strConnectedRouteList[j].returnOperationNumber;
                break;
            }
        }
        if( 0 == CIMFWStrLen(returnOpeNo) )
        {
            PPT_METHODTRACE_V2("", "Not found subRoute", strEqpMonitorSubInfoSeq[i].subRouteID.identifier);
            CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotAllBranchReqResult,
                                    CS_MSG_INVALID_EQPM_SUBROUTE,
                                    CS_RC_INVALID_EQPM_SUBROUTE,
                                    strEqpMonitorSubInfoSeq[i].subRouteID.identifier,
                                    strEqpMonitorSubInfoSeq[i].productID.identifier );
            return CS_RC_INVALID_EQPM_SUBROUTE;
        }
        //-----------------------------------------------------------
        // Route change request
        //-----------------------------------------------------------
        objProcess_BranchRoute_out strProcess_BranchRoute_out ;
        rc = process_BranchRoute( strProcess_BranchRoute_out,
                                  strObjCommonIn,
                                  strWaferMapInCassetteInfoSeq[i].lotID,
                                  strEqpMonitorSubInfoSeq[i].subRouteID,
                                  returnOpeNo) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "process_BranchRoute() != RC_OK") ;
            strEqpMonitorLotAllBranchReqResult.strResult = strProcess_BranchRoute_out.strResult ;
            return rc ;
        }
    }
    lotIDs.length(nLotLen);

    //---------------------------------------------
    //   Return
    //---------------------------------------------
    strEqpMonitorLotAllBranchReqResult.lotIDs = lotIDs;

    SET_MSG_RC(strEqpMonitorLotAllBranchReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorLotAllBranchReq")
    return( RC_OK );
}
