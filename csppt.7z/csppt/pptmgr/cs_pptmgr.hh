//----------------------------------------------------------------------------
//
//  Generated from cs_pptmgr.idl
//  On Tuesday, November 14, 2017 11:54:27 AM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_pptmgr_server_defined
#ifndef _cs_pptmgr_hh_included
#define _cs_pptmgr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif
#ifndef _DCL_CS_PPTManager_SOM_IMPORTEXPORT
#define _DCL_CS_PPTManager_SOM_IMPORTEXPORT 
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_PPTManager_idl 
#define CS_PPTManager_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _pptmgr_hh_included
#include <pptmgr.hh>
#endif
#else
#ifndef _pptmgr_hh_included
#include "pptmgr.hh"
#endif
#endif

// Begin mapping for interface ::CS_PPTManager

#ifndef _DCL_CS_PPTManager
#define _DCL_CS_PPTManager
#ifndef _DCL_CS_PPTManager_SOM_IMPORTEXPORT
#define _DCL_CS_PPTManager_SOM_IMPORTEXPORT 
#endif
class _DCL_CS_PPTManager_SOM_IMPORTEXPORT
   CS_PPTManager
    ;
class _DCL_CS_PPTManager_SOM_IMPORTEXPORT CS_PPTManager_var;
typedef CS_PPTManager* CS_PPTManager_ptr;
typedef CS_PPTManager* CS_PPTManagerRef;

_DCL_CS_PPTManager_SOM_IMPORTEXPORT CORBA::Object_ptr SOMLINK CS_PPTManager_getBase(void *);

_DCL_CS_PPTManager_SOM_IMPORTEXPORT CS_PPTManager_ptr SOMLINK CS_PPTManager_aux_duplicate(CS_PPTManager_ptr);
_DCL_CS_PPTManager_SOM_IMPORTEXPORT CS_PPTManager_ptr SOMLINK CS_PPTManager_aux_narrow(::CORBA::Object_ptr);
_DCL_CS_PPTManager_SOM_IMPORTEXPORT CS_PPTManager_ptr SOMLINK CS_PPTManager_aux_nil();
_DCL_CS_PPTManager_SOM_IMPORTEXPORT const char* SOMLINK CS_PPTManager_aux_CN();

    class _DCL_CS_PPTManager_SOM_IMPORTEXPORT CS_PPTManager_StructElem
    {
        public:

        CS_PPTManager_StructElem ();

        CS_PPTManager_StructElem (const CS_PPTManager_StructElem &s);

        CS_PPTManager_StructElem &operator= (CS_PPTManager_ptr p);

        CS_PPTManager_StructElem &operator= (CS_PPTManager_var v);

        CS_PPTManager_StructElem &operator= (const CS_PPTManager_StructElem &s);

        ~CS_PPTManager_StructElem ();

        operator ::CORBA::Object_ptr() const;

        operator CS_PPTManager_ptr () const;

        CS_PPTManager_ptr _ptr;

    }; // CS_PPTManager_StructElem

    class _DCL_CS_PPTManager_SOM_IMPORTEXPORT CS_PPTManager_SeqElem
    {
       public:

       CS_PPTManager_SeqElem (CS_PPTManager_ptr* p, unsigned char rel);

       CS_PPTManager_SeqElem &operator= (CS_PPTManager_ptr p);

        CS_PPTManager_SeqElem &operator= (CS_PPTManager_var v);

       CS_PPTManager_SeqElem &operator= (const CS_PPTManager_SeqElem &s);

       operator CS_PPTManager_ptr () const;

       CS_PPTManager_ptr operator->() const;

       protected:
       CS_PPTManager_ptr *_ptr;
       unsigned char _release;
   }; // CS_PPTManager_SeqElem


class  CS_PPTManager_var : public ::CORBA::__vb__
{
    public:

    CS_PPTManager_var ();
    CS_PPTManager_var (CS_PPTManager *p);
    CS_PPTManager_var (const CS_PPTManager_var &s);
    CS_PPTManager_var (const CS_PPTManager_StructElem &s);
    CS_PPTManager_var (const CS_PPTManager_SeqElem &s);
    CS_PPTManager_var &operator= (CS_PPTManager *p);
    CS_PPTManager_var &operator= (const CS_PPTManager_var &s);
    CS_PPTManager_var &operator= (const CS_PPTManager_StructElem &s);
    CS_PPTManager_var &operator= (const CS_PPTManager_SeqElem &s);
    ~CS_PPTManager_var ();
    CS_PPTManager_ptr in() const;
    CS_PPTManager_ptr& inout();
    CS_PPTManager_ptr& out();
    CS_PPTManager_ptr _retn();
    CS_PPTManager_ptr operator-> ();
    operator CS_PPTManager_ptr& ();
    operator const CS_PPTManager_ptr& () const;
#ifdef __sun
    operator CS_PPTManager_ptr () { return _ptr; };
#endif

    protected:
       CS_PPTManager *_ptr;

    private:
       ::CORBA::__vb__& operator= (::CORBA::__vb__&);

};  // CS_PPTManager_var

#endif /* _DCL_CS_PPTManager */ 


class 

   CS_PPTManager
: virtual public ::PPTManager {

public: 
    static const char* CS_PPTManager_CN;
    static const char* CS_PPTManager_RID;
    typedef CS_PPTManager_ptr _ptr_type;
    typedef CS_PPTManager_var _var_type;

    /* for Orbix compatibility */
    virtual void *_deref();

protected: 
    /* constructor */

   CS_PPTManager
();
protected: 
    virtual ~

   CS_PPTManager
();
private: 

   CS_PPTManager
    (const 
   CS_PPTManager
     &); // unimplemented

    void operator=(const 
   CS_PPTManager
     &); // unimplemented
public: 

    static CS_PPTManager_ptr SOMLINK _duplicate(CS_PPTManager_ptr obj);

    static CS_PPTManager_ptr SOMLINK _narrow (::CORBA::Object_ptr);

    virtual void* _has_ancestor(const char* classname);
    static CS_PPTManager_ptr SOMLINK _nil ();

    CS_PPTManager_ptr _self();
    CS_PPTManager_ptr _this();
    virtual void *_SOMThis(const char *& ifname);


    virtual  ::CORBA::Void  CS_PPTManager_init (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Void  _req_CS_PPTManager_init (::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Void  CS_PPTManager_uninit (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Void  _req_CS_PPTManager_uninit (::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txTestFunction (::csTestFunctionResult& strTestFunctionResult, const ::pptObjCommonIn& strObjCommonIn, const char* functionName, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& controlJobID, const char* eventID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txTestFunction (::csTestFunctionResult& strTestFunctionResult, const ::pptObjCommonIn& strObjCommonIn, const char* functionName, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& controlJobID, const char* eventID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpInAuditListInq (::csEqpInAuditListInqResult& strCsEqpInAuditListInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpInAuditListInq (::csEqpInAuditListInqResult& strCsEqpInAuditListInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpListByOwnerInq (::csEqpListByOwnerInqResult& strCsEqpListByOwnerInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpListByOwnerInq (::csEqpListByOwnerInqResult& strCsEqpListByOwnerInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpRMSFlgInq (::csEqpRMSFlgInqResult& strEqpRMSFlgInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpRMSFlgInq (::csEqpRMSFlgInqResult& strEqpRMSFlgInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txPrivilegeCheckForRMSReq (::csPrivilegeCheckForRMSReqResult& strCsPrivilegeCheckForRMSReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txPrivilegeCheckForRMSReq (::csPrivilegeCheckForRMSReqResult& strCsPrivilegeCheckForRMSReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpInfoListByOwnerInq (::csEqpInfoListByOwnerInqResult& strCsEqpInfoListByOwnerInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpInfoListByOwnerInq (::csEqpInfoListByOwnerInqResult& strCsEqpInfoListByOwnerInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpRelatedRecipeIDAuditFlagListInq (::csEqpRelatedRecipeIDAuditFlagListInqResult& strEqpRelatedRecipeIDAuditFlagListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean getAuditFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpRelatedRecipeIDAuditFlagListInq (::csEqpRelatedRecipeIDAuditFlagListInqResult& strEqpRelatedRecipeIDAuditFlagListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean getAuditFlag, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txCassetteInspectionTimeResetReq (::csCassetteInspectionTimeResetReqResult& strCassetteInspectionTimeResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txCassetteInspectionTimeResetReq (::csCassetteInspectionTimeResetReqResult& strCassetteInspectionTimeResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txCassettePMTimeResetReq (::csCassettePMTimeResetReqResult& strCassettePMTimeResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txCassettePMTimeResetReq (::csCassettePMTimeResetReqResult& strCassettePMTimeResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txReticleWaferCountResetReq (::csReticleWaferCountResetReqResult& strReticleWaferCountResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txReticleWaferCountResetReq (::csReticleWaferCountResetReqResult& strReticleWaferCountResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txReticleUsedDurationResetReq (::csReticleUsedDurationResetReqResult& strReticleUsedDurationResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txReticleUsedDurationResetReq (::csReticleUsedDurationResetReqResult& strReticleUsedDurationResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txVendorLotReserveReq (::csVendorLotReserveReqResult& strVendorLotReserveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotType, const char* subLotType, const char* sourceProduct, const ::pptNewLotAttributes& strNewLotAttributes, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txVendorLotReserveReq (::csVendorLotReserveReqResult& strVendorLotReserveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotType, const char* subLotType, const char* sourceProduct, const ::pptNewLotAttributes& strNewLotAttributes, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txVendorLotReserveCancelReq (::csVendorLotReserveCancelReqResult& strVendorLotReserveCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txVendorLotReserveCancelReq (::csVendorLotReserveCancelReqResult& strVendorLotReserveCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txVendorLotReserveListInq (::csVendorLotReserveListInqResult& strVendorLotReserveListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txVendorLotReserveListInq (::csVendorLotReserveListInqResult& strVendorLotReserveListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txFixtureTouchCountRpt (::csFixtureTouchCountRptResult& strFixtureTouchCountRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::csFixtureTouchCountRptInParm& strFixtureTouchCountRptInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txFixtureTouchCountRpt (::csFixtureTouchCountRptResult& strFixtureTouchCountRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::csFixtureTouchCountRptInParm& strFixtureTouchCountRptInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txUserCertifiedSkillDeleteReq (::csUserCertifiedSkillDeleteReqResult& strUserCertifiedSkillDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedSkillDeleteReqInParm& strUserCertifiedSkillDeleteReqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txUserCertifiedSkillDeleteReq (::csUserCertifiedSkillDeleteReqResult& strUserCertifiedSkillDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedSkillDeleteReqInParm& strUserCertifiedSkillDeleteReqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txUserCertifiedSkillUpdateReq (::csUserCertifiedSkillUpdateReqResult& strUserCertifiedSkillUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedSkillUpdateReqInParm& strUserCertifiedSkillUpdateReqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txUserCertifiedSkillUpdateReq (::csUserCertifiedSkillUpdateReqResult& strUserCertifiedSkillUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedSkillUpdateReqInParm& strUserCertifiedSkillUpdateReqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txUserCertifyCheckInq (::csUserCertifyCheckInqResult& strUserCertifyCheckInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifyCheckInqInParm& strUserCertifyCheckInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txUserCertifyCheckInq (::csUserCertifyCheckInqResult& strUserCertifyCheckInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifyCheckInqInParm& strUserCertifyCheckInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txUserCertifiedEqpTypeSkillInq (::csUserCertifiedEqpTypeSkillInqResult& strUserCertifiedEqpTypeSkillInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txUserCertifiedEqpTypeSkillInq (::csUserCertifiedEqpTypeSkillInqResult& strUserCertifiedEqpTypeSkillInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txCarrierUsageTypeChangeReq (::csCarrierUsageTypeChangeReqResult& strCarrierUsageTypeChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txCarrierUsageTypeChangeReq (::csCarrierUsageTypeChangeReqResult& strCarrierUsageTypeChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txStartLotsReservationForInternalBufferReq (::pptStartLotsReservationForInternalBufferReqResult& strStartLotsReservationForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean skipBatchSizeFlag, ::CORBA::Boolean skipWaferCountFlag, const char* claimMemo, char*& APCIFControlStatus, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txStartLotsReservationForInternalBufferReq (::pptStartLotsReservationForInternalBufferReqResult& strStartLotsReservationForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean skipBatchSizeFlag, ::CORBA::Boolean skipWaferCountFlag, const char* claimMemo, char*& APCIFControlStatus, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txLotComplicatedHoldReq (::csLotComplicatedHoldReqResult& strLotComplicatedHoldReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csLotComplicatedHoldReqInParam& strLotComplicatedHoldReqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txLotComplicatedHoldReq (::csLotComplicatedHoldReqResult& strLotComplicatedHoldReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csLotComplicatedHoldReqInParam& strLotComplicatedHoldReqInParam, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpMonitorInventoryListInq (::csEqpMonitorInventoryListInqResult& strEqpMonitorInventoryListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorInventoryListInqInParm& strEqpMonitorInventoryListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpMonitorInventoryListInq (::csEqpMonitorInventoryListInqResult& strEqpMonitorInventoryListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorInventoryListInqInParm& strEqpMonitorInventoryListInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDowngradeItemListInq (::csDowngradeItemListInqResult& strDowngradeItemListInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDowngradeItemListInq (::csDowngradeItemListInqResult& strDowngradeItemListInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDowngradeSettingListInq (::csDowngradeSettingListInqResult& strDowngradeSettingListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeSettingListInqInParm& strDowngradeSettingListInqParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDowngradeSettingListInq (::csDowngradeSettingListInqResult& strDowngradeSettingListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeSettingListInqInParm& strDowngradeSettingListInqParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpMonitorInventoryUpdateReq (::csEqpMonitorInventoryUpdateReqResult& strEqpMonitorInventoryUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorInventoryUpdateReqInParm& strEqpMonitorInventoryUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpMonitorInventoryUpdateReq (::csEqpMonitorInventoryUpdateReqResult& strEqpMonitorInventoryUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorInventoryUpdateReqInParm& strEqpMonitorInventoryUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txBWSWaferOutAndSTBReq (::csBWSWaferOutAndSTBReqResult& strBWSWaferOutAndSTBReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSWaferOutAndSTBReqInParm& strBWSWaferOutAndSTBReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txBWSWaferOutAndSTBReq (::csBWSWaferOutAndSTBReqResult& strBWSWaferOutAndSTBReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSWaferOutAndSTBReqInParm& strBWSWaferOutAndSTBReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpMonitorLotSTBReq (::csEqpMonitorLotSTBReqResult& strEqpMonitorLotSTBReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotSTBReqInParm& strEqpMonitorLotSTBReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpMonitorLotSTBReq (::csEqpMonitorLotSTBReqResult& strEqpMonitorLotSTBReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotSTBReqInParm& strEqpMonitorLotSTBReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpMonitorLotAllBranchReq (::csEqpMonitorLotAllBranchReqResult& strEqpMonitorLotAllBranchReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotAllBranchReqInParm& strEqpMonitorLotAllBranchReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpMonitorLotAllBranchReq (::csEqpMonitorLotAllBranchReqResult& strEqpMonitorLotAllBranchReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotAllBranchReqInParm& strEqpMonitorLotAllBranchReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpMonitorLotPrepareIDResetReq (::csEqpMonitorLotPrepareIDResetReqResult& strEqpMonitorLotPrepareIDResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotPrepareIDResetReqInParm& strEqpMonitorLotPrepareIDResetReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpMonitorLotPrepareIDResetReq (::csEqpMonitorLotPrepareIDResetReqResult& strEqpMonitorLotPrepareIDResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotPrepareIDResetReqInParm& strEqpMonitorLotPrepareIDResetReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDowngradeItemUpdateReq (::csDowngradeItemUpdateReqResult& strDowngradeItemUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeItemUpdateReqInParm& strDowngradeItemUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDowngradeItemUpdateReq (::csDowngradeItemUpdateReqResult& strDowngradeItemUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeItemUpdateReqInParm& strDowngradeItemUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDowngradeSettingUpdateReq (::csDowngradeSettingUpdateReqResult& strDowngradeSettingUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeSettingUpdateReqInParm& strDowngradeSettingUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDowngradeSettingUpdateReq (::csDowngradeSettingUpdateReqResult& strDowngradeSettingUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeSettingUpdateReqInParm& strDowngradeSettingUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpMonitorUpdateReq (::pptEqpMonitorUpdateReqResult& strEqpMonitorUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorUpdateReqInParm& strEqpMonitorUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpMonitorUpdateReq (::pptEqpMonitorUpdateReqResult& strEqpMonitorUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorUpdateReqInParm& strEqpMonitorUpdateReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpMonitorListInq (::csEqpMonitorListInqResult& strEqpMonitorListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorListInqInParm& strEqpMonitorListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpMonitorListInq (::csEqpMonitorListInqResult& strEqpMonitorListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorListInqInParm& strEqpMonitorListInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txEqpMonitorSourceCandidateInfoInq (::csEqpMonitorSourceCandidateInfoInqResult& strEqpMonitorSourceCandidateInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorSourceCandidateInfoInqInParm& strEqpMonitorSourceCandidateInfoInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txEqpMonitorSourceCandidateInfoInq (::csEqpMonitorSourceCandidateInfoInqResult& strEqpMonitorSourceCandidateInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorSourceCandidateInfoInqInParm& strEqpMonitorSourceCandidateInfoInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txNPWProductChangeReq (::csNPWProductChangeReqResult& strNPWProductChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csNPWProductChangeReqInParm& strNPWProductChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txNPWProductChangeReq (::csNPWProductChangeReqResult& strNPWProductChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csNPWProductChangeReqInParm& strNPWProductChangeReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txBWSWaferListInq (::csBWSWaferListInqResult& strBWSWaferListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSWaferListInqInParm& strBWSWaferListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txBWSWaferListInq (::csBWSWaferListInqResult& strBWSWaferListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSWaferListInqInParm& strBWSWaferListInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txBWSConfigInfoInq (::csBWSConfigInfoInqResult& strBWSConfigInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSConfigInfoInqInParm& strBWSConfigInfoInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txBWSConfigInfoInq (::csBWSConfigInfoInqResult& strBWSConfigInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSConfigInfoInqInParm& strBWSConfigInfoInqInParm, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txBWSConfigChangeReq (::csBWSConfigChangeReqResult& strBWSConfigChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSConfigChangeReqInParm& strBWSConfigChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txBWSConfigChangeReq (::csBWSConfigChangeReqResult& strBWSConfigChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSConfigChangeReqInParm& strBWSConfigChangeReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txBWSInventoryReq (::csBWSInventoryReqResult& strBWSInventoryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSInventoryReqInParm& strBWSInventoryReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txBWSInventoryReq (::csBWSInventoryReqResult& strBWSInventoryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSInventoryReqInParm& strBWSInventoryReqInParm, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDurableDeliveryReq (::csDurableDeliveryReqResult& strDurableDeliveryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDurableDeliveryReq (::csDurableDeliveryReqResult& strDurableDeliveryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDurableOpeCompForInternalBufferReq (::csDurableOpeCompForInternalBufferReqResult& strDurableOpeCompForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOpeCompForInternalBufferReqInParam& strDurableOpeCompForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDurableOpeCompForInternalBufferReq (::csDurableOpeCompForInternalBufferReqResult& strDurableOpeCompForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOpeCompForInternalBufferReqInParam& strDurableOpeCompForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDurableOperationStartCancelForInternalBufferReq (::csDurableOperationStartCancelForInternalBufferReqResult& strDurableOperationStartCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOperationStartCancelForInternalBufferReqInParam& strDurableOperationStartCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDurableOperationStartCancelForInternalBufferReq (::csDurableOperationStartCancelForInternalBufferReqResult& strDurableOperationStartCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOperationStartCancelForInternalBufferReqInParam& strDurableOperationStartCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDurableOperationStartForInternalBufferReq (::csDurableOperationStartForInternalBufferReqResult& strDurableOperationStartForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOperationStartForInternalBufferReqInParam& strDurableOperationStartForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDurableOperationStartForInternalBufferReq (::csDurableOperationStartForInternalBufferReqResult& strDurableOperationStartForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOperationStartForInternalBufferReqInParam& strDurableOperationStartForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDurablesInfoForOpeStartForInternalBufferInq (::csDurablesInfoForOpeStartForInternalBufferInqResult& strDurablesInfoForOpeStartForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurablesInfoForOpeStartForInternalBufferInqInParam& strDurablesInfoForOpeStartForInternalBufferInqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDurablesInfoForOpeStartForInternalBufferInq (::csDurablesInfoForOpeStartForInternalBufferInqResult& strDurablesInfoForOpeStartForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurablesInfoForOpeStartForInternalBufferInqInParam& strDurablesInfoForOpeStartForInternalBufferInqInParam, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txDurablesInfoForStartReservationForInternalBufferInq (::csDurablesInfoForStartReservationForInternalBufferInqResult& strDurablesInfoForStartReservationForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurablesInfoForStartReservationForInternalBufferInqInParam& strDurablesInfoForStartReservationForInternalBufferInqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txDurablesInfoForStartReservationForInternalBufferInq (::csDurablesInfoForStartReservationForInternalBufferInqResult& strDurablesInfoForStartReservationForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurablesInfoForStartReservationForInternalBufferInqInParam& strDurablesInfoForStartReservationForInternalBufferInqInParam, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txStartDurablesReservationCancelForInternalBufferReq (::csStartDurablesReservationCancelForInternalBufferReqResult& strStartDurablesReservationCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csStartDurablesReservationCancelForInternalBufferReqInParam& strStartDurablesReservationCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txStartDurablesReservationCancelForInternalBufferReq (::csStartDurablesReservationCancelForInternalBufferReqResult& strStartDurablesReservationCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csStartDurablesReservationCancelForInternalBufferReqInParam& strStartDurablesReservationCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::CORBA::Long  cs_txStartDurablesReservationForInternalBufferReq (::csStartDurablesReservationForInternalBufferReqResult& strStartDurablesReservationForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csStartDurablesReservationForInternalBufferReqInParam& strStartDurablesReservationForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::CORBA::Long  _req_cs_txStartDurablesReservationForInternalBufferReq (::csStartDurablesReservationForInternalBufferReqResult& strStartDurablesReservationForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csStartDurablesReservationForInternalBufferReqInParam& strStartDurablesReservationForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:

}; // end nesting scope for interface class ::CS_PPTManager

#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif

class  CS_PPTManager_ORBProxy : virtual public 

   CS_PPTManager
, virtual public ::PPTManager_ORBProxy {

public: 
    CS_PPTManager_ORBProxy ();

    virtual  ::CORBA::Void  CS_PPTManager_init (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Void  CS_PPTManager_uninit (::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txTestFunction (::csTestFunctionResult& strTestFunctionResult, const ::pptObjCommonIn& strObjCommonIn, const char* functionName, const ::objectIdentifier& lotID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& routeID, const char* operationNumber, const ::objectIdentifier& controlJobID, const char* eventID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpInAuditListInq (::csEqpInAuditListInqResult& strCsEqpInAuditListInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Boolean bodyFlag, ::CORBA::Boolean constFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpListByOwnerInq (::csEqpListByOwnerInqResult& strCsEqpListByOwnerInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpRMSFlgInq (::csEqpRMSFlgInqResult& strEqpRMSFlgInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txPrivilegeCheckForRMSReq (::csPrivilegeCheckForRMSReqResult& strCsPrivilegeCheckForRMSReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpInfoListByOwnerInq (::csEqpInfoListByOwnerInqResult& strCsEqpInfoListByOwnerInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentOwnerID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpRelatedRecipeIDAuditFlagListInq (::csEqpRelatedRecipeIDAuditFlagListInqResult& strEqpRelatedRecipeIDAuditFlagListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Boolean getAuditFlag, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txCassetteInspectionTimeResetReq (::csCassetteInspectionTimeResetReqResult& strCassetteInspectionTimeResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txCassettePMTimeResetReq (::csCassettePMTimeResetReqResult& strCassettePMTimeResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txReticleWaferCountResetReq (::csReticleWaferCountResetReqResult& strReticleWaferCountResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txReticleUsedDurationResetReq (::csReticleUsedDurationResetReqResult& strReticleUsedDurationResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& reticleID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txVendorLotReserveReq (::csVendorLotReserveReqResult& strVendorLotReserveReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& bankID, const char* lotType, const char* subLotType, const char* sourceProduct, const ::pptNewLotAttributes& strNewLotAttributes, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txVendorLotReserveCancelReq (::csVendorLotReserveCancelReqResult& strVendorLotReserveCancelReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txVendorLotReserveListInq (::csVendorLotReserveListInqResult& strVendorLotReserveListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& cassetteID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txFixtureTouchCountRpt (::csFixtureTouchCountRptResult& strFixtureTouchCountRptResult, const ::pptObjCommonIn& strObjCommonIn, const ::csFixtureTouchCountRptInParm& strFixtureTouchCountRptInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txUserCertifiedSkillDeleteReq (::csUserCertifiedSkillDeleteReqResult& strUserCertifiedSkillDeleteReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedSkillDeleteReqInParm& strUserCertifiedSkillDeleteReqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txUserCertifiedSkillUpdateReq (::csUserCertifiedSkillUpdateReqResult& strUserCertifiedSkillUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedSkillUpdateReqInParm& strUserCertifiedSkillUpdateReqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txUserCertifyCheckInq (::csUserCertifyCheckInqResult& strUserCertifyCheckInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifyCheckInqInParm& strUserCertifyCheckInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txUserCertifiedEqpTypeSkillInq (::csUserCertifiedEqpTypeSkillInqResult& strUserCertifiedEqpTypeSkillInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txCarrierUsageTypeChangeReq (::csCarrierUsageTypeChangeReqResult& strCarrierUsageTypeChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txStartLotsReservationForInternalBufferReq (::pptStartLotsReservationForInternalBufferReqResult& strStartLotsReservationForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, const ::pptStartCassetteSequence& strStartCassette, ::CORBA::Boolean skipBatchSizeFlag, ::CORBA::Boolean skipWaferCountFlag, const char* claimMemo, char*& APCIFControlStatus, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txLotComplicatedHoldReq (::csLotComplicatedHoldReqResult& strLotComplicatedHoldReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csLotComplicatedHoldReqInParam& strLotComplicatedHoldReqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpMonitorInventoryListInq (::csEqpMonitorInventoryListInqResult& strEqpMonitorInventoryListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorInventoryListInqInParm& strEqpMonitorInventoryListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDowngradeItemListInq (::csDowngradeItemListInqResult& strDowngradeItemListInqResult, const ::pptObjCommonIn& strObjCommonIn, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDowngradeSettingListInq (::csDowngradeSettingListInqResult& strDowngradeSettingListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeSettingListInqInParm& strDowngradeSettingListInqParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpMonitorInventoryUpdateReq (::csEqpMonitorInventoryUpdateReqResult& strEqpMonitorInventoryUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorInventoryUpdateReqInParm& strEqpMonitorInventoryUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txBWSWaferOutAndSTBReq (::csBWSWaferOutAndSTBReqResult& strBWSWaferOutAndSTBReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSWaferOutAndSTBReqInParm& strBWSWaferOutAndSTBReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpMonitorLotSTBReq (::csEqpMonitorLotSTBReqResult& strEqpMonitorLotSTBReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotSTBReqInParm& strEqpMonitorLotSTBReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpMonitorLotAllBranchReq (::csEqpMonitorLotAllBranchReqResult& strEqpMonitorLotAllBranchReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotAllBranchReqInParm& strEqpMonitorLotAllBranchReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpMonitorLotPrepareIDResetReq (::csEqpMonitorLotPrepareIDResetReqResult& strEqpMonitorLotPrepareIDResetReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorLotPrepareIDResetReqInParm& strEqpMonitorLotPrepareIDResetReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDowngradeItemUpdateReq (::csDowngradeItemUpdateReqResult& strDowngradeItemUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeItemUpdateReqInParm& strDowngradeItemUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDowngradeSettingUpdateReq (::csDowngradeSettingUpdateReqResult& strDowngradeSettingUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDowngradeSettingUpdateReqInParm& strDowngradeSettingUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpMonitorUpdateReq (::pptEqpMonitorUpdateReqResult& strEqpMonitorUpdateReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorUpdateReqInParm& strEqpMonitorUpdateReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpMonitorListInq (::csEqpMonitorListInqResult& strEqpMonitorListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::pptEqpMonitorListInqInParm& strEqpMonitorListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txEqpMonitorSourceCandidateInfoInq (::csEqpMonitorSourceCandidateInfoInqResult& strEqpMonitorSourceCandidateInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csEqpMonitorSourceCandidateInfoInqInParm& strEqpMonitorSourceCandidateInfoInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txNPWProductChangeReq (::csNPWProductChangeReqResult& strNPWProductChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csNPWProductChangeReqInParm& strNPWProductChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txBWSWaferListInq (::csBWSWaferListInqResult& strBWSWaferListInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSWaferListInqInParm& strBWSWaferListInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txBWSConfigInfoInq (::csBWSConfigInfoInqResult& strBWSConfigInfoInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSConfigInfoInqInParm& strBWSConfigInfoInqInParm, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txBWSConfigChangeReq (::csBWSConfigChangeReqResult& strBWSConfigChangeReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSConfigChangeReqInParm& strBWSConfigChangeReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txBWSInventoryReq (::csBWSInventoryReqResult& strBWSInventoryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csBWSInventoryReqInParm& strBWSInventoryReqInParm, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDurableDeliveryReq (::csDurableDeliveryReqResult& strDurableDeliveryReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDurableOpeCompForInternalBufferReq (::csDurableOpeCompForInternalBufferReqResult& strDurableOpeCompForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOpeCompForInternalBufferReqInParam& strDurableOpeCompForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDurableOperationStartCancelForInternalBufferReq (::csDurableOperationStartCancelForInternalBufferReqResult& strDurableOperationStartCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOperationStartCancelForInternalBufferReqInParam& strDurableOperationStartCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDurableOperationStartForInternalBufferReq (::csDurableOperationStartForInternalBufferReqResult& strDurableOperationStartForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurableOperationStartForInternalBufferReqInParam& strDurableOperationStartForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDurablesInfoForOpeStartForInternalBufferInq (::csDurablesInfoForOpeStartForInternalBufferInqResult& strDurablesInfoForOpeStartForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurablesInfoForOpeStartForInternalBufferInqInParam& strDurablesInfoForOpeStartForInternalBufferInqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txDurablesInfoForStartReservationForInternalBufferInq (::csDurablesInfoForStartReservationForInternalBufferInqResult& strDurablesInfoForStartReservationForInternalBufferInqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csDurablesInfoForStartReservationForInternalBufferInqInParam& strDurablesInfoForStartReservationForInternalBufferInqInParam, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txStartDurablesReservationCancelForInternalBufferReq (::csStartDurablesReservationCancelForInternalBufferReqResult& strStartDurablesReservationCancelForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csStartDurablesReservationCancelForInternalBufferReqInParam& strStartDurablesReservationCancelForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::CORBA::Long  cs_txStartDurablesReservationForInternalBufferReq (::csStartDurablesReservationForInternalBufferReqResult& strStartDurablesReservationForInternalBufferReqResult, const ::pptObjCommonIn& strObjCommonIn, const ::csStartDurablesReservationForInternalBufferReqInParam& strStartDurablesReservationForInternalBufferReqInParam, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

}; /* end of ::CS_PPTManager_ORBProxy*/
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
class  CS_PPTManagerProxyFactory : virtual public ::PPTManagerProxyFactory {

public:
   CS_PPTManagerProxyFactory (::CORBA::Boolean is_default = 0);

   virtual ::CORBA::Object_ptr create_proxy (const char* classname);
   virtual ::CORBA::Object_ptr asObject(void *obj);
}; // CS_PPTManagerProxyFactory


class  CS_PPTManager_Dispatcher : virtual public ::PPTManager_Dispatcher {

  public:

   CS_PPTManager_Dispatcher (::CORBA::Object_ptr target);

   CS_PPTManager_Dispatcher (); 

   virtual ::CORBA::Boolean dispatch (::CORBA::Request &request);
#ifdef _MSC_VER
   ::CORBA::Boolean __CS_PPTManager__dispatch(::CORBA::Request &_req);
#endif // _MSC_VER
}; // CS_PPTManager_Dispatcher
#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
class  CS_PPTManagerBOAImpl : virtual public 

   CS_PPTManager
, virtual public ::CORBA::Object_ORBProxy { 
   public:
     CS_PPTManagerBOAImpl() ;

     virtual ~CS_PPTManagerBOAImpl();
     CS_PPTManagerBOAImpl &operator= (const CS_PPTManagerBOAImpl &s);
     CS_PPTManagerBOAImpl (const CS_PPTManagerBOAImpl &s);
};  // CS_PPTManagerBOAImpl

    extern  ::CORBA::TypeCode_ptr _tc_CS_PPTManager;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_pptmgr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_pptmgr_ANYOPERATOR__
#undef __NOTUSE_cs_pptmgr_ANYOPERATOR__
#endif //__USE_cs_pptmgr_ANYOPERATOR__
#ifndef __NOTUSE_cs_pptmgr_ANYOPERATOR__
#define _DCL_ANYOPS_CS_PPTManager
#endif //__NOTUSE_cs_pptmgr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_CS_PPTManager
#ifndef __NOTUSE_ANYOPERATOR_INTERFACE__
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_PPTManager_ptr _data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_PPTManager_ptr *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_PPTManager_ptr& _data);
#endif
#endif //__NOTUSE_ANYOPERATOR_INTERFACE__
#endif // _DCL_ANYOPS_CS_PPTManager

#endif /* _cs_pptmgr_hh_included */

#endif /* _cs_pptmgr_server_defined */
