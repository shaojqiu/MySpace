// @(#) 1.2 superpos/src/csppt/source/posppt/pptmgr/cs_pptdefs.h, mm_srv_5_0_cspp, mm_srv_5_0_cspp 5/27/03 10:14:54 [ 5/27/03 10:14:56 ]
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2003. All rights reserved.
//
// SiView
// Name: cs_pptdefs.h
// Description:
//      This file contains the list of definitions required commonly between
//      CS_PPTServiceManager & PPT Client.
//
// Date       Version   Name        Description
// ---------- --------- ----------- ----------------------------------------
// 2003/03/06 D5000014  C.Tsuchiya  Initial Release
//

//implement here


