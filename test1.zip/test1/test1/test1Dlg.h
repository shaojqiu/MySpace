
// test1Dlg.h : ͷ�ļ�
//

#pragma once


// Ctest1Dlg �Ի���
class Ctest1Dlg : public CDialogEx
{
// ����
public:
	Ctest1Dlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TEST1_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	void DrawTitleBar(CDC * pDC);
	DECLARE_MESSAGE_MAP()
	CRect m_rtButtExit;
	CRect m_rtButtMax;
	CRect m_rtButtMin;
public:
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnNcMouseMove(UINT nHitTest, CPoint point);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
